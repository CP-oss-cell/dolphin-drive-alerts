package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors

class ForegroundPolicyAccessibilityService : AccessibilityService() {
    @Volatile private var activePackage: String? = null
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "dpi-adb-worker").apply { isDaemon = true } }

    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
            CoreLog.i("ACCESSIBILITY", "key-event filter enabled")
        }.onFailure { CoreLog.w("ACCESSIBILITY", "key-event filtering failed: ${it.message}") }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val pkg = event.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (pkg == activePackage) return
        activePackage = pkg
        worker.execute {
            if (pkg != activePackage) return@execute
            val policy = AppPolicyStore.all(this)[pkg]
            AppPolicyRuntime.activeRoute = policy?.audioRoute
            CoreLog.i("APP_POLICY", "foreground=$pkg dpi=${policy?.requestedDpi()} selfAudio=${policy?.audioRoute}")
            val success = DensityController.apply(this, policy?.requestedDpi())
            CoreLog.i("APP_POLICY", "DPI_APPLY_RESULT package=$pkg success=$success")
            if (policy != null) ExternalAppAudioRouter.apply(this, pkg, policy.audioRoute)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        SteeringTripleTapDetector.onKeyEvent(this, event)
        return false
    }

    override fun onInterrupt() = Unit
    override fun onDestroy() {
        activePackage = null
        AppPolicyRuntime.activeRoute = null
        worker.execute { DensityController.apply(this, null) }
        worker.shutdown()
        super.onDestroy()
    }
}
