# 믿음하나 브라우저 — APK 빌드 및 업데이트용 서명 안내 (v2.0.3)

## 가장 쉬운 첫 번째 빌드: GitHub Secrets 없이 실행

GitHub Actions에서 `MideumHanaBrowser_v2.0.3_Source` 워크플로를 실행하면 별도 설정 없이 **Debug APK**를 빌드합니다.
이것은 **임시 설치·테스트용**입니다. GitHub의 새 빌드에서는 서명 키가 달라질 수 있으므로 다음 버전으로 **삭제 없이 업데이트되는 것을 보장하지 않습니다**.

**앞으로 삭제 없이 덮어쓰려면 최초 기준 설치부터 아래 고정 서명키 방식으로 만든 Release APK를 설치하는 것이 필요합니다.** Debug APK에서 Release APK로 바꾸려면 기존 Debug APK 삭제가 필요할 수 있습니다. 앱 내부 데이터는 삭제될 수 있습니다.

## 업데이트 가능한 Release APK 빌드 — 최초 1회 설정

1. 본인이 관리하는 PC에서 JDK의 `keytool`로 **개인 전용** 키스토어를 생성합니다.

```bash
keytool -genkeypair -v -keystore MideumHanaBrowser-release.jks -storetype PKCS12 -alias mideumhana -keyalg RSA -keysize 3072 -validity 10000
```

생성 과정에서 비밀번호를 정해 보관하고 키 비밀번호도 동일하게 둡니다. 키스토어 파일과 비밀번호는 **다른 사람에게 보내거나 GitHub 저장소에 올리지 마세요.**

2. 키스토어를 Base64로 변환합니다.

Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path '.\MideumHanaBrowser-release.jks')))
```

macOS/Linux:

```bash
base64 < MideumHanaBrowser-release.jks | tr -d '\n'
```

3. GitHub 저장소 `Settings → Secrets and variables → Actions → New repository secret`에서 아래 **두 항목 모두** 등록합니다.

- `MHB_KEYSTORE_BASE64` : 2단계 Base64 문자열
- `MHB_KEYSTORE_PASSWORD` : 키스토어 생성 시 비밀번호

4. Actions 워크플로를 실행하면 자동으로 **Release APK**를 빌드하고 Artifact 이름에 `Release`가 표시됩니다.

이후 버전에서도 **패키지 ID `com.mideumhana.browser`, 동일 서명키와 alias, 증가하는 versionCode**를 유지해야 삭제 없이 업데이트할 수 있습니다.
키스토어 원본과 비밀번호는 안전하게 별도 백업하세요. 키를 잃으면 기존 설치본의 업데이트가 불가능해질 수 있습니다.

## 중요한 구분

- Secret 두 개 모두 없음 → `Debug APK` 빌드 성공(테스트용, 장기 업데이트 불확실)
- Secret 두 개 모두 있음 → `Release APK` 빌드 성공(업데이트용, 최초 설치부터 동일 키 사용)
- Secret 한 개만 있음 → 오류와 누락 안내를 표시하고 중단(실수로 Debug 빌드로 전환하지 않음)

서명키를 소스 코드나 통합 ZIP에 동봉하지 않습니다.
