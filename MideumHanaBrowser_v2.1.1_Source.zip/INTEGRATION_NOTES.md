# 믿음하나 브라우저 v2.1.0 통합 노트

기준: v2.0.4 실제 소스에서 작업. 이전 v1.x~v2.0.4 앱 패키지와 혼동하지 않고 `com.mideumhana.browser` 유지, versionCode 5 → 6.

## 통합 변경

- `HlsDownloadService.java`: 직접/ HLS 전송 통합, HTTP Range·ETag·If-Range·Content-Range 검증, HLS 구간별 동기화·체크포인트, 최종 저장 전 임시 스테이징, 크기 확인, 장치 앱 폴더에 임시파일 보존, 속도/ETA 반영, 서비스 종료시 정리.
- `TransferIntegrity.java`: Android에 의존하지 않는 이어받기 응답 범위 및 HLS 체크포인트 검증 규칙.
- `DownloadStore.java`: 신규 작업 상태, 용량·속도·남은 시간, 재개용 엔터티 식별자, 복구 대기, 임시 출력 URI 정리. 기존 기록은 삭제하지 않음.
- `StorageTarget.java`: 기본 Download/믿음하나와 SAF 폴더에서 동명이인 파일 검사 후 번호 부여, 실제 출력 문서 이름 반영.
- `MainActivity.java`: 새 직접 다운로드를 자체 서비스로 통합, 이어받기/새 작업 분리, 다운로드 통계 표시, 스크롤 유지, 앱 재실행 후 URL 탭 복원, 접힘/펼침 화면별 사이트 배율 보존.
- `BootRecoveryReceiver.java`: BOOT_COMPLETED에서 데이터 전송을 시작하지 않고 상태만 안전하게 재조정.
- `AndroidManifest.xml`: RECEIVE_BOOT_COMPLETED와 복구 Receiver 추가.
- `app/build.gradle`: v2.1.0 versionCode6, 같은 applicationId 및 서명 방식 유지.

## 검증 범위

Java 17 구문 파서, XML 파서, JavaScript Node 구문, 기존 회귀 검사, 새로운 정책 단위 테스트(범위 응답/서버 버전/HLS 지문), ZIP SHA256/CRC 및 GitHub 워크플로 자동 압축 해제 시나리오.

**미실행**: Android SDK에서 AAPT 및 APK 컴파일, 네트워크 서버에 대한 Android 실기기 통합 테스트, 폴드8 실제 배율 검증. 따라서 빌드/실사용 성공은 확정할 수 없음.
