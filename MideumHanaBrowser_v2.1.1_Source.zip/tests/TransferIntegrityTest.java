package com.mideumhana.browser;

public final class TransferIntegrityTest {
    static void check(boolean good) { if (!good) throw new AssertionError(); }
    static void invalid(String header, long start) {
        try { TransferIntegrity.contentRangeTotal(header, start); throw new AssertionError(header); }
        catch (AssertionError ae) { throw ae; }
        catch (Exception expected) { }
    }
    public static void main(String[] args) throws Exception {
        check(TransferIntegrity.contentRangeTotal("bytes 100-199/400", 100) == 400);
        check(TransferIntegrity.contentRangeTotal("bytes 0-99/*", 0) == -1);
        invalid("bytes 0-199/400", 100); // server ignored requested starting byte
        invalid("bytes 200-199/400", 200);
        invalid("bytes 100-400/400", 100);
        invalid("garbage", 100);
        check(TransferIntegrity.validatorMatches("\"v1\"", "", "\"v1\"", null));
        check(!TransferIntegrity.validatorMatches("\"v1\"", "", "\"v2\"", null));
        check(!TransferIntegrity.validatorMatches("\"v1\"", "", null, null));
        check(TransferIntegrity.validatorMatches("W/\"weak\"", "Tue, 04 Nov 2026 12:00:00 GMT", null,
                "Tue, 04 Nov 2026 12:00:00 GMT"));
        check(!TransferIntegrity.validatorMatches("W/\"weak\"", "", null, null));
        check(TransferIntegrity.keepHlsCheckpoint("hash", "hash", 3, 10, 2048, 2100));
        check(!TransferIntegrity.keepHlsCheckpoint("old", "new", 3, 10, 2048, 2100));
        check(!TransferIntegrity.keepHlsCheckpoint("hash", "hash", 3, 10, 2048, 2047));
        check(!TransferIntegrity.keepHlsCheckpoint("hash", "hash", 11, 10, 2048, 2100));
        System.out.println("RANGE_HLS_CHECKPOINT_INTEGRITY_TEST_OK");
    }
}
