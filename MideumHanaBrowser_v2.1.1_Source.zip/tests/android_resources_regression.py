from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
layout = root / 'app/src/main/res/layout/activity_main.xml'
xml = layout.read_text(encoding='utf8')
ET.parse(layout)
assert 'android:horizontalScrollBarEnabled' not in xml
assert 'web_tab_strip' not in xml, 'Old hidden scroll-strip should be removed in card-grid UI'
assert 'settings_menu' in xml
assert 'open_tabs' in xml
print('AAPT_CARD_GRID_RESOURCE_REGRESSION_OK')
