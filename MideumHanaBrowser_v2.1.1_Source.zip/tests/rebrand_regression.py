from pathlib import Path
from xml.etree import ElementTree
root = Path(__file__).resolve().parents[1]
a = root / 'app/src/main'
manifest = (a / 'AndroidManifest.xml').read_text()
layout = (a / 'res/layout/activity_main.xml').read_text()
strings = ElementTree.parse(a / 'res/values/strings.xml').getroot()
names = {x.attrib.get('name'):x.text for x in strings}
assert names['app_name'] == '믿음하나 브라우저'
assert 'android:label="@string/app_name"' in manifest
assert 'android:text="@string/app_name"' in layout
for java in ('MainActivity.java', 'HlsDownloadService.java'):
    code = (a / 'java/com/mideumhana/browser' / java).read_text()
    assert 'getString(R.string.app_name)' in code
    assert '"CleanVideo Browser"' not in code
build = (root/'app/build.gradle').read_text()
assert "applicationId 'com.mideumhana.browser'" in build
assert 'versionCode 7' in build
assert "versionName '2.1.1'" in build
assert "rootProject.name = 'MideumHanaBrowser'" in (root/'settings.gradle').read_text()
print('APP_REBRAND_OK')
