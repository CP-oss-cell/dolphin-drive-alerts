from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
main=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
assert 'android:usesCleartextTraffic="false"' in manifest
assert 's.setSafeBrowsingEnabled(true)' in main
assert 'handler.cancel()' in main
assert 'MIXED_CONTENT_NEVER_ALLOW' in main
assert 's.setAllowFileAccess(false)' in main
assert 'addJavascriptInterface' not in main
assert 'evaluateJavascript(scanScript' in main
print('SECURITY_STATIC_OK')
