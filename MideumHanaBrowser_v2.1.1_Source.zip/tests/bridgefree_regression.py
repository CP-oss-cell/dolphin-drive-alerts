"""Check native bridge removal and top-page-only scanner behavior (Node VM, no network)."""
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parents[1]
source = root / 'app/src/main/assets/video_scan.js'
main = (root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
assert 'addJavascriptInterface' not in main
assert 'new JSONTokener(json)' in main
assert 'openCompletedDownload' in main
assert 'DownloadStore.setUri' in (root/'app/src/main/java/com/mideumhana/browser/HlsDownloadService.java').read_text()
node = r"""
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const script=fs.readFileSync(process.argv[1],'utf8');
const video={paused:false,ended:false,videoWidth:1920,videoHeight:1080,duration:650,
  currentSrc:'https://media.test/video/main.mp4',src:'',
  getBoundingClientRect:()=>({width:640,height:360,bottom:400,top:0}),
  querySelectorAll:()=>[]};
function scan(iframe=false){
  const win={}; win.top=iframe?{}:win;
  const ctx={window:win,location:{href:'https://media.test/watch'},
    document:{baseURI:'https://media.test/watch',querySelectorAll:()=>[video]},
    performance:{getEntriesByType:()=>[{name:'https://ads.test/ad/preroll.mp4'},
      {name:'https://media.test/video/main.mp4'}]},
    innerHeight:800,URL,Math,isFinite,JSON,Object};
  return JSON.parse(vm.runInNewContext(script,ctx));
}
let top=scan();
assert.equal(top.page,'https://media.test/watch');
assert.equal(top.videos.length,2);
assert.equal(top.videos[0].source,3);
assert.equal(top.videos[0].playing,true);
assert.equal(top.videos[1].source,1);
assert.equal(scan(true).videos.length,0);
console.log('BRIDGEFREE_SCANNER_OK');
"""
subprocess.run(['node', '-e', node, str(source)],check=True)
