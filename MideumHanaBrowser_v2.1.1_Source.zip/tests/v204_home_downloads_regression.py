"""Non-Android structural checks; APK and device behavior require separate validation."""
from pathlib import Path
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
store=(root/'app/src/main/java/com/mideumhana/browser/DownloadStore.java').read_text()
service=(root/'app/src/main/java/com/mideumhana/browser/HlsDownloadService.java').read_text()
layout=root/'app/src/main/res/layout/activity_main.xml'
tree=ElementTree.parse(layout)
android='{http://schemas.android.com/apk/res/android}'
elements={node.attrib[android+'id'].replace('@+id/',''):node
          for node in tree.iter() if android+'id' in node.attrib}
all_ids=[n.attrib[android+'id'] for n in tree.iter() if android+'id' in n.attrib]
assert len(all_ids)==len(set(all_ids)), 'Duplicate XML view ID'
for name in ('home','open_tabs','new_web_tab','download_bulk_actions',
             'select_downloads','select_all_downloads','stop_downloads',
             'retry_downloads','delete_downloads','downloads_list'):
    assert name in elements,name
assert elements['open_tabs'].get(android+'text')=='탭 1 ▦'
header=next(node for node in tree.iter() if any(c.attrib.get(android+'text')=='@string/app_name' for c in list(node)))
header_children=list(header)
title_idx=next(i for i,c in enumerate(header_children) if c.attrib.get(android+'text')=='@string/app_name')
assert header_children[title_idx+1].attrib.get(android+'id')=='@+id/dashboard_status'
assert header_children[title_idx+2].attrib.get(android+'id')=='@+id/open_tabs'
assert header_children[title_idx+3].attrib.get(android+'id')=='@+id/new_web_tab'
assert 'web_tab_strip' not in elements and 'GridLayout grid' in main
assert 'showHomeSettings()' in main and 'Bookmarks.all(this)' in main
assert 'PREF_HOME_URL' in main and 'browser.loadUrl(homeUrl())' in main
assert 'showTabPicker(false)' in main and 'showTabPicker(true)' in main
assert 'setAdapter(new ArrayAdapter<>(this,' not in main[main.index('private void renderDownloads()'):main.index('private void openCompletedDownload(')]
assert 'setSelectionFromTop' in main and 'getFirstVisiblePosition()' in main
assert 'visible instanceof TextView' in main
assert 'BaseAdapter' in main and 'selectedDownloadIds' in main
assert '목록에서만 삭제 (파일 유지)' in main
assert '목록과 다운로드 파일 함께 삭제' in main
assert 'DownloadManager' in main and 'manager.remove(Long.parseLong(row.id))' in main
assert 'retryDownload' in main and 'resumeDownload(row, false)' in main
assert 'static synchronized void addSource' in store and 'static synchronized void remove' in store
assert 'ACTION_CANCEL' in service and 'check(id)' in service
assert 'target' in service and 'StorageTarget.delete' in service
assert 'getCookie(url)' in main and 'o.put("cookie"' not in store
assert "versionName '2.1.1'" in (root/'app/build.gradle').read_text()
print('HOME_DOWNLOAD_MANAGEMENT_STATIC_REGRESSION_OK')
