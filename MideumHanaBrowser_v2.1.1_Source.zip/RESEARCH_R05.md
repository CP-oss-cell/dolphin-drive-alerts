# CleanVideoBrowser R05 — 2026-11-04

## 확인된 문제
- v1.1.2 AndroidManifest.xml은 cleartextTraffic=true여서 앱 전체에서 평문 HTTP가 허용됨.
- Safe Browsing이 명시적으로 활성화되어 있지 않음.
- URL 검증이 userinfo를 거부하지 않아 `https://trusted.example@evil.example/` 같은 오해 소지가 있는 URL 허용.

## 이번 수정 (v1.1.3)
- 앱 기본 평문 통신 금지 (`usesCleartextTraffic=false`). HTTP만 제공하는 사이트 및 영상 다운로드는 제한될 수 있음.
- Android 8+ WebView Safe Browsing 활성화. 실제 차단 여부는 WebView 공급자 및 기기 설정에 좌우됨.
- 미디어 후보 URL에서 내장 자격 증명(userinfo) 거부.
- 기존 SSL 오류 차단, 혼합 콘텐츠 금지, WebView 파일 접근 차단 유지.

## 미해결 보안 위험
- addJavascriptInterface는 iframe에서도 접근할 수 있고 JS가 보고한 페이지 문자열은 위조 가능. 현 구조의 samePageHost 검증만으로는 신뢰 경계가 완전하지 않음. 추후 origin이 검증되는 WebMessageListener 또는 네이티브 DOM/네트워크 관측 기반 재설계 필요.
- URL 리다이렉트/사설 IP 접근/다운로드 크기 제한/파일명 Unicode 정규화/Content-Disposition 처리는 추가 점검 필요.
- HTTP 허용을 끄면 로컬 테스트 HTTP 서버 및 일부 사이트에 영향을 줄 수 있음.
- DRM 보호 콘텐츠 우회는 지원하지 않음.

## 검증 범위
- Python 정적 보안 검사, 기존 오프라인 회귀 테스트, XML 파싱, ZIP CRC 확인.
- Android SDK 빌드 및 실제 단말 테스트는 별도로 확인해야 함.
