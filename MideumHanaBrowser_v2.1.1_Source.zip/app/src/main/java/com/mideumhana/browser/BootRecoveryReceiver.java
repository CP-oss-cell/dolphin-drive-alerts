package com.mideumhana.browser;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Android 15+ forbids launching dataSync foreground services from BOOT_COMPLETED.
 *  Recover the journal only; the user can resume from the download list. */
public final class BootRecoveryReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))
            DownloadStore.reconcile(context);
    }
}
