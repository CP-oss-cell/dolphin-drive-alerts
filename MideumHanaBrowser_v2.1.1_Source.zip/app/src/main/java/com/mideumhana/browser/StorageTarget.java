package com.mideumhana.browser;

import android.content.Context;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import java.io.OutputStream;
import android.database.Cursor;
import android.content.ContentResolver;
import java.util.HashSet;
import java.util.Set;

/** User-selected Storage Access Framework tree; otherwise public Downloads/믿음하나. */
final class StorageTarget {
    private static final String PREFS = "mideumhana_local_v2";
    private static final String TREE = "target_tree_uri";
    private StorageTarget() {}

    static String selected(Context c) {
        return c.getSharedPreferences(PREFS, 0).getString(TREE, "");
    }
    static void choose(Context c, Uri tree) {
        c.getSharedPreferences(PREFS, 0).edit().putString(TREE, tree.toString()).apply();
    }
    static void reset(Context c) {
        c.getSharedPreferences(PREFS, 0).edit().remove(TREE).apply();
    }
    static String display(Context c) {
        String raw = selected(c);
        if (raw.isEmpty()) return "다운로드/믿음하나";
        try {
            String id = DocumentsContract.getTreeDocumentId(Uri.parse(raw));
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? "선택한 폴더" : path;
        } catch (Exception e) { return "선택한 폴더"; }
    }
    static final class FileOutput {
        final Uri uri;
        final boolean mediaStore;
        FileOutput(Uri u, boolean mediaStore) { this.uri = u; this.mediaStore = mediaStore; }
    }
    /** Detect existing names in the selected SAF tree or public Downloads folder. */
    private static String unusedName(Context c, String treeRaw, String suggested) throws Exception {
        String name = DownloadStore.safeFileName(suggested);
        Set<String> existing = new HashSet<>();
        ContentResolver resolver = c.getContentResolver();
        if (treeRaw != null && !treeRaw.isEmpty()) {
            Uri tree = Uri.parse(treeRaw);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            try (Cursor cursor = resolver.query(children,
                    new String[] {DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
                if (cursor == null) throw new Exception("저장 폴더를 읽을 수 없습니다. 다시 선택하세요");
                while (cursor.moveToNext()) {
                    String old = cursor.getString(0);
                    if (old != null) existing.add(old.toLowerCase(java.util.Locale.ROOT));
                }
            }
        } else {
            try (Cursor cursor = resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[] {MediaStore.MediaColumns.DISPLAY_NAME},
                    MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    new String[] {Environment.DIRECTORY_DOWNLOADS + "/믿음하나/"}, null)) {
                if (cursor != null) while (cursor.moveToNext()) {
                    String old = cursor.getString(0);
                    if (old != null) existing.add(old.toLowerCase(java.util.Locale.ROOT));
                }
            }
        }
        String base = name, extension = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); extension = name.substring(dot); }
        for (int n = 0; n < 10000; n++) {
            String candidate = n == 0 ? name : base + " (" + n + ")" + extension;
            if (!existing.contains(candidate.toLowerCase(java.util.Locale.ROOT))) return candidate;
        }
        throw new Exception("저장 파일명이 너무 많이 중복됩니다");
    }

    static FileOutput create(Context c, String treeRaw, String name, String mime) throws Exception {
        Uri uri;
        name = unusedName(c, treeRaw, name);
        if (treeRaw != null && !treeRaw.isEmpty()) {
            Uri tree = Uri.parse(treeRaw);
            Uri document = DocumentsContract.buildDocumentUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            uri = DocumentsContract.createDocument(c.getContentResolver(), document, mime, name);
            if (uri == null) throw new Exception("선택한 폴더에 파일을 만들 수 없습니다. 폴더를 다시 지정하세요");
            return new FileOutput(uri, false);
        }
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/믿음하나");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("기본 다운로드 폴더를 만들 수 없습니다");
        return new FileOutput(uri, true);
    }
    static String actualName(Context c, Uri document, String fallback) {
        try (Cursor cursor = c.getContentResolver().query(document,
                new String[] {MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && !cursor.isNull(0))
                return cursor.getString(0);
        } catch (Exception ignored) { }
        return fallback;
    }
    static OutputStream open(Context c, FileOutput target) throws Exception {
        OutputStream out = c.getContentResolver().openOutputStream(target.uri, "w");
        if (out == null) throw new Exception("저장 파일을 열 수 없습니다");
        return out;
    }
    static void finish(Context c, FileOutput target) throws Exception {
        if (!target.mediaStore) return;
        ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        if (c.getContentResolver().update(target.uri, ready, null, null) != 1)
            throw new Exception("저장 파일을 완료 상태로 전환할 수 없습니다");
    }
    static void delete(Context c, FileOutput target) {
        if (target == null) return;
        try { c.getContentResolver().delete(target.uri, null, null); }
        catch (Exception ignored) { }
    }
}
