package com.mideumhana.browser;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Portable validation rules, testable independently of Android. */
final class TransferIntegrity {
    private static final Pattern RANGE = Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+|\\*)");
    private TransferIntegrity() { }

    static long contentRangeTotal(String header, long start) throws Exception {
        if (header == null) throw new Exception("서버가 Content-Range를 보내지 않았습니다");
        Matcher match = RANGE.matcher(header.trim());
        if (!match.matches()) throw new Exception("잘못된 Content-Range");
        long first = Long.parseLong(match.group(1));
        long last = Long.parseLong(match.group(2));
        long total = "*".equals(match.group(3)) ? -1 : Long.parseLong(match.group(3));
        if (first != start || last < first || (total >= 0 && last >= total))
            throw new Exception("이어받기 범위 검증 실패");
        return total;
    }

    static boolean keepHlsCheckpoint(String oldHash, String newHash, int index,
                                     int segmentCount, long committedBytes, long stagedBytes) {
        return oldHash != null && oldHash.equals(newHash)
                && index >= 0 && index <= segmentCount && committedBytes >= 0
                && stagedBytes >= committedBytes;
    }

    static boolean validatorMatches(String oldEtag, String oldModified,
                                    String newEtag, String newModified) {
        if (oldEtag != null && !oldEtag.isEmpty() && !oldEtag.startsWith("W/"))
            return newEtag != null && oldEtag.equals(newEtag);
        if (oldModified != null && !oldModified.isEmpty())
            return newModified != null && oldModified.equals(newModified);
        return false;
    }
}
