package com.mideumhana.browser;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Records downloads only on this device; never sends URLs or usage information out. */
final class DownloadStore {
    private static final String PREFS = "mideumhana_local_v2";
    private static final String KEY = "downloads";

    private DownloadStore() {}

    static synchronized void add(Context c, String id, String type, String name) {
        addSource(c, id, type, name, "", "", "", "");
    }

    /** Preserve a retryable source without storing session cookies or passwords. */
    static synchronized void addSource(Context c, String id, String type, String name,
                                       String url, String referer, String folder, String userAgent) {
        JSONArray all = loadArray(c);
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("type", type);
            o.put("name", name);
            o.put("url", url == null ? "" : url);
            o.put("referer", referer == null ? "" : referer);
            o.put("folder", folder == null ? "" : folder);
            o.put("ua", userAgent == null ? "" : userAgent);
            o.put("status", "대기 중");
            o.put("progress", 0);
            o.put("created", System.currentTimeMillis());
            o.put("state", "QUEUED");
            o.put("bytes", 0L);
            o.put("total", -1L);
            o.put("speed", 0L);
            o.put("eta", -1L);
            o.put("segmentIndex", 0);
            o.put("segmentBytes", 0L);
            JSONArray result = new JSONArray();
            result.put(o);
            for (int i = 0; i < all.length() && i < 299; i++) result.put(all.optJSONObject(i));
            save(c, result);
        } catch (Exception ignored) { }
    }

    static synchronized JSONObject get(Context c, String id) {
        for (JSONObject item : list(c)) if (id.equals(item.optString("id"))) return item;
        return null;
    }

    /** Remove only local history; never delete a downloaded file. */
    static synchronized void remove(Context c, String id) {
        JSONArray all = loadArray(c);
        JSONArray kept = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject item = all.optJSONObject(i);
            if (item != null && !id.equals(item.optString("id"))) kept.put(item);
        }
        save(c, kept);
    }

    static synchronized void update(Context c, String id, String status, int progress) {
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) {
                try {
                    o.put("status", status);
                    o.put("progress", Math.max(0, Math.min(100, progress)));
                    save(c, all);
                } catch (Exception ignored) { }
                break;
            }
        }
    }

    /** Atomic journal in app-private preferences; never stores cookies or authorization headers. */
    static synchronized void patch(Context c, String id, String... fields) {
        if (fields.length % 2 != 0) throw new IllegalArgumentException("field/value pairs");
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null || !id.equals(o.optString("id"))) continue;
            try {
                for (int k = 0; k < fields.length; k += 2) {
                    String raw = fields[k + 1];
                    if (fields[k].equals("bytes") || fields[k].equals("total") ||
                            fields[k].equals("speed") || fields[k].equals("eta") ||
                            fields[k].equals("segmentBytes")) o.put(fields[k], Long.parseLong(raw));
                    else if (fields[k].equals("segmentIndex") || fields[k].equals("progress"))
                        o.put(fields[k], Integer.parseInt(raw));
                    else o.put(fields[k], raw);
                }
                save(c, all);
            } catch (Exception ignored) { }
            return;
        }
    }

    static synchronized void transfer(Context c, String id, String state,
                                      long bytes, long total, long speed, long eta, String status) {
        int pct = total > 0 ? (int) Math.min(99L, bytes * 100L / total) : 0;
        patch(c, id, "state", state, "bytes", Long.toString(bytes),
                "total", Long.toString(total), "speed", Long.toString(speed),
                "eta", Long.toString(eta), "progress", Integer.toString(pct),
                "status", status);
    }

    /** On a cold start, jobs that lost their process become recoverable rather than 'running' forever. */
    static synchronized void reconcile(Context c) {
        JSONArray all = loadArray(c);
        boolean changed = false;
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null || !o.optString("type").startsWith("service-")) continue;
            String pendingUri = o.optString("targetUri");
            if (!pendingUri.isEmpty() && !HlsDownloadService.isJobActive(o.optString("id"))) {
                try { c.getContentResolver().delete(android.net.Uri.parse(pendingUri), null, null); }
                catch (Exception ignored) { }
                try { o.put("targetUri", ""); changed = true; } catch (Exception ignored) { }
            }
            String state = o.optString("state");
            boolean oldActive = state.isEmpty() &&
                    (o.optString("status").startsWith("다운로드 중")
                    || o.optString("status").startsWith("대기 중")
                    || o.optString("status").startsWith("중지 요청"));
            if (("RUNNING".equals(state) || "QUEUED".equals(state) || oldActive)
                    && !HlsDownloadService.isJobActive(o.optString("id"))) {
                try {
                    o.put("state", "RECOVERY");
                    o.put("status", "중단됨 · 이어받기 선택");
                    changed = true;
                } catch (Exception ignored) { }
            }
        }
        if (changed) save(c, all);
    }

    static synchronized String freshName(Context c, String candidate) {
        String name = safeFileName(candidate);
        String stem = name; String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { stem = name.substring(0, dot); ext = name.substring(dot); }
        List<JSONObject> old = list(c);
        for (int n = 0; n < 1000; n++) {
            String next = n == 0 ? name : stem + " (" + n + ")" + ext;
            boolean used = false;
            for (JSONObject o : old) if (next.equalsIgnoreCase(o.optString("name"))) { used = true; break; }
            if (!used) return next;
        }
        return stem + "-" + System.currentTimeMillis() + ext;
    }

    static synchronized void setUri(Context c, String id, String uri) {
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) {
                try { o.put("uri", uri); save(c, all); }
                catch (Exception ignored) { }
                break;
            }
        }
    }

    static synchronized List<JSONObject> list(Context c) {
        List<JSONObject> result = new ArrayList<>();
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null) result.add(o);
        }
        return result;
    }

    private static JSONArray loadArray(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try { return new JSONArray(p.getString(KEY, "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray arr) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, arr.toString()).commit();
    }

    static String safeFileName(String candidate) {
        if (candidate == null) candidate = "video.mp4";
        String s = candidate.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        s = s.replaceAll("^\\.+", "");
        if (s.length() > 110) {
            int dot = s.lastIndexOf('.');
            String ext = dot > 0 ? s.substring(dot) : "";
            s = s.substring(0, Math.min(100, s.length())) + ext;
        }
        return s.isEmpty() ? "video.mp4" : s;
    }
}
