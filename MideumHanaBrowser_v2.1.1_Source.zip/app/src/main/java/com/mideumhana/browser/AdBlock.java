package com.mideumhana.browser;

import android.net.Uri;
import java.util.Locale;

/** Small, local domain deny-list; no ad service or tracking SDK is bundled. */
final class AdBlock {
    private static final String[] HOSTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
        "pubmatic.com", "rubiconproject.com", "criteo.com", "criteo.net",
        "unityads.unity3d.com", "applovin.com", "ironsrc.com",
        "inmobi.com", "adsrvr.org", "amazon-adsystem.com"
    };

    private AdBlock() {}

    static boolean blocked(Uri uri) {
        if (uri == null || uri.getHost() == null) return false;
        String host = uri.getHost().toLowerCase(Locale.ROOT);
        for (String bad : HOSTS) {
            if (host.equals(bad) || host.endsWith("." + bad)) return true;
        }
        return false;
    }
}
