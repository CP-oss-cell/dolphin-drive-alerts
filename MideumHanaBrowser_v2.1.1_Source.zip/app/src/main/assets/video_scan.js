/* One-shot top-document scan, returned via WebView.evaluateJavascript().
   No native JS interface is exposed to embedded/advertising iframes. */
(function () {
  'use strict';
  var media = [];
  var seen = Object.create(null);
  function collect(url, source, width, height, duration, playing) {
    try {
      if (!url || /^(blob|data|javascript):/i.test(url)) return;
      var resolved = new URL(url, document.baseURI);
      if (!/^https?:$/.test(resolved.protocol)) return;
      var href = resolved.href;
      if (href.length > 4096) return;
      if (seen[href] || media.length >= 75) return;
      seen[href] = true;
      media.push({url:href, source:source, width:Math.max(0,Math.round(width||0)),
        height:Math.max(0,Math.round(height||0)),
        duration:Math.max(0,Math.round(isFinite(duration)?duration:0)),
        playing:!!playing});
    } catch (e) { /* invalid or inaccessible URL */ }
  }
  try {
    if (window !== window.top) return JSON.stringify({page:location.href,videos:[]});
    var videos = document.querySelectorAll('video');
    for (var i=0;i<videos.length && i<40;i++) {
      var v = videos[i];
      var rect = v.getBoundingClientRect();
      var visible = rect.width >= 180 && rect.height >= 100 && rect.bottom > 0
        && rect.top < innerHeight;
      var playing = !v.paused && !v.ended;
      if (!visible && !playing) continue;
      var source = playing ? 3 : 2;
      var width = v.videoWidth || rect.width || 0;
      var height = v.videoHeight || rect.height || 0;
      collect(v.currentSrc || v.src, source, width, height, v.duration, playing);
      var children = v.querySelectorAll('source[src]');
      for (var j=0;j<children.length && j<8;j++)
        collect(children[j].src, source, width, height, v.duration, playing);
    }
    var entries = performance.getEntriesByType('resource');
    for (var k=Math.max(0, entries.length-160);k<entries.length;k++) {
      var url=entries[k].name;
      if (/\.(m3u8|mp4|m4v|mov|webm)(?:[?#]|$)/i.test(url))
        collect(url, 1, 0, 0, 0, false);
    }
  } catch (e) { /* site-specific DOM may be inaccessible */ }
  return JSON.stringify({page:location.href,videos:media});
})();
