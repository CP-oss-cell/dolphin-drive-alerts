# CleanVideoBrowser R06 — UI/UX 개선 (2026-11-04)

v1.1.3 기준으로 화면 하단 영상 추천 카드를 재배치했다. 본편 추정의 불확실성을 명시하고, 현재 페이지 제목과 저장 위치를 표시하며, 저장 폴더 변경과 화질 선택/다운로드를 같은 카드에서 접근하도록 했다. MP4는 원본 받기, HLS는 화질 선택 후 받기로 문구를 구분했다. 다른 후보는 필요할 때만 표시한다.

검증: tests/verify_project.py, tests/offline_regression.py, tests/security_regression.py PASS. Android SDK/Gradle APK 컴파일 및 실기기 검증은 미수행. 감지 신뢰도 개선과 프레임 출처 검증, SAF 저장 완료 검증은 남은 과제다. 이 UI는 기존 팝업 다운로드 절차를 유지하므로 완전한 단일 화면 다운로드는 아니다.
