# CleanVideoBrowser R07 — 2026-11-04

## Source-based findings
- `addJavascriptInterface` exposes methods to every frame. A frame can spoof the `page` parameter; Java-side URL equality is not authentication.
- v1.1.4 accepted same-host *different-page* reports. v1.1.5 requires exact document URL (ignoring fragments), and the injected script avoids reporting from subframes. This reduces accidental cross-frame mixing but **does not eliminate malicious-frame spoofing**.
- Network-resource candidates are still not cryptographically tied to the playing video. Ad filtering is heuristic.
- v1.1.4 source and workflow were available; Android SDK/Gradle executable not found, so APK compilation and device behavior remain unverified.

## Follow-up priorities
1. Replace frame-wide JavaScript bridge with origin-scoped WebMessageListener via AndroidX WebKit and validate actual sender origin and main-frame status; account for library dependency and supported WebView versions.
2. Verify SAF writes, failure cleanup and final file integrity with instrumented tests.
3. Validate HLS separate audio and variant handling with local fixture streams.
4. Integrate quality/folder/download controls into a single UI and verify accessibility.
5. Run GitHub Actions APK build and on-device tests; do not call static checks a release validation.

## Safety
No DRM bypass, no authenticated-content circumvention. v1.1.5 is an incremental hardening candidate, not a production-ready download engine.
