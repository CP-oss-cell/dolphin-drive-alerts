# Dolphin Drive Alerts v0.17.8 GitHub APK 빌드

1. `DolphinDriveAlerts-v0.17.8-RELIABILITY-RESEARCH-source.zip` 그대로 GitHub `CP-oss-cell/dolphin-drive-alerts` 저장소 루트에 업로드합니다.
2. `build-v0178-from-source-zip.yml`을 `.github/workflows/build-v0178-from-source-zip.yml`에 업로드합니다.
3. GitHub Actions → `Build Dolphin Drive Alerts v0.17.8` → Run workflow → `build-apk` 성공 후 Artifacts에서 APK를 받습니다.
4. *APK는 이 패키지에 미리 포함돼 있지 않습니다.* 현재 도구에는 해당 GitHub 저장소 push 권한이 없고, 로컬 Android SDK 전체 빌드는 실행하지 못했습니다.
5. 재시동·BSD·DOW·앞차 출발·차선/ICC·미디어/분할·DPI·EQ·운전석 음성·AVAS는 첨부 연구 이슈표대로 검증하며, 미확인 안전 신호를 발화로 연결하지 않습니다.
