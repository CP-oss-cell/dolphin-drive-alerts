plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.byd.dolphin.drivealerts"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.byd.dolphin.drivealerts"
        minSdk = 29
        targetSdk = 29
        versionCode = 35
        versionName = "0.17.9-oem-wake-signal-recovery"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging.resources.excludes += setOf("META-INF/LICENSE.md", "META-INF/LICENSE-notice.md")
}

dependencies {
    implementation("dev.mobile:dadb:1.2.8")
}
