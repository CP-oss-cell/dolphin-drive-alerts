package com.byd.dolphin.drivealerts.automation

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper
import android.widget.*

/** Multi-app ignition launch playlist. Each delay is relative to the previous action. */
class AutoLaunchSettingsActivity:Activity() {
    private lateinit var panel:LinearLayout
    private lateinit var apps:List<AppSelection.App>
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        apps=AppSelection.launchable(this)+FeatureProfiles.splits(this).map {
            AppSelection.App("분할 프로필: ${it.title}","split:${it.id}")
        }
        panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,28)}
        setContentView(ScrollView(this).apply{addView(panel)})
        redraw()
    }
    private fun label(s:String)=TextView(this).apply{text=s;textSize=16f;setPadding(0,8,0,8)}
    private fun button(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun redraw(){
        panel.removeAllViews()
        panel.addView(label("시동 시 여러 앱 자동실행 / 앱별 지연 · 미디어 재생"))
        panel.addView(Switch(this).apply{
            text="시동 자동 실행 시퀀스 ON/OFF"
            isChecked=FeatureProfiles.sequenceEnabled(this@AutoLaunchSettingsActivity)
            setOnCheckedChangeListener{_,v->FeatureProfiles.setSequenceEnabled(this@AutoLaunchSettingsActivity,v)}
        })
        panel.addView(label("시동 신호당 1회, 등록 순서대로 실행합니다. 각 앱 실행 전 지연(초), 미디어 앱의 재생 전 지연(초)을 별도 설정합니다. 저장된 분할 프로필도 단계로 선택할 수 있습니다. 앱 백그라운드 유지/실제 재생은 앱·Android 정책에 따라 달라집니다."))
        panel.addView(button("+ 앱 추가",{edit(null)}))
        panel.addView(button("ADB 미디어 알림 권한 적용·확인",{
            Thread({
                val result = PermissionBootstrapper.apply(applicationContext)
                runOnUiThread { toast(result.lines.filter{it.contains("미디어 알림") || it.contains("로컬 ADB")}.joinToString(" / ").take(200)) }
            },"media-adb-permission").start()
        }))
        panel.addView(button("저장된 시퀀스 지금 수동 실행",{AutoLaunchSequenceService.start(this,true)}))
        panel.addView(button("자동 실행 취소",{
            stopService(Intent(this,AutoLaunchSequenceService::class.java))
            toast("실행 중단 요청")
        }))
        FeatureProfiles.steps(this).forEachIndexed{idx,step->
            panel.addView(label("${idx+1}. ${step.packageName}\n${step.delaySeconds}초 뒤 실행 / 미디어=${step.isMedia} / 재생 ${step.playDelaySeconds}초 뒤 / 백그라운드=${step.restoreBackground} / 사용=${step.enabled}"))
            panel.addView(button("편집",{edit(step)}))
            panel.addView(button("위로",{move(step,-1)}))
            panel.addView(button("아래로",{move(step,1)}))
            panel.addView(button("삭제",{FeatureProfiles.saveSteps(this,FeatureProfiles.steps(this).filterNot{it.id==step.id});redraw()}))
        }
        panel.addView(label("미디어+백그라운드 선택 시 앱 화면을 열지 않습니다. 대상 앱에서 MediaSession/MediaBrowser가 제공되지 않으면 자동 재생은 실패로 기록합니다. 해당 앱을 미리 한 번 실행하거나 미디어앱 자체 자동재개 설정이 필요할 수 있습니다."))
    }
    private fun move(step:LaunchStep,direction:Int){
        val list=FeatureProfiles.steps(this).toMutableList()
        val from=list.indexOfFirst{it.id==step.id};val to=from+direction
        if(from>=0&&to in list.indices){val old=list.removeAt(from);list.add(to,old);FeatureProfiles.saveSteps(this,list);redraw()}
    }
    private fun edit(old:LaunchStep?){
        if(apps.isEmpty()){toast("실행 가능한 앱을 찾을 수 없습니다");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,6,24,6)}
        val packages=apps.map{"${it.title} (${it.packageName})"}
        val chooser=Spinner(this).apply{adapter=ArrayAdapter(this@AutoLaunchSettingsActivity,android.R.layout.simple_spinner_dropdown_item,packages)}
        old?.let {chooser.setSelection(apps.indexOfFirst{a->a.packageName==old.packageName}.coerceAtLeast(0))}
        val delay=EditText(this).apply{hint="앱 실행 전 지연 (초, 0~600)";inputType=2;setText("${old?.delaySeconds?:0}")}
        val media=CheckBox(this).apply{text="미디어 앱 (재생 명령 추가)";isChecked=old?.isMedia?:false}
        val play=EditText(this).apply{hint="앱 실행 후 재생 지연 (초, 0~600)";inputType=2;setText("${old?.playDelaySeconds?:3}")}
        val background=CheckBox(this).apply{text="미디어 앱 화면 열지 않고 백그라운드 재생만 시도 (MediaSession/Browser 지원 앱)";isChecked=old?.restoreBackground?:false}
        val enabled=CheckBox(this).apply{text="이 앱 자동실행 사용";isChecked=old?.enabled?:true}
        box.addView(label("실행할 앱"));box.addView(chooser);box.addView(label("실행 전 지연(초)"));box.addView(delay)
        box.addView(media);box.addView(label("미디어 재생 지연(초)"));box.addView(play);box.addView(background);box.addView(enabled)
        AlertDialog.Builder(this).setTitle(if(old==null)"앱 실행 추가" else "앱 실행 변경")
            .setView(ScrollView(this).apply{addView(box)}).setNegativeButton("취소",null)
            .setPositiveButton("저장"){_,_->
                val a=apps[chooser.selectedItemPosition].packageName
                val seconds=delay.text.toString().toIntOrNull()?.coerceIn(0,600)?:0
                val playSeconds=play.text.toString().toIntOrNull()?.coerceIn(0,600)?:0
                val step=LaunchStep(old?.id?:java.util.UUID.randomUUID().toString(),a,seconds,media.isChecked,playSeconds,enabled.isChecked,background.isChecked)
                val list=FeatureProfiles.steps(this).toMutableList()
                val idx=list.indexOfFirst{it.id==step.id}
                if(idx>=0)list[idx]=step else list.add(step)
                FeatureProfiles.saveSteps(this,list);redraw()
            }.show()
    }
}
