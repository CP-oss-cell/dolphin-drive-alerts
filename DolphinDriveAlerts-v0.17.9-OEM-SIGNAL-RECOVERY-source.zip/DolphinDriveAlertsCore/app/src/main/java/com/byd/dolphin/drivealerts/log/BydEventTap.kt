package com.byd.dolphin.drivealerts.log

import android.content.Context
import android.hardware.IBYDAutoEvent
import android.hardware.bydauto.BYDAutoEventValue
import android.hardware.bydauto.adas.AbsBYDAutoADASListener
import android.hardware.bydauto.dipilot.AbsBYDAutoDiPilotListener
import android.hardware.bydauto.energy.AbsBYDAutoEnergyListener
import android.hardware.bydauto.gearbox.AbsBYDAutoGearboxListener
import android.hardware.bydauto.instrument.AbsBYDAutoInstrumentListener
import android.hardware.bydauto.radar.AbsBYDAutoRadarListener
import android.hardware.bydauto.setting.AbsBYDAutoSettingListener
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.lang.reflect.Modifier
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Passive BYD listener tap. It only registers listeners and records callbacks; it never invokes
 * a BYD setter/control method. This is especially useful for discovering which event ID changes
 * when the stock "주행 전자음" setting is toggled.
 */
class BydEventTap(
    context: Context,
    private val logger: RawSignalLogger,
    private val featureIds: FeatureIdCatalog
) {
    private val app = context.applicationContext
    private data class Binding(val device: Any, val listener: Any)
    private val bindings = mutableListOf<Binding>()
    private val last = ConcurrentHashMap<String, String>()
    private val domainCounts = ConcurrentHashMap<String, AtomicLong>()
    private val domainLastMs = ConcurrentHashMap<String, Long>()
    private val suppressedCounts = ConcurrentHashMap<String, AtomicLong>()

    /** Actual callback counts, including repeated unchanged states suppressed from raw JSONL. */
    fun healthSnapshot(): String {
        val now = System.currentTimeMillis()
        return domainCounts.keys.sorted().joinToString(";") { domain ->
            val age = (now - (domainLastMs[domain] ?: now)).coerceAtLeast(0)
            "$domain=${domainCounts[domain]?.get() ?: 0},silentMs=$age,repeated=${suppressedCounts[domain]?.get() ?: 0}"
        }.ifBlank { "NO_CALLBACKS_RECEIVED" }
    }

    private fun observed(source: String) {
        domainCounts.getOrPut(source) { AtomicLong() }.incrementAndGet()
        domainLastMs[source] = System.currentTimeMillis()
    }
    private fun suppressed(source: String) {
        suppressedCounts.getOrPut(source) { AtomicLong() }.incrementAndGet()
    }

    fun start() {
        if (bindings.isNotEmpty()) return
        val wrapped = BydPermissionContext.wrap(app)
        safeSetup("setting") { setup("setting", "android.hardware.bydauto.setting.BYDAutoSettingDevice", wrapped,
            object : AbsBYDAutoSettingListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("setting", eventType, eventValue)

                override fun onError(errCode: Int, errMessage: String?) = error("setting", errCode, errMessage)
            }) }
        safeSetup("instrument") { setup("instrument", "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice", wrapped,
            object : AbsBYDAutoInstrumentListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("instrument", eventType, eventValue)

                override fun onError(errCode: Int, errMessage: String?) = error("instrument", errCode, errMessage)
            }) }
        safeSetup("adas") { setup("adas", "android.hardware.bydauto.adas.BYDAutoADASDevice", wrapped,
            object : AbsBYDAutoADASListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("adas", eventType, eventValue)

                override fun onError(errCode: Int, errMessage: String?) = error("adas", errCode, errMessage)
            }) }
        safeSetup("dipilot") { setup("dipilot", "android.hardware.bydauto.dipilot.BYDAutoDipilotDevice", wrapped,
            object : AbsBYDAutoDiPilotListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("dipilot", eventType, eventValue)

                override fun onError(errCode: Int, errMessage: String?) = error("dipilot", errCode, errMessage)

                // These callback signatures are taken from BeetleLauncher 1.713's
                // ProbeDiPilotListener DEX. Log only; never map to speech until a real-car
                // capture proves the value semantics on the Korean Dolphin.
                override fun onAlarmTypeChanged(state: Int) = special("dipilot.alarmType", state)
                override fun onAEBDecActiveChanged(state: Int) = special("dipilot.aebDecActive", state)
                override fun onFrontCarStartStateChange(state: Int) = special("dipilot.frontCarStart", state)
                override fun onDriveDepartureStateChanged(state: Int) = special("dipilot.driveDeparture", state)
                override fun onDrivieDepartureStateChanged(state: Int) = special("dipilot.drivieDeparture", state)
                override fun onOpenDoorAlertStateChanged(state: Int) = special("dipilot.openDoorAlert", state)
                override fun onLeftBehindReminderStateChanged(state: Int) = special("dipilot.leftBehindReminder", state)
                override fun onControlLossWarningStateChanged(state: Int) = special("dipilot.controlLossWarning", state)
                override fun onFrontTrafficCrossAlertStateChanged(state: Int) = special("dipilot.frontTrafficCrossAlert", state)
                override fun onRearTrafficCrossAlertStateChanged(state: Int) = special("dipilot.rearTrafficCrossAlert", state)
                override fun onFrontTrafficBrakeAlertStateChanged(state: Int) = special("dipilot.frontTrafficBrakeAlert", state)
                override fun onRearTrafficBrakeAlertStateChanged(state: Int) = special("dipilot.rearTrafficBrakeAlert", state)
                override fun onRearCrashAlertStateChanged(state: Int) = special("dipilot.rearCrashAlert", state)
                override fun onSideDistanceWarningStateChanged(state: Int) = special("dipilot.sideDistanceWarning", state)
                override fun onCollisionWarningStateChanged(state: Int) = special("dipilot.collisionWarning", state)
                override fun onPredictCrashAlertStateChange(state: Int) = special("dipilot.predictCrashAlert", state)
                override fun onEmergencyBrakeWarningStateChanged(state: Int) = special("dipilot.emergencyBrakeWarning", state)
                override fun onBlindMonitorStateChanged(state: Int) = special("dipilot.blindMonitor", state)
                override fun onBlindMonitorStateChanged1(state: Int) = special("dipilot.blindMonitor1", state)
                override fun onBlindMonitorStateChanged2(state: Int) = special("dipilot.blindMonitor2", state)
            }) }
        safeSetup("energy") { setup("energy", "android.hardware.bydauto.energy.BYDAutoEnergyDevice", wrapped,
            object : AbsBYDAutoEnergyListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("energy", eventType, eventValue)

                override fun onOperationModeChanged(type: Int) = special("energy.operationMode", type)
                override fun onEnergyRecycleChanged(state: Int) = special("energy.recycle", state)
                override fun onError(errCode: Int, errMessage: String?) = error("energy", errCode, errMessage)
            }) }
        safeSetup("radar") { setup("radar", "android.hardware.bydauto.radar.BYDAutoRadarDevice", wrapped,
            object : AbsBYDAutoRadarListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("radar", eventType, eventValue)

                override fun onError(errCode: Int, errMessage: String?) = error("radar", errCode, errMessage)
            }) }
        safeSetup("gearbox") { setup("gearbox", "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice", wrapped,
            object : AbsBYDAutoGearboxListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = event("gearbox", eventType, eventValue)

                override fun onCurrentGearChanged(gear: Int) = special("gearbox.currentGear", gear)
                override fun onError(errCode: Int, errMessage: String?) = error("gearbox", errCode, errMessage)
            }) }
        logger.diagnostic("BYD_EVENT_TAP_STARTED", "bindings=${bindings.size}")
    }

    fun hasActiveBindings(): Boolean = bindings.isNotEmpty()

    fun close() {
        bindings.forEach { b ->
            runCatching {
                val m = b.device.javaClass.methods.firstOrNull { it.name == "unregisterListener" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(b.listener.javaClass) }
                    ?: b.device.javaClass.methods.firstOrNull { it.name == "unregisterListener" && it.parameterTypes.size == 1 }
                m?.invoke(b.device, b.listener)
            }
        }
        bindings.clear()
        last.clear()
        domainCounts.clear()
        domainLastMs.clear()
        suppressedCounts.clear()
    }

    /** Isolate OEM listener implementation/linkage failures to one domain. */
    private fun safeSetup(domain: String, install: () -> Unit) {
        try {
            install()
        } catch (error: Throwable) {
            // Device OEM SDK can mark callbacks final even when compile-time BYD stubs do not.
            logger.diagnostic("BYD_EVENT_LISTENER_CLASS_FAILED", "$domain:${error.javaClass.simpleName}:${error.message}")
            CoreLog.w("BYD_EVENT_TAP", "$domain listener unavailable: ${error.message}")
        }
    }

    private fun setup(source: String, className: String, wrapped: Context, listener: Any) {
        runCatching {
            val c = Class.forName(className)
            val device = c.getMethod("getInstance", Context::class.java).invoke(null, wrapped) ?: error("null device")
            val register = c.methods.firstOrNull { it.name == "registerListener" && it.parameterTypes.size == 1 && it.parameterTypes[0].isAssignableFrom(listener.javaClass) }
                ?: c.methods.firstOrNull { it.name == "registerListener" && it.parameterTypes.size == 1 }
                ?: error("registerListener not found")
            register.invoke(device, listener)
            bindings += Binding(device, listener)
            logger.diagnostic("BYD_EVENT_LISTENER_REGISTERED", source)
        }.onFailure {
            CoreLog.w("BYD_EVENT_TAP", "$source unavailable: ${it.message}")
            logger.diagnostic("BYD_EVENT_LISTENER_UNAVAILABLE", "$source:${it.javaClass.simpleName}:${it.message}")
        }
    }

    private fun event(source: String, eventType: Int, eventValue: BYDAutoEventValue?) {
        observed(source)
        val value = serializeEventValue(eventValue)
        val key = "$source:$eventType"
        if (last.put(key, value) == value) { suppressed(source); return }
        logger.bydEvent(source, eventType, value, featureIds.namesFor(eventType))
    }

    private fun legacy(source: String, e: IBYDAutoEvent?) {
        if (e == null) return
        val type = runCatching { e.eventType }.getOrDefault(Int.MIN_VALUE)
        observed("$source.legacy")
        val value = runCatching { e.value.toString() }.getOrNull()
        val data = runCatching { e.data?.toString() }.getOrNull()
        val key = "$source:legacy:$type"
        val payload = "$value|$data"
        if (last.put(key, payload) == payload) { suppressed("$source.legacy"); return }
        logger.bydEvent("$source.legacy", type, value, featureIds.namesFor(type), data)
    }

    private fun special(source: String, value: Int) {
        observed(source)
        val key = "special:$source"
        val v = value.toString()
        if (last.put(key, v) == v) { suppressed(source); return }
        logger.bydEvent(source, Int.MIN_VALUE, v, detail = "special callback")
    }

    private fun error(source: String, code: Int, msg: String?) {
        logger.diagnostic("BYD_EVENT_ERROR", "$source:$code:${msg ?: ""}")
    }

    private fun serializeEventValue(v: Any?): String {
        if (v == null) return "null"
        val parts = mutableListOf<String>()
        v.javaClass.fields.filter { f -> Modifier.isPublic(f.modifiers) }.sortedBy { it.name }.forEach { f ->
            runCatching {
                val x = f.get(v)
                if (x == null || x is Number || x is Boolean || x is String || x is Char || x.javaClass.isEnum) parts += "${f.name}=$x"
            }
        }
        if (parts.isNotEmpty()) return parts.joinToString(",")
        return v.toString()
    }
}
