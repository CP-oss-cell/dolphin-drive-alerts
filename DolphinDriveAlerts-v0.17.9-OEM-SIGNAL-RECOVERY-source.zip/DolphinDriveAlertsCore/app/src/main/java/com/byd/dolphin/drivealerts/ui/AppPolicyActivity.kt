package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.*
import com.byd.dolphin.drivealerts.util.CoreLog

/** Device-wide display/rotation + fixed five navigation target list. No app picker. */
class AppPolicyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,20,28,28) }
        scroll.addView(box); setContentView(scroll)
        fun label(t: String, size: Float=15f) = TextView(this).apply { text=t; textSize=size; setPadding(0,7,0,9) }
        fun btn(t: String, fn: ()->Unit) = Button(this).apply { text=t; isAllCaps=false; setOnClickListener { fn() } }
        box.addView(label("디스플레이 · 회전 · 내비 운전석 출력",22f))
        box.addView(label("DPI와 회전은 디스플레이 전체에 적용됩니다. 앱 선택은 없습니다. 순정 선택 시 wm density reset으로 시스템의 물리 DPI 설정을 복원합니다. 단, BYD 순정 런처의 독자적 레이아웃까지 앱에서 변경할 수는 없습니다.",13f))
        box.addView(label("전역 DPI: 순정 / 200 / 180 / 160 / 140 / 120(실차 잘림으로 차단) / 수동",18f))
        val modes = listOf("순정", "200", "180", "160", "140", "120", "수동")
        val dpi = Spinner(this).apply { adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,modes) }
        box.addView(dpi)
        val manual = EditText(this).apply { hint="수동 DPI 100~640"; inputType=InputType.TYPE_CLASS_NUMBER }
        box.addView(manual)
        val densityStatus = label("현재 DPI: 조회 전",13f)
        box.addView(densityStatus)
        fun runDpi(change: Boolean) {
            val chosenIndex = dpi.selectedItemPosition
            val chosenManual = manual.text.toString().toIntOrNull()
            Thread {
                val result = if (change) {
                    val target = when (chosenIndex) {
                        0 -> null
                        1 -> 200; 2 -> 180; 3 -> 160; 4 -> 140; 5 -> 120
                        else -> chosenManual
                    }
                    if (chosenIndex == 6 && (target == null || target !in 100..640))
                        DisplaySettingsController.Result(false,"수동 DPI는 100~640 범위여야 합니다")
                    else DisplaySettingsController.applyDensity(applicationContext,target)
                } else {
                    val state=DisplaySettingsController.readDensity(applicationContext)
                    DisplaySettingsController.Result(state != null,"DPI=${state ?: "ADB 조회 실패"}, size=${DisplaySettingsController.readSize(applicationContext)}")
                }
                runOnUiThread { densityStatus.text=result.message
                    if(change) Toast.makeText(this@AppPolicyActivity,if(result.ok) "DPI 적용 및 조회 확인" else "DPI 실패/미확인",Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        box.addView(btn("현재 해상도/DPI 확인") { runDpi(false) })
        box.addView(btn("DPI 변경 적용 · 전체 화면 배율 변경") {
            AlertDialog.Builder(this).setTitle("차량 전체 화면 변경")
                .setMessage("순정 화면·모든 앱의 크기가 변경됩니다. 순정 선택 시 wm density reset으로 전체 override를 제거합니다. 변경 후 화면이 불편할 수 있습니다. 적용하시겠습니까?")
                .setPositiveButton("적용") { _,_ -> runDpi(true) }.setNegativeButton("취소",null).show()
        })
        box.addView(label("디스플레이 프로필/해상도",18f))
        box.addView(label("wm size 1920x1080은 논리적 화면 크기 변경일 뿐 실제 패널 12인치/1920x1080 하드웨어로 속이지 않습니다. BYD 차량 설정의 12인치 프로필과 동일한 효과는 미확인입니다. 안전상 프로필 위장은 자동 실행하지 않습니다.",13f))
        box.addView(btn("패널 / 논리 해상도 정보 조회 (읽기 전용)") {
            Thread {
                val info = DisplaySettingsController.readDisplayHardware(applicationContext)
                runOnUiThread { AlertDialog.Builder(this@AppPolicyActivity)
                    .setTitle("물리 패널 및 논리 해상도")
                    .setMessage(info).setPositiveButton("닫기",null).show() }
            }.start()
        })
        box.addView(label("화면 회전 · Orientation Control 방식 (앱 선택 없음)",18f))
        val toggle = CheckBox(this).apply { text="전역 회전 사용"; isChecked=RotationPolicy.enabled(this@AppPolicyActivity) }
        box.addView(toggle)
        val all = listOf(OrientationMode.STOCK,OrientationMode.LANDSCAPE,OrientationMode.REVERSE_LANDSCAPE,OrientationMode.PORTRAIT,OrientationMode.REVERSE_PORTRAIT,OrientationMode.SENSOR_LANDSCAPE,OrientationMode.SENSOR_PORTRAIT,OrientationMode.USER_LANDSCAPE,OrientationMode.USER_PORTRAIT,OrientationMode.FULL_USER,OrientationMode.LOCKED,OrientationMode.FULL_SENSOR)
        val rotation = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,listOf("순정","가로 고정","가로 반전","세로 고정","세로 반전","센서 가로","센서 세로","사용자 가로","사용자 세로","전체 사용자 회전","현재 방향 잠금","센서 전체"))
            setSelection(all.indexOf(RotationPolicy.selected(this@AppPolicyActivity)).coerceAtLeast(0))
        }
        box.addView(rotation)
        val rotStatus=label("0×0 오버레이 이용. 차량의 오버레이 권한 필요. 시스템/앱별 패키지 권한 불필요.",13f)
        box.addView(rotStatus)
        box.addView(btn("회전 적용") {
            RotationPolicy.setSelected(this, all[rotation.selectedItemPosition]); RotationPolicy.setEnabled(this,toggle.isChecked)
            val ok=RotationPolicy.applyCurrent(this)
            rotStatus.text=if(ok) "회전 요청 적용: ${RotationPolicy.selected(this)} (실제 차량 화면 확인 필요)" else "회전 요청 실패: 화면 위 표시 권한 및 순정 화면 정책 확인"
        })
        box.addView(btn("화면 위 표시 권한 열기") { SafeSettingsLauncher.open(this,Settings.ACTION_MANAGE_OVERLAY_PERMISSION,true) })
        box.addView(label("내비게이션 운전석 스피커 · 대상 5종 고정",18f))
        box.addView(label("현재 BYD 타 앱 UID→운전석 물리 라우팅은 아직 미구현입니다. 아래 선택은 향후 전용 라우팅 대상 저장용이며, 선택만으로 운전석에서 출력되지 않습니다.",13f))
        for (entry in ExternalAppAudioRouter.NAVIGATION_APPS) {
            val current=ExternalAppAudioRouter.enabled(this,entry.pkg)
            val cb=CheckBox(this).apply { text="${entry.title} (${entry.pkg})"; isChecked=current
                setOnCheckedChangeListener { _,checked -> ExternalAppAudioRouter.setEnabled(this@AppPolicyActivity,entry.pkg,checked)
                    ExternalAppAudioRouter.diagnose(this@AppPolicyActivity,entry.pkg) }
            }
            box.addView(cb)
        }
    }
}
