package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.audio.GlobalEqualizerEngine
import com.byd.dolphin.drivealerts.audio.EqPreferences
import com.byd.dolphin.drivealerts.audio.SoundFocusMode
import com.byd.dolphin.drivealerts.service.DrivingAlertService

/** Simple car-style sound tuning surface backed by Android AudioEffect. */
class AudioTuningActivity : Activity() {
    private lateinit var bassValue: TextView
    private lateinit var midValue: TextView
    private lateinit var trebleValue: TextView
    private lateinit var runtimeState: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val current = EqPreferences.read(this)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 30)
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "이퀄라이저 · 음향 효과"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "차량형 간편 저음·중음·고음과 음장 모드를 조절하세요. 실제 적용은 차량 오디오 세션과 지원 상태에 따라 달라집니다."
            textSize = 13f
            setPadding(0, 8, 0, 18)
        })

        runtimeState = TextView(this).apply {
            text = GlobalEqualizerEngine.readStatus(this@AudioTuningActivity)
            textSize = 13f
            setPadding(0, 4, 0, 12)
        }
        root.addView(runtimeState)

        root.addView(CheckBox(this).apply {
            text = "이퀄라이저 사용"
            isChecked = current.enabled
            setOnCheckedChangeListener { _, checked ->
                EqPreferences.setEnabled(this@AudioTuningActivity, checked)
                refreshEngine()
            }
        })


        fun addBand(title: String, initial: Int, setter: (Int) -> Unit, valueHolder: (TextView) -> Unit) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(TextView(this).apply {
                text = title
                textSize = 17f
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val value = TextView(this).apply {
                text = formatGain(initial)
                textSize = 15f
            }
            valueHolder(value)
            line.addView(value)
            root.addView(line)
            root.addView(SeekBar(this).apply {
                max = 20
                progress = initial + 10
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val v = progress - 10
                        value.text = formatGain(v)
                        if (fromUser) setter(v)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { refreshEngine() }
                })
            })
        }

        addBand("저음 (Bass)", current.bass, { EqPreferences.setBass(this, it) }) { bassValue = it }
        addBand("중음 (Mid)", current.mid, { EqPreferences.setMid(this, it) }) { midValue = it }
        addBand("고음 (Treble)", current.treble, { EqPreferences.setTreble(this, it) }) { trebleValue = it }

        root.addView(TextView(this).apply {
            text = "음색 변화 강도 · 기본/선명/강력"
            textSize = 18f
            setPadding(0, 18, 0, 0)
        })
        val impactLabel = TextView(this).apply { text = "강도: ${listOf("기본 (기존)", "선명", "강력")[current.impactLevel]}" }
        root.addView(impactLabel)
        root.addView(SeekBar(this).apply {
            max = 2
            progress = current.impactLevel
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    impactLabel.text = "강도: ${listOf("기본 (기존)", "선명", "강력")[progress]}"
                    if (fromUser) EqPreferences.setImpactLevel(this@AudioTuningActivity, progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) { refreshEngine() }
            })
        })
        root.addView(TextView(this).apply {
            text = "강력 모드는 오디오 장치가 허용하는 범위에서만 적용되며 피크 헤드룸을 낮춰 과입력을 억제합니다. 사용 중 잡음·왜곡이 생기면 기본으로 복귀하세요."
            textSize = 13f
        })

        root.addView(TextView(this).apply {
            text = "공간 확장 · 음장 효과"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 4)
        })
        root.addView(CheckBox(this).apply {
            text = "공간 확장 사용 (Centerpoint 유사 모드)"
            isChecked = current.centerpoint360
            setOnCheckedChangeListener { _, checked ->
                EqPreferences.setCenterpoint360(this@AudioTuningActivity, checked)
                refreshEngine()
            }
        })
        root.addView(TextView(this).apply {
            text = "기본 Android Virtualizer의 지원 경로에서만 적용됩니다. 미지원 상태는 위에 표시됩니다. 실제 Bose Centerpoint 360 멀티채널 효과는 아닙니다."
            textSize = 13f
        })

        root.addView(TextView(this).apply {
            text = "Sound Focus"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 4)
        })
        val focusGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val reference = RadioButton(this).apply { text = "Reference · 기존 3밴드 그대로"; id = View.generateViewId() }
        val surround = RadioButton(this).apply { text = "Surround · EQ 프리셋 + Virtualizer"; id = View.generateViewId() }
        val cinema = RadioButton(this).apply { text = "Cinema · 저음 프리셋 + Virtualizer"; id = View.generateViewId() }
        focusGroup.addView(reference)
        focusGroup.addView(surround)
        focusGroup.addView(cinema)
        when (current.soundFocus) {
            SoundFocusMode.REFERENCE -> reference.isChecked = true
            SoundFocusMode.SURROUND -> surround.isChecked = true
            SoundFocusMode.CINEMA -> cinema.isChecked = true
        }
        focusGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                surround.id -> SoundFocusMode.SURROUND
                cinema.id -> SoundFocusMode.CINEMA
                else -> SoundFocusMode.REFERENCE
            }
            EqPreferences.setSoundFocus(this, mode)
            refreshEngine()
        }
        root.addView(focusGroup)

        val spatialValue = TextView(this).apply {
            text = "공간감 강도 · ${current.spatialStrength}%"
            textSize = 16f
            setPadding(0, 12, 0, 0)
        }
        root.addView(spatialValue)
        root.addView(SeekBar(this).apply {
            max = 100
            progress = current.spatialStrength
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    spatialValue.text = "공간감 강도 · $progress%"
                    if (fromUser) EqPreferences.setSpatialStrength(this@AudioTuningActivity, progress)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) { refreshEngine() }
            })
        })

        root.addView(TextView(this).apply {
            text = "호환 설정"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 4)
        })
        root.addView(CheckBox(this).apply {
            text = "다른 앱 음악에도 적용 · Global Mix 호환모드"
            isChecked = current.globalMix
            setOnCheckedChangeListener { _, checked ->
                EqPreferences.setGlobalMix(this@AudioTuningActivity, checked)
                refreshEngine()
            }
        })
        root.addView(TextView(this).apply {
            text = "차량 펌웨어가 Global Mix를 지원하지 않으면 실제 오디오가 바뀌지 않을 수 있습니다. 원래 음색으로 되돌리려면 EQ를 끄세요."
            textSize = 13f
        })

        root.addView(Button(this).apply {
            text = "실제 EQ 적용 상태 다시 확인"
            setOnClickListener { refreshEngine() }
        })

        root.addView(Button(this).apply {
            text = "모두 기본값으로 복원"
            setOnClickListener {
                EqPreferences.setBass(this@AudioTuningActivity, 0)
                EqPreferences.setMid(this@AudioTuningActivity, 0)
                EqPreferences.setTreble(this@AudioTuningActivity, 0)
                EqPreferences.setCenterpoint360(this@AudioTuningActivity, false)
                EqPreferences.setSpatialStrength(this@AudioTuningActivity, 50)
                EqPreferences.setSoundFocus(this@AudioTuningActivity, SoundFocusMode.REFERENCE)
                EqPreferences.setImpactLevel(this@AudioTuningActivity, 0)
                refreshEngine()
                recreate()
            }
        })

        return scroll
    }

    private fun refreshEngine() {
        DrivingAlertService.refreshEqualizer(this)
        runtimeState.postDelayed({
            if (!isFinishing) runtimeState.text = GlobalEqualizerEngine.readStatus(this)
        }, 300)
    }

    override fun onResume() {
        super.onResume()
        if (::runtimeState.isInitialized) runtimeState.text = GlobalEqualizerEngine.readStatus(this)
    }

    private fun formatGain(value: Int): String = "${if (value > 0) "+" else ""}${"%.1f".format(value * 0.6f)} dB"
}
