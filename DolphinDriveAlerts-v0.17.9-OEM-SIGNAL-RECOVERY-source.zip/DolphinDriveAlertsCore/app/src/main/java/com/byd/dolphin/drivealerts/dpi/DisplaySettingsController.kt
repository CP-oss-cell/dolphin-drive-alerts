package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** Explicit device-wide density change, never tied to an app lifecycle. */
object DisplaySettingsController {
    private const val PREF = "display_global_v0169"
    data class DensitySnapshot(val physical: Int?, val override: Int?)
    data class Result(val ok: Boolean, val message: String)
    private val physicalRegex = Regex("""(?i)physical density:\s*(\d+)""")
    private val overrideRegex = Regex("""(?i)override density:\s*(\d+)""")
    fun parseDensity(raw: String): DensitySnapshot = DensitySnapshot(
        physicalRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull(),
        overrideRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull()
    )
    fun readDensity(context: Context): DensitySnapshot? {
        val res = AuthorizedAdbRuntime.read(context, "wm density").result
        if (!res.success) return null
        return parseDensity(res.output).takeIf { it.physical != null }
    }
    fun readSize(context: Context): String {
        val res = AuthorizedAdbRuntime.read(context, "wm size").result
        return if (res.success) res.output.trim().take(240) else "해상도 조회 실패: ${res.message}"
    }
    fun readDisplayHardware(context: Context): String {
        // ADB read only: physical panel / logical mode / OEM profile must not be guessed.
        val res = AuthorizedAdbRuntime.read(context, "dumpsys display", timeoutMs = 6_000L).result
        if (!res.success) return "BYD 디스플레이 정보 읽기 실패: ${res.message}"
        val lines = res.output.lineSequence().filter { line ->
            listOf("DisplayDeviceInfo", "mBaseDisplayInfo", "DisplayInfo{", "supportedModes", "physicalWidth", "logicalWidth", "logicalHeight")
                .any { line.contains(it, ignoreCase = true) }
        }.take(18).joinToString("\n")
        return lines.ifBlank { "디스플레이 모드 정보가 dumpsys에서 노출되지 않음" }.take(2400)
    }
    fun applyDensity(context: Context, requested: Int?): Result {
        if (requested != null && (requested !in listOf(200,180,160,140,120) && requested !in 100..640)) {
            return Result(false, "허용되지 않는 DPI")
        }
        val app = context.applicationContext
        // wm density is display-wide; it cannot independently scale proprietary OEM layouts.
        // Do not silently repeat the known 120dpi clipping regression.
        if (requested != null && requested <= 120) {
            CoreLog.w("DPI", "OEM_UI_CLIPPING_RISK requested=$requested; global density cannot spoof OEM layout metrics")
            return Result(false, "DPI $requested 변경 차단: 순정 런처/카메라/공조 UI 잘림 위험이 실차에서 확인됐습니다. 순정 DPI 복원을 사용하세요. 앱별 DPI나 가짜 해상도는 현재 미구현입니다")
        }
        val before = readDensity(app) ?: return Result(false, "ADB로 현재 DPI 확인 불가: 변경하지 않았습니다")
        val prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        // Capture original override exactly once; do not overwrite on every subsequent change.
        if (!prefs.contains("baseline_captured")) {
            prefs.edit().putBoolean("baseline_captured", true)
                .putInt("baseline_physical", before.physical ?: -1)
                .putInt("baseline_override", before.override ?: -1).apply()
        }
        // Explicit OEM recovery always clears global override, even when old baseline captured a bad override.
        val target = requested
        val command = if (target == null) "wm density reset" else "wm density $target"
        val ready = AuthorizedAdbRuntime.health(app)
        if (ready.state != AuthorizedAdbRuntime.State.READY) return Result(false, "ADB 연결 상태: ${ready.state}")
        val changed = AuthorizedAdbRuntime.writeOnce(app, command).result
        if (!changed.success) return Result(false, "명령 거부: ${changed.message}")
        val after = readDensity(app)
        val expected = if (target == null) after?.physical else target
        val actual = after?.override ?: after?.physical
        val verified = actual != null && actual == expected && (target != null || after?.override == null)
        CoreLog.i("DPI", "before=$before cmd=$command after=$after verified=$verified")
        if (!verified) {
            val restore = if (before.override == null) "wm density reset" else "wm density ${before.override}"
            AuthorizedAdbRuntime.writeOnce(app, restore)
            return Result(false, "DPI 적용값 검증 실패. 직전 설정으로 복구를 시도했습니다. 실제=${after ?: "조회 실패"}")
        }
        return Result(true, "현재 DPI ${actual}, 변경 전=${before.override ?: before.physical}, 순정 기준=${prefs.getInt("baseline_override",-1).takeIf { it>0 } ?: prefs.getInt("baseline_physical",-1)}")
    }
}
