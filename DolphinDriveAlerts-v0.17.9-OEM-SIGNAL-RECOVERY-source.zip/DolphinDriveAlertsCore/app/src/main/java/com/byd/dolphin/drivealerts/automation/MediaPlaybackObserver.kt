package com.byd.dolphin.drivealerts.automation

import android.service.notification.NotificationListenerService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.browse.MediaBrowser
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.util.Log
import com.byd.dolphin.drivealerts.util.CoreLog

/** Media play is targeted to a matching active session; no blind global keyevent. */
class MediaPlaybackObserver : NotificationListenerService() {
    companion object {
        /** First try already-active session without launching the media app UI. */
        fun playExisting(c: Context, pkg: String): Boolean = requestPlay(c, pkg, waitForSession = false)

        /**
         * Optional background-only cold start for media apps exposing Android MediaBrowserService.
         * Does not launch a visible Activity; fails safely when the app lacks an exported browser.
         */
        fun playWithoutUi(c: Context, pkg: String): Boolean {
            if (playExisting(c, pkg)) return true
            val candidates = runCatching {
                c.packageManager.queryIntentServices(Intent("android.media.browse.MediaBrowserService").setPackage(pkg), 0)
                    .mapNotNull { it.serviceInfo }
                    .filter { it.exported && it.packageName == pkg }
            }.getOrDefault(emptyList())
            if (candidates.isEmpty()) {
                CoreLog.w("MEDIA_START", "MEDIA_BROWSER_UNAVAILABLE pkg=$pkg (no exported MediaBrowserService)")
                return false
            }
            for (service in candidates.take(4)) {
                val finished = CountDownLatch(1)
                val outcome = AtomicReference("BROWSER_NOT_CONNECTED")
                val browser = AtomicReference<MediaBrowser?>(null)
                val handler = Handler(Looper.getMainLooper())
                handler.post {
                    try {
                        val callback = object : MediaBrowser.ConnectionCallback() {
                            override fun onConnected() {
                                try {
                                    val client = browser.get() ?: return
                                    val controller = MediaController(c.applicationContext, client.sessionToken)
                                    controller.transportControls.play()
                                    outcome.set("BROWSER_PLAY_SENT")
                                } catch (t: Throwable) { outcome.set("BROWSER_PLAY_FAILED:${t.javaClass.simpleName}") }
                                finally { finished.countDown() }
                            }
                            override fun onConnectionFailed() { outcome.set("BROWSER_CONNECTION_FAILED"); finished.countDown() }
                            override fun onConnectionSuspended() { outcome.set("BROWSER_SUSPENDED"); finished.countDown() }
                        }
                        val b = MediaBrowser(c.applicationContext,
                            ComponentName(service.packageName, service.name), callback, null)
                        browser.set(b)
                        b.connect()
                    } catch (t: Throwable) {
                        outcome.set("BROWSER_EXCEPTION:${t.javaClass.simpleName}")
                        finished.countDown()
                    }
                }
                val done = finished.await(5, TimeUnit.SECONDS)
                handler.post { runCatching { browser.get()?.disconnect() } }
                val accepted = done && outcome.get() == "BROWSER_PLAY_SENT"
                CoreLog.i("MEDIA_START", "MEDIA_BROWSER pkg=$pkg service=${service.name} result=${outcome.get()} accepted=$accepted")
                if (accepted) {
                    // Transport command sent; verify actual media state asynchronously using
                    // the existing session API rather than treating a successful Binder call as sound.
                    Thread.sleep(450L)
                    if (isPlaybackActive(c, pkg)) return true
                    CoreLog.w("MEDIA_START", "MEDIA_BROWSER_SENT_NO_PLAYBACK_READBACK pkg=$pkg")
                }
            }
            return false
        }

        private fun isPlaybackActive(c: Context, pkg: String): Boolean = runCatching {
            val component = ComponentName(c, MediaPlaybackObserver::class.java)
            c.getSystemService(MediaSessionManager::class.java).getActiveSessions(component).any {
                it.packageName == pkg && (it.playbackState?.state == PlaybackState.STATE_PLAYING ||
                    it.playbackState?.state == PlaybackState.STATE_BUFFERING)
            }
        }.getOrDefault(false)

        /** Normal cold app launch fallback waits for the newly created media session. */
        fun play(c: Context, pkg: String): Boolean = requestPlay(c, pkg, waitForSession = true)

        private fun requestPlay(c: Context, pkg: String, waitForSession: Boolean): Boolean {
            return try {
                val manager = c.getSystemService(MediaSessionManager::class.java)
                val component = ComponentName(c, MediaPlaybackObserver::class.java)
                var controller = manager.getActiveSessions(component).firstOrNull { it.packageName == pkg }
                var retries = 0
                while (controller == null && waitForSession && retries++ < 8) {
                    Thread.sleep(500L)
                    controller = manager.getActiveSessions(component).firstOrNull { it.packageName == pkg }
                }
                if (controller == null) {
                    CoreLog.w("MEDIA_START", "no_active_session pkg=$pkg coldFallback=$waitForSession")
                    false
                } else {
                    val active = controller
                    active.transportControls.play()
                    var status: Int? = null
                    // Playback can transition STARTING -> BUFFERING -> PLAYING asynchronously.
                    repeat(10) {
                        if (status != PlaybackState.STATE_PLAYING && status != PlaybackState.STATE_BUFFERING) {
                            Thread.sleep(300L)
                            status = active.playbackState?.state
                        }
                    }
                    val accepted = status == PlaybackState.STATE_PLAYING || status == PlaybackState.STATE_BUFFERING
                    CoreLog.i("MEDIA_START", "pkg=$pkg reused=${!waitForSession} state=$status accepted=$accepted")
                    accepted
                }
            } catch (t: Throwable) {
                CoreLog.w("MEDIA_START", "play failure for $pkg: ${t.message}")
                false
            }
        }
    }
}
