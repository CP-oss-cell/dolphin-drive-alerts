# Dolphin Drive Alerts v0.17.8 — 전체 미해결 기능 개선 / 실차 검증 경계

- 기준: v0.17.7 최종 소스 / 2026-10-09 17:17 실차 로그(56,751건) / Master Issues v43 / 2026-10-10 순정 NAV·AVAS 연구.
- APK: `applicationId=com.byd.dolphin.drivealerts`, versionCode 34, versionName `0.17.8-diagnostics-background-media`.
- 표시는 `CODE_CANDIDATE`/`LOCAL_PASS`이며 실제 글로벌 2602 차량 검증 또는 GitHub CI 전체 APK 생성 성공을 뜻하지 않음.

## 이번 소스 수정 완료

1. **미디어 백그라운드 전용**: `미디어 앱+백그라운드` 설정일 때 화면을 아예 실행하지 않음. 기존 MediaSession 활용, 없으면 exported MediaBrowserService에 연결 후 `MediaController.play`, 활성 세션 재생 상태를 읽어서 성공 판정. 불가능한 앱은 `MEDIA_BROWSER_UNAVAILABLE`/`MEDIA_BROWSER_SENT_NO_PLAYBACK_READBACK` 로그를 남김. 일반 앱 자동시작과 기존 시퀀스는 유지. 배터리·Android 정책이 차단하면 실패(모든 앱 지원 아님).
2. **시동 지연 최적화**: 전체 시퀀스 시작 시 30초 ADB 대기를 하지 않고, 실제 shell/분할/Activity 실행 단계에서만 ADB 대기. OEM ReferenceVehicleEventBridge 초기화를 foreground 서비스의 `startForeground` 이후 별도 worker로 이동. `BOOT_RX_TIME`, `SERVICE_INIT_DURATION`, `REFERENCE_LISTENER_ASYNC_READY`, `MEDIA_BACKGROUND_ONLY`로 구간별 지연 측정. 초기 기동 후 OEM listener 준비는 시간차가 있을 수 있음.
3. **BSD 좌우**: `BSD_GATE_SUPPRESSED`(왜 알림이 막혔는지 원시값), `BSD_GATE_ACCEPTED` 진단 추가. 실차 raw 2/5가 LEFT/RIGHT라는 증거는 없으므로 기존 readback=1/0 가설을 임의 변경하거나 오경고를 발생시키지 않음.
4. **노멀·전방·차선·DOW**: `REFERENCE_OPERATION_MODE`에 NORMAL raw0 미검증, 다른 모드로부터 추정 발화 없음 명기. `DIPILOT_HAZARD_CALLBACK_CANDIDATE`는 콜백 변화 기록 강화. 일반/ICC 주행에서 인식된 상태가 실제 경고인지 명확하지 않으므로 미검증 ADAS 경고 자동 발화는 도입하지 않음. 순정 ADAS 경고를 대체하지 않음.
5. **이퀄라이저**: 기본 설정은 이전 0.6dB/step 그대로. 추가로 `기본(0.6) / 선명(0.8) / 강력(1.0) dB/step` 선택·영구 저장·복원. 기존 10-band DP/5-band fallback, 최대 +10dB와 peak 자동 헤드룸 보정. Android AudioEffect readback과 실제 청감은 별도 확인. 상용 Bose/현대기아 DSP 구현이 아님.
6. **DPI 순정 안전**: 120 이하 전역 DPI 재적용 방지(이전 차량 UI 잘림 보고), `순정` 클릭은 과거 잘못 저장됐을 수 있는 override를 복구하는 대신 `wm density reset`로 초기화. 물리 패널 해상도·OEM 런처 고정 레이아웃 속이기 기능 구현/실증 없음. 가상 디스플레이/앱별 크기 정책은 별도 연구.
7. **분할·멀티태스킹**: 기존 2분할 실행, ADB/양쪽 앱 readback, bounds 실패 시 미완료 표시 유지. `분할/멀티팝업 지원 상태 진단 (읽기 전용)` 추가. 3분할·4분할·멀티팝업은 OEM capability 미확인 상태이므로 실행 기능 추가하지 않음. `am stack` 일부 펌웨어에서 폐기됐을 수 있으며 실제 2분할 정상 작동은 미검증.

## 연구/이슈 중복 대조 — 상태

| 요구사항 | 기존 이슈 | v0.17.8 단계 | 실차 재검증/남은 차단 요인 |
|---|---|---|---|
| NORMAL 음성 누락 | DA-003, DA-005 | LOG_DIAGNOSTIC_ADDED | ECO→NORMAL→SPORT 실제 콜백 raw/getter 비교 후 매핑 확정 |
| BSD 좌/우 | DA-007 | GATE_REASON_DIAGNOSTIC | 방향지시등 SDK raw 별 LEFT/RIGHT/점멸 OFF/비상등 수집 |
| 정차 후 DOW 도어 위험 | DA-007/008 | CALLBACK_CANDIDATE_ONLY | 경고 이벤트 vs 기능 활성화 구분, 기어 P/속도0 연계 |
| 일반/ICC 차선이탈 좌/우 | DA-008 | CALLBACK_CANDIDATE_ONLY | 순정 차선 경고 실제 이벤트 캡처, 좌우 확인 |
| 일반/ICC 정차 앞차 출발 | DA-008 | CALLBACK_CANDIDATE_ONLY | OEM DiPilot 호환 클래스/실제 active 값 별도 검증 |
| 시동 서비스 지연 | DA-016 | SOURCE_OPTIMIZATION | 콜드부팅/퀵부팅 시간·listener 준비 시간 측정 |
| 미디어 무화면 재생 | DA-016 | IMPLEMENTED_WHEN_COMPATIBLE | 5종 미디어 앱 각각 Session/Browser 지원 여부 |
| 2분할 | DA-027 | CAPABILITY_DIAG_ADDED | ADB 쓰기 승인/DiLink split API, 실제 bounds 확인 |
| 3/4분할·멀티팝업 | DA-027 | RESEARCH_ONLY | OEM ActivityTaskManager 지원 증거 필요 |
| DPI 순정 화면 잘림 | DA-010 | GUARD_AND_STOCK_RESET | 120 가상 크기 불일치 방지, OEM per-app density 연구 |
| 3밴드 EQ 체감 강화 | DA-015 | USER_SELECTABLE_GAIN | session control/readback + 청감 왜곡·헤드룸 테스트 |
| 내비 5종 운전석 | DA-009/010 | NO_VENDOR_ROUTE | 순정 내비의 UID/AudioPolicy/device 비교; OEM 권한 필요 |
| 외부 AVAS | DA-012 | NO_OEM_WRITE | 외부기기 오인 정정 유지, 안전한 readback에서만 진행 |
| 로그 재시동 복구 | DA-029(번호충돌 주의) | PRESERVED | 재시동 후 상세 이벤트 등록 성공과 콜백 활성 별도 검증 |

## 구현 금지/미검증 기준
- 2602에서 확인되지 않은 ADAS 신호 raw를 좌/우 또는 위험 트리거로 확정하지 않음.
- 순정 주행 안전 ADAS / VESS/AVAS 출력 기능을 변경·비활성화하는 write 호출 추가 없음.
- 5개 내비의 타 UID를 권한 없이 운전석 스피커로 강제 라우팅하거나 설정저장을 성공으로 표시하지 않음.
- 3/4분할, 가짜 디스플레이 크기/해상도, OEM 360 DSP 기능 구현이라고 표시하지 않음.
- APK 전체 Android Gradle 빌드와 실차 확인 전 VERIFIED 금지.

## 기존 정상 기능 보존
- ECO/SPORT/회생제동/오토홀드/기어/EPB/ICC 상태 음성, Steering MENU 3연타, 화면 회전, 앱별 권한, 통합 로그 시작·끝·연속성, 시스템 순정 설정, 설정 저장과 실패 readback 등 기존 소스 유지.

## 테스트·빌드
- `python tools/verify_v0178_integration.py` 핵심 소스 구조/안전 회귀 검사.
- `python tools/verify_v0178_media_kotlin_compile.py` 수정한 MediaSession/MediaBrowser 소스 typed stub Kotlin compile.
- `python tools/verify_v0177_eq_kotlin_compile.py` 수정 EQ 실제 Kotlin 파일 typed strict API stub compile.
- GitHub Actions `:app:compileDebugKotlin`, `:app:assembleDebug`가 전체 Android SDK 최종 게이트. Artifact 포장 전 필요 파일 체크 필수.
