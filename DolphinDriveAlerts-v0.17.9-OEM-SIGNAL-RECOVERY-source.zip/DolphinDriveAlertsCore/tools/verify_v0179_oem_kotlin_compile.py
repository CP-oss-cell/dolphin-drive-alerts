#!/usr/bin/env python3
"""Compile REAL v0.17.9 OEM read-only probe source; exercise transient 2602 service recovery.
Not a full Android SDK build, nor confirmation of real-car safety warning semantics.
"""
from pathlib import Path
import tempfile, subprocess, shutil
root = Path(__file__).resolve().parents[1]
base = root/'app/src/main/java/com/byd/dolphin/drivealerts'
sources = [base/x for x in ('log/ReadOnlySignalProbe.kt','log/TargetedSignalProbe.kt','vehicle/BydVehicleReader.kt')]
assert all(f.is_file() for f in sources)
assert shutil.which('kotlinc') and shutil.which('kotlin'), 'Kotlin compiler/runtime missing'
stubs = {
'Context.kt': '''package android.content
open class Context {
    val applicationContext: Context get() = this
    fun getSystemService(name: String): Any? = null
}
''',
'Clock.kt': '''package android.os
object SystemClock { @JvmStatic var current: Long = 100000L
  @JvmStatic fun elapsedRealtime(): Long = current }
open class RemoteException: Exception()
''',
'Helpers.kt': '''package com.byd.dolphin.drivealerts.vehicle
import android.content.Context
object BydPermissionContext { fun wrap(context: Context): Context = context }
''',
'Log.kt': '''package com.byd.dolphin.drivealerts.util
object CoreLog { @JvmStatic fun w(tag: String, message: String) {} }
''',
'Frame.kt': '''package com.byd.dolphin.drivealerts.model
data class RawVehicleFrame(
 val speedKmH: Float? = null, val gearRaw: Int? = null, val epbRaw: Int? = null,
 val brakePedalRaw: Int? = null, val avhRaw: Int? = null, val bsdRaw: Int? = null,
 val laneOffsetRaw: Int? = null, val tjaRaw: Int? = null, val driveInterfaceRaw: Int? = null,
 val energyFeedbackRaw: Int? = null, val driveConfigRaw: Int? = null,
 val deviationRaw: Int? = null, val pcwAlarmRaw: Int? = null,
 val laneLineStateRaw: Int? = null, val radarDistances: IntArray? = null)
''',
'Energy.kt': '''package android.hardware.bydauto.energy
import android.content.Context
class BYDAutoEnergyDevice {
 companion object { @JvmStatic var available = false
   @JvmStatic fun getInstance(ctx: Context): BYDAutoEnergyDevice {
     if(!available) throw IllegalStateException("IGNITION_NOT_READY")
     return BYDAutoEnergyDevice()
   }
 }
 fun getOperationMode(): Int = 2
 fun getOperationModeState(): Int = 2
}
''',
'Runner.kt': '''package com.byd.dolphin.drivealerts.log
import android.content.Context
import android.os.SystemClock
import android.hardware.bydauto.energy.BYDAutoEnergyDevice
import com.byd.dolphin.drivealerts.vehicle.BydVehicleReader
fun main() {
 val c = Context()
 val fast = ReadOnlySignalProbe(c)
 val targeted = TargetedSignalProbe(c)
 val reader = BydVehicleReader(c)
 check("BYDAutoEnergyDevice.getOperationMode" !in fast.snapshot())
 check("target.energy.operationMode" !in targeted.snapshot())
 check(reader.readReferenceEnergySignals().isEmpty())
 BYDAutoEnergyDevice.available = true
 SystemClock.current += 500L
 check("BYDAutoEnergyDevice.getOperationMode" !in fast.snapshot())
 check("target.energy.operationMode" !in targeted.snapshot())
 SystemClock.current += 15_001L
 check(fast.snapshot()["BYDAutoEnergyDevice.getOperationMode"] == "2")
 check(targeted.snapshot()["target.energy.operationMode"] == "2")
 check(reader.readReferenceEnergySignals()["energy.operationMode"] == 2)
 targeted.close()
 println("PASS OEM_GETTER_RECOVERS_AFTER_IGNITION")
}
'''
}
with tempfile.TemporaryDirectory(prefix='v0179_oem_kotlin_') as td:
 tmp=Path(td);paths=[]
 for filename,content in stubs.items():
  f=tmp/filename;f.write_text(content);paths.append(str(f))
 jar=str(tmp/'test.jar')
 build=subprocess.run(['kotlinc',*map(str,sources),*paths,'-include-runtime','-d',jar],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=100)
 print(build.stdout[-4500:]);assert build.returncode==0,'OEM actual Kotlin source compilation FAILED'
 run=subprocess.run(['java','-jar',jar],capture_output=True,text=True,timeout=15)
 print(run.stdout);print(run.stderr[-1000:]);assert run.returncode==0,'Transient binder recovery test FAILED'
 print('PASS 3_REAL_OEM_SOURCE_KOTLIN_COMPILE')
