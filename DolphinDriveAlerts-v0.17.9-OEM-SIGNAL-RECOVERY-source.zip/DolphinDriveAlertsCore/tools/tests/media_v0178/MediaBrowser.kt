package android.media.browse
class MediaBrowser(context: android.content.Context, component: android.content.ComponentName,
    callback: ConnectionCallback, options: android.os.Bundle?) {
    open class ConnectionCallback { open fun onConnected() {} ; open fun onConnectionFailed() {} ; open fun onConnectionSuspended() {} }
    val sessionToken: android.media.session.MediaSession.Token = android.media.session.MediaSession.Token()
    fun connect() {} ; fun disconnect() {}
}
