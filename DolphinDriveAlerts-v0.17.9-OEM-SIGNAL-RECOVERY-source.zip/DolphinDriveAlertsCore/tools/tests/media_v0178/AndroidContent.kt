package android.content
open class Context {
    val packageManager: android.content.pm.PackageManager = android.content.pm.PackageManager()
    val applicationContext: Context get() = this
    fun <T: Any> getSystemService(clazz: Class<T>): T = throw UnsupportedOperationException()
}
class ComponentName {
    constructor(c: Context, type: Class<*>)
    constructor(pkg: String, klass: String)
}
class Intent(val action: String) {
    fun setPackage(value: String): Intent = this
}
