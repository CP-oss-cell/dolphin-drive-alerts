package android.media.session
class MediaSession { class Token }
class PlaybackState(val state: Int) { companion object { const val STATE_PLAYING=3; const val STATE_BUFFERING=6 } }
class MediaController(context: android.content.Context, token: MediaSession.Token) {
    val packageName: String=""; val playbackState: PlaybackState?=null
    val transportControls = TransportControls()
    class TransportControls { fun play() {} }
}
class MediaSessionManager {
    fun getActiveSessions(component: android.content.ComponentName): List<MediaController> = emptyList()
}
