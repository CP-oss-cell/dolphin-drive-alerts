package android.os
class Looper { companion object { @JvmStatic fun getMainLooper(): Looper = Looper() } }
class Handler(looper: Looper) { fun post(runnable: Runnable): Boolean { runnable.run(); return true } }
