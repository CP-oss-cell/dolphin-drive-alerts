package com.byd.dolphin.drivealerts.util
object CoreLog {
    fun i(tag: String,msg: String) {}
    fun w(tag: String,msg: String) {}
}
