package android.content.pm
class ServiceInfo { var exported: Boolean=true; var packageName: String=""; var name: String="" }
class ResolveInfo { var serviceInfo: ServiceInfo?=null }
class PackageManager { fun queryIntentServices(intent: android.content.Intent, flags: Int): List<ResolveInfo> = emptyList() }
