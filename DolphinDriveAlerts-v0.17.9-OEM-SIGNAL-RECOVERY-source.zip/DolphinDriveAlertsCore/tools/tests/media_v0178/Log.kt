package android.util
object Log
