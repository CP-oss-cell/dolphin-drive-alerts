#!/usr/bin/env python3
"""Compile actual MediaPlaybackObserver Kotlin with Android method-shape stubs."""
from pathlib import Path
import shutil,subprocess,tempfile,sys
r=Path(__file__).resolve().parents[1]
compiler=shutil.which('kotlinc')
if compiler is None:
    print('SKIP: kotlinc unavailable; authoritative CI Android Gradle compile required')
    sys.exit(0)
source=r/'app/src/main/java/com/byd/dolphin/drivealerts/automation/MediaPlaybackObserver.kt'
stubs=sorted((r/'tools/tests/media_v0178').glob('*.kt'))
with tempfile.TemporaryDirectory(prefix='media_v0178_') as d:
    args=[compiler,*map(str,stubs),str(source),'-d',str(Path(d)/'media.jar')]
    res=subprocess.run(args,capture_output=True,text=True,timeout=90)
    if res.returncode:
        print('FAIL MEDIA_KOTLIN_COMPILE:',(res.stdout+res.stderr)[-6000:]);sys.exit(res.returncode)
print('PASS: actual MediaPlaybackObserver.kt compiled against typed Android MediaBrowser + MediaSession stubs')
