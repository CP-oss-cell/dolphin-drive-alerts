# Dolphin Drive Alerts v0.17.9 — 글로벌 2602 실차 신호 복구·정밀 계측 통합

## 0. 증거 범위 및 이슈 중복 대조
- 기준: v0.17.8 소스 ZIP(`DolphinDriveAlerts-v0.17.8-RELIABILITY-RESEARCH-source.zip`), 한국형 돌핀 글로벌 2602 사용자 보고, `REALCAR_DEEP_AUDIT_20261009_KO.md`, `BYD_DOLPHIN_2602_AUDIO_AVAS_RESEARCH_20261010_KO.md`, 마스터 이슈 v44와 실차증거 v40.
- 실차 로그: 56,751 JSONL, 54,516 BYD events; 135 source+signal-ID 계열, 재시동 전후 69.525초 snapshot gap. 리스너 등록만으로 콜백 품질/물리 소리 출력 증명 불가.
- 기존 이슈 연계만: DA-003/005 NORMAL, DA-007/008 BSD·DOW·차선·앞차 출발, DA-009/010 순정 내비 운전석 경로, DA-012 AVAS, DA-015 EQ, DA-016 시동, DA-027 분할·미디어, DA-029 시동 수집. 신규 중복 이슈 없음. DA-029 과거 번호 충돌은 그대로 명시.

## 1. 소스 수정(실제 구현)
1. `ReadOnlySignalProbe.kt`: 기존 영구 `unavailable` 실패 캐시를 15초 만료로 변경. 시동 초기에 미존재·권한대기였던 BYD 클래스가 뒤늦게 준비되면 재조회. `RemoteException`/`DeadObject` 계열이면 오래된 장치 인스턴스 제거. 확장 스냅샷을 이전값과 섞지 않고 새로고침하여 재시동 후 유령 데이터 오인 방지.
2. `TargetedSignalProbe.kt`: 메서드 미탐지를 앱 실행 동안 영구 잠금하지 않고 15초 후 재시도; 실패한 Binder 장치·메서드 캐시 제거. `getOperationMode`/`getOperationModeState`와 좌우 깜박이 getter 원시값을 읽기 전용으로 기록. 숫자 2·5 등 임의 좌우 해석·음성 트리거 없음.
3. `BydVehicleReader.kt`: OEM Binder 연결 끊김 시 캐시된 장치/메서드 인스턴스를 무효화하고 다음 샘플에서 재연결.
4. `BydEventTap.kt`: 중복 값 억제 중에도 도메인별 실제 콜백 수, 중복 횟수, 마지막 수신시각을 집계. `healthSnapshot()`으로 계속 수신되는지 진단. 수집 중 30초마다 `BYD_CALLBACK_HEALTH`로 보고.
5. `ReferenceVehicleEventBridge.kt`: 정상 경고 경로의 instrument/adas/energy/setting/dipilot 콜백 수/age를 집계하는 `callbackHealth()` 신설. `REFERENCE_OPERATION_MODE`에 글로벌 2602 getter와 원시 콜백 비교 필요 표시. BSD 좌우·Pilot 경고의 의미 미확정 원칙 보존.
6. `DrivingAlertService.kt`: FGS 기동 직후 비동기 리스너는 그대로. 재시동 wake 시 일반 경고 경로도 작업 스레드에서 close→start 재등록하고, 초기 생성 실패라면 새 객체를 생성해 재시도. 최소 8초 중복 재시도 방지; 30초마다 `REFERENCE_CALLBACK_HEALTH`. 기존 지속 수집 리스너 재연결도 유지. *등록 시도와 실제 콜백 수신은 별개로 명시*.
7. `SystemDiagnosticsCollector.kt`: 짧은 NAV 비교 수집에도 `dumpsys media.audio_flinger` 포함하여 순정 내비 vs 타사 내비 AudioTrack/UID/출력 경로 비교 가능성을 높임.
8. `MainActivity.kt`: 사용자가 직접 읽기 전용으로 수집할 수 있는 순정 내비 안내음/타사 내비 안내음 비교 버튼 2개, 순정 보행자 경고음 설정 전후 12초 기록 버튼 추가. 순정 AVAS의 ON/OFF 또는 출력 명령 전송 없음. 수집을 시작한 뒤 정차에서 이용.
9. `build.gradle.kts`: 기존 applicationId 유지, versionCode 35 / versionName 0.17.9.

## 2. 기능별 실차 검증 상태 — 포장으로 인한 허위 VERIFIED 금지
| 영역 | v0.17.9 개선 및 상태 |
|---|---|
| NORMAL | 에너지 callback + 읽기 전용 getter 원시값 동시 비교 가능. 0 raw 실차 미관찰로 무리하게 NORMAL 발화하지 않음; 미해결 |
| BSD 좌우 | 게이트 기존 보존 + 좌우 원시 getter/콜백 수집 강화. 2·5 임의 좌/우 부여 금지; 미해결 |
| 주차 도어 위험·일반/ICC 차선·앞차출발 | DiPilot 후보 콜백 + 원시 FeatureId 관찰 및 리스너 재연결 강화. 실제 경고 활성 의미 미확정, 임의 위험 발화 금지; 미해결 |
| 시동 지연 | 기존 비동기 초기화 보존 + 실패 후 재시도. 실차 지연 시간 감소는 재측정 필요 |
| 미디어 앱 무화면 재생 | v0.17.8 MediaSession/MediaBrowserService 경로 보존. 앱에서 지원하지 않으면 실패, 화면 강제 기동 안 함 |
| 2분할 / 3·4분할 / 팝업 | 기존 ADB 권한·분할 스택 readback 및 읽기 전용 지원 진단 보존. OEM 3/4/popup 실차 지원 미확정 |
| DPI | DPI 120 등 순정 UI 잘림 위험 차단·`wm density reset` 보존. 가짜 해상도/순정 앱만 크기 고정 구현 없음 |
| EQ | v0.17.8 저/중/고 + 음장 + 기본/선명/강력 강도 및 세션 readback 보존. OEM 현대·기아 DSP 동일 구현 아님 |
| 운전석 NAV 5종 | 순정 내비와 Android AudioPolicy/AudioFlinger read-only 비교 수집 추가. 타 앱 cross-UID driver routing 미구현 |
| 외부 AVAS | 연구 ID는 외부 펌웨어 후보. v0.17.9는 순정 설정 시험 시각/AudioFlinger 수집만 추가. 외부 음성 PCM 출력 미확인; 모든 MCU 쓰기 금지 |

## 3. 실차 다음 실험 — 절대 의무 아님, 안전한 정차 상태에서만
- 통합 로그 **수집 시작** → 전원 OFF/ON 후 30~60초 → `REFERENCE_CALLBACK_HEALTH`, `BYD_CALLBACK_HEALTH` 확인. 특히 dipilot/adas/setting이 0건·ageMs=-1이면 리스너 등록과 실제 수신을 혼동하지 않음.
- 일반 주행/ICC 안전 기능은 위험 상황을 의도적으로 만들지 말 것. 자연 발생한 순정 계기판 경고 시각과 raw 후보 콜백을 비교.
- 정차 중 NORMAL/ECO/SPORT 선택 시 `target.energy.operationMode*`와 `REFERENCE_OPERATION_MODE`를 비교해 모드 후보 검증.
- BSD는 안전하게 정차한 상태에서 방향지시등 ON/OFF의 좌/우 getter raw와 `BSD_GATE_SUPPRESSED`를 대조. 위험 장애물 고의 유발 금지.
- 순정 내비 실제 안내음이 재생 중 `①`, 내비 5종 중 하나의 안내음 출력 중 `②` 버튼. ①②에서 audio session·bus·UID/usage를 비교. ③은 순정 AVAS 상태 시험 전후 기록만 하며 차량 안전 설정 강제 변경 없음.

## 4. 검증(로컬)
- 기존 v0.17.8 통합 정적 회귀 57/57 통과.
- 신규 v0.17.9 변경·안전 gate 검사 및 YAML 파싱.
- 실제 Kotlin 소스 3개(`ReadOnlySignalProbe`,`TargetedSignalProbe`,`BydVehicleReader`)를 최소 Android 계약 스텁으로 컴파일하고 시동 전 unavailable→15초 이후 재조회 성공을 실행 검증.
- 실제 Kotlin 소스 9개(레퍼런스 브리지, BYD tap, BSD/모드/안전 gate)를 프로젝트에 포함된 BYD Java listener 스텁으로 컴파일하고 heartbeat·방향 미확정 억제 검증.
- 로컬 Android Gradle 전체 컴파일·실차 설치·물리 스피커 출력은 **검증하지 않음**. GitHub Actions `:app:compileDebugKotlin` + `:app:assembleDebug` 성공을 기다려야 함.

## 5. 빌드 실패 방지
- `build-v0179-from-source-zip.yml`은 소스 ZIP 정확명, APK 산출 파일명, 통합 설명서 등 사전 파일 존재 검사 후 TTS→회귀→Gradle 컴파일→APK→Artifact 업로드 순서.
- v0.17.7의 잘못된 문서명 참조 이슈가 재발하지 않도록 실제 ZIP 내부 문서 목록과 워크플로 `cp` 이름을 별도 검사.
