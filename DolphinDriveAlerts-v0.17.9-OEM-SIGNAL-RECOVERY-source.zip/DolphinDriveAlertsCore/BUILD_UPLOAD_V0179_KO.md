# Dolphin Drive Alerts v0.17.9 GitHub APK 빌드 안내

1. `DolphinDriveAlerts-v0.17.9-OEM-SIGNAL-RECOVERY-source.zip`을 `CP-oss-cell/dolphin-drive-alerts` 저장소 루트에 업로드.
2. `build-v0179-from-source-zip.yml`을 `.github/workflows/build-v0179-from-source-zip.yml`에 업로드.
3. GitHub → Actions → `Build Dolphin Drive Alerts v0.17.9 OEM Signal Recovery APK` → Run workflow 실행.
4. `build-apk` 성공 후 Artifacts에서 `DolphinDriveAlerts-v0.17.9-OEM-SIGNAL-RECOVERY.apk` 다운로드.
5. 새 APK의 `versionCode=35`, 패키지명 `com.byd.dolphin.drivealerts`. v0.17.8(34)에서 업그레이드 가능하되 **동일 앱 서명 키** 필요. GitHub 매번 debug keystore가 바뀌면 업데이트 설치가 실패할 수 있어 기존 설치 서명 확인 필수.
6. 이번 패키지에는 설치용 APK가 들어 있지 않음. 전체 Android SDK 빌드는 GitHub Actions 실행 후에만 결과 확정.
7. 연구 버튼은 수집 시작 후 안전한 정차 상태에서만 사용. 순정 AVAS 보행자 경고를 끄거나 MCU에 제어 명령을 전송하지 않음.
