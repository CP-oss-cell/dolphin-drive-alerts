# 믿음하나 브라우저 v2.1.3

## 기능 추가
- 상단 앱 제목 옆 가로 퀵 탭바: 탭1, 탭2, 탭3 ... 최대 8개 바로 전환; 길게 눌러 탭 닫기 확인.
- 기존 카드 배열 탭 전체 보기 유지.
- 웹페이지 링크 길게 누르기: 링크 텍스트 복사(정보가 있을 경우), 링크 복사, 새 탭 열기, 배경 탭 열기, 공유; 직접 영상 주소면 다운로드 제공.
- 이미지 길게 누르기: 이미지 주소 복사, 새 탭 보기, 주소 공유.
- 일반 텍스트 길게 누르기는 시스템 WebView 복사/선택 메뉴 유지.
- http/https 외 링크는 앱 안에서 새 탭으로 열지 않음. DRM 우회 없음.

## 새 설치 후 업데이트 기준
- com.mideumhana.browser / versionCode 9 / versionName 2.1.2
- Debug 대체 빌드를 금지하고 Release 서명키가 등록된 경우에만 빌드.
- GitHub Actions Secrets: MHB_KEYSTORE_BASE64, MHB_KEYSTORE_PASSWORD. alias: mideumhana.
- 첫 v2.1.3 설치는 기존 앱 제거 후. v2.1.3부터는 동일 키와 상향 버전코드로 설치.

## 검증 제한
- Android SDK가 없는 실행 환경이라 실제 APK 컴파일과 Fold8 실기기 동작은 미검증.
