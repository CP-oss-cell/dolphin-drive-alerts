from pathlib import Path
r=Path(__file__).resolve().parents[1]
b=(r/'app/build.gradle').read_text()
s=(r/'SIGNING_SETUP_KO.md').read_text()
assert "versionCode 9" in b and "versionName '2.1.3'" in b
assert "applicationId 'com.mideumhana.browser'" in b
assert 'debuggable true' in b
assert 'MHB_SIGNING_KEYSTORE_PATH' not in b
assert 'GitHub Secrets' in s and '필요 없음' in s
print('V213_DEBUG_SIGNING_REGRESSION_OK')
