package app.mideumhanatube.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.app.RemoteAction;
import android.app.PendingIntent;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.JsPromptResult;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.window.OnBackAnimationCallback;
import android.window.BackEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MideumHanaTube v0.1: standalone Android web-video viewer with a best-effort ad filter.
 * The application is NOT affiliated with YouTube and does not guarantee zero ads.
 * No privileged permissions, VPN, root, Google credentials or external account servers.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://m.youtube.com/";
    private static final String PREF = "mideumhanatube_settings";
    private static final String KEY_FILTER = "filter_hosts";
    private static final String KEY_HIDE = "hide_promotions";
    private static final String KEY_SKIP = "auto_skip";
    private static final String KEY_BACKGROUND = "background_audio";
    private static final String KEY_AUTO_PIP = "auto_pip_on_home";
    private static final String KEY_MICROPHONE = "youtube_voice_microphone_enabled";
    private static final int REQUEST_MICROPHONE = 131;
    private static final int REQUEST_SPEECH = 132;
    private static final String KEY_NOTIFICATION_ASKED = "notification_permission_asked";
    private static final int COLOR_BG = Color.rgb(15, 23, 35);
    private static final int COLOR_PANEL = Color.rgb(25, 36, 52);
    private static final int COLOR_ACCENT = Color.rgb(96, 165, 250);
    private static final int COLOR_WHITE = Color.rgb(237, 242, 249);

    private SharedPreferences settings;
    private LibraryStore library;
    private FrameLayout root;
    private LinearLayout page;
    private LinearLayout statusStrip;
    private HorizontalScrollView toolsScroll;
    private TextView status;
    private WebView webView;
    private FrameLayout browserContainer;
    private FrameLayout fullscreenContainer;
    private ProgressBar loading;
    private Button bookmarkButton;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private int priorOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private boolean filterOn;
    private boolean hidePromotions;
    private boolean autoSkip;
    private boolean backgroundAudio;
    private boolean autoPip;
    private boolean microphoneEnabled;
    private boolean speechAfterPermission;
    private boolean exiting;
    private AlertDialog exitConfirmationDialog;
    private boolean backLongPressHandled;
    private PermissionRequest pendingWebMicrophoneRequest;
    private boolean activityBackgrounded;
    private boolean lastKnownPlaying;
    private boolean serviceWasStarted;
    private boolean playWasActiveOnLeave;
    private boolean attemptedResumeOnLeave;
    private boolean preparingPip;
    private boolean nativeHandoffRequested;
    private boolean nativeAudioActive;
    private long lastKnownPositionMs;
    private Button returnToVideoButton;
    private String pipEnterJavaScript = "";
    private String pipExitJavaScript = "";
    private long lastPlayerCommandMs;
    private static final long PLAYER_COMMAND_VERIFY_MS = 900L;
    private String lastMediaTitle = "믿음하나튜브";
    private boolean audioReceiverRegistered;
    private OnBackInvokedCallback systemBackCallback;
    private long systemBackGestureStartedAt;
    private long lastVoiceBridgeRequestAt;
    private String youtubeMicBridgeJavaScript = "";
    private String lastNativeError = "";
    private long lastBackAtRoot;
    private static final long BACK_EXIT_WINDOW_MS = 2000L;
    private final Runnable refreshSavedTitle = () -> {
        if (webView != null && LibraryStore.isYoutubeUrl(webView.getUrl())) {
            requestPageTitle(webView.getUrl(), 0, null);
        }
    };
    private final Handler audioHandler = new Handler(Looper.getMainLooper());
    private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BackgroundAudioService.ACTION_NATIVE_READY.equals(action)) {
                nativeHandoffRequested = false;
                nativeAudioActive = true;
                lastNativeError = "";
                if (webView != null) webView.evaluateJavascript(
                        "(function(){var v=document.querySelector('video');if(v)v.pause();})()", null);
                updateReturnToVideoButton();
                updateStatus();
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_FAILURE.equals(action)) {
                nativeHandoffRequested = false;
                nativeAudioActive = false;
                String why = intent.getStringExtra(BackgroundAudioService.EXTRA_ERROR);
                lastNativeError = why == null ? "오디오 전환 실패" : why;
                if (!activityBackgrounded) toast(lastNativeError);
                updateReturnToVideoButton();
                updateStatus();
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_POSITION.equals(action)) {
                long position = intent.getLongExtra(BackgroundAudioService.EXTRA_POSITION_MS, 0L);
                resumeVideoFromNative(position);
                return;
            }
            if (!BackgroundAudioService.ACTION_CONTROL.equals(action)) return;
            String control = intent.getStringExtra(BackgroundAudioService.EXTRA_CONTROL);
            if (BackgroundAudioService.ACTION_PLAY.equals(control)) {
                playWasActiveOnLeave = true;
                controlWebPlayer(true);
            } else if (BackgroundAudioService.ACTION_PAUSE.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
            } else if (BackgroundAudioService.ACTION_STOP.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
                stopBackgroundService();
            }
        }
    };
    private final Runnable playbackPoll = new Runnable() {
        @Override public void run() {
            if (webView != null) {
                String url = webView.getUrl();
                if (LibraryStore.isYoutubeUrl(url)) {
                    webView.evaluateJavascript(PLAYBACK_PROBE_JS, MainActivity.this::readWebPlayerState);
                } else if (lastKnownPlaying) {
                    reportPlayerState(false, lastMediaTitle);
                }
            }
            audioHandler.postDelayed(this, 1200);
        }
    };
    // Poll the HTML5 media element without exposing a JavascriptInterface to untrusted frames.
    private static final String PLAYBACK_PROBE_JS = "(function(){var a=document.querySelectorAll('video'),v=null;" +
            "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
            "if(!v&&a.length)v=a[0];" +
            "return JSON.stringify({playing:!!(v&&!v.paused&&!v.ended&&v.readyState>0&&!v.muted&&v.volume>0)," +
            "hasVideo:!!v,ended:!!(v&&v.ended),positionMs:v?Math.floor(v.currentTime*1000):0,title:document.title||'믿음하나튜브'});})()";
    private final AtomicInteger blockedCount = new AtomicInteger();
    private String cleanerJavaScript = "";
    private String bookmarkTitleJavaScript = "";
    // A bookmark is committed only when a meaningful title is available.
    private int bookmarkLookupGeneration;
    private String pendingBookmarkUrl;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences(PREF, MODE_PRIVATE);
        library = new LibraryStore(this);
        filterOn = settings.getBoolean(KEY_FILTER, true);
        hidePromotions = settings.getBoolean(KEY_HIDE, true);
        autoSkip = settings.getBoolean(KEY_SKIP, true);
        backgroundAudio = settings.getBoolean(KEY_BACKGROUND, true);
        autoPip = settings.getBoolean(KEY_AUTO_PIP, false);
        microphoneEnabled = settings.getBoolean(KEY_MICROPHONE, true);
        registerAudioReceiver();
        try { cleanerJavaScript = loadAsset("cleaner.js"); }
        catch (Exception e) { cleanerJavaScript = ""; }
        try { bookmarkTitleJavaScript = loadAsset("bookmark-title.js"); }
        catch (Exception e) { bookmarkTitleJavaScript = ""; }
        try { youtubeMicBridgeJavaScript = loadAsset("youtube-mic-bridge.js"); }
        catch (Exception e) { youtubeMicBridgeJavaScript = ""; }
        try { pipEnterJavaScript = loadAsset("pip-video-enter.js");
              pipExitJavaScript = loadAsset("pip-video-exit.js"); }
        catch (Exception e) { pipEnterJavaScript = ""; pipExitJavaScript = ""; }
        setWindowColors();
        buildUi();
        nativeAudioActive = BackgroundAudioService.hasNativeAudioSession();
        updateReturnToVideoButton();
        buildBrowser();
        registerSystemBack();
        if (state != null && state.getBundle("web_state") != null) {
            webView.restoreState(state.getBundle("web_state"));
        } else {
            navigateInitial(getIntent());
        }
        audioHandler.postDelayed(playbackPoll, 500);
        if (!settings.getBoolean("intro_seen", false)) showIntro();
    }

    private void setWindowColors() {
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        // The YouTube page already contains its own search.  The former 56dp
        // native search row was duplicate UI and is intentionally removed.

        toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setBackgroundColor(COLOR_PANEL);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(6), 0, dp(6), 0);
        toolsScroll.addView(actions, new HorizontalScrollView.LayoutParams(-2, dp(45)));
        // Keep the extra voice button on the far-right edge of the real screen,
        // independent from the horizontally scrolling navigation/action buttons.
        LinearLayout toolbarRow = new LinearLayout(this);
        toolbarRow.setOrientation(LinearLayout.HORIZONTAL);
        toolbarRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbarRow.setBackgroundColor(COLOR_PANEL);
        toolbarRow.addView(toolsScroll, new LinearLayout.LayoutParams(0, dp(45), 1f));
        Button separateVoiceButton = toolbarButton("🎙", "보조 음성 검색 (유튜브 화면 마이크와 별도)",
                v -> startVoiceSearch());
        toolbarRow.addView(separateVoiceButton, new LinearLayout.LayoutParams(-2, dp(45)));
        page.addView(toolbarRow, new LinearLayout.LayoutParams(-1, dp(45)));

        Button backButton = addAction(actions, "◀", "뒤로 (길게 누르면 앱 종료)", v -> back());
        backButton.setOnLongClickListener(v -> { showExitConfirmation(); return true; });
        addAction(actions, "▶", "앞으로", v -> { if (webView.canGoForward()) webView.goForward(); });
        addAction(actions, "⌂", "홈", v -> webView.loadUrl(HOME));
        addAction(actions, "↻", "새로고침", v -> webView.reload());
        bookmarkButton = addAction(actions, "☆", "즐겨찾기 추가 또는 제거", v -> toggleBookmark());
        addAction(actions, "즐겨찾기", "즐겨찾기 목록", v -> showEntries(false));
        addAction(actions, "기록", "시청 기록", v -> showEntries(true));
        addAction(actions, "작은 화면", "PIP 작은 화면", v -> enterPip());
        returnToVideoButton = addAction(actions, "영상 복귀", "독립 오디오에서 영상 재생으로 복귀", v -> returnToVideo());
        updateReturnToVideoButton();
        addAction(actions, "음악 설정", "홈 버튼 이후 백그라운드 음악 재생 설정", v -> showAudioSettings());
        addAction(actions, "설정", "필터·마이크·개인 정보 설정", v -> showSettings());
        addAction(actions, "앱 종료", "확인 후 음악과 영상을 중단하고 앱 종료", v -> showExitConfirmation());

        statusStrip = new LinearLayout(this);
        statusStrip.setGravity(Gravity.CENTER_VERTICAL);
        statusStrip.setPadding(dp(12), 0, dp(10), 0);
        statusStrip.setBackgroundColor(COLOR_BG);
        page.addView(statusStrip, new LinearLayout.LayoutParams(-1, dp(26)));
        status = new TextView(this);
        status.setTextColor(Color.rgb(160, 178, 195));
        status.setTextSize(11);
        status.setSingleLine(true);
        statusStrip.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_ACCENT));
        statusStrip.addView(loading, new LinearLayout.LayoutParams(dp(65), dp(4)));

        browserContainer = new FrameLayout(this);
        page.addView(browserContainer, new LinearLayout.LayoutParams(-1, 0, 1f));
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets area = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                if (isInPictureInPictureMode() || preparingPip) view.setPadding(0, 0, 0, 0);
                else view.setPadding(area.left, area.top, area.right, area.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
        updateStatus();
    }

    private Button addAction(LinearLayout container, String label, String description, View.OnClickListener action) {
        Button btn = toolbarButton(label, description, action);
        container.addView(btn, new LinearLayout.LayoutParams(-2, dp(44)));
        return btn;
    }

    private Button toolbarButton(String label, String description, View.OnClickListener action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(COLOR_WHITE);
        btn.setTextSize(13);
        btn.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        btn.setPadding(dp(8), 0, dp(8), 0);
        btn.setMinWidth(0);
        btn.setMinimumWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumHeight(0);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(COLOR_PANEL));
        btn.setContentDescription(description);
        btn.setOnClickListener(action);
        return btn;
    }

    private void buildBrowser() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browserContainer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Notification Play and one-shot background recovery are not DOM user gestures.
        // The app only attempts recovery after an already-playing video was user-started.
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (filterOn && AdBlockEngine.shouldBlock(request.getUrl().toString(), request.isForMainFrame())) {
                    int count = blockedCount.incrementAndGet();
                    if (count <= 10 || count % 10 == 0) runOnUiThread(MainActivity.this::updateStatus);
                    WebResourceResponse empty = new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                    empty.setStatusCodeAndReasonPhrase(204, "No Content");
                    return empty;
                }
                return null;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if (isInternal(url)) return false;
                if ("https".equalsIgnoreCase(url.getScheme()) || "http".equalsIgnoreCase(url.getScheme())) {
                    openExternal(url);
                } else {
                    toast("외부 앱으로 연결되는 링크는 지원하지 않습니다.");
                }
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (lastKnownPlaying) reportPlayerState(false, lastMediaTitle);
                loading.setVisibility(View.VISIBLE);
                loading.setProgress(5);
                updateStatus();
            }

            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
                if (LibraryStore.isYoutubeUrl(url)) {
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                    injectCleaner();
                    injectYouTubeMicBridge();
                }
                updateBookmark();
                scheduleSavedTitleRefresh();
                updateStatus();
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                super.doUpdateVisitedHistory(view, url, isReload);
                if (!isReload && LibraryStore.isYoutubeUrl(url))
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                updateBookmark();
                scheduleSavedTitleRefresh();
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loading.setVisibility(View.GONE);
                    toast("페이지 연결 실패: 인터넷 상태와 Android WebView를 확인하세요.");
                }
            }

            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view == webView) {
                    browserContainer.removeView(view);
                    view.destroy();
                    webView = null;
                    toast("웹 엔진이 종료되어 화면을 다시 엽니다.");
                    recreate();
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loading.setProgress(progress);
                loading.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (LibraryStore.isYoutubeUrl(view.getUrl())) {
                    library.addHistory(BookmarkTitleResolver.resolve(title, null, view.getUrl()), view.getUrl());
                    scheduleSavedTitleRefresh();
                }
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            // Some YouTube pages show "브라우저 설정에서 마이크를 허용" instead
            // of requesting getUserMedia in Android WebView. An injected listener
            // on the PAGE'S voice-search control bridges that user click to the
            // Android speech recognizer; never allow untrusted origins to use it.
            @Override public boolean onJsPrompt(WebView view, String url, String message,
                                                String defaultValue, JsPromptResult result) {
                if ("MHT_YOUTUBE_VOICE_SEARCH_0111".equals(message) &&
                        microphoneEnabled && VoicePermissionPolicy.isTrustedOrigin(url)) {
                    result.confirm("");
                    audioHandler.post(MainActivity.this::startVoiceSearch);
                    return true;
                }
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }

            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (pendingWebMicrophoneRequest == request) pendingWebMicrophoneRequest = null;
                });
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCallback = callback;
                priorOrientation = getRequestedOrientation();
                page.setVisibility(View.GONE);
                fullscreenContainer.removeAllViews();
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenContainer.setVisibility(View.VISIBLE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        View.SYSTEM_UI_FLAG_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() { hideCustomView(); }
        });
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(priorOrientation);
        page.setVisibility(isInPictureInPictureMode() ? View.GONE : View.VISIBLE);
        if (root != null) root.requestApplyInsets();
    }

    private static boolean isInternal(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                || AdBlockEngine.isHostOrSubdomain(host, "youtu.be")
                || AdBlockEngine.isHostOrSubdomain(host, "youtube-nocookie.com");
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException ex) { toast("연결할 브라우저가 없습니다."); }
    }

    private void navigateInitial(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        webView.loadUrl(uri != null && isInternal(uri) ? uri.toString() : HOME);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // A media notification opens this Activity with NO URL. Do not navigate to HOME:
        // doing so destroys the current video position and makes PiP restoration restart.
        Uri link = intent == null ? null : intent.getData();
        if (webView != null && link != null && isInternal(link) &&
                !link.toString().equals(webView.getUrl())) webView.loadUrl(link.toString());
    }

    /** Request microphone access only for HTTPS YouTube origins and audio only.
     * NEVER grant all requested WebView resources; camera and other resources stay denied.
     */
    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) return;
        if (!microphoneEnabled ||
                !VoicePermissionPolicy.isTrustedOrigin(String.valueOf(request.getOrigin())) ||
                !VoicePermissionPolicy.isAudioOnly(request.getResources(),
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
            request.deny();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            return;
        }
        // The Android permission prompt is shown only after the web page asks for audio.
        if (pendingWebMicrophoneRequest != null && pendingWebMicrophoneRequest != request)
            pendingWebMicrophoneRequest.deny();
        pendingWebMicrophoneRequest = request;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
    }

    private void requestMicForSettings() {
        if (!microphoneEnabled) {
            toast("먼저 설정에서 유튜브 음성 검색 마이크 사용을 켜 주세요.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            toast("마이크 권한이 허용되어 있습니다.");
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
        }
    }

    /** Replaces only the YouTube *page's own* voice-icon click when WebView
     * rejects web microphone access. A separate toolbar mic also remains.
     * The injected script uses a trusted-origin prompt, not JavascriptInterface.
     */
    private void injectYouTubeMicBridge() {
        if (!microphoneEnabled || webView == null || youtubeMicBridgeJavaScript.isEmpty()) return;
        if (!VoicePermissionPolicy.isTrustedOrigin(webView.getUrl())) return;
        webView.evaluateJavascript(youtubeMicBridgeJavaScript, null);
    }

    // Native recognizer: invoked from either the page mic icon or separate toolbar mic.
    private void startVoiceSearch() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastVoiceBridgeRequestAt < 850L) return;
        lastVoiceBridgeRequestAt = now;
        if (!microphoneEnabled) {
            toast("설정에서 '유튜브 음성 검색 마이크 사용'을 켜 주세요.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speechAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
            return;
        }
        launchVoiceRecognizer();
    }

    private void launchVoiceRecognizer() {
        Intent voice = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        voice.putExtra(RecognizerIntent.EXTRA_PROMPT, "유튜브에서 무엇을 검색할까요?");
        try {
            startActivityForResult(voice, REQUEST_SPEECH);
        } catch (ActivityNotFoundException error) {
            toast("음성 인식 앱이 없습니다. 유튜브 화면의 검색을 이용해 주세요.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SPEECH || resultCode != RESULT_OK || data == null) return;
        ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (results == null || results.isEmpty()) return;
        String words = results.get(0) == null ? "" : results.get(0).trim();
        if (!words.isEmpty() && webView != null) {
            webView.loadUrl("https://m.youtube.com/results?search_query=" + Uri.encode(words));
            toast("음성 검색: " + words);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_MICROPHONE) return;
        boolean granted = grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;
        PermissionRequest webRequest = pendingWebMicrophoneRequest;
        pendingWebMicrophoneRequest = null;
        if (webRequest != null) {
            if (granted && microphoneEnabled &&
                    VoicePermissionPolicy.isTrustedOrigin(String.valueOf(webRequest.getOrigin())))
                webRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else webRequest.deny();
        }
        boolean search = speechAfterPermission;
        speechAfterPermission = false;
        if (search && granted && microphoneEnabled) launchVoiceRecognizer();
        else if (!granted) toast("마이크 권한이 거부되었습니다. Android 앱 설정에서 허용할 수 있습니다.");
    }

    /**
     * Save the real current title, never a synthetic video ID.
     * SPA pages may publish their title well after the navigation callbacks fire.
     * DOM and YouTube oEmbed lookup race; the first verified title wins.
     */
    private void toggleBookmark() {
        if (webView == null) return;
        String url = webView.getUrl();
        if (!LibraryStore.isYoutubeUrl(url)) {
            toast("유튜브 페이지에서만 저장할 수 있습니다.");
            return;
        }
        if (library.isBookmarked(url)) {
            bookmarkLookupGeneration++;
            pendingBookmarkUrl = null;
            library.removeBookmark(url);
            updateBookmark();
            toast("즐겨찾기에서 제거했습니다.");
            return;
        }
        if (url.equals(pendingBookmarkUrl)) {
            toast("영상 제목을 확인하는 중입니다.");
            return;
        }
        // A previously visited entry may already have the correct title.
        for (LibraryStore.Entry entry : library.history()) {
            if (url.equals(entry.url) && BookmarkSavePolicy.isActualTitle(entry.title, url)) {
                library.addBookmark(entry.title, url);
                updateBookmark();
                toast("즐겨찾기 저장: " + entry.title);
                return;
            }
        }
        // Home and search have stable, meaningful names without waiting for video metadata.
        String simpleName = BookmarkSavePolicy.simplePageName(url);
        if (simpleName != null) {
            library.addBookmark(simpleName, url);
            updateBookmark();
            toast("즐겨찾기 저장: " + simpleName);
            return;
        }
        final int requestId = ++bookmarkLookupGeneration;
        pendingBookmarkUrl = url;
        toast("즐겨찾기 제목을 확인하고 있습니다.");
        requestTitleForBookmark(url, requestId, 0);

        // oEmbed is a complementary, public YouTube title endpoint; it is never
        // trusted as HTML and never receives unrelated query parameters.
        if (YouTubeOEmbedUrl.forSource(url) != null) {
            new Thread(() -> {
                String title = YouTubeOEmbedTitle.fetch(url);
                runOnUiThread(() -> completeBookmarkWithTitle(url, requestId, title));
            }, "bookmark-metadata").start();
        }
        audioHandler.postDelayed(() -> {
            if (!isActiveBookmarkRequest(url, requestId)) return;
            pendingBookmarkUrl = null;
            showBookmarkTitleInput(url);
        }, 8500L);
    }

    private boolean isActiveBookmarkRequest(String url, int requestId) {
        return requestId == bookmarkLookupGeneration && url.equals(pendingBookmarkUrl)
                && webView != null && url.equals(webView.getUrl());
    }

    private void completeBookmarkWithTitle(String url, int requestId, String title) {
        if (!isActiveBookmarkRequest(url, requestId)) return;
        String resolved = BookmarkTitleResolver.resolve(title, null, url);
        if (!BookmarkSavePolicy.isActualTitle(resolved, url)) return;
        pendingBookmarkUrl = null;
        library.addBookmark(resolved, url);
        library.repairGenericTitles(url, resolved);
        updateBookmark();
        toast("즐겨찾기 저장: " + resolved);
    }

    private void requestTitleForBookmark(String url, int requestId, int attempt) {
        if (!isActiveBookmarkRequest(url, requestId)) return;
        extractLiveTitle(url, title -> {
            if (!isActiveBookmarkRequest(url, requestId)) return;
            if (BookmarkSavePolicy.isActualTitle(title, url)) {
                completeBookmarkWithTitle(url, requestId, title);
            } else if (attempt < 12) {
                audioHandler.postDelayed(() -> requestTitleForBookmark(url, requestId, attempt + 1), 550L);
            }
        });
    }

    /** On source pages with unavailable metadata, never silently save an ID. */
    private void showBookmarkTitleInput(String url) {
        if (webView == null || !url.equals(webView.getUrl())) return;
        // Search and home URLs have meaningful names even without a video title.
        String meaningfulFallback = BookmarkSavePolicy.simplePageName(url);
        if (meaningfulFallback != null) {
            library.addBookmark(meaningfulFallback, url);
            updateBookmark();
            toast("즐겨찾기 저장: " + meaningfulFallback);
            return;
        }
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("영상 또는 채널 이름을 입력하세요");
        FrameLayout wrapper = new FrameLayout(this);
        wrapper.setPadding(dp(18), dp(10), dp(18), dp(10));
        wrapper.addView(input, new FrameLayout.LayoutParams(-1, -2));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 이름 확인")
                .setMessage("유튜브에서 제목을 가져오지 못했습니다. 영상 ID 대신 이름을 직접 입력해 저장할 수 있어요.")
                .setView(wrapper)
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(clicked -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) { input.setError("이름을 입력해 주세요."); return; }
                    if (webView == null || !url.equals(webView.getUrl())) {
                        toast("페이지가 변경되어 저장하지 않았습니다.");
                        dialog.dismiss();
                        return;
                    }
                    library.addBookmark(name, url);
                    updateBookmark();
                    toast("즐겨찾기 저장: " + name);
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private interface TitleResult { void resolved(String title); }

    private void extractLiveTitle(String expectedUrl, TitleResult callback) {
        if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
        if (bookmarkTitleJavaScript.isEmpty()) {
            callback.resolved(BookmarkTitleResolver.fallbackForUrl(expectedUrl));
            return;
        }
        webView.evaluateJavascript(bookmarkTitleJavaScript, json -> {
            if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
            String metadata = null;
            // Do not trust WebView.getTitle(): it can still refer to the previous SPA video.
            String pageTitle = "YouTube";
            try {
                Object unwrapped = new JSONTokener(json).nextValue();
                if (unwrapped instanceof String) {
                    JSONObject parsed = new JSONObject((String) unwrapped);
                    if (!expectedUrl.equals(parsed.optString("url", ""))) return;
                    metadata = parsed.optString("title", "");
                    pageTitle = parsed.optString("pageTitle", "YouTube");
                }
            } catch (Exception ignored) { }
            callback.resolved(BookmarkTitleResolver.resolve(metadata, pageTitle, expectedUrl));
        });
    }

    private void requestPageTitle(String expectedUrl, int retry, TitleResult callback) {
        extractLiveTitle(expectedUrl, resolved -> {
            if (BookmarkTitleResolver.isFallback(resolved) && retry < 2) {
                audioHandler.postDelayed(() -> requestPageTitle(expectedUrl, retry + 1, callback),
                        retry == 0 ? 450L : 900L);
                return;
            }
            library.repairGenericTitles(expectedUrl, resolved);
            if (callback != null) callback.resolved(resolved);
        });
    }

    private void scheduleSavedTitleRefresh() {
        audioHandler.removeCallbacks(refreshSavedTitle);
        audioHandler.postDelayed(refreshSavedTitle, 650);
    }

    private void updateBookmark() {
        if (bookmarkButton != null && webView != null)
            bookmarkButton.setText(library.isBookmarked(webView.getUrl()) ? "★" : "☆");
    }

    private void showEntries(boolean history) {
        List<LibraryStore.Entry> entries = history ? library.history() : library.bookmarks();
        String title = history ? "최근 방문 기록" : "즐겨찾기";
        if (entries.isEmpty()) { toast(title + "이 없습니다."); return; }
        String[] titles = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) titles[i] = entries.get(i).title;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(history ? title : "즐겨찾기 · 길게 눌러 이름 변경")
                .setItems(titles, (d, index) -> webView.loadUrl(entries.get(index).url))
                .setNegativeButton("닫기", null)
                .setNeutralButton("전체 삭제", (d, which) -> new AlertDialog.Builder(this)
                        .setTitle(title + " 전체 삭제")
                        .setMessage("기기에 저장된 항목을 모두 삭제할까요?")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제", (confirmation, w) -> {
                            if (history) library.clearHistory(); else library.clearBookmarks();
                            updateBookmark();
                            toast("삭제했습니다.");
                        }).show())
                .create();
        dialog.setOnShowListener(ignored -> {
            if (history) return;
            dialog.getListView().setOnItemLongClickListener((parent, view, position, id) -> {
                dialog.dismiss();
                renameBookmark(entries.get(position));
                return true;
            });
        });
        dialog.show();
    }

    private void renameBookmark(LibraryStore.Entry entry) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(entry.title);
        input.selectAll();
        int pad = dp(18);
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(pad, dp(8), pad, dp(8));
        frame.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 이름 변경")
                .setView(frame)
                .setNegativeButton("취소", null)
                .setNeutralButton("삭제", (d, which) -> {
                    library.removeBookmark(entry.url);
                    updateBookmark();
                    toast("즐겨찾기를 삭제했습니다.");
                })
                .setPositiveButton("저장", (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) { toast("이름을 입력해 주세요."); return; }
                    library.renameBookmark(entry.url, name);
                    toast("이름을 변경했습니다.");
                })
                .show();
    }

    private void showSettings() {
        String[] labels = {
                "외부 광고 서버 요청 차단 (권장)",
                "광고성 화면 요소 숨기기 (권장)",
                "광고 건너뛰기 버튼 자동 클릭 (실험)",
                "백그라운드 음악 재생 (홈/화면잠금)",
                "홈 버튼 시 PIP 작은 화면 자동 전환 (선택)",
                "유튜브 음성 검색 마이크 사용 (Android 권한 필요)"
        };
        boolean[] checks = {filterOn, hidePromotions, autoSkip, backgroundAudio, autoPip, microphoneEnabled};
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 설정")
                .setMultiChoiceItems(labels, checks, (dialog, which, checked) -> checks[which] = checked)
                .setPositiveButton("적용", (dialog, which) -> {
                    boolean shouldReload = filterOn != checks[0]
                            || hidePromotions != checks[1] || autoSkip != checks[2];
                    filterOn = checks[0];
                    hidePromotions = checks[1];
                    autoSkip = checks[2];
                    boolean wasBackground = backgroundAudio;
                    backgroundAudio = checks[3];
                    autoPip = checks[4];
                    microphoneEnabled = checks[5];
                    if (!microphoneEnabled && pendingWebMicrophoneRequest != null) {
                        pendingWebMicrophoneRequest.deny();
                        pendingWebMicrophoneRequest = null;
                    }
                    settings.edit().putBoolean(KEY_MICROPHONE, microphoneEnabled)
                            .putBoolean(KEY_FILTER, filterOn)
                            .putBoolean(KEY_HIDE, hidePromotions)
                            .putBoolean(KEY_SKIP, autoSkip)
                            .putBoolean(KEY_BACKGROUND, backgroundAudio)
                            .putBoolean(KEY_AUTO_PIP, autoPip).apply();
                    if (microphoneEnabled &&
                            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                        requestMicForSettings();
                    if (microphoneEnabled) injectYouTubeMicBridge();
                    if (!backgroundAudio) stopBackgroundService();
                    if (backgroundAudio && !wasBackground) {
                        requestNotificationPermission();
                        if (lastKnownPlaying) {
                            lastKnownPlaying = false;
                            reportPlayerState(true, lastMediaTitle);
                        }
                    }
                    injectCleaner();
                    // Reload only if web filtering options changed, not when toggling audio.
                    if (webView != null && shouldReload)
                        webView.reload();
                    updateStatus();
                })
                .setNeutralButton("설명", (dialog, which) -> new AlertDialog.Builder(this)
                        .setTitle("광고 필터 및 개인정보")
                        .setMessage("광고 필터는 실험적이며 완전한 광고 제거는 보장되지 않습니다. 재생이 실패하면 필터를 꺼보세요.\n\n마이크는 사용자가 음성 검색을 실행하거나 웹페이지가 요청할 때만 권한을 요청하며, HTTPS 유튜브 음성 입력에만 허용합니다. 앱 위쪽 메뉴의 🎙 버튼은 기기의 음성 인식 앱으로 검색합니다. 인식 처리는 해당 음성 인식 제공자의 정책을 따릅니다.\n\n시청 기록과 즐겨찾기는 기기 안에 저장합니다.")
                        .setPositiveButton("확인", null).show())
                .setNegativeButton("취소", null)
                .show();
    }

    private void injectCleaner() {
        if (webView == null || cleanerJavaScript.isEmpty()) return;
        if (!LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        String script = "window.__CS_HIDE=" + (hidePromotions ? "true" : "false") + ";" +
                "window.__CS_SKIP=" + (autoSkip ? "true" : "false") + ";\n" + cleanerJavaScript;
        webView.evaluateJavascript(script, null);
    }

    /**
     * PiP is an Activity window, not a separate video player. Before shrinking the window
     * we hide ALL native chrome and isolate the existing HTML5 video element in-place.
     * We must never call loadUrl/reload/recreate or move the video DOM node here.
     */
    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26 ||
                !getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("이 기기는 작은 화면(PIP)을 지원하지 않습니다.");
            return;
        }
        if (isInPictureInPictureMode() || preparingPip) return;
        if (customView != null) { // WebChromeClient already supplied video-only fullscreen view.
            enterNativePip();
            return;
        }
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl()) ||
                pipEnterJavaScript.isEmpty()) {
            toast("영상 재생 화면을 먼저 열어 주세요.");
            return;
        }
        preparingPip = true;
        webView.evaluateJavascript(pipEnterJavaScript, response -> {
            boolean ready = false;
            try {
                Object result = new JSONTokener(response).nextValue();
                if (result instanceof String)
                    ready = new JSONObject((String) result).optBoolean("ready", false);
            } catch (Exception ignored) { }
            if (!ready) {
                preparingPip = false;
                toast("재생 중인 영상이 없어 작은 화면을 열지 않았습니다.");
                return;
            }
            enterNativePip();
        });
    }

    private void enterNativePip() {
        if (Build.VERSION.SDK_INT < 26) return;
        preparingPip = true;
        setPipChromeHidden(true);
        try {
            Rect visibleVideo = new Rect();
            View videoSurface = customView == null ? browserContainer : fullscreenContainer;
            boolean hasBounds = videoSurface != null && videoSurface.getGlobalVisibleRect(visibleVideo);
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (hasBounds && !visibleVideo.isEmpty()) builder.setSourceRectHint(visibleVideo);
            if (serviceWasStarted) builder.setActions(pipControls());
            boolean entered = enterPictureInPictureMode(builder.build());
            if (!entered) {
                preparingPip = false;
                setPipChromeHidden(false);
                exitPipVideoIsolation();
                toast("작은 화면 전환이 허용되지 않았습니다.");
            }
        } catch (RuntimeException e) {
            preparingPip = false;
            setPipChromeHidden(false);
            exitPipVideoIsolation();
            toast("작은 화면 전환 실패. 기기 PIP 설정을 확인해 주세요.");
        }
    }

    private java.util.List<RemoteAction> pipControls() {
        // A PiP window does not provide touch access to the web page itself.
        // These two standard actions appear when the user taps the PiP bubble.
        PendingIntent resume = PendingIntent.getService(this, 410,
                new Intent(this, BackgroundAudioService.class)
                        .setAction(BackgroundAudioService.ACTION_PLAY),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pause = PendingIntent.getService(this, 411,
                new Intent(this, BackgroundAudioService.class)
                        .setAction(BackgroundAudioService.ACTION_PAUSE),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return java.util.Arrays.asList(
                new RemoteAction(Icon.createWithResource(this, android.R.drawable.ic_media_play),
                        "재생", "작은 화면 영상 재생", resume),
                new RemoteAction(Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                        "일시중지", "작은 화면 영상 일시중지", pause));
    }

    private void setPipChromeHidden(boolean hide) {
        int visibility = hide ? View.GONE : View.VISIBLE;
        if (toolsScroll != null) toolsScroll.setVisibility(visibility);
        if (statusStrip != null) statusStrip.setVisibility(visibility);
        if (root != null && Build.VERSION.SDK_INT >= 30) root.requestApplyInsets();
    }

    private void exitPipVideoIsolation() {
        if (webView != null && !pipExitJavaScript.isEmpty())
            webView.evaluateJavascript(pipExitJavaScript, null);
    }

    @Override public void onPictureInPictureModeChanged(boolean pip, Configuration config) {
        super.onPictureInPictureModeChanged(pip, config);
        preparingPip = false;
        if (pip) {
            setPipChromeHidden(true);
            // Some Android 12+ home gestures enter PiP before the JS callback arrives.
            if (customView == null && webView != null && !pipEnterJavaScript.isEmpty())
                webView.evaluateJavascript(pipEnterJavaScript, null);
        } else {
            // Restore the exact same DOM/video instance without navigating or restarting.
            exitPipVideoIsolation();
            setPipChromeHidden(false);
            if (root != null && Build.VERSION.SDK_INT >= 30) root.requestApplyInsets();
        }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText((!lastNativeError.isEmpty() ? "오디오 오류 · 설정→음악 설정→재생 진단" :
                (backgroundAudio ? "음악 백그라운드 ON" : "음악 백그라운드 OFF")) +
                " · " + (nativeAudioActive ? "독립 오디오 중" : (nativeHandoffRequested ? "오디오 전환 중" :
                (lastKnownPlaying ? "재생 중" : "대기"))) +
                " · 광고 차단 요청 " + blockedCount.get() + "건");
    }

    private void showIntro() {
        settings.edit().putBoolean("intro_seen", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 0.1.11")
                .setMessage("일반 Android 8 이상용 유튜브 웹 시청 앱입니다. 상단 중복 검색줄을 제거하고, 뒤로 버튼 길게 누르기 및 종료 버튼의 종료 확인창, 유튜브 마이크 권한 및 음성 검색을 추가했습니다. 백그라운드 오디오와 광고 필터는 실험 기능입니다. 차량에서는 정차 상태에서만 영상을 시청하세요.")
                .setPositiveButton("시작", null)
                .show();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }

    private String loadAsset(String name) throws Exception {
        try (java.io.InputStream stream = getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int n;
            while ((n = stream.read(chunk)) != -1) buffer.write(chunk, 0, n);
            return buffer.toString(StandardCharsets.UTF_8.name());
        }
    }

    /** One handler for toolbar, Android Back button and Android 13+ back gestures. */
    private void back() {
        if (customView != null) { hideCustomView(); return; }
        if (webView != null && webView.canGoBack()) {
            lastBackAtRoot = 0L;
            webView.goBack();
            return;
        }
        if (webView != null) {
            String current = webView.getUrl();
            if (current != null && !HOME.equals(current) &&
                    !"https://www.youtube.com/".equals(current)) {
                lastBackAtRoot = 0L;
                webView.loadUrl(HOME);
                return;
            }
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackAtRoot <= BACK_EXIT_WINDOW_MS) {
            showExitConfirmation();
        } else {
            lastBackAtRoot = now;
            toast("한 번 더 뒤로 누르면 앱을 종료합니다.");
        }
    }

    /**
     * All user-facing exit paths ask first. Merely opening/cancelling this dialog
     * never pauses WebView, changes playback position or stops native audio.
     */
    private void showExitConfirmation() {
        if (exiting || isFinishing() || isDestroyed()) return;
        if (exitConfirmationDialog != null && exitConfirmationDialog.isShowing()) return;
        lastBackAtRoot = 0L;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 종료")
                .setMessage("앱을 종료하시겠습니까?\n\n재생 중인 음악과 영상도 함께 종료됩니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("종료", (d, which) -> exitApp())
                .create();
        exitConfirmationDialog = dialog;
        dialog.setOnDismissListener(d -> {
            if (exitConfirmationDialog == dialog) exitConfirmationDialog = null;
        });
        dialog.show();
    }

    /** Called ONLY after the user confirms exit. Stops all playing media. */
    private void exitApp() {
        if (exiting) return;
        exiting = true;
        nativeHandoffRequested = false;
        nativeAudioActive = false;
        playWasActiveOnLeave = false;
        preparingPip = false;
        audioHandler.removeCallbacksAndMessages(null);
        try {
            if (webView != null) {
                webView.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
                webView.onPause();
            }
        } catch (RuntimeException ignored) { }
        stopBackgroundService();
        finishAndRemoveTask();
    }

    /** Physical BACK keys can report a long press; system gestures cannot. */
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.getRepeatCount() == 0) {
                backLongPressHandled = false;
                event.startTracking();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            backLongPressHandled = true;
            showExitConfirmation();
            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!backLongPressHandled && !event.isCanceled()) back();
            backLongPressHandled = false;
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void registerSystemBack() {
        // Android 14+ can report Back *started* and *committed* events.
        // On some system navigation modes a long press can thus be measured.
        // On Android 13 and gesture modes that provide commit only, duration
        // is not available; we preserve ordinary back and explicit App Exit.
        if (Build.VERSION.SDK_INT >= 34) {
            systemBackCallback = new OnBackAnimationCallback() {
                @Override public void onBackStarted(BackEvent event) {
                    systemBackGestureStartedAt = SystemClock.elapsedRealtime();
                }
                @Override public void onBackProgressed(BackEvent event) { }
                @Override public void onBackCancelled() { systemBackGestureStartedAt = 0L; }
                @Override public void onBackInvoked() {
                    long elapsed = systemBackGestureStartedAt == 0L ? 0L :
                            SystemClock.elapsedRealtime() - systemBackGestureStartedAt;
                    systemBackGestureStartedAt = 0L;
                    if (elapsed >= 850L) showExitConfirmation();
                    else back();
                }
            };
        } else if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback = this::back;
        }
        if (systemBackCallback != null) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, systemBackCallback);
        }
    }

    @Override public void onBackPressed() { back(); }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); }
    @Override protected void onSaveInstanceState(Bundle output) {
        if (webView != null) {
            Bundle webState = new Bundle();
            webView.saveState(webState);
            output.putBundle("web_state", webState);
        }
        super.onSaveInstanceState(output);
    }
    private void registerAudioReceiver() {
        android.content.IntentFilter filter = new android.content.IntentFilter(BackgroundAudioService.ACTION_CONTROL);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_READY);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_FAILURE);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_POSITION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(audioControlReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(audioControlReceiver, filter);
        }
        audioReceiverRegistered = true;
    }

    private void readWebPlayerState(String response) {
        try {
            Object unwrapped = new JSONTokener(response).nextValue();
            if (!(unwrapped instanceof String)) return;
            JSONObject state = new JSONObject((String) unwrapped);
            lastKnownPositionMs = Math.max(0L, state.optLong("positionMs", lastKnownPositionMs));
            boolean playing = state.optBoolean("playing", false);
            if (!state.optBoolean("hasVideo", false)) playing = false;
            String title = state.optString("title", "믿음하나튜브");
            if (title.isEmpty()) title = "믿음하나튜브";
            reportPlayerState(playing, title);
        } catch (Exception ignored) {
            // A navigation may invalidate the JS callback; the next poll will retry.
        }
    }

    private void reportPlayerState(boolean playing, String title) {
        if (nativeHandoffRequested || nativeAudioActive) {
            // WebView is no longer the audio source: never overwrite the native session.
            lastKnownPlaying = playing;
            lastMediaTitle = title;
            updateStatus();
            return;
        }
        if (playing == lastKnownPlaying && title.equals(lastMediaTitle)) return;
        boolean changed = playing != lastKnownPlaying;
        lastKnownPlaying = playing;
        lastMediaTitle = title;
        if (!backgroundAudio) { updateStatus(); return; }
        if (playing) {
            if (!activityBackgrounded && Build.VERSION.SDK_INT >= 33 &&
                    !settings.getBoolean(KEY_NOTIFICATION_ASKED, false)) {
                settings.edit().putBoolean(KEY_NOTIFICATION_ASKED, true).apply();
                requestNotificationPermission();
            }
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, true)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title)
                    .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL,
                            webView == null ? "" : webView.getUrl());
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);
                serviceWasStarted = true;
            } catch (RuntimeException ignored) {
                // Foreground service restrictions may prevent a late background start.
                serviceWasStarted = false;
            }
        } else if (serviceWasStarted) {
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, false)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title);
            try { startService(intent); } catch (RuntimeException ignored) { }
        }
        if (changed) updateStatus();
    }

    private void stopBackgroundService() {
        serviceWasStarted = false;
        stopService(new Intent(this, BackgroundAudioService.class));
    }

    /** Request play/pause, then check the REAL video state before changing the notification. */
    private void controlWebPlayer(boolean play) {
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) {
            reportControlFailure("앱에서 먼저 영상을 열어 재생해 주세요.");
            return;
        }
        final String expectedUrl = webView.getUrl();
        lastPlayerCommandMs = SystemClock.elapsedRealtime();
        final long commandId = lastPlayerCommandMs;
        String script = "(function(){try{var a=document.querySelectorAll('video'),v=null;" +
                "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
                "if(!v&&a.length)v=a[0];if(!v)return 'NO_VIDEO';" +
                (play ? "var p=v.play();if(p&&p.catch)p.catch(function(e){window.__MHT_PLAY_ERROR=String(e&&e.name||e);});" : "v.pause();") +
                "return 'SENT';}catch(e){return String(e&&e.name||e);}})()";
        webView.evaluateJavascript(script, response -> {
            if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
            if (response == null || !response.contains("SENT")) {
                reportControlFailure("웹 플레이어 명령을 실행할 수 없습니다.");
                return;
            }
            audioHandler.postDelayed(() -> verifyPlayerCommand(expectedUrl, commandId, play),
                    PLAYER_COMMAND_VERIFY_MS);
        });
    }

    private void verifyPlayerCommand(String expectedUrl, long commandId, boolean requestedPlay) {
        if (webView == null || commandId != lastPlayerCommandMs ||
                !expectedUrl.equals(webView.getUrl())) return;
        webView.evaluateJavascript(PLAYBACK_PROBE_JS, response -> {
            if (webView == null || commandId != lastPlayerCommandMs ||
                    !expectedUrl.equals(webView.getUrl())) return;
            readWebPlayerState(response);
            if (requestedPlay && !lastKnownPlaying) {
                reportControlFailure("웹 플레이어가 재생을 시작하지 못했습니다. 앱 화면에서 재생해 주세요.");
            }
        });
    }

    private void reportControlFailure(String reason) {
        if (!activityBackgrounded) toast(reason);
        Intent intent = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_FEEDBACK)
                .putExtra(BackgroundAudioService.EXTRA_ERROR, reason);
        try { startService(intent); } catch (RuntimeException ignored) { }
    }

    private void attemptBackgroundResumptionOnce() {
        if (!activityBackgrounded || !backgroundAudio || !playWasActiveOnLeave || attemptedResumeOnLeave)
            return;
        attemptedResumeOnLeave = true;
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        // A single retry is allowed only for media the user had actively started.
        // We intentionally do not create a repeating autoplay loop.
        webView.evaluateJavascript("(function(){var v=document.querySelector('video');" +
                "if(v&&v.paused&&!v.ended&&v.currentTime>0){" +
                "var p=v.play();if(p&&p.catch)p.catch(function(){});return true;}return false;})()", null);
    }

    private void beginNativeHandoff() {
        if (webView == null || nativeHandoffRequested || nativeAudioActive) return;
        String url = webView.getUrl();
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) return;
        nativeHandoffRequested = true;
        Intent intent = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_NATIVE_START)
                .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL, url)
                .putExtra(BackgroundAudioService.EXTRA_POSITION_MS, lastKnownPositionMs)
                .putExtra(BackgroundAudioService.EXTRA_TITLE, lastMediaTitle);
        try {
            // Foreground-service transition is user-initiated via the Home gesture.
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
        } catch (RuntimeException error) {
            nativeHandoffRequested = false;
        }
        updateStatus();
    }

    private void updateReturnToVideoButton() {
        if (returnToVideoButton != null)
            returnToVideoButton.setVisibility(nativeAudioActive ? View.VISIBLE : View.GONE);
    }

    private void returnToVideo() {
        if (!nativeAudioActive || webView == null) return;
        Intent request = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_NATIVE_RETURN);
        try { startService(request); } catch (RuntimeException ignored) { }
    }

    private void resumeVideoFromNative(long positionMs) {
        if (!nativeAudioActive || webView == null) return;
        final String url = webView.getUrl();
        // Seek the EXISTING WebView video element; no page reload and no video restart.
        String js = "(function(){var v=document.querySelector('video');if(!v)return 'MISSING';" +
                "if(Number.isFinite(" + positionMs + ")&&" + positionMs + ">0)v.currentTime=" +
                (positionMs / 1000.0) + ";" +
                "var p=v.play();if(p&&p.catch)p.catch(function(){});return 'OK';})()";
        webView.evaluateJavascript(js, response -> {
            if (webView == null || !url.equals(webView.getUrl())) return;
            if (response == null || !response.contains("OK")) {
                toast("영상 복귀에 실패했습니다. 독립 오디오는 계속 재생합니다.");
                return;
            }
            // Allow the HTML player to really start before releasing native playback.
            audioHandler.postDelayed(() -> webView.evaluateJavascript(PLAYBACK_PROBE_JS, result -> {
                try {
                    Object o = new JSONTokener(result).nextValue();
                    boolean playing = o instanceof String && new JSONObject((String)o).optBoolean("playing", false);
                    if (!playing) {
                        toast("웹 영상 재생이 차단되었습니다. 독립 오디오는 유지합니다.");
                        return;
                    }
                    nativeAudioActive = false;
                    nativeHandoffRequested = false;
                    lastKnownPlaying = false;
                    updateReturnToVideoButton();
                    try { startService(new Intent(this, BackgroundAudioService.class)
                            .setAction(BackgroundAudioService.ACTION_NATIVE_STOP)); }
                    catch (RuntimeException ignored) { }
                    reportPlayerState(true, lastMediaTitle);
                } catch (Exception ignored) { toast("영상 재생 상태 확인 실패"); }
            }), 900L);
        });
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 122);
        }
    }

    private void showAudioSettings() {
        new AlertDialog.Builder(this)
                .setTitle("백그라운드 음악")
                .setMessage("영상을 재생 중일 때 독립 오디오 스트림을 미리 준비하고, 홈 버튼을 누르면 영상 위치를 이어받아 독립 오디오 엔진으로 전환을 시도합니다. 알림창 재생/일시정지는 독립 플레이어에 직접 전달합니다. 앱으로 돌아오면 '영상 복귀'를 눌러 이어볼 수 있습니다.\n\n유튜브의 스트림 제공 방식이 변경되거나 일부 영상에 접근 제한이 있으면 연결이 실패할 수 있습니다. 시작 전 PIP 자동 전환을 꺼 주세요.")
                .setPositiveButton(backgroundAudio ? "백그라운드 끄기" : "백그라운드 켜기", (d, w) -> {
                    backgroundAudio = !backgroundAudio;
                    settings.edit().putBoolean(KEY_BACKGROUND, backgroundAudio).apply();
                    if (!backgroundAudio) stopBackgroundService();
                    else {
                        requestNotificationPermission();
                        if (lastKnownPlaying) {
                            lastKnownPlaying = false;
                            reportPlayerState(true, lastMediaTitle);
                        }
                    }
                    updateStatus();
                })
                .setNeutralButton("재생 진단", (d, w) -> showAudioDiagnostics())
                .setNegativeButton("닫기", null)
                .show();
    }

    private void showAudioDiagnostics() {
        SharedPreferences d = getSharedPreferences("mht_audio_diagnostics", MODE_PRIVATE);
        String stage = d.getString("stage", "기록 없음");
        String reason = d.getString("reason", "아직 네이티브 재생 결과 없음");
        String last = lastNativeError.isEmpty() ? reason : lastNativeError;
        new AlertDialog.Builder(this)
                .setTitle("백그라운드 오디오 진단")
                .setMessage("상태: " + stage + "\n상세: " + last +
                        "\n\n독립 스트림 연결이 실패하면 Android 알림만으로 음악을 계속 재생할 수 없습니다. " +
                        "영상 재생 중 홈으로 이동하기 전에 스트림을 미리 준비합니다.")
                .setPositiveButton("닫기", null)
                .setNeutralButton("알림 권한", (d0, w) -> requestNotificationPermission())
                .show();
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (exiting) return;
        if (!autoPip && backgroundAudio && lastKnownPlaying && !nativeAudioActive)
            beginNativeHandoff();
        if (autoPip && lastKnownPlaying &&
                Build.VERSION.SDK_INT >= 26 &&
                getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            // The Home gesture can pause WebView before evaluateJavascript returns.
            // For this user-initiated Home action, use the already-confirmed playing state
            // and enter native PiP immediately. CSS isolation is applied without navigation.
            if (customView == null && webView != null && !pipEnterJavaScript.isEmpty())
                webView.evaluateJavascript(pipEnterJavaScript, null);
            enterNativePip();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        activityBackgrounded = false;
        playWasActiveOnLeave = false;
        if (webView != null) webView.onResume();
        if (!lastNativeError.isEmpty()) {
            status.setText("오디오 전환 실패 · 음악 설정 → 재생 진단");
        }
    }

    @Override protected void onPause() {
        activityBackgrounded = true;
        // Some Android navigation paths omit onUserLeaveHint; use onPause as fallback.
        if (!exiting && backgroundAudio && !autoPip && lastKnownPlaying &&
                !nativeHandoffRequested && !nativeAudioActive) beginNativeHandoff();
        playWasActiveOnLeave = !exiting && backgroundAudio && lastKnownPlaying;
        attemptedResumeOnLeave = false;
        // The previous v0.1.1 onPause() stopped WebView media as soon as Home was used.
        // Keep the media WebView active while background audio is enabled.
        if (webView != null && (exiting || !backgroundAudio) && !isInPictureInPictureMode()) webView.onPause();
        super.onPause();
        if (playWasActiveOnLeave && !nativeHandoffRequested && !nativeAudioActive)
            audioHandler.postDelayed(this::attemptBackgroundResumptionOnce, 800);
    }

    @Override protected void onDestroy() {
        if (exitConfirmationDialog != null) {
            exitConfirmationDialog.dismiss();
            exitConfirmationDialog = null;
        }
        audioHandler.removeCallbacksAndMessages(null);
        if (pendingWebMicrophoneRequest != null) {
            pendingWebMicrophoneRequest.deny();
            pendingWebMicrophoneRequest = null;
        }
        if (Build.VERSION.SDK_INT >= 33 && systemBackCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);
            systemBackCallback = null;
        }
        if (!nativeAudioActive && !nativeHandoffRequested) stopBackgroundService();
        if (audioReceiverRegistered) {
            unregisterReceiver(audioControlReceiver);
            audioReceiverRegistered = false;
        }
        if (webView != null) {
            browserContainer.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
