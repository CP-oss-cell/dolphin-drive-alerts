package app.mideumhanatube.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import androidx.media3.common.MediaItem;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hosts an independent Media3 ExoPlayer for background audio. The WebView is
 * used only while on-screen; on Home, we request a separate stream and seek
 * to the last known video time. Stream availability is not guaranteed.
 */
public final class BackgroundAudioService extends Service {
    public static final String ACTION_NATIVE_START = "app.mideumhanatube.android.native.START";
    public static final String ACTION_NATIVE_READY = "app.mideumhanatube.android.native.READY";
    public static final String ACTION_NATIVE_FAILURE = "app.mideumhanatube.android.native.FAIL";
    public static final String ACTION_NATIVE_RETURN = "app.mideumhanatube.android.native.RETURN";
    public static final String ACTION_NATIVE_POSITION = "app.mideumhanatube.android.native.POSITION";
    public static final String ACTION_NATIVE_STOP = "app.mideumhanatube.android.native.STOP";
    public static final String ACTION_NATIVE_QUERY = "app.mideumhanatube.android.native.QUERY";
    public static final String EXTRA_MEDIA_URL = "media_url";
    public static final String EXTRA_POSITION_MS = "position_ms";
    public static final String EXTRA_KIND = "stream_kind";
    public static final String ACTION_UPDATE = "app.mideumhanatube.android.media.UPDATE";
    public static final String ACTION_PLAY = "app.mideumhanatube.android.media.PLAY";
    public static final String ACTION_PAUSE = "app.mideumhanatube.android.media.PAUSE";
    public static final String ACTION_STOP = "app.mideumhanatube.android.media.STOP";
    public static final String ACTION_CONTROL = "app.mideumhanatube.android.media.CONTROL";
    public static final String ACTION_FEEDBACK = "app.mideumhanatube.android.media.FEEDBACK";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_PLAYING = "playing";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_CONTROL = "control";
    private static final String CHANNEL_ID = "mht_background_audio";
    private static final int NOTIFICATION_ID = 1002;
    private static final long PAUSED_TIMEOUT_MS = 120_000L;

    // Java field initializers run in declaration order. State referenced from
    // stopWhenPaused must be declared before its lambda initializer.
    private boolean playing;
    private static volatile boolean nativeSessionExists;
    public static boolean hasNativeAudioSession() { return nativeSessionExists; }
    private boolean nativePreparing;
    private boolean nativeMode;
    // Prepare the same stream while the Activity is still foreground and playing;
    // on Home the player can start without waiting for a new extractor request.
    private String prefetchedUrl;
    private YouTubeStreamResolver.Result prefetchedStream;
    private boolean prefetchRunning;
    private int prefetchGeneration;
    private long prefetchedAtMs;
    private String activeNativeUrl;
    private long activeNativeStartMs;
    private String prefetchError = "";
    private final Runnable nativeTransitionTimeout = () -> {
        if (nativeMode && nativePreparing) failNative("오디오 전환 시간 초과 (40초). 음악 설정의 재생 진단을 확인하세요.");
    };
    private static final long PREFETCH_TTL_MS = 180_000L;
    private int nativeGeneration;
    private final ExecutorService extractionWorker = Executors.newSingleThreadExecutor();
    private ExoPlayer nativePlayer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stopWhenPaused = () -> {
        if (!playing) stopSelf();
    };
    private MediaSession session;
    private PowerManager.WakeLock wakeLock;
    private String title = "믿음하나튜브";
    private String playbackMessage = "재생 상태 확인 중";
    private boolean awaitingPlaybackConfirmation;
    private final Runnable noPlayerResponse = () -> {
        if (awaitingPlaybackConfirmation) {
            awaitingPlaybackConfirmation = false;
            playbackMessage = "웹 플레이어의 재생 응답 없음. 앱 화면을 확인하세요.";
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "백그라운드 음악 재생",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("믿음하나튜브가 음악을 재생할 때 표시합니다.");
            channel.setSound(null, null);
            nm.createNotificationChannel(channel);
        }
        session = new MediaSession(this, "MideumHanaTubeBackgroundAudio");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { requestPlayerControl(ACTION_PLAY); }
            @Override public void onPause() { requestPlayerControl(ACTION_PAUSE); }
            @Override public void onStop() { relay(ACTION_STOP); stopSelf(); }
        });
        session.setActive(true);
        nativePlayer = new ExoPlayer.Builder(this).build();
        // Unlike the WebView-owned player, the service explicitly manages media
        // audio focus so it can retain playback when Chrome/WebView is paused.
        nativePlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(), true);
        nativePlayer.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                if (!nativeMode || nativePreparing) return;
                playing = isPlaying;
                playbackMessage = isPlaying ? "독립 오디오 재생 중" : "독립 오디오 일시중지";
                updateSessionAndNotification();
                if (isPlaying) {
                    nativeSessionExists = true;
                    noteAudioStage("재생 성공", "독립 오디오 엔진 동작 중");
                    sendNativeState(ACTION_NATIVE_READY, null, nativePlayer.getCurrentPosition());
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                if (!nativeMode) return;
                failNative("오디오 스트림 재생 실패: " + error.getErrorCodeName());
            }
        });
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MideumHanaTube:BackgroundAudio");
            wakeLock.setReferenceCounted(false);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            relay(ACTION_STOP);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_NATIVE_START.equals(action)) {
            beginNativeAudio(intent);
        } else if (ACTION_NATIVE_RETURN.equals(action) || ACTION_NATIVE_QUERY.equals(action)) {
            if (nativeMode && !nativePreparing && nativePlayer != null)
                sendNativeState(ACTION_NATIVE_POSITION, null, nativePlayer.getCurrentPosition());
        } else if (ACTION_NATIVE_STOP.equals(action)) {
            stopNativeAudio();
        } else if (ACTION_PLAY.equals(action) || ACTION_PAUSE.equals(action)) {
            requestPlayerControl(action);
        } else if (ACTION_UPDATE.equals(action)) {
            if (nativeMode || nativePreparing) return START_NOT_STICKY;
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            playing = intent.getBooleanExtra(EXTRA_PLAYING, false);
            String nextTitle = intent.getStringExtra(EXTRA_TITLE);
            if (nextTitle != null && !nextTitle.trim().isEmpty()) title = nextTitle;
            playbackMessage = playing ? "영상 재생 중 (음악 전환 준비)" : "재생 일시중지";
            String visiblePageUrl = intent.getStringExtra(EXTRA_MEDIA_URL);
            if (playing && YouTubeStreamResolver.isSupportedVideoUrl(visiblePageUrl))
                prefetchStream(visiblePageUrl, false);
        } else if (ACTION_FEEDBACK.equals(action)) {
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            String error = intent.getStringExtra(EXTRA_ERROR);
            if (error != null && !error.trim().isEmpty()) {
                playing = false;
                playbackMessage = error;
            }
        } else {
            stopSelf();
            return START_NOT_STICKY;
        }
        updateSessionAndNotification();
        return START_NOT_STICKY;
    }

    private void beginNativeAudio(Intent input) {
        String url = input.getStringExtra(EXTRA_MEDIA_URL);
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) {
            failNative("유튜브 영상 주소를 확인하지 못했습니다.");
            return;
        }
        activeNativeUrl = url;
        activeNativeStartMs = Math.max(0L, input.getLongExtra(EXTRA_POSITION_MS, 0L));
        String proposedTitle = input.getStringExtra(EXTRA_TITLE);
        if (proposedTitle != null && !proposedTitle.trim().isEmpty()) title = proposedTitle;
        nativePreparing = true;
        nativeMode = true;
        awaitingPlaybackConfirmation = false;
        handler.removeCallbacks(noPlayerResponse);
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.postDelayed(nativeTransitionTimeout, 40_000L);
        playing = true; // maintain the foreground notification while resolving URL
        playbackMessage = "독립 오디오 전환 중…";
        noteAudioStage("오디오 전환 요청", "영상 주소 확인 완료, 독립 오디오 시작 대기");
        updateSessionAndNotification();
        if (isValidPrefetchedStream(url)) {
            startResolvedAudio(prefetchedStream);
        } else if (!prefetchRunning || !url.equals(prefetchedUrl)) {
            // Cached lookup failed earlier, or the page changed: retry once on Home.
            prefetchStream(url, true);
        }
        // If the exact URL is already being prefetched, its completion callback
        // will call startResolvedAudio, avoiding two network requests.
    }

    private boolean isValidPrefetchedStream(String url) {
        return url != null && url.equals(prefetchedUrl) && prefetchedStream != null &&
                android.os.SystemClock.elapsedRealtime() - prefetchedAtMs < PREFETCH_TTL_MS;
    }

    /** Prepares the stream address asynchronously WHILE viewing the video.
     * Does not pause, restart, or seek the current WebView player.
     */
    private void prefetchStream(String url, boolean force) {
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) return;
        if (!force && (isValidPrefetchedStream(url) ||
                (prefetchRunning && url.equals(prefetchedUrl)))) return;
        final int generation = ++prefetchGeneration;
        prefetchedUrl = url;
        prefetchedStream = null;
        prefetchRunning = true;
        prefetchError = "";
        noteAudioStage("스트림 미리 준비 중", "재생 중 연결 주소를 확인하는 중");
        extractionWorker.execute(() -> {
            try {
                YouTubeStreamResolver.Result info = YouTubeStreamResolver.resolve(url);
                handler.post(() -> {
                    if (generation != prefetchGeneration) return;
                    prefetchRunning = false;
                    prefetchedStream = info;
                    prefetchedAtMs = android.os.SystemClock.elapsedRealtime();
                    prefetchError = "";
                    noteAudioStage("스트림 준비 완료", "오디오: " + info.streamKind);
                    if (nativeMode && nativePreparing && url.equals(activeNativeUrl))
                        startResolvedAudio(info);
                });
            } catch (Exception | LinkageError error) {
                handler.post(() -> {
                    if (generation != prefetchGeneration) return;
                    prefetchRunning = false;
                    prefetchedStream = null;
                    String reason = error.getMessage();
                    prefetchError = reason == null ? error.getClass().getSimpleName() : reason;
                    noteAudioStage("스트림 연결 실패", prefetchError);
                    if (nativeMode && nativePreparing && url.equals(activeNativeUrl))
                        failNative("오디오 주소를 얻지 못했습니다: " + prefetchError);
                });
            }
        });
    }

    private void startResolvedAudio(YouTubeStreamResolver.Result result) {
        if (!nativeMode || !nativePreparing || nativePlayer == null) return;
        handler.removeCallbacks(nativeTransitionTimeout);
        nativePreparing = false;
        title = result.title == null || result.title.isEmpty() ? title : result.title;
        playbackMessage = "독립 오디오 버퍼링 중… (" + result.streamKind + ")";
        noteAudioStage("오디오 버퍼링 중", "스트림 주소 확인 성공");
        try {
            nativePlayer.setMediaItem(MediaItem.fromUri(result.streamUrl));
            nativePlayer.prepare();
            nativePlayer.seekTo(activeNativeStartMs);
            nativePlayer.play();
            updateSessionAndNotification();
        } catch (RuntimeException error) {
            failNative("오디오 플레이어 시작 실패: " + error.getClass().getSimpleName());
        }
    }

    private void noteAudioStage(String stage, String reason) {
        getSharedPreferences("mht_audio_diagnostics", MODE_PRIVATE).edit()
                .putString("stage", stage)
                .putString("reason", reason)
                .putLong("timestamp", System.currentTimeMillis())
                .apply();
    }

    private void failNative(String message) {
        handler.removeCallbacks(nativeTransitionTimeout);
        noteAudioStage("전환 실패", message);
        ++nativeGeneration;
        nativeMode = false;
        nativePreparing = false;
        nativeSessionExists = false;
        playing = false;
        if (nativePlayer != null) nativePlayer.stop();
        playbackMessage = message;
        updateSessionAndNotification();
        sendNativeState(ACTION_NATIVE_FAILURE, message, 0L);
    }

    private void stopNativeAudio() {
        handler.removeCallbacks(nativeTransitionTimeout);
        ++nativeGeneration;
        nativeMode = false;
        nativePreparing = false;
        nativeSessionExists = false;
        if (nativePlayer != null) { nativePlayer.stop(); nativePlayer.clearMediaItems(); }
        playing = false;
        playbackMessage = "영상 플레이어로 전환됨";
        updateSessionAndNotification();
    }

    private void sendNativeState(String action, String message, long position) {
        Intent result = new Intent(action);
        result.setPackage(getPackageName());
        result.putExtra(EXTRA_POSITION_MS, Math.max(0L, position));
        if (message != null) result.putExtra(EXTRA_ERROR, message);
        sendBroadcast(result);
    }

    private void requestPlayerControl(String action) {
        // While in native mode, controls operate on the real ExoPlayer, not WebView.
        if (nativeMode && nativePlayer != null) {
            if (ACTION_PLAY.equals(action)) nativePlayer.play();
            else nativePlayer.pause();
            return;
        }
        // The old WebView path only remains for ordinary on-screen viewing.
        awaitingPlaybackConfirmation = true;
        playbackMessage = "웹 플레이어 응답 확인 중";
        relay(action);
        handler.removeCallbacks(noPlayerResponse);
        handler.postDelayed(noPlayerResponse, 1800L);
    }

    private void relay(String action) {
        Intent message = new Intent(ACTION_CONTROL);
        message.setPackage(getPackageName());
        message.putExtra(EXTRA_CONTROL, action);
        sendBroadcast(message);
    }

    private void updateSessionAndNotification() {
        long available = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_PLAY_PAUSE;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(available)
                .setState(nativePreparing ? PlaybackState.STATE_BUFFERING :
                        (playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED),
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? 1f : 0f)
                .build());
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "믿음하나튜브")
                .build());
        Notification notification = buildNotification();
        // Start/refresh foreground state in response to active, user-initiated playback.
        if (playing) {
            handler.removeCallbacks(stopWhenPaused);
            try {
                startForeground(NOTIFICATION_ID, notification);
            } catch (RuntimeException e) {
                // Foreground start may be denied by newer Android background-start limits.
                stopSelf();
                return;
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        } else {
            releaseWakeLock();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, notification);
            handler.removeCallbacks(stopWhenPaused);
            handler.postDelayed(stopWhenPaused, PAUSED_TIMEOUT_MS);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 100, openIntent, flags());
        String controlAction = playing ? ACTION_PAUSE : ACTION_PLAY;
        int controlIcon = playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String controlLabel = playing ? "일시중지" : "재생";
        Notification.Action toggle = new Notification.Action.Builder(
                controlIcon, controlLabel, servicePending(controlAction, 101)).build();
        Notification.Action stop = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "종료", servicePending(ACTION_STOP, 102)).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(playbackMessage)
                .setContentIntent(openPending)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(toggle)
                .addAction(stop)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0))
                .build();
    }

    private PendingIntent servicePending(String action, int id) {
        return PendingIntent.getService(this, id,
                new Intent(this, BackgroundAudioService.class).setAction(action), flags());
    }

    private static int flags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    @Override public void onDestroy() {
        nativeSessionExists = false;
        ++nativeGeneration;
        extractionWorker.shutdownNow();
        if (nativePlayer != null) { nativePlayer.release(); nativePlayer = null; }
        handler.removeCallbacks(stopWhenPaused);
        handler.removeCallbacks(noPlayerResponse);
        handler.removeCallbacks(nativeTransitionTimeout);
        releaseWakeLock();
        if (session != null) { session.setActive(false); session.release(); session = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
