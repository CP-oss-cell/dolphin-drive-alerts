package com.dolphin.clusterprobe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.*;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

/**
 * Vehicle-only trial: center-display UI + explicit local ADB RSA auth for read-only diagnosis
 * + user-confirmed APK updates via system Package Installer, without connecting a PC.
 * Does NOT modify the OEM cluster, send CAN messages, use root, or install silently.
 */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 15, 27), FG = Color.rgb(239, 247, 255);
    private static final int REQ_APK = 101, REQ_UNKNOWN_SOURCES = 102;
    private LinearLayout body;
    private WebView web;
    private String lastAdbResult = "아직 로컬 ADB 인증을 시도하지 않았습니다.\n";
    private String lastReport;
    private boolean updateValidated = false, waitingSettings = false;
    private boolean activityDestroyed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        TextView banner = new TextView(this);
        banner.setText("돌핀 계기판 V1.2 · 차량 단독 시험 · 순정 5인치 화면 변경 없음");
        banner.setTextColor(Color.rgb(255, 210, 136)); banner.setGravity(Gravity.CENTER);
        banner.setPadding(dp(6), dp(7), dp(6), dp(7)); banner.setTextSize(13);
        root.addView(banner, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row1 = row(root);
        Button preview = button(row1, "테마 시연");
        Button info = button(row1, "차량 정보");
        Button adb = button(row1, "로컬 ADB 연결·승인");
        LinearLayout row2 = row(root);
        Button setup = button(row2, "설치 권한 확인");
        Button install = button(row2, "APK 선택·업데이트");
        Button share = button(row2, "진단 결과 공유");
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        preview.setOnClickListener(v -> showPreview());
        info.setOnClickListener(v -> showInfo());
        adb.setOnClickListener(v -> adbDiagnostic());
        setup.setOnClickListener(v -> showInstallPermissions());
        install.setOnClickListener(v -> chooseUpdate());
        share.setOnClickListener(v -> shareReport());
        showSetupText();
    }
    private LinearLayout row(LinearLayout root) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(5), 0, dp(5), dp(2)); root.addView(row); return row;
    }
    private Button button(LinearLayout row, String text) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(11);
        row.addView(b, new LinearLayout.LayoutParams(0, dp(45), 1)); return b;
    }
    private void clearBody() {
        if(web!=null) { web.stopLoading(); body.removeView(web); web.destroy(); web=null; }
        body.removeAllViews();
    }
    private void showText(String content) {
        clearBody(); ScrollView scroll=new ScrollView(this); TextView text=new TextView(this);
        text.setText(content); text.setTextColor(FG); text.setTextIsSelectable(true); text.setTextSize(15);
        text.setPadding(dp(19), dp(12), dp(19), dp(22)); scroll.addView(text);
        body.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
    }
    private void showSetupText() {
        showText("차량 단독 사용 안내\n\n"
            + "① 첫 설치: USB나 차량 다운로드 폴더의 V1.2 APK를 차량 파일 관리자로 한 번 엽니다.\n"
            + "② 앱에서 '로컬 ADB 연결·승인'을 눌러 127.0.0.1:5555를 검사합니다.\n"
            + "③ ADB가 활성화되어 있으면 차량에 뜨는 RSA 승인창에서 직접 허용합니다.\n"
            + "④ '테마 시연'으로 센터 화면에만 새 디자인을 표시합니다.\n"
            + "⑤ 다음 버전부터 'APK 선택·업데이트'에서 새 APK를 선택하고 설치를 승인합니다.\n\n"
            + "APK 설치는 Android Package Installer 방식입니다. ADB 연결이 실패해도 이 기능은 별개로 작동할 수 있습니다.\n"
            + "앱이 ADB를 임의로 켜거나 시스템/계기판 쓰기 권한을 자동 획득할 수는 없습니다.\n");
    }
    private void showPreview() {
        clearBody(); web=new WebView(this); web.setBackgroundColor(BG);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true); s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return true; }
        });
        body.addView(web, new LinearLayout.LayoutParams(-1, -1));
        web.loadUrl("file:///android_asset/cluster_preview.html");
    }
    private void showInfo() { lastReport=diagnosticText(); showText(lastReport); }
    private String diagnosticText() {
        StringBuilder out=new StringBuilder();
        out.append("Dolphin Cluster V1.2 — CENTER ONLY / READ-ONLY\n");
        out.append("실제 계기판 테마 변경/ADB 시스템권한 획득/차량 신호 송신 없음\n\n");
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" / SDK ").append(Build.VERSION.SDK_INT).append("\n");
        out.append("Model: ").append(Build.MODEL).append("\nBuild fingerprint: ").append(Build.FINGERPRINT).append("\n");
        for(String name:new String[]{"ro.build.system.fission_single_os", "ro.vehicle.type", "ro.build.version.release"})
            out.append(name).append(": ").append(readProperty(name)).append("\n");
        DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
        out.append("\n앱에서 열람 가능한 디스플레이 목록:\n");
        for(Display d:dm.getDisplays()) {
            DisplayMetrics m=new DisplayMetrics(); d.getRealMetrics(m);
            out.append("id=").append(d.getDisplayId()).append(" name=").append(d.getName())
                .append(" size=").append(m.widthPixels).append("x").append(m.heightPixels)
                .append(" dpi=").append(m.densityDpi).append("\n");
        }
        out.append("\n설치 요청 허용: ").append(getPackageManager().canRequestPackageInstalls()).append("\n");
        out.append("\n로컬 ADB 결과:\n").append(lastAdbResult);
        out.append("\n결과 공유 전 개인 식별 가능 정보는 검토하세요.\n");
        return out.toString();
    }
    private String readProperty(String name) {
        Process p=null;
        try { p=new ProcessBuilder("getprop", name).redirectErrorStream(true).start();
            if(!p.waitFor(900, TimeUnit.MILLISECONDS)) {p.destroyForcibly();return "TIMEOUT";}
            try(BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String text=r.readLine(); return text==null || text.trim().isEmpty()?"UNAVAILABLE":text.trim();
            }
        } catch(Exception e) {return "UNAVAILABLE("+e.getClass().getSimpleName()+")";}
        finally {if(p!=null)p.destroy();}
    }
    private void adbDiagnostic() {
        showText("로컬 ADB 인증 중… 차량 화면에 승인창이 나타나면 '허용'을 선택하세요.\n\n"
            + "이 연결은 차량 내부(127.0.0.1:5555)로만 시도합니다. 실패하면 화면에 원인을 표시합니다.\n");
        new Thread(() -> {
            String result;
            try(LocalAdb client=new LocalAdb(getFilesDir())) {
                result = client.checkAndRead(this::postStatus);
                lastAdbResult="ADB_CONNECTED_AND_AUTHORIZED\n"+result;
            } catch(Exception e) {
                lastAdbResult="ADB_UNAVAILABLE_OR_DENIED\n"+e.getClass().getSimpleName()+": "+e.getMessage()
                    +"\n확인: 차량의 개발자/ADB 기능, 5555 개방 상태, 인증 승인 여부.\n"
                    +"ADB가 연결되지 않아도 APK 업데이트 설치는 별도로 가능합니다.\n";
            }
            lastReport=diagnosticText();
            runOnUiThread(() -> { if(!activityDestroyed) showText(lastReport); });
        }, "local-adb-readonly").start();
    }
    private void postStatus(String state) {
        runOnUiThread(() -> { if(!activityDestroyed) showText(state+"\n\n승인창이 없으면 ADB 서버 활성화 여부를 확인하세요."); });
    }
    private void showInstallPermissions() {
        String details="설치 기능: 동일 패키지(com.dolphin.clusterprobe) 업데이트 전용\n\n"
            +"Android 설치 요청 권한: "+ (getPackageManager().canRequestPackageInstalls()?"허용":"미허용")+"\n"
            +"로컬 ADB 연결은 APK 설치에 필요하지 않습니다.\n"
            +"설치할 APK는 Android 시스템에서 사용자 승인을 받아야 합니다.\n"
            +"APK 서명키가 현재 버전과 다르거나 버전이 낮으면 업데이트가 실패합니다.\n"
            +"현재 앱은 펌웨어 파일 변경·자동 설치·OEM 계기판 권한을 포함하지 않습니다.";
        new AlertDialog.Builder(this).setTitle("APK 설치 권한")
            .setMessage(details)
            .setPositiveButton("설치 설정 열기", (d,w)->openInstallSettings())
            .setNegativeButton("닫기",null).show();
    }
    private void chooseUpdate() {
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("*/*");
        try {startActivityForResult(pick,REQ_APK);} catch(Exception ex) {showText("APK 파일 선택기를 열 수 없습니다: "+ex.getMessage());}
    }
    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==REQ_APK && result==RESULT_OK && data!=null && data.getData()!=null) processApk(data.getData());
        if(req==REQ_UNKNOWN_SOURCES) {
            waitingSettings=false;
            if(updateValidated && getPackageManager().canRequestPackageInstalls()) launchInstaller();
            else showInstallPermissions();
        }
    }
    private void processApk(Uri uri) {
        showText("선택한 APK 확인 중… 패키지명·버전·크기 검증 후 설치 여부를 안내합니다.");
        new Thread(() -> {
            try {
                File file=new File(getCacheDir(),"candidate.apk");
                try(InputStream source=getContentResolver().openInputStream(uri);
                    OutputStream out=new FileOutputStream(file)) {
                    if(source==null) throw new IOException("APK 입력 파일을 열 수 없습니다");
                    byte[] buffer=new byte[16384]; long total=0; int count;
                    while((count=source.read(buffer))!=-1) {
                        total+=count; if(total>150L*1024*1024) throw new IOException("APK 150MB 초과");
                        out.write(buffer,0,count);
                    }
                }
                PackageInfo apk=getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),0);
                if(apk==null) throw new IOException("유효한 APK 파일이 아닙니다");
                if(!getPackageName().equals(apk.packageName)) throw new IOException("다른 앱의 APK입니다: "+apk.packageName);
                PackageInfo current=getPackageManager().getPackageInfo(getPackageName(),0);
                long newCode=Build.VERSION.SDK_INT>=28?apk.getLongVersionCode():apk.versionCode;
                long oldCode=Build.VERSION.SDK_INT>=28?current.getLongVersionCode():current.versionCode;
                if(newCode<oldCode) throw new IOException("낮은 버전은 설치할 수 없습니다. 현재="+oldCode+" 선택="+newCode);
                String hash=sha256(file); updateValidated=true;
                runOnUiThread(() -> {
                    if(activityDestroyed) return;
                    new AlertDialog.Builder(this).setTitle("업데이트 APK 확인")
                        .setMessage("패키지: "+apk.packageName+"\n버전코드: "+newCode
                            +"\nSHA-256: "+hash+"\n\nAndroid 시스템 설치 화면을 열까요?\n"
                            +"※ 현재 앱과 동일한 서명키여야 설치됩니다. 새로운 빌드에서 서명키가 바뀌면 실패합니다.")
                        .setPositiveButton("설치 진행",(d,w)->beginInstall())
                        .setNegativeButton("취소",(d,w)->{updateValidated=false;})
                        .show();
                });
            } catch(Exception ex) {
                updateValidated=false;
                runOnUiThread(() -> {if(!activityDestroyed) showText("APK 확인 실패: "+ex.getMessage());});
            }
        },"verify-same-app-apk").start();
    }
    private static String sha256(File f) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(f)) {byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)digest.update(b,0,n);}
        StringBuilder sb=new StringBuilder();for(byte b:digest.digest())sb.append(String.format(java.util.Locale.ROOT,"%02x",b & 0xff));return sb.toString();
    }
    private void beginInstall() {
        if(!updateValidated) {showText("먼저 APK를 선택하고 확인하세요.");return;}
        if(!getPackageManager().canRequestPackageInstalls()) {openInstallSettings();return;}
        launchInstaller();
    }
    private void openInstallSettings() {
        waitingSettings=true;
        Intent settings=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:"+getPackageName()));
        try {startActivityForResult(settings,REQ_UNKNOWN_SOURCES);}
        catch(Exception ex) {waitingSettings=false;showText("차량 설정에서 '이 앱에서 설치 허용'을 찾을 수 없습니다: "+ex.getMessage());}
    }
    private void launchInstaller() {
        if(!updateValidated) return;
        updateValidated=false; waitingSettings=false;
        Intent installer=new Intent(Intent.ACTION_INSTALL_PACKAGE);
        installer.setDataAndType(ApkFileProvider.APK_URI,"application/vnd.android.package-archive");
        installer.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {startActivity(installer);showText("Android APK 설치창을 실행했습니다.\n\n시스템 설치 안내를 따라 승인하세요.\n"
                +"업데이트가 실패하면 서명키 불일치/정책 차단/버전 문제를 확인하세요.\n"
                +"앱은 설치 성공을 임의로 선언하지 않습니다.");}
        catch(Exception e){showText("차량에서 Android 패키지 설치 화면을 열지 못했습니다: "+e.getMessage());}
    }
    private void shareReport() {
        lastReport=diagnosticText(); Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT,lastReport);
        try {startActivity(Intent.createChooser(share,"진단 결과 공유(민감정보 확인 후)"));}
        catch(Exception ex) {showText("공유 실패: "+ex.getMessage()+"\n\n"+lastReport);}
    }
    private int dp(int x) {return Math.round(x*getResources().getDisplayMetrics().density);}
    @Override protected void onDestroy() {activityDestroyed=true;clearBody();super.onDestroy();}
}
