package com.dolphin.clusterprobe;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/** Shares ONE user-selected and validated same-package update with Android's installer. */
public final class ApkFileProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dolphin.clusterprobe.updates";
    public static final Uri APK_URI = Uri.parse("content://" + AUTHORITY + "/candidate.apk");
    private File allowedFile(Uri uri) throws FileNotFoundException {
        if (!APK_URI.equals(uri)) throw new FileNotFoundException("Invalid update URI");
        File f = new File(getContext().getCacheDir(), "candidate.apk");
        if (!f.isFile() || !f.canRead()) throw new FileNotFoundException("No selected update");
        return f;
    }
    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) { return "application/vnd.android.package-archive"; }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read-only provider");
        return ParcelFileDescriptor.open(allowedFile(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File file=allowedFile(uri);
            String[] columns=projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
            MatrixCursor c = new MatrixCursor(columns);
            Object[] row=new Object[columns.length];
            for(int i=0;i<columns.length;i++) {
                if(OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i]="DolphinCluster-update.apk";
                if(OpenableColumns.SIZE.equals(columns[i])) row[i]=file.length();
            }
            c.addRow(row); return c;
        } catch (FileNotFoundException e) { return null; }
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
}
