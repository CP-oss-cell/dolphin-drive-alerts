package com.dolphin.clusterprobe;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import javax.crypto.Cipher;

/**
 * Small, local-only (127.0.0.1:5555), opt-in ADB client for read-only diagnosis.
 * Implements legacy CNXN / AUTH (RSA 2048) / shell protocol without native binaries,
 * root or a PC. No general shell interface and no write/pm/cmd operations.
 * Requires adbd already enabled and user confirmation on vehicle if requested.
 */
public final class LocalAdb implements Closeable {
    private static final int CNXN = 0x4e584e43, AUTH = 0x48545541;
    private static final int OPEN = 0x4e45504f, OKAY = 0x59414b4f;
    private static final int WRTE = 0x45545257, CLSE = 0x45534c43;
    private static final int STLS = 0x534c5453;
    private static final int MAX_PACKET = 256 * 1024;
    private static final byte[] SHA1_INFO = hex("3021300906052b0e03021a05000414");

    public interface Status { void onStatus(String state); }
    private final File privateFolder;
    private Socket socket;
    private DataInputStream input;
    private OutputStream output;
    private int streamId = 1;

    public LocalAdb(File privateFolder) { this.privateFolder = privateFolder; }

    public String checkAndRead(Status status) throws Exception {
        status.onStatus("차량 내부 ADB 포트(127.0.0.1:5555) 연결 중…");
        socket = new Socket();
        // Intentionally never connect to a host outside this same device.
        socket.connect(new InetSocketAddress("127.0.0.1", 5555), 2500);
        socket.setSoTimeout(25000); // allow user to confirm device-local RSA dialog
        input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        output = socket.getOutputStream();
        writePacket(CNXN, 0x01000000, 4096, "host::\0".getBytes(StandardCharsets.UTF_8));
        KeyPair pair = loadOrCreateKey();
        boolean signed = false, shared = false, connected = false;
        for (int i = 0; i < 12; i++) {
            Packet p = readPacket();
            if (p.cmd == CNXN) { connected = true; break; }
            if (p.cmd == STLS) throw new IOException("이 장치는 ADB TLS 연결을 요구합니다. 기존 로컬 5555 방식 불가");
            if (p.cmd != AUTH || p.arg0 != 1) throw new IOException("예상하지 못한 ADB 응답: " + Integer.toHexString(p.cmd));
            if (!signed) {
                status.onStatus("기존 ADB 인증키 확인 중…");
                byte[] sig = signChallenge(pair.getPrivate(), p.data);
                writePacket(AUTH, 2, 0, sig);
                signed = true;
            } else if (!shared) {
                status.onStatus("차량에 ADB 승인창이 나타나면 '허용'을 선택하세요 (한 번만 확인)");
                byte[] publicKey = adbPublicKey((java.security.interfaces.RSAPublicKey) pair.getPublic());
                String printable = Base64.getEncoder().encodeToString(publicKey) + " dolphin-cluster@vehicle\0";
                writePacket(AUTH, 3, 0, printable.getBytes(StandardCharsets.UTF_8));
                shared = true;
            } else {
                throw new IOException("ADB 인증 대기/거부. 차량 화면의 승인 여부를 확인하세요");
            }
        }
        if (!connected) throw new IOException("ADB 인증 성공 응답(CNXN)을 받지 못했습니다");
        status.onStatus("로컬 ADB 인증 성공. 읽기 전용 조회 중…");
        StringBuilder result = new StringBuilder();
        for (String[] item : new String[][] {
            {"시스템 분할 구조", "getprop ro.build.system.fission_single_os"},
            {"계기판 크기 식별", "cat /sys/module/max96745/parameters/clu_size"},
            {"순정 테마 파일 목록", "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc"}
        }) {
            result.append("\n[ ").append(item[0]).append(" ]\n");
            try { result.append(shellReadOnly(item[1])); }
            catch(Exception ex) { result.append("조회 실패: ").append(ex.getMessage()).append("\n"); }
        }
        result.append("\n※ adbd 셸 결과는 접근 가능 여부를 의미하며 계기판 화면 변경 허가가 아닙니다.\n");
        return result.toString();
    }

    private String shellReadOnly(String command) throws Exception {
        // hard allowlist. Any unknown command is rejected before touching adbd.
        Set<String> allowed = new HashSet<>(Arrays.asList(
            "getprop ro.build.system.fission_single_os",
            "cat /sys/module/max96745/parameters/clu_size",
            "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc"));
        if (!allowed.contains(command)) throw new SecurityException("허용되지 않은 진단 명령");
        int id = streamId++;
        byte[] commandBytes = ("shell:" + command + "\0").getBytes(StandardCharsets.UTF_8);
        writePacket(OPEN, id, 0, commandBytes);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int remote = -1;
        long deadline = System.currentTimeMillis() + 7000;
        while (System.currentTimeMillis() < deadline) {
            Packet p = readPacket();
            if (p.cmd == OKAY && p.arg1 == id) { remote = p.arg0; continue; }
            if (p.cmd == WRTE && p.arg1 == id) {
                remote = p.arg0;
                if (buffer.size() + p.data.length > 32768) throw new IOException("진단 출력 제한 초과");
                buffer.write(p.data);
                writePacket(OKAY, id, remote, new byte[0]);
                continue;
            }
            if (p.cmd == CLSE && p.arg1 == id) {
                writePacket(CLSE, id, p.arg0, new byte[0]);
                return buffer.toString("UTF-8");
            }
        }
        if (remote != -1) writePacket(CLSE, id, remote, new byte[0]);
        return buffer.toString("UTF-8") + "\n(TIMEOUT)\n";
    }

    private static final class Packet {
        int cmd, arg0, arg1; byte[] data;
    }
    private Packet readPacket() throws IOException {
        byte[] h = new byte[24]; input.readFully(h);
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Packet p = new Packet(); p.cmd = b.getInt(); p.arg0 = b.getInt(); p.arg1 = b.getInt();
        int length = b.getInt(), checksum = b.getInt(), magic = b.getInt();
        if ((p.cmd ^ -1) != magic || length < 0 || length > MAX_PACKET) throw new IOException("유효하지 않은 ADB 패킷");
        p.data = new byte[length]; input.readFully(p.data);
        int sum = 0; for(byte value:p.data) sum += value & 0xff;
        if (checksum != 0 && sum != checksum) throw new IOException("ADB 패킷 체크섬 불일치");
        return p;
    }
    private void writePacket(int cmd, int arg0, int arg1, byte[] bytes) throws IOException {
        int sum = 0; for(byte value:bytes) sum += value & 0xff;
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(cmd).putInt(arg0).putInt(arg1).putInt(bytes.length).putInt(sum).putInt(cmd ^ -1);
        output.write(b.array()); output.write(bytes); output.flush();
    }

    private KeyPair loadOrCreateKey() throws Exception {
        File privateFile = new File(privateFolder, "adb_probe_private.key");
        File publicFile = new File(privateFolder, "adb_probe_public.key");
        KeyFactory factory = KeyFactory.getInstance("RSA");
        if (privateFile.isFile() && publicFile.isFile()) {
            PrivateKey privateKey = factory.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(privateFile.toPath())));
            PublicKey publicKey = factory.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(publicFile.toPath())));
            return new KeyPair(publicKey, privateKey);
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, new SecureRandom());
        KeyPair pair = gen.generateKeyPair();
        try(FileOutputStream f = new FileOutputStream(privateFile)) { f.write(pair.getPrivate().getEncoded()); }
        try(FileOutputStream f = new FileOutputStream(publicFile)) { f.write(pair.getPublic().getEncoded()); }
        privateFile.setReadable(false, false); privateFile.setReadable(true, true);
        privateFile.setWritable(false, false); privateFile.setWritable(true, true);
        return pair;
    }
    private static byte[] signChallenge(PrivateKey key, byte[] token) throws Exception {
        if (token.length != 20) throw new IOException("지원되지 않는 ADB 인증 토큰 길이");
        byte[] der = new byte[SHA1_INFO.length + token.length];
        System.arraycopy(SHA1_INFO, 0, der, 0, SHA1_INFO.length);
        System.arraycopy(token, 0, der, SHA1_INFO.length, token.length);
        Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        rsa.init(Cipher.ENCRYPT_MODE, key);
        return rsa.doFinal(der);
    }
    private static byte[] adbPublicKey(java.security.interfaces.RSAPublicKey key) {
        BigInteger n = key.getModulus();
        BigInteger rad = BigInteger.ONE.shiftLeft(4096).mod(n);
        BigInteger n0 = n.and(new BigInteger("ffffffff", 16));
        BigInteger n0inv = n0.modInverse(BigInteger.ONE.shiftLeft(32)).negate();
        ByteBuffer data = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN);
        data.putInt(64); data.putInt(n0inv.intValue());
        putLE(data, n, 256); putLE(data, rad, 256); data.putInt(key.getPublicExponent().intValue());
        return data.array();
    }
    private static void putLE(ByteBuffer b, BigInteger x, int bytes) {
        byte[] v = x.toByteArray();
        for(int i=0;i<bytes;i++) b.put(i<v.length ? v[v.length-1-i] : (byte)0);
    }
    private static byte[] hex(String hex){ byte[] v=new byte[hex.length()/2]; for(int i=0;i<v.length;i++) v[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16); return v; }
    @Override public void close() throws IOException { if(socket != null) socket.close(); }
}
