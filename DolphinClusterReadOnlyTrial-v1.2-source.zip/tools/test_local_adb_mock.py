import socket,threading,struct,subprocess,os
CNXN=0x4e584e43; AUTH=0x48545541; OPEN=0x4e45504f;OKAY=0x59414b4f;WRTE=0x45545257;CLSE=0x45534c43

def recvall(s,n):
 data=b''
 while len(data)<n:
  next=s.recv(n-len(data))
  if not next:raise RuntimeError('connection ended')
  data+=next
 return data

def recv(s):
 c,a1,a2,l,ck,magic=struct.unpack('<6I',recvall(s,24)); d=recvall(s,l)
 assert c^0xffffffff==magic;assert ck in (sum(d),0)
 return c,a1,a2,d

def send(s,c,a1=0,a2=0,data=b''):
 s.sendall(struct.pack('<6I',c,a1,a2,len(data),sum(data)&0xffffffff,c^0xffffffff)+data)

def mock():
 with socket.socket() as server:
  server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
  server.bind(('127.0.0.1',5555));server.listen(1)
  ready.set()
  with server.accept()[0] as s:
   s.settimeout(10)
   assert recv(s)[0]==CNXN
   send(s,AUTH,1,0,bytes(range(20)))
   sig=recv(s);assert sig[0]==AUTH and sig[1]==2 and len(sig[3])==256
   send(s,AUTH,1,0,bytes(range(1,21)))
   pub=recv(s);assert pub[0]==AUTH and pub[1]==3
   import base64
   key=base64.b64decode(pub[3].split(b' ')[0]);assert len(key)==524
   modulus=int.from_bytes(key[8:264],'little'); exponent=int.from_bytes(key[520:524],'little')
   decoded=pow(int.from_bytes(sig[3],'big'),exponent,modulus).to_bytes(256,'big')
   expected=bytes.fromhex('3021300906052b0e03021a05000414')+bytes(range(20))
   assert decoded.startswith(b'\x00\x01\xff') and decoded.endswith(expected), 'RSA ADB authentication signature invalid'
   send(s,CNXN,0x1000000,4096,b'device::\0')
   for i in range(3):
    c,a1,a2,data=recv(s);assert c==OPEN;assert data.startswith(b'shell:')
    send(s,OKAY,10+i,a1,b'')
    send(s,WRTE,10+i,a1,b'OK_MOCK_'+str(i).encode()+b'\n')
    assert recv(s)[0]==OKAY
    send(s,CLSE,10+i,a1,b'')
    assert recv(s)[0]==CLSE

ready=threading.Event();t=threading.Thread(target=mock,daemon=True);t.start();assert ready.wait(5)
cp='app/src/main/java/com/dolphin/clusterprobe/LocalAdb.java'
subprocess.run(['javac','-d','/tmp/adbjavac',cp,'tools/TestLocalAdb.java'],check=True)
p=subprocess.run(['java','-cp','/tmp/adbjavac','TestLocalAdb'],text=True,capture_output=True,timeout=22)
print('exit=',p.returncode,'stdout=',p.stdout[:800],'stderr=',p.stderr[:200])
assert p.returncode==0
assert 'OK_MOCK_2' in p.stdout
