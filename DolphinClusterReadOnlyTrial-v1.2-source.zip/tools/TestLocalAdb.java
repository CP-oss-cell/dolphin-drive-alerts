import com.dolphin.clusterprobe.LocalAdb;
import java.io.File;
public class TestLocalAdb {
  public static void main(String[] args) throws Exception {
    File store = new File("/tmp/cluster-local-adb-test"); store.mkdirs();
    try (LocalAdb local = new LocalAdb(store)) {
       String txt = local.checkAndRead(System.out::println);
       System.out.println(txt);
       if (!txt.contains("OK_MOCK_2")) throw new IllegalStateException("Missing response");
    }
  }
}
