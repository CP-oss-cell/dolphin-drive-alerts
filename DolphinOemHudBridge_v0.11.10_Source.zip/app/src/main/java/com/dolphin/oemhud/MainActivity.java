package com.dolphin.oemhud;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import com.dolphin.oemhud.adb.HudAdbPermissions;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/**
 * Automotive cockpit dashboard for BYD Dolphin (1280x720).
 * Redesigned with primary controls pinned at top, 1-tap segmented buttons,
 * large finger-friendly 2-column grids, and unified checkbox/slider styling.
 */
public final class MainActivity extends Activity {
    private static final int BT_REQ = 305;
    private static final int SCREEN_PROBE_REQ = 306;
    private static final int VISUAL_ASSIST_REQ = 307;
    // Automotive OLED dark cockpit palette (high contrast, low glare).
    private static final int NAVY=Color.rgb(16,26,42), INK=Color.rgb(238,245,252);
    private static final int MUTED=Color.rgb(148,168,192), TEAL=Color.rgb(14,138,152);
    private static final int SURFACE=Color.rgb(11,16,24), WHITE=Color.rgb(22,32,48);
    private static final int LIGHT=Color.rgb(250,252,255), SECONDARY=Color.rgb(32,46,67);
    private static final int BORDER=Color.rgb(42,60,84), ACCENT=Color.rgb(56,189,248);
    private static final int EMERALD=Color.rgb(34,197,94), AMBER=Color.rgb(251,191,36);

    private final ArrayList<BluetoothDevice> devices=new ArrayList<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable refreshTask=new Runnable(){@Override public void run(){updateStatus();main.postDelayed(this,3000);}};
    private HudConnector scanner;
    private SharedPreferences prefs;
    private TextView hudState, navState, rightsState, brightnessState, details, operationDescription;
    private Spinner hudPicker;
    private CheckBox safetyEnabled, buzzerEnabled;
    private LinearLayout safetyToggleRow, buzzerToggleRow;
    private SegmentGroup volumeSeg, brightnessModeSeg, brightnessDaySeg, brightnessNightSeg, userHudCheckSeg;
    private SeekBar volumeSeek, brightnessDaySeek, brightnessNightSeek;
    private TextView volumeLabel, brightnessDayLabel, brightnessNightLabel;
    private LinearLayout nightEqCard;
    private Button dayStartButton, nightStartButton;
    private TextView brightnessScheduleStatus, brightnessRuntimeStatus;
    private int dayStartMinutes, nightStartMinutes;
    private TextView navSelection, guidanceState, oemBinderState, tbtCompareState;
    private TextView safetyState, visualAssistState, userHudCheckState;
    private Button operationButton, adbButton, visualAssistButton;
    private LinearLayout advancedContent;
    private boolean advancedVisible;
    private final Button[] tabButtons=new Button[4];
    private final LinearLayout[] tabPanels=new LinearLayout[4];
    private int activeTab=0;

    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        prefs=getSharedPreferences(BridgeLog.STORE,0);
        dayStartMinutes=HudBrightnessSchedule.validMinute(prefs.getInt(HudBrightnessSchedule.KEY_DAY_START,HudBrightnessSchedule.DEFAULT_DAY_START),HudBrightnessSchedule.DEFAULT_DAY_START);
        nightStartMinutes=HudBrightnessSchedule.validMinute(prefs.getInt(HudBrightnessSchedule.KEY_NIGHT_START,HudBrightnessSchedule.DEFAULT_NIGHT_START),HudBrightnessSchedule.DEFAULT_NIGHT_START);
        if(dayStartMinutes==nightStartMinutes){dayStartMinutes=HudBrightnessSchedule.DEFAULT_DAY_START;nightStartMinutes=HudBrightnessSchedule.DEFAULT_NIGHT_START;}
        scanner=new HudConnector(this);
        buildDashboard();
        // OEM IPC boundary check is observational; no INaviService transaction is sent.
        OemTmapBinderProbe.start(this);
        OemVehicleIpcProbe.inspect(this);
        if(!hasBluetoothPermission())requestBluetoothPermission();
        if(prefs.getBoolean("enabled",false)){
            try{startServiceSafely(new Intent(this,BridgeService.class));}
            catch(Exception e){BridgeLog.event(this,"자동 시작 실패: "+e.getClass().getSimpleName());}
        }
        if(!prefs.getBoolean("adb_first_run_prompt",false)){
            prefs.edit().putBoolean("adb_first_run_prompt",true).apply();
            new AlertDialog.Builder(this).setTitle("차량 ADB 권한 설정")
                .setMessage("순정 내비 안내 수신을 위해 차량 로컬 ADB 승인이 필요할 수 있습니다. 차량이 ADB를 제공하는 경우에만 승인창이 나타납니다. 지금 진행할까요?")
                .setNegativeButton("나중에",null)
                .setPositiveButton("승인 및 권한 설정",(d,w)->requestAdbSetup()).show();
        }
    }
    private void openNavPicker(){
        BridgeLog.event(this,"내비 앱 목록 화면 열기 · "+installedVersion());
        startActivity(new Intent(this,NavAppPickerActivity.class));
    }
    private String installedVersion(){
        try{
            PackageInfo info=getPackageManager().getPackageInfo(getPackageName(),0);
            long code=Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;
            return info.versionName+" ("+code+")";
        }catch(Exception e){return "버전 확인 불가";}
    }
    private void buildDashboard(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout root=column();root.setPadding(dp(18),dp(14),dp(18),dp(28));root.setBackgroundColor(SURFACE);
        scroll.addView(root);

        // 1. Hero + Primary Driving Controls Pinned at Top (Always 1-Tap Accessible)
        LinearLayout hero=column();hero.setPadding(dp(18),dp(14),dp(18),dp(14));
        hero.setBackground(bordered(NAVY,BORDER,18));
        LinearLayout heroTop=new LinearLayout(this);heroTop.setOrientation(LinearLayout.HORIZONTAL);
        heroTop.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brandCol=column();
        brandCol.addView(label("BYD DOLPHIN  ·  ARIA HUD Q",11,ACCENT,true));
        TextView title=label("순정 내비 HUD 대시보드",21,LIGHT,true);
        title.setPadding(0,dp(2),0,dp(2));brandCol.addView(title);
        brandCol.addView(label("v"+installedVersion(),12,MUTED,false));
        heroTop.addView(brandCol,new LinearLayout.LayoutParams(0,-2,1f));
        hero.addView(heroTop,margin(0,0,0,10));

        // Top-level navigation app selector entry (above the fold)
        Button navPickButton=button(hero,"① 설치된 내비 앱 목록 열기",false,this::openNavPicker);
        navPickButton.setMinHeight(dp(46));

        // Primary 2-Column Finger-Friendly Action Dock (Always Visible)
        LinearLayout primaryDock=twoColRow();
        operationButton=addGridButton(primaryDock,"▶ 운행 연동 시작",true,56,this::toggleRunning);
        visualAssistButton=addGridButton(primaryDock,"▶ 화살표 보조 인식",false,56,this::toggleVisualAssist);
        hero.addView(primaryDock,margin(0,8,0,6));

        operationDescription=label("현재 상태를 확인하는 중입니다.",12,MUTED,false);
        hero.addView(operationDescription,margin(2,2,2,2));
        visualAssistState=label("화면 보조: 대기 중",12,MUTED,false);
        hero.addView(visualAssistState,margin(2,0,2,0));
        root.addView(hero,margin(0,0,0,10));

        // 2. Live 4-Tile Telemetry Strip (Always visible)
        LinearLayout statusRow=new LinearLayout(this);statusRow.setOrientation(LinearLayout.HORIZONTAL);
        hudState=smallStatus(statusRow,"📡 HUD 연결");
        navState=smallStatus(statusRow,"🧭 TBT 안내");
        rightsState=smallStatus(statusRow,"🔐 권한");
        brightnessState=smallStatus(statusRow,"☀️ 자동 밝기");
        root.addView(statusRow,margin(0,0,0,10));

        // 3. 1-Tap Segmented 4-Tab Cockpit Switcher
        LinearLayout tabBar=new LinearLayout(this);tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setPadding(dp(4),dp(4),dp(4),dp(4));
        tabBar.setBackground(bordered(NAVY,BORDER,14));
        String[] tabNames={"🧭 운행","📡 HUD·설정","🧪 정차 시험","🛠️ 권한·진단"};
        for(int i=0;i<4;i++){
            final int idx=i;
            Button tb=new Button(this);tb.setAllCaps(false);tb.setText(tabNames[i]);tb.setTextSize(13);
            tb.setTextColor(LIGHT);tb.setMinHeight(dp(46));
            tb.setOnClickListener(v->selectTab(idx));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(46),1f);
            tp.setMargins(dp(2),0,dp(2),0);
            tabBar.addView(tb,tp);
            tabButtons[i]=tb;
            tabPanels[i]=column();
        }
        root.addView(tabBar,margin(0,0,0,10));
        for(int i=0;i<4;i++)root.addView(tabPanels[i]);

        // ================= TAB 0: 운행 상태 · 안전운전 =================
        LinearLayout operation=card(tabPanels[0],"🧭 실시간 운행 수신 상태","시동 후 자동 연결 · 순정 TMAP 길안내 중계");
        navSelection=label("내비 앱: 자동 감지",14,ACCENT,true);
        operation.addView(navSelection,margin(0,0,0,6));
        guidanceState=label("순정 TMAP 수신 상태 확인 중",13,INK,false);
        operation.addView(guidanceState,margin(0,2,0,4));
        tbtCompareState=label("순정/일반 TMAP 수신 비교 대기",12,MUTED,false);
        operation.addView(tbtCompareState,margin(0,2,0,4));
        oemBinderState=label("순정 TMAP Binder 경계 확인 중",11,MUTED,false);
        operation.addView(oemBinderState,margin(0,2,0,0));

        LinearLayout safety=card(tabPanels[0],"🛡️ 안전운전 정보 → ARIA HUD Q","카메라 · 제한속도 · 단속 거리");
        safetyEnabled=new CheckBox(this);
        safetyToggleRow=styledCheckRow(safety,safetyEnabled,"선택한 내비의 안전운전 정보 전달",prefs.getBoolean("safety_enabled",true),(checked)->{
            prefs.edit().putBoolean("safety_enabled",checked).apply();
            if(!checked)startServiceSafely(new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_SAFETY_CLEAR));
        });
        safetyState=label("안전운전 정보 수신 대기",12,MUTED,false);
        safety.addView(safetyState,margin(0,6,0,0));

        // ================= TAB 1: HUD · 설정 (1-Tap Segments + 2-Col EQ Sliders) =================
        LinearLayout connection=card(tabPanels[1],"📡 HUD 블루투스 연결","BLE FFF2 채널 · 자동 연결 관리");
        LinearLayout searchRow=twoColRow();
        addGridButton(searchRow,"🔍 HUD 검색",false,48,()->loadPaired());
        addGridButton(searchRow,"⚙️ 블루투스 설정",false,48,()->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        connection.addView(searchRow,margin(0,0,0,8));
        hudPicker=spinner(connection,new String[]{"HUD 검색을 눌러 기기를 선택하세요"},0);
        LinearLayout connActRow=twoColRow();
        addGridButton(connActRow,"연결·자동 저장",true,48,()->connectSelected());
        addGridButton(connActRow,"연결 해제",false,48,()->{
            Intent svc=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_DISCONNECT);
            startServiceSafely(svc);toast("HUD 자동 연결 해제");updateStatus();
        });
        connection.addView(connActRow,margin(0,4,0,0));

        LinearLayout settings=card(tabPanels[1],"☀️ 경보음 · 밝기 설정","1탭 세그먼트 & 대형 2열 슬라이더로 즉시 조절 후 저장");
        buzzerEnabled=new CheckBox(this);
        buzzerToggleRow=styledCheckRow(settings,buzzerEnabled,"HUD 경보음 사용",prefs.getBoolean("hud_buzzer_enabled",true),null);

        // Buzzer Volume: 1-Tap Segment + Global Slider
        int initVol=clampIndex(prefs.getInt("hud_buzzer_level",1),2);
        volumeLabel=label("경보음 크기: "+levelText(initVol),13,INK,true);
        settings.addView(volumeLabel,margin(0,8,0,4));
        volumeSeg=segmentedBar(settings,new String[]{"작게","보통","크게"},initVol,(idx)->{
            if(volumeSeek!=null && volumeSeek.getProgress()!=idx)volumeSeek.setProgress(idx);
            volumeLabel.setText("경보음 크기: "+levelText(idx));
        });
        volumeSeek=styledSeekBar(settings,2,initVol,(idx)->{
            if(volumeSeg!=null)volumeSeg.setSelected(idx);
            volumeLabel.setText("경보음 크기: "+levelText(idx));
        });

        // Brightness Mode: 1-Tap Segment
        int sourceMode=prefs.getInt(HudBrightnessSchedule.KEY_SOURCE,0);
        int selectedMode=prefs.getBoolean("hud_brightness_auto",true)?(sourceMode==1?1:0):2;
        settings.addView(label("밝기 제어 방식 (1탭 선택)",13,INK,true),margin(0,10,0,4));
        brightnessModeSeg=segmentedBar(settings,new String[]{"자동 · 조도 센서 우선","자동 · 사용자 시간표만","고정 밝기"},selectedMode,(idx)->updateBrightnessModeUi(idx));

        // Large Finger-Friendly 2-Column EQ-Style Brightness Cards (Day | Night)
        LinearLayout eqRow=twoColRow();
        LinearLayout dayEqCard=subCard(eqRow,1f);
        int initDay=clampIndex(prefs.getInt("hud_brightness_day",2),2);
        brightnessDayLabel=label("☀️ 주간/고정: "+levelText(initDay),13,INK,true);
        dayEqCard.addView(brightnessDayLabel,margin(0,0,0,6));
        brightnessDaySeg=segmentedBar(dayEqCard,new String[]{"1단계","2단계","3단계"},initDay,(idx)->{
            if(brightnessDaySeek!=null && brightnessDaySeek.getProgress()!=idx)brightnessDaySeek.setProgress(idx);
            brightnessDayLabel.setText("☀️ 주간/고정: "+levelText(idx));
        });
        brightnessDaySeek=styledSeekBar(dayEqCard,2,initDay,(idx)->{
            if(brightnessDaySeg!=null)brightnessDaySeg.setSelected(idx);
            brightnessDayLabel.setText("☀️ 주간/고정: "+levelText(idx));
        });

        nightEqCard=subCard(eqRow,1f);
        int initNight=clampIndex(prefs.getInt("hud_brightness_night",0),2);
        brightnessNightLabel=label("🌙 야간 밝기: "+levelText(initNight),13,INK,true);
        nightEqCard.addView(brightnessNightLabel,margin(0,0,0,6));
        brightnessNightSeg=segmentedBar(nightEqCard,new String[]{"1단계","2단계","3단계"},initNight,(idx)->{
            if(brightnessNightSeek!=null && brightnessNightSeek.getProgress()!=idx)brightnessNightSeek.setProgress(idx);
            brightnessNightLabel.setText("🌙 야간 밝기: "+levelText(idx));
        });
        brightnessNightSeek=styledSeekBar(nightEqCard,2,initNight,(idx)->{
            if(brightnessNightSeg!=null)brightnessNightSeg.setSelected(idx);
            brightnessNightLabel.setText("🌙 야간 밝기: "+levelText(idx));
        });
        settings.addView(eqRow,margin(0,8,0,6));
        updateBrightnessModeUi(selectedMode);

        // 2-Column Time Schedule Buttons
        settings.addView(label("자동 밝기 시간표",12,MUTED,true),margin(0,6,0,4));
        LinearLayout scheduleRow=twoColRow();
        dayStartButton=addGridButton(scheduleRow,"주간 시작",false,48,()->pickBrightnessTime(true));
        nightStartButton=addGridButton(scheduleRow,"야간 시작",false,48,()->pickBrightnessTime(false));
        settings.addView(scheduleRow);
        brightnessScheduleStatus=label("",12,MUTED,false);
        settings.addView(brightnessScheduleStatus,margin(0,6,0,4));
        updateScheduleLabels();
        brightnessRuntimeStatus=label("실제 자동 밝기 상태 확인 중",12,ACCENT,false);
        settings.addView(brightnessRuntimeStatus,margin(0,0,0,10));
        Button saveSettingsBtn=button(settings,"경보음·밝기 함께 저장 및 전송",true,this::saveHudSettings);
        saveSettingsBtn.setMinHeight(dp(52));

        // ================= TAB 2: 정차 시험 (2-Column Grid + 1-Tap Check) =================
        LinearLayout testCard=card(tabPanels[2],"🧪 정차 중 HUD 출력 시험","반드시 정차(P) 상태에서 표시·캡처 정상 여부를 확인하세요");
        LinearLayout testRow1=twoColRow();
        addGridButton(testRow1,"HUD 연결 진단 · 우회전 300m",true,52,()->{
            new AlertDialog.Builder(this).setTitle("HUD 출력 경로 확인")
                .setMessage("차량을 안전하게 정차(P)한 상태에서만 실행하세요. 실제 길안내가 아닌 '우회전 300m' 명령을 한 번 전송합니다. 블루투스 쓰기가 성공해도 HUD 화면 표시 여부는 별도로 확인되어야 합니다. 동의하면 8초간 접근 가능한 화면 창의 소유 앱·창 종류·영역만 기록합니다. 글자·목적지·화면 사진은 기록하지 않습니다.")
                .setNegativeButton("취소",null)
                .setPositiveButton("1회 전송",(d,w)->{
                    NavAccessibilityService.requestWindowProbe(this);
                    startServiceSafely(new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_DEMO));
                    toast("HUD 전송 요청 · 상태와 응답은 진단에서 확인");
                }).show();
        });
        addGridButton(testRow1,"📷 화면 캡처 1회 진단",false,52,this::requestScreenProbe);
        testCard.addView(testRow1,margin(0,0,0,8));

        LinearLayout testRow2=twoColRow();
        addGridButton(testRow2,"🛡️ 안전운전 50km/h 시험",false,52,()->{
            new AlertDialog.Builder(this).setTitle("안전운전 표시 시험")
                .setMessage("정차한 상태에서 예시 카메라·제한 50km/h·300m를 1회 보냅니다. 5초 뒤 지우기를 요청합니다.")
                .setNegativeButton("취소",null).setPositiveButton("1회 보내기",(dialog,which)->
                    startServiceSafely(new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_SAFETY_DEMO))).show();
        });
        addGridButton(testRow2,"🧹 안전운전 표시 지우기",false,52,()->
            startServiceSafely(new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_SAFETY_CLEAR)));
        testCard.addView(testRow2,margin(0,0,0,4));

        LinearLayout checkCard=card(tabPanels[2],"✅ 실제 HUD 표시 확인 기록","주행·시험 후 눈에 보인 결과를 1탭으로 기록해 진단 ZIP에 포함합니다");
        userHudCheckState=label("실제 HUD 표시 확인: 미확인",13,ACCENT,true);
        checkCard.addView(userHudCheckState,margin(0,0,0,8));
        String curCheck=prefs.getString("user_hud_display_check","미확인");
        int checkIdx=curCheck.contains("자동")?2:(curCheck.contains("수동")?1:0);
        userHudCheckSeg=segmentedBar(checkCard,new String[]{"미확인","수동 표시 확인","자동 표시 확인"},checkIdx,(idx)->{
            saveUserHudCheck(idx==2?"자동 안내 HUD 표시 확인":(idx==1?"수동 시험 HUD 표시 확인":"미확인"));
        });

        // ================= TAB 3: 권한 · 진단 (2-Column Primary + Collapsible Logs) =================
        LinearLayout permission=card(tabPanels[3],"🔐 권한 관리 · 자동 진단","ADB 일괄 권한 적용 및 원터치 진단 ZIP 공유");
        LinearLayout adminRow=twoColRow();
        adbButton=addGridButton(adminRow,"ADB 연결·권한 적용",true,54,this::requestAdbSetup);
        addGridButton(adminRow,"📦 자동 진단 ZIP 생성·공유",true,54,this::quickDiagnosticZip);
        permission.addView(adminRow,margin(0,0,0,8));
        Button oemProbeBtn=button(permission,"📡 순정 내비 방송·HUD 경로 1회 진단 (ADB)",false,this::requestOemBroadcastProbe);
        oemProbeBtn.setMinHeight(dp(48));

        LinearLayout advanced=card(tabPanels[3],"📋 상세 로그 · 고급 진단","평소에는 닫아 두어도 됩니다");
        advancedContent=column();advancedContent.setVisibility(View.GONE);
        Button advToggle=button(advanced,"고급 설정 및 진단 보기",false,()->{
            advancedVisible=!advancedVisible;
            advancedContent.setVisibility(advancedVisible?View.VISIBLE:View.GONE);
            if(advancedVisible)updateStatus();
        });
        advToggle.setMinHeight(dp(48));
        advanced.addView(advancedContent);
        Button recheckBtn=button(advancedContent,"권한 상태 다시 확인",false,()->{
            HudAdbPermissions.audit(this,(msg,done)->runOnUiThread(()->{refreshDetails(msg);updateStatus();}));
        });
        recheckBtn.setMinHeight(dp(46));
        details=label("",11,INK,false);details.setTextIsSelectable(true);details.setPadding(0,dp(10),0,dp(6));
        advancedContent.addView(details);

        root.addView(label("차량 ECU·계기판 제어 없음 · 주행 안내는 순정 내비 화면을 우선하세요.",11,MUTED,false),margin(4,6,4,0));
        setContentView(scroll);
        selectTab(0);
        updateStatus();
    }

    private void updateBrightnessModeUi(int modeIdx){
        boolean nightEnabled=(modeIdx!=2);
        if(brightnessNightSeg!=null)brightnessNightSeg.setEnabled(nightEnabled);
        if(brightnessNightSeek!=null)brightnessNightSeek.setEnabled(nightEnabled);
        if(nightEqCard!=null)nightEqCard.setAlpha(nightEnabled?1.0f:0.45f);
    }

    private void selectTab(int index){
        activeTab=Math.max(0,Math.min(3,index));
        for(int i=0;i<4;i++){
            if(tabPanels[i]!=null)tabPanels[i].setVisibility(i==activeTab?View.VISIBLE:View.GONE);
            if(tabButtons[i]!=null){
                tabButtons[i].setBackground(bordered(i==activeTab?TEAL:NAVY,i==activeTab?ACCENT:NAVY,10));
                tabButtons[i].setTextColor(i==activeTab?LIGHT:MUTED);
            }
        }
    }
    private void toggleRunning(){
        boolean enabled=!prefs.getBoolean("enabled",false);
        prefs.edit().putBoolean("enabled",enabled)
            .putLong("nav_last_enabled_changed_at",System.currentTimeMillis()).apply();
        try{if(enabled)startServiceSafely(new Intent(this,BridgeService.class));
            else {
                stopService(new Intent(this,BridgeService.class));
                if(ScreenCaptureService.isAssistActive())stopVisualAssist();
            }
            toast(enabled?"HUD 길안내 연동 시작":"HUD 길안내 연동 중지");
        }catch(Exception e){prefs.edit().putBoolean("enabled",!enabled).apply();toast("작동 변경 실패: "+e.getClass().getSimpleName());}
        updateStatus();
    }
    private void connectSelected(){
        int pos=hudPicker.getSelectedItemPosition();
        if(pos<0||pos>=devices.size()){toast("먼저 HUD를 검색하고 선택하세요");return;}
        if(!hasBluetoothPermission()){requestBluetoothPermission();return;}
        try{
            BluetoothDevice d=devices.get(pos);
            if(!HudConnector.isSupportedName(d.getName())){toast("지원 대상 HUD Q가 아닙니다");return;}
            String addr=d.getAddress();prefs.edit().putString("hud_mac",addr).apply();
            Intent intent=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_CONNECT);
            intent.putExtra(BridgeService.EXTRA_ADDRESS,addr);startServiceSafely(intent);
            scanner.stopScanning();toast("HUD 연결·자동 연결 저장");updateStatus();
        }catch(Exception ex){toast("HUD 연결 요청 실패: "+ex.getClass().getSimpleName());}
    }
    private void pickBrightnessTime(boolean day){
        int selected=day?dayStartMinutes:nightStartMinutes;
        new TimePickerDialog(this,(picker,hour,minute)->{
            int value=hour*60+minute;
            int nextDay=day?value:dayStartMinutes;
            int nextNight=day?nightStartMinutes:value;
            if(!HudBrightnessSchedule.validPair(nextDay,nextNight)){
                toast("주간 시작과 야간 시작은 다른 시간이어야 합니다");return;
            }
            dayStartMinutes=nextDay;nightStartMinutes=nextNight;
            updateScheduleLabels();
        },selected/60,selected%60,true).show();
    }
    private void updateScheduleLabels(){
        if(dayStartButton!=null)dayStartButton.setText("☀️ 주간 시작 "+HudBrightnessSchedule.clockLabel(dayStartMinutes));
        if(nightStartButton!=null)nightStartButton.setText("🌙 야간 시작 "+HudBrightnessSchedule.clockLabel(nightStartMinutes));
        if(brightnessScheduleStatus!=null)brightnessScheduleStatus.setText(
            HudBrightnessSchedule.summary(dayStartMinutes,nightStartMinutes)+" · 아래 저장 버튼을 눌러 적용");
    }
    private void saveHudSettings(){
        Intent buzzer=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_BUZZER);
        buzzer.putExtra("enabled",buzzerEnabled.isChecked());buzzer.putExtra("level",volumeSeg.selectedIndex);
        Intent bright=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_BRIGHTNESS);
        int mode=brightnessModeSeg.selectedIndex;
        if(!HudBrightnessSchedule.validPair(dayStartMinutes,nightStartMinutes)){
            toast("주간 시작과 야간 시작을 다르게 선택하세요");return;
        }
        bright.putExtra("auto",mode!=2);
        bright.putExtra("source_mode",mode==1?1:0);
        bright.putExtra("day_start",dayStartMinutes);
        bright.putExtra("night_start",nightStartMinutes);
        bright.putExtra("day",brightnessDaySeg.selectedIndex);
        bright.putExtra("night",brightnessNightSeg.selectedIndex);
        try{startServiceSafely(buzzer);startServiceSafely(bright);
            toast("HUD 경보음·밝기 저장 및 전송 요청");updateStatus();
        }catch(Exception e){toast("설정 전송 오류: "+e.getClass().getSimpleName());}
    }
    private void requestOemBroadcastProbe(){
        new AlertDialog.Builder(this).setTitle("순정 내비 방송·HUD 경로 진단 (읽기 전용)")
            .setMessage("차량 로컬 ADB(127.0.0.1:5555)를 통해 순정 TMAP 길안내 중 송출되는 브로드캐스트(dumpsys activity broadcasts), 패키지 리시버(dumpsys package), 최근 logcat을 읽기 전용으로 1회 수집합니다. 차량 설정을 변경하지 않으며, 결과는 진단 ZIP에도 자동 포함됩니다.")
            .setNegativeButton("취소",null)
            .setPositiveButton("진단 실행",(d,w)->{
                toast("순정 내비 방송·HUD 경로 진단 중...");
                HudAdbPermissions.probeOemNavBroadcasts(this,(msg,done)->runOnUiThread(()->{
                    prefs.edit().putString("oem_broadcast_probe_result",msg)
                        .putLong("oem_broadcast_probe_at",System.currentTimeMillis()).apply();
                    BridgeLog.event(this,"순정 내비 방송 진단 완료 ("+msg.length()+"자)");
                    if(advancedVisible)refreshDetails("");
                    new AlertDialog.Builder(this).setTitle("순정 내비 방송·HUD 경로 결과")
                        .setMessage(msg.length()>3500?msg.substring(0,3500)+"\n...(진단 ZIP에서 전체 확인)":msg)
                        .setPositiveButton("확인",null).show();
                }));
            }).show();
    }
    private void requestAdbSetup(){
        new AlertDialog.Builder(this).setTitle("차량 ADB 연결 및 권한 적용")
            .setMessage("차량 로컬 ADB(127.0.0.1:5555)에 연결하고, 동의하면 알림 접근·위치·순정 내비 화면 텍스트 읽기(접근성) 권한을 적용합니다. 다른 앱의 화면 내용은 길안내로 처리하지 않으며 차량 ECU를 변경하지 않습니다. 이 권한들을 허용하시겠습니까?")
            .setNegativeButton("취소",null).setPositiveButton("연결·적용",(d,w)->startAdbSetup()).show();
    }
    private void startAdbSetup(){
        adbButton.setEnabled(false);adbButton.setText("ADB 연결 중...");
        HudAdbPermissions.connect(this,(msg,done)->runOnUiThread(()->{
            prefs.edit().putString("adb_last_result",msg).apply();updateStatus();
            if(!done)return;
            if(!msg.startsWith("ADB_READY:")){
                adbButton.setEnabled(true);adbButton.setText("ADB 연결·권한 적용");
                new AlertDialog.Builder(this).setTitle("ADB 연결 실패").setMessage(msg).setPositiveButton("확인",null).show();
                return;
            }
            adbButton.setText("필수 권한 적용 중...");
            HudAdbPermissions.apply(this,true,(result,finished)->runOnUiThread(()->{
                prefs.edit().putString("adb_last_result",result).apply();updateStatus();
                if(finished){
                    adbButton.setEnabled(true);adbButton.setText("ADB 연결·권한 적용");
                    new AlertDialog.Builder(this).setTitle("ADB 권한 적용 결과").setMessage(result)
                        .setPositiveButton("확인",null).show();
                }
            }));
        }));
    }
    private void loadPaired(){
        if(!hasBluetoothPermission()){requestBluetoothPermission();return;}
        scanner.scan(new HudConnector.ScanListener(){
            @Override public void found(ArrayList<BluetoothDevice> found){runOnUiThread(()->{
                devices.clear();devices.addAll(found);ArrayList<String> names=new ArrayList<>();
                for(BluetoothDevice d:found){
                    try{String a=d.getAddress(),n=d.getName();
                        names.add((n==null?"HUD Q":n)+" ("+a.substring(0,Math.min(5,a.length()))+"…)");}
                    catch(Exception ex){names.add("HUD Q 기기");}
                }
                if(names.isEmpty())names.add("검색된 HUD 없음");
                ArrayAdapter<String> adapter=new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_item,names);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);hudPicker.setAdapter(adapter);
            });}
            @Override public void status(String message){runOnUiThread(()->{
                BridgeLog.event(MainActivity.this,message);
                if(!message.startsWith("검색 중"))toast(message);
            });}
        });
    }
    private boolean hasBluetoothPermission(){
        return (Build.VERSION.SDK_INT<31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED))
            && (Build.VERSION.SDK_INT>=31 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED);
    }
    private void requestBluetoothPermission(){
        if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},BT_REQ);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},BT_REQ);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==BT_REQ){if(hasBluetoothPermission())loadPaired();else toast("HUD 검색을 위해 블루투스·위치 권한을 허용하세요");}
        updateStatus();
    }
    private void startServiceSafely(Intent i){
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
    private void updateStatus(){
        if(prefs==null||operationButton==null)return;
        boolean running=prefs.getBoolean("enabled",false);
        boolean assistOn=ScreenCaptureService.isAssistActive();
        if(visualAssistButton!=null){
            visualAssistButton.setText(assistOn?"⏹ 화살표 보조 인식 중지":"▶ 화살표 보조 인식");
            visualAssistButton.setBackground(bordered(assistOn?Color.rgb(180,50,60):SECONDARY,assistOn?AMBER:ACCENT,12));
        }
        if(visualAssistState!=null)visualAssistState.setText((assistOn?"● 보조 실행 중 · ":"○ 보조 대기 · ")+prefs.getString("visual_assist_state","미시작")+" / 앵커: "+prefs.getString("tbt_last_ready_anchor","미탐지"));
        if(userHudCheckState!=null)userHudCheckState.setText("현재 기록: "+prefs.getString("user_hud_display_check","미확인"));
        if(safetyState!=null)safetyState.setText(prefs.getString("safety_status","최근 유효 안전운전 정보 없음 · 자동 수신 미확인")+"\n"+
            prefs.getString("last_safety","")+"\n입력: "+prefs.getString("safety_input_diagnosis","아직 관측되지 않음")+" · "+prefs.getString("safety_transport_status","BLE 안전운전 송신 없음"));
        operationButton.setText(running?"⏹ 운행 연동 중지":"▶ 운행 연동 시작");
        operationButton.setBackground(bordered(running?Color.rgb(185,55,65):TEAL,running?AMBER:ACCENT,12));
        operationDescription.setText(running?"● 안내 수신 및 HUD 연결 유지 사용 중":"○ 연동 꺼짐 · 누르면 자동 실행 설정도 함께 켜집니다");
        String navPkg=prefs.getString("nav_package","").trim();
        String navLabel=prefs.getString("selected_nav_label","");
        navSelection.setText(navPkg.isEmpty()?"선택 내비: 자동 감지":
            "선택 내비: "+(navLabel.isEmpty()?navPkg:navLabel));
        if(brightnessRuntimeStatus!=null){
            brightnessRuntimeStatus.setText("현재 적용: "+prefs.getString("hud_auto_status","저장 후 확인")+
                " · "+prefs.getString("hud_auto_sensor","센서 상태 확인 중"));
        }
        if(oemBinderState!=null){
            oemBinderState.setText("순정 Binder: "+prefs.getString("oem_binder_state","확인 중")+
                " · 상태방송 "+prefs.getInt("oem_state_observed_count",0)+"회");
        }
        String hud=prefs.getString("hud_status","연결 전");
        boolean hudReady=hud.contains("준비");
        hudState.setText(hudReady?"● 연결됨":hud.contains("재연결")?"◐ 재연결 중":"○ 연결 전");
        hudState.setTextColor(hudReady?EMERALD:(hud.contains("재연결")?AMBER:MUTED));
        String rights=HudAdbPermissions.readStatus(this);
        boolean accessEnabled=rights.contains("화면 접근성: ENABLED");
        boolean rightsOk=rights.contains("알림 리스너: GRANTED")&&accessEnabled&&hasBluetoothPermission();
        rightsState.setText(rightsOk?"● 완료":rights.contains("GRANTED")?"◐ 일부":"○ 설정 필요");
        rightsState.setTextColor(rightsOk?EMERALD:AMBER);
        brightnessState.setText(prefs.getBoolean("hud_brightness_saved",false)?
            (prefs.getBoolean("hud_brightness_auto",true)?"● 자동":"● 고정"):"○ 미설정");
        brightnessState.setTextColor(prefs.getBoolean("hud_brightness_saved",false)?ACCENT:MUTED);
        long now=System.currentTimeMillis();
        boolean runtime=prefs.getBoolean("a11y_runtime_connected",false);
        long lastPoll=prefs.getLong("nav_poll_last_attempt_at",0);
        long lastNavEvent=prefs.getLong("last_nav_event_at",0);
        long lastParsed=prefs.getLong("nav_last_parsed_at",0);
        boolean recentPoll=lastPoll>0 && now-lastPoll<15000;
        boolean recentNavEvent=lastNavEvent>0 && now-lastNavEvent<15000;
        boolean recentParsed=lastParsed>0 && now-lastParsed<20000;
        String watchState=prefs.getString("nav_watchdog_state","");
        boolean monitorCurrent=now-prefs.getLong("nav_watchdog_last_check_at",0)<40000;
        navState.setText(!running?"○ 연동 꺼짐":recentParsed?"● 안내 해석":
            !accessEnabled?"○ 권한 꺼짐":
            running&&monitorCurrent&&NavPollHealth.STALE.equals(watchState)?"◐ 조회 지연":
            running&&monitorCurrent&&NavPollHealth.DISCONNECTED.equals(watchState)?"○ 미연결":
            runtime&&recentPoll?"● 조회 중":runtime?"◐ 대기":"○ 대기");
        navState.setTextColor(recentParsed?EMERALD:(runtime&&recentPoll?ACCENT:MUTED));
        if(tbtCompareState!=null)tbtCompareState.setText(
            NavInputTrace.oneLine(prefs,NavTracePolicy.OEM)+"\n"+
            NavInputTrace.oneLine(prefs,NavTracePolicy.GENERAL));
        if(guidanceState!=null){
            String message=!running?"연동이 꺼져 있습니다":recentParsed?
                "최근 안내 해석됨 · HUD 접수 " + prefs.getInt("nav_tbt_hud_attempts",0)+"회(누적), HUD 표시 미확인":
                !accessEnabled?"순정 TMAP 화면 접근성 OFF · 권한·진단 탭에서 활성화 필요":
                running&&monitorCurrent&&NavPollHealth.STALE.equals(watchState)?
                    "화면 조회 루프 지연 감지 · 자동 재예약 대기 중":
                running&&monitorCurrent&&NavPollHealth.DISCONNECTED.equals(watchState)?
                    "접근성 수신기 미연결 · 권한·진단 탭에서 다시 확인":
                recentNavEvent||prefs.getInt("nav_visible_text_chars",0)>0?
                    "순정 TMAP 화면 감지됨 · 방향/거리 짝 확인 중 (거리="+prefs.getBoolean("nav_distance_token_seen",false)+", 방향="+prefs.getBoolean("nav_direction_token_seen",false)+")":
                runtime&&recentPoll?"순정 TMAP 수신기 대기 중 · 내비 실행 후 길안내를 시작하세요":
                    "과거 누적 기록 있음 · 현재 세션 대기 중 (과거 안내 누적 "+prefs.getInt("nav_parsed_count",0)+"회)";
            guidanceState.setText(message);
        }
        if(advancedVisible)refreshDetails("");
    }
    private String statusText(){
        return HudAdbPermissions.readStatus(this)+"\n\n"+
            "실행 APK 버전: "+installedVersion()+"\n"+
            "앱 선택 기능: 대시보드 상단 ① 설치된 내비 앱 목록 열기\n"+
            "브리지 자동 실행: "+(prefs.getBoolean("enabled",false)?"ON":"OFF")+"\n"+
            "HUD: "+prefs.getString("hud_status","연결 전")+"\n"+
            "안전운전 수신: "+prefs.getString("safety_status","유효 입력 없음")+" / "+prefs.getString("last_safety","")+"\n"+
            "안전운전 입력 판정: "+prefs.getString("safety_input_diagnosis","관측 없음")+" / 관측 "+prefs.getInt("safety_observations",0)+"회 / 최근 시각(ms): "+prefs.getLong("safety_observed_at",0)+"\n"+
            "안전운전 유효 입력(자동): "+prefs.getInt("safety_valid_inputs",0)+" / 마지막 시각(ms): "+prefs.getLong("safety_last_input_at",0)+"\n"+
            "안전운전 BLE 요청/완료/콜백/오류: "+prefs.getInt("hud_safety_write_requests",0)+"/"+prefs.getInt("hud_safety_write_completed",0)+"/"+prefs.getInt("hud_safety_callback_confirmed",0)+"/"+prefs.getInt("hud_safety_transport_errors",0)+" (지우기 포함 · 표시 미확인)\n"+
            "안전운전 전송: "+prefs.getString("safety_transport_status","없음")+"\n"+
            "경보음: "+(prefs.getBoolean("hud_buzzer_saved",false)?(prefs.getBoolean("hud_buzzer_enabled",true)?"ON":"OFF")+" / "+(prefs.getInt("hud_buzzer_level",1)+1)+"단계":"미설정")+"\n"+
            "밝기: "+(prefs.getBoolean("hud_brightness_saved",false)?(prefs.getBoolean("hud_brightness_auto",true)?"주야간 프로필":"고정")+" / 주간 "+(prefs.getInt("hud_brightness_day",2)+1)+" / 야간 "+(prefs.getInt("hud_brightness_night",0)+1):"미설정")+"\n"+
            "자동 밝기: "+prefs.getString("hud_auto_status","미실행")+" / "+prefs.getString("hud_auto_sensor","미확인")+"\n"+
            "자동 밝기 입력 방식: "+(prefs.getInt(HudBrightnessSchedule.KEY_SOURCE,0)==1?"사용자 시간표만":"센서 우선/시간표 대체")+"\n"+
            "밝기 시간표: "+HudBrightnessSchedule.summary(
                prefs.getInt(HudBrightnessSchedule.KEY_DAY_START,HudBrightnessSchedule.DEFAULT_DAY_START),
                prefs.getInt(HudBrightnessSchedule.KEY_NIGHT_START,HudBrightnessSchedule.DEFAULT_NIGHT_START))+"\n"+
            "설정 송신: "+prefs.getString("hud_setting_status","아직 없음")+"\n"+
            "실제 HUD 이름: "+prefs.getString("hud_device_name","미확인")+"\n"+
            "MCon 예상 프로필: "+prefs.getString("hud_model_expected","미확인")+"\n"+
            "실제 GATT 서비스: "+prefs.getString("hud_services_found","미확인")+"\n"+
            "BLE 쓰기 특성: "+prefs.getString("hud_write_channel","미연결")+"\n"+
            "HUD FFF1 기기 알림: "+prefs.getInt("hud_notify_count",0)+"회 (없어도 미지원일 수 있음)\n"+
            "최근 FFF1 응답: "+prefs.getString("hud_last_notify","없음")+"\n"+
            "수동 출력 진단: "+prefs.getString("hud_demo_status","미실행")+"\n"+
            "창 출처 진단 상태: "+prefs.getString("window_probe_status","수동 시험 전")+"\n"+
            "창 출처 샘플: "+prefs.getInt("window_probe_samples",0)+"회 / 마지막 시각(ms): "+prefs.getLong("window_probe_last_at",0)+"\n"+
            "창 변경 이벤트(8초 창): "+prefs.getInt("window_probe_change_events",0)+"회 · window id/layer는 소유 단서일 뿐 내부 팝업 생성자를 보증하지 않음\n"+
            "창 출처 기록(앱·종류·표시 영역, 화면 텍스트 없음):\n"+prefs.getString("window_probe_history","")+"\n"+
            "순정 TMAP 서비스 바인딩: "+prefs.getString("oem_binder_state","미실행")+" / "+prefs.getString("oem_binder_detail","확인 전")+"\n"+
            "순정 TMAP Binder 공개 여부: "+prefs.getString("oem_binder_exported","미확인")+" / 요구 권한: "+prefs.getString("oem_binder_permission","미확인")+"\n"+
            "순정 TMAP TBT 직접 수신: 미확인 (Binder 연결과 구별)\n"+
            "DiCar Provider 선언 조회: "+prefs.getString("oem_vehicle_provider_probe","미실행")+"\n"+
            "계기판 전용 Activity 선언 조회: "+prefs.getString("oem_cluster_activity_probe","미실행")+"\n"+
            "순정 TMAP 상태 방송(TBT 아님): "+prefs.getInt("oem_state_observed_count",0)+"회 / "+prefs.getString("oem_state_last","없음")+"\n"+
            "순정 상태 방송 무효/다른 출처: "+prefs.getInt("oem_state_ignored",0)+"회 (발신자 인증 불가)\n"+
            "AutoNavi 호환 방송(순정 송출 근거 없음): "+prefs.getInt("compat_broadcast_observed",0)+"회\n"+
            "OEM 우선 원칙으로 무시한 호환 방송: "+prefs.getInt("autonavi_ignored_for_oem",0)+"회\n"+
            "내비 알림 이벤트: "+prefs.getInt("nav_notification_count",0)+"회\n"+
            "내비 접근성 이벤트: "+prefs.getInt("nav_accessibility_count",0)+"회\n"+
            "화면 수신기 과거 연결 플래그: "+prefs.getString("a11y_runtime_state","UNKNOWN")+" (현재 생존 증명이 아님)\n"+
            "접근성 세션 시작(epoch ms): "+prefs.getLong("a11y_session_started_at",0)+"\n"+
            "이번 서비스 세션 내비 이벤트: "+prefs.getInt("nav_session_events",0)+"회\n"+
            "이번 서비스 세션 화면 조회: "+prefs.getInt("nav_session_polls",0)+"회\n"+
            "연동 설정 마지막 변경(epoch ms): "+prefs.getLong("nav_last_enabled_changed_at",0)+"\n"+
            "수신 감시 상태: "+prefs.getString("nav_watchdog_state","미실행")+" / 마지막 검사(epoch ms): "+prefs.getLong("nav_watchdog_last_check_at",0)+"\n"+
            "수신 감시 접근성 붙음: "+prefs.getBoolean("nav_watchdog_attached",false)+" / 복구 요청(epoch ms): "+prefs.getLong("nav_watchdog_repair_requested_at",0)+"\n"+
            "수신기 루프 재예약 횟수: "+prefs.getInt("nav_poll_repair_count",0)+" / 마지막 시각: "+prefs.getLong("nav_poll_repair_last_at",0)+"\n"+
            "수신기 루프 마지막 tick(epoch ms): "+prefs.getLong("nav_poll_loop_last_tick_at",0)+" / 종료: "+prefs.getLong("nav_poll_loop_last_finished_at",0)+" / 다음 예약: "+prefs.getLong("nav_poll_next_due_at",0)+"\n"+
            "수신기 루프 마지막 결과: "+prefs.getString("nav_poll_last_outcome","없음")+" / 실행시간(ms): "+prefs.getLong("nav_poll_duration_ms",0)+"\n"+
            "원클릭 진단(epoch ms): "+prefs.getLong("hud_quick_diagnostic_at",0)+" / "+prefs.getString("hud_quick_diagnostic_state","미실행")+"\n"+
            "마지막 내비 이벤트(epoch ms): "+prefs.getLong("last_nav_event_at",0)+"\n"+
            "이전 접근성 세션 최종 이벤트(epoch ms): "+prefs.getLong("nav_previous_session_last_event_at",0)+"\n"+
            "마지막 화면 조회 시도(epoch ms): "+prefs.getLong("nav_poll_last_attempt_at",0)+"\n"+
            "마지막 텍스트 유효 조회(epoch ms): "+prefs.getLong("nav_poll_last_success_at",0)+"\n"+
            "마지막 빈 화면 조회(epoch ms): "+prefs.getLong("nav_poll_last_empty_at",0)+"\n"+
            "TMAP 화면트리 검색: "+prefs.getInt("nav_tree_scan_count",0)+"회\n"+
            "TMAP 화면 주기 조회: "+prefs.getInt("nav_poll_scans_count",0)+"회\n"+
            "순정 TBT 거리 전용 뷰 관측(최근 조회): "+prefs.getInt("oem_tbt_distance_widgets_last",0)+"개\n"+
            "순정 라벨 없는 이미지 뷰(회전임을 보증 안함): "+prefs.getInt("oem_unlabeled_images_last",0)+"개\n"+
            "순정 화살표 원본 값: "+prefs.getString("oem_direction_access","미확인")+"\n"+
            "방향·거리 해석 누적: "+prefs.getInt("nav_parsed_count",0)+"회\n"+
            "접근성 이번 세션 해석: "+prefs.getInt("nav_session_parsed",0)+"회 / 알림 해석 누적: "+prefs.getInt("nav_notification_parsed",0)+"회\n"+
            "마지막 해석 시각(epoch ms): "+prefs.getLong("nav_last_parsed_at",0)+"\n"+
            "내비 화면 텍스트 길이: "+prefs.getInt("nav_visible_text_chars",0)+"자"+"\n"+
            "거리 표기 감지: "+prefs.getBoolean("nav_distance_token_seen",false)+" / 방향 문구 감지: "+prefs.getBoolean("nav_direction_token_seen",false)+" (최근 화면)"+"\n"+
            "HUD 안내 전송 접수 시도: "+prefs.getInt("nav_tbt_hud_attempts",0)+"회"+"\n"+
            "최근 안내 입력 경로: "+prefs.getString("last_nav_input_source","없음")+"\n"+
            "선택한 내비 앱: "+prefs.getString("nav_package","")+"\n"+
            "최근 감지 내비 앱: "+prefs.getString("last_nav_package","없음")+"\n"+
            "마지막 순정 방송: "+prefs.getString("last_oem_tbt","없음")+"\n"+
            "GATT 전체 쓰기 완료: "+prefs.getInt("hud_tx_completed",0)+" / 오류: "+prefs.getInt("hud_tx_errors",0)+"\n"+
            "안내 전송 요청: "+prefs.getInt("hud_nav_write_requests",0)+" / 완료: "+prefs.getInt("hud_nav_write_completed",0)+" / 콜백 확인: "+prefs.getInt("hud_nav_callback_confirmed",0)+" / 오류: "+prefs.getInt("hud_nav_transport_errors",0)+"\n"+
            "현재 속도(GPS): "+prefs.getInt("last_gps_speed_kmh",-1)+"km/h (최고 "+prefs.getInt("gps_max_speed_kmh",0)+"km/h · "+prefs.getString("gps_speed_status","미시작")+") / BLE 요청="+prefs.getInt("hud_speed_write_requests",0)+" / 완료="+prefs.getInt("hud_speed_write_completed",0)+"\n"+
            "밝기·경보음 설정 요청: "+prefs.getInt("hud_setting_write_requests",0)+" / 완료: "+prefs.getInt("hud_setting_write_completed",0)+" / 콜백 확인: "+prefs.getInt("hud_setting_callback_confirmed",0)+" / 오류: "+prefs.getInt("hud_setting_transport_errors",0)+"\n"+
            "설정 큐 대기 중 동일 프레임 차단: "+prefs.getInt("hud_setting_pending_duplicates_suppressed",0)+"회 (실제 전송 후 재적용과 구분)\n"+
            "최근 전송: "+prefs.getString("last_tx","없음")+"\n"+
            "최근 안내: "+prefs.getString("last_cue","없음")+"\n"+
            "최근 ADB 결과: "+prefs.getString("adb_last_result","없음")+"\n"+
            "※ GATT 완료는 실물 HUD 화면 표시 성공을 증명하지 않습니다.\n"+
            "※ 순정 상태 방송·Binder 연결·화면 이미지 요소는 TBT 방향·거리 수신 성공이 아닙니다.\n"+
            "화면 캡처 1회 진단: "+prefs.getString("screen_probe_status","NOT_TESTED")+"\n"+
            "TBT 마지막 유효 앵커: "+prefs.getString("tbt_last_ready_anchor","없음")+"\n"+
            "TBT 레이아웃 좌표 진단(텍스트 없음): "+prefs.getString("tbt_layout_probe","없음")+"\n"+
            "TBT 거리 위젯 좌표 이력(텍스트 없음): "+prefs.getString("tbt_dist_history","없음")+"\n"+
            "TBT 공간 앵커(최근): "+prefs.getString("tbt_anchor_status","미탐지")+" / 거리(m): "+prefs.getInt("tbt_anchor_distance_m",-1)+" / 화살표 크기: "+prefs.getString("tbt_anchor_arrow_size","없음")+" / 시각(ms): "+prefs.getLong("tbt_anchor_updated_at",0)+"\n"+
            "화면 화살표 보조 인식 상태: "+prefs.getString("visual_assist_state","미시작")+" / 실행중="+ScreenCaptureService.isAssistActive()+"\n"+
            "화면 화살표 검사/채택/거부: "+prefs.getInt("visual_frames_checked",0)+"/"+prefs.getInt("visual_arrow_accepted",0)+"/"+prefs.getInt("visual_arrow_rejected",0)+" / 최근사유="+prefs.getString("visual_last_reason","없음")+" / 신뢰도="+prefs.getString("visual_last_confidence","0.00")+" / 최근방향="+prefs.getString("visual_last_direction","없음")+" / 8x8실루엣="+prefs.getString("visual_last_shape_hex","없음")+"\n"+
            "사용자 실제 HUD 표시 확인: "+prefs.getString("user_hud_display_check","미확인")+" / 기록 시각(ms): "+prefs.getLong("user_hud_display_check_at",0)+"\n"+
            "순정 내비 방송·HUD 경로 진단(시각="+prefs.getLong("oem_broadcast_probe_at",0)+"):\n"+prefs.getString("oem_broadcast_probe_result","미실행")+"\n\n"+
            NavInputTrace.report(prefs);
    }
    private void refreshDetails(String extra){
        if(details!=null)details.setText((extra.isEmpty()?"":extra+"\n\n")+statusText());
    }
    private void requestScreenProbe(){
        new AlertDialog.Builder(this).setTitle("화면 캡처 가능 여부 진단")
            .setMessage("Android의 화면 공유 동의창이 나타납니다. 동의하면 현재 화면을 단 한 장 분석해 검은 화면 여부와 크기, TBT 앵커 및 8×8 실루엣만 기록합니다. 이미지·글자·목적지는 저장하거나 전송하지 않습니다. 순정 TMAP 안내창을 표시한 상태에서 진행하세요.")
            .setNegativeButton("취소",null)
            .setPositiveButton("화면 공유 동의 요청",(d,w)->{
                try{
                    android.media.projection.MediaProjectionManager mgr=(android.media.projection.MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if(mgr==null)throw new IllegalStateException("MediaProjection 서비스 없음");
                    startActivityForResult(mgr.createScreenCaptureIntent(),SCREEN_PROBE_REQ);
                }catch(Exception e){BridgeLog.event(this,"화면 진단 시작 실패 "+e.getClass().getSimpleName());toast("화면 진단 시작 실패");}
            }).show();
    }
    private void saveUserHudCheck(String state){
        prefs.edit().putString("user_hud_display_check",state)
            .putLong("user_hud_display_check_at",System.currentTimeMillis()).apply();
        BridgeLog.event(this,"사용자 HUD 표시 확인 기록: "+state);
        toast("기록됨: "+state);
        updateStatus();
    }
    private void toggleVisualAssist(){
        if(ScreenCaptureService.isAssistActive()){
            stopVisualAssist();
            return;
        }
        if(!prefs.getBoolean("enabled",false)){
            toast("먼저 '운행 연동 시작'을 켜세요");
            return;
        }
        new AlertDialog.Builder(this).setTitle("순정 화살표 화면 보조 인식 (사용자 동의)")
            .setMessage("정차 상태에서 동의하세요. Android 화면 공유 동의를 받아 순정 TMAP의 화살표 영역만 기기 메모리 내부에서 분석합니다. 화면 이미지·목적지·도로명은 저장하거나 외부로 전송하지 않으며, 2프레임 연속 일치하고 동일 카드 거리가 확인될 때만 HUD로 전달합니다.")
            .setNegativeButton("취소",null)
            .setPositiveButton("동의하고 시작",(d,w)->{
                try{
                    android.media.projection.MediaProjectionManager mgr=(android.media.projection.MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if(mgr==null)throw new IllegalStateException("MediaProjection 서비스 없음");
                    startActivityForResult(mgr.createScreenCaptureIntent(),VISUAL_ASSIST_REQ);
                }catch(Exception e){BridgeLog.event(this,"화살표 보조 인식 시작 실패 "+e.getClass().getSimpleName());toast("화살표 보조 인식 시작 실패");}
            }).show();
    }
    private void stopVisualAssist(){
        try{
            Intent stop=new Intent(this,ScreenCaptureService.class).setAction(ScreenCaptureService.ACTION_STOP_ASSIST);
            startService(stop);
            toast("화면 화살표 보조 인식 중지");
        }catch(Exception e){BridgeLog.event(this,"화살표 보조 인식 중지 오류: "+e.getClass().getSimpleName());}
        updateStatus();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=SCREEN_PROBE_REQ && requestCode!=VISUAL_ASSIST_REQ)return;
        boolean assistMode=(requestCode==VISUAL_ASSIST_REQ);
        if(resultCode!=RESULT_OK||data==null){
            prefs.edit().putString(assistMode?"visual_assist_state":"screen_probe_status","USER_DECLINED").apply();
            toast("화면 공유 동의가 취소되었습니다");updateStatus();return;
        }
        toast(assistMode?"화면 화살표 보조 인식을 시작합니다. 순정 TMAP으로 전환하세요.":"화면 캡처 진단을 시작합니다. 5초 안에 순정 TMAP으로 전환하세요.");
        try {
            Intent capture=new Intent(this,ScreenCaptureService.class);
            capture.setAction(assistMode?ScreenCaptureService.ACTION_START_ASSIST:ScreenCaptureService.ACTION_PROBE_ONCE);
            capture.putExtra("resultCode",resultCode);
            capture.putExtra("resultData",data);
            if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(capture);
            else startService(capture);
        } catch(Exception e) {
            String status="ERROR_START_SERVICE_"+e.getClass().getSimpleName();
            prefs.edit().putString(assistMode?"visual_assist_state":"screen_probe_status",status).apply();
            BridgeLog.event(this,(assistMode?"화살표 보조 인식: ":"화면 캡처 진단: ")+status);
        }
        updateStatus();
    }
    private void quickDiagnosticZip(){
        long now=System.currentTimeMillis();
        String watchdog=prefs.getString("nav_watchdog_state","감시 시작 전");
        String observation="순정="+NavInputTrace.oneLine(prefs,NavTracePolicy.OEM)+
            " / 일반="+NavInputTrace.oneLine(prefs,NavTracePolicy.GENERAL)+
            " / HUD="+prefs.getString("hud_status","미연결")+
            " / TBT해석="+prefs.getInt("nav_session_parsed",0)+
            " / 수신기="+watchdog+
            " / 마지막 조회="+prefs.getLong("nav_poll_last_attempt_at",0)+
            " / 화면캡처="+prefs.getString("screen_probe_status","NOT_TESTED");
        prefs.edit().putLong("hud_quick_diagnostic_at",now)
            .putString("hud_quick_diagnostic_state",observation).apply();
        exportZip();
    }
    private void exportZip(){
        Uri uri=null;boolean completed=false;
        try{
            String name="DolphinOemHud_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.KOREA).format(new Date())+".zip";
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,name);
            values.put(MediaStore.Downloads.MIME_TYPE,"application/zip");
            values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("다운로드 저장소 생성 실패");
            try(OutputStream out=getContentResolver().openOutputStream(uri);ZipOutputStream zip=new ZipOutputStream(out)){
                zip.putNextEntry(new ZipEntry("report.txt"));
                String report="Dolphin OEM HUD Bridge "+installedVersion()+"\n"+statusText()+"\n\n=== EVENTS ===\n"+
                    prefs.getString("history","")+"\n=== NOTE ===\nGATT write != HUD screen confirmation.\n";
                zip.write(report.getBytes(StandardCharsets.UTF_8));zip.closeEntry();
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);completed=true;
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/zip");
            share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"HUD 진단 ZIP 공유"));
        }catch(Exception e){toast("ZIP 저장/공유 실패: "+e.getMessage());}
        finally{if(!completed&&uri!=null)getContentResolver().delete(uri,null,null);}
    }
    @Override protected void onResume(){super.onResume();main.removeCallbacks(refreshTask);main.post(refreshTask);}
    @Override protected void onPause(){main.removeCallbacks(refreshTask);super.onPause();}
    @Override protected void onDestroy(){main.removeCallbacks(refreshTask);scanner.stopScanning();super.onDestroy();}

    // ================= Global Cockpit UI Builders (1-Tap Segments, 2-Col Grid, Unified Check/Slider) =================
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout twoColRow(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
    private GradientDrawable rounded(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private GradientDrawable bordered(int color,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private int clampIndex(int val,int max){return Math.max(0,Math.min(max,val));}
    private String levelText(int idx){return idx==0?"1단계 (어둡/작게)":(idx==1?"2단계 (보통)":"3단계 (밝/크게)");}
    private LinearLayout.LayoutParams margin(int left,int top,int right,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private TextView label(String value,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout card(LinearLayout root,String title,String sub){
        LinearLayout card=column();card.setBackground(bordered(WHITE,BORDER,16));card.setPadding(dp(18),dp(15),dp(18),dp(15));
        card.setElevation(dp(2));card.addView(label(title,16,INK,true));
        card.addView(label(sub,12,MUTED,false),margin(0,2,0,10));root.addView(card,margin(0,0,0,10));return card;
    }
    private LinearLayout subCard(LinearLayout row,float weight){
        LinearLayout box=column();box.setPadding(dp(12),dp(12),dp(12),dp(10));
        box.setBackground(bordered(NAVY,BORDER,14));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,weight);
        p.setMargins(dp(4),0,dp(4),0);
        row.addView(box,p);return box;
    }
    private TextView smallStatus(LinearLayout parent,String heading){
        LinearLayout wrapper=column();wrapper.setGravity(Gravity.CENTER_VERTICAL);
        wrapper.setPadding(dp(12),dp(8),dp(10),dp(8));wrapper.setBackground(bordered(WHITE,BORDER,14));
        wrapper.setElevation(dp(1));
        wrapper.addView(label(heading,11,MUTED,true));
        TextView result=label("확인 중",13,INK,true);result.setSingleLine(true);result.setEllipsize(android.text.TextUtils.TruncateAt.END);
        wrapper.addView(result,margin(0,3,0,0));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1f);
        p.setMargins(dp(3),0,dp(3),0);parent.addView(wrapper,p);return result;
    }
    private Button button(LinearLayout host,String title,boolean primary,Runnable action){
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTextSize(14);b.setMinHeight(dp(48));
        b.setTextColor(LIGHT);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(bordered(primary?TEAL:SECONDARY,primary?ACCENT:BORDER,12));
        host.addView(b,margin(0,4,0,2));
        b.setOnClickListener(v->action.run());return b;
    }
    private Button addGridButton(LinearLayout row,String title,boolean primary,int minHeightDp,Runnable action){
        Button b=new Button(this);b.setText(title);b.setTextSize(13);b.setAllCaps(false);
        b.setTextColor(LIGHT);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setMinHeight(dp(minHeightDp));
        b.setBackground(bordered(primary?TEAL:SECONDARY,primary?ACCENT:BORDER,12));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(minHeightDp),1f);
        p.setMargins(dp(4),0,dp(4),0);
        row.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private Spinner spinner(LinearLayout host,String[] choices,int selected){
        Spinner s=new Spinner(this);
        s.setBackground(bordered(SECONDARY,BORDER,12));
        s.setPadding(dp(10),dp(8),dp(10),dp(8));
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,choices);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);s.setSelection(Math.max(0,Math.min(choices.length-1,selected)));
        host.addView(s,margin(0,3,0,8));return s;
    }

    private interface IntCallback{void onChange(int index);}
    private interface BoolCallback{void onToggle(boolean checked);}

    private static final class SegmentGroup {
        final Button[] buttons;
        final Drawable[] activeBgs, inactiveBgs;
        int selectedIndex;
        SegmentGroup(Button[] buttons,Drawable[] activeBgs,Drawable[] inactiveBgs,int selectedIndex){
            this.buttons=buttons;this.activeBgs=activeBgs;this.inactiveBgs=inactiveBgs;this.selectedIndex=selectedIndex;
        }
        void setSelected(int idx){
            selectedIndex=idx;
            for(int i=0;i<buttons.length;i++){
                boolean active=(i==idx);
                buttons[i].setBackground(active?activeBgs[i]:inactiveBgs[i]);
                buttons[i].setTextColor(active?Color.rgb(250,252,255):Color.rgb(148,168,192));
            }
        }
        void setEnabled(boolean enabled){
            for(Button b:buttons)b.setEnabled(enabled);
        }
    }

    private SegmentGroup segmentedBar(LinearLayout host,String[] labels,int initial,IntCallback onSelect){
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(4),dp(4),dp(4),dp(4));
        bar.setBackground(bordered(SURFACE,BORDER,12));
        Button[] btns=new Button[labels.length];
        Drawable[] activeBgs=new Drawable[labels.length];
        Drawable[] inactiveBgs=new Drawable[labels.length];
        int sel=clampIndex(initial,labels.length-1);
        SegmentGroup group=new SegmentGroup(btns,activeBgs,inactiveBgs,sel);
        for(int i=0;i<labels.length;i++){
            final int idx=i;
            Button b=new Button(this);b.setAllCaps(false);b.setText(labels[i]);b.setTextSize(12);
            b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
            b.setMinHeight(dp(44));
            activeBgs[i]=bordered(TEAL,ACCENT,10);
            inactiveBgs[i]=bordered(SECONDARY,BORDER,10);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1f);
            lp.setMargins(dp(2),0,dp(2),0);
            bar.addView(b,lp);
            btns[i]=b;
            b.setOnClickListener(v->{
                group.setSelected(idx);
                if(onSelect!=null)onSelect.onChange(idx);
            });
        }
        group.setSelected(sel);
        host.addView(bar,margin(0,2,0,6));
        return group;
    }

    private LinearLayout styledCheckRow(LinearLayout host,CheckBox cb,String title,boolean initial,BoolCallback onChange){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12),dp(10),dp(14),dp(10));
        row.setMinimumHeight(dp(50));
        cb.setChecked(initial);
        cb.setButtonTintList(new ColorStateList(
            new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},
            new int[]{ACCENT,MUTED}));
        cb.setClickable(false);cb.setFocusable(false);
        row.addView(cb,new LinearLayout.LayoutParams(-2,-2));
        TextView tv=label(title,14,INK,true);
        tv.setPadding(dp(8),0,0,0);
        row.addView(tv,new LinearLayout.LayoutParams(0,-2,1f));
        row.setBackground(bordered(initial?Color.rgb(18,44,62):SECONDARY,initial?ACCENT:BORDER,12));
        row.setOnClickListener(v->{
            boolean next=!cb.isChecked();
            cb.setChecked(next);
            row.setBackground(bordered(next?Color.rgb(18,44,62):SECONDARY,next?ACCENT:BORDER,12));
            if(onChange!=null)onChange.onToggle(next);
        });
        host.addView(row,margin(0,2,0,6));
        return row;
    }

    private SeekBar styledSeekBar(LinearLayout host,int max,int initial,IntCallback onChange){
        SeekBar sb=new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(clampIndex(initial,max));
        sb.setMinimumHeight(dp(44));
        sb.setPadding(dp(14),dp(8),dp(14),dp(8));
        GradientDrawable bg=rounded(BORDER,6);
        GradientDrawable fg=rounded(ACCENT,6);
        ClipDrawable clip=new ClipDrawable(fg,Gravity.START,ClipDrawable.HORIZONTAL);
        LayerDrawable layer=new LayerDrawable(new Drawable[]{bg,clip});
        layer.setId(0,android.R.id.background);
        layer.setId(1,android.R.id.progress);
        sb.setProgressDrawable(layer);
        GradientDrawable thumb=new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setSize(dp(24),dp(24));
        thumb.setColor(ACCENT);
        thumb.setStroke(dp(2),LIGHT);
        sb.setThumb(thumb);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int progress,boolean fromUser){
                if(fromUser && onChange!=null)onChange.onChange(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar s){}
            @Override public void onStopTrackingTouch(SeekBar s){}
        });
        host.addView(sb,margin(0,0,0,4));
        return sb;
    }

    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
}
