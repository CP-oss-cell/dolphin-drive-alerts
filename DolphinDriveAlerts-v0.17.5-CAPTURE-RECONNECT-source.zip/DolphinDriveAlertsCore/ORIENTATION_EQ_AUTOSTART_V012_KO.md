# Dolphin Drive Alerts v0.12 — 화면 회전 + EQ + 자동 백그라운드

버전: `0.12.0-orientation-eq-autostart-keymap` / versionCode 12

## 1. 화면 회전
사용자가 제공한 Screen Orientation Control 7.10.1의 실제 구현 원리를 재구현했다.

핵심:
- `SYSTEM_ALERT_WINDOW`
- 0×0 `TYPE_APPLICATION_OVERLAY`
- `WindowManager.LayoutParams.screenOrientation`
- 앱별 회전 규칙 저장
- 접근성 foreground event + UsageStats 1초 fallback
- 가로/가로반전/세로/세로반전/센서가로/센서전체/순정

ADB `wm user-rotation`에 의존하지 않는다. Overlay/UsageStats 권한은 ADB permission bootstrap에서 자동 적용을 시도하고 수동 설정 버튼도 유지한다.

주의: 실제 물리 display 방향 강제 방식이다. 런처 중앙 embedded pane 하나만 독립 회전시키는 기능으로 검증된 것은 아니다.

## 2. 이퀄라이저
사용자가 제공한 Equalizer APK에서 확인한 Android 표준 AudioEffect 접근을 기반으로 독립 재구현했다. APK의 서명우회/광고/결제 코드는 사용하지 않는다.

사용자 UI:
- 저음 (Bass) -10 ~ +10
- 중음 (Mid) -10 ~ +10
- 고음 (Treble) -10 ~ +10
- Centerpoint 360 공간 확장 ON/OFF
- Sound Focus
  - Reference: 원음 중심
  - Surround: 공간감 확대
  - Cinema: 저음/공간감 강조

내부:
- `Equalizer`
- `BassBoost`
- `Virtualizer`
- `LoudnessEnhancer`
- audio session 0 Global Mix 우선
- `OPEN_AUDIO_EFFECT_CONTROL_SESSION` / `CLOSE_AUDIO_EFFECT_CONTROL_SESSION` 세션 fallback
- 설정 SharedPreferences 영구 저장 및 서비스 재시작 시 자동 재적용

`Centerpoint 360`, `Sound Focus`는 UI 구분명이며 Bose/현대/기아 순정 DSP 알고리즘을 복제한 기능이 아니다. 표준 Android 효과로 비슷한 사용 목적을 제공하는 자체 프리셋이다.

## 3. 자동 백그라운드 실행
- 기본 ON
- 최초 설치 후 앱 1회 실행
- 이후 BOOT / Android·BYD·Qualcomm Quick Boot / USER_PRESENT·USER_UNLOCKED / SCREEN_ON / ACTION_POWER_CONNECTED / 앱 업데이트 / BYD ACC_ON·IGN_ON·ACC_MODE_CHANGED에서 foreground service 자동 시작 요청
- ACC_OFF / ACTION_POWER_DISCONNECTED는 종료측 신호로 관찰만 하고 신규 service start는 하지 않음
- `START_STICKY`
- `stopWithTask=false`

강제 종료(Force stop) 후에는 Android 정책상 앱을 다시 한 번 실행해야 한다.

## 4. 유지된 v0.11 기능
- SubAI 기반 ACC/자율주행 경로
- 회생제동 Standard/High
- Snow ON/OFF
- SPORT mode
- 핸들 MENU/이전 3연타 차량 신호
- 기어/EPB
- ADB RSA 승인/권한 bootstrap
- 미확정 AVH/BSD/차선/앞차/DOW 자동 발화 금지

## 5. 아직 완료로 간주하지 않는 기능
- 지정앱 DPI: 기존 ADB `wm density` 경로는 여전히 실차 회귀 이슈이며 이번 v0.12의 화면 회전과 별개다.
- 지정앱 외부 앱 음성을 운전석 스피커로 강제 라우팅: 아직 미구현.
- 3연타 → 외부 AVAS 1회 패턴: 아직 미구현.
- EQ/회전/자동시작은 코드 구현 상태이며 한국형 Dolphin v0.12 실차 결과 전에는 `VERIFIED`가 아니다.


## DA-017 보강 — OverDrive v48.18 기반 핸들키 / 차량 전원 이벤트
- 기본 핸들 후보를 Android 추측값에서 BYD 정본 후보 `289=Mode/Menu`, `88=Previous`로 전환. Android MENU/BACK은 fallback으로만 유지.
- 전체 알려진 BYD 키 15개(87/88/289/291/292/293/294/304/305/313/317/302/303/306/312)를 RAW 로그에서 이름으로 표시.
- 302/303/306/312는 펌웨어 전용 long-key 코드로 취급하고 3연타 기본키와 분리.
- 기존 저장값 `MENU`/`BACK`은 각각 `BYD_MODE`/`BYD_PREVIOUS`로 자동 마이그레이션.
- OverDrive APK 원본 문자열에서 확인한 `com.byd.action.ACC_ON`, `com.byd.action.ACC_OFF`, `com.byd.action.IGN_ON`, `com.byd.accmode.ACC_MODE_CHANGED`를 lifecycle 관찰에 추가.
- Android 표준 전원 액션은 `android.intent.action.ACTION_POWER_CONNECTED` / `ACTION_POWER_DISCONNECTED`로 교정.
- ACC_OFF/POWER_DISCONNECTED는 새 서비스를 시작하지 않는 stop-side 관찰 신호.
- `LOCKED_BOOT_COMPLETED`는 credential-protected SharedPreferences를 direct-boot 대응으로 옮기지 않은 상태라 이번 v0.12에는 무리하게 추가하지 않음.


## DA-017 2차 보강 — 저빈도 read-only discovery
- OverDrive v48.18 APK 문자열에서 실제 BYD device class를 추가 확인: AC, Charging, DoorLock, RearViewMirror, Engine, Light, Multimedia, PM2.5, Power, SafetyBelt, Sensor, Statistic, Tyre, VehicleHealth, Wiper.
- `ReadOnlySignalProbe`는 기존 핵심 8개 장치는 기존 주기로 유지하고, 신규 장치는 약 5초마다만 조회하여 vendor binder 부하를 제한한다.
- 신규 장치에서도 **파라미터 없는 `get*`/`is*` + 단순 반환형만** 허용한다. setter/enable/write 호출은 추가하지 않았다.
- 이 경로는 배터리/SOH/충전/타이어/12V/안전벨트/와이퍼/조명/공조/PM2.5 등 OverDrive 자동화 신호와 한국형 Dolphin의 실제 getter를 연결하기 위한 evidence 수집용이며, 의미/단위/지원 여부는 실차 확인 전 `VERIFIED`가 아니다.
- `DA017_V012_KEYMAP_115_AUDIT.tsv`: 115/115 분류, 미분류 0개.
- `DA017_V012_AUTOMATION_197_AUDIT.tsv`: 197/197 분류, 미분류 0개.
- 차량 write, 카메라/녹화, Cluster Cast, 범용 Automation engine은 v0.12에 활성화하지 않는다.
