# Dolphin Drive Alerts v0.17.4 — DA-012/DA-029 사운드 신호 로그 해석 개선

## 원본 증거: 2026-10-09 10:26:15~10:40:15 KST
- 실차 원본 ZIP: `DolphinDriveLogs_20261009_102615_890_1268ec42.zip`. 원본 로그 자체는 개인정보/차량정보 보존을 위해 배포용 소스 ZIP에 포함하지 않는다.
- 38,317 JSONL / 36,531 BYD raw 이벤트 / snapshot 795. `INSTRUMENT_DD_SOUND_FREQ` (`0x26100035`), `INSTRUMENT_DD_SOUND_TYPE` (`0x26100038`)에서 source `reference.instrument` + `instrument` 양쪽의 중복 이벤트 총 24개 관찰.
- 두 개 신호가 동일하게 3 → 0으로 변한 **후보 펄스 3개**:

| KST 시각 | FREQ/TYPE 활성 값 | 원점 복귀 | 근사 지속시간 | 가까운 snapshot |
|---|---|---|---:|---|
| 10:31:20.097 | 3/3 | 10:31:20.291 | 194ms | gearRaw=1, 0km/h |
| 10:31:33.800 | 3/3 | 10:31:33.993 | 193ms | gearRaw=1, 0km/h |
| 10:32:01.722 | 3/3 | 10:32:01.905 | 183ms | gearRaw=1, 0km/h |

- 주변 기록에 gearRaw 2 → 1 전환이 있다. 이는 연관 가능성일 뿐 **기어 의미, 음원 종류, 스피커 위치를 확정하는 증거가 아니다.**
- `getSoundFreq/getSoundType` 시작·종료 logcat 샘플은 0; 차량 snapshot probe 각각 36번 모두 0. 이는 순간 신호가 스냅샷 검사에서는 보이지 않는 현상과 일치함.
- Android logcat 2,000줄 끝부분만 시작/종료에 저장돼 중간 시점 10:31~10:32의 HAL/MCU 출력 로그를 확보할 수 없다.
- 셸 diagnostic 실패 1건: `lshal` 4초 timeout. `tinymix unavailable` 양쪽에서 발생했지만 command wrapper 자체 success=true. 전용 MCU/AVAS 물리 출력 로그는 없음.
- **판정**: `INSTRUMENT_SOUND_PAIR_SEEN / EXTERIOR_AVAS_UNVERIFIED`. 유효한 차량 *사운드 관련* 이벤트는 이미 있었지만 기존 코드가 일반 `byd_event`로만 남겨 상관분석/가시화하지 못했다. 이는 외부 스피커에서 음원이 출력되었다는 의미가 아니다.

## v0.17.4 실제 코드 변경
- 최신 v0.17.3 `DolphinDriveAlerts-v0.17.3-EQ-SOUND-FOCUS-source.zip` 기준, 신규 프로젝트나 별도 앱 설치 없이 누적 수정.
- `InstrumentSoundCandidateTracker.kt`(추가): 2개 ID의 raw 정수 혹은 `intValue` 파싱, 음수 sentinel 거부, 양쪽 listener 중복 80ms 제거, pair 시간창 400ms, START→END 및 지속시간 검출. 차량에 쓰기/음원출력 **절대 없음**.
- `RawSignalLogger.kt`: 원래 `byd_event` 기록을 보존하면서 자동 `instrument_sound_candidate` JSONL 추가. `phase`, `frequencyRaw`, `soundTypeRaw`, `startedAtMs`, `elapsedMs`, `speedKmH`, `gearRaw`, `frameAgeMs`, `externalSpeakerConfirmed:false`, `readOnly:true`, 미확정 해석 코드 저장. 기존 통합 로그 ZIP의 `logs/vehicle_events.jsonl`에 자동 포함.
- `app/build.gradle.kts`: versionCode 30, versionName `0.17.4-avas-log-correlation`.
- 기존 통합 로그 수집 버튼 2개 / 서비스·EQ·ADAS·음성·시동 자동실행·화면 분할·ADB권한/로그 UI 변경 없음.
- `tools/analyze_avas_log.py`: 과거/신규 ZIP 이벤트 오프라인 재검토 도구 (물리 AVAS 출력 확정 불가라는 판정 유지).

## 다음 실차 수용 테스트
1. 안전한 장소에서 주차한 뒤 통합 로그 **수집 시작**. 순정 주행 전자음 OFF/ON/OFF 시점 별도로 메모. 실제 AVAS 안전 기능을 강제로 OFF시키거나 무력화하는 개발용 조작 금지.
2. 주변 안전을 확보한 상태에서 순정 시스템이 제공하는 정상 주행 전자음 동작 및 정상 후진 동작 중 외부 청취자(또는 외부 녹음)가 소리를 확인한 순간을 적고, **수집 종료**.
3. ZIP에서 `instrument_sound_candidate` START/END와 두 ID 원본 `byd_event`/기어·속도 시각을 상관분석. Android audio dumpsys로 MCU 출력 단정하지 않음.
4. 녹음 시각과 이벤트가 일치한 경우에만 **AVAS 연관 후보** 판정 격상. MCU 출력 장치/물리 스피커 경로 증거 없이는 `VERIFIED` 불가.
5. 사용자가 만든 사람 목소리 WAV/MP3를 차량 외부 스피커로 보내는 기능, MCU 테스트톤 제어, 차량 AVAS/VESS 교체는 **이번 버전에 구현하지 않았음**.

## 검증 수준
- Kotlin 후보 신호/중복/비정상값 단독 컴파일·테스트 수행 가능.
- 원본 로그 3개 구간 오프라인 파서 재생.
- 기존 v0.17.3 EQ·자동실행·권한·ADAS·분할 회귀 스크립트 동일 내용 기반 버전 체크만 업데이트.
- 이 환경에서 Android SDK 전체 APK Gradle 빌드 및 차량 적용은 아직 수행되지 않음. GitHub Actions 성공/실차 성공 표시 금지.

**STATUS**: `DA-012 LOG_CORRELATION_IMPLEMENTED / EXTERIOR_OUTPUT_NOT_PROVEN / ANDROID_CI_PENDING / REALCAR_REVERIFY_REQUIRED`.
