# Dolphin Drive Alerts 0.9 실차참조 수정본

## 실제 반영

- 발화: `에코 모드`, `노멀 모드`, `스포츠 모드`, `스노우 모드`, `스노우 모드 오프`.
- 전용 운전석 AudioTrack stream 14 두 방식: legacy Attributes(Route 6), raw AudioTrack(Route 5) 개별 시험 선택; 실패 시 미디어 fallback 및 로그.
- 접근성 서비스에서 DPI ADB 호출을 UI 스레드에서 제거; 전용 worker로 전달하여 응답 중 앱 멈춤 감소.
- 별도 ADB 연결·DPI 140·순정 원복 시험 버튼.
- 지정 앱 정책의 오디오 선택은 **우리 앱의 알림음** 출력에만 적용. 외부 앱 자신의 스트림을 강제 변환하는 기능은 BYD vendor hook 없으면 불가. 작동한다고 표시하지 않음.
- AudioFeedback 참조의 기어/회생제동/노면(스노우)/스포츠 값은 기존 로직 유지.

## 실차 참조

- v30.5: 2026-09-16 실차 보고 기준 14번 legacy stream Route 5/6 운전석 출력 확인 (원본 ZIP 유지).
- AutoFeedback v1.0: energy recycle 2/3 = STANDARD/HIGH, road surface 1/2 = 일반/스노우, sports on=2.
- EVSound APK: 별도 사운드 합성·Audio API 흔적 존재. 순정 외부 보행자 경고(AVAS) 출력 검증 증거는 미확보.

## 여전히 필요한 실차 검증

- 0.8 즉시 강제 종료 실제 FATAL EXCEPTION stacktrace 미확보; 0.9 역시 실차에서 실행 확인 전입니다.
- 오토홀드 brake release 지연, BSD 좌우, 차선이탈, 앞차출발: getter/raw 수치와 이벤트 의미를 동작 시점에서 더 검증해야 합니다.
- 핸들 메뉴/이전 버튼 표준 keycode가 차량에서 전달되는지 아직 확인되지 않아 학습/RAW 버튼 캡처는 유지.
- 다른 앱 소리의 별도 stream 14 강제 라우팅, 외부 AVAS 커스텀 재생은 구현되었다고 주장하지 않습니다.
- ADB localhost:5555 사용은 실제 인증·보안 정책에 따라 실패할 수 있습니다. 시스템 권한을 무조건 얻는다는 뜻이 아닙니다.

운행 중 설정·DPI 시험은 지양하고 안전하게 정차한 상태에서 확인할 것.
