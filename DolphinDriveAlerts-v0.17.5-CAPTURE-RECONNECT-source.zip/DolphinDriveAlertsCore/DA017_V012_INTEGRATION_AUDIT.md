# DA-017 → Dolphin Drive Alerts v0.12 정적 통합 감사

기준: OverDrive v48.18 APK 정적 분석 + 현재 v0.12 소스. 이 문서는 **기능 존재/정적 매핑**이며 한국형 Dolphin 실차 VERIFIED가 아니다.

## 결론
- Key Mapping **115/115 분류 완료**, 미분류 0개.
- Automation 어휘 **197/197 분류 완료**, 미분류 0개.
- v0.12에 즉시 안전하게 반영할 항목은 차량 write가 아니라 **BYD 핸들키 정본, ACC/IGN lifecycle, 저빈도 read-only 신호 discovery**로 제한.
- 차량 제어/ADAS 설정/충전/시트/창문/조명/카메라/녹화/Cluster Cast/범용 Automation engine은 v0.12에서 활성화하지 않음.

## v0.12에 반영된 DA-017 항목
- BYD keyCode 15개 카탈로그 및 `289=Mode/Menu`, `88=Previous` 기본 3연타 후보; 기존 Android MENU/BACK은 fallback.
- BYD long-key `302/303/306/312` 독립 keyCode 기록.
- `ACC_ON / ACC_OFF / IGN_ON / ACC_MODE_CHANGED` 및 Android power action 교정.
- OverDrive APK에서 직접 확인된 BYD read device class 중 안전한 getter-only surface를 `ReadOnlySignalProbe`에 확장.
- 확장 장치는 기존 1초급 핵심 Probe와 분리해 약 5초마다 읽고 값을 cache하여 vendor binder 부하를 제한.

## Key Mapping 115 상태 집계
- `DEFER_ANDROID_SYSTEM_CONTROL`: 7
- `DEFER_AUTOMATION_ENGINE`: 2
- `DEFER_CAMERA_RECORDING_STACK`: 26
- `DEFER_CLUSTER_CAST`: 2
- `DEFER_DISPLAY_SYSTEM_CONTROL`: 5
- `DEFER_MEDIA_CONTROL`: 5
- `DEFER_VEHICLE_WRITE_REALCAR`: 64
- `PARTIAL_DA014_ORIENTATION`: 1
- `PARTIAL_LOCAL_AUDIO_COMPONENT`: 3

## Automation 197 상태 집계
- `DEFER_AUTOMATION_ENGINE`: 13
- `DEFER_CAMERA_RECORDING_STACK`: 20
- `DEFER_CLUSTER_CAST`: 2
- `DEFER_LOCAL_ANDROID_NETWORK_AUTOMATION`: 27
- `DEFER_VEHICLE_WRITE_REALCAR`: 86
- `PARTIAL_LOCAL_COMPONENT`: 4
- `V012_READ_DISCOVERY_SURFACE`: 36
- `V012_READ_RAW_EXISTING`: 9

## 안전 경계
- `V012_READ_*`는 getter/callback/broadcast를 읽거나 기록하는 단계이며 제어 성공을 뜻하지 않는다.
- `PARTIAL_*`은 유사한 로컬 구성요소가 있다는 뜻일 뿐 OverDrive와 동등한 기능 구현을 주장하지 않는다.
- `DEFER_VEHICLE_WRITE_REALCAR` 항목은 정차 → readback → 단일 write → 복구 확인 절차가 생기기 전에는 활성화하지 않는다.
- AEB/ESP/차선/제동 같은 안전 기능 비활성화는 별도 안전 검토 없이는 구현하지 않는다.

## 도메인 감사 결과
Camera/Recording/Surveillance/Remote/Charging/Trips/Seat/Cluster/Network 9개 상위 도메인의 v0.12 상태 분류를 완료했다. 활성 구현을 즉시 추가할 근거가 있는 항목은 없으며, Charging/SOH는 getter-only read discovery로만 유지한다.

상세: `DA017_V012_DOMAIN_AUDIT.md`.

산출물: `DA017_V012_KEYMAP_115_AUDIT.tsv`, `DA017_V012_AUTOMATION_197_AUDIT.tsv`, `DA017_V012_DOMAIN_AUDIT.md`.
