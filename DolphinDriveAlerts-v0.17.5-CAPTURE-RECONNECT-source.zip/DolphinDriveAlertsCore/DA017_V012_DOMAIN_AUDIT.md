# DA-017 → v0.12 도메인별 상세 정적 감사

기준: OverDrive v48.18 정적 분석 + Dolphin Drive Alerts v0.12 소스. 이 문서는 기능 존재/구조 비교이며 한국형 Dolphin 실차 VERIFIED가 아니다.

| 도메인 | OverDrive v48.18 확인 구조 | 현재 v0.12 상태 | v0.12 처리 | 다음 단계 |
|---|---|---|---|---|
| Camera / Live View | DiLink 4 AVMCamera + DiLink 5 QCarCam, 0=Front/1=Right/2=Rear/3=Left, native owner/release guard, head-unit/cluster projection, blind-spot/fisheye | `MISSING_ACTIVE_STACK` | 활성 구현하지 않음 | 한국형 Dolphin camera ownership/read-only capability부터 별도 이슈/실차 검증 |
| Recording | H.264/AAC circular buffer, pre/post clip, MP4 mux, H.265/FPS/clip tier, telemetry/geotag, SD/USB/internal fallback, index DB, OEM CDR coexist | `MISSING_ACTIVE_STACK` | 활성 구현하지 않음 | Camera stack 검증 후 storage/power-loss/recovery 포함 별도 구현 |
| Surveillance | YOLO/TFLite + MOG2 + tracking, object/severity, ROI/schedule/safe-location, parked event/continuous/smart modes | `MISSING_ACTIVE_STACK` | 활성 구현하지 않음 | 주차 전원 지속성·카메라 점유·열/배터리 영향부터 검증 |
| Remote | embedded server/API, Remote Dev View frame/input/WebSocket, BYD Cloud, Telegram/Push/remote voice | `MISSING_SECURE_REMOTE_STACK` | 활성 구현하지 않음 | 인증·권한·암호화·원격 write 안전가드 설계 후 별도 이슈 |
| Charging / SOH | charging state/history/tariff/SOC, current limit, schedule/start charging, SOH/ABRP | `PARTIAL_READ_DISCOVERY` | `BYDAutoChargingDevice`, Energy/Power/VehicleHealth getter-only 증거 수집만 유지 | 실차 getter 명/단위/readback 확정 후 read UI; write는 별도 검증 |
| Trips | trip DB/history/summary/range/DNA/recover/external storage | `RAW_INPUTS_ONLY` | 기존 RAW/차량상태 로그만 유지 | 실차 신호 정확도 확정 후 trip DB/summary를 별도 구현 |
| Seat Positions | 저장/호출 seat + mirror position, 차량 메모리 연계 | `READ_DISCOVERY_ONLY` | mirror/body/device getter discovery만 유지, seat/mirror write 없음 | 실제 seat/mirror GET/SET 경로를 정차 상태에서 단계 검증 |
| Cluster Cast | app/camera/nav map을 driver cluster로 projection/cast, stop/restore | `MISSING_PROJECTION_STACK` | 활성 구현하지 않음 | 디스플레이 ID/권한/복원 경로 read-only 조사 후 별도 구현 |
| Network / Integration | Hotspot/Wi-Fi/Bluetooth/Data, MQTT, Tailscale/Cloudflared/Zrok/Sing-box, PWA/Telegram | `MISSING_AUTOMATION_REMOTE_STACK` | 차량 앱 핵심 v0.12 범위에서 제외 | 필요 기능별 최소권한 + 인증/비밀값 저장 정책으로 분리 |

## v0.12 최종 판단
- **즉시 반영 유지**: BYD 핸들키 정본, ACC/IGN lifecycle, getter-only 저빈도 read-only discovery.
- **추가 활성화하지 않음**: Camera/Recording/Surveillance/Remote/Trips/Seat write/Cluster/Network automation.
- Charging/SOH는 이번 v0.12에서 제어가 아니라 **evidence 수집면만** 확장됨.
- Camera/Recording 계열은 일반 Android Camera2 대체 구현으로 간주하지 않는다. OverDrive의 DiLink4/5 vendor camera + native ownership/release 구조가 핵심이므로 별도 검증 전 모방 구현 금지.
- Remote/Network 계열은 인증·원격입력·터널·차량 write를 포함하므로 기능 편의보다 접근통제/복구/감사로그를 먼저 설계한다.

## DA-017 잔여 경계
Key Mapping 115/115, Automation 197/197, 9개 상위 도메인의 정적 분류는 완료했다. 다만 OverDrive의 290개 Web API endpoint 각각을 현재 Dolphin Drive 함수에 1:1 연결한 것은 아니므로 DA-017을 `REALCAR_VERIFIED` 또는 완전 구현 완료로 승격하지 않는다. 이후 신규 기능 구현은 중복 없는 별도 DA 이슈로 분리한다.
