# Dolphin Drive Alerts v0.15 — EVSound 분석 결과 중 요청 기능에 직접 필요한 항목만 적용

## 사용자 확정 지시
- v0.14는 아직 미빌드. v0.15는 v0.14 모든 기능(분할·시동 자동 실행·통합 로그) 그대로 유지.
- **추가 금지**: EVSound 주행 가상 엔진/차량 효과음, 4채널 주행음, 속도 감응 볼륨(SVC), 별도 EVSound 앱 메뉴, 5초 SVC 시험 UI, WAV 81개 재배포. 사용자가 요청하지 않은 기능을 추가하지 않는다.
- 반영 대상: 사용자가 이미 요청한 3밴드 Bass/Mid/Treble, Reference/Surround/Cinema/공간확장과 직접 연관된 오디오 세션 안정성. 내비 5개 운전석 전용 라우팅은 별도 권한/출력 경로 없이 성공이라고 표시하지 않는다.

## 실제 소스 변경
1. `audio/GlobalEqualizerEngine.kt`:
   - EVSound 확인 경로 `OPEN/CLOSE_AUDIO_EFFECT_CONTROL_SESSION`, `AUDIO_SESSION`를 세션 생명주기 참조로 유지하고 세션 열림/닫힘에 따라 효과 attach/release.
   - `AudioEffect.hasControl()` 확인. 제어권이 없는 세션의 파라미터를 임의 설정하지 않음.
   - 효과별 독립 처리: Equalizer 오류가 Virtualizer/Loudness와 섞여 전체 엔진이 실패하지 않도록 분리.
   - 3밴드 적용 후 `Equalizer.getBandLevel()` 및 `enabled`, `setEnabled()` 결과로 **Android API 수준**에서 읽기 확인. 성공은 물리 스피커 청감 증거와 다름.
   - EQ/BassBoost/Virtualizer/Loudness의 기존 enabled/강도/레벨을 최초 attach 때 저장한 뒤 OFF/종료 때 가능한 범위에서 복원. 다른 앱의 설정을 무조건 0/비활성으로 덮지 않음.
   - 글로벌 세션 0은 레거시 fallback으로만 사용, 별도 세션 열림 때 이중 적용 방지. 세션 0은 최신 Android에서 deprecated/미지원 가능.
   - `audio_tuning_runtime` pref에 마지막 API 상태를 기록하여 UI에 상태 표시. 실차 VERIFIED나 실제 청감 성공 문구로 둔갑시키지 않음.
2. `ui/AudioTuningActivity.kt`: 기존 3밴드·3모드·Centerpoint UI 보존, 별도 로그 버튼 없이 오디오 효과의 마지막 API 적용 상태 한 줄만 표시.
3. `app/build.gradle.kts`: versionCode 15 / versionName 0.15.0-eq-session-stability.
4. 신규 검증 `tools/verify_eq_v015.py` 및 버전 보존 게이트 `tools/verify_unified_log_v015.py`/`verify_split_sequence_v015.py`.

## 네비 5종 운전석 출력의 실제 경계
- `ExternalAppAudioRouter`는 아직 다른 UID의 오디오를 운전석 스피커로 이동시키는 기능이 아니다. 원본 EVSound APK에도 UID AudioPolicy 이동 / `MODIFY_AUDIO_ROUTING` 구현이 발견되지 않았다.
- TMAP, NAVER Maps, KakaoMap, Atlan3D, MCon K의 외부 앱 출력은 **이번 EQ 개선만으로 해결되지 않는다**. BYD 실제 운전석 출력 경로와 cross-UID routing 권한 없이는 단순 `AudioTrack(stream14)` 방식으로 구현 완료라고 할 수 없다.
- 앱 자체 음성 stream14와 타 앱 소리 라우팅은 독립 기능이다. 운전석을 가리키는 가짜 옵션 활성/동작 성공 출력 금지.

## 검증 범위
- 정적 게이트 v0.15 신규 19개 + v0.14 로그 게이트 41개 + 보존 기능 게이트 145개 = 205 항목 (결과는 `v015_static_gates.log`).
- 변경된 이퀄라이저 엔진 및 저장 설정의 Kotlin typed Android stub 독립 컴파일 성공.
- **전체 Gradle Android APK 빌드 / 차량 물리 청감 / OEM 권한**은 수행한 것으로 표시하지 않는다. 사용자가 요청하지 않은 별도 실차 검증 프로토콜을 필수 단계로 요구하지 않으며, GitHub Actions가 APK 컴파일 여부를 자동 판단하도록 구성한다.
- Android 표준 AudioEffect만으로 OEM 차량의 전체 오디오나 개별 내비 앱의 소리를 제어할 수 있다고 보장하지 않는다.
