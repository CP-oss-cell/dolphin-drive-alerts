# Dolphin Drive Alerts v0.16.5 — SubAI / AutoFeedback 회생제동 알림 실제 누락 경로 수정

## 범위
이 빌드는 **회생제동 스탠다드·하이 음성 미작동** 원인만 바로잡는 소규모 수정입니다. 기존 스포츠·스노우·분할·시동·EQ 등의 기능은 변경하지 않습니다. 참조 앱 추가 설치 메뉴를 만들지 않습니다.

## 분석한 원본
- `BydSubAI-beta_v13.zip` 안 `BydAutoService.java`: `AbsBYDAutoEnergyListener.onEnergyRecycleChanged`, `AbsBYDAutoSettingListener.onDataEventChanged`, `handleDeviceEventLogic`에서 `ENERGY_RECYCLE` 또는 `SET_DR_ENERGY_FB`를 `handleEnergyRecycle`로 전달. 2→standard, 3→high.
- `Byd_AutoFeedBack_v1.0.apk`: `com.poorgrammera.adasnoti.BydAutoService$5.onEnergyRecycleChanged`와 `BydAutoService.handleEnergyRecycle(int)` 안 `playRawAudio` 2개 분기 확인.
- 사용자 실차 `DolphinDriveLogs_20261008_195909_444_8f775ba4.zip`: `setting` 이벤트 **0x34100022 / SET_DR_ENERGY_FB / intValue=2 및 intValue=3**를 수신. 기존 Dolphin `reference.energy`는 등록되어 있고 스포츠·스노우를 수신하지만 `reference.setting` 자체 등록이 없어 회생제동 알림 트리거 누락.

## 변경 내용
`ReferenceVehicleEventBridge.kt`에 `AbsBYDAutoSettingListener` 등록을 추가해 BYD `BYDAutoSettingDevice`에서 받는 `onDataEventChanged`를 기존 `processEvent()`로 전달. FeatureIds 필드 누락에 대비해 **실차 로그에서 확인한 0x34100022**를 추가 조건으로 사용. `handleRecycle()`의 상태별 1회 처리(동일값 반복 무시) 유지.

## 실차 로그와 검증 경계
- 사용자가 보고한 스포츠/스노우 정상은 건드리지 않음.
- Kotlin 최소 타입 스텁으로 **실제 수정한 전체 ReferenceVehicleEventBridge 파일**을 컴파일, 가짜 Setting device 2→2→3 입력으로 `REGEN_STANDARD,REGEN_HIGH` 각 1회 및 스포츠 보존 검사 통과.
- **에코·노멀은 별도 문제**. 위 두 원본에서 `onOperationModeChanged(1/2)`는 **스포츠 해제/스포츠 켜짐**. 1을 ECO나 NORMAL로 자동 간주하면 허위 안내가 됩니다. 둘을 구분하는 실제 차량 모드 신호가 원본 소스에 확정되기 전 임의 매핑하지 않음.
- 전체 Android Gradle 빌드와 새 APK 실차 동작은 아직 수행되지 않음. 이 소스는 GitHub Actions 빌드 후보.
