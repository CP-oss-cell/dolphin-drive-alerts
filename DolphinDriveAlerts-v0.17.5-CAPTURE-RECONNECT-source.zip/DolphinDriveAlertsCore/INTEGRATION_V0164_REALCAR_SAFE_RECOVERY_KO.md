# Dolphin Drive Alerts v0.16.4 — 실차 음향·화면 보호 및 기능 회귀 분석

## 증거
- 사용자의 직접 보고: 회생제동 에코/하이, 에코/노멀, 오토홀드 체결/해제, BSD·차선·앞차출발 미출력; MCon K 음성 운전석 지정 미동작; MCon K+YouTube 분할 20:80 요청 → 50:50으로 MCon K+우리 앱 실행; DPI가 시스템 전체 변경 후 순정 UI 비율 이상; EQ 음질 악화; 미디어 자동재생 안 됨; 회전 미동작.
- 파일: `DolphinDriveLogs_20261008_195909_444_8f775ba4.zip` (원본 사용자에게 보존), session 19:59:09~20:27:12, 70,891 JSONL events / 1,584 snapshots. ADB shell 17 성공·1 실패.
- raw valid signal gap: energyFeedbackRaw 65535 (전 스냅샷), driveInterfaceRaw 2 (전 스냅샷), avhRaw 0/1, bsdRaw 1/2; DiPilot class unavailable. 경고 신호 의미 미확정, 자동 발화로 승격 금지.

## v0.16.4 실제 코드 수정
1. `DensityController`: `wm density set/reset` 자동 호출 전면 차단. 앱별 DPI 보장 불가 상태로 명확히 표시. OEM 디스플레이의 순정 스케일을 보존하기 위해 이전 앱이 남긴 override까지 임의로 자동 리셋하지 않음. `AppPolicyActivity` 실행 버튼은 DPI와 관계없이 대상 앱 실행 가능. 진짜 앱별 DPI 및 순정 UI 원복은 별도 OEM 원값 확보 이슈.
2. `GlobalEqualizerEngine`: session 0 글로벌 EQ 제거; 활성 오디오 세션에 한해 3밴드 ±3dB 제한 적용·readback·복구; BassBoost/Virtualizer/LoudnessEnhancer 동시 생성/가중 증폭 제거. 360/SoundFocus는 순정 DSP 접근 미확정으로 `UNSUPPORTED_OEM_DSP` 상태 표시. 사용자가 원한 현대/기아 동등 음향은 **미구현**.
3. `VehicleSplitEngine`: 두 선택 앱이 `dumpsys activity activities` 모두 실제 존재하는지 확인하고 실패 시 성공 표시하지 않음; `20:80` 명령 응답 성공만으로 적용 성공 처리하지 않음. 미확정 픽셀 비율은 실패/미확인. 설치된 원본 AutoSplit 실제 profileId 연결 경로는 유지.
4. `MediaPlaybackObserver` + `AutoLaunchSequenceService`: 대상 MediaSession 생성 지연을 최대 2초 대기하고 `PLAYING` readback 확인. 재생 실패 시 HOME 복귀를 막아 플레이어를 전면에 남김. 시동 이벤트 수신·앱 실행 자체는 사용자 실차 성공 미확정.
5. 차내 안전 경고·회생제동·오토홀드·차선·BSD·앞차출발은 **유효 신호/SDK 이벤트를 확보할 때까지 자동 발화 값을 조작하지 않음**. DiPilot SDK `ClassNotFoundException`은 별도 호환성 조사 필요. 화면 회전 문제도 아직 해결 미확정.

## 검증과 한계
- 29개 신규 구조 회귀 검사/패키징 무결성 검사. 전체 Android Gradle CI 및 물리 차량 동작은 아직 별도 성공 근거 없음.
- 이미 설치된 구버전이 `wm density`를 변경한 내역의 순정 UI 크기는 이 수정본이 자동으로 원복하지 않는다. 임의의 `wm density reset`으로 OEM 전용 배율을 망가뜨리지 않도록 보호.
- MCon K 등 타 앱의 운전석 출력은 `MODIFY_AUDIO_ROUTING`/BYD 출력 정책 권한 미확보로 미해결.
