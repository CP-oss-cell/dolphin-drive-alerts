package android.hardware.bydauto.dipilot;

import android.hardware.IBYDAutoEvent;
import android.hardware.IBYDAutoListener;
import android.hardware.bydauto.BYDAutoEventValue;

/**
 * Compile-time compatibility stub only.
 * On a BYD head unit the platform framework class is expected to win via parent-first loading.
 * Methods mirror callbacks observed in BeetleLauncher 1.713's ProbeDiPilotListener.
 */
public abstract class AbsBYDAutoDiPilotListener implements IBYDAutoListener {
    @Override public void onError(int errCode, String errMessage) {}
    @Override public void onDataChanged(IBYDAutoEvent event) {}
    @Override public void onDataEventChanged(int eventType, BYDAutoEventValue eventValue) {}

    public void onAlarmTypeChanged(int state) {}
    public void onAEBDecActiveChanged(int state) {}
    public void onFrontCarStartStateChange(int state) {}
    public void onDriveDepartureStateChanged(int state) {}
    public void onDrivieDepartureStateChanged(int state) {}
    public void onOpenDoorAlertStateChanged(int state) {}
    public void onLeftBehindReminderStateChanged(int state) {}
    public void onControlLossWarningStateChanged(int state) {}
    public void onFrontTrafficCrossAlertStateChanged(int state) {}
    public void onRearTrafficCrossAlertStateChanged(int state) {}
    public void onFrontTrafficBrakeAlertStateChanged(int state) {}
    public void onRearTrafficBrakeAlertStateChanged(int state) {}
    public void onRearCrashAlertStateChanged(int state) {}
    public void onSideDistanceWarningStateChanged(int state) {}
    public void onCollisionWarningStateChanged(int state) {}
    public void onPredictCrashAlertStateChange(int state) {}
    public void onEmergencyBrakeWarningStateChanged(int state) {}
    public void onBlindMonitorStateChanged(int state) {}
    public void onBlindMonitorStateChanged1(int state) {}
    public void onBlindMonitorStateChanged2(int state) {}
}
