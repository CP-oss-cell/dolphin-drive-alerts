package com.byd.dolphin.drivealerts.steering

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File

object SteeringTriggerPreferences {
    private const val PREF = "steering_one_shot"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_SOUND_PATH = "sound_path"
    private const val KEY_SOUND_NAME = "sound_name"

    fun enabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, value).apply()

    // Old learning/mode preferences are intentionally ignored from v0.17.0 onward.
    // Both proven MENU and PREVIOUS codes are always recognized while enabled.

    fun soundFile(context: Context): File? = prefs(context).getString(KEY_SOUND_PATH, null)
        ?.let(::File)?.takeIf { it.isFile && it.canRead() }
    fun soundName(context: Context): String = prefs(context).getString(KEY_SOUND_NAME, null) ?: "기본 음성: 빵빵, 차 좀 지나갈게요"

    fun importSound(context: Context, uri: Uri): Result<String> = runCatching {
        val app = context.applicationContext
        val name = displayName(app, uri) ?: "custom_one_shot_audio"
        val dir = File(app.filesDir, "one_shot").apply { mkdirs() }
        dir.listFiles()?.forEach { runCatching { it.delete() } }
        val target = File(dir, "custom_audio.bin")
        app.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= 25L * 1024L * 1024L) { "음성파일은 25MB 이하만 지원합니다." }
                    output.write(buffer, 0, n)
                }
                require(total > 0L) { "빈 파일입니다." }
            }
        } ?: error("선택한 파일을 읽을 수 없습니다.")
        prefs(app).edit().putString(KEY_SOUND_PATH, target.absolutePath).putString(KEY_SOUND_NAME, name).apply()
        CoreLog.i("STEERING", "custom one-shot imported name=$name bytes=${target.length()}")
        name
    }

    fun clearSound(context: Context) {
        soundFile(context)?.let { runCatching { it.delete() } }
        prefs(context).edit().remove(KEY_SOUND_PATH).remove(KEY_SOUND_NAME).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun displayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
}
