package com.byd.dolphin.drivealerts.model

enum class Gear { P, D, N, R, UNKNOWN }
enum class RegenMode { STANDARD, HIGH, UNKNOWN }
enum class DriveMode { ECO, NORMAL, SPORT, UNKNOWN }

data class RawVehicleFrame(
    val timestampMs: Long = System.currentTimeMillis(),
    val speedKmH: Float? = null,
    val gearRaw: Int? = null,
    val epbRaw: Int? = null,
    val brakePedalRaw: Int? = null,
    val avhRaw: Int? = null,
    val bsdRaw: Int? = null,
    val laneOffsetRaw: Int? = null,
    val tjaRaw: Int? = null,
    val driveInterfaceRaw: Int? = null,
    val energyFeedbackRaw: Int? = null,
    val driveConfigRaw: Int? = null,
    val deviationRaw: Int? = null,
    val pcwAlarmRaw: Int? = null,
    val laneLineStateRaw: Int? = null,
    val radarDistances: IntArray? = null
)
