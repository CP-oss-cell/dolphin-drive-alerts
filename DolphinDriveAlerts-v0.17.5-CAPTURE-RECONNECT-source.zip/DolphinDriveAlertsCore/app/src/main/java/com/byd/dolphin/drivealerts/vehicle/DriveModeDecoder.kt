package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.AlertEvent

/**
 * User's Korean Dolphin three-position drive-mode hypothesis (2026-10-08):
 * 0 NORMAL (not yet observed), 1 ECO (user-confirmed playback), 2 SPORT. This pertains ONLY to ENERGY_OPERATION_MODE,
 * not ADAS_ACC_MODE / INSTRUMENT drive interface / regeneration / snow mode.
 * Values 1 and 2 were seen in BOTH user logs (0x2120000e);
 * the user directly reports 1 is ECO and 2 is SPORT. NORMAL raw=0 remains UNVERIFIED.
 */
internal object DriveModeDecoder {
    fun fromEnergyOperationMode(raw: Int): AlertEvent? = when (raw) {
        0 -> AlertEvent.DRIVE_NORMAL
        1 -> AlertEvent.DRIVE_ECO
        2 -> AlertEvent.DRIVE_SPORT
        else -> null
    }
}
