package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.RotationPolicy
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

class MainActivity : Activity() {
    private lateinit var unifiedCaptureStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(buildUi())
        } catch (t: Throwable) {
            setContentView(TextView(this).apply {
                text = "Dolphin Drive Alerts SAFE START\n\nUI 초기화 오류: ${t.javaClass.simpleName}: ${t.message}\n\n이 화면이 보이면 앱 자체 실행은 정상입니다."
                textSize = 18f
                setPadding(32, 32, 32, 32)
            })
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure {
                Toast.makeText(this, "차량 감시 서비스 시작 실패: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 24, 30, 30)
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "Dolphin Drive · 0.17.0 · 음성 안내 / 분할 / 자동실행"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "한국형 돌핀: 오버레이는 순정 설정, 접근성·알림 접근·사용기록은 승인된 ADB를 통한 설정 및 상태 확인."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val raw14 = RadioButton(this).apply { text = "운전석(raw14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(raw14); route.addView(media); box.addView(route)
        when (AlertPreferences.route(this)) {
            OutputRoute.DRIVER_STREAM14 -> driver.isChecked = true
            OutputRoute.DRIVER_RAW14 -> raw14.isChecked = true
            OutputRoute.MEDIA -> media.isChecked = true
        }
        route.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setRoute(this, when (id) {
                driver.id -> OutputRoute.DRIVER_STREAM14
                raw14.id -> OutputRoute.DRIVER_RAW14
                else -> OutputRoute.MEDIA
            })
        }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개 + 단발 기본음 남/여 2개(총 60개)를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        // Real-car verified: keep a single ON/OFF switch.
        // Vehicle event listener and fallback KeyEvent detector remain active in DrivingAlertService.
        box.addView(section("핸들 메뉴/이전 버튼 3연타"))
        box.addView(CheckBox(this).apply {
            text = "핸들 3연타 단발 음성 ON/OFF"
            isChecked = SteeringTriggerPreferences.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                SteeringTriggerPreferences.setEnabled(this@MainActivity, checked)
            }
        })

        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(CheckBox(this).apply {
            text = "시동 시 자동 백그라운드 실행"
            isChecked = AlertPreferences.autoStartEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> AlertPreferences.setAutoStartEnabled(this@MainActivity, checked) }
        })
        box.addView(TextView(this).apply {
            text = "기본값 ON. 최초 설치 후 앱을 1회 실행하면 이후 BOOT_COMPLETED, Android/BYD/Qualcomm Quick Boot, USER_PRESENT/USER_UNLOCKED, SCREEN_ON, ACTION_POWER_CONNECTED, 앱 업데이트와 BYD ACC_ON/IGN_ON/ACC_MODE_CHANGED 신호에서 foreground 서비스 시작을 재요청합니다. ACC_OFF/ACTION_POWER_DISCONNECTED는 종료측 상태로 기록만 하고 서비스를 새로 시작하지 않습니다. 서비스는 START_STICKY + stopWithTask=false라 최근 앱에서 지워도 계속 유지됩니다. 사용자가 Android 설정에서 강제 종료(force-stop)한 경우만 정책상 앱을 다시 한 번 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(Button(this).apply {
            text = "시동 앱 자동실행 · 여러 앱 순서/초 단위/미디어 재생 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AutoLaunchSettingsActivity::class.java)) }
        })
        box.addView(section("화면 분할 프로필"))
        box.addView(Button(this).apply {
            text = "2앱 분할 프로필 · 비율 % · 이름/바로가기 · 카메라 복원"
            setOnClickListener { startActivity(Intent(this@MainActivity,SplitProfilesActivity::class.java)) }
        })
        box.addView(section("통합 로그 수집"))
        box.addView(TextView(this).apply {
            text = "수집 시작을 누른 뒤 기능을 시험하고, 수집 종료를 누르면 해당 구간의 차량 RAW·음성·앱·오류 기록과 시스템 진단을 ZIP 하나로 Download 폴더에 저장합니다. 시동 주행알림 서비스는 수집 종료 후에도 정상 유지됩니다."
            textSize = 13f
        })
        unifiedCaptureStatus = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8) }
        box.addView(unifiedCaptureStatus)
        updateCaptureStatus()
        box.addView(Button(this).apply {
            text = "수집 시작"
            setOnClickListener {
                runCatching { DrivingAlertService.beginUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "수집 시작 요청 중… (서비스 알림에 결과 표시)" }
                    .onFailure { unifiedCaptureStatus.text = "시작 요청 실패: ${it.message}" }
            }
        })
        box.addView(Button(this).apply {
            text = "수집 종료"
            setOnClickListener {
                runCatching { DrivingAlertService.endUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "로그 저장 요청 중… (완료 시 상단 알림 및 Download 폴더 확인)" }
                    .onFailure { unifiedCaptureStatus.text = "저장 요청 실패: ${it.message}" }
            }
        })

        box.addView(section("ADB 권한 관리"))
        box.addView(Button(this).apply {
            text = "설치 앱 선택 · 배터리/알림/접근성/사용기록 ADB 권한 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AppPermissionManagerActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "차량에서 일반 권한 설정이 막힌 항목만 승인된 ADB로 적용합니다. 순정 화면 크기를 바꾸는 시험은 제공하지 않습니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "ADB 필수 권한 적용 · 접근성/알림 리스너/사용기록"
            setOnClickListener {
                isEnabled = false
                Thread {
                    val message = runCatching {
                        com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper.apply(this@MainActivity)
                            .lines.joinToString("\n")
                    }.getOrElse { "권한 설정 오류: ${it.javaClass.simpleName}: ${it.message}" }
                    runOnUiThread {
                        isEnabled = true
                        android.app.AlertDialog.Builder(this@MainActivity).setTitle("ADB 권한 적용 및 검증")
                            .setMessage(message).setPositiveButton("닫기", null).show()
                    }
                }.start()
            }
        })
        box.addView(section("디스플레이 DPI / 화면 회전 / 내비 음성"))
        box.addView(CheckBox(this).apply {
            text = "전역 화면 회전 ON/OFF"
            isChecked = RotationPolicy.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                RotationPolicy.setEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "회전 규칙 활성화" else "회전 오버레이 해제 · 순정 복원", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply { text = "디스플레이 DPI · 전역 회전 · 내비 5종 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(TextView(this).apply {
            text = "화면 회전은 Orientation Control의 0×0 투명 오버레이 방식이며 모든 앱에 전역 적용됩니다. 앱 선택·UsageStats 감시에 의존하지 않습니다."
            textSize = 13f
        })
        box.addView(TextView(this).apply {
            text = "접근성·알림 접근·사용기록은 차량 순정 메뉴가 차단되어 있으므로 위 'ADB 필수 권한 적용'에서 설정합니다. ADB 서버가 열려 있지 않으면 별도 승인된 PC ADB 연결이 필요합니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "화면 위 표시 권한 열기"
            setOnClickListener { SafeSettingsLauncher.open(this@MainActivity, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
        })
        box.addView(TextView(this).apply {
            text = "DPI는 전체 화면에만 명시적으로 적용되며 변경 전 기준값을 저장합니다. 타 앱 운전석 출력은 BYD 오디오 UID 라우팅 구현 전까지 진단 대상만 저장합니다."
            textSize = 13f
        })

        box.addView(section("이퀄라이저 / 음향 효과"))
        box.addView(Button(this).apply {
            text = "저음 · 중음 · 고음 / Centerpoint 360 / Sound Focus"
            setOnClickListener { startActivity(Intent(this@MainActivity, AudioTuningActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "3밴드 조절은 사용 가능한 오디오 세션에서만 적용되며, 순정 차량 DSP 기반 360/공간 음장은 아직 지원하지 않습니다."
            textSize = 13f
        })

        return root
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 재시동 후 같은 세션 복구 시도 (전원 OFF 구간은 누락 가능) · '수집 종료'로 ZIP 저장"
            UnifiedLogCapture.SAVING -> "저장 중 · 완료되면 상단 알림으로 안내"
            UnifiedLogCapture.FAILED -> "저장 실패 · '수집 종료'를 다시 눌러 재시도"
            else -> "대기 중 · '수집 시작'을 눌러주세요"
        }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }

}
