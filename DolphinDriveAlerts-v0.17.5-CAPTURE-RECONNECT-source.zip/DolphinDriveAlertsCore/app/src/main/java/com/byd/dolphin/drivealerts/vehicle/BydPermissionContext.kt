package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager

/**
 * Context used only when obtaining BYD framework devices.
 * It mirrors the proven SubAI client-side permission wrapper, but deliberately limits the
 * bypass to android.permission.BYDAUTO_* checks. This does not grant Binder/SELinux privileges.
 */
class BydPermissionContext private constructor(base: Context) : ContextWrapper(base.applicationContext) {
    private fun isByd(permission: String) = permission.startsWith(PREFIX)

    override fun checkPermission(permission: String, pid: Int, uid: Int): Int =
        if (isByd(permission)) PackageManager.PERMISSION_GRANTED else super.checkPermission(permission, pid, uid)

    override fun checkCallingOrSelfPermission(permission: String): Int =
        if (isByd(permission)) PackageManager.PERMISSION_GRANTED else super.checkCallingOrSelfPermission(permission)

    override fun checkCallingPermission(permission: String): Int =
        if (isByd(permission)) PackageManager.PERMISSION_GRANTED else super.checkCallingPermission(permission)

    override fun checkSelfPermission(permission: String): Int =
        if (isByd(permission)) PackageManager.PERMISSION_GRANTED else super.checkSelfPermission(permission)

    override fun enforceCallingOrSelfPermission(permission: String, message: String?) {
        if (isByd(permission)) return
        super.enforceCallingOrSelfPermission(permission, message)
    }

    override fun enforceCallingPermission(permission: String, message: String?) {
        if (isByd(permission)) return
        super.enforceCallingPermission(permission, message)
    }

    override fun enforcePermission(permission: String, pid: Int, uid: Int, message: String?) {
        if (isByd(permission)) return
        super.enforcePermission(permission, pid, uid, message)
    }

    companion object {
        private const val PREFIX = "android.permission.BYDAUTO_"
        fun wrap(context: Context): Context = if (context is BydPermissionContext) context else BydPermissionContext(context)
    }
}
