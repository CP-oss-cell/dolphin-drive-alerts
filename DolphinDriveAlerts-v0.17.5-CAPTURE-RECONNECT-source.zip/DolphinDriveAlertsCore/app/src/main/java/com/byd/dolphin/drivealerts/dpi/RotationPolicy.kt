package com.byd.dolphin.drivealerts.dpi

import android.content.Context

/** Device-wide orientation mode. No foreground-package rule or usage-access dependency. */
object RotationPolicy {
    private const val PREF = "global_rotation_v016"
    private const val MODE_PREF = "global_orientation_mode_v0169"
    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getBoolean("enabled", true)
    fun selected(context: Context): OrientationMode = runCatching {
        OrientationMode.valueOf(context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(MODE_PREF, OrientationMode.STOCK.name)!!)
    }.getOrDefault(OrientationMode.STOCK)
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
        applyCurrent(context)
    }
    fun setSelected(context: Context, selected: OrientationMode) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(MODE_PREF, selected.name).apply()
        applyCurrent(context)
    }
    fun applyCurrent(context: Context): Boolean =
        OrientationOverlayController.apply(context, mode(context, selected(context)))
    fun mode(context: Context, requested: OrientationMode): OrientationMode =
        if (enabled(context)) requested else OrientationMode.STOCK
}
