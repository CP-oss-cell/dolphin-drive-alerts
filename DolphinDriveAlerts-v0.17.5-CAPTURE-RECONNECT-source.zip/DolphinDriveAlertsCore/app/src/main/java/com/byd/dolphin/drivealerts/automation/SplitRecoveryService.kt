package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.util.CoreLog

/** Observes fullscreen transition and restores the *saved* percent only after leaving it.
 * Never interferes while the 360 camera is foreground. Needs BYD-local ADB authorization.
 */
class SplitRecoveryService : Service() {
    @Volatile private var running=false
    @Volatile private var generation=0
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val manager=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel("split_recovery","분할 화면 복원",NotificationManager.IMPORTANCE_LOW))
        startForeground(762, Notification.Builder(this,"split_recovery")
            .setContentTitle("분할 비율 복원 감시")
            .setSmallIcon(android.R.drawable.ic_menu_crop).build())
    }
    override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_STOP){running=false;generation++;stopSelf();return START_NOT_STICKY}
        val id=intent?.getStringExtra("id") ?: return START_NOT_STICKY
        val p=FeatureProfiles.splits(this).firstOrNull{it.id==id} ?: return START_NOT_STICKY
        running=true;val local=++generation
        Thread({watch(p,local)},"split-ratio-recovery").start()
        return START_NOT_STICKY
    }
    private fun watch(p:SplitProfile,token:Int) {
        var external=false;var attempts=0
        while(running && token==generation && FeatureProfiles.splitEnabled(this)) {
            try {
                Thread.sleep(5_000)
                val foreground=VehicleSplitEngine.screenToken(this) ?: continue
                val isTarget=foreground.contains(p.firstPackage)||foreground.contains(p.secondPackage)
                val isSelf=foreground.contains(packageName)
                // The OEM 360 camera may run in another package or Activity; never restore while external is top.
                if(!isTarget && !isSelf){external=true;continue}
                if(external && isTarget && attempts<3 && !Regex("(?i)(camera|surroundview|avm|com\\.byd\\.cdr)").containsMatchIn(foreground)) {
                    val ratio=VehicleSplitEngine.applyRatio(this,p.primaryPercent)
                    // Some OEM 360 activities dismantle the docked stack altogether.
                    // Recreate the saved pair only once the camera is no longer top.
                    val result=if(ratio.success)ratio else VehicleSplitEngine.launch(this,p)
                    CoreLog.i("SPLIT_RESTORE","profile=${p.id} pct=${p.primaryPercent} attempt=${attempts+1} result=${result.message}")
                    attempts++
                    if(result.success){external=false;attempts=0}
                }
            }catch (_:InterruptedException){Thread.currentThread().interrupt();break}
            catch(t:Throwable){CoreLog.w("SPLIT_RESTORE","watch failure: ${t.message}")}
        }
        if(token==generation) stopSelf()
    }
    override fun onDestroy(){running=false;generation++;super.onDestroy()}
    companion object {
        const val ACTION_STOP="com.byd.dolphin.drivealerts.SPLIT_STOP"
        fun start(context:Context,id:String) {
            val i=Intent(context,SplitRecoveryService::class.java).putExtra("id",id)
            try {context.startForegroundService(i)} catch(t:Throwable){CoreLog.w("SPLIT_RESTORE","service start failed: ${t.message}")}
        }
    }
}
