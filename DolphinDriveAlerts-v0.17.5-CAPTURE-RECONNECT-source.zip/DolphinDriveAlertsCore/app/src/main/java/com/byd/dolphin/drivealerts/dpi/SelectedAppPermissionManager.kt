package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** User-requested ADB permissions for an explicitly selected installed app. */
object SelectedAppPermissionManager {
    enum class Action { BATTERY, NOTIFICATION_POST, NOTIFICATION_ACCESS, ACCESSIBILITY, USAGE_STATS }
    data class Result(val lines: List<String>, val okCount: Int, val attempted: Int)

    fun process(context: Context, packageName: String, actions: Set<Action>, configure: Boolean): Result {
        val app = context.applicationContext
        val lines=mutableListOf<String>()
        if (!AppPermissionRules.packageAllowed(packageName)) return Result(listOf("잘못된 앱 패키지"),0,0)
        if (runCatching { app.packageManager.getApplicationInfo(packageName,0) }.isFailure)
            return Result(listOf("설치되지 않은 앱: $packageName"),0,0)
        if (actions.isEmpty()) return Result(listOf("권한 항목을 선택하세요"),0,0)
        val connection=AuthorizedAdbRuntime.awaitReady(app,maxWaitMs=if(configure) 8000L else 3000L)
        if (!connection.result.success) return Result(listOf("ADB 승인 연결 실패: ${connection.state} ${connection.result.message}"),0,actions.size)
        fun exec(cmd:String) = NativeAdbClient.executeShell(app,cmd,timeoutMs=6500L)
        var ok=0
        fun check(action: Action, write: String?, read: String, verify:(String)->Boolean, suffix:String="") {
            if (configure && write!=null) {
                val r=exec(write)
                if (!r.success) { lines += "${action.name} 명령 실패: ${r.message}"; return }
            }
            val r=exec(read)
            val pass=r.success && verify(r.output)
            if(pass)ok++
            lines += "${action.name}: ${if(pass) "readback 확인" else "미확인/거부"} $suffix ${r.output.trim().replace('\n',' ').take(100)}"
        }
        val pm=app.packageManager
        fun services(actionName:String):List<String> = pm.queryIntentServices(Intent(actionName).setPackage(packageName),0)
            .mapNotNull { it.serviceInfo?.let { info -> ComponentName(info.packageName,info.name).flattenToString() } }
            .filter { AppPermissionRules.serviceAllowed(it) }.distinct().sorted()
        for (action in Action.entries) {
            if(action !in actions)continue
            when(action) {
                Action.BATTERY -> check(action,AppPermissionRules.batteryCommand(packageName),"dumpsys deviceidle whitelist",{ raw -> raw.lineSequence().any { it.contains(packageName) } })
                Action.NOTIFICATION_POST -> {
                    val requested = runCatching { pm.getPackageInfo(packageName,PackageManager.GET_PERMISSIONS).requestedPermissions?.toList().orEmpty() }.getOrDefault(emptyList())
                    if("android.permission.POST_NOTIFICATIONS" !in requested) {
                        lines += "NOTIFICATION_POST: 앱에 POST_NOTIFICATIONS 선언 없음 (적용 불가)"
                    } else check(action,AppPermissionRules.grantNotificationCommand(packageName),"dumpsys package $packageName",{ raw ->
                        raw.lineSequence().any { it.contains("android.permission.POST_NOTIFICATIONS:") && it.contains("granted=true") }
                    })
                }
                Action.NOTIFICATION_ACCESS -> {
                    val list=services("android.service.notification.NotificationListenerService")
                    if(list.isEmpty()) lines += "NOTIFICATION_ACCESS: 앱에 NotificationListenerService 없음"
                    else {
                        val component=list.first()
                        check(action,AppPermissionRules.notificationListenerCommand(component),"settings get secure enabled_notification_listeners",{ it.split(':').map(String::trim).contains(component) },"서비스=$component")
                        if(list.size>1) lines += "알림 서비스 ${list.size}개 중 첫 번째만 적용: ${list.joinToString()}"
                    }
                }
                Action.ACCESSIBILITY -> {
                    val list=services("android.accessibilityservice.AccessibilityService")
                    if(list.isEmpty()) lines += "ACCESSIBILITY: 앱에 AccessibilityService 없음"
                    else {
                        val component=list.first()
                        val current=exec("settings get secure enabled_accessibility_services")
                        if(!current.success) {lines += "ACCESSIBILITY: 기존 서비스 목록 조회 실패, 변경하지 않음";continue}
                        val merged=AppPermissionRules.addAccessibilityService(current.output,component)
                        if(configure) {
                            val r=exec(AppPermissionRules.accessibilityCommand(merged))
                            if(r.success)exec("settings put secure accessibility_enabled 1")
                            else {lines += "ACCESSIBILITY: 변경 거부 ${r.message}";continue}
                        }
                        check(action,null,"settings get secure enabled_accessibility_services",{ it.split(':').map(String::trim).contains(component) },"서비스=$component")
                        if(list.size>1) lines += "접근성 서비스 ${list.size}개 중 첫 번째만 적용: ${list.joinToString()}"
                    }
                }
                Action.USAGE_STATS -> check(action,AppPermissionRules.usageStatsCommand(packageName),"appops get $packageName GET_USAGE_STATS",{ it.contains("allow",true) && !it.contains("ignore",true) })
            }
        }
        lines += "확인 $ok/${actions.size}개 · Shell 권한 확인은 실제 앱 팝업 제거/동작 성공의 보장이 아닙니다"
        return Result(lines,ok,actions.size)
    }
}
