package com.byd.dolphin.drivealerts.steering

/**
 * Static BYD DiLink steering/dashboard key catalog recovered from the OverDrive v48.18
 * key-mapping surface. These values are reference candidates until confirmed on the Korean
 * Dolphin, so the detector still keeps the raw learning path and never consumes OEM events.
 */
object BydSteeringKeyCatalog {
    const val NEXT = 87
    const val PREVIOUS = 88
    const val MODE = 289
    const val VOLUME_UP = 291
    const val VOLUME_DOWN = 292
    const val MUTE = 293
    const val SURROUND_VIEW = 294
    const val VOICE = 304
    const val ROTATE = 305
    const val PHONE = 313
    const val POWER = 317

    // BYD firmware can emit these as dedicated keyCodes instead of repeatCount-based long presses.
    const val NEXT_LONG = 302
    const val PREVIOUS_LONG = 303
    const val ROTATE_LONG = 306
    const val VOICE_LONG = 312

    private val labels = mapOf(
        NEXT to "BYD Next",
        PREVIOUS to "BYD Previous",
        MODE to "BYD Mode/Menu",
        VOLUME_UP to "BYD Volume+",
        VOLUME_DOWN to "BYD Volume-",
        MUTE to "BYD Mute",
        SURROUND_VIEW to "BYD Surround View",
        VOICE to "BYD Voice",
        ROTATE to "BYD Rotate",
        PHONE to "BYD Phone",
        POWER to "BYD Power",
        NEXT_LONG to "BYD Next long",
        PREVIOUS_LONG to "BYD Previous long",
        ROTATE_LONG to "BYD Rotate long",
        VOICE_LONG to "BYD Voice long",
    )

    fun label(keyCode: Int): String? = labels[keyCode]
    fun isDedicatedLongKey(keyCode: Int): Boolean = keyCode in setOf(NEXT_LONG, PREVIOUS_LONG, ROTATE_LONG, VOICE_LONG)
    fun knownCodes(): Set<Int> = labels.keys
}
