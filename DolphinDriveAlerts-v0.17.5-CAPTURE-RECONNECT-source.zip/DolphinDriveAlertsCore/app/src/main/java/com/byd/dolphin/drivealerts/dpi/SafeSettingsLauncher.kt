package com.byd.dolphin.drivealerts.dpi

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.byd.dolphin.drivealerts.util.CoreLog

/** Vehicle Settings applications often omit ordinary Android intent targets. */
object SafeSettingsLauncher {
    fun open(activity: Activity, action: String, packageUri: Boolean = false): Boolean {
        val primary = Intent(action).apply { if (packageUri) data = Uri.parse("package:${activity.packageName}") }
        val fallback = Intent(Settings.ACTION_SETTINGS)
        for (candidate in listOf(primary, fallback)) {
            try { activity.startActivity(candidate); return true }
            catch (t: Exception) { CoreLog.w("SETTINGS_INTENT", "${candidate.action}: ${t.javaClass.simpleName} ${t.message}") }
        }
        Toast.makeText(activity, "차량 설정 앱에서 해당 메뉴를 열 수 없습니다", Toast.LENGTH_LONG).show()
        return false
    }
}
