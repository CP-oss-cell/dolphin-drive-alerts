package com.byd.dolphin.drivealerts.automation

import android.content.Context

/** Only launch intents supplied by PackageManager are selectable; never accept arbitrary shell text. */
object AppSelection {
    data class App(val title: String, val packageName: String)
    fun launchable(context: Context): List<App> {
        val pm = context.packageManager
        return pm.getInstalledApplications(0).mapNotNull { app ->
            if (app.packageName == context.packageName || pm.getLaunchIntentForPackage(app.packageName) == null)
                null else App(pm.getApplicationLabel(app).toString(), app.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    }
    fun safeComponent(context: Context, pkg: String): String? {
        if (!pkg.matches(Regex("[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+"))) return null
        return context.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToString()
            ?.takeIf { it.matches(Regex("[a-zA-Z0-9_.$/]+")) }
    }
}
