package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import android.os.Build
import com.byd.dolphin.drivealerts.automation.MediaPlaybackObserver
import com.byd.dolphin.drivealerts.util.CoreLog

/** Explicit, user-invoked authorized ADB bootstrap for restricted BYD Settings UI.
 * ADB is not root: signature/OEM grants can still be rejected by the device.
 */
object PermissionBootstrapper {
    data class Result(val success: Boolean, val lines: List<String>)
    private data class Check(val ok: Boolean, val details: String)

    fun apply(context: Context): Result = perform(context, configure = true)
    fun audit(context: Context): Result = perform(context, configure = false)

    private fun perform(context: Context, configure: Boolean): Result {
        val app = context.applicationContext
        val pkg = app.packageName
        val lines = mutableListOf<String>()
        val adb = AuthorizedAdbRuntime.awaitReady(app, maxWaitMs = if (configure) 30_000L else 6_000L)
        val auth = adb.result
        lines += "로컬 ADB: ${if (auth.success) "연결됨" else "실패"} / ${adb.state} / ${auth.message}"
        if (!auth.success) {
            lines += "ADB RSA 승인 및 127.0.0.1:5555 접근 불가. 이 앱이 단독으로 ADB 서버를 열거나 권한을 우회할 수 없습니다."
            lines += "차량에서 승인된 외부 ADB 연결이 가능하면 동봉된 PC 설정 스크립트를 실행하세요."
            return Result(false, lines)
        }
        val a11y = ComponentName(app, ForegroundPolicyAccessibilityService::class.java).flattenToString()
        val notification = ComponentName(app, MediaPlaybackObserver::class.java).flattenToString()
        fun shell(command: String) = NativeAdbClient.executeShell(app, command, timeoutMs = 7_000L)
        fun change(label: String, command: String) {
            if (!configure) return
            val result = shell(command)
            lines += "$label 적용: ${if (result.success) "명령 OK" else "명령 거부"} ${result.output.trim().ifEmpty { result.message }.take(140)}"
        }
        fun read(label: String, command: String, test: (String)->Boolean): Check {
            val result = shell(command)
            val ok = result.success && test(result.output)
            val msg = if (!result.success) result.message else result.output.trim().replace('\n',' ').take(160)
            lines += "$label 검증: ${if (ok) "확인" else "미확인/거부"} [$msg]"
            return Check(ok, msg)
        }
        // WRITE_SECURE_SETTINGS must be declared. An authorized ADB shell might grant it;
        // whether the user settings change is accepted still requires readback.
        change("WRITE_SECURE_SETTINGS", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        val secure = read("secure 설정 권한", "dumpsys package $pkg | grep -F 'android.permission.WRITE_SECURE_SETTINGS:'") {
            it.contains("granted=true")
        }
        // Overlay works in stock BYD UI; do not override the user's overlay selection here.
        lines += "화면 위 표시(오버레이): 순정 설정에서 직접 허용, 본 자동 작업은 변경하지 않음"
        change("사용기록", "appops set $pkg GET_USAGE_STATS allow")
        val usage = read("사용기록 권한", "appops get $pkg GET_USAGE_STATS") {
            Regex("(?i)\\b(GET_USAGE_STATS|android:get_usage_stats):\\s*allow").containsMatchIn(it)
        }
        change("백그라운드 실행", "appops set $pkg RUN_IN_BACKGROUND allow")
        change("백그라운드 제한 완화", "appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        change("배터리 예외", "dumpsys deviceidle whitelist +$pkg")
        val battery = read("배터리 최적화 예외", "dumpsys deviceidle whitelist") { it.contains(pkg) }

        // The authenticated ADB shell may write secure settings even when this app cannot
        // itself receive WRITE_SECURE_SETTINGS. Treat pm grant as optional, not a blocker.
        if (configure) {
            val existing = shell("settings get secure enabled_accessibility_services")
            if (existing.success) {
                val merged = existing.output.trim().takeUnless { it.isEmpty() || it == "null" }.orEmpty()
                    .split(':').filter { it.isNotBlank() }.toMutableList().apply { if (a11y !in this) add(a11y) }
                    .distinct().joinToString(":")
                change("접근성 목록", "settings put secure enabled_accessibility_services '${quote(merged)}'")
                change("접근성 활성화", "settings put secure accessibility_enabled 1")
            } else lines += "기존 접근성 목록 조회 실패: 타 서비스 보호를 위해 변경 생략"
        }
        val enabledList = read("접근성 서비스", "settings get secure enabled_accessibility_services") {
            it.split(':').map(String::trim).contains(a11y)
        }
        val a11yEnabled = read("접근성 전체 활성화", "settings get secure accessibility_enabled") { it.trim() == "1" }

        // Authorized shell command available on Android framework. It is not POST_NOTIFICATIONS.
        if (configure) {
            val changeListener = shell("cmd notification allow_listener $notification")
            lines += "미디어 알림 리스너 적용: ${if(changeListener.success) "명령 OK" else "명령 거부/미지원"} ${changeListener.message.take(140)}"
            if (!changeListener.success) {
                val previous = shell("settings get secure enabled_notification_listeners")
                if (previous.success) {
                    val merged = previous.output.trim().takeUnless { it.isBlank() || it == "null" }.orEmpty()
                        .split(':').filter { it.isNotBlank() }.toMutableList().apply {
                            if (notification !in this) add(notification)
                        }.distinct().joinToString(":")
                    change("미디어 알림 리스너 목록 보존 병합", "settings put secure enabled_notification_listeners '${quote(merged)}'")
                } else lines += "기존 알림 리스너 목록 읽기 실패: 다른 리스너를 지우지 않기 위해 변경 생략"
            }
        }
        val listener = read("미디어 알림 리스너", "settings get secure enabled_notification_listeners") {
            it.split(':').map(String::trim).contains(notification)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            change("알림 게시", "pm grant $pkg android.permission.POST_NOTIFICATIONS")
        }
        val posting = if (Build.VERSION.SDK_INT >= 33) read("알림 게시 권한", "dumpsys package $pkg | grep -F 'android.permission.POST_NOTIFICATIONS:'") {
            it.contains("granted=true")
        } else Check(true,"API < 33")

        // BYD OEM permissions are not runtime permissions on all ROMs. Do not claim success.
        val byo = listOf("SETTING","AC","BODYWORK","LIGHT","RADAR","INSTRUMENT")
        if (configure) for (domain in byo) change("BYD $domain", "pm grant $pkg android.permission.BYDAUTO_${domain}_COMMON")
        lines += "BYD 차량 제어 권한은 제조사 서명/privileged 제한일 수 있으므로 ADB에서도 실패할 수 있음"
        val ok = usage.ok && enabledList.ok && a11yEnabled.ok && listener.ok && posting.ok
        lines += "권한 종합: ${if(ok) "일반 자동화 권한 readback 확인" else "권한 누락 / 기능 일부 동작 불가"} (battery=${battery.ok}, secure=${secure.ok})"
        CoreLog.i("PERMISSION_BOOTSTRAP", lines.joinToString(" | ").take(3000))
        return Result(ok, lines)
    }
    private fun quote(v: String): String = v.replace("'", "'\\''")
}
