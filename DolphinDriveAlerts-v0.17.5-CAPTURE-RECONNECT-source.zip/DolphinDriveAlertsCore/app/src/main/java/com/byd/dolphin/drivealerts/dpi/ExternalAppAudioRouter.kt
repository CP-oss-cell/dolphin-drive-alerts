package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.PackageManager
import com.byd.dolphin.drivealerts.util.CoreLog

/** User fixed five-app navigation catalog. No arbitrary-app selector and no fake UID audio routing. */
object ExternalAppAudioRouter {
    data class NavigationApp(val title: String, val pkg: String)
    val NAVIGATION_APPS = listOf(
        NavigationApp("TMAP", "com.skt.tmap.ku"),
        NavigationApp("네이버지도", "com.nhn.android.nmap"),
        NavigationApp("카카오맵", "net.daum.android.map"),
        NavigationApp("아틀란3D", "kr.mappers.AtlanSmart"),
        NavigationApp("MCon K", "kr.co.telecons.mcon")
    )
    val navigationPackages: Set<String> = NAVIGATION_APPS.map { it.pkg }.toSet()
    enum class Status { NOT_INSTALLED, TARGET_SAVED_VENDOR_ROUTE_UNAVAILABLE, DISABLED }
    private const val PREF = "fixed_navigation_driver_route_v0169"
    fun enabled(context: Context, pkg: String): Boolean = pkg in navigationPackages &&
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(pkg, false)
    fun setEnabled(context: Context, pkg: String, enabled: Boolean) {
        require(pkg in navigationPackages) { "Unsupported navigation package" }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(pkg, enabled).apply()
    }
    fun diagnose(context: Context, pkg: String): Status {
        require(pkg in navigationPackages)
        val installed = runCatching { context.packageManager.getApplicationInfo(pkg, 0) }.isSuccess
        val status = when {
            !installed -> Status.NOT_INSTALLED
            !enabled(context, pkg) -> Status.DISABLED
            else -> Status.TARGET_SAVED_VENDOR_ROUTE_UNAVAILABLE
        }
        CoreLog.i("APP_AUDIO", "nav=$pkg installed=$installed route=$status; OEM cross-UID hook not implemented")
        return status
    }
}
