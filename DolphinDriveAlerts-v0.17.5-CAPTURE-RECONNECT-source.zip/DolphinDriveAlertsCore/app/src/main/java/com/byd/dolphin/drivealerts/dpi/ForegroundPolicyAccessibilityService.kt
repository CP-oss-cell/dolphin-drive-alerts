package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.util.CoreLog

/** Accessibility is used for steering-key monitoring, NEVER for per-app display rules. */
class ForegroundPolicyAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        }.onFailure { CoreLog.w("ACCESSIBILITY", "Key events unavailable: ${it.message}") }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onKeyEvent(event: KeyEvent): Boolean {
        runCatching { SteeringTripleTapDetector.onKeyEvent(this,event) }
            .onFailure { CoreLog.w("ACCESSIBILITY", "key error=${it.message}") }
        return false
    }
    override fun onInterrupt() = Unit
}
