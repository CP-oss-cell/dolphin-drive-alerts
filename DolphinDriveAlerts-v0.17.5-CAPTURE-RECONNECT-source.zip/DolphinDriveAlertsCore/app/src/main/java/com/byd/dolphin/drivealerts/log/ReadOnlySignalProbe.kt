package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap

/** Read-only reflection probe for unknown BYD raw values. Never invokes setters or methods with parameters. */
class ReadOnlySignalProbe(context: Context) {
    private val app = context.applicationContext
    private val devices = ConcurrentHashMap<String, Any>()
    private val getterCache = ConcurrentHashMap<String, List<Method>>()
    private val unavailable = HashSet<String>()
    private val extendedCache = linkedMapOf<String, String>()
    private var snapshotCount = 0L

    fun snapshot(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        snapshotClasses(FAST_CLASSES, out)

        // Service calls this probe about once per second. OverDrive-derived secondary devices are
        // deliberately sampled only once every ~5 snapshots to avoid hammering vendor binders.
        snapshotCount += 1
        if (snapshotCount == 1L || snapshotCount % EXTENDED_EVERY_N_SNAPSHOTS == 0L) {
            val fresh = linkedMapOf<String, String>()
            snapshotClasses(EXTENDED_CLASSES, fresh)
            extendedCache.putAll(fresh)
        }
        out.putAll(extendedCache)
        return out
    }

    private fun snapshotClasses(classNames: List<String>, out: MutableMap<String, String>) {
        for (className in classNames) {
            val instance = instance(className) ?: continue
            val short = className.substringAfterLast('.')
            val getters = getterCache.getOrPut(className) {
                instance.javaClass.methods.filter { m ->
                    m.parameterTypes.isEmpty() &&
                        (m.name.startsWith("get") || m.name.startsWith("is")) &&
                        m.name !in BLOCKED_NAMES && isSafeReturn(m.returnType)
                }.sortedBy { it.name }
            }
            for (m in getters) {
                val v = runCatching { m.invoke(instance) }.getOrNull() ?: continue
                serialize(v)?.let { out["$short.${m.name}"] = it }
            }
        }
    }

    private fun instance(className: String): Any? {
        devices[className]?.let { return it }
        synchronized(unavailable) { if (className in unavailable) return null }
        return runCatching {
            val c = Class.forName(className)
            val o = c.getMethod("getInstance", Context::class.java).invoke(null, BydPermissionContext.wrap(app)) ?: return null
            devices[className] = o; o
        }.getOrElse { synchronized(unavailable) { unavailable.add(className) }; null }
    }

    private fun isSafeReturn(c: Class<*>): Boolean = c.isPrimitive || Number::class.java.isAssignableFrom(c) ||
        c == java.lang.Boolean::class.java || c == String::class.java || c.isEnum || c.isArray

    private fun serialize(v: Any): String? = when (v) {
        is IntArray -> v.joinToString(prefix="[", postfix="]")
        is FloatArray -> v.joinToString(prefix="[", postfix="]")
        is DoubleArray -> v.joinToString(prefix="[", postfix="]")
        is LongArray -> v.joinToString(prefix="[", postfix="]")
        is BooleanArray -> v.joinToString(prefix="[", postfix="]")
        is Array<*> -> v.joinToString(prefix="[", postfix="]") { it?.toString() ?: "null" }
        is Number, is Boolean, is String, is Enum<*> -> v.toString()
        else -> null
    }

    companion object {
        private const val EXTENDED_EVERY_N_SNAPSHOTS = 5L
        private val BLOCKED_NAMES = setOf("getClass", "getInstance")

        // Existing v0.10/v0.11 core read surface.
        private val FAST_CLASSES = listOf(
            "android.hardware.bydauto.speed.BYDAutoSpeedDevice",
            "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
            "android.hardware.bydauto.adas.BYDAutoADASDevice",
            "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
            "android.hardware.bydauto.setting.BYDAutoSettingDevice",
            "android.hardware.bydauto.radar.BYDAutoRadarDevice",
            "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
            "android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice"
        )

        // SOURCE_FOUND in OverDrive v48.18 APK strings. No setters are called: the generic probe
        // still permits only zero-argument get*/is* methods with simple return types. These are
        // slower evidence surfaces for future Dolphin verification, not VERIFIED signal mappings.
        private val EXTENDED_CLASSES = listOf(
            "android.hardware.bydauto.ac.BYDAutoAcDevice",
            "android.hardware.bydauto.charging.BYDAutoChargingDevice",
            "android.hardware.bydauto.doorlock.BYDAutoDoorLockDevice",
            "android.hardware.bydauto.doormirror.BYDAutoRearViewMirrorDevice",
            "android.hardware.bydauto.engine.BYDAutoEngineDevice",
            "android.hardware.bydauto.light.BYDAutoLightDevice",
            "android.hardware.bydauto.mirror.BYDAutoRearViewMirrorDevice",
            "android.hardware.bydauto.multimedia.BYDAutoMultimediaDevice",
            "android.hardware.bydauto.pm2p5.BYDAutoPM2p5Device",
            "android.hardware.bydauto.power.BYDAutoPowerDevice",
            "android.hardware.bydauto.rearview.BYDAutoRearViewMirrorDevice",
            "android.hardware.bydauto.rearviewmirror.BYDAutoRearViewMirrorDevice",
            "android.hardware.bydauto.rvm.BYDAutoRearViewMirrorDevice",
            "android.hardware.bydauto.safetybelt.BYDAutoSafetyBeltDevice",
            "android.hardware.bydauto.sensor.BYDAutoSensorDevice",
            "android.hardware.bydauto.statistic.BYDAutoStatisticDevice",
            "android.hardware.bydauto.tyre.BYDAutoTyreDevice",
            "android.hardware.bydauto.vehiclehealth.BYDAutoVehicleHealthDevice",
            "android.hardware.bydauto.wiper.BYDAutoWiperDevice"
        )
    }
}
