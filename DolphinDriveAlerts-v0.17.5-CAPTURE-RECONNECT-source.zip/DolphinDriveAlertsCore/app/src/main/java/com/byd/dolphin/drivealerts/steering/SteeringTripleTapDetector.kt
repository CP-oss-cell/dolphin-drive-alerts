package com.byd.dolphin.drivealerts.steering

import android.content.Context
import android.view.KeyEvent
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Observes (does not consume) steering/menu/back key presses. Three DOWN presses of the same
 * configured key inside TRIPLE_WINDOW_MS trigger one local one-shot audio playback.
 */
object SteeringTripleTapDetector {
    private val window = TripleTapWindow(windowMs = 1_200L, minGapMs = 80L)
    private val pressed = mutableSetOf<String>()

    @Synchronized
    fun onKeyEvent(context: Context, event: KeyEvent): Boolean {
        val edgeId = "${event.deviceId}:${event.keyCode}:${event.scanCode}"
        if (event.action == KeyEvent.ACTION_UP) { pressed.remove(edgeId); return false }
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        // Do not treat a duplicate KeyEvent.DOWN as another physical click.
        if (!pressed.add(edgeId)) return false
        val now = event.eventTime.takeIf { it > 0 } ?: System.currentTimeMillis()
        val bydLabel = BydSteeringKeyCatalog.label(event.keyCode) ?: "unknown"
        val detail = "keyCode=${event.keyCode} bydKey=$bydLabel scanCode=${event.scanCode} deviceId=${event.deviceId} source=0x${event.source.toString(16)} flags=0x${event.flags.toString(16)}"
        DrivingAlertService.marker(context, "STEERING_KEY_DOWN", detail)
        CoreLog.i("STEERING_KEY", detail)

        if (!SteeringTriggerPreferences.enabled(context) || !matches(event)) return false
        val identity = "${event.keyCode}:${event.scanCode}"
        if (window.register(now, identity) && SteeringPlaybackGuard.allow()) {
            DrivingAlertService.marker(context, "STEERING_TRIPLE_TAP", detail)
            CoreLog.i("STEERING_KEY", "triple tap trigger $detail")
            DrivingAlertService.playOneShot(context, "steering_triple_tap")
        }
        return false // Never consume: single/double presses keep the OEM behavior.
    }

    /** User-confirmed MENU/PREVIOUS keys plus Android compatibility fallbacks. */
    private fun matches(event: KeyEvent): Boolean =
        event.keyCode == BydSteeringKeyCatalog.MODE ||
        event.keyCode == BydSteeringKeyCatalog.PREVIOUS ||
        event.keyCode == KeyEvent.KEYCODE_MENU ||
        event.keyCode == KeyEvent.KEYCODE_BACK
}
