package com.byd.dolphin.drivealerts.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.audio.GlobalEqualizerEngine
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.ForegroundPackageMonitor
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.log.CaptureContinuity
import com.byd.dolphin.drivealerts.log.ReadOnlySignalProbe
import com.byd.dolphin.drivealerts.log.AudioRouteProbe
import com.byd.dolphin.drivealerts.log.FeatureIdCatalog
import com.byd.dolphin.drivealerts.log.SystemDiagnosticsCollector
import com.byd.dolphin.drivealerts.log.TargetedSignalProbe
import com.byd.dolphin.drivealerts.ui.MainActivity
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.AlertGate
import com.byd.dolphin.drivealerts.vehicle.BydVehicleReader
import com.byd.dolphin.drivealerts.vehicle.VehicleEventDetector
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Safe-start foreground monitor.
 *
 * Important:
 * - startForeground() happens before any BYD/vendor probing.
 * - every optional vehicle/diagnostic component is initialized independently.
 * - the direct BYD listener tap is NOT created at app startup; it is enabled only when an
 *   AVAS diagnostic capture is explicitly requested. This keeps an OEM listener ABI mismatch
 *   from killing the launcher Activity.
 */
class DrivingAlertService : Service() {
    private var audio: AlertAudioPlayer? = null
    private var reader: BydVehicleReader? = null
    private var gate: AlertGate? = null
    private var detector: VehicleEventDetector? = null
    private val executor = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "byd-signal-poller") }
    private val commandExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "drive-alert-command") }
    private var task: ScheduledFuture<*>? = null
    private var tick = 0L

    private var rawLogger: RawSignalLogger? = null
    private var signalProbe: ReadOnlySignalProbe? = null
    private var targetedSignalProbe: TargetedSignalProbe? = null
    private var audioRouteProbe: AudioRouteProbe? = null
    private var featureIds: FeatureIdCatalog? = null
    private var diagnostics: SystemDiagnosticsCollector? = null
    private var bydEventTap: Any? = null
    private var nextTapRetryMs = 0L
    private var lastTapWakeRebindMs = 0L
    private val tapRetryQueued = AtomicBoolean(false)
    private var referenceEventBridge: Any? = null
    private var foregroundPackageMonitor: ForegroundPackageMonitor? = null
    private var equalizerEngine: GlobalEqualizerEngine? = null

    override fun onCreate() {
        super.onCreate()

        // Meet Android's foreground-service deadline before touching BYD/vendor classes.
        runCatching { startForeground(NOTIFICATION_ID, notification()) }
            .onFailure { CoreLog.w("SERVICE", "startForeground failed: ${it.message}", it) }

        UnifiedLogCapture.recoverInterruptedSave(this)
        rawLogger = safeInit("RawSignalLogger") { RawSignalLogger(this) }
        activeLogger = rawLogger
        rawLogger?.marker("SERVICE_STARTED_V014_UNIFIED_LOG")
        val recovering = UnifiedLogCapture.state(this)
        if (recovering.status == UnifiedLogCapture.RECORDING && recovering.id.isNotBlank()) {
            val gap = runCatching { CaptureContinuity.serviceRestored(this, recovering.id) }
                .onFailure { rawLogger?.diagnostic("CAPTURE_JOURNAL_RESTORE_FAILED", it.javaClass.simpleName) }.getOrNull()
            rawLogger?.marker("UNIFIED_CAPTURE_PROCESS_RESUME", "id=${recovering.id} sinceHeartbeatMs=${gap ?: "unknown"}")
        }

        audio = safeInit("AlertAudioPlayer") { AlertAudioPlayer(this) }
        equalizerEngine = safeInit("GlobalEqualizerEngine") { GlobalEqualizerEngine(this).also { it.start() } }
        foregroundPackageMonitor = safeInit("ForegroundPackageMonitor") { ForegroundPackageMonitor(this).also { it.start() } }
        reader = safeInit("BydVehicleReader") { BydVehicleReader(this) }
        gate = safeInit("AlertGate") {
            AlertGate { if (AlertPreferences.isEnabled(this)) audio?.play(it) }
        }
        detector = gate?.let { g -> safeInit("VehicleEventDetector") { VehicleEventDetector(g::submit) } }
        signalProbe = safeInit("ReadOnlySignalProbe") { ReadOnlySignalProbe(this) }
        targetedSignalProbe = safeInit("TargetedSignalProbe") { TargetedSignalProbe(this) }
        audioRouteProbe = safeInit("AudioRouteProbe") { AudioRouteProbe(this) }
        featureIds = safeInit("FeatureIdCatalog") { FeatureIdCatalog() }

        // Restore the normal-runtime listener path from Byd_SubAI_Beta_v13. The bridge is
        // reflection-loaded so an OEM ABI mismatch cannot stop the foreground service itself.
        val normalLogger = rawLogger
        val normalGate = gate
        if (normalLogger != null && normalGate != null) {
            referenceEventBridge = safeInit("ReferenceVehicleEventBridge") {
                val c = Class.forName("com.byd.dolphin.drivealerts.vehicle.ReferenceVehicleEventBridge")
                val ctor = c.getConstructor(Context::class.java, RawSignalLogger::class.java, AlertGate::class.java, Runnable::class.java)
                val tripleTap = Runnable {
                    if (SteeringTriggerPreferences.enabled(this) &&
                        com.byd.dolphin.drivealerts.steering.SteeringPlaybackGuard.allow()) {
                        normalLogger.marker("STEERING_TRIPLE_TAP_PLAY", "SubAI INSTRUMENT_2IN1_MENU_STATE")
                        audio?.playOneShot(SteeringTriggerPreferences.soundFile(this), "subai-reference-menu-triple")
                    } else normalLogger.diagnostic("STEERING_DUPLICATE_SUPPRESSED", "source=SubAI")
                }
                ctor.newInstance(this, normalLogger, normalGate, tripleTap).also { c.getMethod("start").invoke(it) }
            }
        }

        val logger = rawLogger
        val ids = featureIds
        if (logger != null && ids != null) {
            diagnostics = safeInit("SystemDiagnosticsCollector") { SystemDiagnosticsCollector(this, logger, ids) }
        }
        activeDiagnostics = diagnostics

        audioRouteProbe?.let { probe ->
            runCatching { rawLogger?.recordAudioRoute(probe.snapshot()) }
                .onFailure { CoreLog.w("SERVICE", "initial audio route failed: ${it.message}") }
        }

        // Keep the OEM subclass out of normal service startup. Only a user-started,
        // persistently RECORDING session authorizes recovering this optional listener.
        if (recovering.status == UnifiedLogCapture.RECORDING && recovering.id.isNotBlank()) {
            commandExecutor.execute { rebindCaptureTap("process-restart", force = false) }
        }
        if (reader != null && detector != null && rawLogger != null) {
            task = executor.scheduleAtFixedRate(::sampleSafely, 0, 150, TimeUnit.MILLISECONDS)
            CoreLog.i("SERVICE", "safe monitor started")
        } else {
            rawLogger?.diagnostic("SERVICE_PARTIAL_START", startupStatus())
            CoreLog.w("SERVICE", "partial start: ${startupStatus()}")
        }
    }

    private fun <T> safeInit(name: String, block: () -> T): T? =
        try {
            block().also {
                rawLogger?.diagnostic("INIT_OK", name)
                CoreLog.i("SERVICE", "init ok: $name")
            }
        } catch (t: Throwable) {
            rawLogger?.diagnostic("INIT_FAILED", "$name:${t.javaClass.simpleName}:${t.message}")
            CoreLog.w("SERVICE", "init failed $name: ${t.message}", t)
            null
        }

    private fun startupStatus(): String =
        "audio=${audio != null},reader=${reader != null},gate=${gate != null},detector=${detector != null}," +
            "logger=${rawLogger != null},probe=${signalProbe != null},targeted=${targetedSignalProbe != null},route=${audioRouteProbe != null}," +
            "featureIds=${featureIds != null},reference=${referenceEventBridge != null},diag=${diagnostics != null}"

    private fun ensureBydEventTap(): Boolean {
        if (bydEventTap != null) return true
        val logger = rawLogger ?: return false
        val ids = featureIds ?: return false
        return try {
            // Keep OEM listener subclasses completely out of normal service class verification.
            // They are loaded only when AVAS diagnostics are explicitly requested.
            val c = Class.forName("com.byd.dolphin.drivealerts.log.BydEventTap")
            val ctor = c.getConstructor(Context::class.java, RawSignalLogger::class.java, FeatureIdCatalog::class.java)
            val tap = ctor.newInstance(this, logger, ids)
            c.getMethod("start").invoke(tap)
            val active = c.getMethod("hasActiveBindings").invoke(tap) as? Boolean ?: false
            if (!active) {
                logger.diagnostic("BYD_EVENT_TAP_LAZY_EMPTY", "No compatible OEM listener could register")
                runCatching { c.getMethod("close").invoke(tap) }
                return false
            }
            bydEventTap = tap
            logger.diagnostic("BYD_EVENT_TAP_LAZY_STARTED", "reflection-ok")
            true
        } catch (t: Throwable) {
            logger.diagnostic("BYD_EVENT_TAP_LAZY_FAILED", "${t.javaClass.simpleName}:${t.cause?.message ?: t.message}")
            CoreLog.w("BYD_EVENT_TAP", "lazy start failed: ${t.cause?.message ?: t.message}", t)
            false
        }
    }


    /** Serialized with capture begin/end: boot can rebind a stale OEM listener after MCU sleep. */
    private fun rebindCaptureTap(reason: String, force: Boolean) {
        val state = UnifiedLogCapture.state(this)
        if (state.status != UnifiedLogCapture.RECORDING || state.id.isBlank()) return
        val now = System.currentTimeMillis()
        val hardAttempt = force && now - lastTapWakeRebindMs >= 8_000L
        if (hardAttempt) lastTapWakeRebindMs = now
        if (hardAttempt && bydEventTap != null) {
            runCatching {
                bydEventTap?.let { tap ->
                    tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
                }
            }.onFailure { rawLogger?.diagnostic("UNIFIED_TAP_CLOSE_FAILED", it.javaClass.simpleName) }
            bydEventTap = null
        }
        if (bydEventTap == null && (hardAttempt || now >= nextTapRetryMs)) {
            val ok = ensureBydEventTap()
            // Registration alone is not proof that callbacks were received or AVAS played.
            runCatching { CaptureContinuity.tapState(this, state.id,
                if (ok) "REGISTERED_UNCONFIRMED" else "RETRY_PENDING", "reason=$reason") }
            rawLogger?.marker("UNIFIED_TAP_RECONNECT", "id=${state.id} registered=$ok reason=$reason")
            nextTapRetryMs = if (ok) 0L else now + 30_000L
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_TEST_ALERT -> {
                    val event = intent.getStringExtra(EXTRA_EVENT)?.let { runCatching { AlertEvent.valueOf(it) }.getOrNull() }
                    val side = intent.getStringExtra(EXTRA_SIDE)?.let { runCatching { Side.valueOf(it) }.getOrNull() } ?: Side.UNKNOWN
                    if (event != null) gate?.submit(AlertRequest(event, side))
                }

                ACTION_PLAY_ONE_SHOT -> {
                    val source = intent.getStringExtra(EXTRA_SOURCE) ?: "unknown"
                    rawLogger?.marker("ONE_SHOT_PLAY_REQUEST", source)
                    audio?.playOneShot(SteeringTriggerPreferences.soundFile(this), source)
                }

                ACTION_MARKER -> {
                    rawLogger?.marker(
                        intent.getStringExtra(EXTRA_LABEL) ?: "MARKER",
                        intent.getStringExtra(EXTRA_DETAIL)
                    )
                }

                ACTION_REFRESH_EQ -> {
                    equalizerEngine?.refresh()
                    rawLogger?.marker("EQ_REFRESH", "user/settings")
                }

                ACTION_CAPTURE_BEGIN -> {
                    commandExecutor.execute {
                        val result = UnifiedLogCapture.begin(this, rawLogger, diagnostics)
                        rebindCaptureTap("manual-start", force = false)
                        updateNotification(result)
                    }
                }

                ACTION_CAPTURE_WAKE -> {
                    val source = intent.getStringExtra(EXTRA_WAKE_SOURCE) ?: "unknown"
                    commandExecutor.execute {
                        val current = UnifiedLogCapture.state(this)
                        if (current.status == UnifiedLogCapture.RECORDING) {
                            rawLogger?.marker("UNIFIED_CAPTURE_IGNITION_WAKE", "id=${current.id} action=$source")
                            val hardWake = source == "com.byd.action.ACC_ON" || source == "com.byd.action.IGN_ON" ||
                                source == Intent.ACTION_BOOT_COMPLETED || source.contains("QUICKBOOT_POWERON")
                            rebindCaptureTap("ignition:$source", force = hardWake)
                        }
                    }
                }

                ACTION_CAPTURE_END -> {
                    commandExecutor.execute {
                        val result = UnifiedLogCapture.finish(this, rawLogger, diagnostics)
                        nextTapRetryMs = 0L
                        runCatching {
                            bydEventTap?.let { tap ->
                                tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
                            }
                            bydEventTap = null
                        }.onFailure { CoreLog.w("UNIFIED_LOG", "tap stop failed: ${it.message}", it) }
                        updateNotification(result.fold(
                            { "수집 종료 · 저장 완료: $it" },
                            { "로그 저장 실패: ${it.message ?: it.javaClass.simpleName}" }
                        ))
                    }
                }

                ACTION_CAPTURE_STEERING -> {
                    val seconds = intent.getIntExtra(EXTRA_SECONDS, 10)
                    diagnostics?.captureSteeringKeyWindow(seconds)
                }

                ACTION_CAPTURE_DEEP -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "DEEP"
                    rawLogger?.marker(label)
                    diagnostics?.captureDeep(label)
                }

                ACTION_CAPTURE_QUICK -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "QUICK"
                    rawLogger?.marker(label)
                    diagnostics?.captureQuick(label)
                }

                ACTION_CAPTURE_WINDOW -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "WINDOW"
                    val seconds = intent.getIntExtra(EXTRA_SECONDS, 12)
                    diagnostics?.captureWindow(label, seconds)
                }

                ACTION_EXPORT -> {
                    val logger = rawLogger
                    if (logger != null) {
                        commandExecutor.execute {
                            val result = com.byd.dolphin.drivealerts.log.DiagnosticsExporter
                                .exportToDownloads(this, logger, diagnostics)
                            logger.diagnostic(
                                if (result.isSuccess) "EXPORT_OK" else "EXPORT_FAILED",
                                result.fold({ it }, { "${it.javaClass.simpleName}:${it.message}" })
                            )
                            updateNotification(
                                result.fold(
                                    { "로그 생성 완료: $it" },
                                    { "로그 생성 실패: ${it.message ?: it.javaClass.simpleName}" }
                                )
                            )
                        }
                    } else {
                        updateNotification("로그 생성 실패: logger unavailable")
                    }
                }
            }
        } catch (t: Throwable) {
            rawLogger?.diagnostic("COMMAND_FAILED", "${intent?.action}:${t.javaClass.simpleName}:${t.message}")
            CoreLog.w("SERVICE", "command failed ${intent?.action}: ${t.message}", t)
        }
        return START_STICKY
    }

    private fun sampleSafely() {
        try {
            val r = reader ?: return
            val d = detector ?: return
            val logger = rawLogger ?: return

            val frame = r.readFrame()
            val currentTick = ++tick
            val energy = if (currentTick % 4L == 0L) r.readReferenceEnergySignals() else emptyMap()
            val probe = if (currentTick % 7L == 0L) {
                linkedMapOf<String, String>().apply {
                    putAll(signalProbe?.snapshot().orEmpty())
                    putAll(targetedSignalProbe?.snapshot().orEmpty())
                }
            } else emptyMap()

            if (currentTick % 7L == 0L) {
                audioRouteProbe?.let { route ->
                    runCatching { logger.recordAudioRoute(route.snapshot()) }
                }
            }

            logger.record(frame, energy, probe)
            if (currentTick % 7L == 0L) {
              val capture = UnifiedLogCapture.state(this)
              if (capture.status == UnifiedLogCapture.RECORDING) {
                runCatching { CaptureContinuity.heartbeat(this, capture.id) }
                    .onFailure { logger.diagnostic("CAPTURE_HEARTBEAT_FAILED", it.javaClass.simpleName) }
                // Retry only an absent tap; never reset a healthy binding during sampling.
                if (bydEventTap == null && System.currentTimeMillis() >= nextTapRetryMs &&
                    tapRetryQueued.compareAndSet(false, true)) {
                    commandExecutor.execute {
                        try { rebindCaptureTap("retry", force = false) }
                        finally { tapRetryQueued.set(false) }
                    }
                }
              }
            }
            d.accept(frame, energy)
            // A blinker may be activated AFTER BSD is already active. Re-check while
            // active, without polling another device or blindly announcing hazards.
            if (currentTick % 3L == 0L) {
                runCatching {
                    referenceEventBridge?.javaClass?.getMethod("pollBsdWithIndicator")?.invoke(referenceEventBridge)
                    referenceEventBridge?.javaClass?.getMethod("pollAutoHoldEngagement")?.invoke(referenceEventBridge)
                }.onFailure { logger.diagnostic("BSD_INDICATOR_POLL_FAILED", it.javaClass.simpleName) }
            }
        } catch (t: Throwable) {
            CoreLog.w("SERVICE", "sample failed: ${t.message}", t)
            rawLogger?.diagnostic("SAMPLE_FAILED", "${t.javaClass.simpleName}:${t.message}")
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        rawLogger?.marker("TASK_REMOVED_KEEP_SERVICE")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        task?.cancel(true)
        executor.shutdownNow()
        commandExecutor.shutdownNow()
        rawLogger?.marker("SERVICE_STOPPED")
        runCatching {
            bydEventTap?.let { tap ->
                tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
            }
        }
        runCatching {
            referenceEventBridge?.let { bridge ->
                bridge.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(bridge)
            }
        }
        runCatching { diagnostics?.close() }
        runCatching { foregroundPackageMonitor?.close() }
        runCatching { equalizerEngine?.close() }
        runCatching { targetedSignalProbe?.close() }
        runCatching { rawLogger?.close() }
        activeLogger = null
        activeDiagnostics = null
        runCatching { audio?.shutdown() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String = "BYD 차량 신호 감시 · SAFE START") : Notification {
        val channelId = "drive_alert_core"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "주행 보조 알림", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("주행 보조 알림 작동 중")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
        }
    }

    companion object {
        const val ACTION_TEST_ALERT = "com.byd.dolphin.drivealerts.TEST_ALERT"
        const val ACTION_PLAY_ONE_SHOT = "com.byd.dolphin.drivealerts.PLAY_ONE_SHOT"
        const val ACTION_MARKER = "com.byd.dolphin.drivealerts.MARKER"
        const val ACTION_REFRESH_EQ = "com.byd.dolphin.drivealerts.REFRESH_EQ"
        const val ACTION_CAPTURE_STEERING = "com.byd.dolphin.drivealerts.CAPTURE_STEERING"
        const val ACTION_CAPTURE_DEEP = "com.byd.dolphin.drivealerts.CAPTURE_DEEP"
        const val ACTION_CAPTURE_QUICK = "com.byd.dolphin.drivealerts.CAPTURE_QUICK"
        const val ACTION_CAPTURE_WINDOW = "com.byd.dolphin.drivealerts.CAPTURE_WINDOW"
        const val ACTION_EXPORT = "com.byd.dolphin.drivealerts.EXPORT" // legacy, not exposed in UI
        const val ACTION_CAPTURE_BEGIN = "com.byd.dolphin.drivealerts.UNIFIED_CAPTURE_BEGIN"
        const val ACTION_CAPTURE_END = "com.byd.dolphin.drivealerts.UNIFIED_CAPTURE_END"

        const val EXTRA_EVENT = "event"
        const val EXTRA_SIDE = "side"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_LABEL = "label"
        const val EXTRA_DETAIL = "detail"
        const val EXTRA_SECONDS = "seconds"
        const val ACTION_CAPTURE_WAKE = "com.byd.dolphin.drivealerts.CAPTURE_WAKE"
        const val EXTRA_WAKE_SOURCE = "wake_source"

        private const val NOTIFICATION_ID = 1414

        @Volatile var activeLogger: RawSignalLogger? = null
            private set
        @Volatile var activeDiagnostics: SystemDiagnosticsCollector? = null
            private set

        private fun launch(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }

        fun start(context: Context) = launch(context, Intent(context, DrivingAlertService::class.java))

        fun wakeRecording(context: Context, source: String) = launch(context,
            Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_WAKE)
                .putExtra(EXTRA_WAKE_SOURCE, source))

        fun test(context: Context, event: AlertEvent, side: Side = Side.UNKNOWN) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_TEST_ALERT)
                    .putExtra(EXTRA_EVENT, event.name)
                    .putExtra(EXTRA_SIDE, side.name)
            )

        fun playOneShot(context: Context, source: String = "manual") =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_PLAY_ONE_SHOT)
                    .putExtra(EXTRA_SOURCE, source)
            )

        fun marker(context: Context, label: String, detail: String? = null) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_MARKER)
                    .putExtra(EXTRA_LABEL, label)
                    .putExtra(EXTRA_DETAIL, detail)
            )

        fun refreshEqualizer(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_REFRESH_EQ))

        fun captureSteering(context: Context, seconds: Int = 10) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_STEERING)
                    .putExtra(EXTRA_SECONDS, seconds)
            )

        fun captureDeep(context: Context, label: String) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_DEEP)
                    .putExtra(EXTRA_LABEL, label)
            )

        fun captureQuick(context: Context, label: String) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_QUICK)
                    .putExtra(EXTRA_LABEL, label)
            )

        fun captureWindow(context: Context, label: String, seconds: Int = 12) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_WINDOW)
                    .putExtra(EXTRA_LABEL, label)
                    .putExtra(EXTRA_SECONDS, seconds)
            )

        fun beginUnifiedCapture(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_BEGIN))

        fun endUnifiedCapture(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_END))

        fun export(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_EXPORT))
    }
}
