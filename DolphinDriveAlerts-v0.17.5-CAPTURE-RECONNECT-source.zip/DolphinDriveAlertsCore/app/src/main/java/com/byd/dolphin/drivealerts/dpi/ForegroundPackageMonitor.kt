package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import java.io.Closeable

/** Compatibility lifecycle surface: global rotation has no app lookup/polling. */
class ForegroundPackageMonitor(private val context: Context) : Closeable {
    fun start() { RotationPolicy.applyCurrent(context) }
    override fun close() { OrientationOverlayController.clear() }
}
