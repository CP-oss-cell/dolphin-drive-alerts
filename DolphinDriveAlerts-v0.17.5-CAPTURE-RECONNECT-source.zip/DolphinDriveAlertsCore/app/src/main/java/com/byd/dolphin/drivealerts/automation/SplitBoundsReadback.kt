package com.byd.dolphin.drivealerts.automation

import kotlin.math.abs

/** Strict parser for legacy Android 10 `am stack list` pixel bounds. */
internal object SplitBoundsReadback {
    private val rect = Regex("""(?i)bounds=\[(\d+),(\d+)\]\[(\d+),(\d+)\]""")
    /** Returns null if actual docked/split bounds cannot be measured. */
    fun primaryPercent(raw: String, width: Int, height: Int, requested: Int): Int? {
        if (width <= 0 || height <= 0) return null
        val horizontal = width >= height
        val candidates = raw.lineSequence().flatMap { line ->
            rect.findAll(line).mapNotNull { m ->
                val (x0,y0,x1,y1) = m.groupValues.drop(1).map { it.toInt() }
                val primaryExtent = if (horizontal) x1-x0 else y1-y0
                val crossExtent = if (horizontal) y1-y0 else x1-x0
                val total = if (horizontal) width else height
                val maxCross = if (horizontal) height else width
                if (primaryExtent <= 0 || primaryExtent >= total || crossExtent < maxCross * 0.85) null
                else primaryExtent * 100 / total
            }
        }.toList()
        return candidates.minByOrNull { abs(it-requested) }
    }
}
