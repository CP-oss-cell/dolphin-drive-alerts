package com.byd.dolphin.drivealerts.automation

import android.service.notification.NotificationListenerService
import android.content.ComponentName
import android.content.Context
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.util.Log
import com.byd.dolphin.drivealerts.util.CoreLog

/** Media play is targeted to a matching active session; no blind global keyevent. */
class MediaPlaybackObserver : NotificationListenerService() {
    companion object {
        /** First try already-active session without launching the media app UI. */
        fun playExisting(c: Context, pkg: String): Boolean = requestPlay(c, pkg, waitForSession = false)

        /** Normal cold app launch fallback waits for the newly created media session. */
        fun play(c: Context, pkg: String): Boolean = requestPlay(c, pkg, waitForSession = true)

        private fun requestPlay(c: Context, pkg: String, waitForSession: Boolean): Boolean {
            return try {
                val manager = c.getSystemService(MediaSessionManager::class.java)
                val component = ComponentName(c, MediaPlaybackObserver::class.java)
                var controller = manager.getActiveSessions(component).firstOrNull { it.packageName == pkg }
                var retries = 0
                while (controller == null && waitForSession && retries++ < 8) {
                    Thread.sleep(500L)
                    controller = manager.getActiveSessions(component).firstOrNull { it.packageName == pkg }
                }
                if (controller == null) {
                    CoreLog.w("MEDIA_START", "no_active_session pkg=$pkg coldFallback=$waitForSession")
                    false
                } else {
                    val active = controller
                    active.transportControls.play()
                    var status: Int? = null
                    // Playback can transition STARTING -> BUFFERING -> PLAYING asynchronously.
                    repeat(10) {
                        if (status != PlaybackState.STATE_PLAYING && status != PlaybackState.STATE_BUFFERING) {
                            Thread.sleep(300L)
                            status = active.playbackState?.state
                        }
                    }
                    val accepted = status == PlaybackState.STATE_PLAYING || status == PlaybackState.STATE_BUFFERING
                    CoreLog.i("MEDIA_START", "pkg=$pkg reused=${!waitForSession} state=$status accepted=$accepted")
                    accepted
                }
            } catch (t: Throwable) {
                CoreLog.w("MEDIA_START", "play failure for $pkg: ${t.message}")
                false
            }
        }
    }
}
