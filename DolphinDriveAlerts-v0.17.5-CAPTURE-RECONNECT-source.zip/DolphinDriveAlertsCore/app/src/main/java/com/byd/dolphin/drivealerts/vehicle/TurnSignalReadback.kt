package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/**
 * Read-only indicator state for BSD audio GATING, never controls vehicle lights.
 * Unknown, missing SDK, inconsistent/hazard lights => NO warning speech.
 * The raw ON=1 convention is a tentative candidate pending car log validation.
 */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    private val lightClass = "android.hardware.bydauto.light.BYDAutoLightDevice"
    data class Result(val side: Side, val detail: String)

    private fun state(names: List<String>): Pair<String, Int>? = runCatching {
        val clazz = Class.forName(lightClass)
        val device = clazz.getMethod("getInstance", Context::class.java).invoke(null, app)
            ?: return@runCatching null
        names.firstNotNullOfOrNull { method ->
            runCatching { (clazz.getMethod(method).invoke(device) as? Number)?.toInt()?.let { method to it } }.getOrNull()
        }
    }.getOrNull()

    fun read(): Result {
        val l = state(listOf("getLeftTurnLightState", "getLeftTurnSignalState", "getLeftTurnLampState"))
        val r = state(listOf("getRightTurnLightState", "getRightTurnSignalState", "getRightTurnLampState"))
        val side = when {
            l?.second == 1 && r?.second == 0 -> Side.LEFT
            r?.second == 1 && l?.second == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        return Result(side, "left=$l right=$r;SDK_ON_1_CANDIDATE")
    }
}
