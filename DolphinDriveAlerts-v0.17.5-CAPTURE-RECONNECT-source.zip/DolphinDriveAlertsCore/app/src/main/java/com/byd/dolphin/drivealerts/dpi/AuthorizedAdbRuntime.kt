package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** Shared, authorized local ADB policy; never borrows another application's private key. */
object AuthorizedAdbRuntime {
    enum class State { READY, PORT_CLOSED, AUTH_REQUIRED, PERMISSION_DENIED, TRANSPORT_ERROR, COMMAND_REJECTED }
    data class Report(val state: State, val result: NativeAdbClient.ShellResult, val attempts: Int)

    fun classify(result: NativeAdbClient.ShellResult): State {
        if (result.success) return State.READY
        val msg = (result.message + " " + result.output).lowercase()
        return when {
            "eperm" in msg || "permission denied" in msg || "operation not permitted" in msg -> State.PERMISSION_DENIED
            "unauthorized" in msg || "authentication" in msg || "rsa" in msg || "승인" in msg -> State.AUTH_REQUIRED
            "refused" in msg || "포트가 닫" in msg || "connection reset" in msg || "connect failed" in msg -> State.PORT_CLOSED
            result.exitCode > 0 -> State.COMMAND_REJECTED
            else -> State.TRANSPORT_ERROR
        }
    }

    /** READ ONLY operations may be retried after reconnect. No state-changing command is replayed. */
    fun read(context: Context, command: String, timeoutMs: Long = 5_000L): Report {
        var last = NativeAdbClient.executeShell(context, command, timeoutMs = timeoutMs)
        var state = classify(last)
        if (state == State.PORT_CLOSED || state == State.TRANSPORT_ERROR) {
            NativeAdbClient.close()
            try { Thread.sleep(350L) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); return Report(state, last, 1) }
            last = NativeAdbClient.executeShell(context, command, timeoutMs = timeoutMs)
            state = classify(last)
            CoreLog.i("ADB_RUNTIME", "read retry state=$state")
            return Report(state, last, 2)
        }
        return Report(state, last, 1)
    }

    fun writeOnce(context: Context, command: String, timeoutMs: Long = 5_000L): Report {
        val r = NativeAdbClient.executeShell(context, command, timeoutMs = timeoutMs)
        return Report(classify(r), r, 1)
    }

    fun health(context: Context): Report = read(context, "echo dolphin_adb_authorized", timeoutMs = 3_000L)

    /** Only use from a worker thread, cancellable at each wait interval. */
    fun awaitReady(context: Context, maxWaitMs: Long = 30_000L, cancelled: () -> Boolean = { false }): Report {
        val deadline = System.currentTimeMillis() + maxWaitMs.coerceIn(0L, 60_000L)
        var current = health(context)
        while (current.state != State.READY && System.currentTimeMillis() < deadline && !cancelled()) {
            if (current.state == State.PERMISSION_DENIED) break
            try { Thread.sleep(2_000L) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); break }
            current = health(context)
        }
        return current
    }
}
