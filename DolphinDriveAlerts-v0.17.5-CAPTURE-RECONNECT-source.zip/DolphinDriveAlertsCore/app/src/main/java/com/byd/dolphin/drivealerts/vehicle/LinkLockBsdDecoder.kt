package com.byd.dolphin.drivealerts.vehicle

/**
 * LinkLock Relay 805 recovered handleBsd(I) behavior:
 * - only raw 2 is an active hazard; raw 1 or other values clear it;
 * - unchanged values do not retrigger.
 * Exact ID ADAS_BSD_STATE=0x41800008 was recorded on Korean Dolphin.
 * No user-installed LinkLock dependency, no vehicle write, no speculative side.
 */
class LinkLockBsdDecoder {
    private var lastRaw: Int? = null
    @Synchronized fun accept(raw: Int): Boolean {
        val previous = lastRaw
        lastRaw = raw
        return raw == 2 && previous != 2
    }
    @Synchronized fun isActive(): Boolean = lastRaw == 2
    @Synchronized fun reset() { lastRaw = null }
}
