package com.byd.dolphin.drivealerts.audio

import kotlin.math.max
import kotlin.math.ln
import kotlin.math.roundToInt

/** Equalizer presets, not licensed OEM/Bose DSP. Pure arithmetic for deterministic tests. */
object EqToneCurve {
    fun gainDb(s: EqSettings, hz: Int): Float {
        val bass = s.bass.coerceIn(-10, 10) * 0.6f
        val mid = s.mid.coerceIn(-10, 10) * 0.6f
        val treble = s.treble.coerceIn(-10, 10) * 0.6f
        // Smooth logarithmic crossovers avoid abrupt 250/4000 Hz cliffs on 10-band DP.
        // 5-band fallback uses the same curve at its own center frequencies.
        val basic = when {
            hz <= 125 -> bass
            hz < 500 -> crossfade(bass, mid, hz, 125, 500)
            hz <= 2000 -> mid
            hz < 8000 -> crossfade(mid, treble, hz, 2000, 8000)
            else -> treble
        }
        val preset = when (s.soundFocus) {
            SoundFocusMode.REFERENCE -> 0f
            SoundFocusMode.SURROUND -> when { hz < 250 -> 0.6f; hz < 4000 -> -0.5f; else -> 0.8f }
            SoundFocusMode.CINEMA -> when { hz < 250 -> 1.2f; hz < 4000 -> -0.4f; else -> 0.4f }
        }
        return (basic + preset).coerceIn(-6.0f, 6.0f)
    }

    private fun crossfade(a: Float, b: Float, hz: Int, lo: Int, hi: Int): Float {
        val x = ((ln(hz.toDouble()) - ln(lo.toDouble())) /
            (ln(hi.toDouble()) - ln(lo.toDouble()))).toFloat().coerceIn(0f, 1f)
        val smooth = x * x * (3f - 2f * x)
        return a + (b - a) * smooth
    }

    // Attenuating before the boost protects headroom. No additional LoudnessEnhancer stacking.
    fun headroomDb(s: EqSettings, frequencies: IntArray): Float =
        -(frequencies.maxOfOrNull { gainDb(s, it) } ?: 0f).coerceAtLeast(0f)

    fun virtualizerStrength(s: EqSettings): Short {
        val multiplier = when {
            s.centerpoint360 -> 1.0f
            s.soundFocus == SoundFocusMode.CINEMA -> 0.9f
            s.soundFocus == SoundFocusMode.SURROUND -> 0.7f
            else -> 0f
        }
        return (s.spatialStrength.coerceIn(0, 100) * 10f * multiplier)
            .roundToInt().coerceIn(0, 1000).toShort()
    }
}
