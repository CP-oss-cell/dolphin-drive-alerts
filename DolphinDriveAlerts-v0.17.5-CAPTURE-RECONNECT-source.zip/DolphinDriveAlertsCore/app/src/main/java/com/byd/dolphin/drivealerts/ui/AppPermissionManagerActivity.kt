package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.SelectedAppPermissionManager

/** Explicit per-app power/notification/accessibility/usage permission manager. */
class AppPermissionManagerActivity: Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root=ScrollView(this)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(28,20,28,28) }
        root.addView(box);setContentView(root)
        fun label(text:String)=TextView(this).apply { this.text=text;textSize=15f;setPadding(0,8,0,8) }
        box.addView(label("설치 앱 · ADB 권한 관리"))
        box.addView(label("설치된 앱을 고르고 필요한 권한만 적용합니다. 앱에서 지원하지 않는 권한이나 BYD/Android의 서명 전용 권한은 부여할 수 없습니다. 사용자 승인된 ADB 연결이 필요합니다."))
        val pm=packageManager
        val apps=pm.getInstalledApplications(0).filter { it.enabled && it.packageName!=packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names=apps.map { "${pm.getApplicationLabel(it)} (${it.packageName})" }
        if(apps.isEmpty()){box.addView(label("설치된 앱이 조회되지 않습니다"));return}
        val appPicker=Spinner(this).apply { adapter=ArrayAdapter(this@AppPermissionManagerActivity,android.R.layout.simple_spinner_dropdown_item,names) }
        box.addView(appPicker)
        val selected=linkedMapOf(
            SelectedAppPermissionManager.Action.BATTERY to "배터리 최적화 예외 · deviceidle whitelist",
            SelectedAppPermissionManager.Action.NOTIFICATION_POST to "알림 게시 권한 (앱에 선언한 경우)",
            SelectedAppPermissionManager.Action.NOTIFICATION_ACCESS to "알림 접근 (리스너 서비스 있는 앱)",
            SelectedAppPermissionManager.Action.ACCESSIBILITY to "접근성 (서비스 있는 앱)",
            SelectedAppPermissionManager.Action.USAGE_STATS to "사용기록 접근 · GET_USAGE_STATS")
        val checkboxes=selected.map { (action,title) ->
            action to CheckBox(this).apply { text=title;isChecked=false;box.addView(this) }
        }.toMap()
        val status=label("권한 항목을 선택한 뒤 조회하거나 적용하세요")
        box.addView(status)
        fun run(configure:Boolean){
            val idx=appPicker.selectedItemPosition
            if(idx !in apps.indices)return
            val pkg=apps[idx].packageName
            val actions=checkboxes.filterValues{it.isChecked}.keys
            Thread {
                val result=runCatching { SelectedAppPermissionManager.process(applicationContext,pkg,actions,configure) }
                    .getOrElse { SelectedAppPermissionManager.Result(listOf("권한 실행 오류 ${it.message}"),0,actions.size) }
                runOnUiThread { status.text="$pkg\n${result.lines.joinToString("\n")}" }
            }.start()
        }
        box.addView(Button(this).apply { text="선택한 앱의 권한 상태 조회";setOnClickListener{run(false)} })
        box.addView(Button(this).apply { text="선택한 권한을 ADB로 적용하고 확인";setOnClickListener{
            val idx=appPicker.selectedItemPosition
            if(idx !in apps.indices)return@setOnClickListener
            AlertDialog.Builder(this@AppPermissionManagerActivity).setTitle("ADB 권한 적용")
                .setMessage("${names[idx]}에 체크한 권한을 적용합니다. 접근성·알림 권한은 해당 앱에 관련 서비스가 있을 때만 적용됩니다. 진행하시겠습니까?")
                .setPositiveButton("적용"){_,_->run(true)}.setNegativeButton("취소",null).show()
        } })
    }
}
