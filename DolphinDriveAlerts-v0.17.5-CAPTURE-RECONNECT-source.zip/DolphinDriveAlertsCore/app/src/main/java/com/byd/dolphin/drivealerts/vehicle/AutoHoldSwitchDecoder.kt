package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.AlertEvent

/**
 * BYD ADAS_AVH_STATE (0x12200046) live candidate from Korean Dolphin.
 * Observed 0/1 transitions are provisionally interpreted as button disabled/enabled;
 * user real-car confirmation is still required. Raw 2 is NOT button ON/OFF:
 * engaged / released messages remain completely separate and unimplemented.
 */
internal class AutoHoldSwitchDecoder {
    private var lastSwitch: Int? = null

    @Synchronized
    fun accept(raw: Int): AlertEvent? {
        if (raw != 0 && raw != 1) return null
        val previous = lastSwitch
        lastSwitch = raw
        if (previous == null || previous == raw) return null
        return if (raw == 1) AlertEvent.AUTOHOLD_ON else AlertEvent.AUTOHOLD_OFF
    }
    @Synchronized
    fun reset() { lastSwitch = null }
}
