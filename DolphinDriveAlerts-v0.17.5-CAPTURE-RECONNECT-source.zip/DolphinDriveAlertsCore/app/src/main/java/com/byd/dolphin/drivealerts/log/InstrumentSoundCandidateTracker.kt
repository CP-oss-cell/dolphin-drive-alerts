package com.byd.dolphin.drivealerts.log

/**
 * Read-only interpretation of two instrument callback IDs observed in the 2026-10-09 log.
 * This is NOT evidence of external AVAS speaker playback and MUST NOT trigger sound/output.
 * Reference + native BYD callbacks can duplicate the same hardware event within milliseconds.
 */
internal class InstrumentSoundCandidateTracker {
    data class Observation(
        val phase: String,
        val frequencyRaw: Int?,
        val typeRaw: Int?,
        val startedAtMs: Long,
        val elapsedMs: Long?
    )

    private data class Sample(val raw: Int, val atMs: Long)
    private var freq: Sample? = null
    private var type: Sample? = null
    private var activeStartMs: Long? = null

    /** Returns one candidate edge when a close-in-time nonzero pair begins/ends. */
    fun observe(eventType: Int, value: String?, nowMs: Long): Observation? {
        if (eventType != FREQ_ID && eventType != TYPE_ID) return null
        val raw = readInteger(value) ?: return null
        // Negative BYD sentinels are not valid sound states.
        if (raw < 0) return null
        val previous = if (eventType == FREQ_ID) freq else type
        if (previous != null && previous.raw == raw && nowMs - previous.atMs in 0..DUPLICATE_WINDOW_MS) return null
        val next = Sample(raw, nowMs)
        if (eventType == FREQ_ID) freq = next else type = next
        val start = activeStartMs
        if (start != null && (freq?.raw == 0 || type?.raw == 0)) {
            activeStartMs = null
            return Observation("END", freq?.raw, type?.raw, start, (nowMs - start).coerceAtLeast(0L))
        }
        val f = freq
        val t = type
        if (start == null && f != null && t != null && f.raw > 0 && t.raw > 0 &&
            kotlin.math.abs(f.atMs - t.atMs) <= PAIR_WINDOW_MS) {
            val began = minOf(f.atMs, t.atMs)
            activeStartMs = began
            return Observation("START", f.raw, t.raw, began, null)
        }
        return null
    }

    companion object {
        const val FREQ_ID: Int = 0x26100035
        const val TYPE_ID: Int = 0x26100038
        private const val PAIR_WINDOW_MS = 400L
        private const val DUPLICATE_WINDOW_MS = 80L
        private val INT_VALUE = Regex("(?:^|[,\\s])intValue=(-?\\d+)(?:[,\\s]|$)")

        fun readInteger(value: String?): Int? = value?.trim()?.toIntOrNull()
            ?: value?.let { INT_VALUE.find(it)?.groupValues?.getOrNull(1)?.toIntOrNull() }
    }
}
