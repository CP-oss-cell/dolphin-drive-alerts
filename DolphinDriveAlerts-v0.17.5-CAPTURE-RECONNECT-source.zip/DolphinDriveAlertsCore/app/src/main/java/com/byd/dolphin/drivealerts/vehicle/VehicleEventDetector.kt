package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Emits only mappings backed by recovered real-car/reference evidence.
 * Unknown BYD raw semantics are logged but deliberately not guessed.
 */
class VehicleEventDetector(private val emit: (AlertRequest) -> Unit) {
    private var previous: RawVehicleFrame? = null
    private var previousEnergy = emptyMap<String, Int>()

    fun accept(frame: RawVehicleFrame, energy: Map<String, Int>) {
        val prev = previous
        if (prev != null) {
            if (frame.gearRaw != prev.gearRaw) decodeGear(frame.gearRaw)?.let { emit(AlertRequest(it)) }
            if (frame.epbRaw != prev.epbRaw) decodeEpb(frame.epbRaw)?.let { emit(AlertRequest(it)) }
            if (frame.energyFeedbackRaw != prev.energyFeedbackRaw) decodeRegen(frame.energyFeedbackRaw)?.let { emit(AlertRequest(it)) }
            logUnknownTransitions(prev, frame)
        }
        if (energy.isNotEmpty()) {
            if (previousEnergy.isNotEmpty()) decodeReferenceEnergy(previousEnergy, energy)
            previousEnergy = energy
        }
        previous = frame
    }

    private fun decodeGear(raw: Int?): AlertEvent? = when (raw) {
        0 -> AlertEvent.GEAR_N
        1 -> AlertEvent.GEAR_R
        2 -> AlertEvent.GEAR_D
        3 -> AlertEvent.GEAR_P
        else -> null
    }

    private fun decodeEpb(raw: Int?): AlertEvent? = when (raw) {
        1 -> AlertEvent.EPB_RELEASED
        3 -> AlertEvent.EPB_ENGAGED
        else -> null
    }

    // Recovered AutoFeedback resources identify 2=STANDARD and 3=HIGH.
    private fun decodeRegen(raw: Int?): AlertEvent? = when (raw) {
        2 -> AlertEvent.REGEN_STANDARD
        3 -> AlertEvent.REGEN_HIGH
        else -> null
    }

    private fun decodeReferenceEnergy(old: Map<String, Int>, now: Map<String, Int>) {
        changed(old, now, "energy.recycle")?.let { decodeRegen(it)?.let { e -> emit(AlertRequest(e)) } }
        changed(old, now, "energy.roadSurface")?.let {
            when (it) { 1 -> emit(AlertRequest(AlertEvent.SNOW_OFF)); 2 -> emit(AlertRequest(AlertEvent.SNOW_ON)) }
        }
        changed(old, now, "energy.operationMode")?.let { raw ->
            DriveModeDecoder.fromEnergyOperationMode(raw)?.let { event ->
                emit(AlertRequest(event))
            }
        }
    }

    private fun changed(old: Map<String, Int>, now: Map<String, Int>, key: String): Int? {
        val a = old[key] ?: return null
        val b = now[key] ?: return null
        return b.takeIf { it != a }
    }

    private fun logUnknownTransitions(a: RawVehicleFrame, b: RawVehicleFrame) {
        fun log(key: String, x: Int?, y: Int?) { if (x != null && y != null && x != y) CoreLog.i("CAL", "$key $x -> $y") }
        log("adas.avh", a.avhRaw, b.avhRaw)
        log("adas.bsd", a.bsdRaw, b.bsdRaw)
        log("adas.laneOffset", a.laneOffsetRaw, b.laneOffsetRaw)
        log("adas.tja", a.tjaRaw, b.tjaRaw)
        log("instrument.driveInterface", a.driveInterfaceRaw, b.driveInterfaceRaw)
        log("setting.driveConfig", a.driveConfigRaw, b.driveConfigRaw)
        log("instrument.deviation", a.deviationRaw, b.deviationRaw)
        log("instrument.pcwAlarm", a.pcwAlarmRaw, b.pcwAlarmRaw)
        log("instrument.laneLineState", a.laneLineStateRaw, b.laneLineStateRaw)
    }
}
