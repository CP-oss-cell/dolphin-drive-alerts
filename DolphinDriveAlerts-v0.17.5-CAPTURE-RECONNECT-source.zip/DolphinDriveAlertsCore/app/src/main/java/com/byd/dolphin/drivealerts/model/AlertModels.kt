package com.byd.dolphin.drivealerts.model

enum class OutputRoute { DRIVER_STREAM14, DRIVER_RAW14, MEDIA }
enum class AlertStyle { MALE, FEMALE, EFFECT }
enum class Side { LEFT, RIGHT, UNKNOWN }

enum class AlertEvent(
    val phrase: String,
    val priority: Int = 10,
    val cooldownMs: Long = 700L
) {
    GEAR_P("파킹"),
    GEAR_D("전진"),
    GEAR_N("중립"),
    GEAR_R("후진", priority = 20),
    REGEN_STANDARD("회생제동 스탠다드"),
    REGEN_HIGH("회생제동 하이"),
    DRIVE_ECO("에코 모드"),
    DRIVE_NORMAL("노멀 모드"),
    DRIVE_SPORT("스포츠 모드"),
    SNOW_ON("스노우 모드"),
    SNOW_OFF("스노우 모드 해제"),
    AUTOHOLD_ON("오토홀드 작동"),
    AUTOHOLD_OFF("오토홀드 중지"),
    AUTOHOLD_ENGAGED("오토홀드 체결", priority = 15),
    AUTOHOLD_RELEASED("오토홀드 해제", priority = 15),
    EPB_ENGAGED("사이드 브레이크 체결", priority = 15),
    EPB_RELEASED("사이드 브레이크 해제", priority = 15),
    ICC_ON("자율주행 모드"),
    ICC_OFF("자율주행 해제"),
    BSD_WARNING("후측방 조심", priority = 80, cooldownMs = 1800L),
    LEAD_CAR_DEPARTURE("앞차 출발", priority = 60, cooldownMs = 6000L),
    LANE_DEPARTURE("차선 이탈", priority = 70, cooldownMs = 1300L),
    EXIT_REAR_WARNING("도어를 열기 전 후측방을 주의하세요", priority = 100, cooldownMs = 2500L);

    fun phraseFor(side: Side): String = when {
        side == Side.LEFT && this in sideAware -> "왼쪽 $phrase"
        side == Side.RIGHT && this in sideAware -> "오른쪽 $phrase"
        else -> phrase
    }

    companion object {
        private val sideAware = setOf(BSD_WARNING, LANE_DEPARTURE, EXIT_REAR_WARNING)
    }
}

data class AlertRequest(
    val event: AlertEvent,
    val side: Side = Side.UNKNOWN,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    val phrase: String get() = event.phraseFor(side)
}
