package com.byd.dolphin.drivealerts.log

import android.content.Context
import android.os.SystemClock
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Evidence-oriented read-only probe for signals discovered in verified BYD apps / framework stubs.
 *
 * Safety rules:
 * - zero setters / no methods with parameters on BYD device classes;
 * - raw Feature-ID access is getInt() only;
 * - no enableDevice(), setInt(), setBuffer(), actuator or configuration writes;
 * - raw-manager calls run on an isolated daemon lane so a wedged vendor binder cannot freeze the
 *   main vehicle sampling loop.
 */
class TargetedSignalProbe(context: Context) : AutoCloseable {
    private val app = context.applicationContext
    private val devices = ConcurrentHashMap<String, Any>()
    private val methods = ConcurrentHashMap<String, Method>()
    private val misses = ConcurrentHashMap.newKeySet<String>()
    private val raw = RawFeatureIdProbe(app)

    fun snapshot(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        TARGETS.forEach { t ->
            readNoArg(t.className, t.methodName)?.let { value ->
                out["target.${t.label}"] = serialize(value)
                if (t.label == "gearbox.brakePedal" && value is Number) {
                    out["target.gearbox.brakePedal.decoded"] = when (value.toInt()) {
                        1 -> "PRESSED"
                        2 -> "RELEASED"
                        else -> "UNKNOWN(${value.toInt()})"
                    }
                }
                if (t.label == "adas.avh" && value is Number) {
                    out["target.adas.avh.evidence"] = if (value.toInt() == 2) {
                        "HOLD_ENGAGED_STRONG_CANDIDATE"
                    } else {
                        "OTHER_RAW(${value.toInt()})"
                    }
                }
            }
        }
        out.putAll(raw.snapshot())
        return out
    }

    override fun close() = raw.close()

    private fun readNoArg(className: String, methodName: String): Any? {
        val key = "$className#$methodName"
        if (key in misses) return null
        return runCatching {
            val device = devices.getOrPut(className) {
                val c = Class.forName(className)
                c.getMethod("getInstance", Context::class.java)
                    .invoke(null, BydPermissionContext.wrap(app)) ?: error("getInstance returned null")
            }
            val m = methods.getOrPut(key) { device.javaClass.getMethod(methodName) }
            m.invoke(device)
        }.getOrElse {
            misses.add(key)
            null
        }
    }

    private fun serialize(v: Any): String = when (v) {
        is IntArray -> v.joinToString(prefix = "[", postfix = "]")
        is LongArray -> v.joinToString(prefix = "[", postfix = "]")
        is FloatArray -> v.joinToString(prefix = "[", postfix = "]")
        is DoubleArray -> v.joinToString(prefix = "[", postfix = "]")
        is BooleanArray -> v.joinToString(prefix = "[", postfix = "]")
        is Array<*> -> v.joinToString(prefix = "[", postfix = "]") { it?.toString() ?: "null" }
        else -> v.toString()
    }

    private data class Target(val label: String, val className: String, val methodName: String)

    companion object {
        private const val ADAS = "android.hardware.bydauto.adas.BYDAutoADASDevice"
        private const val GEARBOX = "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice"
        private const val DIPILOT = "android.hardware.bydauto.dipilot.BYDAutoDiPilotDevice"

        private val TARGETS = listOf(
            // BYD framework / verified helper-app getters.
            Target("gearbox.brakePedal", GEARBOX, "getBrakePedalState"),
            Target("adas.avh", ADAS, "getAVHState"),
            Target("adas.bsd", ADAS, "getBSDState"),
            Target("adas.ldswType", ADAS, "getLDSWType"),
            Target("adas.lksMode", ADAS, "getLKSMode"),
            Target("adas.laneOffset", ADAS, "getLaneOffsetState"),
            Target("adas.tja", ADAS, "getTJAState"),
            Target("adas.pcwState", ADAS, "getPCWState"),

            // BeetleLauncher 1.713 contains these DiPilot getter names. We record raw values only;
            // the getter alone does NOT prove whether it is a feature switch or an event signal.
            Target("dipilot.switchCandidate.frontCarStart", DIPILOT, "getFrontCarStartState"),
            Target("dipilot.switchCandidate.controlLossWarning", DIPILOT, "getControlLossWarningState"),
            Target("dipilot.switchCandidate.openDoorAlert", DIPILOT, "getOpenDoorAlertState"),
            Target("dipilot.switchCandidate.frontTrafficCrossAlert", DIPILOT, "getFrontTrafficCrossAlertState"),
            Target("dipilot.switchCandidate.rearTrafficCrossAlert", DIPILOT, "getRearTrafficCrossAlertState"),
            Target("dipilot.switchCandidate.frontTrafficBrakeAlert", DIPILOT, "getFrontTrafficBrakeAlertState"),
            Target("dipilot.switchCandidate.rearTrafficBrakeAlert", DIPILOT, "getRearTrafficBrakeAlertState"),
            Target("dipilot.switchCandidate.sideDistanceWarning", DIPILOT, "getSideDistanceWarningState"),
            Target("dipilot.switchCandidate.collisionWarning", DIPILOT, "getCollisionWarningState"),
            Target("dipilot.switchCandidate.predictCrashAlert", DIPILOT, "getPredictCrashAlertState"),
            Target("dipilot.switchCandidate.emergencyBrakeWarning", DIPILOT, "getEmergencyBrakeWarningState"),
            Target("dipilot.switchCandidate.blindMonitor", DIPILOT, "getBlindMonitorState"),
            Target("dipilot.switchCandidate.blindMonitor1", DIPILOT, "getBlindMonitorState1"),
            Target("dipilot.switchCandidate.blindMonitor2", DIPILOT, "getBlindMonitorState2")
        )
    }
}

/** Exact read-only Feature-ID channel for the warning signals exposed by Overdrive/framework data. */
private class RawFeatureIdProbe(private val app: Context) : AutoCloseable {
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "byd-raw-feature-probe").apply { isDaemon = true }
    }
    private val inFlight = AtomicBoolean(false)
    private val values = ConcurrentHashMap<String, String>()
    @Volatile private var startedAt = 0L
    @Volatile private var closed = false

    fun snapshot(): Map<String, String> {
        if (!closed && inFlight.compareAndSet(false, true)) {
            startedAt = SystemClock.elapsedRealtime()
            values["raw.managerState"] = "probing"
            executor.execute {
                try { probe() }
                finally {
                    inFlight.set(false)
                    if (values["raw.managerState"] == "probing") values["raw.managerState"] = "idle"
                }
            }
        } else if (inFlight.get()) {
            val age = SystemClock.elapsedRealtime() - startedAt
            if (age >= 5_000L) values["raw.managerState"] = "probe-in-flight-${age}ms"
        }
        return values.toSortedMap()
    }

    private fun probe() {
        val wrapped = BydPermissionContext.wrap(app)
        val adas = runCatching {
            val c = Class.forName("android.hardware.bydauto.adas.BYDAutoADASDevice")
            c.getMethod("getInstance", Context::class.java).invoke(null, wrapped)
        }.getOrNull()
        if (adas == null) {
            values["raw.managerState"] = "adas-device-unavailable"
            return
        }

        val deviceType = runCatching {
            val m = adas.javaClass.methods.firstOrNull {
                (it.name == "getDevicetype" || it.name == "getDeviceType" || it.name == "getType") && it.parameterCount == 0
            } ?: error("device type method missing")
            (m.invoke(adas) as Number).toInt()
        }.getOrElse {
            values["raw.managerState"] = "adas-device-type-unavailable"
            return
        }
        values["raw.adasDeviceType"] = deviceType.toString()

        val manager = runCatching { app.getSystemService("auto") }.getOrNull()
        if (manager == null) {
            values["raw.managerState"] = "auto-service-unavailable"
            return
        }
        val getInt = runCatching {
            manager.javaClass.getMethod("getInt", Int::class.javaPrimitiveType!!, Int::class.javaPrimitiveType!!)
        }.getOrElse {
            values["raw.managerState"] = "getInt-unavailable"
            return
        }

        FEATURE_IDS.forEach { f ->
            readFeature(getInt, manager, deviceType, f.name, f.id)
        }
        DYNAMIC_FEATURE_FIELDS.forEach { f ->
            val id = resolveFeatureId(f.fieldName)
            if (id != null && id > 0) {
                values["raw.${f.name}.featureId"] = "${id} (0x${id.toUInt().toString(16)})"
                readFeature(getInt, manager, deviceType, f.name, id)
            } else {
                values["raw.${f.name}.featureId"] = "unresolved"
            }
        }
        values["raw.managerState"] = "idle"
    }

    private fun readFeature(getInt: Method, manager: Any, deviceType: Int, name: String, id: Int) {
        val result = runCatching { (getInt.invoke(manager, deviceType, id) as Number).toInt() }
        result.onSuccess { v ->
            values["raw.$name"] = "$v (0x${v.toUInt().toString(16)})"
        }.onFailure { t ->
            values["raw.$name"] = "ERR:${t.javaClass.simpleName}:${t.cause?.javaClass?.simpleName ?: t.message}"
        }
    }

    private fun resolveFeatureId(fieldName: String): Int? {
        val classes = listOf(
            "android.hardware.bydauto.BYDAutoFeatureIds\$Adas",
            "android.hardware.bydauto.BYDAutoFeatureIds"
        )
        for (className in classes) {
            val id = runCatching {
                val c = Class.forName(className)
                val f = c.getField(fieldName)
                f.getInt(null)
            }.getOrNull()
            if (id != null) return id
        }
        return null
    }

    override fun close() {
        closed = true
        executor.shutdownNow()
    }

    private data class Feature(val name: String, val id: Int)
    private data class DynamicFeature(val name: String, val fieldName: String)

    companion object {
        private val DYNAMIC_FEATURE_FIELDS = listOf(
            // LauncherMap 3.722 registers this ADAS event and treats intValue==0x12 as a
            // real driving-event boolean. Runtime field reflection avoids inventing an ID because
            // older public stubs expose this field as 0.
            DynamicFeature("acc.textInfoForDriver", "ADAS_ACC_TEXT_INFO_FOR_DRIVER")
        )

        private val FEATURE_IDS = listOf(
            // Overdrive AdasBlindSpotProbe: BSD is LEVEL; LCA/RCTA/DOW are COUNTER-style warnings.
            Feature("bsd.left.level", 1098907692),      // 0x4180002c
            Feature("bsd.right.level", 1098907694),     // 0x4180002e
            Feature("lca.left.counter", 1098907664),    // 0x41800010
            Feature("lca.right.counter", 1098907666),   // 0x41800012
            Feature("rcta.left.counter", 1098907668),   // 0x41800014
            Feature("rcta.right.counter", 1098907669),  // 0x41800015
            Feature("dow.left.counter", 1098907680),    // 0x41800020
            Feature("dow.right.counter", 1098907682),   // 0x41800022

            // BYD framework IDs used to correlate lane/collision/AVH transitions.
            Feature("avh.state", 304087110),             // 0x12200046
            Feature("pcw.preWarning", 852492312),        // 0x32d00018
            Feature("pcw.latentWarning", 852492313),     // 0x32d00019
            Feature("lane.leftTracking", 828375052),     // 0x3160000c
            Feature("lane.rightTracking", 828375082)     // 0x3160002a
        )
    }
}
