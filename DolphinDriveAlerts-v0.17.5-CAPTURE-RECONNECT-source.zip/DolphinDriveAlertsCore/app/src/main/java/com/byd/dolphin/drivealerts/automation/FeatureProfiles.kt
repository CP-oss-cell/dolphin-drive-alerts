package com.byd.dolphin.drivealerts.automation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** User-owned data; deliberately does not bundle or patch either third-party APK. */
data class SplitProfile(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val firstPackage: String,
    val secondPackage: String,
    val primaryPercent: Int = 50
)

data class LaunchStep(
    val id: String = UUID.randomUUID().toString(),
    val packageName: String,
    val delaySeconds: Int = 0,
    val isMedia: Boolean = false,
    val playDelaySeconds: Int = 0,
    val enabled: Boolean = true,
    val restoreBackground: Boolean = false
)

object FeatureProfiles {
    private const val PREF = "dolphin_split_sequence_v013"
    private const val SPLIT = "split_profiles"
    private const val STEPS = "launch_steps"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun splits(c: Context): List<SplitProfile> = runCatching {
        val rows = JSONArray(prefs(c).getString(SPLIT, "[]"))
        (0 until rows.length()).map { rows.getJSONObject(it) }.map { row ->
            SplitProfile(row.getString("id"), row.getString("title"), row.getString("first"),
                row.getString("second"), row.optInt("percent", 50).coerceIn(10, 90))
        }
    }.getOrDefault(emptyList())

    fun saveSplits(c: Context, list: List<SplitProfile>) {
        val array = JSONArray()
        list.forEach { p -> array.put(JSONObject().put("id",p.id).put("title",p.title)
            .put("first",p.firstPackage).put("second",p.secondPackage)
            .put("percent",p.primaryPercent.coerceIn(10, 90))) }
        prefs(c).edit().putString(SPLIT,array.toString()).apply()
    }

    fun steps(c: Context): List<LaunchStep> = runCatching {
        val rows = JSONArray(prefs(c).getString(STEPS, "[]"))
        (0 until rows.length()).map { rows.getJSONObject(it) }.map { row ->
            LaunchStep(row.getString("id"),row.getString("pkg"),row.optInt("delay",0).coerceIn(0,600),
                row.optBoolean("media",false),row.optInt("play",0).coerceIn(0,600),
                row.optBoolean("enabled",true),row.optBoolean("background",false))
        }
    }.getOrDefault(emptyList())

    fun saveSteps(c: Context, list: List<LaunchStep>) {
        val array = JSONArray()
        list.forEach { p -> array.put(JSONObject().put("id",p.id).put("pkg",p.packageName)
            .put("delay",p.delaySeconds.coerceIn(0,600)).put("media",p.isMedia)
            .put("play",p.playDelaySeconds.coerceIn(0,600))
            .put("enabled",p.enabled).put("background",p.restoreBackground)) }
        prefs(c).edit().putString(STEPS,array.toString()).apply()
    }

    fun selectedSplit(c: Context): SplitProfile? {
        val id = prefs(c).getString("last_split_id",null)
        return splits(c).firstOrNull { it.id == id }
    }
    fun markSplit(c: Context, id: String) = prefs(c).edit().putString("last_split_id",id).apply()
    fun splitEnabled(c: Context) = prefs(c).getBoolean("split_recovery_enabled", true)
    fun setSplitEnabled(c: Context, value: Boolean) = prefs(c).edit().putBoolean("split_recovery_enabled",value).apply()
    fun sequenceEnabled(c: Context) = prefs(c).getBoolean("sequence_enabled",false)
    fun setSequenceEnabled(c: Context, value: Boolean) = prefs(c).edit().putBoolean("sequence_enabled",value).apply()
}
