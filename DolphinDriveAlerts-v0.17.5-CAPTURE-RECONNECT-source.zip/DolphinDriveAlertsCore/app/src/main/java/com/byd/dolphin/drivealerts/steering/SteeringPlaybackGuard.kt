package com.byd.dolphin.drivealerts.steering

import android.os.SystemClock

/** Shared cooldown: SubAI vehicle state and Accessibility key event may report one physical gesture. */
object SteeringPlaybackGuard {
    private var lastElapsed = Long.MIN_VALUE
    @Synchronized fun allow(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (lastElapsed != Long.MIN_VALUE && now - lastElapsed < 1600L) return false
        lastElapsed = now
        return true
    }
}
