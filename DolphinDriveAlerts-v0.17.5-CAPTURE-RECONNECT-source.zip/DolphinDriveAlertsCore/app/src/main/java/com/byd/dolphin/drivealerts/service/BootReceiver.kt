package com.byd.dolphin.drivealerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.automation.AutoLaunchSequenceService
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.log.CaptureContinuity

/**
 * Starts the always-on foreground monitor after Android/BYD boot and vehicle wake signals.
 * OverDrive v48.18 showed BYD ACC/IGN broadcasts in addition to Quick Boot, so v0.12 listens
 * to those read-only lifecycle hints as well. ACC_OFF / power-disconnect are intentionally
 * observation-only and never start a fresh service.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "<null>"
        val enabled = AlertPreferences.isEnabled(context)
        val autoStart = AlertPreferences.autoStartEnabled(context)
        CoreLog.i("BOOT", "received $action enabled=$enabled autoStart=$autoStart")

        val recording = UnifiedLogCapture.state(context).takeIf {
            it.status == UnifiedLogCapture.RECORDING && it.id.isNotBlank()
        }
        if (action in STOP_SIDE_ACTIONS) {
            if (recording != null) runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            // Re-arm ignition sequence only at a documented off edge.
            context.getSharedPreferences("ignition_sequence_guard", Context.MODE_PRIVATE)
                .edit().putBoolean("armed",true).apply()
            context.stopService(Intent(context,AutoLaunchSequenceService::class.java))
            CoreLog.i("BOOT", "vehicle/power stop-side signal observed; auto sequence cancelled: $action")
            return
        }
        // A user-controlled recording must be resumed even if background auto-launch
        // of other apps was disabled. Android may still block a background FGS start.
        // Only accepted start-side hints can resume; never start on ACC_OFF.
        if (recording != null && action in CAPTURE_WAKE_ACTIONS) {
            runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            runCatching { DrivingAlertService.wakeRecording(context.applicationContext, action) }
                .onFailure { CoreLog.w("BOOT", "capture wake request failed: $action ${it.message}", it) }
        } else if (enabled && autoStart) {
            runCatching { DrivingAlertService.start(context.applicationContext) }
                .onSuccess { CoreLog.i("BOOT", "foreground service start requested: $action") }
                .onFailure { CoreLog.w("BOOT", "start failed for $action: ${it.message}", it) }
        }
        if (FeatureProfiles.sequenceEnabled(context) && action in AUTO_SEQUENCE_ACTIONS) {
            val guard=context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
            val now=System.currentTimeMillis()
            val last=guard.getLong("last_started",0L)
            val armed=guard.getBoolean("armed",true)
            val boot=action==Intent.ACTION_BOOT_COMPLETED || action.contains("QUICKBOOT_POWERON")
            if ((armed || boot) && (now-last>120_000L || armed)) {
                guard.edit().putBoolean("armed",false).putLong("last_started",now).apply()
                AutoLaunchSequenceService.start(context.applicationContext)
                CoreLog.i("BOOT", "auto launch sequence triggered by $action")
            } else CoreLog.i("BOOT","duplicate ignition launch suppressed: $action")
        }
    }

    companion object {
        private val CAPTURE_WAKE_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_USER_PRESENT, Intent.ACTION_USER_UNLOCKED,
            Intent.ACTION_SCREEN_ON, Intent.ACTION_POWER_CONNECTED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON", "com.byd.intent.action.QUICKBOOT_POWERON",
            "com.qualcomm.action.QUICKBOOT_POWERON", "com.byd.action.ACC_ON", "com.byd.action.IGN_ON",
            "com.byd.accmode.ACC_MODE_CHANGED"
        )
        private val AUTO_SEQUENCE_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED, "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON", "com.byd.intent.action.QUICKBOOT_POWERON",
            "com.qualcomm.action.QUICKBOOT_POWERON", "com.byd.action.ACC_ON", "com.byd.action.IGN_ON"
        )
        private val STOP_SIDE_ACTIONS = setOf(
            Intent.ACTION_POWER_DISCONNECTED,
            "com.byd.action.ACC_OFF",
        )
    }
}
