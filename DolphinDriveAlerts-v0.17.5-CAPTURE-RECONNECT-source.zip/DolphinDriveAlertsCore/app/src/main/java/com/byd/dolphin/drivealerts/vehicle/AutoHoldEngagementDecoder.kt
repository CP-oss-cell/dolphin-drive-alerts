package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.AlertEvent

/**
 * Evidence-informed ADAS_AVH_STATE 2 -> 1 engagement candidate.
 * The Oct-09 Dolphin trace often goes 2 (brake/standstill) -> 1 (brake released),
 * while 0 corresponds to button disabled. Require a stable 2 for 500ms to avoid
 * transient 2/1 toggles when changing gear. Real-car meaning remains pending.
 */
internal class AutoHoldEngagementDecoder {
    private var pendingAt: Long? = null
    private var engaged = false
    @Synchronized fun accept(raw: Int, now: Long): AlertEvent? {
        return when (raw) {
            2 -> { if (!engaged && pendingAt == null) pendingAt = now; null }
            1 -> {
                val released = engaged
                engaged = false; pendingAt = null
                if (released) AlertEvent.AUTOHOLD_RELEASED else null
            }
            else -> { engaged = false; pendingAt = null; null }
        }
    }
    @Synchronized fun poll(now: Long): AlertEvent? {
        val since = pendingAt ?: return null
        if (engaged || now - since < 500L) return null
        engaged = true
        pendingAt = null
        return AlertEvent.AUTOHOLD_ENGAGED
    }
    @Synchronized fun reset() { pendingAt = null; engaged = false }
}
