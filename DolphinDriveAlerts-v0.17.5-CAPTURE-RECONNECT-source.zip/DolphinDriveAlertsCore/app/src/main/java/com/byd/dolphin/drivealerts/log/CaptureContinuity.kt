package com.byd.dolphin.drivealerts.log

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persisted *evidence* of capture continuity, not a claim that an unpowered vehicle was observed.
 * All timestamps are wall-clock milliseconds; user clock changes can make intervals unreliable.
 * This component never requests vehicle writes or audio output.
 */
object CaptureContinuity {
    private const val PREF = "capture_continuity_v0175"
    private const val ID = "session_id"
    private const val HEARTBEAT = "heartbeat_ms"
    private const val EVENTS = "events"
    private const val MAX_EVENTS = 128
    private const val MAX_HEARTBEAT_INTERVAL_MS = 10_000L
    private const val GAP_THRESHOLD_MS = 20_000L

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    @Synchronized fun reset(context: Context, sessionId: String, atMs: Long = System.currentTimeMillis()) {
        val event = JSONObject().put("kind", "CAPTURE_STARTED").put("atMs", atMs)
            .put("sessionId", sessionId)
        prefs(context).edit().putString(ID, sessionId).putLong(HEARTBEAT, atMs)
            .putString(EVENTS, JSONArray().put(event).toString()).commit()
    }

    /** Service process recreated; resumes the same recorded session, not a new session. */
    @Synchronized fun serviceRestored(context: Context, sessionId: String, nowMs: Long = System.currentTimeMillis()): Long? {
        val p = prefs(context)
        if (p.getString(ID, "") != sessionId) {
            reset(context, sessionId, nowMs)
            append(context, sessionId, "JOURNAL_REPAIRED", nowMs, "state survived but journal was missing")
            return null
        }
        val last = p.getLong(HEARTBEAT, 0L)
        val elapsed = if (last > 0 && nowMs >= last) nowMs - last else null
        append(context, sessionId, "SERVICE_RESTORED", nowMs, "lastHeartbeatMs=$last elapsedMs=${elapsed ?: "unknown"}")
        if (elapsed != null && elapsed > GAP_THRESHOLD_MS) {
            append(context, sessionId, "POSSIBLE_CAPTURE_GAP", nowMs, "fromMs=$last toMs=$nowMs elapsedMs=$elapsed")
        }
        // No fabricated events between the last persisted heartbeat and service restart.
        p.edit().putLong(HEARTBEAT, nowMs).commit()
        return elapsed
    }

    /** Called by the sampling thread, not the UI. A heartbeat does not prove OEM callback delivery. */
    @Synchronized fun heartbeat(context: Context, sessionId: String, nowMs: Long = System.currentTimeMillis()) {
        val p = prefs(context)
        if (p.getString(ID, "") != sessionId) return
        if (nowMs - p.getLong(HEARTBEAT, 0L) >= MAX_HEARTBEAT_INTERVAL_MS) {
            p.edit().putLong(HEARTBEAT, nowMs).commit()
        }
    }

    /** Saves a read-only ignition hint even if the service cannot run during power-off. */
    @Synchronized fun ignitionHint(context: Context, sessionId: String, action: String, nowMs: Long = System.currentTimeMillis()) {
        append(context, sessionId, "IGNITION_HINT", nowMs, "action=$action (not proof of physical ECU power)")
    }

    @Synchronized fun tapState(context: Context, sessionId: String, state: String, detail: String = "") {
        append(context, sessionId, "BYD_TAP_$state", System.currentTimeMillis(), detail)
    }

    private fun append(context: Context, sessionId: String, kind: String, nowMs: Long, detail: String = "") {
        val p = prefs(context)
        if (p.getString(ID, "") != sessionId) return
        val previous = runCatching { JSONArray(p.getString(EVENTS, "[]").orEmpty()) }.getOrDefault(JSONArray())
        val next = JSONArray()
        for (i in maxOf(0, previous.length() - MAX_EVENTS + 1) until previous.length()) {
            next.put(previous.opt(i))
        }
        next.put(JSONObject().put("kind", kind).put("atMs", nowMs).put("detail", detail))
        p.edit().putString(EVENTS, next.toString()).commit()
    }

    @Synchronized fun snapshot(context: Context, sessionId: String): JSONObject {
        val p = prefs(context)
        val correct = p.getString(ID, "") == sessionId
        return JSONObject().put("sessionId", sessionId)
            .put("journalAvailable", correct)
            .put("lastSamplerHeartbeatMs", if (correct) p.getLong(HEARTBEAT, 0L) else JSONObject.NULL)
            .put("heartbeatIsNotOemCallbackProof", true)
            .put("powerOffEventsMayBeMissing", true)
            .put("events", if (correct) runCatching { JSONArray(p.getString(EVENTS, "[]").orEmpty()) }.getOrDefault(JSONArray()) else JSONArray())
    }

    @Synchronized fun clear(context: Context, sessionId: String) {
        if (prefs(context).getString(ID, "") == sessionId) prefs(context).edit().clear().commit()
    }
}
