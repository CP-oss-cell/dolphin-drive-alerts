# v0.17.4 GitHub 빌드 방법

1. GitHub `CP-oss-cell/dolphin-drive-alerts` 저장소의 루트에 `DolphinDriveAlerts-v0.17.4-AVAS-LOG-CORRELATION-source.zip` 파일을 업로드한다.
2. `.github/workflows/build-v0174-from-source-zip.yml` 경로에 제공된 YML을 업로드한다.
3. GitHub → Actions → `Build Dolphin Drive Alerts v0.17.4 AVAS READONLY LOG APK` → Run workflow.
4. `build-apk` 성공 후 Artifacts에서 `DolphinDriveAlerts-v0.17.4-AVAS-LOG-CORRELATION`을 내려받아 그 안의 APK를 수동 설치한다.
5. 기존 정상 기능 및 로그 수집 2버튼 정상 여부를 확인한다. 실차 로그를 생성한 후 필요하면 `tools/analyze_avas_log.py <log.zip>`으로 후보 펄스를 분석한다.

**중요:** 이 ZIP은 설치용 APK가 아니라 APK 빌드용 전체 원본이다. 안드로이드 외부 스피커로 소리를 재생하는 기능을 추가한 것이 아니다. AVAS/VESS 안전 장치를 강제로 끄지 않는다. 전체 Android Gradle CI·실차 검증은 진행 전이다.
