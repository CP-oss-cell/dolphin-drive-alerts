# Dolphin Drive Alerts v0.17.1 — 2026-10-09 실차 회귀 검토

## 증거
- 원본: 사용자 제공 `DolphinDriveLogs_20261009_102615_890_1268ec42.zip`; 10:26:15–10:40:15 KST, JSONL 38,317줄, BYD event 36,531건, snapshot 795건. ADB 진단 17건 성공/1건 실패.
- 실제 차량 USER_REPORT: BSD 경고는 감지 즉시 재생(방향지시등과 결합 및 좌우 구분 요구); ECO는 NORMAL로 재생, NORMAL은 무음, SPORT 정상; 오토홀드 체결/해제 무음; DPI 및 분할 2번 앱/비율 미작동; EQ 미약, 360·음장 미작동; 시동 앱 자동실행·미디어 재생 정상이나 HOME 복귀 실패; 5종 네비 운전석 출력은 전자음만 발생/알림 미디어 출력; ADB 앱 권한 부여 정상; 도어 경고·차선이탈·앞차출발 미시험.
- 실제 `REFERENCE_ALERT_EMIT`: SPORT 3, NORMAL 3, REGEN_STANDARD 1, REGEN_HIGH 1, AUTOHOLD_ON 3, AUTOHOLD_OFF 3. 로그에 음성 요청이 있다고 실차 청취 확인을 뜻하지 않음.
- `ENERGY_OPERATION_MODE (0x2120000e)` callback raw=2 및 1이 각 3회, raw=0은 없음. 사용자 실차 청취 관찰을 우선해 1=ECO, 2=SPORT; 0=NORMAL은 미관측 후보 유지.
- `SET_DR_ENERGY_FB (0x34100022)` raw 2/3 변화가 있어 회생제동 스탠다드/하이 출력 요청은 발생. 체결/해제라는 문구는 회생제동이 아니라 **오토홀드 체결/해제**에 해당하는 것으로 구분해야 함.
- `ADAS_AVH_STATE (0x12200046)` raw 0/1/2가 각각 발생; snapshot `avhRaw` 0 또는 1만 존재. 이벤트 2가 제동 중 발생 후 1로 돌아온 사례가 있으나 체결 여부는 OEM UI/실차 청취로 확인 필요.
- 주기적 `bsdRaw=1` 795/795건. BSD 경고 이벤트 `raw=2`는 이번 녹화 구간에서 관측되지 않았으므로 좌·우 방향지시등 동시 시나리오를 검증한 것으로 볼 수 없음.
- `dipilot` 리스너 등록 실패 ClassNotFoundException 계속 발생. 전방 차량 출발·차선·문열림 이벤트는 검증되지 않음.

## v0.17.1 소스 변경
1. `DriveModeDecoder` raw1 -> ECO, raw2 -> SPORT, raw0 -> NORMAL **미확인 후보**. raw1=NORMAL 오발화 수정. NORMAL 신호 자체 미수신 문제는 미해결.
2. BSD: `ADAS_BSD_STATE=2`만으로 음성 재생하는 구간 삭제. ON인 방향지시등 한쪽/반대쪽 OFF를 직접 SDK 반사 getter로 읽을 때만 좌/우 `AlertRequest` 생성. BSD 먼저 활성화된 뒤 방향지시등 켜는 경우를 위해 주기적 재검사, 끊기는 깜빡임 1.6초 유예. **SDK getter 이름·ON=1은 실차 미검증 후보**이므로 해당 데이터가 없을 때 무음 처리.
3. 오토홀드 실제 체결/해제 후보: `ADAS_AVH_STATE=2` 안정 500ms 후 `AUTOHOLD_ENGAGED`, 다음 2→1시 `AUTOHOLD_RELEASED`. BUTTON 0/1과 분리. 사용자 장착차 실차 검증 전 코드 후보, 잘못된 경고 방지 위해 200ms 미만 순간 변화 무시.
4. 미디어 앱: 이미 활성 MediaSession이 있으면 UI 실행하지 않고 바로 play, 없으면 기존 cold-start 폴백. `BUFFERING` 또는 `PLAYING` 읽어 홈 복귀 조건 판단. UI 실행/홈 복귀 실패는 로깅.
5. DPI: 승인된 `AuthorizedAdbRuntime` health/read/writeOnce/readback으로 진단 정합화. BYD 펌웨어가 논리 DPI 변경을 거부하거나 무시하면 성공을 꾸미지 않음.
6. 분할 비율: `am stack list` bounds에서 실제 20:80 등 요청 비율을 비교하고 다를 경우 실패 처리. 두 번째 앱 실제 실행 실패/스택 배치 엔진 문제는 **계속 미해결**. shell success를 기능 성공으로 보고하지 않음.

## 기능 보존·미해결
- 보존(USER_REPORTED_OK): 스포츠 모드, 눈길 모드, 시동시 앱 자동실행, 기존 미디어 재생, 3연타, 설치 앱 ADB 권한 부여. 변경 없음.
- 미해결: NORMAL 이벤트 미관측(0 후보), BSD 좌우 ON 신호 SDK getter 실차 미확인, DOW 문열림, 차선·앞차출발, MCon K/YouTube 실제 분할·20:80, BYD 순정 화면 DPI 적용, 5종 타 앱 운전석 물리 라우팅, Hyundai/Kia EQ DSP/360/음장. 현재 앱에 이 OEM 기능을 구현했다는 주장은 금지.
- `GlobalEqualizerEngine`: 세션 단위 3밴드 ±3dB readback만 지원, OEM 360·SoundFocus는 미지원. 무리한 증폭으로 소리 왜곡 유발하지 않음. 타 앱 스피커 출력은 `ExternalAppAudioRouter`가 대상만 저장할 뿐 BYD 오디오 라우팅 엔진은 아님. 사용자 보고 '전자음'의 발생원은 이 로그만으로 판명 불가.
- 단독 Kotlin 테스트: DriveMode/BSD/Bounds 12개, 가짜 조명 SDK Indicator 5개, MediaSession 3개, 오토홀드 후보 12개. 컴파일 및 테스트 통과 (총 32개). 소스 정적 회귀 32/32 통과. **전체 Gradle Android APK/차량 재검증 미실행**.
- 외부 AutoSplit/AutoStart/LinkLock/EVSound 설치 유도 기능 추가 없음. 원본 코드·음원 무단 복사/패키지 포함 없음.
