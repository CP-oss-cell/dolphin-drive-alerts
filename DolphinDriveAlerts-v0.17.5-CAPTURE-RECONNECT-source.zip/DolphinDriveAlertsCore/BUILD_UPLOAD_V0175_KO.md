# v0.17.5 빌드 안내

1. `DolphinDriveAlerts-v0.17.5-CAPTURE-RECONNECT-source.zip`을 GitHub 저장소 최상단(루트)에 업로드합니다.
2. `build-v0175-from-source-zip.yml`을 GitHub `.github/workflows/build-v0175-from-source-zip.yml`에 업로드합니다.
3. GitHub Actions에서 `Build Dolphin Drive Alerts v0.17.5 CAPTURE RESTART RECOVERY APK`를 `Run workflow`로 실행합니다.
4. 성공 시 Artifacts의 `DolphinDriveAlerts-v0.17.5-CAPTURE-RECONNECT` ZIP 안에서 `.apk`를 받습니다.
5. 실제 빌드 성공/실차 시험 전엔 수정본을 VERIFIED로 처리하지 마세요.

기존 검증 정상 기능 보존. v0.17.4 기준. 시동 OFF 중 물리적 전력 차단이 발생하면 그 구간은 수집 불가입니다. 오류 발생 시 YAML Actions run 로그 공유 바랍니다.
