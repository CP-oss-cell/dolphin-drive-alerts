# Dolphin Drive Alerts — Evidence Registry v0.10

이 파일은 0.10 진단판에서 확인한 사실과 아직 실차 검증이 필요한 후보를 분리한다. 다음 버전은 `VERIFIED` 또는 실차 상관관계가 추가된 항목만 자동 음성 트리거로 승격한다.

## VERIFIED — 코드/프레임워크/참조앱에서 직접 확인

| 항목 | 근거 | 0.10 처리 |
|---|---|---|
| Gearbox brake pedal | BYD SDK `getBrakePedalState()`, `PRESS=1`, `NOT_PRESS=2` | raw + decoded 로그 |
| AVH Feature ID | `ADAS_AVH_STATE = 0x12200046` | getter + exact getInt 동시 로그 |
| BSD 좌/우 | `0x4180002C / 0x4180002E`, Overdrive가 LEVEL 처리 | read-only 로그 |
| LCA 좌/우 | `0x41800010 / 0x41800012`, Overdrive가 COUNTER 처리 | read-only 로그 |
| RCTA 좌/우 | `0x41800014 / 0x41800015`, Overdrive가 COUNTER 처리 | read-only 로그 |
| DOW 좌/우 | `0x41800020 / 0x41800022`, Overdrive가 COUNTER 처리 | read-only 로그 |
| PCW pre/latent | `0x32D00018 / 0x32D00019` | read-only 로그 |
| Lane tracking L/R | `0x3160000C / 0x3160002A` | read-only 로그 |
| DiPilot listener class | Beetle `ProbeDiPilotListener` extends `android.hardware.bydauto.dipilot.AbsBYDAutoDiPilotListener` | explicit capture에서만 등록 |
| DiPilot callback signature | `onFrontCarStartStateChange(int)`, `onOpenDoorAlertStateChanged(int)`, `onAlarmTypeChanged(int)` 등 DEX method table 직접 확인 | callback raw 로그 |
| Beetle 앞차출발 메뉴 | i18n: `앞차 출발 알림 / Lead car departure alert`; `get/setFrontCarStartState` 존재 | getter는 switchCandidate로만 취급 |
| AVAS Android audio direct route | Dolphin 연구에서 Android WAV/PCM→AVAS 직접 라우팅 실패; MCU tone/preset 경로는 별개 | 임의 WAV 외부 출력 기능 미구현 |

## STRONG_CANDIDATE — 코드 상관관계는 강하지만 실차 의미 확정 전

| 항목 | 근거 | 남은 검증 |
|---|---|---|
| `AVH=2` = AutoHold 실제 체결/hold-active | LauncherMap `onAdasAvhState`: D 상태에서 값 2일 때만 AR vehicle gear를 N-like 상태로 바꿈 | Dolphin에서 D+정지+브레이크 해제 상태와 동시 로그 |
| DOW L/R = 도어 열기 전 후측방 경고 | 기능명/좌우 counter semantics가 사용자 설명과 직접 일치 | 순정 경고 1회당 해당 counter 증가 확인 |
| `onAlarmTypeChanged(int)` = 실제 경고 타입 | DiPilot listener에 별도 callback 존재 | 어떤 순정 경고에서 어떤 값이 나오는지 매핑 |

## REAL_CAR_REQUIRED — 자동 음성 연결 금지

- AVH raw `0/1/3` 의미.
- `getFrontCarStartState`, `getOpenDoorAlertState`, `getControlLossWarningState` 등 DiPilot getter가 설정값인지 현재상태인지.
- `onFrontCarStartStateChange(int)`가 설정 스위치 변경인지 실제 앞차출발 이벤트인지.
- `onDriveDepartureStateChanged(int)` / typo variant `onDrivieDepartureStateChanged(int)`의 실제 의미.
- `onLeftBehindReminderStateChanged(int)`의 실제 의미.
- `onAlarmTypeChanged(int)` 값→경고 종류 매핑.
- BSD/LCA/RCTA/DOW 실제 Dolphin 값과 clear/reset 동작.
- 차선 이탈 좌/우를 직접 구분하는 활성 경고 신호.
- `ADAS_ACC_TEXT_INFO_FOR_DRIVER`의 runtime ID 및 값 `0x12`가 Korean Dolphin에서 나타내는 실제 문구/상황.

## REJECTED / DO NOT CLAIM

- `getFrontCarStartState()`만으로 앞차출발 순간을 확정했다고 주장하지 않는다. 같은 APK에 setter와 메뉴 토글이 존재한다.
- `ADAS_CMD_BRAKE_FOOT_SENSE`를 브레이크 페달 pressed/released로 쓰지 않는다. BYD SDK상 brake-foot-sense는 감각/모드 계열이다.
- Android `AudioTrack`/WAV를 AVAS 외부 스피커에 바로 보낼 수 있다고 주장하지 않는다. 현재 Dolphin 실차 연구 근거와 배치된다.
- Feature ID를 이름만 보고 추정해서 차량 write에 사용하지 않는다.

## 0.10 실차 승격 규칙

1. 진단 캡처 시작 → 해당 순정 동작/경고 직전 마커.
2. 동작/경고 1회 발생 → 직후 마커.
3. `probe.raw.*`, `probe.target.*`, `dipilot.*`, `BYD_EVENT`의 같은 시간대 변화 비교.
4. 같은 조건을 최소 3회 반복해 동일 값/방향/카운터 패턴 확인.
5. 충돌하는 후보가 없을 때만 다음 버전에서 음성 trigger 후보로 올림.
6. 차량 제어 write는 별도 근거와 실차 안전 검증 없이는 추가하지 않음.
