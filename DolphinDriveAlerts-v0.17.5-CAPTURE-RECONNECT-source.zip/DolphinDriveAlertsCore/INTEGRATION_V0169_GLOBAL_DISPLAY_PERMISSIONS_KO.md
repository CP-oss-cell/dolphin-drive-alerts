# Dolphin Drive Alerts v0.16.9 — 전역 디스플레이 / 화면 회전 / 내비 5종 / 앱별 ADB 권한

## 사용자 요청 및 실제 반영

1. 앱별 DPI·회전 정책과 PackagePicker 제거. `AppPolicyStore` 및 구형 per-app DensityController와 전면 앱 기반 조건 로직 제거.
2. 전역 DPI: 순정(첫 설정 이전 측정 baseline 복원), 200,180,160,140,120 및 수동 100~640. `wm density` 전에 `wm density` 상태 저장, 실행 응답 확인 후 `wm density` readback, 불일치 시 직전 설정으로 복구 시도. 사용자가 명시적으로 '적용'할 때만 시스템 전체 DPI 변경. **순정 OEM 고유 모드의 원값은 기존 APK가 변경해 둔 경우 알 수 없으므로, baseline=최초 측정값을 진정한 공장값으로 오인하지 않음.**
3. 해상도/12인치 프로필: `wm size` 조회 및 `dumpsys display` 읽기 전용 프로브 추가. Android `wm size 1920x1080`은 논리적 해상도 override이며 실제 물리 패널이나 BYD 12인치 모델 스펙을 위장하지 못함. 차량 UI 훼손 위험 때문에 자동 크기 변경·허위 프로필 메뉴 미제공.
4. 전역 회전: Screen Orientation Control (원본 `Orientation Control.7.10.0.apk`, 기존 7.10.1 정밀 분석) 검증된 0×0 TYPE_APPLICATION_OVERLAY 및 `LayoutParams.screenOrientation` 방식. 순정/가로·반전/세로·반전/센서 가로·세로/사용자/방향 고정·전체 센서 모드. `DrivingAlertService` 시작·종료 시 전역 overlay 라이프사이클. 앱별 조건 및 UsageStats/접근성 감시 제거. 오버레이 권한 없거나 ROM에 의해 미지원 시 실패 표시.
5. 내비 운전석 출력 대상 **TMAP, 네이버지도, 카카오맵, 아틀란3D, MCon K** 고정 (사용자 제공 XAPK manifest에서 Atlan=`kr.mappers.AtlanSmart`, MCon K=`kr.co.telecons.mcon` 확인). 다른 앱 추가/선택 기능 제거. 항목 선택은 전용 출력 목표 저장만 구현; 타 UID 물리 오디오 출력은 미구현 `TARGET_SAVED_VENDOR_ROUTE_UNAVAILABLE` 유지. 별도 BYD UID AudioPolicy 권한 및 실제 5종 물리 스피커 검사 필요. 가짜 성공 금지.
6. 설치 앱 ADB 권한 관리: 사용자가 설치 앱 1개와 권한 종류 선택, 명령 실행·readback 분리. 배터리 whitelist, 알림 게시(pm grant), 알림 접근(cmd notification allow_listener), 접근성(enabled_accessibility_services 기존 목록 보존), 사용기록(AppOps). 패키지/서비스 식별자 검증 및 설치 여부 확인, 관련 서비스가 없으면 실행 안 함. OEM 서명 권한이나 앱 자체 팝업까지 임의 우회하지 않음.
7. 주행음성/차량 이벤트(회생, 주행모드, AVH, BSD), 기존 내장 EQ 안전모드, 자체 분할·시동 자동실행, 로그 시작/종료 2버튼 보존.

## 수용 기준/제한
- 정적 회귀 검사 `verify_v0169_prior_regressions.py` 및 `verify_v0169_global_display_permissions.py`.
- `AppPermissionRules` 명령 유효성 검증 Kotlin 9사례, 전역 DPI+권한 처리 독립 Kotlin 8사례; 테스트는 Android typed stub에 기반하므로 차량/전체 APK 동작을 입증하지 않음.
- 전체 Android Gradle 컴파일과 실차 시험 미수행; GitHub Actions 재빌드 필수.
- 앱을 가로로 강제해도 일부 세로 전용 Activity의 픽셀 UI 자체 재배치는 OEM 창 시스템과 앱 정책에 따라 안 될 수 있음.
- 디스플레이 DPI가 이미 기존 0.16.x에서 바뀐 경우, 현재 관측 초기값은 원래 BYD 순정값과 다를 수 있으므로 차량 원래 모델 스펙이 확보되기 전 임의 고정값 자동 원복 금지.
- ADB 권한은 ADB RSA가 허용돼야 적용하며, `pm grant`로 앱에서 선언하지 않은 권한이나 privileged/vendor-only 권한을 줄 수 없음.
- Android Auto 등 최신 target의 보호 서비스 접근 제한은 별개로 유지.
