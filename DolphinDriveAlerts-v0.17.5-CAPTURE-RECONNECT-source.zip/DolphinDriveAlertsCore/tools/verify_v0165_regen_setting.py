#!/usr/bin/env python3
from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/byd/dolphin/drivealerts'
s=lambda n:(p/n).read_text()
dpi=s('dpi/DensityController.kt');eq=s('audio/GlobalEqualizerEngine.kt');split=s('automation/VehicleSplitEngine.kt');seq=s('automation/AutoLaunchSequenceService.kt');media=s('automation/MediaPlaybackObserver.kt')
checks={
 'no-system-wide-density-write':not re.search(r'"wm density (?:\$|reset|[0-9])',dpi),
 'per-app-density-blocked':'PER_APP_DPI_UNSUPPORTED' in dpi,
 'read-only-density':'readOnlyStatus' in dpi,
 'eq-safe-session':'sessionId <= 0' in eq and 'attach(0)' not in eq,
 'eq-no-stacked-effects':all(x not in eq for x in ('BassBoost(','Virtualizer(','LoudnessEnhancer(')),
 'eq-max-3db':'trim.coerceIn(-10, 10) * 30' in eq,
 'split-exact-target-check':'SPLIT_TARGET_MISMATCH' in split,
 'split-ratio-not-falsely-confirmed':'SPLIT_RATIO_UNVERIFIED' in split,
 'media-session-wait':'attempts++ < 4' in media,
 'home-only-after-real-play':'if(step.restoreBackground && mediaPlaying)' in seq,
 'legacy-vehicle-voice-kept':'INSTRUMENT_2IN1_MENU_STATE' in s('vehicle/ReferenceVehicleEventBridge.kt'),
 'log-capture-kept':'UnifiedLogCapture' in s('service/DrivingAlertService.kt'),
 'version-v0165':'versionCode = 21' in (r/'app/build.gradle.kts').read_text(),
}
bridge=s('vehicle/ReferenceVehicleEventBridge.kt')
checks.update({
 'setting-listener-type':'AbsBYDAutoSettingListener' in bridge and 'android.hardware.bydauto.setting.BYDAutoSettingDevice' in bridge,
 'setting-listener-register':'setup(\n            "setting"' in bridge,
 'setting-listener-callback':'processEvent("setting", eventType, eventValue)' in bridge,
 'confirmed-id-from-realcar':'0x34100022' in bridge and 'SET_DR_ENERGY_FB_CONFIRMED' in bridge,
 'double-source-callback-and-event':'onEnergyRecycleChanged' in bridge and 'handleRecycle(value, "$source:eventType=' in bridge,
 'subai-2-standard':'2 -> emit(AlertEvent.REGEN_STANDARD' in bridge,
 'subai-3-high':'3 -> emit(AlertEvent.REGEN_HIGH' in bridge,
 'no-regen-duplicate':'if (state == lastRecycle) return' in bridge,
 'unchanged-sport-snow':'DRIVE_SPORT' in bridge and 'SNOW_ON' in bridge and 'SNOW_OFF' in bridge,
 'no-fake-eco-normal':'emit(AlertEvent.DRIVE_ECO' not in bridge and 'emit(AlertEvent.DRIVE_NORMAL' not in bridge,
})
try:ET.parse(r/'app/src/main/AndroidManifest.xml');checks['manifest-xml']=True
except:checks['manifest-xml']=False
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
print(f'V0165 {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):sys.exit(1)
