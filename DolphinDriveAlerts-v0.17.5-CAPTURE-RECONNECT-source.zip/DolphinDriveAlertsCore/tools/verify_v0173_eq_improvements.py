#!/usr/bin/env python3
"""v0.17.3 EQ improvements; pure Kotlin sound tests run if local compiler exists."""
from pathlib import Path
import shutil, subprocess, tempfile, sys
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/byd/dolphin/drivealerts'
load=lambda p:(j/p).read_text()
engine=load('audio/GlobalEqualizerEngine.kt')
curve=load('audio/EqToneCurve.kt')
prefs=load('audio/EqPreferences.kt')
ui=load('ui/AudioTuningActivity.kt')
checks={
 'spatial-user-setting': 'spatialStrength: Int = 50' in prefs and 'setSpatialStrength' in prefs,
 'ui-3band-preserved': all(x in ui for x in ('저음 (Bass)','중음 (Mid)','고음 (Treble)')),
 'ui-spatial-strength-control': '공간감 강도' in ui and 'EqPreferences.setSpatialStrength' in ui,
 'ui-reference-surround-cinema': all(x in ui for x in ('Reference','Surround','Cinema')),
 'ui-compat-status-button': '실제 EQ 적용 상태 다시 확인' in ui,
 'smoother-crossover': 'crossfade(bass, mid' in curve and 'crossfade(mid, treble' in curve,
 'legacy-safe-trim': 'EqToneCurve.headroomDb(s, frequencies)' in engine,
 'no-effects-stack': 'BassBoost(' not in engine and 'LoudnessEnhancer(' not in engine,
 'readback-both-channels': '(0 until e.channelCount).sumOf' in engine and '(0 until e.channelCount).any' in engine,
 'dp-baseline-release-before-fallback': engine.index('releaseDynamics()') < engine.index('val fallback = prepareLegacy()'),
 'session-retain-on-enable-toggle': 'sessions.remove(0)?.close()' in engine and 'sessions.clear()' not in engine.split('if (!s.enabled) {',1)[1].split('// Individual audio sessions',1)[0],
 'exclude-own-session': 'pkg == app.packageName' in engine,
 'actual-route-mode-check': 'v.virtualizationMode' in engine and 'ROUTE_NOT_VIRTUALIZED' in engine,
 'vendor-dsp-unsupported': 'UNSUPPORTED_OEM_DSP' in engine,
 'no-third-party-install': 'startActivity(' not in engine and 'installPackage' not in ui,
 'non-audio-path-unmodified-by-feature': 'setLegacyStreamType' not in engine and 'setAudioPolicy' not in engine,
 'version-code-next': 'versionCode = 29' in (root/'app/build.gradle.kts').read_text(),
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL'),name)
print('EQ-IMPROVEMENTS',sum(checks.values()), '/', len(checks))
if not all(checks.values()):sys.exit(2)
compiler=shutil.which('kotlinc')
if compiler:
    with tempfile.TemporaryDirectory(prefix='eq_v0173_') as d:
        jar=Path(d)/'test.jar'
        cmd=[compiler,str(j/'audio/EqToneCurve.kt'),str(root/'tools/tests/eq_v0173/EqFixture.kt'),str(root/'tools/tests/eq_v0173/CurveSmoke.kt'),'-include-runtime','-d',str(jar)]
        subprocess.run(cmd,check=True,timeout=80)
        subprocess.run(['java','-jar',str(jar)],check=True,timeout=30)
else:
    print('SKIP KOTLIN_EQ_TONE_AND_SPATIAL: kotlinc not installed (Gradle CI will compile)')
