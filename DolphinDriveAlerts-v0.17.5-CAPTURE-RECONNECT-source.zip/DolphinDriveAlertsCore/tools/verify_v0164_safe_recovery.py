#!/usr/bin/env python3
from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/byd/dolphin/drivealerts'
s=lambda n:(p/n).read_text()
dpi=s('dpi/DensityController.kt');eq=s('audio/GlobalEqualizerEngine.kt');split=s('automation/VehicleSplitEngine.kt');seq=s('automation/AutoLaunchSequenceService.kt');media=s('automation/MediaPlaybackObserver.kt')
checks={
 'no-system-wide-density-write':not re.search(r'"wm density (?:\$|reset|[0-9])',dpi),
 'per-app-density-blocked':'PER_APP_DPI_UNSUPPORTED' in dpi,
 'read-only-density':'readOnlyStatus' in dpi,
 'eq-safe-session':'sessionId <= 0' in eq and 'attach(0)' not in eq,
 'eq-no-stacked-effects':all(x not in eq for x in ('BassBoost(','Virtualizer(','LoudnessEnhancer(')),
 'eq-max-3db':'trim.coerceIn(-10, 10) * 30' in eq,
 'split-exact-target-check':'SPLIT_TARGET_MISMATCH' in split,
 'split-ratio-not-falsely-confirmed':'SPLIT_RATIO_UNVERIFIED' in split,
 'media-session-wait':'attempts++ < 4' in media,
 'home-only-after-real-play':'if(step.restoreBackground && mediaPlaying)' in seq,
 'legacy-vehicle-voice-kept':'INSTRUMENT_2IN1_MENU_STATE' in s('vehicle/ReferenceVehicleEventBridge.kt'),
 'log-capture-kept':'UnifiedLogCapture' in s('service/DrivingAlertService.kt'),
 'version-v0164':'versionCode = 20' in (r/'app/build.gradle.kts').read_text(),
}
try:ET.parse(r/'app/src/main/AndroidManifest.xml');checks['manifest-xml']=True
except:checks['manifest-xml']=False
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
print(f'V0164 {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):sys.exit(1)
