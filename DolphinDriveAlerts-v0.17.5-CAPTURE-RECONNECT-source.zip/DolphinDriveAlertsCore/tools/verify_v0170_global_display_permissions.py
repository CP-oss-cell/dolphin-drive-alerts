#!/usr/bin/env python3
from pathlib import Path
import re,xml.etree.ElementTree as ET,sys
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda p:(src/p).read_text()
a=read('ui/AppPolicyActivity.kt')
m=read('ui/MainActivity.kt')
r=read('dpi/RotationPolicy.kt')
c=read('dpi/DisplaySettingsController.kt')
nav=read('dpi/ExternalAppAudioRouter.kt')
p=read('dpi/SelectedAppPermissionManager.kt')
pa=read('ui/AppPermissionManagerActivity.kt')
rules=read('dpi/AppPermissionRules.kt')
acc=read('dpi/ForegroundPolicyAccessibilityService.kt')
monitor=read('dpi/ForegroundPackageMonitor.kt')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
checks={
'new-version-code':'versionCode = 26' in (root/'app/build.gradle.kts').read_text(),
'new-version-name':'0.17.0-steering-toggle-only' in (root/'app/build.gradle.kts').read_text(),
'dpi-all-options': all(q in a for q in ['"순정"','"200"','"180"','"160"','"140"','"120"','"수동"']),
'dpi-no-app-picker':'queryIntentActivities' not in a and 'getInstalledApplications' not in a,
'dpi-user-confirm':'AlertDialog.Builder(this)' in a and '차량 전체 화면 변경' in a,
'dpi-snapshot':'baseline_captured' in c and 'baseline_override' in c,
'dpi-global-adb-apply':'"wm density $target"' in c,
'dpi-stock-reset':'"wm density reset"' in c,
'dpi-readback':'verified' in c and 'readDensity(app)' in c,
'dpi-on-failure-restore':'직전 설정으로 복구를 시도했습니다' in c,
'dpi-no-automatic-by-app':'DensityController.apply(' not in acc and 'DensityController.apply(' not in monitor,
'dpi-readonly-resolution':'"wm size"' in c and '"wm size 1920x1080"' not in c,
'dpi-oem-disclaimer':'실제 패널' in a and '프로필 위장은 자동 실행하지 않습니다' in a,
'rotation-overlay-0x0':'0,' in read('dpi/OrientationOverlayController.kt') and 'TYPE_APPLICATION_OVERLAY' in read('dpi/OrientationOverlayController.kt'),
'rotation-global-pref':'global_orientation_mode_v0169' in r,
'rotation-mode-options':all(q in a for q in ['"가로 고정"','"가로 반전"','"세로 고정"','"세로 반전"','"센서 가로"','"센서 전체"']),
'rotation-no-foreground-polling':'queryEvents' not in monitor and 'AppPolicyStore' not in monitor,
'rotation-accessibility-no-app-rule':'AppPolicyStore' not in acc and 'onKeyEvent' in acc,
'rotation-service-global-start':'RotationPolicy.applyCurrent(context)' in monitor,
'legacy-app-policy-removed':not (src/'dpi/AppPolicyStore.kt').exists(),
'legacy-app-runtime-removed':not (src/'dpi/AppPolicyRuntime.kt').exists(),
'legacy-per-app-density-removed':not (src/'dpi/DensityController.kt').exists(),
'alerts-not-route-by-foreground':'AppPolicyRuntime' not in read('audio/AlertAudioPlayer.kt'),
'nav-five-and-only-five':nav.count('NavigationApp(')==6 and len(re.findall(r'NavigationApp\("[^"\n]+",\s*"[^"\n]+"\)',nav))==5,
'nav-labels':all(x in nav for x in ['"TMAP"','"네이버지도"','"카카오맵"','"아틀란3D"','"MCon K"']),
'nav-no-arbitrary-picker':'Spinner(' not in nav and '앱 선택' not in a.split('내비게이션 운전석')[1],
'nav-honest-state':'TARGET_SAVED_VENDOR_ROUTE_UNAVAILABLE' in nav and '실제 물리 라우팅은 아직 미구현' not in nav,  # UI disclaims
'nav-ui-disclaimer':'라우팅은 아직 미구현' in a,
'permission-manager-menu':'AppPermissionManagerActivity::class.java' in m,
'permission-manager-manifest':'AppPermissionManagerActivity' in manifest,
'permission-battery': 'dumpsys deviceidle whitelist +' in rules,
'permission-post':'android.permission.POST_NOTIFICATIONS' in rules,
'permission-listener':'cmd notification allow_listener' in rules,
'permission-a11y-preserve':'addAccessibilityService(current.output,component)' in p,
'permission-usage':'appops set $pkg GET_USAGE_STATS allow' in rules,
'permission-package-whitelist':'packageAllowed(packageName)' in p and 'getApplicationInfo(packageName,0)' in p,
'permission-service-check':'NotificationListenerService' in p and 'AccessibilityService' in p,
'permission-prompt':'AlertDialog.Builder' in pa and 'setPositiveButton' in pa,
'permission-readback':'readback 확인' in p,
'permission-not-fake':'팝업 제거/동작 성공의 보장이 아닙니다' in p,
'keep-two-log-buttons':m.count('text = "수집 시작"')==1 and m.count('text = "수집 종료"')==1,
'keep-auto-split':'SplitProfilesActivity::class.java' in m and 'AutoLaunchSettingsActivity::class.java' in m,
'keep-ADAS-bridge':'emit(AlertEvent.BSD_WARNING' in read('vehicle/ReferenceVehicleEventBridge.kt'),
}
try: ET.parse(root/'app/src/main/AndroidManifest.xml');checks['manifest-valid']=True
except:checks['manifest-valid']=False
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
print(f'V0169 {sum(checks.values())}/{len(checks)}')
sys.exit(0 if all(checks.values()) else 1)
