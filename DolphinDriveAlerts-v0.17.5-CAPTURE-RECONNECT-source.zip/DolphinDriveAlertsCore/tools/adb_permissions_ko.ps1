# Korean BYD Dolphin: user-authorized PC ADB shell bootstrap (no root, no OEM bypass)
# First connect your own vehicle through its permitted USB or TCP ADB interface.
$ErrorActionPreference = "Stop"
$pkg = "com.byd.dolphin.drivealerts"
$access = "$pkg/com.byd.dolphin.drivealerts.dpi.ForegroundPolicyAccessibilityService"
$listener = "$pkg/com.byd.dolphin.drivealerts.automation.MediaPlaybackObserver"
& adb get-state
if ($LASTEXITCODE -ne 0) { throw "ADB 연결 또는 RSA 승인 필요" }
function ADB($label, [string[]]$cmd) {
  Write-Host "`n[$label]" -ForegroundColor Cyan
  & adb shell @cmd
  if ($LASTEXITCODE -ne 0) { Write-Warning "$label 거부됨/미지원: 오류를 무시하지 마세요" }
}
ADB 'secure settings' @('pm','grant',$pkg,'android.permission.WRITE_SECURE_SETTINGS')
ADB '사용기록' @('appops','set',$pkg,'GET_USAGE_STATS','allow')
ADB '백그라운드' @('appops','set',$pkg,'RUN_IN_BACKGROUND','allow')
ADB '백그라운드 제한 완화' @('appops','set',$pkg,'RUN_ANY_IN_BACKGROUND','allow')
ADB '배터리 예외' @('dumpsys','deviceidle','whitelist',"+$pkg")
# Preserve the user's already enabled accessibility services.
$old = (& adb shell settings get secure enabled_accessibility_services).Trim()
if ($LASTEXITCODE -ne 0) { throw '기존 접근성 목록을 읽지 못하여 변경 중단' }
$services = @(); if ($old -and $old -ne 'null') { $services += $old.Split(':') | Where-Object { $_ } }
if ($services -notcontains $access) { $services += $access }
$new = ($services | Select-Object -Unique) -join ':'
ADB '접근성 목록' @('settings','put','secure','enabled_accessibility_services',$new)
ADB '접근성 활성화' @('settings','put','secure','accessibility_enabled','1')
ADB '알림 리스너' @('cmd','notification','allow_listener',$listener)
$apiString = (& adb shell getprop ro.build.version.sdk).Trim()
if ([int]$apiString -ge 33) { ADB '알림 게시' @('pm','grant',$pkg,'android.permission.POST_NOTIFICATIONS') }
Write-Host "`n====== READBACK ======" -ForegroundColor Cyan
ADB '사용기록 상태' @('appops','get',$pkg,'GET_USAGE_STATS')
ADB '접근성 서비스 상태' @('settings','get','secure','enabled_accessibility_services')
ADB '접근성 활성화 상태' @('settings','get','secure','accessibility_enabled')
ADB '알림 리스너 상태' @('settings','get','secure','enabled_notification_listeners')
ADB '패키지 권한' @('dumpsys','package',$pkg)
Write-Host '차량 제조사 signature/privileged 권한은 일반 ADB로 보장되지 않습니다.'
