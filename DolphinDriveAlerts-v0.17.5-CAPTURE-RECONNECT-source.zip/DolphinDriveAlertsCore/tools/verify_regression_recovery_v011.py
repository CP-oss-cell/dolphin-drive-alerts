#!/usr/bin/env python3
from pathlib import Path
import json, re
root=Path(__file__).resolve().parents[1]
read=lambda p:(root/p).read_text(encoding='utf-8')
build=read('app/build.gradle.kts')
models=read('app/src/main/java/com/byd/dolphin/drivealerts/model/AlertModels.kt')
prompts=json.loads(read('tools/voice_prompts.json'))
bridge=read('app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ReferenceVehicleEventBridge.kt')
service=read('app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt')
adb=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/NativeAdbClient.kt')
perm=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt')
ctx=read('app/src/main/java/com/byd/dolphin/drivealerts/vehicle/BydPermissionContext.kt')
manifest=read('app/src/main/AndroidManifest.xml')
probe=read('app/src/main/java/com/byd/dolphin/drivealerts/log/TargetedSignalProbe.kt')
tap=read('app/src/main/java/com/byd/dolphin/drivealerts/log/BydEventTap.kt')
registry=read('EVIDENCE_REGISTRY_V010.md')
checks=[]
def check(n,c): checks.append((n,bool(c)))
check('versionCode=11','versionCode = 11' in build)
check('versionName=0.11','0.11.0-regression-recovery' in build)
check('dadb=1.2.8','dev.mobile:dadb:1.2.8' in build)
for phrase in ['오토홀드 켜짐','오토홀드 꺼짐','자율주행 모드','자율주행 해제']:
    check('phrase:'+phrase, phrase in models and any(x['text']==phrase for x in prompts))
for old in ['오토홀드 온','오토홀드 오프','자율주행 온','자율주행 오프']:
    check('old-phrase-removed:'+old, old not in models and all(x['text']!=old for x in prompts))
check('reference-bridge-loaded','ReferenceVehicleEventBridge' in service and 'REFERENCE_EVENT_BRIDGE_STARTED' in bridge)
check('subai-menu-feature','INSTRUMENT_2IN1_MENU_STATE' in bridge)
check('subai-menu-pattern','listOf(1, 2, 1, 2, 1, 2)' in bridge and 'listOf(2, 1, 2, 1, 2, 1)' in bridge)
check('subai-acc-mode','ADAS_ACC_MODE' in bridge and '3 -> if (!accActive)' in bridge)
check('subai-recycle','2 -> emit(AlertEvent.REGEN_STANDARD' in bridge and '3 -> emit(AlertEvent.REGEN_HIGH' in bridge)
check('subai-snow','ENERGY_ROAD_SURFACE = 0x24000033' in bridge and 'emit(AlertEvent.SNOW_ON' in bridge)
check('bsd-assist-not-hazard','DO NOT emit BSD_WARNING' in bridge and 'emit(AlertEvent.BSD_WARNING' not in bridge)
check('no-autohold-guess','emit(AlertEvent.AUTOHOLD_' not in bridge)
check('adb-auth-wait','waitForAuthorization' in adb and '2_500L' in adb)
check('permission-bootstrap','dumpsys deviceidle whitelist +' in perm and 'enabled_accessibility_services' in perm and 'WRITE_SECURE_SETTINGS' in perm)
check('byd-context-checkSelf','override fun checkSelfPermission' in ctx and 'override fun checkCallingPermission' in ctx)
check('manifest-secure-settings','android.permission.WRITE_SECURE_SETTINGS' in manifest and 'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS' in manifest)

# Preserve v0.10 diagnostic safety guardrails while recovering proven paths.
forbidden = re.compile(r'\.(setInt|setBuffer|setDouble|setIntArray|enableDevice)\s*\(')
probe_code='\n'.join(line.split('//',1)[0] for line in probe.splitlines())
tap_code='\n'.join(line.split('//',1)[0] for line in tap.splitlines())
check('targeted-probe-remains-read-only', forbidden.search(probe_code) is None)
check('diagnostic-tap-remains-read-only', forbidden.search(tap_code) is None)
check('v010-evidence-guardrails-retained', 'REAL_CAR_REQUIRED' in registry and 'REJECTED / DO NOT CLAIM' in registry)
check('avh-not-auto-promoted', 'emit(AlertEvent.AUTOHOLD_' not in bridge)

for n,ok in checks: print(('PASS' if ok else 'FAIL')+': '+n)
failed=[n for n,ok in checks if not ok]
if failed: raise SystemExit('FAILED: '+', '.join(failed))
print(f'ALL {len(checks)} V0.11 REGRESSION RECOVERY GATES PASSED')
