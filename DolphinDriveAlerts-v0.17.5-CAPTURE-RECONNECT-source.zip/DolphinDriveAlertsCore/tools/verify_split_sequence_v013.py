#!/usr/bin/env python3
from pathlib import Path
import json, re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
read=lambda p:(root/p).read_text(encoding='utf-8')

build=read('app/build.gradle.kts')
models=read('app/src/main/java/com/byd/dolphin/drivealerts/model/AlertModels.kt')
prompts=json.loads(read('tools/voice_prompts.json'))
bridge=read('app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ReferenceVehicleEventBridge.kt')
service=read('app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt')
adb=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/NativeAdbClient.kt')
perm=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt')
ctx=read('app/src/main/java/com/byd/dolphin/drivealerts/vehicle/BydPermissionContext.kt')
manifest=read('app/src/main/AndroidManifest.xml')
probe=read('app/src/main/java/com/byd/dolphin/drivealerts/log/TargetedSignalProbe.kt')
readonly=read('app/src/main/java/com/byd/dolphin/drivealerts/log/ReadOnlySignalProbe.kt')
tap=read('app/src/main/java/com/byd/dolphin/drivealerts/log/BydEventTap.kt')
registry=read('EVIDENCE_REGISTRY_V010.md')
rotation=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/OrientationOverlayController.kt')
monitor=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/ForegroundPackageMonitor.kt')
policy=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/AppPolicyStore.kt')
accessibility=read('app/src/main/java/com/byd/dolphin/drivealerts/dpi/ForegroundPolicyAccessibilityService.kt')
eqprefs=read('app/src/main/java/com/byd/dolphin/drivealerts/audio/EqPreferences.kt')
eqengine=read('app/src/main/java/com/byd/dolphin/drivealerts/audio/GlobalEqualizerEngine.kt')
eqactivity=read('app/src/main/java/com/byd/dolphin/drivealerts/ui/AudioTuningActivity.kt')
boot=read('app/src/main/java/com/byd/dolphin/drivealerts/service/BootReceiver.kt')
keycatalog=read('app/src/main/java/com/byd/dolphin/drivealerts/steering/BydSteeringKeyCatalog.kt')
steeringprefs=read('app/src/main/java/com/byd/dolphin/drivealerts/steering/SteeringTriggerPreferences.kt')
steeringdetector=read('app/src/main/java/com/byd/dolphin/drivealerts/steering/SteeringTripleTapDetector.kt')
prefs=read('app/src/main/java/com/byd/dolphin/drivealerts/config/AlertPreferences.kt')
main=read('app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt')
appPolicy=read('app/src/main/java/com/byd/dolphin/drivealerts/ui/AppPolicyActivity.kt')
domain_audit=read('DA017_V012_DOMAIN_AUDIT.md')

checks=[]
def check(n,c): checks.append((n,bool(c)))

# Preserve v0.11 recovered behavior.
check('versionCode=13','versionCode = 13' in build)
check('versionName=0.13','0.13.0-split-sequence-integration-candidate' in build)
check('dadb=1.2.8','dev.mobile:dadb:1.2.8' in build)
for phrase in ['오토홀드 켜짐','오토홀드 꺼짐','자율주행 모드','자율주행 해제']:
    check('phrase:'+phrase, phrase in models and any(x['text']==phrase for x in prompts))
check('reference-bridge-retained','ReferenceVehicleEventBridge' in service and 'INSTRUMENT_2IN1_MENU_STATE' in bridge)
check('subai-menu-pattern','listOf(1, 2, 1, 2, 1, 2)' in bridge and 'listOf(2, 1, 2, 1, 2, 1)' in bridge)
check('subai-acc-recycle-snow','ADAS_ACC_MODE' in bridge and 'REGEN_STANDARD' in bridge and 'ENERGY_ROAD_SURFACE = 0x24000033' in bridge)
check('no-autohold-guess','emit(AlertEvent.AUTOHOLD_' not in bridge)
check('no-bsd-assist-hazard','DO NOT emit BSD_WARNING' in bridge and 'emit(AlertEvent.BSD_WARNING' not in bridge)
check('adb-auth-wait','waitForAuthorization' in adb)
check('permission-bootstrap-retained','enabled_accessibility_services' in perm and 'dumpsys deviceidle whitelist +' in perm)
check('byd-context-retained','override fun checkSelfPermission' in ctx and 'override fun checkCallingPermission' in ctx)

# DA-014 orientation.
check('orientation-overlay-type','TYPE_APPLICATION_OVERLAY' in rotation)
check('orientation-zero-size','WindowManager.LayoutParams(\n                0,\n                0,' in rotation)
check('orientation-screenOrientation','screenOrientation' in rotation and 'updateViewLayout' in rotation and 'addView' in rotation)
check('orientation-stock-restore','SCREEN_ORIENTATION_UNSPECIFIED' in rotation and 'removeViewImmediate' in rotation)
check('orientation-package-rule','orientationMode: OrientationMode' in policy and 'x.getOrNull(4)' in policy)
check('orientation-usage-monitor','UsageStatsManager' in monitor and 'MOVE_TO_FOREGROUND' in monitor and '1, TimeUnit.SECONDS' in monitor)
check('orientation-accessibility-fastpath','OrientationOverlayController.apply' in accessibility)
check('orientation-ui','가로 고정' in appPolicy and '센서 가로' in appPolicy)
check('usage-stats-appop','GET_USAGE_STATS' in perm and 'PACKAGE_USAGE_STATS' in manifest)
check('overlay-permission','SYSTEM_ALERT_WINDOW' in manifest)

# DA-015 EQ.
for cls in ['Equalizer','BassBoost','Virtualizer','LoudnessEnhancer']:
    check('eq-class:'+cls, cls in eqengine)
check('eq-global-session0','attach(0)' in eqengine)
check('eq-session-broadcast','OPEN_AUDIO_EFFECT_CONTROL_SESSION' in eqengine and 'CLOSE_AUDIO_EFFECT_CONTROL_SESSION' in eqengine)
check('eq-3band','bass: Int' in eqprefs and 'mid: Int' in eqprefs and 'treble: Int' in eqprefs)
check('eq-centerpoint','centerpoint360' in eqprefs and 'Centerpoint 360' in eqactivity)
check('eq-focus-modes', all(x in eqprefs for x in ['REFERENCE','SURROUND','CINEMA']))
check('eq-ui-simple', all(x in eqactivity for x in ['저음 (Bass)','중음 (Mid)','고음 (Treble)','Reference · 원음 중심','Surround · 공간감 확대','Cinema · 저음/공간감 강조']))
check('eq-modify-audio-settings','android.permission.MODIFY_AUDIO_SETTINGS' in manifest)
check('eq-service-lifecycle','GlobalEqualizerEngine' in service and 'equalizerEngine?.refresh()' in service and 'equalizerEngine?.close()' in service)

# Auto-start / background.
check('autostart-default-on','getBoolean(KEY_AUTOSTART, true)' in prefs)
check('bootreceiver-uses-autostart','autoStartEnabled' in boot)
for action in [
    'BOOT_COMPLETED','MY_PACKAGE_REPLACED','USER_PRESENT','USER_UNLOCKED','SCREEN_ON',
    'android.intent.action.ACTION_POWER_CONNECTED','android.intent.action.ACTION_POWER_DISCONNECTED',
    'QUICKBOOT_POWERON','com.byd.intent.action.QUICKBOOT_POWERON','com.qualcomm.action.QUICKBOOT_POWERON',
    'com.byd.action.ACC_ON','com.byd.action.ACC_OFF','com.byd.action.IGN_ON','com.byd.accmode.ACC_MODE_CHANGED'
]:
    check('boot-action:'+action, action in manifest)
check('power-action-typo-removed','android.intent.action.POWER_CONNECTED' not in manifest)
check('stop-side-does-not-start','STOP_SIDE_ACTIONS' in boot and 'Intent.ACTION_POWER_DISCONNECTED' in boot and 'com.byd.action.ACC_OFF' in boot and 'return' in boot)
check('service-stopWithTask-false','android:stopWithTask="false"' in manifest)
check('service-start-sticky','return START_STICKY' in service)
check('autostart-ui','시동 시 자동 백그라운드 실행' in main)


# DA-017 OverDrive steering key reference integration.
for code in [87,88,289,291,292,293,294,304,305,313,317,302,303,306,312]:
    check('byd-key:'+str(code), re.search(r'\b'+str(code)+r'\b', keycatalog) is not None)
check('byd-key-label-log','bydKey=$bydLabel' in steeringdetector and 'BydSteeringKeyCatalog.label' in steeringdetector)
check('byd-mode-default-match','BydSteeringKeyCatalog.MODE' in steeringdetector and 'KeyEvent.KEYCODE_MENU' in steeringdetector)
check('byd-previous-default-match','BydSteeringKeyCatalog.PREVIOUS' in steeringdetector and 'KeyEvent.KEYCODE_BACK' in steeringdetector)
check('legacy-mode-migration','"MENU" -> SteeringTriggerMode.BYD_MODE' in steeringprefs and '"BACK" -> SteeringTriggerMode.BYD_PREVIOUS' in steeringprefs)
check('triple-window-preserved','windowMs = 1_200L' in steeringdetector)

# XML parses and safety guardrails.
ET.fromstring(manifest)
check('manifest-xml-parse', True)
forbidden = re.compile(r'\.(setInt|setBuffer|setDouble|setIntArray|enableDevice)\s*\(')

# DA-017 extended read-only signal discovery surface.
extended_classes = [
    'BYDAutoAcDevice','BYDAutoChargingDevice','BYDAutoDoorLockDevice','BYDAutoRearViewMirrorDevice',
    'BYDAutoEngineDevice','BYDAutoLightDevice','BYDAutoMultimediaDevice','BYDAutoPM2p5Device',
    'BYDAutoPowerDevice','BYDAutoSafetyBeltDevice','BYDAutoSensorDevice','BYDAutoStatisticDevice',
    'BYDAutoTyreDevice','BYDAutoVehicleHealthDevice','BYDAutoWiperDevice'
]
for cls in extended_classes:
    check('readonly-class:'+cls, cls in readonly)
check('readonly-extended-rate-limit','EXTENDED_EVERY_N_SNAPSHOTS = 5L' in readonly and 'snapshotCount % EXTENDED_EVERY_N_SNAPSHOTS' in readonly)
check('readonly-zero-arg-only','m.parameterTypes.isEmpty()' in readonly and '(m.name.startsWith("get") || m.name.startsWith("is"))' in readonly)
readonly_code='\n'.join(line.split('//',1)[0] for line in readonly.splitlines())
check('readonly-no-write-calls', forbidden.search(readonly_code) is None)
probe_code='\n'.join(line.split('//',1)[0] for line in probe.splitlines())
tap_code='\n'.join(line.split('//',1)[0] for line in tap.splitlines())
check('targeted-probe-remains-read-only', forbidden.search(probe_code) is None)
check('diagnostic-tap-remains-read-only', forbidden.search(tap_code) is None)
check('evidence-guardrails-retained','REAL_CAR_REQUIRED' in registry and 'REJECTED / DO NOT CLAIM' in registry)

# DA-017 domain audit completion surface.
for domain in ['Camera / Live View','Recording','Surveillance','Remote','Charging / SOH','Trips','Seat Positions','Cluster Cast','Network / Integration']:
    check('domain-audit:'+domain, domain in domain_audit)
check('domain-audit-camera-native','DiLink 4 AVMCamera + DiLink 5 QCarCam' in domain_audit)
check('domain-audit-charging-readonly','PARTIAL_READ_DISCOVERY' in domain_audit and 'getter-only' in domain_audit)
check('domain-audit-no-overclaim','290개 Web API endpoint 각각' in domain_audit and 'REALCAR_VERIFIED' in domain_audit)


# New DA-016 / DA-027 split+sequence integration static gates.
auto_dir=Path('app/src/main/java/com/byd/dolphin/drivealerts/automation')
files={f.stem:read(str(f)) for f in (root/auto_dir).glob('*.kt')}
for name in ['FeatureProfiles','AppSelection','VehicleSplitEngine','SplitRecoveryService',
             'SplitProfilesActivity','AutoLaunchSettingsActivity','AutoLaunchSequenceService','MediaPlaybackObserver']:
    check('new-class:'+name,name in files)
check('split-named-shortcuts','setShortLabel(p.title.take(30))' in files['SplitProfilesActivity'] and 'requestPinShortcut' in files['SplitProfilesActivity'])
check('split-dynamic-shortcuts','addDynamicShortcuts' in files['SplitProfilesActivity'])
check('split-two-app-selection','firstPackage' in files['FeatureProfiles'] and 'secondPackage' in files['FeatureProfiles'])
check('split-ratio-1-percent','progress+10' in files['SplitProfilesActivity'] and 'coerceIn(10, 90)' in files['FeatureProfiles'])
check('split-ratio-adb','resize-docked-stack' in files['VehicleSplitEngine'] and 'wm size' in files['VehicleSplitEngine'])
check('split-status-readback','am stack list' in files['VehicleSplitEngine'])
check('split-restore-when-return','if(external && isTarget' in files['SplitRecoveryService'])
check('split-restore-saved-ratio','applyRatio(this,p.primaryPercent)' in files['SplitRecoveryService'])
check('split-restore-native-fallback','VehicleSplitEngine.launch(this,p)' in files['SplitRecoveryService'])
check('split-autostart-link','startsWith("split:")' in files['AutoLaunchSequenceService'])
check('autostart-step-per-app','data class LaunchStep' in files['FeatureProfiles'] and 'saveSteps' in files['FeatureProfiles'])
check('autostart-seconds-clamped','coerceIn(0,600)' in files['FeatureProfiles'])
check('autostart-enabled-toggle','sequenceEnabled' in files['FeatureProfiles'] and 'setSequenceEnabled' in files['FeatureProfiles'])
check('autostart-ignition-guard','ignition_sequence_guard' in boot and 'last_started' in boot)
check('autostart-off-cancels','context.stopService(Intent(context,AutoLaunchSequenceService::class.java))' in boot)
check('autostart-independent-of-alert-service','if (enabled && autoStart)' in boot and 'if (FeatureProfiles.sequenceEnabled(context)' in boot)
check('autostart-cancellable','generation!=seq' in files['AutoLaunchSequenceService'])
check('autostart-wakelock-bounded','lock.acquire(600_000L)' in files['AutoLaunchSequenceService'])
check('autostart-media-app-specific','getActiveSessions(component).firstOrNull' in files['MediaPlaybackObserver'])
check('autostart-play-delay','pause(step.playDelaySeconds,seq)' in files['AutoLaunchSequenceService'])
check('autostart-media-background-attempt','input keyevent 3' in files['AutoLaunchSequenceService'])
check('camera-guard','OEM camera foreground; skipped' in files['AutoLaunchSequenceService'])
check('manifest-split-sequence-components',all(x in manifest for x in ['SplitProfilesActivity','SplitShortcutActivity','SplitRecoveryService','AutoLaunchSettingsActivity','AutoLaunchSequenceService','MediaPlaybackObserver']))
check('main-ui-split-sequence-links','SplitProfilesActivity::class.java' in main and 'AutoLaunchSettingsActivity::class.java' in main)
check('no-hardcoded-vehicle-write',all(x not in '\n'.join(files.values()) for x in ['BYDAutoBodyworkDevice.set','BYDAutoAcDevice.set']))

for n,ok in checks: print(('PASS' if ok else 'FAIL')+': '+n)
failed=[n for n,ok in checks if not ok]
if failed: raise SystemExit('FAILED: '+', '.join(failed))
print(f'ALL {len(checks)} V0.13 SPLIT/SEQUENCE INTEGRATION STATIC GATES PASSED')
