#!/usr/bin/env python3
from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/byd/dolphin/drivealerts'
s=lambda n:(p/n).read_text()
dpi=s('dpi/DensityController.kt');eq=s('audio/GlobalEqualizerEngine.kt');split=s('automation/VehicleSplitEngine.kt');seq=s('automation/AutoLaunchSequenceService.kt');media=s('automation/MediaPlaybackObserver.kt')
checks={
 'no-system-wide-density-write':not re.search(r'"wm density (?:\$|reset|[0-9])',dpi),
 'per-app-density-blocked':'PER_APP_DPI_UNSUPPORTED' in dpi,
 'read-only-density':'readOnlyStatus' in dpi,
 'eq-safe-session':'sessionId <= 0' in eq and 'attach(0)' not in eq,
 'eq-no-stacked-effects':all(x not in eq for x in ('BassBoost(','Virtualizer(','LoudnessEnhancer(')),
 'eq-max-3db':'trim.coerceIn(-10, 10) * 30' in eq,
 'split-exact-target-check':'SPLIT_TARGET_MISMATCH' in split,
 'split-ratio-not-falsely-confirmed':'SPLIT_RATIO_UNVERIFIED' in split,
 'media-session-wait':'attempts++ < 4' in media,
 'home-only-after-real-play':'if(step.restoreBackground && mediaPlaying)' in seq,
 'legacy-vehicle-voice-kept':'INSTRUMENT_2IN1_MENU_STATE' in s('vehicle/ReferenceVehicleEventBridge.kt'),
 'log-capture-kept':'UnifiedLogCapture' in s('service/DrivingAlertService.kt'),
 'version-v0167':'versionCode = 23' in (r/'app/build.gradle.kts').read_text(),
}
bridge=s('vehicle/ReferenceVehicleEventBridge.kt')
checks.update({
 'setting-listener-type':'AbsBYDAutoSettingListener' in bridge and 'android.hardware.bydauto.setting.BYDAutoSettingDevice' in bridge,
 'setting-listener-register':'setup(\n            "setting"' in bridge,
 'setting-listener-callback':'processEvent("setting", eventType, eventValue)' in bridge,
 'confirmed-id-from-realcar':'0x34100022' in bridge and 'SET_DR_ENERGY_FB_CONFIRMED' in bridge,
 'double-source-callback-and-event':'onEnergyRecycleChanged' in bridge and 'handleRecycle(value, "$source:eventType=' in bridge,
 'subai-2-standard':'2 -> emit(AlertEvent.REGEN_STANDARD' in bridge,
 'subai-3-high':'3 -> emit(AlertEvent.REGEN_HIGH' in bridge,
 'no-regen-duplicate':'if (state == lastRecycle) return' in bridge,
 'unchanged-sport-snow':'DRIVE_SPORT' in s('vehicle/DriveModeDecoder.kt') and 'SNOW_ON' in bridge and 'SNOW_OFF' in bridge,
 'safe-mapping-centralized':'DriveModeDecoder.fromEnergyOperationMode(type)' in bridge,
 'energy-event-fallback':'ENERGY_OPERATION_MODE_OBSERVED = 0x2120000e' in bridge and 'handleOperationMode(value, "energy:eventType=' in bridge,
 'polling-uses-shared-codec':'DriveModeDecoder.fromEnergyOperationMode(raw)' in s('vehicle/VehicleEventDetector.kt'),
 'user-mapping-0-eco-1-normal-2-sport':all(t in s('vehicle/DriveModeDecoder.kt') for t in ['0 -> AlertEvent.DRIVE_ECO','1 -> AlertEvent.DRIVE_NORMAL','2 -> AlertEvent.DRIVE_SPORT']),
 'do-not-map-drive-interface':'DriveModeDecoder.fromEnergyOperationMode' not in s('vehicle/BydVehicleReader.kt'),
})
try:ET.parse(r/'app/src/main/AndroidManifest.xml');checks['manifest-xml']=True
except:checks['manifest-xml']=False
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
print(f'V0167 {sum(checks.values())}/{len(checks)}')
# New focused acceptance gates: no external AutoStart/AutoSplit installation, no
# duplicate manual diagnostics, and the user-requested AutoHold button alerts.
decoder=s('vehicle/AutoHoldSwitchDecoder.kt')
model=s('model/AlertModels.kt')
setting=s('ui/MainActivity.kt')
splitui=s('automation/SplitProfilesActivity.kt')
autoUI=s('automation/AutoLaunchSettingsActivity.kt')
profiles=s('automation/FeatureProfiles.kt')
boot=s('service/BootReceiver.kt')
checks.update({
  'autohold-confirmed-event-id': 'ADAS_AVH_STATE_CONFIRMED = 0x12200046' in bridge,
  'autohold-adas-only': 'source == "adas" && eventType == ADAS_AVH_STATE_CONFIRMED' in bridge,
  'autohold-decoder-in-receiver':'autoHoldButtonDecoder.accept(value)' in bridge,
  'autohold-button-on':'raw == 1) AlertEvent.AUTOHOLD_ON' in decoder,
  'autohold-button-off':'else AlertEvent.AUTOHOLD_OFF' in decoder,
  'autohold-ignore-engagement': 'raw != 0 && raw != 1' in decoder and 'AUTOHOLD_ENGAGED' not in decoder,
  'autohold-dedup':'previous == raw' in decoder,
  'autohold-initialize-silent':'previous == null' in decoder,
  'autohold-reset-on-close':'autoHoldButtonDecoder.reset()' in bridge,
  'autohold-thread-safe':'@Synchronized' in decoder,
  'autohold-voice-phrases': all(v in model for v in ['AUTOHOLD_ON("오토홀드 작동")','AUTOHOLD_OFF("오토홀드 중지")']),
  'autohold-voice-assets': all(v in (r/'tools/voice_prompts.json').read_text() for v in ['"오토홀드 작동"','"오토홀드 중지"']),
  'autohold-engagement-separate':all(v in model for v in ['AUTOHOLD_ENGAGED("오토홀드 체결"','AUTOHOLD_RELEASED("오토홀드 해제"']),
  'no-external-split-runtime':'OriginalAutoSplitBridge' not in split and 'originalAutoSplitProfileId' not in split,
  'no-external-autostart-runtime':'OriginalAutoStartBridge' not in seq and 'externalAutoStartPreferred' not in seq,
  'no-external-boot-hook':'OriginalAutoStartBridge' not in boot and 'externalAutoStartPreferred' not in boot,
  'no-external-app-install-menus':'원본 AutoSplit' not in splitui and '원본 AutoStart' not in autoUI,
  'no-external-profile-id':'originalAutoSplitProfileId' not in splitui and 'originalAutoSplitProfileId' not in profiles,
  'no-external-autostart-optin':'externalAutoStartPreferred' not in autoUI and 'externalAutoStartPreferred' not in profiles,
  'legacy-original-autostart-removed': not (p/'automation/OriginalAutoStartBridge.kt').exists(),
  'legacy-original-autosplit-removed':not (p/'automation/OriginalAutoSplitBridge.kt').exists(),
  'no-system-wide-density-test-buttons': all(t not in setting for t in ['DPI 140 직접 시험','DPI 순정 원복','wm density 140','wm density reset']),
  'no-duplicated-adb-diagnostics': 'ADB 권한 상태 다시 확인' not in setting and 'ADB 연결/현재 DPI 조회' not in setting,
  'no-manual-alert-debug-menu':'section("알림 테스트")' not in setting and '선택 알림 즉시 재생' not in setting,
  'retain-voice-output-choice':'운전석(stream 14)' in setting and '여성' in setting,
  'retain-unified-log-two-buttons':setting.count('text = "수집 시작"')==1 and setting.count('text = "수집 종료"')==1,
  'retain-autostart-editor':'AutoLaunchSettingsActivity::class.java' in setting and 'FeatureProfiles.steps' in autoUI,
  'retain-split-shortcuts':'ShortcutInfo.Builder' in splitui and 'SplitProfile(' in profiles,
  'retain-split-ratio':'val primaryPercent: Int' in profiles and 'seek.progress+10' in splitui,
  'retain-equlizer':'AudioTuningActivity::class.java' in setting,
  'version-name':'0.16.7-autohold-button-menu-cleanup' in (r/'app/build.gradle.kts').read_text(),
})
for k in list(checks):
 if k.startswith('autohold') or k.startswith('no-') or k.startswith('retain-') or k.startswith('legacy-') or k=='version-name':
  print(('PASS' if checks[k] else 'FAIL')+': '+k)
print(f'V0167 total {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):sys.exit(1)
