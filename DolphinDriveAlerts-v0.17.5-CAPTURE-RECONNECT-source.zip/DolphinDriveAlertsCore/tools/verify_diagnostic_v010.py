#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
probe = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/log/TargetedSignalProbe.kt').read_text(encoding='utf-8')
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
logger = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/log/RawSignalLogger.kt').read_text(encoding='utf-8')
reader = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/BydVehicleReader.kt').read_text(encoding='utf-8')
tap = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/log/BydEventTap.kt').read_text(encoding='utf-8')
dipilot_stub = (root / 'app/src/main/java/android/hardware/bydauto/dipilot/AbsBYDAutoDiPilotListener.java').read_text(encoding='utf-8')
catalog = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/log/FeatureIdCatalog.kt').read_text(encoding='utf-8')
service = (root / 'app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt').read_text(encoding='utf-8')
registry = (root / 'EVIDENCE_REGISTRY_V010.md').read_text(encoding='utf-8')

checks = []
def check(name, cond):
    checks.append((name, bool(cond)))

check('versionCode=10', 'versionCode = 10' in build)
check('versionName=0.10.0-diagnostic-capture', 'versionName = "0.10.0-diagnostic-capture"' in build)
check('raw-log-schema=4', 'put("schema", 4)' in logger)
check('brake-pedal-read', 'getBrakePedalState' in reader and 'brakePedalRaw' in logger)
check('DOW-left-right', '1098907680' in probe and '1098907682' in probe)
check('BSD-left-right', '1098907692' in probe and '1098907694' in probe)
check('LCA-left-right', '1098907664' in probe and '1098907666' in probe)
check('RCTA-left-right', '1098907668' in probe and '1098907669' in probe)
check('AVH-exact-id', '304087110' in probe and 'HOLD_ENGAGED_STRONG_CANDIDATE' in probe)
check('PCW-pre-latent', '852492312' in probe and '852492313' in probe)
check('lane-tracking-left-right', '828375052' in probe and '828375082' in probe)
check('runtime-ACC-text-feature', 'ADAS_ACC_TEXT_INFO_FOR_DRIVER' in probe)
check('DiPilot-front-car-switch-candidate', 'dipilot.switchCandidate.frontCarStart' in probe)
check('DiPilot-open-door-switch-candidate', 'dipilot.switchCandidate.openDoorAlert' in probe)
check('DiPilot-listener-stub', 'class AbsBYDAutoDiPilotListener' in dipilot_stub and 'onFrontCarStartStateChange' in dipilot_stub)
check('DiPilot-front-car-callback-log', 'onFrontCarStartStateChange' in tap and 'dipilot.frontCarStart' in tap)
check('DiPilot-alarm-type-callback-log', 'onAlarmTypeChanged' in tap and 'dipilot.alarmType' in tap)
check('DiPilot-AEB-active-callback-log', 'onAEBDecActiveChanged' in tap and 'dipilot.aebDecActive' in tap)
check('DiPilot-open-door-callback-log', 'onOpenDoorAlertStateChanged' in tap and 'dipilot.openDoorAlert' in tap)
check('DiPilot-rear-crash-callback-log', 'onRearCrashAlertStateChanged' in tap and 'dipilot.rearCrashAlert' in tap)
check('DiPilot-listener-lazy-only', 'ensureBydEventTap()' in service and 'Intentionally do NOT start BydEventTap here' in service)
check('DiPilot-feature-catalog-optional', 'BYDAutoFeatureIds\\$DiPilot' in catalog)

# Only executable call sites matter; comments/doc text can mention forbidden APIs.
forbidden = re.compile(r'\.(setInt|setBuffer|setDouble|setIntArray|enableDevice)\s*\(')
probe_code = '\n'.join(line.split('//', 1)[0] for line in probe.splitlines())
tap_code = '\n'.join(line.split('//', 1)[0] for line in tap.splitlines())
check('targeted-probe-no-write-calls', forbidden.search(probe_code) is None)
check('event-tap-no-write-calls', forbidden.search(tap_code) is None)
check('evidence-registry-guardrails', 'REAL_CAR_REQUIRED' in registry and 'REJECTED / DO NOT CLAIM' in registry and 'AVH=2' in registry)

for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)

failed = [name for name, ok in checks if not ok]
if failed:
    print('FAILED CHECKS:', ', '.join(failed), file=sys.stderr)
    raise SystemExit(1)
print(f'ALL {len(checks)} V0.10 STATIC GATES PASSED')
