#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(__file__).resolve().parents[1]; src=p/'app/src/main/java/com/byd/dolphin/drivealerts'
main=(src/'ui/MainActivity.kt').read_text(); detector=(src/'steering/SteeringTripleTapDetector.kt').read_text(); pref=(src/'steering/SteeringTriggerPreferences.kt').read_text(); svc=(src/'service/DrivingAlertService.kt').read_text(); bridge=(src/'vehicle/ReferenceVehicleEventBridge.kt').read_text(); build=(p/'app/build.gradle.kts').read_text()
section=main.split('box.addView(section("핸들 메뉴/이전 버튼 3연타"))')[1].split('box.addView(section("자동 실행 / 백그라운드"))')[0]
checks={
 'only-one-control':section.count('CheckBox(this)')==1 and 'Button(this)' not in section and 'Spinner(this)' not in section,
 'toggle-state-is-persistent':'SteeringTriggerPreferences.enabled(this@MainActivity)' in section and 'SteeringTriggerPreferences.setEnabled(this@MainActivity, checked)' in section,
 'no-key-learning-ui':all(x not in main for x in ['핸들 버튼 학습 시작','학습된 버튼','학습 대기 중','키값 캡처','키 값 캡처','감지 버튼']),
 'no-trigger-mode-spinner':'SteeringTriggerMode' not in main and 'triggerModes' not in main,
 'no-one-shot-test-ui':'단발 음성 즉시 테스트' not in main and 'manual_test' not in main,
 'no-one-shot-picker-ui':'내 단발 음성파일 선택' not in main and '선택 음성 삭제' not in main,
 'no-one-shot-result-callback':'override fun onActivityResult' not in main,
 'no-learned-state':'enum class SteeringTriggerMode' not in pref and 'armLearning' not in pref and 'isLearning' not in pref,
 'no-learning-detector':'isLearning' not in detector and 'saveLearnedKey' not in detector,
 'android-menu-back-fallback':'KeyEvent.KEYCODE_MENU' in detector and 'KeyEvent.KEYCODE_BACK' in detector,
 'byd-menu-previous':'BydSteeringKeyCatalog.MODE' in detector and 'BydSteeringKeyCatalog.PREVIOUS' in detector,
 'no-oem-key-consume':'return false // Never consume' in detector,
 'repeat-down-dedup':'event.repeatCount != 0' in detector and 'if (!pressed.add(edgeId)) return false' in detector,
 'actual-triple-window':'TripleTapWindow(windowMs = 1_200L, minGapMs = 80L)' in detector,
 'existing-toggle-used-by-main-listener':'SteeringTriggerPreferences.enabled(this)' in svc,
 'existing-voice-playback-unchanged':'audio?.playOneShot(SteeringTriggerPreferences.soundFile(this)' in svc,
 'existing-voice-file-kept':'fun soundFile(context: Context)' in pref and 'KEY_SOUND_PATH' in pref,
 'existing-byd-event-pattern':'completePressReleaseTriplet' in bridge and 'INSTRUMENT_2IN1_MENU_STATE' in bridge,
 'shared-key-dedup':'SteeringPlaybackGuard.allow()' in detector and 'SteeringPlaybackGuard.allow()' in svc,
 'unified-log-buttons-untouched':main.count('text = "수집 시작"') == 1 and main.count('text = "수집 종료"')==1,
 'auto-split-and-auto-launch-kept':'SplitProfilesActivity::class.java' in main and 'AutoLaunchSettingsActivity::class.java' in main,
 'dpi-rotation-eq-kept':'AppPolicyActivity::class.java' in main and 'AudioTuningActivity::class.java' in main,
 'permissions-kept':'AppPermissionManagerActivity::class.java' in main,
 'version-name':'0.17.0-steering-toggle-only' in build and 'versionCode = 26' in build,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
print(f'STEERING_MENU_V0170 {sum(checks.values())}/{len(checks)}')
sys.exit(0 if all(checks.values()) else 1)
