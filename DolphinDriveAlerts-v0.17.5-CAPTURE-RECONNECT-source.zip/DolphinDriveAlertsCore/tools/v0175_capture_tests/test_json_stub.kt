package org.json
private val cache=mutableMapOf<String,MutableList<Any?>>()
private var seq=0
class JSONObject {
  private val fields=linkedMapOf<String,Any?>()
  constructor()
  fun put(key:String,value:Any?):JSONObject { fields[key]=value;return this }
  fun getString(key:String)=fields[key] as String
  fun getLong(key:String)=(fields[key] as Number).toLong()
  fun getBoolean(key:String)=fields[key] as Boolean
  fun getJSONArray(key:String)=fields[key] as JSONArray
  fun has(key:String)=fields.containsKey(key)
  fun toString(indent:Int)=toString()
  override fun toString():String=fields.toString()
  companion object { val NULL=Any() }
}
class JSONArray {
  private val values=mutableListOf<Any?>()
  constructor()
  constructor(saved:String){ values.addAll(cache[saved]?:emptyList()) }
  fun put(value:Any?):JSONArray { values+=value;return this }
  fun length()=values.size
  fun opt(index:Int)=values.getOrNull(index)
  fun getJSONObject(index:Int)=values[index] as JSONObject
  override fun toString():String {val id="ARR#${++seq}";cache[id]=values.toMutableList();return id}
}
