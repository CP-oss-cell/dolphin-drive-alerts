package android.content
interface SharedPreferences {
    fun getString(key: String, def: String?): String?
    fun getLong(key: String, def: Long): Long
    fun edit(): Editor
    interface Editor {
        fun putString(key:String, v:String?):Editor
        fun putLong(key:String,v:Long):Editor
        fun clear():Editor
        fun commit():Boolean
    }
}
open class Context {
    companion object { const val MODE_PRIVATE = 0 }
    private val map=mutableMapOf<String,SharedPreferences>()
    open fun getSharedPreferences(name:String, mode:Int):SharedPreferences=map.getOrPut(name){ MemPrefs() }
}
private class MemPrefs:SharedPreferences {
    private val data=mutableMapOf<String,Any?>()
    override fun getString(key:String, def:String?)=data[key] as? String ?: def
    override fun getLong(key:String, def:Long)=data[key] as? Long ?: def
    override fun edit():SharedPreferences.Editor=object:SharedPreferences.Editor {
        private var clear=false
        private val staged=mutableMapOf<String,Any?>()
        override fun putString(key:String,v:String?)=apply{staged[key]=v}
        override fun putLong(key:String,v:Long)=apply{staged[key]=v}
        override fun clear()=apply{clear=true}
        override fun commit():Boolean { if(clear)data.clear(); data.putAll(staged);return true }
    }
}
