package com.byd.dolphin.drivealerts.audio

enum class SoundFocusMode { REFERENCE, SURROUND, CINEMA }
data class EqSettings(
    val enabled: Boolean = false, val globalMix: Boolean = true,
    val bass: Int = 0, val mid: Int = 0, val treble: Int = 0,
    val centerpoint360: Boolean = false, val spatialStrength: Int = 50,
    val soundFocus: SoundFocusMode = SoundFocusMode.REFERENCE
)
