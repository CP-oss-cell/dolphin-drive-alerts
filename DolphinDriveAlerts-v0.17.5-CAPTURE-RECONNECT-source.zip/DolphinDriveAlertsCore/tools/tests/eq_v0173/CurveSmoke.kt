package com.byd.dolphin.drivealerts.audio

import kotlin.math.abs

fun main() {
    val reference = EqSettings(enabled = true)
    val allHz = intArrayOf(31, 63, 125, 230, 250, 500, 910, 1000, 2000, 3600, 4000, 8000, 14000, 16000)
    var assertions = 0
    fun expect(condition: Boolean, description: String) {
        check(condition) { description }
        assertions++
    }
    expect(allHz.all { abs(EqToneCurve.gainDb(reference, it)) < .001f }, "flat reference must be flat")
    val bassOnly = reference.copy(bass = 10, mid = -10, treble = 10)
    expect(EqToneCurve.gainDb(bassOnly, 63) > EqToneCurve.gainDb(bassOnly, 1000), "bass greater than mid")
    expect(EqToneCurve.gainDb(bassOnly, 16000) > EqToneCurve.gainDb(bassOnly, 1000), "treble greater than mid")
    expect(abs(EqToneCurve.gainDb(bassOnly, 249) - EqToneCurve.gainDb(bassOnly, 250)) < 0.2f, "125-500 crossover continuity")
    expect(abs(EqToneCurve.gainDb(bassOnly, 3999) - EqToneCurve.gainDb(bassOnly, 4000)) < 0.2f, "2000-8000 crossover continuity")
    expect(allHz.all { EqToneCurve.gainDb(bassOnly, it) in -6f..6f }, "headroom gain bounds")
    expect(EqToneCurve.headroomDb(bassOnly, allHz) in -6f..0f, "headroom negative or neutral")
    expect(EqToneCurve.headroomDb(reference, intArrayOf()) == 0f, "empty frequencies safe")
    expect(EqToneCurve.virtualizerStrength(reference) == 0.toShort(), "reference has no virtualizer")
    expect(EqToneCurve.virtualizerStrength(reference.copy(centerpoint360 = true, spatialStrength = 50)) == 500.toShort(), "50% spatial")
    expect(EqToneCurve.virtualizerStrength(reference.copy(centerpoint360 = true, spatialStrength = 0)) == 0.toShort(), "0% spatial off")
    expect(EqToneCurve.virtualizerStrength(reference.copy(centerpoint360 = true, spatialStrength = 100)) == 1000.toShort(), "100% spatial")
    expect(EqToneCurve.virtualizerStrength(reference.copy(soundFocus = SoundFocusMode.CINEMA)) == 450.toShort(), "cinema effect on")
    expect(EqToneCurve.virtualizerStrength(reference.copy(soundFocus = SoundFocusMode.SURROUND)) == 350.toShort(), "surround effect on")
    expect(EqToneCurve.gainDb(reference.copy(soundFocus = SoundFocusMode.CINEMA), 63) != EqToneCurve.gainDb(reference, 63), "cinema EQ differs")
    println("PASS KOTLIN_EQ_TONE_AND_SPATIAL $assertions assertions")
}
