from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
source=p/'app/src/main/java/com/byd/dolphin/drivealerts'
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
tap=(source/'log/BydEventTap.kt').read_text()
code=(source/'log/UnifiedLogCapture.kt').read_text()
adb=(source/'dpi/NativeAdbClient.kt').read_text()
build=(p/'app/build.gradle.kts').read_text()
checks={
    'manifest INTERNET grants loopback TCP socket': 'android.permission.INTERNET' in manifest,
    'manifest parses': (ET.fromstring(manifest) is not None),
    'ADB still loopback': '127.0.0.1' in adb,
    'problematic final onDataChanged override eliminated': 'override fun onDataChanged' not in tap,
    'seven domains isolated': all('safeSetup("%s")'%d in tap for d in ('setting','instrument','adas','dipilot','energy','radar','gearbox')),
    'OEM linkage problem reported': 'BYD_EVENT_LISTENER_CLASS_FAILED' in tap,
    'empty tap does not claim active': 'fun hasActiveBindings()' in tap and 'BYD_EVENT_TAP_LAZY_EMPTY' in (source/'service/DrivingAlertService.kt').read_text(),
    'BYD change callback preserved': tap.count('override fun onDataEventChanged') == 7,
    'no BYD setter is introduced': 'setBYD' not in tap,
    'log captures true success and failure': 'diagnosticShellCommandSuccessCount' in code and 'diagnosticShellCommandFailureCount' in code,
    'failure cannot be confused with snapshot completed': 'diagnosticShellUsable' in code,
    'two button workflow preserved': 'UNIFIED_CAPTURE_START' in code and 'UNIFIED_CAPTURE_END' in code,
    'version 0.16.1 code 17': 'versionCode = 17' in build and '0.16.1-realcar-logfix' in build,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()), 'realcar logfix gate failed'
print(f'{len(checks)}/{len(checks)} PASS')
