# v0.17.4 checks preserved. Only the release-version assertions were updated for v0.17.5.
#!/usr/bin/env python3
"""Compile real production Kotlin tracker with kotlinc and replay observed sound IDs."""
from pathlib import Path
import shutil
import subprocess
import tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts/log/InstrumentSoundCandidateTracker.kt'
logger=(root/'app/src/main/java/com/byd/dolphin/drivealerts/log/RawSignalLogger.kt').read_text()
assert 'instrument_sound_candidate' in logger
assert 'externalSpeakerConfirmed", false' in logger
assert 'instrumentSoundTracker.observe(eventType, value, eventAtMs)' in logger
assert 'logger.flush()' in (root/'app/src/main/java/com/byd/dolphin/drivealerts/log/UnifiedLogCapture.kt').read_text()
assert 'versionCode = 31' in (root/'app/build.gradle.kts').read_text()
assert 'versionName = "0.17.5-capture-reconnect"' in (root/'app/build.gradle.kts').read_text()
print('PASS source wiring, readonly/unverified contract, release version')
if not shutil.which('kotlinc') or not shutil.which('kotlin'):
 print('SKIP: Kotlin compiler unavailable; CI Kotlin compile still required')
 raise SystemExit(0)
test='''
package com.byd.dolphin.drivealerts.log
fun main() {
    val t=InstrumentSoundCandidateTracker()
    val f=InstrumentSoundCandidateTracker.FREQ_ID
    val s=InstrumentSoundCandidateTracker.TYPE_ID
    check(t.observe(99,"3",900L)==null)
    check(t.observe(f,"INVAILD_INT=-999999999,intValue=3",1000L)==null)
    check(t.observe(f,"3",1002L)==null) // duplicated native callback
    val start=t.observe(s,"3",1004L)!!
    check(start.phase=="START" && start.frequencyRaw==3 && start.typeRaw==3)
    check(t.observe(s,"intValue=3",1005L)==null)
    val end=t.observe(f,"0",1194L)!!
    check(end.phase=="END" && end.elapsedMs==194L)
    check(t.observe(s,"0",1195L)==null)
    check(t.observe(f,"3",2000L)==null)
    check(t.observe(s,"3",2004L)?.phase=="START")
    check(t.observe(f,"0",2195L)?.phase=="END")
    check(t.observe(s,"0",2196L)==null)
    check(t.observe(f,"3",3000L)==null)
    check(t.observe(s,"3",3002L)?.phase=="START")
    check(t.observe(f,"0",3200L)?.elapsedMs==200L)
    check(t.observe(s,"0",3202L)==null)
    check(t.observe(f,"-999999999",4000L)==null)
    check(t.observe(s,"no intValue",4001L)==null)
    val u=InstrumentSoundCandidateTracker()
    check(u.observe(f,"1",1000L)==null)
    check(u.observe(s,"1",2000L)==null) // stale cannot manufacture a pulse
    println("PASS Kotlin read-only correlation, 3 pulses, duplicate native/reference, malformed/stale values")
}
'''
with tempfile.TemporaryDirectory() as td:
    p=Path(td); (p/'Main.kt').write_text(test)
    subprocess.run(['kotlinc',str(src),str(p/'Main.kt'),'-include-runtime','-d',str(p/'test.jar')],check=True)
    subprocess.run(['java','-jar',str(p/'test.jar')],check=True)
