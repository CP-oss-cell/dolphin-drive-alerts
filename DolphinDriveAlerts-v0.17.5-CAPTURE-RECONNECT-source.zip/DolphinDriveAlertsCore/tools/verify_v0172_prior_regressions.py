from pathlib import Path
import subprocess,tempfile,zipfile,json,collections,os
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/byd/dolphin/drivealerts'
text=lambda p:(j/p).read_text()
checks={
'v0.17.2': 'versionCode = 28' in (r/'app/build.gradle.kts').read_text(),
'eco-is-1': '1 -> AlertEvent.DRIVE_ECO' in text('vehicle/DriveModeDecoder.kt'),
'normal-candidate-is-0': '0 -> AlertEvent.DRIVE_NORMAL' in text('vehicle/DriveModeDecoder.kt'),
'sport-still-2': '2 -> AlertEvent.DRIVE_SPORT' in text('vehicle/DriveModeDecoder.kt'),
'regen-standard-high-preserved': all(x in text('vehicle/ReferenceVehicleEventBridge.kt') for x in ['2 -> emit(AlertEvent.REGEN_STANDARD','3 -> emit(AlertEvent.REGEN_HIGH']),
'button-and-engagement-separated': all(x in text('model/AlertModels.kt') for x in ['AUTOHOLD_ON','AUTOHOLD_OFF','AUTOHOLD_ENGAGED','AUTOHOLD_RELEASED']),
'bsd-requires-blinker': 'pollBsdWithIndicator' in text('vehicle/ReferenceVehicleEventBridge.kt') and 'indicatorRequired=true' in text('vehicle/ReferenceVehicleEventBridge.kt'),
'bsd-no-raw-only-emit': 'emit(AlertEvent.BSD_WARNING,' not in text('vehicle/ReferenceVehicleEventBridge.kt'),
'bsd-poll-follow-up': 'pollBsdWithIndicator' in text('service/DrivingAlertService.kt'),
'bsd-side-voice': 'AlertRequest(AlertEvent.BSD_WARNING, reading.side)' in text('vehicle/ReferenceVehicleEventBridge.kt'),
'door-warning-not-faked': 'emit(AlertEvent.EXIT_REAR_WARNING,' not in text('vehicle/ReferenceVehicleEventBridge.kt'),
'adas-radar-probes-retained': 'targetedSignalProbe?.snapshot()' in text('service/DrivingAlertService.kt'),
'auto-launch-kept': 'VehicleSplitEngine.launch(this,profile)' in text('automation/AutoLaunchSequenceService.kt'),
'background-before-ui': text('automation/AutoLaunchSequenceService.kt').index('MediaPlaybackObserver.playExisting') < text('automation/AutoLaunchSequenceService.kt').index('AppSelection.safeComponent(this,step.packageName)'),
'background-buffering': 'PlaybackState.STATE_BUFFERING' in text('automation/MediaPlaybackObserver.kt'),
'home-restoration-still-there': '"input keyevent 3"' in text('automation/AutoLaunchSequenceService.kt'),
'split-bounds-readback': 'SplitBoundsReadback.primaryPercent' in text('automation/VehicleSplitEngine.kt'),
'split-no-unverified-success': '"비율 불일치' in text('automation/VehicleSplitEngine.kt'),
'split-two-app-confirm': 'firstSeen' in text('automation/VehicleSplitEngine.kt') and 'secondSeen' in text('automation/VehicleSplitEngine.kt'),
'dpi-readback-still': 'val after = readDensity(app)' in text('dpi/DisplaySettingsController.kt'),
'dpi-adb-auth-first': 'AuthorizedAdbRuntime.health(app)' in text('dpi/DisplaySettingsController.kt'),
'no-user-picker-dpi': 'AppPolicyActivity' not in text('dpi/DisplaySettingsController.kt'),
'nav-five-only': 'NavigationApp("MCon K"' in text('dpi/ExternalAppAudioRouter.kt'),
'no-raw-equalizer-boost': 'BassBoost(' not in text('audio/GlobalEqualizerEngine.kt'),
'unsupported-oem-dsp-kept': 'UNSUPPORTED_OEM_DSP' in text('audio/GlobalEqualizerEngine.kt'),
'permission-management-unchanged': (j/'dpi/InstalledAppPermissionManager.kt').exists() or any('Permission' in x.name for x in (j/'dpi').glob('*.kt')),
'rotator-kept': 'RotationPolicy.applyCurrent' in text('ui/AppPolicyActivity.kt'),
'steering-kept': 'STEERING_TRIPLE_TAP_REFERENCE' in text('vehicle/ReferenceVehicleEventBridge.kt'),
'voice-kept': (r/'tools/voice_prompts.json').exists(),
'auto-hold-stable-engagement': '500L' in text('vehicle/AutoHoldEngagementDecoder.kt'),
'auto-hold-engagement-hook': 'pollAutoHoldEngagement' in text('service/DrivingAlertService.kt'),
'unified-log-kept': 'UnifiedLogCapture' in text('service/DrivingAlertService.kt')
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
print('CHECKS',sum(checks.values()),'/',len(checks))
if not all(checks.values()):raise SystemExit(2)
