#!/usr/bin/env python3
"""Regression-oriented EQ checks. Does not assert vehicle DSP or listening verification."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/byd/dolphin/drivealerts'
r=lambda file:(j/file).read_text(encoding='utf-8')
eq=r('audio/GlobalEqualizerEngine.kt');settings=r('audio/EqPreferences.kt');ui=r('ui/AudioTuningActivity.kt');curve=r('audio/EqToneCurve.kt')
checks={
  'version-0172': 'versionCode = 28' in (root/'app/build.gradle.kts').read_text(),
  'master-switch':'if (!s.enabled)' in eq and 'sessions.clear()' in eq,
  'global-mix-preference':'globalMix: Boolean = true' in settings and 'setGlobalMix' in settings,
  'global-is-opt-out':'s.globalMix' in eq and 'sessions.remove(0)?.close()' in eq,
  'specific-session-over-global':'sessions.remove(0)?.close()' in eq and 'sessions.getOrPut(id)' in eq,
  'no-media-launch-dependency':'startActivity(' not in eq,
  'session-lifecycle':'AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION' in eq and 'AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION' in eq,
  'external-intent-no-zero-injection':'id <= 0 || pkg.isBlank()' in eq,
  'session-global-zero':'SessionFx(0, "Global Mix / 호환모드")' in eq,
  'new-dp-10-band':'true, 10, false, 0, false, 0, false' in eq,
  'dp-readback':'getPreEqBandByChannelIndex' in eq and 'READBACK_FAIL' in eq,
  'dp-control-check':'created.hasControl()' in eq,
  'legacy-fallback':'prepareLegacy()' in eq and 'applyClassic(s)' in eq,
  'eq-control-check':'eq.hasControl()' in eq,
  'band-real-gain':'s.bass.coerceIn(-10, 10) * 0.6f' in curve,
  'headroom':'setInputGainAllChannelsTo(headroom)' in eq,
  'gain-range':'coerceIn(-6.0f, 6.0f)' in curve,
  'not-stacking-bass-loud':'BassBoost(' not in eq and 'LoudnessEnhancer(' not in eq,
  'standard-virtualizer':'Virtualizer(priority, sessionId)' in eq,
  'virtualizer-no-control-guard':'v.hasControl()' in eq,
  'virtualizer-onoff-restores':'initialVirtualStrength' in eq and 'initialVirtualEnabled' in eq,
  'eq-restores-baseline':'initialBands?.forEachIndexed' in eq and 'initialDp' in eq,
  'mode-reference': 'SoundFocusMode.REFERENCE' in curve,
  'mode-surround': 'SoundFocusMode.SURROUND' in curve,
  'mode-cinema': 'SoundFocusMode.CINEMA' in curve,
  'no-fake-bose':'UNSUPPORTED_OEM_DSP' in eq and '실제 Bose Centerpoint 360' in ui,
  'user-visible-truth':'미지원 상태' in ui and 'READBACK_FAIL' in eq,
  'ui-global-option':'다른 앱 음악에도 적용' in ui,
  'ui-3-bands':all(x in ui for x in ['저음 (Bass)','중음 (Mid)','고음 (Treble)']),
  'no-driver-speaker-route':'setAudioPolicy' not in eq and 'setLegacyStreamType' not in eq,
  'no-svc': 'speedGain' not in eq and 'onVehicleSpeed' not in eq,
  'own-voice-unaffected-code':'AlertAudioPlayer' not in eq,
  'ADAS-unchanged':'pollBsdWithIndicator' in r('vehicle/ReferenceVehicleEventBridge.kt'),
  'regen-unchanged':'2 -> emit(AlertEvent.REGEN_STANDARD' in r('vehicle/ReferenceVehicleEventBridge.kt'),
  'user-permission-ui':'AppPermissionManagerActivity' in r('ui/MainActivity.kt'),
  'manifest-audio-permission':'android.permission.MODIFY_AUDIO_SETTINGS' in (root/'app/src/main/AndroidManifest.xml').read_text(),
  'manifest-valid':True,
}
try: ET.parse(root/'app/src/main/AndroidManifest.xml')
except Exception: checks['manifest-valid']=False
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
print('EQ-CHECKS',sum(checks.values()),'/',len(checks))
if not all(checks.values()):raise SystemExit(2)
