#!/usr/bin/env python3
"""Read-only instrument sound correlation for historic/new Dolphin Drive log ZIPs.
This tool NEVER calls an AVAS/vehicle output API and never asserts acoustic playback.
"""
import argparse
import collections
import datetime
import json
import pathlib
import re
import zipfile

FREQ='0x26100035'
TYPE='0x26100038'


def decode(value):
    text=str(value or '').strip()
    if re.fullmatch(r'-?\d+',text): return int(text)
    m=re.search(r'(?:^|[,\s])intValue=(-?\d+)(?:[,\s]|$)', text)
    return int(m.group(1)) if m else None


def analyze(path):
    with zipfile.ZipFile(path) as z:
        raw=[json.loads(x) for x in z.read('logs/vehicle_events.jsonl').decode().splitlines() if x.strip()]
        logcats=[n for n in z.namelist() if n.endswith('12_logcat_filtered.txt')]
        snap_paths=[n for n in z.namelist() if n.startswith('diagnostics/') and n.endswith('.txt')]
        cmd_fail=[]; unavailable=[]
        for n in snap_paths:
            lines=z.read(n).decode(errors='replace').splitlines()
            if len(lines)>1 and 'success=false' in lines[1]: cmd_fail.append(n)
            if 'tinymix unavailable' in '\n'.join(lines[:8]): unavailable.append(n)
        sound_logcat=[]
        for n in logcats:
            lines=z.read(n).decode(errors='replace').splitlines()
            sound_logcat += [n+':'+s for s in lines if 'getSoundFreq:' in s or 'getSoundType:' in s]
    # Prefer reference listener when both listeners report identical sound events.
    sound_events=[x for x in raw if x.get('type')=='byd_event' and x.get('eventHex') in (FREQ,TYPE)]
    reference={x['eventHex'] for x in sound_events if x.get('source')=='reference.instrument'}
    selected=[x for x in sound_events if (x.get('source')=='reference.instrument' if x['eventHex'] in reference else x.get('source')=='instrument')]
    frequency=None; kind=None; active=None; pulses=[]
    for x in selected:
        t=x['ts'];v=decode(x.get('value'))
        if v is None or v < 0: continue
        if x['eventHex']==FREQ:frequency=(v,t)
        else: kind=(v,t)
        if active and ((frequency and frequency[0]==0) or (kind and kind[0]==0)):
            pulses.append({'startMs':active[0],'endMs':t,'durationMs':t-active[0],
                           'frequencyRawAtStart':active[1],'soundTypeRawAtStart':active[2]})
            active=None
        if active is None and frequency and kind and frequency[0]>0 and kind[0]>0 and abs(frequency[1]-kind[1])<=400:
            active=(min(frequency[1],kind[1]),frequency[0],kind[0])
    # Snapshot correlation is context only, not proof of sound output.
    snap=[x for x in raw if x.get('type')=='snapshot']
    for p in pulses:
        near=min(snap, key=lambda x:abs(x['ts']-p['startMs'])) if snap else None
        if near:
            p['nearestSnapshotDeltaMs']=near['ts']-p['startMs']
            p['nearestGearRaw']=near.get('gearRaw')
            p['nearestSpeedKmH']=near.get('speedKmH')
        p['startKST']=datetime.datetime.fromtimestamp(p['startMs']/1000,datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec='milliseconds')
    return {
      'sourceZip':pathlib.Path(path).name,'totalVehicleJsonl':len(raw),
      'bydEventCount':sum(x.get('type')=='byd_event' for x in raw),
      'rawInstrumentSoundEvents':len(sound_events),
      'pairedSoundCandidateCount':len(pulses),'pairedSoundCandidates':pulses,
      'androidLogcatGetterSamples':len(sound_logcat),
      'androidShellFailures':cmd_fail,'toolUnavailable':unavailable,
      'stockAvAsUiToggleConfirmed':False,'externalSpeakerPlaybackConfirmed':False,
      'status':'INSTRUMENT_SOUND_PAIR_SEEN__EXTERIOR_SPEAKER_UNVERIFIED',
      'warning':'These instrument callbacks do not prove AVAS/VESS physical speaker audio. No vehicle setter or sound playback is used.'
    }

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('log_zip')
    a.add_argument('--out')
    args=a.parse_args()
    result=analyze(args.log_zip)
    data=json.dumps(result,indent=2,ensure_ascii=False)
    if args.out:pathlib.Path(args.out).write_text(data+'\n',encoding='utf-8')
    else:print(data)
