from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
root=p/'app/src/main/java/com/byd/dolphin/drivealerts'
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
bootstrap=(root/'dpi/PermissionBootstrapper.kt').read_text()
main=(root/'ui/MainActivity.kt').read_text()
fg=(root/'dpi/ForegroundPackageMonitor.kt').read_text()
autostart=(root/'automation/AutoLaunchSequenceService.kt').read_text()
split=(root/'automation/VehicleSplitEngine.kt').read_text()
android='{http://schemas.android.com/apk/res/android}'
xml=ET.fromstring(manifest)
permissions={e.attrib.get(android+'name') for e in xml.findall('uses-permission')}
checks={
 'manifest XML parses': xml is not None,
 'adb loopback internet declared':'android.permission.INTERNET' in permissions,
 'post notifications declared':'android.permission.POST_NOTIFICATIONS' in permissions,
 'secure settings permission declared':'android.permission.WRITE_SECURE_SETTINGS' in permissions,
 'user overlay permission preserved':'android.permission.SYSTEM_ALERT_WINDOW' in permissions and '화면 위 표시 권한 열기' in main,
 'explicit adb bootstrap action':'PermissionBootstrapper.apply(this@MainActivity)' in main,
 'read-only audit without mutation':'PermissionBootstrapper.audit(this@MainActivity)' in main and 'if (!configure) return' in bootstrap,
 'standalone adb audit visible':'ADB 권한 상태 다시 확인' in main,
 'inaccessible accessibility settings button removed':'접근성 서비스 설정 열기' not in main,
 'inaccessible usage settings button removed':'사용기록 접근 권한 열기' not in main,
 'inaccessible battery settings button removed':'배터리 최적화 설정 열기' not in main,
 'accessibility list read before merge':'settings get secure enabled_accessibility_services' in bootstrap,
 'accessibility list preserve and append':'add(a11y)' in bootstrap and 'distinct().joinToString(":")' in bootstrap,
 'accessibility enabled readback':'settings get secure accessibility_enabled' in bootstrap,
 'notification listener allow via adb':'cmd notification allow_listener' in bootstrap,
 'listener list readback':'settings get secure enabled_notification_listeners' in bootstrap,
 'notification listener preserves existing on fallback':'add(notification)' in bootstrap,
 'usage adb appops grant and readback':'appops set $pkg GET_USAGE_STATS allow' in bootstrap and 'appops get $pkg GET_USAGE_STATS' in bootstrap,
 'android 13 notifications runtime adb grant':'POST_NOTIFICATIONS' in bootstrap and 'Build.VERSION.SDK_INT >= 33' in bootstrap,
 'battery adb whitelist':'dumpsys deviceidle whitelist +$pkg' in bootstrap,
 'adb authentication precondition':'waitForAuthorization' in bootstrap and 'if (!auth.success)' in bootstrap,
 'not claiming manufacturer oem permissions':'제조사 서명/privileged 제한' in bootstrap,
 'foreground usage fallback to authenticated adb':'adbForegroundFallback()' in fg and 'dumpsys activity activities' in fg,
 'usage stats long horizon and latest fallback':'queryUsageStats' in fg and 'queryEvents(end - 120_000L' in fg,
 'boot ADB delayed readiness wait':'for (attempt in 0..10)' in autostart and 'if (!adbReady)' in autostart,
 'split alternative state readback':'private fun splitState' in split and 'dumpsys activity activities' in split,
 'no false speaker routing': 'DRIVER_ROUTE_PENDING_VENDOR_HOOK' in (root/'dpi/ExternalAppAudioRouter.kt').read_text(),
 'post notifications listener service still declared':'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE' in manifest,
 'no unsafe vehicle write introduced':'setBYD' not in bootstrap,
 'PC adb script included':(p/'tools/adb_permissions_ko.ps1').exists(),
 'no root in PC script':'adb root' not in (p/'tools/adb_permissions_ko.ps1').read_text(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
print(f'V0162 new checks: {sum(checks.values())}/{len(checks)}')
assert all(checks.values())
