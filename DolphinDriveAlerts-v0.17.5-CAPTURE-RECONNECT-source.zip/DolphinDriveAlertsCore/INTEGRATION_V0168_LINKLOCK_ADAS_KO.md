# Dolphin Drive Alerts v0.16.8 — LinkLock ADAS 경고 실차 증거 연결

## 목적 / 범위
사용자가 실차 정상 작동을 확인한 LinkLock Relay 805 및 EVSound 10013을 재대조했다. 외부 앱 설치나 호출 메뉴를 추가하지 않는다. 기반은 v0.16.7의 모든 기능이며 차량 제어 write는 추가하지 않는다.

## A. 후측방경고: **원본 코드·실차 이벤트 의미 교차확인 / 실제 음성 경로 연결**

- 원본 `linklock-relay-805.apk`, `SnifferService.onVehicleEvent` → `handleBsd(int)` → `bsdDetected` 및 `beep()` 경로를 DEX invoke/field/opcode에서 확인했다.
- `handleBsd(int)`는 `raw==2`인 경우 `bsdDetected=true`, 그 외는 `false`로 처리하며 직전 값과 같으면 갱신하지 않는다. 앱 자체 `alert_enabled`, `turn_only`, auto/turn 상태에 따른 부가 경보음 게이트도 존재한다.
- 사용자가 제공한 `DolphinDriveLogs_20261008_195909_444_8f775ba4.zip`의 `logs/vehicle_events.jsonl`에서는 `ADAS_BSD_STATE`(이벤트 ID `1098907656`, `0x41800008`, `source=adas`)를 28회 확인, 값 `1/2` 변화를 확인했다.
- v0.16.7에서는 같은 ID를 과거 `BSD_ASSIST`라는 이름으로 기록만 하고 음성은 내지 않았다. v0.16.8은 `ReferenceVehicleEventBridge`의 **ADAS 콜백**에서 이 값으로 `LinkLockBsdDecoder`를 실행하고 값 2에 진입한 때에만 `BSD_WARNING`을 제출한다. `AlertGate`가 이벤트 쿨다운을 적용한다. 좌/우는 판별하지 못하는 경우 **방향 없는 후측방 경고**만 출력한다.
- 주의: LinkLock과 완전히 동일한 `turn_only`·경고 ON/OFF·경보음 환경 설정은 복제하지 않았다. 현재 Dolphin의 일반 음성 알림 설정과 gate를 사용한다.

## B. DiPilot 수신 경로 복구: 소스 확인 / 실차 재검증 전

- LinkLock 원본 `SnifferService.fcsrProbe` 문자열의 정확한 SDK 클래스는 `android.hardware.bydauto.dipilot.BYDAutoDipilotDevice`이다. 기존 Dolphin의 `BYDAutoDiPilotDevice`와 **대소문자가 다르다**.
- `ReferenceVehicleEventBridge` 정상 주행 서비스 구독에 `AbsBYDAutoDiPilotListener` 콜백을 등록한다. 원본 클래스명을 우선 사용하고 다른 SDK 이름은 호환 fallback으로만 시도한다.
- `onFrontCarStartStateChange`, `onDriveDepartureStateChanged`, `onDrivieDepartureStateChanged`, `onOpenDoorAlertStateChanged`, `onBlindMonitorStateChanged(1/2)`를 수신할 때 **값을 원시 이벤트 로그로 기록**한다. 이 콜백의 raw 0/1/2가 단순 설정 변경인지 실제 위험/출발 이벤트인지 아직 분류되지 않아 자동 발화시키지 않는다.
- 별도 통합 로그 진단의 DiPilot 클래스명도 LinkLock 확인 이름으로 수정했다. 사용자 19:59 로그에서 DiPilot `ClassNotFoundException`이 있었으므로 그 문제의 직접적인 코드 수정 후보이다. DiLink/펌웨어별 클래스 존재 여부는 실차 미확인.

## C. 차선이탈·앞차출발: 아직 **경고 발생 조건 확인 전**

- LinkLock `SnifferService.handleLaneEvent`는 `LEFT_TRACK`, `RIGHT_TRACK`, `TJA_ICA`, `accActive`, 방향지시등·정차 필터를 사용해 `중앙유지 해제/복구` 음향을 처리한다. 이를 실제 차선 **이탈** 경보와 같다고 판단할 근거는 없다. `d5LaneObserve`는 DiLink5의 다른 상태/콜백 탐색용이다.
- LinkLock `SnifferService.fcsrProbe`는 앞차 출발·신호등 관련 SDK 메서드를 탐색하는 프로브다. `FrontAlertTracker.onTick`에서는 전방 객체의 bounding box/검출 정보로 앞차 출발을 추정하는 별도 경로가 관측된다. 해당 차량 카메라·추적 엔진은 Dolphin Drive에 이식되지 않았다.
- EVSound 10013은 `front_car_start.wav` 음원이 존재하고 `DiPilotManagerImpl.onAINavigationStateChanged` ACC/ICC 경로가 확인되지만 **'앞차가 출발한 순간'의 실제 raw 값→자동 재생 콜백**까지 검증된 것은 아니다.
- 따라서 차선이탈/앞차출발/정차 시 후방접근(DOW)은 원시 신호 구독·로그 복구 단계로만 처리하고, 위험 경보의 거짓 발화를 막기 위해 아직 `LANE_DEPARTURE`, `LEAD_CAR_DEPARTURE`, `EXIT_REAR_WARNING`을 자동 emit하지 않는다.

## 소스 변경
- `vehicle/ReferenceVehicleEventBridge.kt`: BSD 이벤트 직접 음성 연결, DiPilot callback 등록/로그/호환 로딩.
- `vehicle/LinkLockBsdDecoder.kt`: BSD 원본 상태 전이 및 중복 억제, 스레드 안전 처리.
- `log/BydEventTap.kt`: DiPilot 클래스 대소문자 수정.
- `app/build.gradle.kts`: versionCode 24, versionName `0.16.8-linklock-bsd-signal-bridge`.
- `tools/verify_v0168_linklock_bsd.py`: 기존 회귀 검수 59 + 신규 검수 16, 총 75개.

## 검증·상태
- 원본 ZIP 및 APK DEX 인벤토리, 실제 사용자 실차 JSONL 교차대조 완료.
- Kotlin 타입 스텁 컴파일 및 가상 ADAS·DiPilot 리스너 호출 재현 통과: BSD 활성 상태의 중복 억제, 실제 게이트, DiPilot 콜백 원시기록 확인.
- 정적 75/75 PASS. ZIP/YML 무결성 확인 필요.
- **GitHub Android 전체 APK 빌드/새 버전 실차 경고음 청취는 미확인.**
- 기존 DA-007(후측방 위험), DA-008(앞차/차선), DA-002(실차 신호), DA-013(빌드), DA-029(메뉴) 등 기존 이슈에만 연결; 신규 중복 이슈 발행하지 않음.
