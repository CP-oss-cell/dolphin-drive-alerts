# Screen Orientation Control 7.10.1 + BYD_equalizerv4.2 정밀 분석 보고서

분석 기준: 사용자가 업로드한 원본 XAPK/APK 바이트를 직접 해제하고 AndroidManifest.xml, DEX, native library, resources, Room schema, 주요 메서드 바이트코드를 대조함. 파일명/기능명만으로 추정한 내용은 포함하지 않음.

## 원본 무결성

### Screen Orientation Control
- 입력: `Screen+Orientation+Control_7.10.1_APKPure.xapk`
- SHA-256: `e19ded48b425a9aff47f8f72e65f398e353bea927b95681e4a0b2484e7a5bcc9`
- XAPK 내부 base package: `net.mm2d.android.orientationfaker.apk`
- 실제 package: `net.mm2d.android.orientationfaker`
- versionCode: `71001`
- versionName: `7.10.1`
- minSdk: 28 / targetSdk: 37 / compileSdk: 37

### BYD Equalizer
- 입력: `BYD_equalizerv4.2.apk`
- SHA-256: `507f384d5fd43ae2b90d3c1f64d4faf5a82428c4c58302b978d59810fca0de28`
- 실제 package: `com.jazibkhan.equalizer`
- 실제 versionCode: `83`
- 실제 versionName: `4.2.6`
- minSdk: 21 / targetSdk: 32 / compileSdk: 32

---

# 1. Screen Orientation Control 7.10.1

## 1.1 핵심 결론

`OBSERVED`: 이 앱은 ADB, root, `WRITE_SETTINGS`, `WRITE_SECURE_SETTINGS`로 화면 방향을 바꾸는 앱이 아니다.

실제 핵심은 **0×0 크기의 `TYPE_APPLICATION_OVERLAY` Window를 띄운 뒤, 그 Window의 `WindowManager.LayoutParams.screenOrientation` 값을 변경하여 디스플레이 방향을 강제하는 방식**이다.

즉 재사용 핵심은 다음 한 줄로 요약된다.

`SYSTEM_ALERT_WINDOW -> 0×0 overlay -> LayoutParams.screenOrientation 변경 -> addView/updateViewLayout`

이 구조는 Dolphin Drive Alerts에 별도 ADB 회전 명령 없이 이식할 가치가 매우 높다.

## 1.2 XAPK 구조

base APK 외에 언어 split과 ABI/density split으로 구성되어 있다. ABI split에서 발견된 `.so`는 AndroidX graphics/datastore 계열이며, 별도의 네이티브 회전 엔진은 확인되지 않았다. 따라서 회전 기능은 Java/Kotlin/Android framework 층에서 구현되어 있다.

## 1.3 핵심 권한

실제 Manifest에서 확인한 핵심 권한:
- `android.permission.SYSTEM_ALERT_WINDOW`
- `android.permission.PACKAGE_USAGE_STATS`
- `android.permission.RECEIVE_BOOT_COMPLETED`
- `android.permission.FOREGROUND_SERVICE`
- `android.permission.FOREGROUND_SERVICE_SPECIAL_USE`
- `android.permission.POST_NOTIFICATIONS`
- `android.permission.WAKE_LOCK`

`OBSERVED`: `WRITE_SETTINGS`, `WRITE_SECURE_SETTINGS`는 없다.

## 1.4 핵심 서비스/리시버

- `net.mm2d.orientation.service.MainService`
  - exported=false
  - foreground service special-use subtype = `control device orientation`
- `net.mm2d.orientation.service.WakeUpReceiver`
  - BOOT_COMPLETED
  - LOCKED_BOOT_COMPLETED
  - MY_PACKAGE_REPLACED
  - USER_PRESENT
- `net.mm2d.orientation.control.OrientationReceiver`
  - action: `net.mm2d.android.orientationfaker.ACTION_ORIENTATION`
  - exported=false
  - 자체 signature permission으로 보호

따라서 다른 앱이 이 Receiver를 일반 broadcast API처럼 호출해 쓰는 구조는 아니다. Dolphin Drive Alerts에서는 같은 아이디어를 자체 구현해야 한다.

## 1.5 실제 회전 엔진

주요 obfuscated controller: `Lni3;`

생성 시:
- `DisplayManager` 획득
- display 0 획득
- display context 생성
- API 30+에서는 window context 생성
- window type = `2038` = `TYPE_APPLICATION_OVERLAY`
- plain `View` 생성
- `WindowManager.LayoutParams` 생성

확인된 LayoutParams:
- width = 0
- height = 0
- x = 0
- y = 0
- type = 2038 (`TYPE_APPLICATION_OVERLAY`)
- flags = 568 (`0x238`)
- format = -3 (`PixelFormat.TRANSLUCENT`)
- 초기 `screenOrientation = -1`

표준 flag 비트로 해석하면 `0x238`은 다음 조합이다.
- NOT_FOCUSABLE
- NOT_TOUCHABLE
- NOT_TOUCH_MODAL
- LAYOUT_NO_LIMITS

즉 화면을 가리는 overlay가 아니라 **보이지도 않고 터치도 받지 않는 0×0 제어용 overlay**다.

방향 변경 시 실제 동작:
- 새 orientation과 현재 `LayoutParams.screenOrientation` 비교
- 값 갱신
- View가 이미 붙어 있으면 `WindowManager.updateViewLayout()`
- 아니면 `WindowManager.addView()`
- unspecified가 되면 overlay 제거
- 예외 발생 시 orientation을 -1로 복구

종료/정리 시:
- `screenOrientation=-1`
- `removeViewImmediate()`
- sensor listener unregister

## 1.6 지원 방향

실제 enum에는 다음 상태가 존재한다.

`INVALID`, `PORTRAIT`, `LANDSCAPE`, `REVERSE_PORTRAIT`, `REVERSE_LANDSCAPE`, `UNSPECIFIED`, `FULL_SENSOR`, `SENSOR_PORTRAIT`, `SENSOR_LANDSCAPE`, `SENSOR_LIE_RIGHT`, `SENSOR_LIE_LEFT`, `SENSOR_HEADSTAND`, `SENSOR_FULL`, `SENSOR_FORWARD`, `SENSOR_REVERSE`.

확인된 Android orientation 계열 값에는 portrait=1, reverse-landscape=8, reverse-portrait=9, full-sensor=10, unspecified=-1 등이 포함된다. 100번대 값들은 앱 내부 sensor mode 값이며 Android public `screenOrientation` 값을 그대로 의미한다고 보면 안 된다.

## 1.7 센서 기반 방향 제어

실제 sensor helper는 `SensorManager`의 default sensor type 1, 즉 **accelerometer**를 사용한다. SCREEN_ON/OFF도 동적으로 감시한다. Sensor listener는 x/y/z를 읽고 앱 자체 방향 판정 로직으로 전달한 뒤 최종적으로 overlay controller를 갱신한다.

즉 “센서 회전” 역시 별도 native 엔진이 아니라 accelerometer + overlay 방식이다.

## 1.8 앱별 방향 지정

이 앱의 앱별 회전 기능도 실제로 확인됐다.

`UsageStatsManager.queryEvents(start,end)`를 사용하고 `UsageEvents.Event` type 1을 추적하여 최근 foreground package를 찾는다. package `android`는 제외한다.

실제 polling 주기는 약 **1초**다. 5분 및 1시간 범위 fallback 시간값도 존재한다.

Room DB schema:

```sql
CREATE TABLE IF NOT EXISTS package_settings (
  package_name TEXT NOT NULL,
  orientation INTEGER NOT NULL,
  PRIMARY KEY(package_name)
)
```

저장은 `INSERT OR REPLACE` 방식이다.

실제 구조는:

`foreground package 감지 -> package별 orientation lookup -> overlay screenOrientation 갱신`

이다.

중요한 해석: 이것은 “앱마다 독립된 가상 디스플레이 방향”을 만드는 것이 아니다. **어떤 앱이 foreground냐에 따라 실제 디스플레이 방향을 자동으로 바꿔주는 정책 엔진**이다.

따라서 Dolphin Drive Alerts에서 “세로 고정 앱을 차의 현재 가로 화면에 맞춰 강제로 가로 실행”하는 요구에는 매우 적합하다. 반대로 런처 중앙 pane 하나만 독립적으로 돌리고 좌우 UI는 방향을 유지하는 완전한 per-display rotation이 필요하다면 이 기술 하나만으로는 부족하다.

## 1.9 시스템 자동회전과 관계

DEX에서 `Settings.System["accelerometer_rotation"]` 읽기/감시가 확인됐다. 리소스 문구에도 reverse 계열 동작을 위해 시스템 자동 회전 상태가 영향을 줄 수 있다는 안내가 있다.

하지만 이 앱 자체에서 `Settings.System.put*` 또는 Secure Settings를 쓰는 근거와 권한은 확인되지 않았다.

## 1.10 불필요한 부분

Google Mobile Ads, Firebase Performance/Analytics/Crashlytics/Sessions/RemoteConfig/Installations, AD_ID 등이 포함돼 있다. 이것들은 회전 기능과 무관하다. Drive Alerts에는 가져올 이유가 없다.

## 1.11 Drive Alerts 이식안

가장 좋은 방식은 `OrientationOverlayController`를 새로 만들어 아래만 가져오는 것이다.

- `SYSTEM_ALERT_WINDOW`
- 0×0 `TYPE_APPLICATION_OVERLAY`
- `LayoutParams.screenOrientation`
- add/update/remove lifecycle
- 앱별 package -> orientation 저장
- foreground package 감지
- 필요 시 accelerometer mode

현재 Drive Alerts의 `wm density`/ADB 방식과는 별개 기능으로 두되, 화면 방향 기능은 **ADB shell rotation보다 이 구조가 우선**이다.

BYD에서 overlay 설정 화면이 막혀 있을 경우 Drive Alerts의 기존 local ADB bootstrap으로 app-op을 보조할 수는 있으나, 이 부분은 별도 구현/readback 전까지 `INFERENCE`다.

---

# 2. BYD_equalizerv4.2.apk

## 2.1 핵심 결론

`OBSERVED`: 이 APK의 실제 EQ 엔진은 BYD 비공개 DSP API가 아니라 **Android 표준 `android.media.audiofx` 계열**이다.

확인된 효과:
- `Equalizer`
- `BassBoost`
- `LoudnessEnhancer`
- `PresetReverb`
- `Virtualizer`
- API 28+ `DynamicsProcessing`

즉 BYD에서 이 앱이 효과가 먹는 이유는 “BYD 전용 숨은 EQ API를 사용해서”가 아니라 **BYD의 Android audio stack이 표준 AudioEffect/session processing을 받아주기 때문**으로 보는 것이 가장 근거에 맞다.

## 2.2 Manifest와 세션 연결 구조

핵심 권한:
- `android.permission.MODIFY_AUDIO_SETTINGS`
- `android.permission.FOREGROUND_SERVICE`
- `android.permission.RECEIVE_BOOT_COMPLETED`
- `android.permission.WAKE_LOCK`

핵심 component:
- `SessionChangeService` (JobService)
- `BootCompleteReceiver`
- `SessionReceiver`
- `ForegroundService`
- `MainActivity`

`SessionReceiver`는 다음 표준 Android broadcast를 실제로 받는다.
- `android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION`
- `android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION`

MainActivity는:
- `android.media.action.DISPLAY_AUDIO_EFFECT_CONTROL_PANEL`
를 처리한다.

## 2.3 Audio session 처리

`SessionReceiver`는:
- `android.media.extra.AUDIO_SESSION`
- `android.media.extra.PACKAGE_NAME`
을 읽는다.

package가 없으면 문자열 **`Global Mix`**를 사용한다.

ForegroundService의 `start_with_audio_session` 액션은:
- `session_id`
- `package_name`
을 받아 현재 효과 엔진에 적용한다.

SharedPreferences 기본값:
- `session_id = 0`
- `package_name = "Global Mix"`
- `always_global = false`
- `is_legacy_mode = false`

`always_global`을 켜는 실제 코드에서는:
- package = `Global Mix`
- session_id = **0**
으로 저장하고 ForegroundService를 session 0으로 다시 시작한다.

따라서 **이 APK에서 Global Mix는 실제 audio session 0**이라는 것이 코드로 확인됐다.

## 2.4 현대식 엔진: DynamicsProcessing

API 28+이고 legacy mode가 꺼져 있을 때 `DynamicsProcessing`을 사용한다.

확인된 설정:
- `DynamicsProcessing.Config`
- preferred frame duration = **10 ms**
- priority = `Integer.MAX_VALUE`
- 현재 audio session ID에 attach
- post-EQ 사용
- pre-EQ 사용
- limiter 사용

EQ gain은 내부적으로 integer millibel 값으로 저장되고, DynamicsProcessing에 적용할 때 `/100`하여 dB float로 변환한다.

BassBoost는 이 모드에서 classic `BassBoost` 객체가 아니라 **pre-EQ band gain** 형태로 구현된다.

Loudness는 `DynamicsProcessing.Limiter.setPostGain()` 계열로 구현된다.

## 2.5 Legacy/classic 엔진

API <28 또는 사용자가 legacy mode를 켠 경우 다음 Android AudioEffect 객체를 현재 session ID로 직접 만든다.

- `new Equalizer(Integer.MAX_VALUE, sessionId)`
- `new BassBoost(Integer.MAX_VALUE, sessionId)`
- `new PresetReverb(Integer.MAX_VALUE, sessionId)`
- `new Virtualizer(Integer.MAX_VALUE, sessionId)`
- `new LoudnessEnhancer(sessionId)`

실제 setter도 확인됨:
- `Equalizer.setBandLevel()`
- `BassBoost.setStrength()`
- `LoudnessEnhancer.setTargetGain()`
- `PresetReverb.setPreset()`
- `Virtualizer.setStrength()`

에러가 나면 효과를 disable/release하고 Crashlytics에 기록하는 방어 코드도 있다.

## 2.6 EQ 밴드

기본/legacy 계열 5-band 중심 주파수:
- 60 Hz
- 230 Hz
- 910 Hz
- 3.6 kHz
- 14 kHz

API 28+ DynamicsProcessing 10-band 중심 주파수:
- 31.25 Hz
- 62.5 Hz
- 125 Hz
- 250 Hz
- 500 Hz
- 1 kHz
- 2 kHz
- 4 kHz
- 8 kHz
- 16 kHz

코드상 10-band 사용 조건은 API 28+ 및 non-legacy mode다. 그 외에는 5-band로 내려간다.

## 2.7 프리셋

내장 프리셋 이름이 실제 DEX에서 확인됐다.

Normal, Classical, Dance, Flat, Folk, Heavy Metal, Hip Hop, Jazz, Pop, Rock, Acoustic, Vocal Boost, Bass Boost, Treble Boost, Deep House, EDM, R&B, Dream, Custom.

각 프리셋은 5/10-band 모드별 millibel 배열로 저장된다.

## 2.8 다른 앱 음악에도 효과가 걸리는 이유

이 앱은 두 경로를 갖는다.

1. 플레이어가 audio effect session broadcast를 정상적으로 열어주면 그 **개별 session ID**에 효과를 attach한다.
2. 그런 session을 얻기 어려운 앱이면 **Global Mix = session 0**에 attach하는 fallback을 제공한다.

따라서 “다른 앱 음성/음악에 EQ가 적용되는 것”과 “그 앱의 소리를 운전석 스피커로 라우팅하는 것”은 완전히 다른 문제다.

EQ는 audio session/mix에 DSP 효과를 넣는 기능이다. 물리 출력 zone/stream14를 고르는 기능은 아니다.

## 2.9 오디오 장치/라우트 감지

Room DB에 다음 구조가 실제 존재한다.

```sql
audio_devices(
  name TEXT NOT NULL,
  type INTEGER NOT NULL,
  id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL
)

auto_apply_config(
  audio_device_id INTEGER NOT NULL,
  custom_preset_id TEXT NOT NULL,
  PRIMARY KEY(audio_device_id)
)
```

seed device:
- Speaker
- Headphones

ForegroundService는 `MediaRouter` callback과 `AudioManager.getDevices()`를 사용하며 speaker, wired headset/headphones, Bluetooth A2DP/SCO, USB, HDMI, BUS, BLE speaker/headset 등 여러 output route를 구분한다.

즉 장치 변경 시 preset을 재적용하기 위한 구조가 들어 있다.

## 2.10 이 APK 자체의 위험한/불필요한 부분

`OBSERVED`: 이 정확한 `BYD_equalizerv4.2.apk`는 순정 upstream 바이너리 그대로가 아니다.

Application class가:
`bin.mt.apksignaturekillerplus.HookApplication`
으로 바뀌어 있다.

이 클래스는 reflection/proxy로 `ActivityThread.sPackageManager`와 Context의 PackageManager proxy를 바꾸고, 자기 package의 `getPackageInfo(... GET_SIGNATURES ...)` 호출 시 `PackageInfo.signatures`를 내장 certificate로 교체한다.

로그 문자열:
- `PmsHook success.`
- `PmsHook failed.`

즉 **APK Signature Killer Plus 계열 signature-spoof/self-check bypass layer가 추가된 repacked binary**다.

실제 APK 서명과 코드가 반환하도록 강제하는 내장 certificate가 서로 다르다. 이 레이어는 EQ 기능과 무관하므로 Drive Alerts에는 절대 가져올 필요가 없다.

`libstub.so`도 존재하지만 문자열/심볼에서 BYD DSP/EQ/routing 기능은 확인되지 않았다. audio engine의 핵심은 Java/Kotlin AudioEffect 쪽이다.

## 2.11 Drive Alerts 이식안

깨끗하게 다시 구현하면 된다.

- `MODIFY_AUDIO_SETTINGS`
- foreground service
- `OPEN_AUDIO_EFFECT_CONTROL_SESSION` / `CLOSE_AUDIO_EFFECT_CONTROL_SESSION` receiver
- session 0 Global Mix fallback
- API 28+ `DynamicsProcessing` 10-band
- legacy `Equalizer` 5-band fallback
- BassBoost / Loudness / Virtualizer / Reverb 옵션
- preset 저장/복원
- boot restore
- audio route 변경 시 preset 재적용

가져오지 말아야 할 것:
- Signature Killer hook
- ads
- Firebase/Crashlytics 의존성
- billing
- repack용 native stub

---

# 3. Dolphin Drive Alerts 관점 최종 판정

## 화면 회전

`SOURCE_FOUND / HIGH CONFIDENCE`

현재 Drive Alerts에서 회전 기능을 ADB/system setting 중심으로 잡을 이유가 거의 없다. 이 APK의 0×0 overlay + `screenOrientation` 방식이 훨씬 직접적이다.

추천 구현:
`OrientationOverlayController + package rule store + foreground monitor`

사용자의 요구인 “세로 고정 앱을 차량의 현재 가로 방향에 맞춰 강제로 표시”에 직접 대응 가능성이 높다. 단, 별도 embedded display/pane만 독립 회전시키는 것은 추가 기술이 필요하다.

## 이퀄라이저

`SOURCE_FOUND / HIGH CONFIDENCE`

BYD 전용 API가 아니라 표준 Android AudioEffect 계열로 재현 가능하다. 특히 BYD 실차에서 이 계열 앱이 정상 작동했다는 사용자 보고와 이번 코드 구조가 서로 잘 맞는다.

추천 구현:
`Global Mix(session 0) + DynamicsProcessing 10-band + legacy 5-band fallback`

## 지정앱 운전석 스피커 출력과의 관계

`SEPARATE PROBLEM`

EQ 분석으로 cross-UID driver-only routing이 해결된 것은 아니다. EQ는 효과 처리이고, 지정앱 운전석 출력은 AudioPolicy/UID affinity/BYD output route 문제다. 두 기능을 코드와 상태에서 분리해야 한다.

---

# 4. 아직 UNKNOWN인 부분

- 이 정확한 Orientation 7.10.1 바이너리가 한국형 Dolphin에서 동일하게 동작하는지: 실차 재검증 필요.
- 이 정확한 Equalizer 4.2.6 repack이 사용자가 과거 테스트한 6.3.5.8과 완전히 같은 내부 engine인지: 별도 바이너리이므로 자동 동일시 금지.
- BYD에서 session 0 Global Mix가 모든 source/stream에 동일하게 적용되는 범위: 실차 청감/로그 필요.
- launcher 중앙 embedded display만 독립 방향 강제 가능 여부: Orientation Control 방식만으로는 입증되지 않음.

