# Dolphin Drive Alerts 0.13 통합 후보 — 분할/시동 순차 실행

## 판정 및 기준
- 기준: 라이브러리 v0.12 (versionCode 12), 기존 DA-016 / DA-027 / DA-026의 AutoStart v2.4.4·AutoSplit v1.2.0 정적 분석 자료.
- 신규 후보: `versionCode 13`, `0.13.0-split-sequence-integration-candidate`.
- 신규 파일: FeatureProfiles, AppSelection, VehicleSplitEngine, SplitProfilesActivity, SplitRecoveryService, AutoLaunchSettingsActivity, AutoLaunchSequenceService, MediaPlaybackObserver (8 Kotlin 파일).
- 기존 앱의 proprietary code·DEX·키·토큰을 통째로 복사하지 않고 참조 기능을 독립적으로 구현. 순정 360 카메라 점유/차량 write는 하지 않음.

## DA-027 (화면 2분할) 구현 후보
1. 실행가능한 설치 앱 목록에서 앱1/앱2를 선택, 프로필에 사용자 이름·10~90% 비율을 1% 단위로 저장.
2. 다수 프로필 편집/삭제/실행. Launcher ShortcutManager의 dynamic+pin shortcut, 지원 런처에서 사용. **'앱 서랍에 독립 아이콘'은 런처 구현에 따라 지원되지 않을 수 있어 실차 검증 대상**.
3. 로컬 127.0.0.1:5555 ADB, `am start --windowingMode 3/4`, `am stack list` 및 `am stack resize-docked-stack`을 통한 분할/비율 요청. 성공 응답+스택 조회가 있어도 실제 비율 픽셀 동일성은 실차 추가 검증 필요.
4. 최근 사용 프로필을 기록. 360 카메라/다른 앱 전체화면으로 전환 중에는 분할을 건드리지 않고 분할 대상 앱이 다시 foreground가 되면 저장 비율을 재적용. 비율 명령 실패 시 프로필 재실행 1회 재시도(총 최대 3회) 로깅. UI에 '비율 다시 적용' 버튼 추가.
5. 검증된 기존 AutoSplit 앱이 설치돼 있으면 기존 앱 직접 실행 버튼 제공(임시 호환 경로).
6. 정식 OEM DiLink 2/3/4 screen embedding, 3/4분할, 카메라 전체화면 중 미검증 사용이나 차량의 reverse-inhibit hook은 **구현하지 않음**. 카메라 foreground 중 자동 앱 실행을 우선 차단하되 안전성과 차종/펌웨어 호환성은 실차 검증 필요.

## DA-016 (시동 앱 자동실행) 구현 후보
1. 기존 DrivingAlertService의 기본 시동 감시와 분리된 별도 **시동 앱 시퀀스 ON/OFF**. 여러 앱 등록, 순서 이동, 각 앱의 실행 전 지연(0~600초)·미디어 플레이 지연(0~600초), 활성화/삭제/수동 실행/취소.
2. 등록 목록에 저장된 분할 프로필도 선택 가능: 시동 시 저장 분할 실행 및 복원 감시 시작.
3. `BOOT_COMPLETED`, QuickBoot, `ACC_ON`, `IGN_ON` 트리거에 대해 armed/cooldown(120s)으로 중복 실행 방지; `ACC_OFF`/전원차단에서는 시퀀스 취소/재무장. 부팅 알림 및 ACC listener 사용 시 Android/BYD OEM broadcast 수신 여부 실차 확인 필요.
4. foreground worker+600초 wake lock 상한+취소 가능한 1초 대기; 각 앱은 검증된 PM ComponentName만 로컬 ADB `am start -n`으로 실행. 키보드 또는 임의 shell 문자열 입력을 받지 않음.
5. 미디어 앱은 대상 패키지의 active MediaSession만 선택하여 `transportControls.play()` 발행 (알림 접근 권한 필요). 설정 화면에 Notification Listener 권한으로 이동하는 버튼 추가. 미디어 앱이 세션을 발행하지 않으면 재생 성공으로 처리하지 않음.
6. '백그라운드'는 지정한 앱 실행 후 홈 화면 복귀 시도; **대상 앱이 onPause에 재생을 중단하거나 head-unit가 백그라운드 작업을 막으면 강제 지속을 보장할 수 없음.** 미디어 session 실제 PLAYING readback/차량 물리 청감 필요.
7. 카메라/360 화면이 전면에 있는 동안 앱 실행을 건너뛰어 순정 카메라 강제 덮어쓰기 방지. 충전/전원 및 차량 운행 상태 감지 전체는 미완성.

## 실차 검증 테스트 ID
| Test ID | 테스트 | 통과 기준 |
|---|---|---|
| SPL-01 | 앱2개 지정 후 분할 | 두 앱이 실제 서로 다른 pane에 동시에 표시 |
| SPL-02 | 저장 이름/프로필 재실행 | 여러 저장 프로필이 정확히 각각 실행 |
| SPL-03 | 비율 20/80, 35/65, 50/50, 70/30, 80/20 | 실제 화면 경계와 저장값 일치, 강제 재설정 없음 |
| SPL-04 | 빠른 아이콘 | 아이콘 사용자 이름, 앱 서랍·런처 동작 확인; 미지원 시 제한 표시 |
| SPL-05 | 360 카메라 전체화면 후 복귀 | 순정 카메라 방해 없이 같은 프로필/비율 복원 |
| SPL-06 | 다른 앱 전체화면 후 복귀 | 사용자가 저장한 비율 변경/초기화 없음 |
| SPL-07 | 가로/세로 전환, 재부팅 | 분할 정책 적용/실패 로그, 원복 및 재시도 확인 |
| SPL-08 | ADB 끊김·앱 미설치 | 다른 작업 스택에 무리한 resize 없음, 명확한 오류 |
| AUT-01 | 시동 ON 첫 번째 앱 | 정확한 시작 트리거에서 지정 딜레이 후 단발 실행 |
| AUT-02 | 앱 3개 이상 | 각 앱 실행 순서/초 단위 지연 정확 |
| AUT-03 | 미디어 앱 | 실행 지연과 PLAY 지연 분리, 대상 세션 PLAYING/청감 |
| AUT-04 | 백그라운드 미디어 | 홈 복귀 후 대상 앱 음악 끊김 없음 (앱 지원 시) |
| AUT-05 | 시동 중복 방송 | BOOT/IGN/ACC 등에서 한 사이클당 1번만 실행 |
| AUT-06 | 시동 OFF/다음 ON | 실행 시퀀스 취소·재무장·다음 시동 재실행 |
| AUT-07 | 저장 분할 프로필 자동시작 | 등록된 분할 프로필 실행·비율·카메라 복원 |
| AUT-08 | 앱 삭제/ADB 미승인/알림접근 거부 | 실패 표시·다음 단계 안전 지속, 허위 재생 성공 금지 |
| AUT-09 | 360 카메라 호출과 경합 | 전체화면 순정 360을 강제로 가리지 않음 |
| AUT-10 | Android force-stop/배터리 절전 | 제한 명시, 재설정/사용자 승인 필요한 경우 정확 안내 |

## 현재 제한 및 게이트
- `CODE_CANDIDATE`: yes — 소스에 실제 Kotlin 컴포넌트를 새로 작성함.
- `STATIC_SOURCE_GATE`: 145/145 통과; **문자열/구조 게이트이지 APK 컴파일이나 기능 성공 아님**.
- `ANDROID_GRADLE_BUILD`: 이 환경에서 SDK/platforms/android-34와 AGP 도구가 없어 미실행.
- `GITHUB_ACTIONS_BUILD`: 미실행. `.github/workflows/build-v013-from-source-zip.yml`을 사용자가 저장소에 업로드한 뒤 수동 실행 필요.
- `REALCAR_VERIFIED`: 아님. 기존 AutoSplit/AutoStart 실차 정상 작동은 참조 앱에 한정.
- `FOLLOW_UP`: OEM별 stack windowing API 정밀 readback, launcher 앱서랍 shortcut 조건, camera fullscreen 후 task/split 재생성, media session 백그라운드 PLAYING readback 및 정확한 시동 전원 listener를 실제 로그로 보정해야 함. 전 항목 완료로 간주하지 않음.
