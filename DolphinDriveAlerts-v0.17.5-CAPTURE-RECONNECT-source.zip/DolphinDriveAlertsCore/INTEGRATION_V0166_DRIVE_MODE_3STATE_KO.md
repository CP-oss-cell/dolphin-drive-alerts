# v0.16.6 - 한국형 BYD Dolphin 주행모드 3상태 안내 정정

## 사용자 바로잡음
- 주행모드는 꺼지는 것이 아니라 `에코 / 노멀 / 스포츠` 세 상태를 선택함.
- 잠정 수신값: `0=에코`, `1=노멀`, `2=스포츠`.
- 적용 대상은 **Energy 장치의 `ENERGY_OPERATION_MODE` / `onOperationModeChanged()`** 뿐임. 계기판 `getCurrentDriveInterFace()`나 회생제동/ACC 이벤트에 이 값을 대입하지 않음.

## 원본·실차 증거의 경계
- SubAI v13의 `BydAutoService.handleOperationMode()`와 AutoFeedback APK에서는 `1`을 "스포츠 해제", `2`를 "스포츠 켜짐" 음성으로만 처리. 이는 두 앱의 **안내문 구현**이지 차량에 OFF 모드가 있다는 증거가 아님.
- 2026-10-08 19:59 실차 로그에는 에너지 이벤트 **`ENERGY_OPERATION_MODE(0x2120000e) : 2 → 1`** 및 에너지 callback과 getter `1/2`가 관측됨. **`0`은 해당 수집 구간에 없음**.
- 따라서 `1=노멀`, `0=에코`는 **사용자 제공 차량 조작/추정 기준**, `2=스포츠`는 소스와 차량 기록이 일치하는 기준. 완전 실차 검증이라고 주장하지 않음.

## 코드 구현
1. `vehicle/DriveModeDecoder.kt`: 세 상태에 대한 단일 `AlertEvent` 매핑 구현, 그 외 값 무시.
2. `vehicle/ReferenceVehicleEventBridge.kt`: Energy 전용 callback 및 실차 이벤트 `0x2120000e` 모두 처리하고 이전 값과 동일한 중복 콜백은 한 번만 안내.
3. `vehicle/VehicleEventDetector.kt`: 폴링 대체 경로에서도 동일 매핑 사용하며 최초 baseline은 변화 알림 아님.
4. 회생제동 `0x34100022`, 스포츠·스노우·기어·음성 asset 기존 경로 보존. 외부 AutoStart/AutoSplit 메뉴·EQ·DPI·ADAS 기능은 변경하지 않음.
5. `versionCode=22`, `versionName=0.16.6-drive-mode-three-state`.

## 재현 검증
- 실제 Kotlin 파일과 Android/BYD 타입 스텁으로 컴파일 및 실행한 결과 `0→1→2→0`, `2→1` 변화, callback + raw event 중복 억제, 잘못된 65535 무음, 회생제동 STANDARD/HIGH 유지 통과.
- 전체 Android Gradle 빌드 및 0=에코 실차 수신은 아직 미확인. 원본 SubAI 앱의 인증·SDK 코드를 배포본에 복제하지 않음.
