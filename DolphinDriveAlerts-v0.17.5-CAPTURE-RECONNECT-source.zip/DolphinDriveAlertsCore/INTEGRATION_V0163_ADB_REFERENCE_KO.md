# Dolphin Drive Alerts v0.16.3 — 검증된 앱 공개 연동 + ADB 실행 안정화

## 변경의 출처와 실제 기능
- v0.16.2를 기준으로 개발, 이전 기능 전부 보존. 버전 코드 19, 이름 0.16.3-adb-reference-bridge.
- AutoSplit 1.2.0 APK에서 확인했던 `com.sspark.bydautosplit.RUN_PROFILE` / `QuickSplitActivity` / `profile_id` 경로를 **원본 앱 설치 + 사용자가 실제 원본 프로필 ID를 연결한 경우에만** 사용.
- 우리 앱의 프로필 ID와 원본 앱의 프로필 ID는 별도. 데이터에 originalAutoSplitProfileId를 추가해 저장·수정·복원. 원본 호출을 수락받아도 분할이 실제로 성공했거나 지정 비율이 적용됐다고 주장하지 않음.
- 원본이 없거나 호출이 거부되면 기존 독립 분할 엔진을 이용하되, 승인된 로컬 ADB 연결이 반드시 필요함. 원본 앱 바이너리/ADB 키/서명/리소스를 이식하지 않음.
- AutoStart 2.4.4 원본 앱을 차량에서 이미 정상 운영하는 경우 `시동 앱 실행 설정` 화면에서 `원본 AutoStart에 맡기기` 선택 가능. 설정 열기 버튼 제공. 선택 시 우리 시동 자동실행을 중복 동작시키지 않음. 원본 앱 미설치 시 기존 자체 시퀀스 유지. **원본 앱의 시동 이벤트를 강제로 대신 호출하지 않으며, 사용자가 원본 설정에서 자동실행을 활성화해야 함.**
- NativeAdbClient 자체 연결/앱 자체 인증 키 유지. AuthorizedAdbRuntime 새 도입: 포트/인증/EPERM/명령거절 상태 분류, 읽기전용 명령만 일시 오류에 한해 재연결 후 최대 1회 재시도, 쓰기 명령은 1회만 전송, 30초 이하 인증 대기와 취소 신호 처리. 원본 앱의 ADB 인증키나 private data를 읽지 않음.
- v0.16.2 권한 버튼의 승인 ADB 사전 확인을 동일 실행 계층으로 일원화. 오버레이 설정은 순정 UI 유지. BYD OEM/signature 전용 권한을 ADB로 무조건 부여한다고 표시하지 않음.
- EQ, 오토홀드, 에코/노멀, 회생제동, BSD/DOW/차선이탈/앞차출발, 내비 5종 운전석 전용 출력은 이 ADB 브리지 변경만으로 해결됐다고 주장하지 않음.

## 사용 방법
1. 원본 AutoSplit/AutoStart를 사용하려면 차량에 **그 원본 앱**이 설치되어 있고 동작해야 함.
2. Dolphin Drive > 화면 분할 프로필 > 편집 > 원본 AutoSplit의 **실제 프로필 ID**(알고 있는 경우만)를 입력해 저장. 입력하지 않으면 자체 분할 계속 사용.
3. Dolphin Drive > 시동 앱 실행 > 원본 AutoStart에 맡기기 스위치를 선택하려면 원본 AutoStart에서 실행 규칙을 먼저 설정. 이 모드에서는 자체 시퀀스 중복 실행을 억제. 원본 미설치 시 자체 모드.
4. 자체 분할/자동실행은 ADB 연결 성공이 필요. 권한 메뉴에서 적용 후 readback 확인. ADB에서 승인되지 않은 권한은 실패로 표시.

## 범위·안전성
- 지원하는 공개 실행 인터페이스는 실차 검증 앱 1.2.0/2.4.4에 대한 이전 정적 분석에서 발견한 후보이며, 다른 버전의 exported 여부, 실제 실행 후 화면 분할 여부는 별도.
- ADB 소켓이 막혀 있거나 RSA 승인이 없으면 우회하지 않음. 모든 쓰기 명령에 자동 재시도를 하지 않아 앱을 2회 실행하거나 분할을 중복 조작하지 않도록 함.
- `RUN_PROFILE` 인텐트 발행은 실제 분할 완료/readback과 구분. 원본 ID가 없는 사용자에게 잘못된 내부 프로필 ID를 전송하지 않음.
- Source-level static checks: 276 prior + 32 new = 308 PASS. New Kotlin typed compilation + runtime unit checks PASS. Android Gradle full compilation + actual APK user installation is **not executed here**.

## 변경 파일
- `dpi/AuthorizedAdbRuntime.kt` 새 파일
- `automation/OriginalAutoSplitBridge.kt`, `automation/OriginalAutoStartBridge.kt` 새 파일
- `automation/{FeatureProfiles,VehicleSplitEngine,SplitProfilesActivity,AutoLaunchSequenceService,AutoLaunchSettingsActivity}.kt`
- `service/BootReceiver.kt`, `dpi/PermissionBootstrapper.kt`, `ui/MainActivity.kt`
- `app/build.gradle.kts` vCode 19.
- `tools/verify_v0163*` 및 `tools/verify_eq_v0163.py`, `tools/verify_unified_log_v0163.py`, `tools/verify_split_sequence_v0163.py`.

## 기존 이슈 연결
DA-004 ADB / DA-016 자동실행 / DA-027 AutoSplit / DA-026 검증 앱 정적 분석 / DA-029 통합 로그 보존. 사용자 요구로 파일 생성과 최종 검증 후 마지막에 Library 이슈 등록.
