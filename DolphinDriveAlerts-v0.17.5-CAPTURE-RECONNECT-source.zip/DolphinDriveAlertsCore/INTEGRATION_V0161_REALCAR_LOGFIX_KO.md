# v0.16.1 실차 로그 기반 진단 복구 — 통합 로그 2버튼 유지

기준: 2026-10-08 17:11:45~17:14:48 KST 실제 사용자 차량 수집 ZIP. 이 자료는 사용자 차량에서 기록된 이벤트이며 설치 APK 버전은 ZIP에 기록되지 않아 미확인입니다.

## 확정 오류
- `BydEventTap$start$1.onDataChanged(IBYDAutoEvent)`는 한국 차량의 `AbsBYDAutoSettingListener`에서 `final`. 원래 APK가 runtime verification error로 통합 tap 전체를 시작하지 못함. v0.16.1에서 seven listener classes의 해당 override를 제거하고 BYD `onDataEventChanged` 콜백은 유지. 등록 실패가 나머지 그룹으로 전파되지 않게 분리; 실제 한 개 이상 바인딩되기 전 tap 성공 선언 금지.
- `NativeAdbClient`는 TCP `127.0.0.1:5555`를 사용하지만 원본 v0.16의 Manifest에 `android.permission.INTERNET`이 없었음. 실제 로그의 socket `EPERM`과 합치됨. INTERNET 선언 추가. 다만 차량 ADB 자체 활성 여부/SELinux/RSA 인증이 나머지 실패 원인일 수 있으므로 연결 성공을 주장하지 않음.
- `session.json`의 `deepSnapshotAttemptSucceeded=true`는 작업 종료 여부일 뿐 명령 성공 보장이 아님. 시작/종료 진단 파일 각각의 `success=true/false`를 확인해 `diagnosticShellCommandSuccessCount`, `diagnosticShellCommandFailureCount`, `diagnosticShellUsable` 3개 필드 추가. 실제 사용자 로그 대조 Kotlin 검사는 0/18 성공/실패.

## 회귀 보존
- 화면의 수집 시작/수집 종료 버튼 2개, Download 단일 ZIP 저장, 원래 원시 로그 JSONL, 자동실행, 화면분할, EQ, TTS·주행음성, 내비 5종 지정 앱 설정을 변경하지 않음.
- `versionCode 17`, `versionName 0.16.1-realcar-logfix` (v0.16 코드 16과 별도 수정 빌드).

## 실차 원본에서 기록된 정상 신호 및 미해결
- 계기판 버저 3540건 (0/1 각각 1770), 빈번한 반복; 요약/스팸 집계 후보이며 신호 수신은 유지.
- ADAS_AVH_STATE (0x12200046) 1/0 세 쌍. 실제 체결인지 설정 상태인지 아직 구분할 수 없으므로 자동 안내 강제 활성화 금지.
- 스포츠 operationMode=2 및 =1 전환, 스노우 roadSurface 2 및 1 기록. `REFERENCE_ALERT_EMIT` 기록은 오디오 청감 성공 근거가 아님.
- MENU 이벤트 8개 중 `STEERING_TRIPLE_TAP_REFERENCE`/`PLAY` 1회. 물리 3회인지 화면만으로 단정 불가; 입력 스트림 정밀 확인 필요.
- EQ_REFRESH 15회는 설정 갱신 요청의 흔적일 뿐 DSP/음향 개선의 성공 근거 아님.
- 통합 로그 ZIP에 속도 0km/h만 있어 주행시 ADAS 출력을 확인할 수 없음. 차량 쓰기/AVAS/외부 스피커 제어는 추가하지 않음.

## 확인 사항
- 새 구조 검사 13/13, 원래 v0.16 검사 27/27, EQ 19/19, 통합 로그 41/41, 보존 split/sequence 145/145 통과(합계 245개 검사). 버전 번호 일치만 기존 검사에서 17로 갱신.
- 변경한 진단 상태 집계 함수는 Kotlin 독립 컴파일/실행 통과. 실제 18개 진단 파일을 입력으로 사용.
- **Android Gradle APK 전체 컴파일 및 수정 기능의 차량 동작은 미실행.** 빌드팩은 GitHub Actions 실행 후보이며 설치 APK가 아닙니다.

관련 이슈: DA-001/004 (권한 및 ADB), DA-029 (통합 로그), DA-003/005/006 (차량신호), DA-011 (핸들), DA-013 (빌드/검증). 자료: DOLPHIN_REALCAR_LOG_ANALYSIS_20261008_171145.md.
