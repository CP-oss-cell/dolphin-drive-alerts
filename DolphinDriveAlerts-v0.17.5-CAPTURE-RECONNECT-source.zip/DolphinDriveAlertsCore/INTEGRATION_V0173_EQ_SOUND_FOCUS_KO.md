# Dolphin Drive Alerts v0.17.3 — 현대·기아식 단순 EQ와 공간감 조절 개선

## 기준선 및 중요 사실
- v0.17.2 (`DolphinDriveAlerts-v0.17.2-EQ-REAL-EFFECT-source.zip`)에서 직접 이어서 개발했다. 새 앱 재구축 아님.
- 기준 실차 증거: `00_MASTER_ISSUES.md`, `01_REALCAR_EVIDENCE.md` (2026-10-09까지).
- v0.17.2 실차 EQ 성공 증거는 없음. 이 버전도 **실차 재검증 전**, 순정 현대·기아·Bose DSP를 그대로 구현했다고 주장할 수 없다.
- 원본 검증 참조: 이전 v0.17.2 분석에 기록된 Equalizer.6.3.5.8.apk, BYD_equalizerv4.2.apk 및 EVSound_10013.apk의 Android 표준 오디오 효과·세션/제어권/복원 패턴. 이 버전은 새로운 APK를 앱 내부에 임베딩하거나 설치하도록 요구하지 않는다.

## v0.17.3에서 수정한 파일
1. `GlobalEqualizerEngine.kt`: EQ OFF 시 수신한 개별 세션 ID를 보존하여 음악이 계속 재생 중일 때 ON으로 복귀 가능하도록 수정; DP 실패 시 설정 복원 후 legacy fallback; 2개 채널 readback; classic EQ는 headroom이 없으므로 모든 밴드를 동일하게 감쇠하는 safe trim; Virtualizer의 실제 routeMode 확인, `ROUTE_NOT_VIRTUALIZED` 표시; 자체 앱 효과 방송 무시.
2. `EqToneCurve.kt`: 저·중·고 3밴드 125~500 Hz와 2~8 kHz 로그 주파수 스무스 크로스페이드. ±6dB 상한, 입력 헤드룸 보호. 기존 Reference / Surround / Cinema 보정 유지.
3. `EqPreferences.kt`: 공간감 강도(0~100%) 저장/복원, 기본 50%.
4. `AudioTuningActivity.kt`: 현기차처럼 간단한 저음·중음·고음 + 공간확장 + Reference/Surround/Cinema + 공간감 강도 슬라이더 + 적용 상태 재확인. Global Mix 호환 설정은 하단에 배치.
5. `app/build.gradle.kts`: versionCode 29, versionName 0.17.3-eq-sound-focus.

## 사용법과 한계
- 음악 재생 중 **이퀄라이저 사용** ON → 저음/중음/고음 슬라이더로 조절(각 ±6dB).
- `Reference`는 음색 자체 위주, `Surround`/`Cinema`는 음색 보정에 표준 Android Virtualizer 효과를 조건부로 적용. 공간확장 체크 ON 시 Reference에서도 Virtualizer 사용을 시도.
- **공간감 강도 0%**는 Virtualizer OFF. 50% 기본, 100% 최대값(오디오 정책·하드웨어가 지원하는 범위만 적용).
- 상단 상태의 `EQ=APPLIED(DP-10band)` 또는 `EQ=APPLIED(LEGACY-5band)`는 Android API 효과값 readback 성공을 나타내며 청감·OEM DSP 성공을 보증하지 않는다.
- `SPATIAL=ROUTE_NOT_VIRTUALIZED`, `UNSUPPORTED_ROUTE_OR_CONTROL`, `NO_CONTROL`, `READBACK_FAIL` 등은 지원 불가·반영 실패 신호다. `API_ON`도 실제 360채널 동작을 증명하지 못한다.
- Global Mix session 0(호환)은 기기별로 미지원일 수 있고, 내비 안내·경고음 등 다른 오디오에도 영향을 줄 수 있다. 음질/경고음이 달라질 경우 EQ OFF 또는 Global Mix OFF.
- 네비 5종 운전석 라우팅(`DA-010`), 외부 AVAS, OEM 다중채널 DSP 제어는 이번 범위가 아니며 **미해결** 상태다.
- 다른 앱 설치를 요구하는 메뉴/연동은 추가하지 않았다.

## 회귀 보호
- 사용자 실차 정상 보고: 오토홀드 버튼 ON/OFF, 회생제동 스탠다드/하이, 빠른 핸들 3연타, 시동 자동실행, ADB 권한 부여. 이 기능의 소스는 이번 작업에서 손대지 않는다.
- 기존 v0.17.2 37개 EQ 구조 검사와 기존 차량 32개 검사에 대응하는 v0.17.3 검사, 신규 EQ 구조 검사 17개 및 독립 Kotlin 커브 테스트 15 assertions. 이 검사는 소스 수준이지 APK/실차 보증이 아니다.
- APK는 GitHub Actions에서 생성한다. 이 작업 컨테이너에서 Android SDK 전체 Gradle APK 빌드는 실행되지 않음. **CI_BUILD_REQUIRED / REALCAR_REVERIFY_REQUIRED**.

## 정차 상태 실차 A/B 승인 기준
1. 외부 EQ 앱을 끈 상태에서 음악 재생 후 v0.17.3 앱의 `EQ=APPLIED` / 세션 ID / 제어권 결과 확인.
2. Reference, Bass -10→0→+10; Mid / Treble도 같은 A/B. 이전 음량과 피크 왜곡 기록.
3. Surround/Cinema 선택, 강도 0/50/100% 비교. `API_ON`와 실제 청감 변화는 각각 별도 기록.
4. EQ OFF → 원래 음색 복귀 및 음악 재생 중 다시 ON 시 즉시 재적용 확인.
5. 경고/내비·주행 음성 오염, 운전석 전자음, 오토홀드/회생제동, 3연타 회귀 유무 확인.
6. 다른 EQ 앱을 동시에 실행 시 제어권/겹침/왜곡 체크. 지연·발열 확인.
