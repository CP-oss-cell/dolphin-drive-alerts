# Dolphin Drive Alerts v0.16.2 — 한국형 돌핀 ADB 권한 재설계 후보

## 근거: 사용자의 실제 차량 보고 (2026-10-08)
- 정상: 스포츠/스노우 ON/OFF 음성, 분할 바로가기 생성, 순정 화면 위 표시(오버레이) 허용.
- 실패: 회생제동 에코·스탠다드, 오토홀드 기능 작동·중지, 주행 에코/노멀 음성, EQ, 화면 회전, 분할 실행.
- 미확인: 오토홀드 실제 체결·해제, BSD/차선/앞차출발/DOW(정차 접근 경고), 시동 다중 앱·미디어 자동재생.
- 접근성/알림/기타 권한: 차량 순정 설정에서 메뉴 접근 불가. 사용자 인증 ADB 경로로만 권한 bootstrap 가능함.
- 과거 3분 로그에서 energyFeedbackRaw=65535(무효 후보), energy.recycle 확보 실패. 따라서 회생/에코 상태를 억지로 이벤트에 매핑하지 않음.

## 실제 변경 파일/행동
1. AndroidManifest: POST_NOTIFICATIONS 권한 추가, 기존 INTERNET·WRITE_SECURE_SETTINGS·BIND_NOTIFICATION_LISTENER_SERVICE·오버레이 유지.
2. `dpi/PermissionBootstrapper`: RSA 승인된 localhost ADB shell 확인 → secure settings(가능한 경우), 사용기록 AppOps, 백그라운드 AppOps, 배터리 예외, 기존 접근성 목록 보존 병합, `cmd notification allow_listener`(미지원 시 기존 목록 보존 병합), API33+ 알림 게시 runtime grant, 각각 독립적인 실제 readback. BYD signature 권한은 ADB로도 거부될 수 있음; 전체 완료처럼 표시하지 않음.
3. 메인 화면의 접근성/사용기록/배터리 일반 Android Settings 버튼 제거. ADB 적용과 ADB 상태 확인 버튼에 전체 결과를 대화상자로 표시. **오버레이 설정 버튼은 정상인 순정 경로로 유지**.
4. `ForegroundPackageMonitor`: UsageStats 이벤트 범위 10초→120초, 최종 사용 앱 조회, 실패 시 일정 간격으로 허가된 ADB에서 foreground task 조회하여 overlay 앱별 회전 후보 적용.
5. `AutoLaunchSequenceService`: 시동 직후 로컬 ADB가 늦게 시작될 수 있어 제한된 연결 확인과 대기 추가. 실패 시 앱 실행 성공을 주장하지 않음. 미디어 play는 NotificationListener와 MediaSession의 실제 PLAYING 확인을 유지.
6. `VehicleSplitEngine`: `am stack list`가 지원되지 않는 ROM이면 읽기 전용 `dumpsys activity activities`를 통한 split state readback을 시도. 기존 task windowingMode3/4 요청, 카메라 복원 가드 보존.
7. `tools/adb_permissions_ko.ps1`: 차량 소유자가 승인한 PC ADB에서 사용할 수 있는 동등 명령 및 readback 포함. 루팅·서명 우회 없음.
8. v0.16.1 로그 수집 성공·실패 분리와 BYD listener ABI 수정, 통합 로그 2버튼·EQ·분할바로가기·기어/스포츠/스노우 정상 경로는 모두 보존.

## 중요한 미해결 조건
- Permission `WRITE_SECURE_SETTINGS` / `POST_NOTIFICATIONS` / AppOps는 각 ROM이 승인해야 함. OEM signature/privileged 권한은 일반 ADB shell로 임의 획득 불가.
- ADB TCP 5555 포트가 닫혀 있거나 RSA 미승인이면 앱 내부에서 자동 연결할 수 없음. 외부 PC ADB 또는 제조사에서 승인한 인터페이스가 필요.
- 실제 EQ는 다른 UID의 오디오 세션 제어권·OEM DSP 지원이 없으면 변경되지 않을 수 있음. API 설정/readback만으로 청감 성공 판정 금지.
- 오토홀드 AVH 0/1이 설정 버튼인지 체결 상태인지 미확정, BSD·차선·앞차발·DOW 후보도 위험 이벤트 의미 미확정. 안전 경고를 임의 발화하지 않음.
- 재생/화면 분할은 ADB 및 MediaSession/시스템 task capability에 종속되며 이 버전 소스 자체의 실차 성공 주장 금지.

## 확인된 검증 범위
- `PermissionBootstrapper.kt` Kotlin typed stub compile + 3개의 동작 테스트(기존 권한 보존·readback·진단만 조회·ADB 불가) PASS.
- v0.16.2 신규 정적 검증, 과거 기능 정적 보존 게이트, manifest XML/YAML parsing, source ZIP CRC 예정.
- **전체 Android Gradle APK CI 빌드와 신규 APK 실차 확인은 미수행.**
