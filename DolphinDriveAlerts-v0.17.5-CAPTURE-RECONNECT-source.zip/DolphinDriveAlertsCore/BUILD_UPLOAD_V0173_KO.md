# v0.17.3 GitHub Actions 빌드 방법

이 패키지는 **설치 APK가 아닌 소스+빌드팩**입니다. Android SDK가 없는 환경에서 APK 빌드를 실행했다고 주장하지 않습니다.

1. GitHub 저장소 `main` 최상단에 `DolphinDriveAlerts-v0.17.3-EQ-SOUND-FOCUS-source.zip` 업로드.
2. `.github/workflows/build-v0173-from-source-zip.yml` 경로에 별도 제공된 YML 추가. 파일명과 ZIP 이름 변경하지 말 것.
3. GitHub → Actions → `Build Dolphin Drive Alerts v0.17.3 EQ SOUND FOCUS APK` → Run workflow.
4. `build-apk` 성공 후 Artifacts의 `DolphinDriveAlerts-v0.17.3-EQ-SOUND-FOCUS` 안에서 APK 받아 수동 설치.
5. 실패 시 `DolphinDriveAlerts-v0.17.3-build-failure-log`와 Gradle 로그 확인. 설치 전 APK의 signing key/기존 버전과 충돌 확인.
6. 안전한 정차 상태에서 `INTEGRATION_V0173_EQ_SOUND_FOCUS_KO.md`의 실차 A/B 수행 후 검증 상태 업데이트.

경고: 본 파일에는 설치 APK가 없습니다. CI/실차 재검증 전 `VERIFIED` 아님.
