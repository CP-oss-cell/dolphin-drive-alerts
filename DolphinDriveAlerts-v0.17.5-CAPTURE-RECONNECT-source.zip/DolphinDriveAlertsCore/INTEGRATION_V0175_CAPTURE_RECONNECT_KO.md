# Dolphin Drive Alerts v0.17.5 — DA-029 통합 로그 시동 재개 보강

## 기준선
- 기존 `/Dolphin Drive Alerts/DolphinDriveAlerts-v0.17.4-AVAS-LOG-CORRELATION-source.zip` 그대로 확장. V0.17.4 AVAS 후보 신호 분석과 v0.17.3 EQ 개선 소스 보존.
- 버전 `versionCode 31` / `versionName 0.17.5-capture-reconnect`.

## 원인
- 기존 UnifiedLogCapture는 수집 상태/세션 ID를 SharedPreferences에 유지하지만, 서비스 onCreate에서 상태가 RECORDING인 경우에도 lazy BYD Event Tap을 다시 열지 않았음.
- 오디오/차량 HAL callback은 headunit 슬립/시동 OFF에서 비활성화될 수 있으며, 단순 START_STICKY 및 수집 중 UI 복원만으로 지속 수집을 증명할 수 없음.
- 기존 ZIP에는 전원 차단·재시작·리스너 등록 재시도 타임라인이 분리 기록되지 않았음.

## 적용 소스
1. `CaptureContinuity.kt` 추가: 세션별 persisted journal(최대 최근 128개), 샘플러 10초 heartbeat, 시동 OFF/ON broadcast 힌트, 서비스 재개 시 이전 heartbeat와 현 시각 차이 20초 초과를 POSSIBLE_CAPTURE_GAP으로 기록. 단순 heartbeat=실제 OEM 콜백 수신 증명 아님.
2. `UnifiedLogCapture.kt`: begin 때 journal 초기화; 수집 종료 ZIP에 `lifecycle/capture_continuity.json` 추가; 성공적으로 ZIP 저장 완료 시에만 journal 삭제. 기존 `session.json`과 범위 제한 `logs/vehicle_events.jsonl` 유지.
3. `DrivingAlertService.kt`: 이전 세션 RECORDING일 때에만 reflection 기반 BYD Event Tap 복구. 하드 시동 ON 힌트에서 listener unregister/re-register; 제어권/바인딩 실패 시 30초 간격 재시도 및 오류 기록. commandExecutor 직렬화 및 중복 재시도 억제. 기존 정상 주행알림 서비스/음성/EQ·분할·권한 로직 보존.
4. `BootReceiver.kt`: ACC_OFF/POWER_DISCONNECTED는 service 시작 없이 읽기 전용 전원 힌트만 지속 저장. 정상 시동·사용자 복귀 계열 알림에서 수집 중인 경우 녹화 세션 복구 요청. Android 정책으로 FGS 시작이 거부될 경우 로그/재시도 경로는 근거가 될 때만 작동. 강제종료(force-stop) 상태에서는 자동 복구 보장 없음.
5. `MainActivity.kt`: 수집 상태 유지와 실제 미수집 구간을 명확히 구분.
6. `app/build.gradle.kts`: versionCode 31, versionName 변경.

## 안전/제약
- OEM 차량 제어, 주행 보행자 전자음 변경, AVAS ON/OFF, 내비 외부 라우팅을 추가하지 않음.
- 시동 OFF 동안 헤드유닛이나 ECU가 전원 차단되면 로그 생성 불가능. 끊긴 범위는 `POSSIBLE_CAPTURE_GAP`으로 표시하며 완전 연속 수집 성공을 주장하지 않음.
- OS 강제중지/권한 거부/배터리 정책에 의해 브로드캐스트/서비스 재시작이 불가능한 기기에서는 자동 복구가 지연되거나 실패할 수 있음.
- journal은 최근 128개 이력만 보존, 이벤트 로그(원본)는 별도 JSONL에 보존. 장기간 로그 파일 보존을 위해 저장 용량 확보 필요.
- listener 등록 성공은 콜백 실수신과 다름(`REGISTERED_UNCONFIRMED`).

## 테스트·검증
- 신규 Kotlin 실제 컴파일 + 가짜 Context/Preferences/JSON 샘플 12개 동작 검증 PASS.
- 신규 capture 복구 구조/수집 종료/보안 검사 26/26 PASS.
- 전 버전 동작 유지 검사: 차량 32/32, EQ 개선 17/17, EQ 엔진 37/37, AVAS read-only tracker 테스트 PASS (기존 테스트 중 버전 assertion만 31로 적응).
- ZIP CRC 및 workflow YAML 구문 검사 PASS. **Android Gradle 전체 :app:assembleDebug 빌드 이 환경에서 실행 불가**. 실제 한국형 Dolphin ACC OFF/ON 반복/로그 복원/이벤트 회복 미검증: `REALCAR_REVERIFY_REQUIRED`.

## 실차 체크 (정차 중)
1. `수집 시작`, 차량 전자음 순정 설정 변화시 로그 발생시키기
2. 시동 OFF → 충분히 대기 → ON, 앱 열지 않아도 가능하면 별도 이벤트 한 차례 유도
3. 두세 번 반복 후 `수집 종료` 1회. `Download/DolphinDriveLogs_<원래 세션 ID>.zip` 하나의 ZIP 확인
4. `session.json`, `logs/vehicle_events.jsonl`, `lifecycle/capture_continuity.json` 확인
5. journal의 `SERVICE_RESTORED`, `IGNITION_HINT`, `BYD_TAP_REGISTERED_UNCONFIRMED`, `POSSIBLE_CAPTURE_GAP`와 새 `byd_event` 실제 발생 타임스탬프 대조
6. 재시동 후 상세 이벤트가 없다면 `BYD_TAP_RETRY_PENDING` 및 실패 원인 확인; 회복을 성공으로 표기하지 않음
