# Dolphin Drive Alerts v0.17.2 — EQ 실제 효과 경로 보강

## 발생 증상 / 소스 분석
- 사용자 실차 보고: 저음·중음·고음 변화 미미함; 360과 음장효과 미적용.
- v0.17.1: OPEN_AUDIO_EFFECT_CONTROL_SESSION 알림 없으면 실시간 EQ 세션 없음. 모든 3밴드의 변화량 ±3 dB.
- Centerpoint360/SoundFocus는 저장/UI 표시만 했으며 효과 엔진에서는 적용되지 않음.

## 참조 원본 및 구현
- 사용자 제공 `Equalizer.6.3.5.8.apk` / `BYD_equalizerv4.2.apk` 정적 분석: Global Mix 세션0, DynamicsProcessing API28+ 10-band, legacy Equalizer 5-band, 표준 Virtualizer.
- 사용자 제공 `EVSound_10013.apk` 분석: hasControl + readback + baseline restore / session lifecycle. SVC 및 엔진음 기능은 도입하지 않음.
- `GlobalEqualizerEngine.kt`: 앱별 세션 OPEN/CLOSE 수신 우선, 수신이 없으면 전역 Global Mix(설정에서 OFF 가능, 사용 중인 EQ ON 시 기본 활성), DP 10밴드 API 적용 및 실제 readback, 미지원·제어권 없으면 기존 Equalizer 5-band fallback, 활성화/세션 종료 시 원복.
- `EqToneCurve.kt`: Bass/Mid/Treble ±6dB, EQ headroom만큼 입력 감쇠(-0~6dB), Reference/Surround/Cinema의 음색 보정. 순정 DSP 처리 아님.
- 선택적으로 Android Virtualizer 적용/강도 readback 및 해제/원복. 순정 Bose Centerpoint 360 동일 아님, 물리적 차량 360 음장 검증 아님.
- `AudioTuningActivity.kt`: 세션 지원·기능 상태 문구 개선, Global Mix 설정, UI 슬라이더 dB 표시.

## 중요 보호
1. 글로벌 이펙트가 경고·내비·음악에도 영향을 줄 수 있으므로 음질이 나빠지면 'Global Mix 호환모드' OFF 또는 EQ OFF. 기존 기본 차량 볼륨·루트 값은 수정하지 않음.
2. 한 세션에 DynamicsProcessing + legacy EQ 동시 적용 금지. BassBoost/LoudnessEnhancer 중첩 금지.
3. Virtualizer 지원 여부가 API에서 TRUE여도 실제 물리 360 공간감은 별도 실차 청감 필요. UI 표시를 실제 OEM DSP와 혼동하지 않음.
4. 오토홀드 작동/중지·회생제동 하이/스탠다드 사용자 확인, 운전석 알림, 3연타, 차량 신호 감지, 권한부여 기능을 변경하지 않음.

## 검증
- Kotlin Android/audiofx stub typed compile + 동작 재현: GLOBAL 10-band / tone gain / headroom / virtualizer / session switch / session close / 5-band fallback / all off.
- 37 EQ 구조 검사 및 32 기존 회귀 검사 PASS.
- 이 컴퓨터에서 전체 Gradle Android SDK 빌드/실차 A-B 청감은 실행되지 않았음. GitHub Actions 전체 빌드 후, 차에서 저·중·고 및 360 지원 상태를 확인할 것.
- GitHub APK 서명·설치 및 실차 여부는 USER_REVERIFY_REQUIRED.
