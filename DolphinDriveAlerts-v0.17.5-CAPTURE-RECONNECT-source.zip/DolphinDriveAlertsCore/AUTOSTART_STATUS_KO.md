# v0.12 자동 실행 / 백그라운드 동작 확인

## 코드 상태
- `AlertPreferences.autoStartEnabled()` 기본값: **true**.
- 최초 설치 후 사용자가 앱을 1회 실행하면 `MainActivity.onCreate()`에서 `DrivingAlertService.start()`를 즉시 호출.
- `BootReceiver`가 다음 이벤트에서 서비스 시작을 재요청:
  - `BOOT_COMPLETED`
  - `MY_PACKAGE_REPLACED`
  - `USER_PRESENT` / `USER_UNLOCKED` / `SCREEN_ON`
  - `android.intent.action.ACTION_POWER_CONNECTED`
  - `android.intent.action.QUICKBOOT_POWERON`
  - `com.byd.intent.action.QUICKBOOT_POWERON`
  - `com.qualcomm.action.QUICKBOOT_POWERON`
  - `com.byd.action.ACC_ON`
  - `com.byd.action.IGN_ON`
  - `com.byd.accmode.ACC_MODE_CHANGED`
- `com.byd.action.ACC_OFF`와 `android.intent.action.ACTION_POWER_DISCONNECTED`는 stop-side 신호로 기록만 하고 새 service start를 요청하지 않음.
- 기존 잘못된 `android.intent.action.POWER_CONNECTED` 문자열은 표준 `android.intent.action.ACTION_POWER_CONNECTED`로 수정.
- `DrivingAlertService`는 `START_STICKY`.
- Manifest 서비스는 `android:stopWithTask="false"`.
- foreground notification을 유지하여 Android 10 계열 백그라운드 제한에 대응.
- 메인 화면에 **시동 시 자동 백그라운드 실행** 체크박스를 제공하며 기본 ON.

## 중요한 제한
Android에서 사용자가 앱을 **강제 종료(Force stop)** 하면 시스템이 해당 패키지의 receiver/service 재시작을 막는다. 이 경우에만 앱을 다시 한 번 직접 실행해야 한다. 일반적인 차량 시동/Quick Boot마다 앱 UI를 수동 실행하도록 설계되어 있지 않다.

## 실차 검증 필요
이 구성은 소스 수준에서 확인/보강됐지만 한국형 Dolphin 펌웨어가 어떤 Quick Boot broadcast를 실제로 전달하는지는 v0.12 APK 실차 검증이 필요하다.

검증 순서:
1. v0.12 설치 후 앱 최초 1회 실행.
2. `시동 시 자동 백그라운드 실행` ON 확인.
3. 앱 화면을 닫고 차량 전원 OFF/ON.
4. 앱 UI를 직접 열지 않은 상태에서 foreground notification 또는 새 RAW log의 `BOOT` / `SERVICE_STARTED_V012_ORIENTATION_EQ_AUTOSTART` 확인.
5. 최근 앱에서 제거한 뒤에도 서비스 유지 확인.
