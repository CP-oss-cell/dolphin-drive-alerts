# Dolphin Drive Alerts v0.16 — 기존 실차 참고 앱 분석의 선별 통합

## 원칙
- 기반: 2026-10-08 `v0.15` compilefix 정본 소스, 기존 v0.13 분할/시동·v0.14 두 버튼 통합로그·v0.15 EQ 보존.
- 출처: SubAI v13, AudioFeedback, OverDrive v48.18, AutoSplit v1.2.0, AutoStart v2.4.4, Screen Orientation Control, Kinex, EVSound v10013. 각 참고 앱에서 확인한 원리만 독립 코딩.
- 실차 검증 앱의 동작을 **Dolphin Drive APK의 검증 성공으로 혼동하지 않는다.** 타 앱 UID 운전석 출력 권한, 차종별 미확정 ADAS 값, 차량 카메라 제어/AVAS write는 가짜 구현하지 않음.

## 코드에 반영한 범위
1. DA-003/005/006/007/008 신호: SubAI / AutoFeedback에서 확인한 기어·회생 2/3·Sport 2·Snow 1/2·ACC mode 정상 경로 보존. 이벤트/AudioTrack 미출력 이슈는 통합 로그 수집으로 추적. ECO/NORMAL 동적 상태 구별에 필요한 안전한 확정 신호는 없어서 추정 자동 알림 금지. AVH 실제 체결, 좌우 BSD 위험, 실제 앞차 출발·차선이탈도 미확정 event value를 근거 없이 발화하지 않음.
2. DA-005 사용자 최신 음성: AutoHold 기능 ON=`오토홀드 작동`, OFF=`오토홀드 중지`, 실제 체결·해제 문구 별도 유지; Snow OFF=`스노우 모드 해제`. `AlertModels`, `tools/voice_prompts.json`, `VOICE_PACK_MANIFEST.csv` 동기화. GitHub Action에서 남·여 WAV 모두 새로 생성.
3. DA-011/012 3연타: SubAI 메뉴 차량 신호의 완성된 1→2 세 쌍만 인정, 2회 이하 반응 없음; 접근성 KEY_DOWN/UP 눌림 상태로 중복 DOWN 카운트 금지, 두 수집 경로에 공통 1.6초 단발 게이트. 302/303/306/312 OEM long 키는 기존 3연타 키와 별개. **외부 AVAS 스피커로 임의 사용자 WAV를 라우팅한다는 뜻이 아님**.
4. DA-014 회전: 전역 ON/OFF 저장 스위치 → 앱별 오버레이·UsageStats·Accessibility 모두 연결; OFF 즉시 오버레이 제거/순정 회전 복구; 기존 per-app 회전 정책 보존.
5. DA-001/004 접근성·ADB: 접근성 키 처리와 패키지 정책 워커의 예외 격리, 차량별 누락 Settings Activity에 기본 Android 설정 fallback, ADB 실패 정보 표시, 배터리 설정 접근 버튼 제공; 서명 권한 부여 성공을 허위 표시하지 않음.
6. DA-010 DPI: 선택 앱 '저장 후 실행'은 `wm density` 시스템 전체 변경 뒤 readback을 검사하고 성공할 때만 앱 launch. 기존 접근성 전면 앱 관찰에 의한 복원 경로는 유지. **진짜 개별 앱 DPI가 아니며, ADB shell 권한 미확보 차량에서는 실행 불가**.
7. DA-010 내비 5개: TMAP, NAVER Maps, KakaoMap, Atlan3D, MCon K 패키지 사전과 실제 UID / `MODIFY_AUDIO_ROUTING` 권한 readback 로그 추가. 권한/차량 운전석 출력 장치 미확보에 따른 `DRIVER_ROUTE_PENDING_VENDOR_HOOK` 명시 유지. **이 APK는 다른 UID 오디오를 운전석으로 바꾸지 못한다**.
8. DA-016/027 AutoStart/AutoSplit: 등록된 앱별 초 단위 예약·미디어 세션 플레이·중단/재시동 가드, 프로필/단축아이콘, 카메라 종료 후 분할 비율 복구를 유지. 분할 resize 요청 이후 분할 스택 readback 및 미디어 PLAY 뒤 `PlaybackState.STATE_PLAYING` readback을 추가해 단순 명령 성공을 실제 재생/화면 성공으로 오인하지 않음. 원본 AutoSplit/AutoStart의 전체 UI/모든 전원 콜백/음장/미디어 카드 동등 이식은 아님.
9. DA-015/030 EQ: 기존 v0.15의 hasControl/세션 OPEN-CLOSE/3밴드 readback/원복 유지. 사용자가 요청하지 않은 EVSound SVC·가상 엔진음 미추가.
10. DA-029 두 버튼 통합 로그(수집 시작/수집 종료) 및 Download 세션 ZIP 유지; 진단 메뉴 재증설 금지.

## 확인 수준
- 이번 버전은 소스 수정·정적 검증·독립 Kotlin 단위 컴파일을 거치는 **GitHub Actions 빌드 대상**이다. 로컬 환경 Android SDK 부재로 전체 APK 빌드 미실행. Actions `assembleDebug` 성공 후 APK 배포 가능.
- 순정 차량 ADAS 안전 기능 및 법정 VESS/AVAS에 대한 미확정 write는 하지 않는다.
- 이번 작업의 이슈 등록은 산출물 검증 후 마지막 단계에 DA-001/003/004/005/006/007/008/010/011/012/013/014/015/016/027/029/030을 기존 마스터에 **중복 ID 없이 추가 기록**한다.
