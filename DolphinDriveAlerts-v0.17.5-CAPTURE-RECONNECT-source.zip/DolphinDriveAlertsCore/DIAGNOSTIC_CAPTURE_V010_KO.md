# Dolphin Drive Alerts 0.10 Diagnostic Capture

기준: `DolphinDriveAlerts_FINAL_v0.9_REFERENCE_TEST_source.zip`은 원본 보존. 0.10은 별도 진단 사본이다.

## 목적

실차에서 아직 확정되지 않은 주행보조 신호를 자동 음성에 바로 연결하지 않고, 한 번의 로그 수집으로 상태값/카운터/좌우 방향을 확정하기 위한 read-only 진단판이다.

## 0.10 추가 수집

- `getBrakePedalState()` 실제 브레이크 페달 원시값
- `getAVHState()` 원시값 0~3 후보. 값 의미는 실차 로그 전까지 확정하지 않음
- ADAS getter: BSD, LDSW type, LKS mode, lane offset, TJA, PCW
- BeetleLauncher에서 확인된 DiPilot getter 이름(같은 APK에 setter 및 `frontstart|켜기/끄기` UI 문자열이 있어 **기능 스위치 후보**로 분류):
  - `getFrontCarStartState()`
  - `getControlLossWarningState()`
  - `getOpenDoorAlertState()`
  - 전/후방 교차 경고 및 제동 경고
  - 충돌/예측충돌/긴급제동 경고
  - blind-monitor 후보 3개
- Overdrive/framework에서 확인된 정확 Feature ID read-only 값:
  - BSD L/R LEVEL: `0x4180002C`, `0x4180002E`
  - LCA L/R COUNTER: `0x41800010`, `0x41800012`
  - RCTA L/R COUNTER: `0x41800014`, `0x41800015`
  - DOW L/R COUNTER: `0x41800020`, `0x41800022`
  - AVH `0x12200046`
  - PCW pre/latent `0x32D00018`, `0x32D00019`
  - lane tracking L/R `0x3160000C`, `0x3160002A`
- LauncherMap 3.722의 ADAS listener가 구독하는 `ADAS_ACC_TEXT_INFO_FOR_DRIVER`도 런타임 Feature ID를 reflection으로 찾아 read-only 기록. 해당 값 `0x12`는 앱 내부에서 실제 주행 이벤트 boolean으로 처리되어 `awayLargeVehicle` 카운트를 증가시키지만, 정확한 사용자 의미는 실차 상관관계 전까지 미확정.
- BeetleLauncher 1.713의 `assets/beetle-sdk-listener.dex` method table에서 실제 DiPilot listener callback 서명도 확인:
  - `onFrontCarStartStateChange(int)`
  - `onDriveDepartureStateChanged(int)` / `onDrivieDepartureStateChanged(int)`
  - `onOpenDoorAlertStateChanged(int)`
  - `onLeftBehindReminderStateChanged(int)`
  - 전/후방 교차경고·제동경고, 충돌/긴급제동/예측충돌, blind-monitor callbacks
  - `onAlarmTypeChanged(int)`, `onAEBDecActiveChanged(int)`, `onRearCrashAlertStateChanged(int)`도 별도로 기록해 설정값과 실제 활성 경고를 구분
- 0.10의 `BydEventTap`은 위 콜백을 explicit diagnostic capture에서만 등록해 `dipilot.*` 로그로 기록한다. getter의 설정값과 실제 callback 값을 분리해서 비교할 수 있다. 자동 음성 재생은 하지 않는다.

## 안전 원칙

- `setInt`, `setBuffer`, ADAS/DiPilot setter 호출 없음.
- `enableDevice` 호출 없음.
- exact Feature-ID 채널은 `getInt`만 사용.
- raw-manager binder가 멈추더라도 메인 150ms 차량 샘플러가 같이 멈추지 않도록 별도 daemon 단일 스레드에 격리.
- DiPilot getter 값은 기능 설정값일 수도 있으므로 이벤트라고 단정하지 않음.
- 실차 값 매핑 전에는 AVH/DOW/BSD/LCA/RCTA/차선/앞차출발 자동 음성 트리거로 승격하지 않음.

## AVAS 외부 스피커 현재 결론

Dolphin 연구 근거상 MCU가 생성하는 AVAH/AVAS 테스트톤과 순정 AVAS 프리셋은 외부 스피커에서 동작한다. 반면 Android 앱 WAV/PCM을 외부 AVAS 스피커로 직접 라우팅하는 시도는 현재 확인된 경로에서 실패했다. 따라서 0.10은 임의 음성을 외부 스피커로 보낸다고 가장하지 않는다.

## 권장 실차 로그 순서

1. 정차 상태에서 앱 실행 후 10초 유지.
2. 브레이크 페달 OFF/ON을 몇 차례 반복하고 마커 기록.
3. AutoHold OFF/ON, 실제 체결/해제를 각각 만들어 마커 기록.
4. 안전한 환경에서 좌/우 BSD 경고를 각각 만들고 마커 기록.
5. 가능하면 LCA/RCTA/DOW 좌/우를 각각 1회 이상 발생.
6. 차선 이탈 좌/우를 각각 발생.
7. 정차 후 앞차출발 알림, 도어 열기 전 후측방 경고가 실제 순정 UI에 뜨는 상황을 각각 기록.
8. Download ZIP 생성.

로그에서 `probe.raw.*`, `probe.target.*`, `brakePedalRaw`, `avhRaw`의 전후 값을 대조해 자동 음성 트리거를 다음 버전에서 확정한다.

## AVH/브레이크 현재 코드 근거

- BYD Gearbox SDK 상수: `getBrakePedalState()`는 `1=PRESS`, `2=NOT_PRESS`.
- Gearbox auto mode: `P=1, R=2, N=3, D=4`.
- LauncherMap의 `onAdasAvhState(int)`는 현재 기어가 D일 때 AVH 값이 `2`이면 AR 내부 vehicle gear를 D 상태값 1에서 N 상태값 2로 바꾸고, 그 외 AVH 값은 D로 유지한다.
- 따라서 `AVH=2`는 실제 AutoHold 체결/hold-active의 강력 후보로 라벨링하되, 자동 음성 트리거 승격은 실차에서 `D + 정지 + brake released + AVH=2` 상관관계를 확인한 뒤 진행한다.
- AVH `0/1/3`의 의미는 아직 미확정이다.
