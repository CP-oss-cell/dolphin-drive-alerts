# Dolphin Drive v0.16.7 — 오토홀드 기능 버튼 안내 복구 후보 + 불필요 메뉴 제거

## 사용자 요청과 증거
- 기능 버튼 OFF→`오토홀드 중지`, ON→`오토홀드 작동`. 실제 오토홀드 체결/해제는 별개 이벤트(`AUTOHOLD_ENGAGED` / `AUTOHOLD_RELEASED`).
- 실차 이벤트 기록에 `ADAS_AVH_STATE` (`0x12200046`)의 0/1 변화가 존재. `0=버튼 OFF`, `1=버튼 ON`은 이 관측과 사용자 요청을 바탕으로 한 **잠정 후보 매핑**으로, 정지/주행 전 구분·실차 발화를 확정한 증거는 아님. 값 2는 차체 제동 체결 관련 후보이며 버튼 ON/OFF로 **해석하지 않음**.
- 확인한 참조 파일: `BydSubAI-beta_v13.zip` 원본 소스 및 `Byd_AutoFeedBack_v1.0.apk` DEX. 이 버전들에서는 AutoHold/AVH 전용 음성 분기를 직접 특정하지 못함. 따라서 특정 원본 코드의 100% 동일 포팅이라고 주장하지 않음.

## 실제 변경
1. `AutoHoldSwitchDecoder.kt` 신규: ADAS raw 0/1만 기능 버튼 안내로 변환, 최초 수신 기준점(무음), 동일값 중복 차단, raw 2 무시, 동시 콜백 보호, 종료 후 기준점 재설정.
2. `ReferenceVehicleEventBridge.kt`: BYD ADAS 이벤트 0x12200046 **해당 소스에서만** 디코딩→`AlertGate`→내장 음성 경로로 연결. 실제 체결/해제 알림은 손대지 않음.
3. `SplitProfilesActivity`, `FeatureProfiles`, `VehicleSplitEngine`, `AutoLaunchSettingsActivity`, `AutoLaunchSequenceService`, `BootReceiver`: 원본 AutoSplit/AutoStart 앱 설치·프로필 ID·호출·위탁 옵션 모두 제거. 자체 기능 유지; 기존 저장 프로필의 앱/비율/바로가기 ID 유지하며 과거 원본 연동 ID 필드는 읽지 않음. 원본 앱 별도 설치 불필요.
4. `MainActivity`: 불필요한 원본 연동 안내·수동 이벤트 테스트·중복 권한 조회·전역 DPI 직접 변경 테스트·중복 핸들 학습 상태 버튼·오래된 상태 문구 제거. **ADB 필수 권한 적용**, 자동실행/분할 프로필 편집, 단발 음성, 2버튼 통합 로그 수집, EQ/회전 설정은 유지.

## 검증과 경계
- Kotlin 컴파일 + 리스너 실제 `processEvent` 호출 테스트에서 ADAS 0,0,1,1,2,1,0,0,1 → `AUTOHOLD_ON`, `AUTOHOLD_OFF`, `AUTOHOLD_ON`만 생성 확인. 다른 소스/이벤트 ID는 트리거하지 않음.
- v0.16.6 보존 검증과 v0.16.7 신규 UI/신호/의존성 정적 게이트 수행. Manifest 및 ZIP 검사 별도.
- 현지 Android Gradle 전체 APK 빌드/실차 발화 검증 **미수행**. 운전 중 임의 음성이 반복되는 경우, 수집한 로그의 같은 eventId raw 값과 페달 상태를 대조해야 함.
- 다른 미해결 기능(ADAS 위험·오토홀드 실제 체결·회전·MConK 라우팅·EQ 순정 DSP 등)은 완료로 표시하지 않음.
