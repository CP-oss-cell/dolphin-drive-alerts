# Dolphin Drive Alerts 0.11 Regression Recovery

## 확인된 0.10 회귀 원인
- `VehicleEventDetector`가 기어/EPB/회생/스노우/SPORT 외 이벤트를 실제 `emit()`하지 않았다.
- AUTOHOLD/ICC/BSD/앞차출발/차선이탈/도어경고는 enum/음성 파일만 존재하고 정상 주행 서비스에서 자동 발화 경로가 없었다.
- 핸들 3연타는 SubAI의 실차 검증 `INSTRUMENT_2IN1_MENU_STATE`가 아니라 접근성 KeyEvent 학습을 우선 사용하고 있었다.
- ADB 클라이언트는 RSA 승인 대기 후 지속 재시도 및 필수 권한 일괄 적용 UI가 없었다.

## 0.11에서 복구한 검증 경로
- Byd_SubAI_Beta_v13 소스의 Instrument/ADAS/Energy listener 방식을 정상 런타임에 별도 브리지로 복원.
- `ADAS_ACC_MODE`: 3=자율주행/크루즈 ON, 0/1/2/4=활성 상태에서 OFF.
- Energy recycle: 2=Standard, 3=High.
- Energy road surface exact event `0x24000033`: 1=Common, 2=Snow.
- Operation mode: 2=Sport ON. 1=Sport OFF이지만 ECO/NORMAL 구분 근거는 없으므로 ECO/NORMAL 자동 발화에는 사용하지 않음.
- `INSTRUMENT_2IN1_MENU_STATE`: 1초 안의 1-2-1-2-1-2 또는 반대 패턴을 핸들 3회 입력으로 처리.
- BSD assist `0x41800008`은 설정 ON/OFF 근거만 있으므로 위험 경고 `BSD_WARNING`으로 오용하지 않음.

## 음성 문구 변경
- 오토홀드 온/오프 -> 오토홀드 켜짐/꺼짐
- 자율주행 온/오프 -> 자율주행 모드/자율주행 해제

## ADB/권한 복구
- dadb 1.2.8, 영구 RSA key, 승인 대기 재시도.
- WRITE_SECURE_SETTINGS, SYSTEM_ALERT_WINDOW, 백그라운드 appops, 배터리 최적화 예외를 일괄 적용.
- 기존 enabled_accessibility_services 목록을 보존하며 이 앱의 접근성 서비스를 추가하고 readback.
- BYDAUTO COMMON 권한 grant도 시도하되 firmware가 signature/privileged로 거부할 수 있으며, 거부를 성공으로 숨기지 않는다.

## 계속 잠근 항목
AVH AutoHold 체결, BSD 실제 위험 좌우, 앞차 출발, 차선이탈, DOW는 후보 로그가 있어도 현재 정본 원칙상 실차 근거가 확정될 때까지 자동 음성 트리거로 승격하지 않는다.
