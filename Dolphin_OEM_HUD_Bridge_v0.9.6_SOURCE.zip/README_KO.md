# Dolphin OEM HUD Bridge v0.9.6 — 순정 TMAP 수신 경로 보완

차량: BYD Dolphin / DiLink Android 10 / 글로벌 2602 순정 BydAutoTMap. 외부 HUD: HUD Q.

## v0.9.6의 확인된 근거

- 사용자 업로드 실차 로그 2026-11-02: HUD BLE GATT FFF2 연결 및 설정 전송 성공, OEM AutoNavi 방송 0회, 안내 패킷 0회, 접근성 최종 NOT_ENABLED.
- 사용자 보유 펌웨어 2602 원본 `BydAutoTMap.apk`의 직접 정적 확인: `com.tmap.auto.byd`, exported `com.tmap.auto.byd.NaviService`, 내부 TMAP 내비/TBT UI 구성요소 존재.
- 기존 브리지는 `AUTONAVI_STANDARD_BROADCAST_SEND` 방송 수신 중심. 2602 순정 TMAP이 그 방송을 송출한다는 근거 없음.
- `NaviService`는 exported지만 별도의 안전한 읽기 전용 TBT getter/호출 계약을 검증하지 못함. 알 수 없는 OEM Binder transact를 보내지 않음.

## 실제 반영한 변경

1. 순정 `com.tmap.auto.byd` 패키지를 내비로 정확히 감지. 패키지 수동 입력 없이 자동 인식.
2. 접근성이 켜져 있을 때 TMAP 화면 이벤트 텍스트뿐 아니라 해당 패키지의 UI 노드/여러 창에서 거리·회전 지시를 수집. 다른 앱 내용은 수집하지 않음.
3. 이벤트가 발생하지 않아도 접근성 서비스가 연결돼 있으면 약 1.8초 간격으로 TMAP 노드를 읽는 폴백. 화면에서 식별 가능한 안내만 변환; 임의로 방향이나 거리를 생성하지 않음.
4. 방향 문자열(대각 진입 포함)을 기존 HUD Q 프로토콜로 변환. 같은 지시가 지속되면 15초 이내 중복 전송 방지.
5. 알림 리스너 접속 시 이미 올라와 있는 순정 내비 알림도 확인.
6. 안내 도착 시 브리지 서비스가 일시 중단됐다면 5초 이내 안내에 한해 서비스 재시작 시 전달 시도.
7. 화면·진단 ZIP에 접근성 실제 연결, 화면 탐색, 해석 성공, HUD 전송 접수 시도 단계를 구분해 표시.
8. 기존 HUD GATT, 부저·밝기, ADB 동의·권한 관리, 내비 앱 목록 선택은 유지.

## 정상 출력에 필요한 조건

- 차량의 순정 TMAP이 길안내 방향과 거리를 접근성 화면 또는 알림을 통해 실제로 노출해야 함.
- 접근성 서비스가 실제 활성화되어야 함. WRITE_SECURE_SETTINGS 권한만으로 접근성이 켜진 것은 아님.
- HUD Q FFF2 연결이 준비되어야 함.
- 이 소스만으로 순정 TMAP의 비공개 Binder 데이터 경로까지 읽을 수 있는 것으로 주장하지 않음.

## GitHub 업로드 (파일 두 개)

1. `Dolphin_OEM_HUD_Bridge_v0.9.6_SOURCE.zip`를 저장소 최상위에 그대로 올림.
2. `build-oem-hud-bridge-v0.9.6.yml`을 `.github/workflows/build-oem-hud-bridge.yml`로 업로드/교체.
3. GitHub Actions에서 `Build Dolphin OEM HUD Bridge v0.9.6 (ZIP + YML)` 실행.
4. 성공 시 `DolphinOemHudBridge_v0.9.6_vc15.apk` 산출물 사용.

기존 앱과 패키지명은 `com.dolphin.oemhud`로 동일하며 버전코드는 15. 다른 서명으로 서명된 APK는 일반 업데이트 설치되지 않을 수 있음.

**검증 경계:** 로컬 정적 검사와 안드로이드 모의 API Java 타입검사·BLE/TBT 시뮬레이션 성공은 실차에서 TBT 수신 및 HUD 화면 표시 성공을 의미하지 않음.


## v0.9.6 GitHub CI 복구
빌드 시 SOURCE.zip 안의 워크플로와 저장소 `.github/workflows/build-oem-hud-bridge.yml`을 정확히 비교하고, 두 파일의 버전이 일치해야 빌드를 시작합니다. 기존 순정 TMAP 입력·HUD 통신부를 변경하지 않았으며, 실제 차량 기능 성공을 의미하지 않습니다.
