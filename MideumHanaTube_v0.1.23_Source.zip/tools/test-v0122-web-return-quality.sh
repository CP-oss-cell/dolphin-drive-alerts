#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
p=Path('app/src/main/java/app/mideumhanatube/android')
v=(p/'VideoPlayerActivity.java').read_text()
m=(p/'MainActivity.java').read_text()
r=(p/'YouTubeStreamResolver.java').read_text()
b=Path('app/build.gradle').read_text()
y=Path('.github/workflows/MideumHanaTube_v0.1.23_Source.yml').read_text()
assert "versionName '0.1.23'" in b and 'versionCode 24' in b
assert 'MideumHanaTube_v0.1.23_Source.zip' in y
assert 'PIP_EXPAND_TO_WEB' in v
assert 'returnToWeb(true)' in v and 'returnToWeb(false)' in v
assert 'wasInPip' in v and 'onPictureInPictureModeChanged' in v
assert 'setAutoEnterEnabled(false)' in v
assert 'FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP' in v
assert 'EXTRA_NATIVE_VIDEO_RETURN_MS' in v and 'player.getCurrentPosition()' in v
assert 'setOnApplyWindowInsetsListener' in v and 'getSystemWindowInsetTop' in v
assert 'BACKGROUND_AUTO_WEB_RETURN' in m
assert 'requestNativeReturnPosition();' in m and 'nativePendingReturnUrl=url;' in m
assert 'NATIVE_VIDEO_SURFACE_RETAINED' in m
assert 'Intent reattach=new Intent(this,VideoPlayerActivity.class)' not in m
assert 'getWidth()<=1280 && v.getHeight()<=720' in r
assert '640 * 360' not in r and '854*480' not in r
assert 'video_split' in r
print('v0.1.22 PiP expand/web return, music auto-return, 720p preference, safe insets PASS')
PY
