#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
main=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
svc=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
diag=Path('app/src/main/java/app/mideumhanatube/android/PlaybackDiagnostics.java').read_text()
policy=Path('app/src/main/java/app/mideumhanatube/android/PlaybackStatePolicy.java').read_text()
assert '"웹 캐시 삭제"' in main and 'showCacheClearConfirmation()' in main
cache=main.split('private void showCacheClearConfirmation()')[1].split('private void injectCleaner()')[0]
assert 'webView.clearCache(true);' in cache
assert 'webView.reload()' not in cache
for s in ['removeAllCookies', 'deleteAllData', 'deleteDatabase', 'clearHistory', 'library.clear', 'stopBackgroundService()']:
 assert s not in cache, f'cache must not erase private data or playback: {s}'
assert '진단 ZIP 저장' in main and 'PlaybackDiagnostics.saveToDownloads(this)' in main
assert 'Intent.ACTION_CREATE_DOCUMENT' in main and 'REQUEST_DIAGNOSTIC_SAVE' in main
assert 'OutputStream out' in main and 'PlaybackDiagnostics.writeZip(this, out)' in main
assert 'PlaybackDiagnostics.nextSession(this)' in main and 'putExtra("trace_session", playbackTraceSession)' in main
for s in ['HANDOFF_ACCEPTED','PLAYER_PREPARING','ACTUAL_PLAYING','BUFFERING_TIMEOUT','PLAYER_ERROR','FGS_DENIED','NOTIFICATION_CONTROL']:
 assert s in svc,s
assert 'PlaybackStatePolicy.classify' in svc and 'PlaybackStatePolicy.keepForeground' in svc
assert 'handler.postDelayed(nativeBufferTimeout' in svc
assert 'onPlaybackStateChanged(int state)' in svc
assert 'onPlayWhenReadyChanged(boolean playWhenReady' in svc
assert 'if (nativePlayRequested) nativePlayer.play();' in svc
assert 'nativePlayer.setMediaItem(item)' in svc
assert 'MimeTypes.APPLICATION_M3U8' in svc
assert 'session.setPlaybackState' in svc
assert 'JSONObject data' in diag and 'play_when_ready' in diag and 'suppression' in diag
assert 'KEEP_LINES = 300' in diag and 'eventCount > KEEP_LINES' in diag
assert 'raw_urls_cookies_titles_recorded' in diag
for s in ['getCookies()', 'getCookie(', 'getTitle()', 'put("url"', 'put("title"', 'put("search"']:
 assert s not in diag,s
assert 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in diag
assert 'Environment.DIRECTORY_DOWNLOADS' in diag
assert 'ZIP' not in policy and 'BUFFERING' in policy
for s in ['HTTP_403','HTTP_401','EXTRACT_ERROR','BUFFERING_TIMEOUT','FGS_DENIED']:
 assert s in diag,s
assert "versionName '0.1.23'" in Path('app/build.gradle').read_text()
print('v0.1.13 auto-diagnosis, cache safety, player state and diagnostics export: 44+ assertions PASS')
PY
