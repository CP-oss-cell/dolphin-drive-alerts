#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
javac -encoding UTF-8 -d "$TMP_DIR" \
  app/src/main/java/app/mideumhanatube/android/PlaybackQueue.java tools/TestPlaybackQueue.java
java -cp "$TMP_DIR" app.mideumhanatube.android.TestPlaybackQueue
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
p=Path('app/src/main/java/app/mideumhanatube/android')
main=(p/'MainActivity.java').read_text()
lib=(p/'LibraryStore.java').read_text()
svc=(p/'BackgroundAudioService.java').read_text()
media=(p/'MediaButtonResumeReceiver.java').read_text()
js=Path('app/src/main/assets/cleaner.js').read_text()
manifest=ET.parse('app/src/main/AndroidManifest.xml').getroot()
checks={
 'pip icon native custom view':'new PipIconButton(this)' in main and 'toolbarRow.addView(pipActionButton' in main,
 'pip left of microphone':main.index('toolbarRow.addView(pipActionButton')<main.index('toolbarRow.addView(separateVoiceButton'),
 'redundant menu removed':all('addAction(actions, "'+x+'"' not in main for x in ['작은 화면','직접 재생','음악 설정','음악목록']),
 'single settings entry':'addAction(actions, "설정"' in main and 'showPlaybackSettings()' in main,
 'first run permission wizard':'KEY_FIRST_RUN_PERMISSIONS' in main and 'beginPermissionSequence()' in main and 'requestFirstMicPermission()' in main,
 'pip optional settings':'android.settings.PICTURE_IN_PICTURE_SETTINGS' in main,
 'music and watch later separate':'private static final String MUSIC_KEY' in lib and 'library.saveMusicTrack(' in main and 'library.addBookmark(' in main,
 'music folders and order':'createMusicPlaylist' in lib and 'renameMusicPlaylist' in lib and 'Collections.swap(items,index,target)' in main,
 'multi select queue':'.setMultiChoiceItems(labels,picks' in main and 'startQueue(selected,0)' in main,
 'playlist from history':'List<LibraryStore.Entry> history = library.history()' in main and 'putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS,queue.urls)' in main and 'collectPlaybackQueue(url)' in main,
 'best effort related suggestions':'collectRelatedTracks()' in main and 'visibleRelatedTracks' in main,
 'backup user chosen':'Intent.ACTION_CREATE_DOCUMENT' in main and 'REQUEST_LIBRARY_EXPORT' in main,
 'restore user chosen':'Intent.ACTION_OPEN_DOCUMENT' in main and 'REQUEST_LIBRARY_IMPORT' in main and 'library.importLibrary(' in main,
 'no cookies in backup':'CookieManager.getInstance().getCookie' not in main.split('if (requestCode == REQUEST_LIBRARY_EXPORT')[1].split('if (requestCode == REQUEST_DIAGNOSTIC_SAVE)')[0],
 'save media resume':'saveLastSession()' in svc and 'resumeLastSession()' in svc and 'RESUME_PREF' in svc,
 'headset audio pause':'ACTION_AUDIO_BECOMING_NOISY' in svc and 'nativePlayer.pause()' in svc,
 'sleep timer':'ACTION_SLEEP_TIMER' in svc and 'showSleepTimer()' in main,
 'hardware media buttons':'KEYCODE_MEDIA_PLAY' in media and 'android.intent.action.MEDIA_BUTTON' in ET.tostring(manifest,encoding='unicode'),
 'native session uses queue':'.setAction(ACTION_NATIVE_START)' in svc and 'playbackQueue.setTracks' in svc and 'onSkipToPrevious' in svc and 'onSkipToNext' in svc,
 'notification repeat shuffle':'.addAction(repeat)' in svc and '.addAction(shuffle)' in svc,
 'autopip failure fallback':'(!autoPip || !canAutoPip)' in main,
 'ad detection separated':'MHT_AD_DETECTED_0120' in js and 'MHT_AD_SKIP_CLICKED_0120' in js and 'AD_SKIP_ATTEMPT' in main,
 'version bump':"versionName '0.1.23'" in Path('app/build.gradle').read_text() and 'versionCode 24' in Path('app/build.gradle').read_text(),
 'workflow no manual secrets':'assembleDebug' in Path('.github/workflows/MideumHanaTube_v0.1.23_Source.yml').read_text(),
}
for name,ok in checks.items():
 if not ok: raise AssertionError('FAIL: '+name)
print('v0.1.20 new integration assertions:',len(checks),'PASS')
PY
node --check app/src/main/assets/cleaner.js
