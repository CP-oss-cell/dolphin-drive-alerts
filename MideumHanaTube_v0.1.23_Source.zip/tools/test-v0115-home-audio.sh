#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY_TEST'
from pathlib import Path
s=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
a=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
js=Path('app/src/main/assets/cleaner.js').read_text()
diag=Path('app/src/main/java/app/mideumhanatube/android/PlaybackDiagnostics.java').read_text()
flow=Path('.github/workflows/MideumHanaTube_v0.1.23_Source.yml').read_text()
seg=s.split('@Override protected void onUserLeaveHint()')[1].split('@Override protected void onResume()')[0]
assert 'boolean canAutoPip = autoPip && lastKnownVideoPlaying' in seg
assert 'if (canAutoPip)' in seg and 'openNativeVideo(true);' in seg
assert 'boolean startAudio = backgroundAudio && (!autoPip || !canAutoPip)' in seg
assert 'if (startAudio)' in seg and 'beginNativeHandoff();' in seg
assert 'HOME_NATIVE_PIP_REQUESTED' in seg and 'HOME_NATIVE_PRIORITY' in seg
assert 'enterNativePip' not in seg
pause=s.split('@Override protected void onPause()')[1].split('@Override protected void onDestroy()')[0]
assert 'backgroundAudio && wasPlayingImmediatelyBeforeLeaving()' in pause
assert 'PAUSE_NATIVE_FALLBACK' in pause
assert 'ACTION_WEB_PLAY' not in s and 'ACTION_WEB_PAUSE' not in s
assert 'ACTION_WEB_PLAY' not in a and 'ACTION_WEB_PAUSE' not in a
assert 'NOTIFICATION_NATIVE_START' in a and 'beginNativeAudio(nativeIntent);' in a
assert 'NOTIFICATION_WEB_FALLBACK' not in a
assert 'lastWebVideoUrl = visiblePageUrl;' in a
assert 'EXTRA_POSITION_MS, lastKnownPositionMs' in s
assert 'HANDOFF_DUPLICATE_SKIPPED' in a
assert 'ytm-ad-slot-renderer' in js and 'ytp-ad-skip-button' in js
assert 'querySelectorAll(css)' in js and 'window.__MHT_SKIP_TIMER' in js
assert 'video.currentTime' not in js and '.playbackRate' not in js, 'ad filter must not seek or accelerate regular content'
assert 'MHT_KEYSTORE_BASE64' not in flow and 'MHT_CERT_SHA256' not in flow
assert 'assembleDebug' in flow and '"$TOOL" verify' in flow
assert 'assembleRelease' not in flow
assert 'app-debug.apk' in flow and 'MideumHanaTube_v0.1.23_Debug.apk' in flow
assert 'getPackageInfo(c.getPackageName(), 0).versionName' in diag and 'summary.put("app_version", "0.1.13")' not in diag
print('v0.1.15: 20+ home/PIP/audio/ads/automatic-debug-signing checks PASS')
PY_TEST
