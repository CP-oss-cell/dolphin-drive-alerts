package app.mideumhanatube.android;

/** Timeline and control policy shared between the web screen and the native player.
 * Does not hold stream URLs, cookies, tokens or Android UI instances. */
public final class PlaybackHandoff {
    private PlaybackHandoff() { }
    public static int normalizedPipActionMode(int choice) { return choice == 1 ? 1 : 0; }
    public static boolean withinSeekTolerance(long requestedMs, long actualMs) {
        if (requestedMs < 0L || actualMs < 0L) return false;
        // Web seek may land a few seconds around the nearest buffered keyframe;
        // do not mistake a position from a different video for a valid return.
        long toleranceMs = 3500L;
        return actualMs >= Math.max(0L, requestedMs - toleranceMs)
                && actualMs <= requestedMs + toleranceMs;
    }
}
