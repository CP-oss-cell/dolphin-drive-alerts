# 믿음하나 브라우저 v2.0.1 빌드 오류 수정

- 받은 증거: `2.zip`, GitHub Actions 로그 2026-11-04 14:09 UTC
- 실제 실패: `Build signed MideumHanaBrowser release APK` 작업에서 `MHB_KEYSTORE_BASE64`, `MHB_KEYSTORE_PASSWORD` 빈 값으로 exit code 1
- APK 컴파일 이전에 중단됨. 이전 단계 SDK, ZIP 추출 및 모든 오프라인 회귀 검사는 성공.
- 수정: Secret 2개 없음 → Debug APK 자동 빌드 / Secret 2개 모두 있음 → 사용자 고정 서명 Release APK / 1개만 있음 → 안내 후 중단.
- 신규 v2.0.1 versionCode=2, packageId=com.mideumhana.browser.
- Debug APK는 서명 유지가 보장되지 않으므로 후속 업데이트의 기준으로 삼으면 안 됨. Release APK부터 설치 권장.
- 실제 GitHub Actions의 Android APK 컴파일과 휴대전화 설치는 여기서 수행하지 못함.
