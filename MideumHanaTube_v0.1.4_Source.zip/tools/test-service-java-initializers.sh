#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
python3 - "$ROOT" "$TMP_DIR" <<'PY'
import pathlib,re,sys
root=pathlib.Path(sys.argv[1]); dst=pathlib.Path(sys.argv[2])
s=(root/'app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text(encoding='utf-8')
playing=re.search(r'(?m)^\s*private\s+boolean\s+playing\s*;',s)
callback=re.search(r'(?ms)^\s*private\s+final\s+Runnable\s+stopWhenPaused\s*=\s*\(\)\s*->\s*\{.*?^\s*\};',s)
assert playing and callback,'Expected playback state and pause-timeout callback are missing'
assert playing.start()<callback.start(),'Playback state is declared after the callback: illegal forward reference'
# Compile an exact excerpt of the field declarations to guard against the original
# Java compilation failure even on CI hosts that do not have the Android SDK loaded.
fields=sorted([(playing.start(),playing.group().strip()),(callback.start(),callback.group().strip())])
probe='public class ServiceFieldProbe {\n'+'\n'.join(x[1] for x in fields)+'\n void stopSelf() {}\n}\n'
(dst/'ServiceFieldProbe.java').write_text(probe,encoding='utf-8')
PY
javac --release 17 -encoding UTF-8 -d "$TMP_DIR" "$TMP_DIR/ServiceFieldProbe.java"
echo 'Service Java initializer regression: PASS'
