// Verify that the exact Java source string for WebView.evaluateJavascript is valid JS.
const fs = require('fs');
const source = fs.readFileSync('app/src/main/java/app/mideumhanatube/android/MainActivity.java','utf8');
const beginning = source.indexOf('private static final String EXTRACT_PAGE_TITLE_JS =');
const end = source.indexOf('\n\n    private interface TitleResult', beginning);
if(beginning < 0 || end < 0) throw Error('EXTRACT_PAGE_TITLE_JS not found');
const literalBlock=source.slice(beginning,end);
const pieces = [...literalBlock.matchAll(/"(?:\\.|[^"\\])*"/g)].map(m=>JSON.parse(m[0]));
const script=pieces.join('');
const run = new Function('document','location','return '+script+';');
let cases=0;
function test(name, path, selectorValue, pageTitle, metaTitle, expected){
 const document = {title:pageTitle,querySelector:(selector)=>{
   if(selector==='meta[property="og:title"]' && metaTitle) return {content:metaTitle};
   if(selector === selectorValue[0]) return {textContent:selectorValue[1]};
   return null;
 }};
 const location={pathname:path,search:'',href:'https://m.youtube.com'+path};
 const parsed=JSON.parse(run(document,location));
 if(parsed.title!==expected || parsed.url!==location.href)
   throw Error(name+': '+JSON.stringify(parsed));
 cases++;
}
test('watch mobile','/watch',['ytm-watch-metadata h1','내가 좋아하는 음악'],'YouTube','', '내가 좋아하는 음악');
test('watch desktop','/watch',['ytd-watch-metadata h1','목표 영상'],'YouTube','', '목표 영상');
test('shorts','/shorts/abcd',['.ytp-title-link','쇼츠 제목'],'YouTube','','쇼츠 제목');
test('playlist','/playlist',['ytd-playlist-header-renderer h1','추천 재생 목록'],'YouTube','','추천 재생 목록');
test('channel','/@mychannel',['ytm-channel-header-renderer h1','내 채널'],'YouTube','','내 채널');
test('metadata','/watch',['not-matched','ignored'],'YouTube','메타데이터 제목','메타데이터 제목');
test('fallback','/watch',['not-matched','ignored'],'YouTube','','YouTube');
console.log('Embedded metadata JavaScript tests PASS',cases);
