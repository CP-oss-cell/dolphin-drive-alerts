import app.mideumhanatube.android.BookmarkTitleResolver;

public class TestBookmarkTitle {
    private static int tests;
    private static void eq(String label, String actual, String expected) {
        tests++;
        if (!actual.equals(expected)) throw new AssertionError(label + " expected '" + expected + "' but got '" + actual + "'");
    }
    private static void yes(String label, boolean value) {
        tests++;
        if (!value) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        eq("normal video metadata", BookmarkTitleResolver.resolve("내가 좋아하는 노래", "YouTube", "https://m.youtube.com/watch?v=xyz"), "내가 좋아하는 노래");
        eq("webview full title", BookmarkTitleResolver.resolve("YouTube", "새 노래 - YouTube", "https://m.youtube.com/watch?v=xyz"), "새 노래");
        eq("non generic DOM", BookmarkTitleResolver.resolve("내 음악 - YouTube", "YouTube", "https://m.youtube.com/watch?v=xyz"), "내 음악");
        eq("different video links different labels", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/watch?v=aaa111"), "영상 · aaa111");
        eq("watch fallback 2", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/watch?v=bbb222"), "영상 · bbb222");
        eq("shorts fallback", BookmarkTitleResolver.resolve(null, "YouTube", "https://www.youtube.com/shorts/short34"), "Shorts · short34");
        eq("playlist fallback", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/playlist?list=PLmusic"), "재생목록 · PLmusic");
        eq("search fallback", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/results?search_query=%ED%95%9C%EA%B5%AD+%EB%85%B8%EB%9E%98"), "검색 · 한국 노래");
        eq("channel fallback", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/@mychannel/videos"), "@mychannel");
        eq("channel id fallback", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://www.youtube.com/channel/UC123abc"), "채널 · UC123abc");
        eq("home fallback", BookmarkTitleResolver.resolve("YouTube", "YouTube", "https://m.youtube.com/"), "유튜브 홈");
        eq("title priority", BookmarkTitleResolver.resolve("정확한 영상명", "이전 영상명 - YouTube", "https://m.youtube.com/watch?v=xyz"), "정확한 영상명");
        eq("trailing suffix", BookmarkTitleResolver.resolve("영상명 | YouTube", "YouTube", "https://m.youtube.com/watch?v=xyz"), "영상명");
        yes("generic original", BookmarkTitleResolver.isGeneric("YouTube"));
        yes("generic localized", BookmarkTitleResolver.isGeneric("유튜브"));
        yes("generic app", BookmarkTitleResolver.isGeneric("믿음하나튜브"));
        yes("not generic real video title", !BookmarkTitleResolver.isGeneric("음악과 추억"));
        yes("fallback placeholder", BookmarkTitleResolver.isFallback("영상 · xyz"));
        yes("real heading not fallback", !BookmarkTitleResolver.isFallback("즐거운 동영상"));
        eq("max title", BookmarkTitleResolver.resolve("z".repeat(200), "YouTube", "https://m.youtube.com/watch?v=x").length() + "", "110");
        System.out.println("Bookmark title tests PASS " + tests);
    }
}
