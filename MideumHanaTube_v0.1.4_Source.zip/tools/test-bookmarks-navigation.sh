#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf /tmp/mht-bookmark-test
mkdir -p /tmp/mht-bookmark-test
javac -encoding UTF-8 -d /tmp/mht-bookmark-test \
  app/src/main/java/app/mideumhanatube/android/BookmarkTitleResolver.java \
  tools/TestBookmarkTitle.java
java -cp /tmp/mht-bookmark-test TestBookmarkTitle
node tools/test-page-title.js
MAIN=app/src/main/java/app/mideumhanatube/android/MainActivity.java
MANIFEST=app/src/main/AndroidManifest.xml
grep -q 'registerOnBackInvokedCallback' "$MAIN"
grep -q 'unregisterOnBackInvokedCallback' "$MAIN"
grep -q 'webView.canGoBack()' "$MAIN"
grep -q 'webView.goBack()' "$MAIN"
grep -q 'android:enableOnBackInvokedCallback="true"' "$MANIFEST"
grep -q 'requestPageTitle(url, 0' "$MAIN"
grep -q 'repairGenericTitles' "$MAIN"
grep -q 'renameBookmark' "$MAIN"
echo 'Navigation / bookmark structural checks PASS'
