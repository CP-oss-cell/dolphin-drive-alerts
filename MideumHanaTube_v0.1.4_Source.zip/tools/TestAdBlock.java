package app.mideumhanatube.android;

public final class TestAdBlock {
    private static int passes = 0;
    private static void check(String message, String url, boolean mainFrame, boolean expected) {
        boolean actual = AdBlockEngine.shouldBlock(url, mainFrame);
        if (actual != expected) throw new AssertionError(message + ": expected " + expected + " got " + actual);
        passes++;
    }
    public static void main(String[] args) {
        check("third-party ads", "https://googleads.g.doubleclick.net/pagead/id", false, true);
        check("sponsor network", "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", false, true);
        check("nested adservice", "https://adservice.google.com/pagead/conversion", false, true);
        check("same-origin ad stats", "https://m.youtube.com/api/stats/ads?x=1", false, true);
        check("same-origin pagead", "https://www.youtube.com/pagead/adview", false, true);
        check("normal YouTube", "https://m.youtube.com/watch?v=abc", false, false);
        check("video CDN must not be blocked", "https://r3---sn-a5mekn7d.googlevideo.com/videoplayback?id=123", false, false);
        check("actual YouTube player API", "https://www.youtube.com/youtubei/v1/player", false, false);
        check("main navigation must pass", "https://googleads.g.doubleclick.net/test", true, false);
        check("domain-suffix spoof protection", "https://googleads.g.doubleclick.net.evil.example/file", false, false);
        check("YT host spoof protection", "https://m.youtube.com.evil.example/pagead/x", false, false);
        check("other media", "https://i.ytimg.com/vi/abc/hqdefault.jpg", false, false);
        check("null", null, false, false);
        check("bad scheme", "javascript://doubleclick.net/?x", false, false);
        check("malformed url", "totally-not-a-url", false, false);
        System.out.println("PASS: " + passes + " ad filter regression cases");
    }
}
