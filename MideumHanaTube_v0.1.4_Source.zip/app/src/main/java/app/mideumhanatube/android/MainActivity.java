package app.mideumhanatube.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MideumHanaTube v0.1: standalone Android web-video viewer with a best-effort ad filter.
 * The application is NOT affiliated with YouTube and does not guarantee zero ads.
 * No privileged permissions, VPN, root, Google credentials or external account servers.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://m.youtube.com/";
    private static final String PREF = "mideumhanatube_settings";
    private static final String KEY_FILTER = "filter_hosts";
    private static final String KEY_HIDE = "hide_promotions";
    private static final String KEY_SKIP = "auto_skip";
    private static final String KEY_BACKGROUND = "background_audio";
    private static final String KEY_AUTO_PIP = "auto_pip_on_home";
    private static final String KEY_NOTIFICATION_ASKED = "notification_permission_asked";
    private static final int COLOR_BG = Color.rgb(15, 23, 35);
    private static final int COLOR_PANEL = Color.rgb(25, 36, 52);
    private static final int COLOR_ACCENT = Color.rgb(96, 165, 250);
    private static final int COLOR_WHITE = Color.rgb(237, 242, 249);

    private SharedPreferences settings;
    private LibraryStore library;
    private FrameLayout root;
    private LinearLayout page;
    private LinearLayout searchBar;
    private HorizontalScrollView toolsScroll;
    private TextView status;
    private EditText searchInput;
    private WebView webView;
    private FrameLayout browserContainer;
    private FrameLayout fullscreenContainer;
    private ProgressBar loading;
    private Button bookmarkButton;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private int priorOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private boolean filterOn;
    private boolean hidePromotions;
    private boolean autoSkip;
    private boolean backgroundAudio;
    private boolean autoPip;
    private boolean activityBackgrounded;
    private boolean lastKnownPlaying;
    private boolean serviceWasStarted;
    private boolean playWasActiveOnLeave;
    private boolean attemptedResumeOnLeave;
    private String lastMediaTitle = "믿음하나튜브";
    private boolean audioReceiverRegistered;
    private OnBackInvokedCallback systemBackCallback;
    private long lastBackAtRoot;
    private static final long BACK_EXIT_WINDOW_MS = 2000L;
    private final Runnable refreshSavedTitle = () -> {
        if (webView != null && LibraryStore.isYoutubeUrl(webView.getUrl())) {
            requestPageTitle(webView.getUrl(), 0, null);
        }
    };
    private final Handler audioHandler = new Handler(Looper.getMainLooper());
    private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BackgroundAudioService.ACTION_CONTROL.equals(intent.getAction())) return;
            String control = intent.getStringExtra(BackgroundAudioService.EXTRA_CONTROL);
            if (BackgroundAudioService.ACTION_PLAY.equals(control)) {
                playWasActiveOnLeave = true;
                controlWebPlayer(true);
            } else if (BackgroundAudioService.ACTION_PAUSE.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
            } else if (BackgroundAudioService.ACTION_STOP.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
                stopBackgroundService();
            }
        }
    };
    private final Runnable playbackPoll = new Runnable() {
        @Override public void run() {
            if (webView != null) {
                String url = webView.getUrl();
                if (LibraryStore.isYoutubeUrl(url)) {
                    webView.evaluateJavascript(PLAYBACK_PROBE_JS, MainActivity.this::readWebPlayerState);
                } else if (lastKnownPlaying) {
                    reportPlayerState(false, lastMediaTitle);
                }
            }
            audioHandler.postDelayed(this, 1200);
        }
    };
    // Poll the HTML5 media element without exposing a JavascriptInterface to untrusted frames.
    private static final String PLAYBACK_PROBE_JS = "(function(){var a=document.querySelectorAll('video'),v=null;" +
            "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
            "if(!v&&a.length)v=a[0];" +
            "return JSON.stringify({playing:!!(v&&!v.paused&&!v.ended&&v.readyState>0&&!v.muted&&v.volume>0)," +
            "hasVideo:!!v,ended:!!(v&&v.ended),title:document.title||'믿음하나튜브'});})()";
    private final AtomicInteger blockedCount = new AtomicInteger();
    private String cleanerJavaScript = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences(PREF, MODE_PRIVATE);
        library = new LibraryStore(this);
        filterOn = settings.getBoolean(KEY_FILTER, true);
        hidePromotions = settings.getBoolean(KEY_HIDE, true);
        autoSkip = settings.getBoolean(KEY_SKIP, true);
        backgroundAudio = settings.getBoolean(KEY_BACKGROUND, true);
        autoPip = settings.getBoolean(KEY_AUTO_PIP, false);
        registerAudioReceiver();
        try { cleanerJavaScript = loadAsset("cleaner.js"); }
        catch (Exception e) { cleanerJavaScript = ""; }
        setWindowColors();
        buildUi();
        buildBrowser();
        registerSystemBack();
        if (state != null && state.getBundle("web_state") != null) {
            webView.restoreState(state.getBundle("web_state"));
        } else {
            navigateInitial(getIntent());
        }
        audioHandler.postDelayed(playbackPoll, 500);
        if (!settings.getBoolean("intro_seen", false)) showIntro();
    }

    private void setWindowColors() {
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(10), dp(5), dp(10), dp(5));
        searchBar.setBackgroundColor(COLOR_BG);
        page.addView(searchBar, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView brand = new TextView(this);
        brand.setText("▶");
        brand.setTextColor(COLOR_ACCENT);
        brand.setTextSize(25);
        brand.setGravity(Gravity.CENTER);
        brand.setContentDescription("믿음하나튜브");
        searchBar.addView(brand, new LinearLayout.LayoutParams(dp(35), -1));

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(COLOR_WHITE);
        searchInput.setHintTextColor(Color.rgb(158, 176, 197));
        searchInput.setHint("유튜브 검색 또는 링크 입력");
        searchInput.setTextSize(15);
        searchInput.setPadding(dp(12), 0, dp(12), 0);
        searchInput.setBackgroundColor(COLOR_PANEL);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(43), 1f);
        searchBar.addView(searchInput, inputParams);
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                search();
                return true;
            }
            return false;
        });
        Button searchButton = toolbarButton("검색", "검색 실행", v -> search());
        searchButton.setTextColor(COLOR_ACCENT);
        searchBar.addView(searchButton, new LinearLayout.LayoutParams(dp(60), dp(44)));

        toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setBackgroundColor(COLOR_PANEL);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(6), 0, dp(6), 0);
        toolsScroll.addView(actions, new HorizontalScrollView.LayoutParams(-2, dp(45)));
        page.addView(toolsScroll, new LinearLayout.LayoutParams(-1, dp(45)));

        addAction(actions, "◀", "뒤로", v -> back());
        addAction(actions, "▶", "앞으로", v -> { if (webView.canGoForward()) webView.goForward(); });
        addAction(actions, "⌂", "홈", v -> webView.loadUrl(HOME));
        addAction(actions, "↻", "새로고침", v -> webView.reload());
        bookmarkButton = addAction(actions, "☆", "즐겨찾기 추가 또는 제거", v -> toggleBookmark());
        addAction(actions, "즐겨찾기", "즐겨찾기 목록", v -> showEntries(false));
        addAction(actions, "기록", "시청 기록", v -> showEntries(true));
        addAction(actions, "작은 화면", "PIP 작은 화면", v -> enterPip());
        addAction(actions, "음악 설정", "홈 버튼 이후 백그라운드 음악 재생 설정", v -> showAudioSettings());
        addAction(actions, "설정", "필터와 개인 정보 설정", v -> showSettings());

        LinearLayout strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(12), 0, dp(10), 0);
        strip.setBackgroundColor(COLOR_BG);
        page.addView(strip, new LinearLayout.LayoutParams(-1, dp(26)));
        status = new TextView(this);
        status.setTextColor(Color.rgb(160, 178, 195));
        status.setTextSize(11);
        status.setSingleLine(true);
        strip.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_ACCENT));
        strip.addView(loading, new LinearLayout.LayoutParams(dp(65), dp(4)));

        browserContainer = new FrameLayout(this);
        page.addView(browserContainer, new LinearLayout.LayoutParams(-1, 0, 1f));
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets area = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(area.left, area.top, area.right, area.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
        updateStatus();
    }

    private Button addAction(LinearLayout container, String label, String description, View.OnClickListener action) {
        Button btn = toolbarButton(label, description, action);
        container.addView(btn, new LinearLayout.LayoutParams(-2, dp(44)));
        return btn;
    }

    private Button toolbarButton(String label, String description, View.OnClickListener action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(COLOR_WHITE);
        btn.setTextSize(13);
        btn.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        btn.setPadding(dp(8), 0, dp(8), 0);
        btn.setMinWidth(0);
        btn.setMinimumWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumHeight(0);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(COLOR_PANEL));
        btn.setContentDescription(description);
        btn.setOnClickListener(action);
        return btn;
    }

    private void buildBrowser() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browserContainer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Notification Play and one-shot background recovery are not DOM user gestures.
        // The app only attempts recovery after an already-playing video was user-started.
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (filterOn && AdBlockEngine.shouldBlock(request.getUrl().toString(), request.isForMainFrame())) {
                    int count = blockedCount.incrementAndGet();
                    if (count <= 10 || count % 10 == 0) runOnUiThread(MainActivity.this::updateStatus);
                    WebResourceResponse empty = new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                    empty.setStatusCodeAndReasonPhrase(204, "No Content");
                    return empty;
                }
                return null;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if (isInternal(url)) return false;
                if ("https".equalsIgnoreCase(url.getScheme()) || "http".equalsIgnoreCase(url.getScheme())) {
                    openExternal(url);
                } else {
                    toast("외부 앱으로 연결되는 링크는 지원하지 않습니다.");
                }
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (lastKnownPlaying) reportPlayerState(false, lastMediaTitle);
                loading.setVisibility(View.VISIBLE);
                loading.setProgress(5);
                updateStatus();
            }

            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
                if (LibraryStore.isYoutubeUrl(url)) {
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                    injectCleaner();
                }
                updateBookmark();
                scheduleSavedTitleRefresh();
                updateStatus();
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                super.doUpdateVisitedHistory(view, url, isReload);
                if (!isReload && LibraryStore.isYoutubeUrl(url))
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                updateBookmark();
                scheduleSavedTitleRefresh();
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loading.setVisibility(View.GONE);
                    toast("페이지 연결 실패: 인터넷 상태와 Android WebView를 확인하세요.");
                }
            }

            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view == webView) {
                    browserContainer.removeView(view);
                    view.destroy();
                    webView = null;
                    toast("웹 엔진이 종료되어 화면을 다시 엽니다.");
                    recreate();
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loading.setProgress(progress);
                loading.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (LibraryStore.isYoutubeUrl(view.getUrl())) {
                    library.addHistory(BookmarkTitleResolver.resolve(title, null, view.getUrl()), view.getUrl());
                    scheduleSavedTitleRefresh();
                }
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCallback = callback;
                priorOrientation = getRequestedOrientation();
                page.setVisibility(View.GONE);
                fullscreenContainer.removeAllViews();
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenContainer.setVisibility(View.VISIBLE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        View.SYSTEM_UI_FLAG_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() { hideCustomView(); }
        });
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(priorOrientation);
        page.setVisibility(isInPictureInPictureMode() ? View.GONE : View.VISIBLE);
        if (root != null) root.requestApplyInsets();
    }

    private static boolean isInternal(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                || AdBlockEngine.isHostOrSubdomain(host, "youtu.be")
                || AdBlockEngine.isHostOrSubdomain(host, "youtube-nocookie.com");
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException ex) { toast("연결할 브라우저가 없습니다."); }
    }

    private void navigateInitial(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        webView.loadUrl(uri != null && isInternal(uri) ? uri.toString() : HOME);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) navigateInitial(intent);
    }

    private void search() {
        String query = searchInput.getText().toString().trim();
        if (query.isEmpty()) { webView.loadUrl(HOME); return; }
        hideKeyboard();
        Uri target = Uri.parse(query);
        if (query.startsWith("https://") && isInternal(target)) {
            webView.loadUrl(query);
        } else {
            webView.loadUrl("https://m.youtube.com/results?search_query=" + Uri.encode(query));
        }
        searchInput.clearFocus();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
    }

    /** The WebView title often stays "YouTube" during single-page navigation.
     * Resolve the actual video/playlist/channel heading from the live page first. */
    private void toggleBookmark() {
        if (webView == null) return;
        String url = webView.getUrl();
        if (!LibraryStore.isYoutubeUrl(url)) {
            toast("유튜브 페이지에서만 저장할 수 있습니다.");
            return;
        }
        if (library.isBookmarked(url)) {
            library.removeBookmark(url);
            toast("즐겨찾기에서 제거했습니다.");
            updateBookmark();
            return;
        }
        requestPageTitle(url, 0, resolvedTitle -> {
            if (webView == null || !url.equals(webView.getUrl())) {
                toast("페이지가 변경됐습니다. 다시 저장해 주세요.");
                return;
            }
            library.addBookmark(resolvedTitle, url);
            toast("즐겨찾기 저장: " + resolvedTitle);
            updateBookmark();
        });
    }

    // The JS is a fixed constant; untrusted page text is returned only as data.
    private static final String EXTRACT_PAGE_TITLE_JS =
            "(function(){" +
            "var path=location.pathname||'',q=location.search||'';" +
            "var watch=path.indexOf('/watch')===0||path.indexOf('/shorts/')===0;" +
            "var playlist=path.indexOf('/playlist')===0;" +
            "var selectors=watch?['ytm-watch-metadata h1','ytm-slim-video-metadata-renderer h1'," +
            "'h1.slim-video-metadata-title','ytd-watch-metadata h1 yt-formatted-string'," +
            "'ytd-watch-metadata h1','#title h1','.ytp-title-link']:" +
            "playlist?['ytd-playlist-header-renderer h1','ytm-playlist-header h1'," +
            "'ytm-playlist-header-renderer h1']:" +
            "['ytm-channel-header-renderer h1','ytd-channel-name yt-formatted-string'];" +
            "var title='';" +
            "for(var i=0;i<selectors.length;i++){var el=document.querySelector(selectors[i]);" +
            "if(el&&el.textContent&&el.textContent.trim()){title=el.textContent.trim();break;}}" +
            "if(!title){var meta=document.querySelector('meta[property=\"og:title\"]');" +
            "if(meta)title=meta.content||'';}" +
            "if(!title)title=document.title||'';" +
            "return JSON.stringify({url:location.href,title:title,pageTitle:document.title||''});" +
            "})()";

    private interface TitleResult { void resolved(String title); }

    private void requestPageTitle(String expectedUrl, int retry, TitleResult callback) {
        if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
        final String webTitle = webView.getTitle();
        webView.evaluateJavascript(EXTRACT_PAGE_TITLE_JS, json -> {
            if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
            String metadata = null;
            String documentTitle = webTitle;
            try {
                Object unwrapped = new JSONTokener(json).nextValue();
                if (unwrapped instanceof String) {
                    JSONObject parsed = new JSONObject((String) unwrapped);
                    if (!expectedUrl.equals(parsed.optString("url", ""))) return;
                    metadata = parsed.optString("title", "");
                    documentTitle = parsed.optString("pageTitle", webTitle);
                }
            } catch (Exception ignored) { }
            String resolved = BookmarkTitleResolver.resolve(metadata, documentTitle, expectedUrl);
            if (BookmarkTitleResolver.isFallback(resolved) && retry < 2) {
                audioHandler.postDelayed(() -> requestPageTitle(expectedUrl, retry + 1, callback),
                        retry == 0 ? 450 : 900);
                return;
            }
            library.repairGenericTitles(expectedUrl, resolved);
            if (callback != null) callback.resolved(resolved);
        });
    }

    private void scheduleSavedTitleRefresh() {
        audioHandler.removeCallbacks(refreshSavedTitle);
        audioHandler.postDelayed(refreshSavedTitle, 650);
    }

    private void updateBookmark() {
        if (bookmarkButton != null && webView != null)
            bookmarkButton.setText(library.isBookmarked(webView.getUrl()) ? "★" : "☆");
    }

    private void showEntries(boolean history) {
        List<LibraryStore.Entry> entries = history ? library.history() : library.bookmarks();
        String title = history ? "최근 방문 기록" : "즐겨찾기";
        if (entries.isEmpty()) { toast(title + "이 없습니다."); return; }
        String[] titles = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) titles[i] = entries.get(i).title;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(history ? title : "즐겨찾기 · 길게 눌러 이름 변경")
                .setItems(titles, (d, index) -> webView.loadUrl(entries.get(index).url))
                .setNegativeButton("닫기", null)
                .setNeutralButton("전체 삭제", (d, which) -> new AlertDialog.Builder(this)
                        .setTitle(title + " 전체 삭제")
                        .setMessage("기기에 저장된 항목을 모두 삭제할까요?")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제", (confirmation, w) -> {
                            if (history) library.clearHistory(); else library.clearBookmarks();
                            updateBookmark();
                            toast("삭제했습니다.");
                        }).show())
                .create();
        dialog.setOnShowListener(ignored -> {
            if (history) return;
            dialog.getListView().setOnItemLongClickListener((parent, view, position, id) -> {
                dialog.dismiss();
                renameBookmark(entries.get(position));
                return true;
            });
        });
        dialog.show();
    }

    private void renameBookmark(LibraryStore.Entry entry) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(entry.title);
        input.selectAll();
        int pad = dp(18);
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(pad, dp(8), pad, dp(8));
        frame.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 이름 변경")
                .setView(frame)
                .setNegativeButton("취소", null)
                .setNeutralButton("삭제", (d, which) -> {
                    library.removeBookmark(entry.url);
                    updateBookmark();
                    toast("즐겨찾기를 삭제했습니다.");
                })
                .setPositiveButton("저장", (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) { toast("이름을 입력해 주세요."); return; }
                    library.renameBookmark(entry.url, name);
                    toast("이름을 변경했습니다.");
                })
                .show();
    }

    private void showSettings() {
        String[] labels = {
                "외부 광고 서버 요청 차단 (권장)",
                "광고성 화면 요소 숨기기 (권장)",
                "광고 건너뛰기 버튼 자동 클릭 (실험)",
                "백그라운드 음악 재생 (홈/화면잠금)",
                "홈 버튼 시 PIP 작은 화면 자동 전환 (선택)"
        };
        boolean[] checks = {filterOn, hidePromotions, autoSkip, backgroundAudio, autoPip};
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 설정")
                .setMultiChoiceItems(labels, checks, (dialog, which, checked) -> checks[which] = checked)
                .setPositiveButton("적용", (dialog, which) -> {
                    boolean shouldReload = filterOn != checks[0]
                            || hidePromotions != checks[1] || autoSkip != checks[2];
                    filterOn = checks[0];
                    hidePromotions = checks[1];
                    autoSkip = checks[2];
                    boolean wasBackground = backgroundAudio;
                    backgroundAudio = checks[3];
                    autoPip = checks[4];
                    settings.edit().putBoolean(KEY_FILTER, filterOn)
                            .putBoolean(KEY_HIDE, hidePromotions)
                            .putBoolean(KEY_SKIP, autoSkip)
                            .putBoolean(KEY_BACKGROUND, backgroundAudio)
                            .putBoolean(KEY_AUTO_PIP, autoPip).apply();
                    if (!backgroundAudio) stopBackgroundService();
                    if (backgroundAudio && !wasBackground) {
                        requestNotificationPermission();
                        if (lastKnownPlaying) {
                            lastKnownPlaying = false;
                            reportPlayerState(true, lastMediaTitle);
                        }
                    }
                    injectCleaner();
                    // Reload only if web filtering options changed, not when toggling audio.
                    if (webView != null && shouldReload)
                        webView.reload();
                    updateStatus();
                })
                .setNeutralButton("설명", (dialog, which) -> new AlertDialog.Builder(this)
                        .setTitle("광고 필터 및 개인정보")
                        .setMessage("광고 필터는 실험적이며 완전한 광고 제거는 보장되지 않습니다. 재생이 실패하면 필터를 꺼보세요.\n\n시청 기록과 즐겨찾기는 기기 안에만 저장됩니다. 별도 분석 서버, 자체 로그인 화면, 외부 전송 기능은 없습니다. 유튜브 계정 로그인은 외부 브라우저로 이동할 수 있습니다.")
                        .setPositiveButton("확인", null).show())
                .setNegativeButton("취소", null)
                .show();
    }

    private void injectCleaner() {
        if (webView == null || cleanerJavaScript.isEmpty()) return;
        if (!LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        String script = "window.__CS_HIDE=" + (hidePromotions ? "true" : "false") + ";" +
                "window.__CS_SKIP=" + (autoSkip ? "true" : "false") + ";\n" + cleanerJavaScript;
        webView.evaluateJavascript(script, null);
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !getPackageManager().hasSystemFeature("android.software.picture_in_picture")) {
            toast("이 기기는 작은 화면(PIP)을 지원하지 않습니다.");
            return;
        }
        try {
            PictureInPictureParams params = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9)).build();
            enterPictureInPictureMode(params);
        } catch (Exception e) {
            toast("PIP를 열 수 없습니다. 영상 재생 상태를 확인하세요.");
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean pip, Configuration config) {
        super.onPictureInPictureModeChanged(pip, config);
        if (pip) {
            searchBar.setVisibility(View.GONE);
            toolsScroll.setVisibility(View.GONE);
            status.setVisibility(View.GONE);
        } else {
            searchBar.setVisibility(View.VISIBLE);
            toolsScroll.setVisibility(View.VISIBLE);
            status.setVisibility(View.VISIBLE);
        }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText((backgroundAudio ? "음악 백그라운드 ON" : "음악 백그라운드 OFF") +
                " · " + (lastKnownPlaying ? "재생 중" : "대기") +
                " · 광고 차단 요청 " + blockedCount.get() + "건");
    }

    private void showIntro() {
        settings.edit().putBoolean("intro_seen", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 0.1.3")
                .setMessage("일반 Android 8 이상 기기를 위한 독립형 유튜브 웹 시청 앱입니다. 백그라운드 음악 재생, 뒤로 가기, 즐겨찾기 이름 자동 인식을 지원합니다. 다만 유튜브 웹사이트 또는 기기 정책에 의해 재생이 멈출 수 있습니다. 광고 필터 또한 실험 기능입니다. 차량에서는 정차 상태에서만 영상을 시청하세요.")
                .setPositiveButton("시작", null)
                .show();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }

    private String loadAsset(String name) throws Exception {
        try (java.io.InputStream stream = getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int n;
            while ((n = stream.read(chunk)) != -1) buffer.write(chunk, 0, n);
            return buffer.toString(StandardCharsets.UTF_8.name());
        }
    }

    /** One handler for toolbar, Android Back button and Android 13+ back gestures. */
    private void back() {
        if (customView != null) { hideCustomView(); return; }
        if (webView != null && webView.canGoBack()) {
            lastBackAtRoot = 0L;
            webView.goBack();
            return;
        }
        if (webView != null) {
            String current = webView.getUrl();
            if (current != null && !HOME.equals(current) &&
                    !"https://www.youtube.com/".equals(current)) {
                lastBackAtRoot = 0L;
                webView.loadUrl(HOME);
                return;
            }
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackAtRoot <= BACK_EXIT_WINDOW_MS) {
            finish();
        } else {
            lastBackAtRoot = now;
            toast("한 번 더 뒤로 누르면 앱을 종료합니다.");
        }
    }

    private void registerSystemBack() {
        // On Android 13+ onBackPressed() alone can be bypassed by predictive back.
        if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback = this::back;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, systemBackCallback);
        }
    }

    @Override public void onBackPressed() { back(); }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); }
    @Override protected void onSaveInstanceState(Bundle output) {
        if (webView != null) {
            Bundle webState = new Bundle();
            webView.saveState(webState);
            output.putBundle("web_state", webState);
        }
        super.onSaveInstanceState(output);
    }
    private void registerAudioReceiver() {
        android.content.IntentFilter filter = new android.content.IntentFilter(BackgroundAudioService.ACTION_CONTROL);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(audioControlReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(audioControlReceiver, filter);
        }
        audioReceiverRegistered = true;
    }

    private void readWebPlayerState(String response) {
        try {
            Object unwrapped = new JSONTokener(response).nextValue();
            if (!(unwrapped instanceof String)) return;
            JSONObject state = new JSONObject((String) unwrapped);
            boolean playing = state.optBoolean("playing", false);
            if (!state.optBoolean("hasVideo", false)) playing = false;
            String title = state.optString("title", "믿음하나튜브");
            if (title.isEmpty()) title = "믿음하나튜브";
            reportPlayerState(playing, title);
        } catch (Exception ignored) {
            // A navigation may invalidate the JS callback; the next poll will retry.
        }
    }

    private void reportPlayerState(boolean playing, String title) {
        if (playing == lastKnownPlaying && title.equals(lastMediaTitle)) return;
        boolean changed = playing != lastKnownPlaying;
        lastKnownPlaying = playing;
        lastMediaTitle = title;
        if (!backgroundAudio) { updateStatus(); return; }
        if (playing) {
            if (!activityBackgrounded && Build.VERSION.SDK_INT >= 33 &&
                    !settings.getBoolean(KEY_NOTIFICATION_ASKED, false)) {
                settings.edit().putBoolean(KEY_NOTIFICATION_ASKED, true).apply();
                requestNotificationPermission();
            }
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, true)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);
                serviceWasStarted = true;
            } catch (RuntimeException ignored) {
                // Foreground service restrictions may prevent a late background start.
                serviceWasStarted = false;
            }
        } else if (serviceWasStarted) {
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, false)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title);
            try { startService(intent); } catch (RuntimeException ignored) { }
        }
        if (changed) updateStatus();
    }

    private void stopBackgroundService() {
        serviceWasStarted = false;
        stopService(new Intent(this, BackgroundAudioService.class));
    }

    private void controlWebPlayer(boolean play) {
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        String script = "(function(){var a=document.querySelectorAll('video'),v=null;" +
                "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
                "if(!v&&a.length)v=a[0];if(!v)return;" +
                (play ? "var p=v.play();if(p&&p.catch)p.catch(function(){});" : "v.pause();") +
                "})()";
        webView.evaluateJavascript(script, null);
        audioHandler.postDelayed(() -> {
            if (webView != null && LibraryStore.isYoutubeUrl(webView.getUrl()))
                webView.evaluateJavascript(PLAYBACK_PROBE_JS, this::readWebPlayerState);
        }, 500);
    }

    private void attemptBackgroundResumptionOnce() {
        if (!activityBackgrounded || !backgroundAudio || !playWasActiveOnLeave || attemptedResumeOnLeave)
            return;
        attemptedResumeOnLeave = true;
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        // A single retry is allowed only for media the user had actively started.
        // We intentionally do not create a repeating autoplay loop.
        webView.evaluateJavascript("(function(){var v=document.querySelector('video');" +
                "if(v&&v.paused&&!v.ended&&v.currentTime>0){" +
                "var p=v.play();if(p&&p.catch)p.catch(function(){});return true;}return false;})()", null);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 122);
        }
    }

    private void showAudioSettings() {
        new AlertDialog.Builder(this)
                .setTitle("백그라운드 음악")
                .setMessage("영상 재생 후 홈 버튼을 눌러도 음악이 이어지도록 시도합니다. 알림창에서 일시중지/재생/종료를 제어할 수 있습니다. YouTube 웹 플레이어와 기기별 절전 정책으로 인해 재생이 중단될 수 있으며, 완전한 보장은 불가능합니다.\n\n작은 화면(PIP)은 기존 도구 모음에서 직접 실행할 수 있습니다.")
                .setPositiveButton(backgroundAudio ? "백그라운드 끄기" : "백그라운드 켜기", (d, w) -> {
                    backgroundAudio = !backgroundAudio;
                    settings.edit().putBoolean(KEY_BACKGROUND, backgroundAudio).apply();
                    if (!backgroundAudio) stopBackgroundService();
                    else {
                        requestNotificationPermission();
                        if (lastKnownPlaying) {
                            lastKnownPlaying = false;
                            reportPlayerState(true, lastMediaTitle);
                        }
                    }
                    updateStatus();
                })
                .setNeutralButton("알림 권한", (d, w) -> requestNotificationPermission())
                .setNegativeButton("닫기", null)
                .show();
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (autoPip && backgroundAudio && lastKnownPlaying && customView == null &&
                Build.VERSION.SDK_INT >= 26 &&
                getPackageManager().hasSystemFeature("android.software.picture_in_picture")) {
            enterPip();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        activityBackgrounded = false;
        playWasActiveOnLeave = false;
        if (webView != null) webView.onResume();
    }

    @Override protected void onPause() {
        activityBackgrounded = true;
        playWasActiveOnLeave = backgroundAudio && lastKnownPlaying;
        attemptedResumeOnLeave = false;
        // The previous v0.1.1 onPause() stopped WebView media as soon as Home was used.
        // Keep the media WebView active while background audio is enabled.
        if (webView != null && !backgroundAudio && !isInPictureInPictureMode()) webView.onPause();
        super.onPause();
        if (playWasActiveOnLeave) audioHandler.postDelayed(this::attemptBackgroundResumptionOnce, 800);
    }

    @Override protected void onDestroy() {
        audioHandler.removeCallbacksAndMessages(null);
        if (Build.VERSION.SDK_INT >= 33 && systemBackCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);
            systemBackCallback = null;
        }
        stopBackgroundService();
        if (audioReceiverRegistered) {
            unregisterReceiver(audioControlReceiver);
            audioReceiverRegistered = false;
        }
        if (webView != null) {
            browserContainer.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
