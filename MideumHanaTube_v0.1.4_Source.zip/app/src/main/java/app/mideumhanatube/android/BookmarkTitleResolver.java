package app.mideumhanatube.android;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Converts the volatile YouTube SPA page title into a useful, local bookmark name.
 * Plain Java to permit independent regression tests without the Android SDK. */
public final class BookmarkTitleResolver {
    private BookmarkTitleResolver() { }

    public static String resolve(String metadata, String pageTitle, String url) {
        String first = clean(metadata);
        if (!isGeneric(first)) return first;
        String second = clean(pageTitle);
        if (!isGeneric(second)) return second;
        return fallback(url);
    }

    public static boolean isGeneric(String title) {
        String t = clean(title);
        String lower = t.toLowerCase(Locale.ROOT);
        return t.isEmpty() || lower.equals("youtube") || lower.equals("youtube.com") ||
                lower.equals("m.youtube.com") || lower.equals("www.youtube.com") ||
                lower.equals("믿음하나튜브") || lower.equals("유튜브") ||
                lower.equals("youtube - youtube") || lower.equals("loading...") ||
                lower.equals("로딩 중...");
    }

    public static boolean isFallback(String title) {
        return isGeneric(title) || title.startsWith("영상 · ") ||
                title.startsWith("Shorts · ") || title.startsWith("재생목록 · ") ||
                title.equals("유튜브 홈") || title.equals("유튜브 채널") ||
                title.equals("유튜브 페이지") || title.startsWith("채널 · ");
    }

    private static String clean(String title) {
        if (title == null) return "";
        String s = title.replace('\n', ' ').replace('\r', ' ').trim().replaceAll("\\s+", " ");
        s = s.replaceAll("(?i)\\s+[-–—|]\\s+youtube\\s*$", "").trim();
        if (s.length() > 110) s = s.substring(0, 110).trim();
        return s;
    }

    private static String fallback(String url) {
        if (url == null) return "유튜브 페이지";
        try {
            URI uri = URI.create(url);
            String path = uri.getPath() == null ? "" : uri.getPath();
            String videoId = param(uri.getRawQuery(), "v");
            if (path.startsWith("/watch") && !videoId.isEmpty())
                return "영상 · " + limit(videoId);
            if (path.startsWith("/shorts/"))
                return "Shorts · " + limit(path.substring("/shorts/".length()).split("/")[0]);
            if (path.startsWith("/live/"))
                return "라이브 · " + limit(path.substring("/live/".length()).split("/")[0]);
            if (path.startsWith("/playlist")) {
                String playlist = param(uri.getRawQuery(), "list");
                return playlist.isEmpty() ? "유튜브 재생목록" : "재생목록 · " + limit(playlist);
            }
            if (path.startsWith("/results")) {
                String query = param(uri.getRawQuery(), "search_query");
                return query.isEmpty() ? "검색 결과" : "검색 · " + limit(query);
            }
            if (path.startsWith("/@")) return limit(path.substring(1).split("/")[0]);
            if (path.startsWith("/channel/")) return "채널 · " + limit(path.substring(9).split("/")[0]);
            if (path.equals("/") || path.isEmpty()) return "유튜브 홈";
            String part = path.substring(path.lastIndexOf('/') + 1).trim();
            return part.isEmpty() ? "유튜브 페이지" : "유튜브 · " + limit(part);
        } catch (RuntimeException ignored) {
            return "유튜브 페이지";
        }
    }

    private static String param(String rawQuery, String name) {
        if (rawQuery == null) return "";
        for (String item : rawQuery.split("&")) {
            int equal = item.indexOf('=');
            if (equal <= 0 || !name.equals(item.substring(0, equal))) continue;
            try { return URLDecoder.decode(item.substring(equal + 1), StandardCharsets.UTF_8.name()); }
            catch (Exception ignored) { return item.substring(equal + 1); }
        }
        return "";
    }

    private static String limit(String value) {
        String cleaned = clean(value);
        return cleaned.length() > 56 ? cleaned.substring(0, 56) : cleaned;
    }
}
