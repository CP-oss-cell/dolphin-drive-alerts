package app.mideumhanatube.android;

import java.net.URI;
import java.util.Locale;

/**
 * Conservative, on-device network filter. Never intercepts video CDN requests.
 * Intentionally pure Java for JVM regression tests.
 */
public final class AdBlockEngine {
    private static final String[] AD_HOSTS = {
            "doubleclick.net",
            "googlesyndication.com",
            "googleadservices.com",
            "adservice.google.com",
            "ads.youtube.com",
            "ad.youtube.com"
    };

    private AdBlockEngine() { }

    public static boolean shouldBlock(String rawUrl, boolean mainFrame) {
        if (mainFrame || rawUrl == null || rawUrl.length() > 4096) return false;
        try {
            URI uri = new URI(rawUrl);
            String scheme = uri.getScheme();
            String rawHost = uri.getHost();
            if (scheme == null || rawHost == null) return false;
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return false;
            String host = rawHost.toLowerCase(Locale.ROOT);
            for (String blockedHost : AD_HOSTS) {
                if (host.equals(blockedHost) || host.endsWith("." + blockedHost)) {
                    return true;
                }
            }
            String path = uri.getPath();
            if (path == null) return false;
            if (isHostOrSubdomain(host, "youtube.com")) {
                return path.equals("/pagead")
                        || path.startsWith("/pagead/")
                        || path.equals("/api/stats/ads");
            }
            return false;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isHostOrSubdomain(String host, String domain) {
        if (host == null || domain == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        String d = domain.toLowerCase(Locale.ROOT);
        return h.equals(d) || h.endsWith("." + d);
    }
}
