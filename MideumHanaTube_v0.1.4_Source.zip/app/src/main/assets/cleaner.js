/*
 * MideumHanaTube best-effort UI filter, injected only on youtube.com pages.
 * This is NOT a substitute for a browser extension, nor a guaranteed ad blocker.
 */
(function () {
  "use strict";
  if (!/(^|\.)youtube\.com$/i.test(location.hostname)) return;
  const styleId = "mideumhanatube-sponsored-style-v01";
  const selectors = [
    "ytm-promoted-sparkles-web-renderer",
    "ytm-promoted-video-renderer",
    "ytm-ad-slot-renderer",
    "ytm-companion-ad-renderer",
    "ytm-display-ad-renderer",
    "ytd-promoted-video-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-display-ad-renderer",
    "ytd-ad-slot-renderer",
    "ytd-companion-slot-renderer",
    ".ytp-ad-overlay-container",
    ".ytp-ad-image-overlay",
    "#player-ads"
  ];
  const existing = document.getElementById(styleId);
  if (window.__CS_HIDE) {
    if (!existing) {
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = selectors.join(",") + "{display:none !important;visibility:hidden !important;}";
      (document.head || document.documentElement).appendChild(style);
    }
  } else if (existing) {
    existing.remove();
  }
  if (!window.__CS_SKIP_TIMER) {
    window.__CS_SKIP_TIMER = setInterval(function () {
      if (!window.__CS_SKIP) return;
      const skip = document.querySelector(
        ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, button.ytp-ad-skip-button-modern"
      );
      if (skip && skip.getClientRects().length) skip.click();
    }, 1200);
  }
})();
