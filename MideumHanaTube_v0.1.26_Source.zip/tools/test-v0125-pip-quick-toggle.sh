#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TEMP" \
  app/src/main/java/app/mideumhanatube/android/PlaybackHandoff.java \
  tools/TestPipQuickToggle.java
java -cp "$TEMP" app.mideumhanatube.android.TestPipQuickToggle
python3 - <<'PY'
from pathlib import Path
base=Path('app/src/main/java/app/mideumhanatube/android')
m=(base/'MainActivity.java').read_text(encoding='utf8')
p=(base/'PipIconButton.java').read_text(encoding='utf8')
v=(base/'VideoPlayerActivity.java').read_text(encoding='utf8')
s=(base/'BackgroundAudioService.java').read_text(encoding='utf8')
y=Path('.github/workflows/MideumHanaTube_v0.1.26_Source.yml').read_text()
assert 'pipActionButton.setOnClickListener(v -> openNativeVideo(true));' in m
assert 'pipActionButton.setOnLongClickListener(v -> {' in m
assert 'togglePipControlMode();' in m
assert 'applyPipControlMode(next, "TOOLBAR_LONG_PRESS")' in m
assert 'settings.edit().putInt("pip_action_mode", mode).apply()' in m
assert 'pipActionButton.setActionMode(mode)' in m
assert 'PIP_CONTROL_MODE_CHANGED' in m
assert 'applyPipControlMode(index, "SETTINGS")' in m
assert 'setContentDescription(' in p and '길게 눌러 버튼 전환' in p
assert 'actionMode == 1 ? "10" : ">>"' in p
assert 'getInt("pip_action_mode", 1)' in v
assert 'ACTION_QUEUE_NEXT' in v and 'ACTION_SEEK_FORWARD' in v
assert 'ACTION_QUEUE_NEXT' in s and 'ACTION_SEEK_FORWARD' in s
assert 'setActions(pipRemoteActions())' in v
assert 'MideumHanaTube_v0.1.26_Source.zip' in y
assert "versionName '0.1.26'" in Path('app/build.gradle').read_text()
print('v0.1.25 PiP toolbar shortcut, accessibility, mode persistence and CI: PASS')
PY
