#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
python3 - "$TMP_DIR" <<'PY'
from pathlib import Path
import sys,re
out=Path(sys.argv[1])
s=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
assert 'private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver()' in s
receiver = s.split('private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver()', 1)[1].split('\n    };',1)[0]
# The two event calls extracted from the real receiver are compiled inside a Java receiver.
checks = {}
for label in ('HANDOFF_ACTUALLY_PLAYING', 'HANDOFF_FAILED_IN_UI'):
    results=[line.strip() for line in receiver.splitlines() if f'"{label}"' in line and 'PlaybackDiagnostics.event(' in line]
    assert len(results)==1, f'expected one {label} event in receiver, got {results}'
    checks[label]=results[0]
assert 'MainActivity.this' in checks['HANDOFF_ACTUALLY_PLAYING']
assert 'MainActivity.this' in checks['HANDOFF_FAILED_IN_UI']
assert not re.search(r'PlaybackDiagnostics\.event\(\s*this\s*,',receiver), 'receiver incorrectly passes its own this as Context'
java = '''
class Context {}\n
class Intent {}\n
abstract class BroadcastReceiver { public abstract void onReceive(Context ctx, Intent intent); }\n
class PlaybackDiagnostics {
    static void event(Context context, long session, String event, String status, Object player) {}
}
class MainActivity extends Context {
    private long playbackTraceSession;
    private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver() {
      @Override public void onReceive(Context context, Intent intent) {
        %s
        %s
      }
    };
}
''' % (checks['HANDOFF_ACTUALLY_PLAYING'],checks['HANDOFF_FAILED_IN_UI'])
(out/'ReceiverContextCompileCheck.java').write_text(java)
print('Generated Java type check directly from the production receiver event calls')
PY
javac --release 17 -encoding UTF-8 -d "$TMP_DIR" "$TMP_DIR/ReceiverContextCompileCheck.java"
python3 - <<'PY'
from pathlib import Path
build=Path('app/build.gradle').read_text()
flow=Path('.github/workflows/MideumHanaTube_v0.1.26_Source.yml').read_text()
assert "versionName '0.1.26'" in build and 'versionCode 27' in build
assert 'for test in' in flow and Path('tools/test-v0114-receiver-context.sh').exists()
assert 'MideumHanaTube_v0.1.26_Source.zip' in flow
assert 'MideumHanaTube_v0.1.13_Source.zip' not in flow
print('v0.1.14 actual javac receiver type test and workflow name check: PASS')
PY
