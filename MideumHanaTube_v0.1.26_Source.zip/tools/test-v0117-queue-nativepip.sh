#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
javac -encoding UTF-8 -d "$tmp" app/src/main/java/app/mideumhanatube/android/PlaybackQueue.java tools/TestPlaybackQueue.java
java -cp "$tmp" app.mideumhanatube.android.TestPlaybackQueue
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path('app/src/main/java/app/mideumhanatube/android')
s=(r/'BackgroundAudioService.java').read_text();a=(r/'MainActivity.java').read_text();v=(r/'VideoPlayerActivity.java').read_text(); x=Path('app/build.gradle').read_text()
assert "versionCode 27" in x and "versionName '0.1.26'" in x
assert "media3-ui:1.11.1" in x
for action in ['QUEUE_NEXT','QUEUE_PREVIOUS','QUEUE_REPEAT','QUEUE_SHUFFLE','QUEUE_PLAY','NATIVE_VIDEO_START']:
 assert 'ACTION_'+action in s
assert 'new PlaybackQueue()' in s
assert 'advanceQueue(false, true)' in s and 'playQueueTrack(target)' in s
assert 'setShuffle' in s and 'cycleRepeat' in s
assert 'onSkipToNext()' in s and 'onSkipToPrevious()' in s
assert 'LocalBinder' in s and 'return localBinder;' in s
assert 'startBookmarkPlaylist()' in a and 'startVisiblePagePlaylist()' in a
assert 'openNativeVideo(true)' in a and 'configureWebAutoPip' not in a
assert 'new PlayerView(this)' in v and 'playerView.setPlayer(player)' in v
assert 'setAutoEnterEnabled(true)' in v
assert 'controls.setVisibility(inPip ? View.GONE : View.VISIBLE)' in v
assert 'getPackageManager().hasSystemFeature' in v
assert 'YouTubeStreamResolver.isSupportedVideoUrl(url)' in v
assert 'new Intent(this, BackgroundAudioService.class)' in v
ns='{http://schemas.android.com/apk/res/android}'
root=ET.parse('app/src/main/AndroidManifest.xml').getroot()
activities=root.find('application').findall('activity')
assert any(a.get(ns+'name')=='.VideoPlayerActivity' and a.get(ns+'supportsPictureInPicture')=='true' for a in activities)
print('Native video PiP / queue / Android manifest structural tests PASS')
PY
