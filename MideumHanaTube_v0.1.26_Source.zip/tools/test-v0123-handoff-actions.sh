#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
temp="$(mktemp -d)"
trap 'rm -rf "$temp"' EXIT
javac --release 17 -encoding UTF-8 -d "$temp" \
    app/src/main/java/app/mideumhanatube/android/PlaybackQueue.java \
    app/src/main/java/app/mideumhanatube/android/PlaybackHandoff.java \
    tools/TestPlaybackHandoff.java
java -cp "$temp" app.mideumhanatube.android.TestPlaybackHandoff
python3 - <<'PY'
from pathlib import Path
base=Path('app/src/main/java/app/mideumhanatube/android')
m=(base/'MainActivity.java').read_text()
v=(base/'VideoPlayerActivity.java').read_text()
s=(base/'BackgroundAudioService.java').read_text()
b=Path('app/build.gradle').read_text()
y=Path('.github/workflows/MideumHanaTube_v0.1.26_Source.yml').read_text()
assert "versionName '0.1.26'" in b and 'versionCode 27' in b
assert 'MideumHanaTube_v0.1.26_Source.zip' in y
assert 'EXTRA_NATIVE_VIDEO_RETURN_PLAYING' in m and 'nativeReturnShouldPlay' in m
assert 'boolean shouldPlay = player == null ? snapshotPlaying : player.getPlayWhenReady();' in v
assert '.putExtra(MainActivity.EXTRA_NATIVE_VIDEO_RETURN_PLAYING, shouldPlay)' in v
assert 'nativeBinder.currentPageUrl()' in v
assert 'sendNativeState(ACTION_NATIVE_POSITION, null, position, wasPlayRequested)' in s
assert 'result.putExtra(EXTRA_PLAYING, requestedPlay);' in s
assert 'PlaybackHandoff.withinSeekTolerance(positionMs,actualPosition)' in m
assert 'correctState=expectPlaying ? videoPlaying : !videoPlaying' in m
assert 'nativeReturnShouldPlay ? BackgroundAudioService.ACTION_PLAY' in m
assert 'getInt("pip_action_mode", 1)' in v
assert 'setSingleChoiceItems(choices' in m
assert 'ACTION_SEEK_BACKWARD' in v and 'ACTION_SEEK_FORWARD' in v
assert 'SYSTEM_ALERT_WINDOW' not in Path('app/src/main/AndroidManifest.xml').read_text()
print('v0.1.24 code integration / PiP seek choice / paused return checks: PASS')
PY
