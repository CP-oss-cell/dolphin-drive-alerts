#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
javac --release 17 -encoding UTF-8 -d "$T" \
  app/src/main/java/app/mideumhanatube/android/AuthorizedDownloadPolicy.java \
  app/src/main/java/app/mideumhanatube/android/YouTubePlaylistContext.java \
  app/src/main/java/app/mideumhanatube/android/YouTubePlaylistWindow.java \
  app/src/main/java/app/mideumhanatube/android/PlaybackQueue.java \
  tools/TestAuthorizedDownloadPolicy.java tools/TestYouTubePlaylistWindow.java tools/TestLargePlaybackQueue.java
java -cp "$T" app.mideumhanatube.android.TestAuthorizedDownloadPolicy
java -cp "$T" app.mideumhanatube.android.TestYouTubePlaylistWindow
java -cp "$T" app.mideumhanatube.android.TestLargePlaybackQueue
node - <<'JS'
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const js=fs.readFileSync('app/src/main/assets/youtube-playlist-context.js','utf8');
const p='PL0123456789';
const rows=Array.from({length:503},(_,i)=>{
 const id=String(i+1).padStart(11,'0');
 const url='https://www.youtube.com/watch?v='+id+'&list='+p+'&index='+(i+1);
 return {
   getAttribute(k){return null;},
   querySelector(s){return {textContent:'영상'+(i+1),getAttribute(k){return null;}};},
   querySelectorAll(s){return [{getAttribute(k){return k==='href'?url:null;}}];}
 };
});
const context={location:{href:'https://www.youtube.com/playlist?list='+p,origin:'https://www.youtube.com'},URL,document:{querySelectorAll:s=>s.includes('ytd-playlist-video-renderer')?rows:[]}};
const out=JSON.parse(vm.runInNewContext(js,context));
assert.equal(out.tracks.length,503);
assert.equal(out.tracks[0].index,1);
assert.equal(out.tracks[502].index,503);
console.log('503 visible YouTube DOM rows captured in order: PASS');
JS
python3 - <<'PY'
from pathlib import Path
p=Path('app/src/main/java/app/mideumhanatube/android')
m=(p/'MainActivity.java').read_text(); s=(p/'BackgroundAudioService.java').read_text(); r=(p/'YouTubeStreamResolver.java').read_text(); d=(p/'AuthorizedMediaDownloads.java').read_text()
assert 'AUTHORIZED_DOWNLOAD_ENQUEUED' in m and 'showDownloadCenter' in m
assert 'setDestinationInExternalPublicDir' in d and 'setDestinationInExternalFilesDir' in d
assert 'LIST_ITEMS_NOT_LOADED' in m and 'YOUTUBE_PLAYLIST_CAPTURED' in m
assert 'PIP_CONTROL_MODE_CHANGED' in m and 'NATIVE_QUALITY_CAP' in m
assert 'getInt("native_video_max_height",720)' in s and 'resolveVideo(pageUrl,cap)' in s
assert 'requestedMaxHeight' in r and 'maxHeight*16+8' in r
assert "versionName '0.1.26'" in Path('app/build.gradle').read_text()
print('v0.1.26 integration guards: PASS')
PY
