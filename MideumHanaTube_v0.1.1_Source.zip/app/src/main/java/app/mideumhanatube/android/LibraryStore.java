package app.mideumhanatube.android;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Private, local-only bookmarks and recent history. No accounts or network sync. */
public final class LibraryStore {
    private static final String PREF = "mideumhanatube_private_library";
    private static final int MAX_HISTORY = 80;
    private static final int MAX_BOOKMARKS = 200;
    private final SharedPreferences prefs;

    public LibraryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static final class Entry {
        public final String title;
        public final String url;

        public Entry(String title, String url) {
            this.title = title;
            this.url = url;
        }

        @Override public String toString() { return title; }
    }

    private List<Entry> read(String key) {
        List<Entry> entries = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                String url = obj.optString("url", "");
                if (!url.startsWith("https://")) continue;
                entries.add(new Entry(obj.optString("title", url), url));
            }
        } catch (Exception ignored) { }
        return entries;
    }

    private void write(String key, List<Entry> entries, int max) {
        JSONArray arr = new JSONArray();
        for (int i = 0; i < entries.size() && i < max; i++) {
            Entry entry = entries.get(i);
            JSONObject obj = new JSONObject();
            try {
                obj.put("title", entry.title);
                obj.put("url", entry.url);
                arr.put(obj);
            } catch (Exception ignored) { }
        }
        prefs.edit().putString(key, arr.toString()).apply();
    }

    public List<Entry> history() { return read("history"); }
    public List<Entry> bookmarks() { return read("bookmarks"); }

    public void addHistory(String title, String url) {
        if (!isYoutubeUrl(url)) return;
        List<Entry> items = history();
        items.removeIf(e -> e.url.equals(url));
        items.add(0, new Entry(safeTitle(title, url), url));
        write("history", items, MAX_HISTORY);
    }

    public boolean isBookmarked(String url) {
        if (url == null) return false;
        for (Entry item : bookmarks()) if (url.equals(item.url)) return true;
        return false;
    }

    public boolean toggleBookmark(String title, String url) {
        if (!isYoutubeUrl(url)) return false;
        List<Entry> items = bookmarks();
        boolean removed = items.removeIf(e -> e.url.equals(url));
        if (!removed) items.add(0, new Entry(safeTitle(title, url), url));
        write("bookmarks", items, MAX_BOOKMARKS);
        return !removed;
    }

    public void clearHistory() { prefs.edit().remove("history").apply(); }
    public void clearBookmarks() { prefs.edit().remove("bookmarks").apply(); }

    private static String safeTitle(String title, String url) {
        if (title == null || title.trim().isEmpty()) return url;
        String cleaned = title.trim();
        return cleaned.length() > 110 ? cleaned.substring(0, 110) : cleaned;
    }

    public static boolean isYoutubeUrl(String url) {
        try {
            android.net.Uri uri = android.net.Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
            String host = uri.getHost();
            return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                    || AdBlockEngine.isHostOrSubdomain(host, "youtu.be");
        } catch (Exception ignored) {
            return false;
        }
    }
}
