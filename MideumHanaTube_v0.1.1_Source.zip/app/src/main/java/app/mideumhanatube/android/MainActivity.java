package app.mideumhanatube.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MideumHanaTube v0.1: standalone Android web-video viewer with a best-effort ad filter.
 * The application is NOT affiliated with YouTube and does not guarantee zero ads.
 * No privileged permissions, VPN, root, Google credentials or external account servers.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://m.youtube.com/";
    private static final String PREF = "mideumhanatube_settings";
    private static final String KEY_FILTER = "filter_hosts";
    private static final String KEY_HIDE = "hide_promotions";
    private static final String KEY_SKIP = "auto_skip";
    private static final int COLOR_BG = Color.rgb(15, 23, 35);
    private static final int COLOR_PANEL = Color.rgb(25, 36, 52);
    private static final int COLOR_ACCENT = Color.rgb(96, 165, 250);
    private static final int COLOR_WHITE = Color.rgb(237, 242, 249);

    private SharedPreferences settings;
    private LibraryStore library;
    private FrameLayout root;
    private LinearLayout page;
    private LinearLayout searchBar;
    private HorizontalScrollView toolsScroll;
    private TextView status;
    private EditText searchInput;
    private WebView webView;
    private FrameLayout browserContainer;
    private FrameLayout fullscreenContainer;
    private ProgressBar loading;
    private Button bookmarkButton;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private int priorOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private boolean filterOn;
    private boolean hidePromotions;
    private boolean autoSkip;
    private final AtomicInteger blockedCount = new AtomicInteger();
    private String cleanerJavaScript = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences(PREF, MODE_PRIVATE);
        library = new LibraryStore(this);
        filterOn = settings.getBoolean(KEY_FILTER, true);
        hidePromotions = settings.getBoolean(KEY_HIDE, true);
        autoSkip = settings.getBoolean(KEY_SKIP, true);
        try { cleanerJavaScript = loadAsset("cleaner.js"); }
        catch (Exception e) { cleanerJavaScript = ""; }
        setWindowColors();
        buildUi();
        buildBrowser();
        if (state != null && state.getBundle("web_state") != null) {
            webView.restoreState(state.getBundle("web_state"));
        } else {
            navigateInitial(getIntent());
        }
        if (!settings.getBoolean("intro_seen", false)) showIntro();
    }

    private void setWindowColors() {
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(10), dp(5), dp(10), dp(5));
        searchBar.setBackgroundColor(COLOR_BG);
        page.addView(searchBar, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView brand = new TextView(this);
        brand.setText("▶");
        brand.setTextColor(COLOR_ACCENT);
        brand.setTextSize(25);
        brand.setGravity(Gravity.CENTER);
        brand.setContentDescription("믿음하나튜브");
        searchBar.addView(brand, new LinearLayout.LayoutParams(dp(35), -1));

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(COLOR_WHITE);
        searchInput.setHintTextColor(Color.rgb(158, 176, 197));
        searchInput.setHint("유튜브 검색 또는 링크 입력");
        searchInput.setTextSize(15);
        searchInput.setPadding(dp(12), 0, dp(12), 0);
        searchInput.setBackgroundColor(COLOR_PANEL);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(43), 1f);
        searchBar.addView(searchInput, inputParams);
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                search();
                return true;
            }
            return false;
        });
        Button searchButton = toolbarButton("검색", "검색 실행", v -> search());
        searchButton.setTextColor(COLOR_ACCENT);
        searchBar.addView(searchButton, new LinearLayout.LayoutParams(dp(60), dp(44)));

        toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setBackgroundColor(COLOR_PANEL);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(6), 0, dp(6), 0);
        toolsScroll.addView(actions, new HorizontalScrollView.LayoutParams(-2, dp(45)));
        page.addView(toolsScroll, new LinearLayout.LayoutParams(-1, dp(45)));

        addAction(actions, "◀", "뒤로", v -> back());
        addAction(actions, "▶", "앞으로", v -> { if (webView.canGoForward()) webView.goForward(); });
        addAction(actions, "⌂", "홈", v -> webView.loadUrl(HOME));
        addAction(actions, "↻", "새로고침", v -> webView.reload());
        bookmarkButton = addAction(actions, "☆", "즐겨찾기 추가 또는 제거", v -> toggleBookmark());
        addAction(actions, "즐겨찾기", "즐겨찾기 목록", v -> showEntries(false));
        addAction(actions, "기록", "시청 기록", v -> showEntries(true));
        addAction(actions, "작은 화면", "PIP 작은 화면", v -> enterPip());
        addAction(actions, "설정", "필터와 개인 정보 설정", v -> showSettings());

        LinearLayout strip = new LinearLayout(this);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(12), 0, dp(10), 0);
        strip.setBackgroundColor(COLOR_BG);
        page.addView(strip, new LinearLayout.LayoutParams(-1, dp(26)));
        status = new TextView(this);
        status.setTextColor(Color.rgb(160, 178, 195));
        status.setTextSize(11);
        status.setSingleLine(true);
        strip.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_ACCENT));
        strip.addView(loading, new LinearLayout.LayoutParams(dp(65), dp(4)));

        browserContainer = new FrameLayout(this);
        page.addView(browserContainer, new LinearLayout.LayoutParams(-1, 0, 1f));
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets area = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(area.left, area.top, area.right, area.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
        updateStatus();
    }

    private Button addAction(LinearLayout container, String label, String description, View.OnClickListener action) {
        Button btn = toolbarButton(label, description, action);
        container.addView(btn, new LinearLayout.LayoutParams(-2, dp(44)));
        return btn;
    }

    private Button toolbarButton(String label, String description, View.OnClickListener action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(COLOR_WHITE);
        btn.setTextSize(13);
        btn.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        btn.setPadding(dp(8), 0, dp(8), 0);
        btn.setMinWidth(0);
        btn.setMinimumWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumHeight(0);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(COLOR_PANEL));
        btn.setContentDescription(description);
        btn.setOnClickListener(action);
        return btn;
    }

    private void buildBrowser() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browserContainer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (filterOn && AdBlockEngine.shouldBlock(request.getUrl().toString(), request.isForMainFrame())) {
                    int count = blockedCount.incrementAndGet();
                    if (count <= 10 || count % 10 == 0) runOnUiThread(MainActivity.this::updateStatus);
                    WebResourceResponse empty = new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                    empty.setStatusCodeAndReasonPhrase(204, "No Content");
                    return empty;
                }
                return null;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if (isInternal(url)) return false;
                if ("https".equalsIgnoreCase(url.getScheme()) || "http".equalsIgnoreCase(url.getScheme())) {
                    openExternal(url);
                } else {
                    toast("외부 앱으로 연결되는 링크는 지원하지 않습니다.");
                }
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                loading.setVisibility(View.VISIBLE);
                loading.setProgress(5);
                updateStatus();
            }

            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
                if (LibraryStore.isYoutubeUrl(url)) {
                    library.addHistory(view.getTitle(), url);
                    injectCleaner();
                }
                updateBookmark();
                updateStatus();
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                super.doUpdateVisitedHistory(view, url, isReload);
                if (!isReload && LibraryStore.isYoutubeUrl(url)) library.addHistory(view.getTitle(), url);
                updateBookmark();
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loading.setVisibility(View.GONE);
                    toast("페이지 연결 실패: 인터넷 상태와 Android WebView를 확인하세요.");
                }
            }

            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view == webView) {
                    browserContainer.removeView(view);
                    view.destroy();
                    webView = null;
                    toast("웹 엔진이 종료되어 화면을 다시 엽니다.");
                    recreate();
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loading.setProgress(progress);
                loading.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (LibraryStore.isYoutubeUrl(view.getUrl())) library.addHistory(title, view.getUrl());
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCallback = callback;
                priorOrientation = getRequestedOrientation();
                page.setVisibility(View.GONE);
                fullscreenContainer.removeAllViews();
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenContainer.setVisibility(View.VISIBLE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        View.SYSTEM_UI_FLAG_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() { hideCustomView(); }
        });
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(priorOrientation);
        page.setVisibility(isInPictureInPictureMode() ? View.GONE : View.VISIBLE);
        if (root != null) root.requestApplyInsets();
    }

    private static boolean isInternal(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                || AdBlockEngine.isHostOrSubdomain(host, "youtu.be")
                || AdBlockEngine.isHostOrSubdomain(host, "youtube-nocookie.com");
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException ex) { toast("연결할 브라우저가 없습니다."); }
    }

    private void navigateInitial(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        webView.loadUrl(uri != null && isInternal(uri) ? uri.toString() : HOME);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (webView != null) navigateInitial(intent);
    }

    private void search() {
        String query = searchInput.getText().toString().trim();
        if (query.isEmpty()) { webView.loadUrl(HOME); return; }
        hideKeyboard();
        Uri target = Uri.parse(query);
        if (query.startsWith("https://") && isInternal(target)) {
            webView.loadUrl(query);
        } else {
            webView.loadUrl("https://m.youtube.com/results?search_query=" + Uri.encode(query));
        }
        searchInput.clearFocus();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
    }

    private void toggleBookmark() {
        String url = webView.getUrl();
        if (!LibraryStore.isYoutubeUrl(url)) { toast("유튜브 페이지에서만 저장할 수 있습니다."); return; }
        boolean saved = library.toggleBookmark(webView.getTitle(), url);
        toast(saved ? "즐겨찾기에 저장했습니다." : "즐겨찾기에서 제거했습니다.");
        updateBookmark();
    }

    private void updateBookmark() {
        if (bookmarkButton != null && webView != null)
            bookmarkButton.setText(library.isBookmarked(webView.getUrl()) ? "★" : "☆");
    }

    private void showEntries(boolean history) {
        List<LibraryStore.Entry> entries = history ? library.history() : library.bookmarks();
        String title = history ? "최근 방문 기록" : "즐겨찾기";
        if (entries.isEmpty()) { toast(title + "이 없습니다."); return; }
        String[] titles = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) titles[i] = entries.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(titles, (dialog, index) -> webView.loadUrl(entries.get(index).url))
                .setNegativeButton("닫기", null)
                .setNeutralButton("전체 삭제", (dialog, which) -> new AlertDialog.Builder(this)
                        .setTitle(title + " 전체 삭제")
                        .setMessage("기기에 저장된 항목을 모두 삭제할까요?")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제", (d, w) -> {
                            if (history) library.clearHistory(); else library.clearBookmarks();
                            updateBookmark();
                            toast("삭제했습니다.");
                        }).show())
                .show();
    }

    private void showSettings() {
        String[] labels = {
                "외부 광고 서버 요청 차단 (권장)",
                "광고성 화면 요소 숨기기 (권장)",
                "광고 건너뛰기 버튼 자동 클릭 (실험)"
        };
        boolean[] checks = {filterOn, hidePromotions, autoSkip};
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 설정")
                .setMultiChoiceItems(labels, checks, (dialog, which, checked) -> checks[which] = checked)
                .setPositiveButton("적용", (dialog, which) -> {
                    filterOn = checks[0];
                    hidePromotions = checks[1];
                    autoSkip = checks[2];
                    settings.edit().putBoolean(KEY_FILTER, filterOn)
                            .putBoolean(KEY_HIDE, hidePromotions)
                            .putBoolean(KEY_SKIP, autoSkip).apply();
                    injectCleaner();
                    if (webView != null) webView.reload();
                    updateStatus();
                })
                .setNeutralButton("설명", (dialog, which) -> new AlertDialog.Builder(this)
                        .setTitle("광고 필터 및 개인정보")
                        .setMessage("광고 필터는 실험적이며 완전한 광고 제거는 보장되지 않습니다. 재생이 실패하면 필터를 꺼보세요.\n\n시청 기록과 즐겨찾기는 기기 안에만 저장됩니다. 별도 분석 서버, 자체 로그인 화면, 외부 전송 기능은 없습니다. 유튜브 계정 로그인은 외부 브라우저로 이동할 수 있습니다.")
                        .setPositiveButton("확인", null).show())
                .setNegativeButton("취소", null)
                .show();
    }

    private void injectCleaner() {
        if (webView == null || cleanerJavaScript.isEmpty()) return;
        if (!LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        String script = "window.__CS_HIDE=" + (hidePromotions ? "true" : "false") + ";" +
                "window.__CS_SKIP=" + (autoSkip ? "true" : "false") + ";\n" + cleanerJavaScript;
        webView.evaluateJavascript(script, null);
    }

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !getPackageManager().hasSystemFeature("android.software.picture_in_picture")) {
            toast("이 기기는 작은 화면(PIP)을 지원하지 않습니다.");
            return;
        }
        try {
            PictureInPictureParams params = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9)).build();
            enterPictureInPictureMode(params);
        } catch (Exception e) {
            toast("PIP를 열 수 없습니다. 영상 재생 상태를 확인하세요.");
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean pip, Configuration config) {
        super.onPictureInPictureModeChanged(pip, config);
        if (pip) {
            searchBar.setVisibility(View.GONE);
            toolsScroll.setVisibility(View.GONE);
            status.setVisibility(View.GONE);
        } else {
            searchBar.setVisibility(View.VISIBLE);
            toolsScroll.setVisibility(View.VISIBLE);
            status.setVisibility(View.VISIBLE);
        }
    }

    private void updateStatus() {
        if (status == null) return;
        status.setText((filterOn ? "광고 요청 필터 켜짐" : "광고 요청 필터 꺼짐") +
                " · 차단 요청 " + blockedCount.get() + "건 · 광고 완전 제거 보장 안 됨");
    }

    private void showIntro() {
        settings.edit().putBoolean("intro_seen", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 0.1")
                .setMessage("일반 Android 8 이상 기기를 위한 독립형 유튜브 웹 시청 앱입니다. 광고 요청 필터는 실험 기능으로, 일부 광고는 표시될 수 있습니다. Google 또는 YouTube의 공식 앱이 아닙니다. 차량에서는 반드시 안전하게 정차한 상태에서만 영상을 시청하세요.")
                .setPositiveButton("시작", null)
                .show();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }

    private String loadAsset(String name) throws Exception {
        try (java.io.InputStream stream = getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int n;
            while ((n = stream.read(chunk)) != -1) buffer.write(chunk, 0, n);
            return buffer.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void back() {
        if (customView != null) { hideCustomView(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else if (webView != null && !HOME.equals(webView.getUrl())) webView.loadUrl(HOME);
        else finish();
    }

    @Override public void onBackPressed() { back(); }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); }
    @Override protected void onSaveInstanceState(Bundle output) {
        if (webView != null) {
            Bundle webState = new Bundle();
            webView.saveState(webState);
            output.putBundle("web_state", webState);
        }
        super.onSaveInstanceState(output);
    }
    @Override protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
    @Override protected void onPause() {
        if (webView != null && !isInPictureInPictureMode()) webView.onPause();
        super.onPause();
    }
    @Override protected void onDestroy() {
        if (webView != null) {
            browserContainer.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
