# 믿음하나튜브 (MideumHanaTube) v0.1.1

일반 Android 스마트폰, 태블릿, BYD 돌핀 Android 10 헤드유닛을 목표로 하는 독립형 웹 동영상 뷰어입니다.

**중요: 공식 YouTube 앱이 아니며, YouTube 또는 Google과 제휴 관계가 없습니다.** 광고 차단은 브라우저 요청 필터 및 페이지 요소 숨김으로 구현한 *실험적·최선 노력 방식*입니다. 인스트림 광고가 남거나 재생이 실패할 수 있습니다. 유튜브 서버 변경, 콘텐츠 차단 정책과 서비스 약관에 영향을 받을 수 있습니다.

## 이미 구현한 기능

- 유튜브 모바일 웹 홈, 검색, 유튜브 링크 열기, 앞으로/뒤로, 새로고침
- 외부 광고 서버 요청 차단(보수적인 도메인 규칙) 및 카운터
- 광고성 화면 요소 CSS 숨기기, 광고 건너뛰기 버튼 자동 클릭(실험)
- 영상 전체화면 및 가로 회전, 작은 화면(PIP) 진입 시도
- 로컬 최근 방문 기록/즐겨찾기 저장·삭제
- 필터 3개 항목 개별 켜기·끄기
- 안드로이드 8(API 26) 이상, 스마트폰 세로 및 차량/태블릿 가로 적응
- 별도 계정 수집 서버/분석 SDK/ADB/Root/VPN 없음, 인터넷 권한만 사용

## 아직 구현 또는 검증하지 못한 기능

- 유튜브 모든 광고의 완전 제거 및 모든 기기의 정상 재생 보장
- 공식 계정 로그인, 구독·재생목록 동기화(외부 브라우저 인증은 가능)
- 네이티브 스트림 추출·전용 ExoPlayer, 확장 프로그램 수준의 필터 엔진
- 앱 자체 동영상 다운로드, 백그라운드 오디오 서비스
- 실차/스마트폰 실기기 검증, APK 실제 빌드 성공 확인

## GitHub에서 APK 빌드

1. 다른 앱과 섞지 않은 **믿음하나튜브 전용 새 GitHub 저장소**를 생성합니다. 아래 A 또는 B 중 하나로 업로드합니다.
   - A(간편): 통합 ZIP을 풀어 나온 `MideumHanaTube_v0.1.1_Source.zip`을 저장소 루트에 올리고, `MideumHanaTube_v0.1.1_Source.yml`을 `.github/workflows/`에 올립니다.
   - B(소스형): 소스 ZIP 내부의 폴더와 파일 전체를 저장소 루트에 올립니다. 워크플로는 소스에 이미 포함되어 있습니다.
2. Actions > `MideumHanaTube Android APK` > `Run workflow` 실행 (또는 main push 시 자동 실행).
3. 빌드가 성공하면 실행 내역 아래 Artifacts에서 `MideumHanaTube_v0.1.1_Debug_APK`를 받습니다.
4. 압축을 풀어 `MideumHanaTube_v0.1.1_Debug.apk`를 안드로이드 기기에 설치합니다. 기존 앱 업데이트 시 패키지 서명키가 달라지면 덮어쓰기 불가하며, GitHub Actions 빌드 간 디버그 서명은 달라질 수 있습니다.

Gradle 8.13, Android Gradle Plugin 8.13.2, JDK 17, Android SDK 36 사용. `android-actions/setup-android@v3`가 2026-11-04 GitHub 환경에서 삭제된 레거시 `tools` 패키지를 요청하여 실패하므로 해당 액션 없이 preinstalled sdkmanager로 플랫폼을 설치합니다. 외부 종속성은 Android Gradle Plugin 외에 없습니다.

> 참고: Play Store 정식 배포는 별도 서명, 정책 검토 및 광고 차단/YouTube 서비스 약관 검토가 필요합니다. 앱을 Google Play에 공개한다고 보장하지 않습니다.

## Android Studio에서 APK 만들기

`Open` > 프로젝트 루트 선택 > Gradle Sync > Build APK(s). Android Studio에 Android SDK 36 설치 필요.

## 코드 구성

- `app/src/main/java/app/mideumhanatube/android/MainActivity.java`: 사용자 인터페이스, Android WebView/전체화면/PIP/환경 설정
- `app/src/main/java/app/mideumhanatube/android/AdBlockEngine.java`: 도메인 기반 광고 요청 차단(최선 노력)
- `app/src/main/java/app/mideumhanatube/android/LibraryStore.java`: 개인용 로컬 기록/즐겨찾기
- `app/src/main/assets/cleaner.js`: 광고성 화면 요소 숨김, 건너뛰기 버튼 자동 클릭
- `.github/workflows/MideumHanaTube_v0.1.1_Source.yml`: GitHub Actions 빌드 및 APK 아티팩트 업로드
- `tools/test-filter.sh`: Java 필터 회귀 테스트

## 보안·안전

- 앱은 외부 서버로 영상 주소나 검색 기록을 전송하는 자체 텔레메트리를 갖고 있지 않습니다. 그러나 유튜브 웹 사용 자체는 Google/YouTube 서버와 통신합니다.
- Google 계정 및 로그인 페이지는 앱 내에서 수집·위장하지 않으며 외부 브라우저에서 처리하도록 구성했습니다.
- 위험한 인증서 오류를 무시하지 않습니다.
- 저장 정보는 기기 내부에만 보관되며 사용자가 기록과 즐겨찾기를 삭제할 수 있습니다.
- 차량 화면을 이용한 영상 시청은 **정차 상태에서만** 해야 합니다. 차량 주행 상태 감지·영상 자동 잠금은 구현되지 않았습니다.

## 알려진 기술적 한계

Android WebView의 `shouldInterceptRequest()`는 모든 리디렉션/`blob:` URL을 포착하지 못합니다. 동일 영상 도메인에서 광고와 영상을 함께 제공할 경우 요청만으로 완벽하게 구분할 수 없어 본 프로젝트는 영상 CDN을 차단하지 않습니다. 비디오를 손상시키는 공격적인 광범위 차단 규칙을 적용하지 않았습니다. WebView의 유튜브 사이트 지원 여부는 기기 웹 엔진 버전과 유튜브 정책에 의존합니다.

## 버전

v0.1.1 / 2026-11-04 / GitHub Actions의 SDK 설정 실패 수리, ZIP 직접 빌드 지원, 타 앱 저장소 오빌드 방지, versionCode 2. 정적 필터 회귀 테스트 및 구조 검사까지만 수행했으며 Android APK 실행 검증은 아직 진행하지 않았습니다.

## 앱 이름 변경 이력

이 패키지는 기존 CleanStream 초기 소스를 바탕으로 이름, 앱 식별자, 프로젝트명 및 빌드파일명을 **믿음하나튜브(MideumHanaTube)**로 통일한 것입니다. 기능의 동작 범위는 기존 v0.1.1과 동일합니다. Android 패키지 ID를 `app.mideumhanatube.android`로 변경했으므로 기존 CleanStream 앱이 별도로 설치된 경우 새로운 앱으로 인식됩니다.

## v0.1.1 오류 수정 기록

`1.zip` 로그(2026-11-04)에서 `android-actions/setup-android@v3`의 `sdkmanager tools` 호출이 `Failed to find package tools`로 종료되었습니다. 원인 SDK 설정 단계를 교체했으며 Android 앱 컴파일 오류 여부는 기존 로그에서 알 수 없습니다. 기존 실행 저장소 `CP-oss-cell/dolphin-drive-alerts`는 주행보조 앱이므로 믿음하나튜브 전용 별도 저장소 사용을 권장합니다. 새로운 빌드가 성공해야 APK가 확보됩니다.
