# Dolphin OEM HUD Bridge v0.9.7 — GitHub CI 패키지 복구

## 이번 변경의 목적
GitHub Actions 로그(2026-11-02)에 나타난 **YML 파일 바이트 불일치 검사 실패**만 수정했습니다. 순정 TMAP 접근성/알림 수신, HUD BLE 등 앱 기능 코드는 v0.9.6에서 유지되었습니다.

## GitHub 업로드 — 2개 파일만

1. 저장소 최상위: `Dolphin_OEM_HUD_Bridge_v0.9.7_SOURCE.zip` (압축 해제하지 않음).
2. `.github/workflows/build-oem-hud-bridge.yml` 경로에 별도 `build-oem-hud-bridge-v0.9.7.yml` 내용을 붙여넣어 교체/커밋.
3. GitHub Actions에서 **Build Dolphin OEM HUD Bridge v0.9.7 (ZIP + YML)**을 선택해 Run workflow. ZIP과 YML은 같은 브랜치에 있어야 합니다.
4. 빌드가 실제로 성공하면 Artifacts에서 `DolphinOemHudBridge_v0.9.7_vc17.apk`가 포함된 ZIP을 받습니다.

## 변경 포인트
- 과거 `cmp -s GitHub_YML ZIP_내부_YML` 검사는 제거. 업로드/개행/브랜치 차이로 빌드 중단되지 않음.
- 소스 ZIP 안 `RELEASE_BUNDLE.json`과 Gradle 버전(0.9.7-ci-release / 17)이 일치하는지 확인.
- 기존 파서·BLE·TMAP 수신기·대시보드 모의 검사와 실제 Gradle APK 빌드 및 APK 버전/컴포넌트 검사는 유지.

## 실차 기능 상태
기존 2602 순정 TMAP의 패키지 `com.tmap.auto.byd` 감지, 접근성·알림 수집 경로를 유지합니다. 차량에서 방향/거리 노출 및 실제 HUD 출력 여부는 아직 검증되지 않았습니다. 빌드 성공 = 기능 성공 아님.

## 업데이트 설치
패키지 `com.dolphin.oemhud`, versionCode 17. 구버전과 APK 서명이 다르면 업그레이드 설치되지 않을 수 있으므로 기존 앱 삭제 전 설정과 저장된 키/권한 상태를 확인하세요.
