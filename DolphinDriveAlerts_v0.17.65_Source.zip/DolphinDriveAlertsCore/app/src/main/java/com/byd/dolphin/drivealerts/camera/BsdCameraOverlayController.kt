package com.byd.dolphin.drivealerts.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Hyundai/Kia BVM-Style Clean-Room Camera2 Floating Blind-Spot Monitor Controller.
 * - Real-time Mirror/Flip, FOV Zoom, Pan X/Y angle alignment, and Brightness/Contrast/Saturation ColorMatrix.
 * - Hardware AE exposure compensation + speed range filter + immediate reverse-gear yield.
 */
class BsdCameraOverlayController(context: Context) {
    private val app = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var camThread: HandlerThread? = null
    private var camHandler: Handler? = null

    private var overlayView: FrameLayout? = null
    private var textureView: TextureView? = null
    private var statusBadge: TextView? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var activeSurface: Surface? = null

    @Volatile private var currentSide: Side = Side.UNKNOWN
    @Volatile private var lastSignalMs: Long = 0L
    @Volatile private var previewUntilMs: Long = 0L

    private val hideRunnable = Runnable { hide("hold_expired") }

    fun isOverlayActive(): Boolean = currentSide != Side.UNKNOWN

    fun probeCameras(): String {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return "CameraManager 조회 불가"
        val ids = runCatching { cm.cameraIdList }.getOrElse {
            return "카메라 목록 조회 실패: ${it.javaClass.simpleName} (${it.message})"
        }
        if (ids.isEmpty()) return "노출된 Camera2 장치 없음 (차량 펌웨어가 일반 앱의 카메라 접근을 차단했을 수 있습니다)"
        val sb = StringBuilder("감지된 Camera2 장치 ${ids.size}개:\n")
        for (id in ids) {
            val info = runCatching {
                val ch = cm.getCameraCharacteristics(id)
                val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                    CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                    CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
                    else -> "UNKNOWN"
                }
                val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
                    ?.take(3)?.joinToString(",") { "${it.width}x${it.height}" } ?: "none"
                "ID=$id | facing=$facing | sizes=$sizes"
            }.getOrElse { "ID=$id | characteristics error: ${it.javaClass.simpleName}" }
            sb.appendLine(" - $info")
        }
        return sb.toString().trim()
    }

    fun onVehicleTurnState(side: Side, isReverseGear: Boolean, speedKmH: Float? = null) {
        val now = System.currentTimeMillis()
        if (isReverseGear) {
            if (currentSide != Side.UNKNOWN) hide("reverse_gear_yield")
            return
        }
        if (now < previewUntilMs) return
        if (!BsdCameraPreferences.enabled(app)) {
            if (currentSide != Side.UNKNOWN) hide("disabled")
            return
        }
        // Optional speed window filter (e.g. 5~80 km/h or 10~110 km/h)
        if (speedKmH != null) {
            val speedOk = when (BsdCameraPreferences.speedFilterMode(app)) {
                1 -> speedKmH in 5f..80f
                2 -> speedKmH in 10f..110f
                else -> true
            }
            if (!speedOk) {
                if (currentSide != Side.UNKNOWN) hide("speed_out_of_range")
                return
            }
        }
        if (side == Side.LEFT || side == Side.RIGHT) {
            lastSignalMs = now
            mainHandler.removeCallbacks(hideRunnable)
            if (currentSide != side) show(side, isPreview = false)
            mainHandler.postDelayed(hideRunnable, BsdCameraPreferences.holdMs(app))
        } else if (currentSide != Side.UNKNOWN && now - lastSignalMs >= BsdCameraPreferences.holdMs(app)) {
            hide("signal_off")
        }
    }

    fun startPreview(side: Side, durationMs: Long = 5_000L) {
        previewUntilMs = System.currentTimeMillis() + durationMs
        mainHandler.removeCallbacks(hideRunnable)
        show(side, isPreview = true)
        mainHandler.postDelayed(hideRunnable, durationMs)
    }

    fun hide(reason: String = "manual") {
        mainHandler.post {
            mainHandler.removeCallbacks(hideRunnable)
            previewUntilMs = 0L
            currentSide = Side.UNKNOWN
            closeCamera()
            removeOverlayView()
            CoreLog.i("BSD_CAM", "overlay hidden reason=$reason")
        }
    }

    fun shutdown() {
        hide("shutdown")
        runCatching { camThread?.quitSafely() }
        camThread = null
        camHandler = null
    }

    private fun ensureCameraThread() {
        if (camThread != null && camThread!!.isAlive) return
        camThread = HandlerThread("bsd-camera2").apply { start() }
        camHandler = Handler(camThread!!.looper)
    }

    private fun show(side: Side, isPreview: Boolean) {
        mainHandler.post {
            if (!Settings.canDrawOverlays(app)) { CoreLog.w("BSD_CAM", "overlay permission missing"); return@post }
            if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                CoreLog.w("BSD_CAM", "CAMERA permission missing"); return@post
            }
            currentSide = side
            closeCamera()
            removeOverlayView()
            createOverlayView(side, isPreview)
        }
    }

    private fun dp(v: Int): Int = (app.resources.displayMetrics.density * v + 0.5f).toInt()

    private fun createOverlayView(side: Side, isPreview: Boolean) {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val (wDp, hDp) = when (BsdCameraPreferences.sizeTier(app)) {
            0 -> 380 to 230
            2 -> 580 to 350
            else -> 480 to 290
        }
        val container = FrameLayout(app).apply {
            background = GradientDrawable().apply {
                setColor(0xF0090F1A.toInt())
                cornerRadius = dp(24).toFloat() // Hyundai/Kia BVM rounded cockpit bezel
                setStroke(dp(3), 0xFF38D9E6.toInt())
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val tv = TextureView(app).apply {
            applyColorCalibration(this)
        }
        val badge = TextView(app).apply {
            val sideKo = if (side == Side.LEFT) "◀ 좌측 BVM 후측방" else "우측 BVM 후측방 ▶"
            text = if (isPreview) "$sideKo (미리보기)" else sideKo
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0xBB090F1A.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        val closeHint = TextView(app).apply {
            text = "✕"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xBB1C2C44.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { hide("user_tap_close") }
        }
        container.addView(tv, FrameLayout.LayoutParams(-1, -1))
        container.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(12), dp(10), 0, 0)
        })
        container.addView(closeHint, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(8), dp(10), 0)
        })

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                applyBvmTransform(tv, side, width, height)
                openCamera(side, surface)
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
                applyBvmTransform(tv, side, width, height)
            }
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                closeCamera()
                return true
            }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            dp(wDp), dp(hDp), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or (if (side == Side.LEFT) Gravity.START else Gravity.END)
            x = dp(24)
            y = dp(32)
        }
        runCatching {
            wm.addView(container, lp)
            overlayView = container
            textureView = tv
            statusBadge = badge
        }.onFailure {
            CoreLog.w("BSD_CAM", "addView failed: ${it.message}")
        }
    }

    /** Hardware-accelerated ColorMatrix (Brightness + Contrast + Saturation) on TextureView. */
    private fun applyColorCalibration(tv: TextureView) {
        val bright = BsdCameraPreferences.brightness(app) * 2.0f // -100..+100
        val contrast = BsdCameraPreferences.contrastPercent(app) / 100f // 0.5..1.8
        val sat = BsdCameraPreferences.saturationPercent(app) / 100f // 0.0..2.0

        val satMatrix = ColorMatrix().apply { setSaturation(sat) }
        val t = (1f - contrast) * 128f + bright
        val bcMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, t,
            0f, contrast, 0f, 0f, t,
            0f, 0f, contrast, 0f, t,
            0f, 0f, 0f, 1f, 0f
        ))
        satMatrix.postConcat(bcMatrix)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(satMatrix) }
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    /** Full Hyundai/Kia BVM geometry: AVM crop + FOV Zoom + Mirror/Flip + Pan X/Y alignment. */
    private fun applyBvmTransform(tv: TextureView, side: Side, viewW: Int, viewH: Int) {
        val w = viewW.toFloat().coerceAtLeast(1f)
        val h = viewH.toFloat().coerceAtLeast(1f)
        val cropMode = BsdCameraPreferences.cropMode(app)
        val zoom = BsdCameraPreferences.zoomPercent(app) / 100f
        val mirrorH = BsdCameraPreferences.mirrorHorizontal(app)
        val flipV = BsdCameraPreferences.flipVertical(app)
        // Mirror panX automatically for right vs left so one setting aligns both sides symmetrically
        val rawPanX = BsdCameraPreferences.panX(app) / 100f
        val panX = if (side == Side.RIGHT) -rawPanX else rawPanX
        val panY = BsdCameraPreferences.panY(app) / 100f

        val m = Matrix()
        when (cropMode) {
            1 -> {
                m.setScale(2f, 1f)
                if (side == Side.RIGHT) m.postTranslate(-w, 0f)
            }
            2 -> {
                m.setScale(2f, 2f)
                m.postTranslate(if (side == Side.RIGHT) -w else 0f, -h)
            }
            else -> m.reset()
        }
        // Apply FOV zoom around view center
        m.postScale(zoom, zoom, w / 2f, h / 2f)
        // Apply horizontal mirror (side-mirror perspective) & optional vertical flip
        val sx = if (mirrorH) -1f else 1f
        val sy = if (flipV) -1f else 1f
        if (mirrorH || flipV) m.postScale(sx, sy, w / 2f, h / 2f)
        // Apply fine pan alignment
        m.postTranslate(panX * w, panY * h)
        tv.setTransform(m)
    }

    private fun openCamera(side: Side, surfaceTexture: SurfaceTexture) {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        val requestedId = if (side == Side.LEFT) BsdCameraPreferences.leftCameraId(app) else BsdCameraPreferences.rightCameraId(app)
        val available = runCatching { cm.cameraIdList.toList() }.getOrDefault(emptyList())
        val camId = if (requestedId in available) requestedId else available.firstOrNull()
        if (camId == null) {
            mainHandler.post { statusBadge?.text = "카메라 ID 없음 (차량 Camera2 미노출)" }
            return
        }
        ensureCameraThread()
        val handler = camHandler ?: return
        runCatching {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (currentSide == Side.UNKNOWN) { runCatching { camera.close() }; return }
                    cameraDevice = camera
                    startPreviewSession(camera, camId, cm, surfaceTexture, handler)
                }
                override fun onDisconnected(camera: CameraDevice) {
                    runCatching { camera.close() }
                    hide("camera_disconnected")
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    mainHandler.post { statusBadge?.text = "카메라 열기 오류 (code=$error)" }
                    runCatching { camera.close() }
                }
            }, handler)
        }.onFailure {
            mainHandler.post { statusBadge?.text = "카메라 접근 실패: ${it.javaClass.simpleName}" }
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreviewSession(
        camera: CameraDevice,
        camId: String,
        cm: CameraManager,
        surfaceTexture: SurfaceTexture,
        handler: Handler
    ) {
        runCatching {
            surfaceTexture.setDefaultBufferSize(1280, 720)
            val surface = Surface(surfaceTexture)
            activeSurface = surface
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                // Also apply hardware AE exposure compensation if supported by the camera HAL
                runCatching {
                    val range = cm.getCameraCharacteristics(camId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                    if (range != null && range.lower < range.upper) {
                        val normalized = BsdCameraPreferences.brightness(app) / 50f
                        val aeVal = (normalized * range.upper).toInt().coerceIn(range.lower, range.upper)
                        set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, aeVal)
                    }
                }
            }
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (cameraDevice == null) { runCatching { session.close() }; return }
                    captureSession = session
                    runCatching { session.setRepeatingRequest(builder.build(), null, handler) }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    mainHandler.post { statusBadge?.text = "카메라 스트림 구성 실패" }
                }
            }, handler)
        }.onFailure {
            CoreLog.w("BSD_CAM", "startPreviewSession failed: ${it.message}")
        }
    }

    private fun closeCamera() {
        runCatching { captureSession?.stopRepeating() }
        runCatching { captureSession?.close() }
        captureSession = null
        runCatching { cameraDevice?.close() }
        cameraDevice = null
        runCatching { activeSurface?.release() }
        activeSurface = null
    }

    private fun removeOverlayView() {
        val view = overlayView ?: return
        overlayView = null
        textureView = null
        statusBadge = null
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        runCatching { wm.removeViewImmediate(view) }
    }
}
