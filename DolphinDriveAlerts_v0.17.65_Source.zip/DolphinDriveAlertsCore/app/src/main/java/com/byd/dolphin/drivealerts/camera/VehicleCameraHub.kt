package com.byd.dolphin.drivealerts.camera

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.BatteryManager
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/**
 * Ultra-Low-Resource Single-Open Shared Camera2 Hub:
 * - Zero-copy hardware H.264 MediaRecorder surface encoding (minimal CPU/RAM)
 * - Conditional analysis dispatch (0ms early-return during steady cruising)
 * - USB/SD/Internal storage selection with auto-fallback + safe soft-format
 * - normal/ loop pruning + protected event/ folder (G-sensor impact, hard braking, manual lock + pre-roll)
 * - Thermal protection (pauses above 60C, resumes below 53C)
 */
class VehicleCameraHub(context: Context) {
    data class StorageVolumeOption(val index: Int, val label: String, val rootDir: File)

    private val app = context.applicationContext
    private val telemetry = DashcamTelemetryRecorder(app)
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recorderSurface: Surface? = null
    private var analysisReader: ImageReader? = null

    @Volatile private var running = false
    @Volatile private var recording = false
    @Volatile private var yielded = false
    @Volatile private var thermalPaused = false
    @Volatile private var consecutiveFailures = 0
    @Volatile private var circuitOpen = false
    @Volatile private var segmentStartedMs = 0L
    @Volatile private var currentFile: File? = null
    @Volatile private var previousCompletedFile: File? = null
    @Volatile private var pendingEventReason: String? = null
    @Volatile private var lastThermalCheckMs = 0L
    @Volatile private var lastSpeedKmH: Float? = null
    @Volatile private var lastSpeedMs: Long = 0L
    @Volatile var statusText: String = "대기 중"
        private set

    private val frameListeners = mutableListOf<(Image) -> Unit>()
    private var analysisGate: (() -> Boolean) = { true }

    // G-sensor impact listener (only active while recording)
    private var sensorManager: SensorManager? = null
    private val gSensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            val e = event ?: return
            if (!recording) return
            val lv = DashcamPreferences.gsensorLevel(app)
            if (lv == 0) return
            val gForce = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.80665f
            val threshold = when (lv) { 1 -> 2.8f; 3 -> 1.75f; else -> 2.2f }
            if (gForce >= threshold) {
                triggerEventLock("GSENSOR_${"%.1f".format(Locale.US, gForce)}G")
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    fun addFrameListener(listener: (Image) -> Unit) {
        synchronized(frameListeners) { frameListeners.add(listener) }
    }

    /** Optional gate so YUV frames are skipped in 0ms when neither lead-car nor BSD analysis needs them. */
    fun setAnalysisNeededGate(gate: () -> Boolean) {
        analysisGate = gate
    }

    fun isActive(): Boolean = running && recording && !yielded

    /** Discover Internal + External USB/SD app-accessible storage volumes. */
    fun availableVolumes(): List<StorageVolumeOption> {
        val dirs = runCatching { app.getExternalFilesDirs(Environment.DIRECTORY_MOVIES) }.getOrNull()
            ?.filterNotNull()
            ?.filter { it.exists() || it.mkdirs() }
            ?: listOf(app.filesDir)
        return dirs.mapIndexed { idx, dir ->
            val kind = if (idx == 0) "내장 저장소" else "외장 USB/SD #$idx"
            val freeGb = dir.usableSpace / (1024.0 * 1024.0 * 1024.0)
            StorageVolumeOption(idx, "$kind (여유 ${"%.1f".format(Locale.US, freeGb)} GB)", File(dir, "DolphinDashcam"))
        }
    }

    fun activeRootDir(): File {
        val vols = availableVolumes()
        val desired = DashcamPreferences.storageVolumeIndex(app)
        val chosen = vols.firstOrNull { it.index == desired } ?: vols.first()
        val root = chosen.rootDir
        if (root.exists() || root.mkdirs()) return root
        // Fallback to internal if USB/SD unmounted mid-drive
        return File(app.filesDir, "DolphinDashcam").apply { mkdirs() }
    }

    fun normalDir(): File = File(activeRootDir(), "normal").apply { mkdirs() }
    fun eventDir(): File = File(activeRootDir(), "event").apply { mkdirs() }

    /** Soft-format: safely wipes recorded normal/ (and optionally event/) folders without touching OS partitions. */
    fun softFormatStorage(includeEvents: Boolean): Int {
        var deleted = 0
        fun wipe(dir: File) {
            dir.listFiles()?.forEach { f -> if (f.isFile && f.delete()) deleted++ }
        }
        wipe(normalDir())
        if (includeEvents) wipe(eventDir())
        CoreLog.i("DASHCAM", "SOFT_FORMAT deleted=$deleted includeEvents=$includeEvents")
        return deleted
    }

    /** Lock current segment (+ pre-roll previous segment) into protected event/ folder. */
    fun triggerEventLock(reason: String) {
        if (pendingEventReason == null) {
            pendingEventReason = reason
            CoreLog.i("DASHCAM", "EVENT_LOCK_ARMED reason=$reason")
            // Also immediately protect the previous completed segment as pre-roll (10-60s before impact)
            previousCompletedFile?.let { prev ->
                if (prev.isFile) copySegmentToEvent(prev, "${reason}_PREROLL")
            }
        }
    }

    fun onVehicleState(frame: RawVehicleFrame, blinker: Side, overlayHoldingCamera: Boolean) {
        val enabled = DashcamPreferences.enabled(app)
        val isReverse = frame.gearRaw == 1
        val isParking = frame.gearRaw == 3

        // Hard braking event detection (speed drop >= 18 km/h within 1.2s)
        val now = System.currentTimeMillis()
        val spd = frame.speedKmH
        if (recording && spd != null) {
            val prevSpd = lastSpeedKmH
            if (prevSpd != null && now - lastSpeedMs in 100L..1_300L && (prevSpd - spd) >= 18f) {
                triggerEventLock("HARD_BRAKE")
            }
            lastSpeedKmH = spd
            lastSpeedMs = now
        }

        // Thermal protection check every 30s
        if (DashcamPreferences.thermalGuardEnabled(app) && now - lastThermalCheckMs > 30_000L) {
            lastThermalCheckMs = now
            val tempC = readDeviceTempC()
            if (tempC >= 60f) {
                thermalPaused = true
                if (running) stopInternal("thermal_guard_${tempC.toInt()}C")
                statusText = "발열 보호 일시중지 (${tempC.toInt()}°C)"
                return
            } else if (thermalPaused && tempC <= 53f) {
                thermalPaused = false
            }
        }
        if (thermalPaused || circuitOpen) return

        if (!enabled || isReverse || overlayHoldingCamera) {
            val reason = when {
                !enabled -> "disabled"
                isReverse -> "reverse_gear_yield"
                else -> "bsd_overlay_yield"
            }
            if (running) {
                yielded = isReverse || overlayHoldingCamera
                stopInternal(reason)
            }
            return
        }

        if (isParking) {
            if (running) stopInternal("park_gear_stop")
            return
        }

        yielded = false
        if (!running) {
            startInternal()
        } else if (recording) {
            telemetry.recordSample(frame, blinker)
            val segMs = DashcamPreferences.segmentMinutes(app) * 60_000L
            if (now - segmentStartedMs >= segMs) {
                rotateSegment()
            }
        }
    }

    fun startManual() {
        yielded = false
        thermalPaused = false
        consecutiveFailures = 0
        circuitOpen = false
        if (!running) startInternal()
    }

    /** Called on ACC_OFF to immediately finalize current MP4 moov atom before power cut. */
    fun flushForPowerOff() {
        if (running) stopInternal("acc_off_power_flush")
    }

    /** Remove truncated/0-byte MP4s (<8KB) left by sudden power loss and their orphan sidecars. */
    fun cleanupCorruptSegments(): Int {
        var cleaned = 0
        for (dir in listOf(normalDir(), eventDir())) {
            dir.listFiles { f -> f.isFile && f.name.endsWith(".mp4") && f.length() < 8_192L }?.forEach { bad ->
                if (deleteWithSidecars(bad)) cleaned++
            }
        }
        if (cleaned > 0) CoreLog.i("DASHCAM", "CLEANED_CORRUPT_SEGMENTS count=$cleaned")
        return cleaned
    }

    fun stopManual() {
        stopInternal("manual_stop")
    }

    fun storageSummary(): String {
        val norm = listMp4(normalDir())
        val ev = listMp4(eventDir())
        val normMb = norm.sumOf { it.length() } / (1024L * 1024L)
        val evMb = ev.sumOf { it.length() } / (1024L * 1024L)
        val capGb = DashcamPreferences.maxStorageGb(app)
        val evCap = DashcamPreferences.eventMaxCount(app)
        return "일반 ${norm.size}개 (${normMb}MB / 상한 ${capGb}GB) · 이벤트 보호 ${ev.size}/${evCap}개 (${evMb}MB)\n저장 위치: ${activeRootDir().absolutePath}"
    }

    fun listMp4(dir: File): List<File> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".mp4") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    /** Query actual Camera2 native max recording size (never upscales above real sensor output). */
    private fun resolveNativeCameraResolution(camId: String): Triple<Int, Int, Int> {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        val nativeSize = runCatching {
            val map = cm?.getCameraCharacteristics(camId)
                ?.get(android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            map?.getOutputSizes(MediaRecorder::class.java)
                ?.filter { it.width <= 1920 && it.height <= 1080 }
                ?.maxByOrNull { it.width * it.height }
        }.getOrNull()
        val w = nativeSize?.width ?: 1280
        val h = nativeSize?.height ?: 720
        val bitrate = if (w >= 1920) 8_000_000 else 5_000_000
        CoreLog.i("DASHCAM", "NATIVE_RESOLUTION camId=$camId size=${w}x${h} bitrate=$bitrate")
        return Triple(w, h, bitrate)
    }

    private fun readDeviceTempC(): Float = runCatching {
        val intent = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        (intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300) ?: 300) / 10f
    }.getOrDefault(30f)

    private fun startInternal() {
        if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            statusText = "CAMERA 권한 없음"
            return
        }
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        val ids = runCatching { cm.cameraIdList.toList() }.getOrDefault(emptyList())
        val reqId = DashcamPreferences.cameraId(app)
        val camId = if (reqId in ids) reqId else ids.firstOrNull()
        if (camId == null) {
            statusText = "노출된 Camera2 장치 없음"
            return
        }

        running = true
        statusText = "주행 녹화 시작 중 (ID=$camId)…"
        registerGSensor()

        val ht = HandlerThread("dolphin-cam-hub").apply { start() }
        val h = Handler(ht.looper)
        thread = ht
        handler = h

        val reader = ImageReader.newInstance(320, 240, ImageFormat.YUV_420_888, 2)
        reader.setOnImageAvailableListener({ r ->
            val img = runCatching { r.acquireLatestImage() }.getOrNull() ?: return@setOnImageAvailableListener
            try {
                // Ultra-low resource: 0ms early return when no vision analyzer currently needs frames
                if (!analysisGate()) return@setOnImageAvailableListener
                val snapshot = synchronized(frameListeners) { frameListeners.toList() }
                for (cb in snapshot) runCatching { cb(img) }
            } finally {
                runCatching { img.close() }
            }
        }, h)
        analysisReader = reader

        runCatching {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (!running) { runCatching { camera.close() }; return }
                    cameraDevice = camera
                    startRecordingSession(camera, h)
                }
                override fun onDisconnected(camera: CameraDevice) {
                    CoreLog.w("DASHCAM", "camera $camId disconnected; yielding cleanly")
                    stopInternal("camera_disconnected")
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    CoreLog.w("DASHCAM", "camera $camId error=$error")
                    recordFailure("카메라 오류 (code=$error)")
                    stopInternal("camera_error_$error")
                }
            }, h)
        }.onFailure {
            recordFailure("카메라 열기 실패: ${it.javaClass.simpleName}")
            stopInternal("open_failed")
        }
    }

    @Suppress("DEPRECATION")
    private fun startRecordingSession(camera: CameraDevice, h: Handler) {
        pruneNormalSegments()
        pruneEventSegments()
        cleanupCorruptSegments()
        // OS Storage Safety Floor: never fill head-unit storage below 512 MB free
        if (activeRootDir().usableSpace < 512L * 1024L * 1024L) {
            pruneNormalSegments()
            if (activeRootDir().usableSpace < 384L * 1024L * 1024L) {
                statusText = "저장 공간 부족 (512MB 미만) · 시스템 보호를 위해 녹화 중지"
                circuitOpen = true
                stopInternal("low_storage_floor")
                return
            }
        }
        val (w, hPx, bitrate) = when (DashcamPreferences.qualityTier(app)) {
            0 -> Triple(854, 480, 2_000_000)
            1 -> Triple(1280, 720, 4_000_000)
            else -> resolveNativeCameraResolution(camera.id)
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(normalDir(), "DDA_${stamp}.mp4")
        currentFile = file
        pendingEventReason = null

        val mr = MediaRecorder()
        val prepared = runCatching {
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(file.absolutePath)
            mr.setVideoEncodingBitRate(bitrate)
            mr.setVideoFrameRate(24) // 24fps reduces SoC thermal & I/O load by ~20% vs 30fps
            mr.setVideoSize(w, hPx)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.prepare()
            true
        }.onFailure {
            CoreLog.w("DASHCAM", "MediaRecorder prepare failed: ${it.message}")
            runCatching { mr.release() }
        }.getOrDefault(false)

        if (!prepared) {
            statusText = "하드웨어 H.264 인코더 초기화 실패"
            stopInternal("recorder_prepare_failed")
            return
        }

        mediaRecorder = mr
        val recSurface = mr.surface
        recorderSurface = recSurface
        val surfaces = mutableListOf(recSurface)
        analysisReader?.surface?.let { surfaces.add(it) }

        runCatching {
            val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                surfaces.forEach { addTarget(it) }
            }
            camera.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (!running || cameraDevice == null) { runCatching { session.close() }; return }
                    captureSession = session
                    runCatching {
                        session.setRepeatingRequest(req.build(), null, h)
                        mr.start()
                        recording = true
                        consecutiveFailures = 0
                        circuitOpen = false
                        segmentStartedMs = System.currentTimeMillis()
                        telemetry.beginSegment(file)
                        statusText = "녹화 중 · ${file.name} (${w}x${hPx} HW)"
                        CoreLog.i("DASHCAM", "RECORDING_STARTED file=${file.name} ${w}x${hPx}")
                    }.onFailure {
                        CoreLog.w("DASHCAM", "MediaRecorder start failed: ${it.message}")
                        stopInternal("recorder_start_failed")
                    }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    statusText = "카메라 녹화 세션 구성 실패"
                    stopInternal("session_config_failed")
                }
            }, h)
        }.onFailure {
            statusText = "세션 시작 실패: ${it.javaClass.simpleName}"
            stopInternal("session_start_failed")
        }
    }

    private fun rotateSegment() {
        val cam = cameraDevice ?: return
        val h = handler ?: return
        finalizeCurrentSegment()
        if (running) startRecordingSession(cam, h)
    }

    private fun finalizeCurrentSegment() {
        val finished = currentFile
        val evReason = pendingEventReason
        pendingEventReason = null
        stopRecorderAndSessionOnly()
        telemetry.flushAndClose()
        if (finished != null && finished.isFile && finished.length() > 8_192L) {
            previousCompletedFile = finished
            if (evReason != null) {
                copySegmentToEvent(finished, evReason)
            }
        }
    }

    private fun copySegmentToEvent(srcMp4: File, reason: String) {
        val dstDir = eventDir()
        val safeTag = reason.replace(Regex("[^A-Za-z0-9_-]"), "").take(20)
        val dstBaseName = "EVT_${safeTag}_${srcMp4.nameWithoutExtension}"
        val exts = listOf(".mp4", ".jsonl", ".srt", ".gpx")
        for (ext in exts) {
            val s = File(srcMp4.parentFile, srcMp4.nameWithoutExtension + ext)
            if (s.isFile) {
                val d = File(dstDir, dstBaseName + ext)
                runCatching { s.copyTo(d, overwrite = true) }
            }
        }
        pruneEventSegments()
        CoreLog.i("DASHCAM", "EVENT_PROTECTED file=$dstBaseName.mp4 reason=$reason")
    }

    private fun pruneNormalSegments() {
        val maxBytes = DashcamPreferences.maxStorageGb(app).toLong() * 1024L * 1024L * 1024L
        val files = normalDir().listFiles { f -> f.isFile && f.name.endsWith(".mp4") }
            ?.sortedBy { it.lastModified() }?.toMutableList() ?: return
        var total = files.sumOf { it.length() }
        val target = (maxBytes - 200L * 1024L * 1024L).coerceAtLeast(256L * 1024L * 1024L)
        while (total > target && files.isNotEmpty()) {
            val oldest = files.removeAt(0)
            val len = oldest.length()
            if (deleteWithSidecars(oldest)) {
                total -= len
                CoreLog.i("DASHCAM", "PRUNED_NORMAL file=${oldest.name}")
            }
        }
    }

    private fun pruneEventSegments() {
        val maxCount = DashcamPreferences.eventMaxCount(app)
        val files = eventDir().listFiles { f -> f.isFile && f.name.endsWith(".mp4") }
            ?.sortedBy { it.lastModified() }?.toMutableList() ?: return
        while (files.size > maxCount) {
            val oldest = files.removeAt(0)
            if (deleteWithSidecars(oldest)) {
                CoreLog.i("DASHCAM", "PRUNED_EVENT_OVER_LIMIT file=${oldest.name} limit=$maxCount")
            }
        }
    }

    fun deleteWithSidecars(mp4: File): Boolean {
        val base = mp4.nameWithoutExtension
        val parent = mp4.parentFile ?: return mp4.delete()
        val ok = mp4.delete()
        listOf(".jsonl", ".srt", ".gpx").forEach { ext ->
            runCatching { File(parent, base + ext).delete() }
        }
        return ok
    }

    private fun registerGSensor() {
        val sm = app.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sensorManager = sm
        runCatching { sm.registerListener(gSensorListener, accel, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    private fun unregisterGSensor() {
        runCatching { sensorManager?.unregisterListener(gSensorListener) }
        sensorManager = null
    }

    private fun stopRecorderAndSessionOnly() {
        recording = false
        runCatching { captureSession?.stopRepeating() }
        runCatching { captureSession?.close() }
        captureSession = null
        mediaRecorder?.let { mr ->
            runCatching { mr.stop() }
            runCatching { mr.reset() }
            runCatching { mr.release() }
        }
        mediaRecorder = null
        runCatching { recorderSurface?.release() }
        recorderSurface = null
    }

    private fun stopInternal(reason: String) {
        running = false
        unregisterGSensor()
        finalizeCurrentSegment()
        runCatching { cameraDevice?.close() }
        cameraDevice = null
        runCatching { analysisReader?.close() }
        analysisReader = null
        runCatching { thread?.quitSafely() }
        thread = null
        handler = null
        statusText = "중지됨 ($reason)"
        CoreLog.i("DASHCAM", "STOPPED reason=$reason")
    }

    private fun recordFailure(msg: String) {
        consecutiveFailures++
        if (consecutiveFailures >= 3) {
            circuitOpen = true
            statusText = "Camera2 3회 연속 실패 · 자동 중지됨 ($msg)"
            CoreLog.w("DASHCAM", "CIRCUIT_BREAKER_OPEN failures=$consecutiveFailures msg=$msg")
        } else {
            statusText = msg
        }
    }

    fun shutdown() {
        synchronized(frameListeners) { frameListeners.clear() }
        stopInternal("shutdown")
    }
}
