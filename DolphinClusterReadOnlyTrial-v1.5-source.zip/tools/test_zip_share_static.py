from pathlib import Path
import re
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
main=(p/'app/src/main/java/com/dolphin/clusterprobe/MainActivity.java').read_text()
prov=(p/'app/src/main/java/com/dolphin/clusterprobe/DiagnosticZipProvider.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
html=(p/'app/src/main/assets/cluster_preview.html').read_text()
gradle=(p/'app/build.gradle').read_text()
checks={
 'share stream zip': 'Intent.EXTRA_STREAM' in main and 'application/zip' in main,
 'grant uri permission': 'FLAG_GRANT_READ_URI_PERMISSION' in main and 'ClipData.newUri' in main,
 'explicit save document': 'Intent.ACTION_CREATE_DOCUMENT' in main and 'openOutputStream' in main,
 'zip content': all(v in main for v in ('diagnostics.txt','status.json','README_KO.txt','ZipOutputStream')),
 'read-only scoped provider': 'MODE_READ_ONLY' in prov and 'if (!ZIP_URI.equals(uri))' in prov,
 'provider declared': 'com.dolphin.clusterprobe.v15.diagnostics' in manifest and 'grantUriPermissions="true"' in manifest,
 'separate install package': "applicationId 'com.dolphin.clusterprobe.v15'" in gradle,
 'old webview no aspect ratio only': 'padding-top:37.5%' in html and 'aspect-ratio:8/3' not in html,
 'no OEM file writing': '/system/lib64/cluster_theme' not in main,
 'version': "versionName '1.5-chain-readonly-wizard'" in gradle,
}
try: ET.fromstring(manifest); checks['manifest XML']=True
except ET.ParseError: checks['manifest XML']=False
for name, result in checks.items():
 print(('PASS ' if result else 'FAIL ')+name)
if not all(checks.values()): raise SystemExit(1)
