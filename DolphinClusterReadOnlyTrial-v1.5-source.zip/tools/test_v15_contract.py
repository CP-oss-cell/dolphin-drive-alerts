from pathlib import Path
import json, zipfile, xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
a=p/'app/src/main/java/com/dolphin/clusterprobe/'
wad=(a/'StageWizardActivity.java').read_text()
adb=(a/'LocalAdb.java').read_text()
cat=(a/'ProbeCatalog.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'wizard manifest declared': '.StageWizardActivity' in manifest,
 'wizard provider declared': '.WizardZipProvider' in manifest,
 'one installation step wizard': all(x in wad for x in ['discoverProcessesInternal','inspectProcess','inspectLibrary','inspectDisplays','finalCheck']),
 'candidate choosing buttons': 'PID ' in wad and '단서 선택:' in wad and '확인: ' in wad,
 'ADB session reuse': 'connectSession' in adb and 'queryReadOnly' in adb,
 'ADB only local': '127.0.0.1' in adb and '5555' in adb,
 'allowlist rejects arbitrary commands': 'throw new SecurityException' in adb,
 'unsafe shell never offered': all(x not in adb for x in ['am force-stop','reboot','mount -o','chmod 777','setprop ','stop fissiond','start FissionHostSvc','pm grant','WriteData']),
 'read only map pid sanitized': '[0-9]{1,7}' in adb and 'ls -l /(system|vendor)/lib64/' in adb,
 'diagnostic has gates': 'oem_theme_write_permitted' in wad and 'oem_5inch_mapping_verified' in wad,
 'zip share & file save': 'ZipOutputStream' in wad and 'ACTION_SEND' in wad and 'ACTION_CREATE_DOCUMENT' in wad,
 'plan controlled': 'ProbeCatalog.command(id)' in wad and 'run_any_shell' not in cat,
 'plan survives restart': 'saveStoredPlan()' in wad and 'loadStoredPlan()' in wad,
 'App no HOME override': 'android.intent.category.HOME' not in manifest,
 'no vehicle bind privileged': 'WRITE_SECURE_SETTINGS' not in manifest,
 'Android manifest wellformed': True,
}
try:ET.fromstring(manifest)
except ET.ParseError:checks['Android manifest wellformed']=False
plan=json.loads((p/'extra-probe-plan-example.json').read_text())
checks['plan example syntactically valid']=len(plan['probes'])>=4 and all('probe_id' in x for x in plan['probes'])
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()),'V1.5 contract gates failed'
