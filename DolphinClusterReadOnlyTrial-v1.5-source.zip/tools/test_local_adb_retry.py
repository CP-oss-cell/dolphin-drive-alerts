"""Local handshake regression: first adbd connection ends; client should retry with same key."""
import socket, threading, struct, subprocess, os, tempfile, re
CNXN=0x4e584e43; AUTH=0x48545541; OPEN=0x4e45504f; OKAY=0x59414b4f; WRTE=0x45545257; CLSE=0x45534c43

def recvall(s,n):
 data=b''
 while len(data)<n:
  part=s.recv(n-len(data))
  if not part: raise EOFError('closed')
  data+=part
 return data

def recv(s):
 c,a1,a2,l,ck,magic=struct.unpack('<6I',recvall(s,24))
 d=recvall(s,l)
 assert c ^ 0xffffffff == magic and ck in (sum(d),0)
 return c,a1,a2,d

def send(s,c,a1=0,a2=0,data=b''):
 s.sendall(struct.pack('<6I',c,a1,a2,len(data),sum(data)&0xffffffff,c^0xffffffff)+data)

ready=threading.Event()
seen=[]
def mock():
 with socket.socket() as server:
  server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
  server.bind(('127.0.0.1',5555));server.listen(2);ready.set()
  # First accepted connection drops after client CNXN.
  with server.accept()[0] as s:
   assert recv(s)[0] == CNXN
   seen.append('first_dropped')
  # Retry accepts same client's key, no need to reauthorize.
  with server.accept()[0] as s:
   s.settimeout(8)
   assert recv(s)[0] == CNXN
   send(s, AUTH, 1, 0, bytes(range(20)))
   typ,_,_,sig=recv(s);assert typ==AUTH and len(sig)==256
   send(s, AUTH, 1, 0, bytes(range(1,21)))
   typ,_,_,key=recv(s);assert typ==AUTH and b'dolphin-cluster@vehicle' in key
   send(s,CNXN,0x1000000,4096,b'device::\0')
   for i in range(5):
    c,a1,a2,data=recv(s);assert c==OPEN
    send(s,OKAY,10+i,a1)
    send(s,WRTE,10+i,a1,b'RETRY_OK_'+str(i).encode()+b'\n')
    assert recv(s)[0]==OKAY
    send(s,CLSE,10+i,a1)
    assert recv(s)[0]==CLSE
   seen.append('retry_connected')

thread=threading.Thread(target=mock,daemon=True);thread.start();assert ready.wait(5)
cp='app/src/main/java/com/dolphin/clusterprobe/LocalAdb.java'
subprocess.run(['javac','-d','/tmp/adbjavac',cp,'tools/TestLocalAdb.java'],check=True)
p=subprocess.run(['java','-cp','/tmp/adbjavac','TestLocalAdb'],text=True,capture_output=True,timeout=17)
print(p.stdout[:1100]);print(p.stderr[:800])
assert p.returncode==0
assert 'RETRY_OK_4' in p.stdout
assert 'ADB 2/2' in p.stdout
assert seen==['first_dropped','retry_connected']
print('PASS ADB dropped-socket retry mock')
