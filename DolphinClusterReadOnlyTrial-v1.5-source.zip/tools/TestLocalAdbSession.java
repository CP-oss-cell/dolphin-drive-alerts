import java.io.File;
import com.dolphin.clusterprobe.LocalAdb;
public final class TestLocalAdbSession {
 public static void main(String[] args)throws Exception{
  try(LocalAdb adb=new LocalAdb(new File(args[0]))){
    adb.connectSession(s->System.out.println("AUTH: "+s));
    for(String c:new String[]{"id","ps -A","cat /proc/123/maps","dumpsys display"}){
      String o=adb.queryReadOnly(c);
      if(!o.contains("MOCK_WIZARD_OK"))throw new IllegalStateException(c+" => "+o);
      System.out.println("PASS step: "+c);
    }
    try{adb.queryReadOnly("setprop persist.debug 1");throw new AssertionError("unsafe command accepted");}
    catch(SecurityException expected){System.out.println("PASS blocked unsafe command");}
    try{adb.queryReadOnly("cat /proc/123/maps;id");throw new AssertionError("command injection accepted");}
    catch(SecurityException expected){System.out.println("PASS rejected command injection");}
  }
 }
}
