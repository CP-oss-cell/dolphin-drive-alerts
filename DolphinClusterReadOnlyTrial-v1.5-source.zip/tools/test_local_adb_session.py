"""Test persistent connectSession and 4 sequential allowlisted read-only shells on one TCP ADB socket."""
import socket,threading,struct,subprocess,tempfile
CNXN=0x4e584e43;AUTH=0x48545541;OPEN=0x4e45504f;OKAY=0x59414b4f;WRTE=0x45545257;CLSE=0x45534c43

def recvall(s,n):
 b=b''
 while len(b)<n:
  chunk=s.recv(n-len(b))
  if not chunk:raise EOFError('disconnect')
  b+=chunk
 return b

def recv(s):
 cmd,a,b,n,c,m=struct.unpack('<6I',recvall(s,24));data=recvall(s,n)
 assert (cmd^0xffffffff)==m
 return cmd,a,b,data

def send(s,cmd,a=0,b=0,payload=b''):
 s.sendall(struct.pack('<6I',cmd,a,b,len(payload),sum(payload)&0xffffffff,cmd^0xffffffff)+payload)
ready=threading.Event();seen=[]
def serve():
 with socket.socket() as sock:
  sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
  sock.bind(('127.0.0.1',5555));sock.listen(1);ready.set()
  with sock.accept()[0] as s:
   s.settimeout(14)
   assert recv(s)[0]==CNXN
   send(s,AUTH,1,0,bytes(range(20)))
   assert recv(s)[0]==AUTH
   send(s,AUTH,1,0,bytes(range(1,21)))
   assert recv(s)[0]==AUTH
   send(s,CNXN,0x1000000,4096,b'device::\0')
   for j in range(4):
    cmd,local,_,shell=recv(s)
    assert cmd==OPEN and shell.startswith(b'shell:')
    seen.append(shell[6:-1].decode())
    remote=90+j
    send(s,OKAY,remote,local)
    send(s,WRTE,remote,local,b'MOCK_WIZARD_OK\n')
    assert recv(s)[0]==OKAY
    send(s,CLSE,remote,local)
    assert recv(s)[0]==CLSE
thread=threading.Thread(target=serve,daemon=True);thread.start();assert ready.wait(4)
with tempfile.TemporaryDirectory() as tmp:
 cp='app/src/main/java/com/dolphin/clusterprobe/LocalAdb.java'
 subprocess.run(['javac','-d',tmp,cp,'tools/TestLocalAdbSession.java'],check=True)
 result=subprocess.run(['java','-cp',tmp,'TestLocalAdbSession',tmp],capture_output=True,text=True,timeout=24)
 print(result.stdout);print(result.stderr)
 assert result.returncode==0,result.stderr
thread.join(1)
assert seen==['id','ps -A','cat /proc/123/maps','dumpsys display'],seen
print('PASS persistent session + branch read-only allowlist mock')
