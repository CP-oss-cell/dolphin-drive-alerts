import com.dolphin.clusterprobe.LocalAdb;
import java.io.File;
public class TestLocalAdb {
  public static void main(String[] args) throws Exception {
    File store = new File("/tmp/cluster-local-adb-test"); store.mkdirs();
    try (LocalAdb local = new LocalAdb(store)) {
       String txt = local.checkAndRead(System.out::println);
       System.out.println(txt);
       if (!txt.contains("OK_MOCK_4") && !txt.contains("RETRY_OK_4")) throw new IllegalStateException("Missing response");
    }
  }
}
