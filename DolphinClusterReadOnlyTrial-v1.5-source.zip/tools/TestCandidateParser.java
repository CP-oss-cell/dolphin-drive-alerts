import java.util.*;
import com.dolphin.clusterprobe.CandidateParser;
import com.dolphin.clusterprobe.ProbeCatalog;
public final class TestCandidateParser {
 private static void yes(boolean x,String name){if(!x)throw new AssertionError(name);System.out.println("PASS "+name);}
 public static void main(String[] args){
  List<String> ps=CandidateParser.processes("USER PID PPID NAME\nroot 218 1 fission_service\nshell 114 1 com.example.app\nroot 221 1 fissiond\n");
  yes(ps.size()==2 && ps.get(0).startsWith("218|"),"PID candidates exact");
  yes(CandidateParser.processes("Permission denied").isEmpty(),"denied not candidate");
  List<String> libs=CandidateParser.libraries("7aa /system/lib64/libBydCluster.so\n7bb /system/lib64/libBydDataSource.so\n7cc /data/unsafe.so\n");
  yes(libs.size()==2,"allowlisted library roots only");
  yes(CandidateParser.libraries("Permission denied").isEmpty(),"maps blocked not success");
  yes(CandidateParser.displays("PhysicalDisplayInfo: 1280x720","cluster_layer\nother_layer").size()==2,"display evidence markers");
  yes(ProbeCatalog.command("fissiond_status").equals("getprop init.svc.fissiond"),"plan enum lookup");
  yes(ProbeCatalog.command("run_any_shell")==null,"unknown plan rejected");
 }
}
