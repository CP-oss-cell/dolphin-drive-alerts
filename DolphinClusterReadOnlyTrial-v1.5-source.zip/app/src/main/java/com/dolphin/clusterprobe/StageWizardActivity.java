package com.dolphin.clusterprobe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** One-install, user-steered chain of read-only diagnostic probes; NEVER tests OEM writes. */
public final class StageWizardActivity extends Activity {
    private static final int BG=Color.rgb(6,16,28), FG=Color.rgb(227,238,249), GOLD=Color.rgb(255,208,128);
    private static final int REQ_PLAN=401, REQ_SAVE=402;
    private static final Pattern LIB=Pattern.compile("/(?:system|vendor)/lib64/[A-Za-z0-9_.+-]+\\.so");
    private static final Pattern TARGET=Pattern.compile("(?i)fission|cluster|byd|cell|surfaceflinger");
    private final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private final StringBuilder evidence=new StringBuilder();
    private final ArrayList<JSONObject> events=new ArrayList<>();
    private final ArrayList<String> processCandidates=new ArrayList<>(), libraryCandidates=new ArrayList<>(), displayCandidates=new ArrayList<>();
    private final LinkedHashMap<String,String> extraProbes=new LinkedHashMap<>();
    private LocalAdb adb;
    private LinearLayout options;
    private TextView header, content;
    private int stage=0, selectedPid=-1;
    private String selectedProcess="", selectedLibrary="", selectedDisplay="";
    private volatile boolean busy=false, connected=false, dead=false;
    private String status="NOT_STARTED";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adb=new LocalAdb(getFilesDir());
        loadStoredPlan();
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        header=new TextView(this);header.setTextColor(GOLD);header.setTextSize(17);
        header.setPadding(dp(15),dp(12),dp(15),dp(7));root.addView(header);
        TextView warning=new TextView(this);
        warning.setText("정차·P단에서만 사용 | 읽기 전용 | 순정 계기판·테마·차량 명령 변경 금지");
        warning.setTextColor(Color.rgb(244,185,123));warning.setTextSize(13);
        warning.setPadding(dp(15),dp(3),dp(15),dp(8));root.addView(warning);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actions);
        addButton(actions,"처음부터",()->reset());
        addButton(actions,"추가 검사 플랜",()->pickPlan());
        addButton(actions,"진단 ZIP 공유",()->share());
        addButton(actions,"ZIP 저장",()->save());
        ScrollView sc=new ScrollView(this);LinearLayout column=new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);sc.addView(column);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        content=new TextView(this);content.setTextColor(FG);content.setTextSize(14);
        content.setPadding(dp(18),dp(14),dp(18),dp(12));column.addView(content);
        options=new LinearLayout(this);options.setOrientation(LinearLayout.VERTICAL);
        options.setPadding(dp(12),dp(0),dp(12),dp(18));column.addView(options);
        setContentView(root);
        record("INFO","wizard","V1.5 started; no OEM modifications");
        render("ADB는 차량 내부 127.0.0.1:5555를 사용합니다.\n\n"
            +"1단계 연결 성공 시 서비스·프로세스를 탐색합니다.\n"
            +"후보를 직접 눌러 다음 단계로 진행합니다.\n"
            +"권한 거부는 BLOCKED로 보존하며 우회하지 않습니다.\n\n"
            +"인증이 실패해도 앱을 다시 설치할 필요는 없습니다.");
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private Button addButton(LinearLayout parent,String title,Runnable action){
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTextSize(12);
        parent.addView(b,parent.getOrientation()==LinearLayout.HORIZONTAL
            ?new LinearLayout.LayoutParams(0,dp(46),1)
            :new LinearLayout.LayoutParams(-1,dp(46)));
        b.setOnClickListener(v->{if(!busy)action.run();});return b;
    }
    private void render(String text) {
        if(dead)return;
        header.setText("계기판 연속 시험 · V1.5  /  " + new String[]{"1. 로컬 ADB","2. 호스트·프로세스","3. 선택 PID 맵","4. 선택 라이브러리","5. 화면 출력 단서","6. 최종 판정"}[Math.min(stage,5)]);
        content.setText(text);options.removeAllViews();
        if(stage==0) addButton(options,"① ADB 연결 후 서비스 자동 탐색",this::connect);
        if(stage==1) {
            addButton(options,"② 프로세스 목록 새로 검색",this::discoverProcesses);
            for(String line:new ArrayList<>(processCandidates)) {
                String[] parts=line.split("\\|",2); int pid=Integer.parseInt(parts[0]);
                addButton(options,"PID " + pid + " · " + parts[1],()->inspectProcess(pid,parts[1]));
            }
            addButton(options,"프로세스 후보 없음/접근거부 → 화면 단서 확인",this::inspectDisplays);
        }
        if(stage==2){
            for(String path:new ArrayList<>(libraryCandidates))
                addButton(options,"확인: " + path,()->inspectLibrary(path));
            addButton(options,"라이브러리 후보 없음/접근거부 → 화면 단서 확인",this::inspectDisplays);
        }
        if(stage==3) addButton(options,"④ 화면 출력 경로 탐색",this::inspectDisplays);
        if(stage==4){
            for(String s:new ArrayList<>(displayCandidates))
                addButton(options,"단서 선택: " + shortText(s,78),()->finalCheck(s));
            addButton(options,"화면 단서 없음/접근거부 → 최종 판정",()->finalCheck("NO_DISPLAY_MATCH"));
        }
        if(stage==5){
            addButton(options,"재탐색: 호스트·프로세스",()->{stage=1;discoverProcesses();});
            addButton(options,"재탐색: 화면 출력 단서",this::inspectDisplays);
            addButton(options,"진단 ZIP 공유",this::share);
        }
        if(connected&&!extraProbes.isEmpty()) {
            addButton(options,"추가 검사 선택",this::showExtraProbes);
        }
    }
    private void reset(){
        if(busy)return;
        try{adb.close();}catch(Exception ignored){}
        adb=new LocalAdb(getFilesDir());
        connected=false;stage=0;status="NOT_STARTED";selectedPid=-1;
        selectedProcess="";selectedLibrary="";selectedDisplay="";
        processCandidates.clear();libraryCandidates.clear();displayCandidates.clear();
        record("INFO","reset","manual reset; previous evidence retained");
        render("처음부터 시작합니다. 기존 증거는 ZIP에 남아 있습니다.");
    }
    private void perform(String name,Task job) {
        if(busy)return;busy=true;content.setText(name+" 실행 중…\n차량 승인창이 뜨면 허용하세요.\n다음 검사로 자동 이어지거나 후보 선택 버튼이 표시됩니다.");
        jobs.execute(()->{
            try{job.run();}catch(Exception ex){
                status="ERROR";record("ERROR",name,ex.getClass().getSimpleName()+": "+ex.getMessage());
                ui(()->render("실패: "+ex.getClass().getSimpleName()+": "+ex.getMessage()+"\n\n실차 권한/경로가 확인되지 않았습니다. 재시도하거나 ZIP을 공유하세요."));
            }finally{busy=false;}
        });
    }
    private interface Task{void run()throws Exception;}
    private void ui(Runnable r){runOnUiThread(()->{if(!dead)r.run();});}
    private void connect(){
        perform("ADB 인증",()->{
            adb.connectSession(s->{record("AUTH","adb",s);ui(()->content.setText("ADB 인증: "+s));});
            connected=true;status="AUTHORIZED";record("PASS","adb","ADB_CONNECTED_AND_AUTHORIZED");
            stage=1;
            discoverProcessesInternal();
        });
    }
    private String query(String label,String command){
        try{
            String result=adb.queryReadOnly(command).replace('\0',' ').trim();
            boolean denied=result.toLowerCase(Locale.ROOT).contains("permission denied") || result.contains("not permitted") || result.contains("(TIMEOUT)");
            record(denied?"BLOCKED":"OBSERVED",label+" :: "+command,shortText(result,10000));
            return result;
        }catch(Exception ex){
            record("BLOCKED",label+" :: "+command,ex.getClass().getSimpleName()+": "+ex.getMessage());
            return "[READ_FAILED] "+ex.getClass().getSimpleName()+": "+ex.getMessage();
        }
    }
    private void discoverProcesses(){perform("호스트 프로세스 탐색",this::discoverProcessesInternal);}
    private void discoverProcessesInternal(){
        stage=1;processCandidates.clear();
        String host=query("fissiond", "getprop init.svc.fissiond");
        String svc=query("FissionHostSvc", "getprop init.svc.FissionHostSvc");
        String who=query("shell-identity", "id");
        String ps=query("ps-list", "ps -A");
        processCandidates.addAll(CandidateParser.processes(ps));
        record("OBSERVED","process-candidates",processCandidates.toString());
        ui(()->render("ADB 상태: "+status+"\n\n"
            +"fissiond 서비스: "+shortText(host,100)+"\nFissionHostSvc 서비스: "+shortText(svc,100)
            +"\n셸: "+shortText(who,150)+"\n\n"
            +"탐색된 프로세스 후보: "+processCandidates.size()+"개\n"
            +"후보를 누르면 즉시 PID의 실행파일과 로드 라이브러리를 읽습니다.\n"
            +"※ 프로세스 이름이 비슷해도 5인치 계기판 사용 증거는 아닙니다."));
    }
    private void inspectProcess(int pid,String label){
        perform("PID "+pid+" 라이브러리 매핑",()->{
            selectedPid=pid;selectedProcess=label;stage=2;libraryCandidates.clear();
            String exe=query("PID-exe", "readlink /proc/"+pid+"/exe");
            String cmd=query("PID-cmd", "cat /proc/"+pid+"/cmdline");
            String maps=query("PID-maps", "cat /proc/"+pid+"/maps");
            libraryCandidates.addAll(CandidateParser.libraries(maps));
            record("OBSERVED","selected-process",pid+" "+label);
            ui(()->render("선택 프로세스: PID "+pid+" / "+label
                +"\n실행 파일: "+shortText(exe,350)
                +"\n명령행: "+shortText(cmd,350)
                +"\nmaps: "+(maps.startsWith("[READ_FAILED]")?maps:maps.toLowerCase(Locale.ROOT).contains("permission denied")?"권한 거부":"읽기 시도 완료")
                +"\n\n계기판/Qt 연관 라이브러리 후보: "+libraryCandidates.size()+"개\n"
                +"선택하면 해당 파일의 존재·권한을 검사합니다.\n"
                +"※ maps 접근 거부는 우회하지 않습니다."));
        });
    }
    private void inspectLibrary(String path){
        perform("선택된 라이브러리 검사",()->{
            selectedLibrary=path;stage=3;
            String info=query("mapped-library", "ls -l "+path);
            String themes=query("rcc-inventory", "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc");
            String host=query("fission-files", "ls -l /system/bin/fissiond /system/bin/fission_service /system/lib64/libfission_services.so");
            ui(()->render("선택한 라이브러리:\n"+path+"\n\n파일 정보:\n"+shortText(info,1500)
                +"\n\n기존 RCC:\n"+shortText(themes,1600)
                +"\n\nFission 호스트 파일:\n"+shortText(host,1600)
                +"\n\n이 정보는 정적 존재 확인입니다. 파일을 수정하지 않았습니다."));
        });
    }
    private void inspectDisplays(){
        if(!connected){render("먼저 1단계 ADB 연결이 필요합니다.");return;}
        perform("화면 출력 단서 검색",()->{
            stage=4;displayCandidates.clear();
            String disp=query("dumpsys-display", "dumpsys display");
            String layers=query("surfaceflinger-list", "dumpsys SurfaceFlinger --list");
            displayCandidates.addAll(CandidateParser.displays(disp,layers));
            ui(()->render("dumpsys display: "+(disp.contains("Permission Denial")||disp.contains("[READ_FAILED]")?"BLOCKED":"조회함")
                +"\nSurfaceFlinger --list: "+(layers.contains("Permission Denial")||layers.contains("[READ_FAILED]")?"BLOCKED":"조회함")
                +"\n\n화면·레이어 관련 단서: "+displayCandidates.size()+"개\n"
                +"아래 단서를 선택해 정합성 검사로 이동합니다.\n"
                +"※ 레이어 문자열만으로 5인치 패널 매핑을 입증할 수 없습니다."));
        });
    }
    private void finalCheck(String selected){
        perform("출력 후보 정합성 확인",()->{
            stage=5;selectedDisplay=selected;
            String identity=query("final-identity", "id");
            String fission=query("final-host", "getprop init.svc.FissionHostSvc");
            String fissiond=query("final-daemon", "getprop init.svc.fissiond");
            String rcc=query("final-rcc", "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc");
            String result="READ_ONLY_EVIDENCE_COLLECTED / OEM_5INCH_MAPPING_UNVERIFIED / OEM_THEME_WRITE_NO_GO";
            status=result;record("GATE","final",result);
            ui(()->render("단계 연속 시험 완료 — 선택 후보 기반 읽기 전용 증거\n\n"
                +"PID: "+selectedPid+" "+selectedProcess
                +"\n라이브러리: "+selectedLibrary
                +"\n출력 단서: "+shortText(selectedDisplay,220)
                +"\n\n셸: "+shortText(identity,120)
                +"\n서비스: "+shortText(fission,60)+" / "+shortText(fissiond,60)
                +"\nRCC: "+shortText(rcc,700)
                +"\n\n판정: "+result
                +"\n\n지금은 실제 계기판 테마 변경·테마 메시지 송신·프로세스 재시작을 수행할 수 없습니다.\n"
                +"진단 ZIP을 공유하면 그 결과로 다음 연구 단계 후보를 좁힐 수 있습니다."));
        });
    }
    private void pickPlan(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
        try{startActivityForResult(i,REQ_PLAN);}catch(Exception ex){render("플랜 파일 선택기 열기 실패: "+ex.getMessage());}
    }
    private void showExtraProbes(){
        options.removeAllViews();
        for(Map.Entry<String,String> e:extraProbes.entrySet()) {
            addButton(options,"추가 검사: "+e.getKey(),()->{
                String name=e.getKey(), command=e.getValue();
                perform("추가 검사 "+name,()->{
                    String res=query("user-plan:"+name,command);
                    ui(()->render("추가 검사: "+name+"\n명령: "+command+"\n\n"+shortText(res,3200)));
                });
            });
        }
        addButton(options,"단계 화면으로 돌아가기",()->render("계속 시험할 후보를 선택하세요."));
    }
    @Override protected void onActivityResult(int req,int result,Intent intent){
        super.onActivityResult(req,result,intent);
        if(result!=RESULT_OK || intent==null || intent.getData()==null)return;
        Uri uri=intent.getData();
        if(req==REQ_PLAN){
            try(InputStream in=getContentResolver().openInputStream(uri)){
                if(in==null)throw new IOException("no input");
                byte[] data=readLimited(in,32768);
                JSONObject root=new JSONObject(new String(data,StandardCharsets.UTF_8));
                JSONArray arr=root.getJSONArray("probes");
                if(arr.length()<1 || arr.length()>30)throw new IOException("검사 수 1~30 허용");
                LinkedHashMap<String,String> next=new LinkedHashMap<>();
                for(int j=0;j<arr.length();j++){
                    JSONObject p=arr.getJSONObject(j);
                    String name=p.getString("label").trim();String id=p.getString("probe_id");
                    if(name.length()<1||name.length()>50||!id.matches("[a-z0-9_]{1,60}"))throw new IOException("label/id 형식 오류");
                    String cmd=ProbeCatalog.command(id);
                    if(cmd==null)throw new IOException("미허용 검사: "+id);
                    next.put(name,cmd);
                }
                extraProbes.clear();extraProbes.putAll(next);
                saveStoredPlan();
                record("INFO","import-plan","added "+next.size()+" allowlisted read-only tasks");
                render("추가 검사 플랜 "+next.size()+"개를 불러왔습니다.\nADB 연결 이후 '추가 검사 선택'에서 실행할 수 있습니다.\n새 명령을 직접 실행하는 기능은 없습니다.");
            }catch(Exception ex){render("플랜 불러오기 실패: "+ex.getMessage());}
        }
        if(req==REQ_SAVE){
            try{
                File file=createZip();
                try(InputStream in=new FileInputStream(file);OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                    if(out==null)throw new IOException("write failed");byte[] b=new byte[8192];int n;
                    while((n=in.read(b))!=-1)out.write(b,0,n);
                }
                render("ZIP 저장 완료: "+WizardZipProvider.FILE+"\n실차 프로세스·서비스 진단 결과를 포함합니다.\n파일 관리자로 선택해 공유하세요.");
            }catch(Exception ex){render("ZIP 저장 실패: "+ex.getMessage());}
        }
    }
    private void saveStoredPlan() throws IOException {
        // Only validated allowlisted commands survive across app restarts.
        JSONArray a=new JSONArray();
        for(Map.Entry<String,String> e:extraProbes.entrySet()){
            String id=null;
            for(String candidate:new String[]{"identity","fissiond_status","fission_host_status",
                "fission_single_os","vehicle_type","process_list","display_inventory","surface_layers",
                "rcc_files","fission_files","clu_size_permissions","clu_size_read","cell_devices","cell_data"}) {
                if(e.getValue().equals(ProbeCatalog.command(candidate))) {id=candidate;break;}
            }
            if(id==null)continue;
            JSONObject o=new JSONObject();
            try{o.put("label",e.getKey());o.put("probe_id",id);}catch(Exception ignored){}
            a.put(o);
        }
        try(OutputStream out=openFileOutput("allowlisted_plan.json",MODE_PRIVATE)){
            out.write(a.toString().getBytes(StandardCharsets.UTF_8));
        }
    }
    private void loadStoredPlan(){
        try(InputStream in=openFileInput("allowlisted_plan.json")) {
            JSONArray a=new JSONArray(new String(readLimited(in,32768),StandardCharsets.UTF_8));
            for(int i=0;i<a.length() && i<30;i++){
                JSONObject p=a.getJSONObject(i);String name=p.getString("label"), id=p.getString("probe_id");
                String cmd=ProbeCatalog.command(id);
                if(name.length()>0 && name.length()<=50 && cmd!=null)extraProbes.put(name,cmd);
            }
        }catch(Exception ignored){} // First run normally has no stored plan.
    }

    private void share(){
        try{
            File file=createZip();
            new AlertDialog.Builder(this).setTitle("진단 ZIP 공유")
                .setMessage(""+file.length()+" bytes\nPID·프로세스명·빌드 환경 등이 포함됩니다. 개인정보가 있는지 확인하고 전달하세요.\nADB 키·OEM 파일·차량 제어 데이터는 저장하지 않습니다.")
                .setPositiveButton("공유",(d,w)->{
                    Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/zip");
                    send.putExtra(Intent.EXTRA_STREAM,WizardZipProvider.URI);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    send.setClipData(ClipData.newUri(getContentResolver(),"단계형 진단 ZIP",WizardZipProvider.URI));
                    try{startActivity(Intent.createChooser(send,"진단 ZIP 공유"));}catch(Exception ex){render("공유할 앱이 없습니다. ZIP 저장을 이용하세요.");}
                }).setNegativeButton("취소",null).show();
        }catch(Exception ex){render("ZIP 생성 실패: "+ex.getMessage());}
    }
    private void save(){
        try{
            createZip();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");
            i.putExtra(Intent.EXTRA_TITLE,WizardZipProvider.FILE);
            startActivityForResult(i,REQ_SAVE);
        }catch(Exception ex){render("ZIP 저장 준비 실패: "+ex.getMessage());}
    }
    private File createZip() throws Exception {
        File dir=new File(getCacheDir(),"wizard_reports");if(!dir.exists()&&!dir.mkdirs())throw new IOException("mkdir failed");
        File dest=new File(dir,WizardZipProvider.FILE);
        JSONArray arr=new JSONArray();synchronized(events){for(JSONObject j:events)arr.put(j);}
        JSONObject meta=new JSONObject();meta.put("app","DolphinCluster-V1.5-Wizard");
        meta.put("adb_connected_this_session",connected);
        meta.put("status",status);meta.put("stage",stage);
        meta.put("selected_pid",selectedPid);meta.put("selected_process",selectedProcess);
        meta.put("selected_library",selectedLibrary);meta.put("selected_display_hint",selectedDisplay);
        meta.put("oem_5inch_mapping_verified",false);meta.put("oem_theme_write_permitted",false);
        try(ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(dest))){
            put(zip,"diagnostics.txt",evidence.toString());
            put(zip,"candidates.json",meta.toString(2));
            put(zip,"events.json",arr.toString(2));
            put(zip,"README_KO.txt","이 ZIP은 127.0.0.1:5555 읽기 전용 진단의 결과입니다. PID, 프로세스, 출력 단서는 실제 5인치 테마 변경 성공을 뜻하지 않습니다.\n"+
                "실차 OEM 쓰기·순정 테마 교체·프로세스 재시작·CAN/SPI 전송 없음.\n개인정보를 공유 전 확인하세요.\n");
        }
        return dest;
    }
    private void put(ZipOutputStream z,String name,String contents)throws IOException {
        z.putNextEntry(new ZipEntry(name));z.write(contents.getBytes(StandardCharsets.UTF_8));z.closeEntry();
    }
    private void record(String type,String tag,String value){
        String line="["+new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.ROOT).format(new Date())+"] "+type+" / "+tag+"\n"+shortText(value,11000)+"\n";
        synchronized(evidence){if(evidence.length()<400000)evidence.append(line);}
        synchronized(events){try{JSONObject e=new JSONObject();e.put("state",type);e.put("tag",tag);e.put("text",shortText(value,3000));events.add(e);}catch(Exception ignored){}}
    }
    private static String shortText(String s,int max){if(s==null)return "";return s.length()<=max?s:s.substring(0,max)+"...[TRUNCATED]";}
    private static byte[] readLimited(InputStream in,int limit)throws IOException {
        ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;
        while((n=in.read(b))!=-1){if(o.size()+n>limit)throw new IOException("파일 32KiB 초과");o.write(b,0,n);}
        return o.toByteArray();
    }
    @Override protected void onDestroy(){dead=true;jobs.shutdownNow();try{adb.close();}catch(Exception ignored){}super.onDestroy();}
}
