package com.dolphin.clusterprobe;

import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import javax.crypto.Cipher;

/**
 * Small, local-only (127.0.0.1:5555), opt-in ADB client for read-only diagnosis.
 * Implements legacy CNXN / AUTH (RSA 2048) / shell protocol without native binaries,
 * root or a PC. No general shell interface and no write/pm/cmd operations.
 * Requires adbd already enabled and user confirmation on vehicle if requested.
 */
public final class LocalAdb implements Closeable {
    private static final int CNXN = 0x4e584e43, AUTH = 0x48545541;
    private static final int OPEN = 0x4e45504f, OKAY = 0x59414b4f;
    private static final int WRTE = 0x45545257, CLSE = 0x45534c43;
    private static final int STLS = 0x534c5453;
    private static final int MAX_PACKET = 256 * 1024;
    private static final byte[] SHA1_INFO = hex("3021300906052b0e03021a05000414");

    public interface Status { void onStatus(String state); }
    private final File privateFolder;
    private Socket socket;
    private DataInputStream input;
    private OutputStream output;
    private int streamId = 1;

    public LocalAdb(File privateFolder) { this.privateFolder = privateFolder; }

    // Each APK owns its own ADB key. Keep that key across retries and subsequent runs.
    // The key, RSA challenge, shell private output and vehicle identifiers are never logged.
    public String checkAndRead(Status status) throws Exception {
        KeyPair pair = loadOrCreateKey();
        Exception last = null;
        for (int attempt = 1; attempt <= 2; attempt++) {
            try {
                return checkOnce(status, pair, attempt);
            } catch (EOFException e) {
                last = e;
                status.onStatus("ADB " + attempt + "/2: 서버가 인증 대화 중 연결 종료");
            } catch (SocketTimeoutException e) {
                last = e;
                status.onStatus("ADB " + attempt + "/2: 응답 대기 초과 (인증창 또는 adbd 응답 지연)");
            } catch (ConnectException e) {
                last = e;
                status.onStatus("ADB " + attempt + "/2: 127.0.0.1:5555 접속 거부 (서버 비활성 가능)");
            } catch (NoRouteToHostException e) {
                last = e;
                status.onStatus("ADB " + attempt + "/2: 로컬 연결 불가");
            } catch (SocketException e) {
                last = e;
                status.onStatus("ADB " + attempt + "/2: 연결 끊김 또는 재설정");
            } finally {
                // Never leave an authorization attempt or stream open after a failed read.
                close();
            }
            if (attempt == 1) {
                status.onStatus("동일한 ADB 키로 1회만 재시도합니다. 차량 승인창이 있으면 허용하세요.");
                Thread.sleep(700);
            }
        }
        throw new IOException("로컬 ADB 인증/연결 2회 실패: "
            + (last instanceof SocketTimeoutException ? "응답 대기 초과" : "연결 불가")
            + ". 차량 승인창·5555 포트 확인 후 다시 버튼을 누르세요.", last);
    }

    private String checkOnce(Status status, KeyPair pair, int attempt) throws Exception {
        connectHandshake(status, pair, attempt);
        status.onStatus("ADB " + attempt + "/2: 허용된 읽기 전용 조회 시작");
        StringBuilder result = new StringBuilder();
        for (String[] item : new String[][] {
            {"ADB 셸 신원", "id"},
            {"시스템 분할 구조", "getprop ro.build.system.fission_single_os"},
            {"계기판 크기 경로 권한", "ls -l /sys/module/max96745/parameters/clu_size"},
            {"계기판 크기 식별", "cat /sys/module/max96745/parameters/clu_size"},
            {"순정 테마 파일 목록", "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc"}
        }) {
            result.append("\n[ ").append(item[0]).append(" ]\n");
            try { result.append(shellReadOnly(item[1])); }
            catch (Exception ex) { result.append("조회 실패: ").append(ex.getClass().getSimpleName()).append("\n"); }
        }
        result.append("\n※ ADB 셸 신원/파일 존재 확인은 계기판 화면 변경 권한을 뜻하지 않습니다.\n");
        return result.toString();
    }

    /** Persistent one-install wizard session. Explicitly reconnects on a lost socket, never changes vehicle settings. */
    public void connectSession(Status status) throws Exception {
        KeyPair pair = loadOrCreateKey();
        Exception last = null;
        for (int attempt = 1; attempt <= 2; attempt++) {
            try {
                last = null;
                connectHandshake(status, pair, attempt);
                return;
            } catch (EOFException | SocketTimeoutException | ConnectException | NoRouteToHostException e) {
                last=e;
                status.onStatus("ADB "+attempt+"/2: "+e.getClass().getSimpleName());
            } catch (SocketException e) {
                last=e;
                status.onStatus("ADB "+attempt+"/2: SocketException");
            } finally {
                if(last!=null) close();
            }
            if(attempt==1) Thread.sleep(700);
        }
        throw new IOException("ADB 접속/인증 실패: "+(last==null?"unknown":last.getClass().getSimpleName()),last);
    }

    private void connectHandshake(Status status, KeyPair pair, int attempt) throws Exception {
        String prefix = "ADB " + attempt + "/2: ";
        status.onStatus(prefix + "127.0.0.1:5555 TCP 연결 시작");
        socket = new Socket();
        socket.connect(new InetSocketAddress("127.0.0.1", 5555), 2500);
        socket.setSoTimeout(attempt == 1 ? 18000 : 27000);
        input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        output = socket.getOutputStream();
        status.onStatus(prefix + "TCP 연결됨. ADB CNXN 요청 전송");
        writePacket(CNXN, 0x01000000, 4096, "host::\0".getBytes(StandardCharsets.UTF_8));
        boolean signed = false, shared = false, connected = false;
        for (int i = 0; i < 12; i++) {
            Packet p = readPacket();
            if (p.cmd == CNXN) { connected = true; break; }
            if (p.cmd == STLS) throw new IOException("ADB TLS 필수: legacy 로컬 ADB 방식 미지원");
            if (p.cmd != AUTH || p.arg0 != 1) throw new IOException("예상 외 ADB 인증 패킷");
            if (!signed) {
                status.onStatus(prefix + "ADB AUTH 토큰 수신, RSA 서명 응답");
                writePacket(AUTH, 2, 0, signChallenge(pair.getPrivate(), p.data));
                signed = true;
            } else if (!shared) {
                status.onStatus(prefix + "새 앱의 공개키 전송. 차량 화면에 ADB 승인창이 있으면 허용");
                byte[] publicKey = adbPublicKey((java.security.interfaces.RSAPublicKey) pair.getPublic());
                String printable = Base64.getEncoder().encodeToString(publicKey) + " dolphin-cluster@vehicle\0";
                writePacket(AUTH, 3, 0, printable.getBytes(StandardCharsets.UTF_8));
                shared = true;
            } else {
                throw new IOException("ADB 서버가 공개키 전송 뒤에도 인증을 재요청함. 승인 거부 또는 인증 불일치 가능");
            }
        }
        if (!connected) throw new IOException("ADB CNXN 성공 응답 누락");
        status.onStatus(prefix + "ADB 인증 완료(CNXN)");
        socket.setSoTimeout(10000);
    }

    public synchronized String queryReadOnly(String command) throws Exception {
        if(socket==null || socket.isClosed()) throw new IOException("ADB 세션 미연결. 1단계에서 연결하세요.");
        return shellReadOnly(command);
    }

    private String shellReadOnly(String command) throws Exception {
        // hard allowlist. Any unknown command is rejected before touching adbd.
        Set<String> allowed = new HashSet<>(Arrays.asList(
            "getprop ro.build.system.fission_single_os", "getprop ro.vehicle.type",
            "getprop init.svc.fissiond", "getprop init.svc.FissionHostSvc",
            "id", "ps -A", "dumpsys display", "dumpsys SurfaceFlinger --list",
            "ls -l /sys/module/max96745/parameters/clu_size",
            "cat /sys/module/max96745/parameters/clu_size",
            "ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc",
            "ls -l /system/bin/fissiond /system/bin/fission_service /system/lib64/libfission_services.so",
            "ls -l /dev/cells", "ls -l /data/cells"));
        boolean procCmd = command.matches("(cat /proc/[0-9]{1,7}/(maps|cmdline)|readlink /proc/[0-9]{1,7}/exe)");
        boolean libInfo = command.matches("ls -l /(system|vendor)/lib64/[A-Za-z0-9_.+-]+[.]so");
        if (!allowed.contains(command) && !procCmd && !libInfo)
            throw new SecurityException("허용되지 않은 진단 명령: "+command);
        int id = streamId++;
        byte[] commandBytes = ("shell:" + command + "\0").getBytes(StandardCharsets.UTF_8);
        writePacket(OPEN, id, 0, commandBytes);
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int remote = -1;
        boolean truncated = false;
        long deadline = System.currentTimeMillis() + 10000;
        while (System.currentTimeMillis() < deadline) {
            Packet p = readPacket();
            if (p.cmd == OKAY && p.arg1 == id) { remote = p.arg0; continue; }
            if (p.cmd == WRTE && p.arg1 == id) {
                remote = p.arg0;
                int room = 131072 - buffer.size();
                if (room > 0) buffer.write(p.data, 0, Math.min(room, p.data.length));
                if (p.data.length > room) truncated = true;
                writePacket(OKAY, id, remote, new byte[0]);
                continue;
            }
            if (p.cmd == CLSE && p.arg1 == id) {
                writePacket(CLSE, id, p.arg0, new byte[0]);
                return buffer.toString("UTF-8") + (truncated ? "\n[OUTPUT_TRUNCATED_AFTER_128KiB]\n" : "");
            }
        }
        if (remote != -1) writePacket(CLSE, id, remote, new byte[0]);
        return buffer.toString("UTF-8") + "\n(TIMEOUT)\n";
    }

    private static final class Packet {
        int cmd, arg0, arg1; byte[] data;
    }
    private Packet readPacket() throws IOException {
        byte[] h = new byte[24]; input.readFully(h);
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        Packet p = new Packet(); p.cmd = b.getInt(); p.arg0 = b.getInt(); p.arg1 = b.getInt();
        int length = b.getInt(), checksum = b.getInt(), magic = b.getInt();
        if ((p.cmd ^ -1) != magic || length < 0 || length > MAX_PACKET) throw new IOException("유효하지 않은 ADB 패킷");
        p.data = new byte[length]; input.readFully(p.data);
        int sum = 0; for(byte value:p.data) sum += value & 0xff;
        if (checksum != 0 && sum != checksum) throw new IOException("ADB 패킷 체크섬 불일치");
        return p;
    }
    private void writePacket(int cmd, int arg0, int arg1, byte[] bytes) throws IOException {
        int sum = 0; for(byte value:bytes) sum += value & 0xff;
        ByteBuffer b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(cmd).putInt(arg0).putInt(arg1).putInt(bytes.length).putInt(sum).putInt(cmd ^ -1);
        output.write(b.array()); output.write(bytes); output.flush();
    }

    private KeyPair loadOrCreateKey() throws Exception {
        File privateFile = new File(privateFolder, "adb_probe_private.key");
        File publicFile = new File(privateFolder, "adb_probe_public.key");
        KeyFactory factory = KeyFactory.getInstance("RSA");
        if (privateFile.isFile() && publicFile.isFile()) {
            PrivateKey privateKey = factory.generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(privateFile.toPath())));
            PublicKey publicKey = factory.generatePublic(new X509EncodedKeySpec(Files.readAllBytes(publicFile.toPath())));
            return new KeyPair(publicKey, privateKey);
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, new SecureRandom());
        KeyPair pair = gen.generateKeyPair();
        try(FileOutputStream f = new FileOutputStream(privateFile)) { f.write(pair.getPrivate().getEncoded()); }
        try(FileOutputStream f = new FileOutputStream(publicFile)) { f.write(pair.getPublic().getEncoded()); }
        privateFile.setReadable(false, false); privateFile.setReadable(true, true);
        privateFile.setWritable(false, false); privateFile.setWritable(true, true);
        return pair;
    }
    private static byte[] signChallenge(PrivateKey key, byte[] token) throws Exception {
        if (token.length != 20) throw new IOException("지원되지 않는 ADB 인증 토큰 길이");
        byte[] der = new byte[SHA1_INFO.length + token.length];
        System.arraycopy(SHA1_INFO, 0, der, 0, SHA1_INFO.length);
        System.arraycopy(token, 0, der, SHA1_INFO.length, token.length);
        Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        rsa.init(Cipher.ENCRYPT_MODE, key);
        return rsa.doFinal(der);
    }
    private static byte[] adbPublicKey(java.security.interfaces.RSAPublicKey key) {
        BigInteger n = key.getModulus();
        BigInteger rad = BigInteger.ONE.shiftLeft(4096).mod(n);
        BigInteger n0 = n.and(new BigInteger("ffffffff", 16));
        BigInteger n0inv = n0.modInverse(BigInteger.ONE.shiftLeft(32)).negate();
        ByteBuffer data = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN);
        data.putInt(64); data.putInt(n0inv.intValue());
        putLE(data, n, 256); putLE(data, rad, 256); data.putInt(key.getPublicExponent().intValue());
        return data.array();
    }
    private static void putLE(ByteBuffer b, BigInteger x, int bytes) {
        byte[] v = x.toByteArray();
        for(int i=0;i<bytes;i++) b.put(i<v.length ? v[v.length-1-i] : (byte)0);
    }
    private static byte[] hex(String hex){ byte[] v=new byte[hex.length()/2]; for(int i=0;i<v.length;i++) v[i]=(byte)Integer.parseInt(hex.substring(i*2,i*2+2),16); return v; }
    @Override public void close() throws IOException { if(socket != null) socket.close(); }
}
