package com.dolphin.clusterprobe;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/** Stable logical probe identifiers for importable test-plans. There is deliberately no arbitrary shell input. */
public final class ProbeCatalog {
    private static final Map<String,String> ALLOWED;
    static {
        Map<String,String> m=new HashMap<>();
        m.put("identity","id");
        m.put("fissiond_status","getprop init.svc.fissiond");
        m.put("fission_host_status","getprop init.svc.FissionHostSvc");
        m.put("fission_single_os","getprop ro.build.system.fission_single_os");
        m.put("vehicle_type","getprop ro.vehicle.type");
        m.put("process_list","ps -A");
        m.put("display_inventory","dumpsys display");
        m.put("surface_layers","dumpsys SurfaceFlinger --list");
        m.put("rcc_files","ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc");
        m.put("fission_files","ls -l /system/bin/fissiond /system/bin/fission_service /system/lib64/libfission_services.so");
        m.put("clu_size_permissions","ls -l /sys/module/max96745/parameters/clu_size");
        m.put("clu_size_read","cat /sys/module/max96745/parameters/clu_size");
        m.put("cell_devices","ls -l /dev/cells");
        m.put("cell_data","ls -l /data/cells");
        ALLOWED=Collections.unmodifiableMap(m);
    }
    private ProbeCatalog(){}
    public static String command(String id){return ALLOWED.get(id);}
}
