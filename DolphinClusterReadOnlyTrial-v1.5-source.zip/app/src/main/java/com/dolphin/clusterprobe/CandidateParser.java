package com.dolphin.clusterprobe;

import java.util.*;
import java.util.regex.*;

/** Deterministic, conservative classification of shell text as CANDIDATES, never as verified cluster links. */
public final class CandidateParser {
    private static final Pattern TARGET=Pattern.compile("(?i)fission|cluster|byd|cell|surfaceflinger");
    private static final Pattern LIB=Pattern.compile("/(?:system|vendor)/lib64/[A-Za-z0-9_.+-]+\\.so");
    private CandidateParser(){}
    public static List<String> processes(String output){
        LinkedHashSet<String> found=new LinkedHashSet<>();
        for(String line:output.split("\\r?\\n")) {
            if(!TARGET.matcher(line).find()) continue;
            String[] p=line.trim().split("\\s+");
            if(p.length>2 && p[1].matches("[0-9]{1,7}")) found.add(p[1]+"|"+clip(p[p.length-1],75));
            if(found.size()>=32)break;
        }
        return new ArrayList<>(found);
    }
    public static List<String> libraries(String output){
        LinkedHashSet<String> found=new LinkedHashSet<>();
        for(String line:output.split("\\r?\\n")) {
            Matcher m=LIB.matcher(line);
            while(m.find()) {
                String path=m.group();
                if(TARGET.matcher(path).find() || path.toLowerCase(Locale.ROOT).contains("qt")) found.add(path);
            }
            if(found.size()>=24)break;
        }
        return new ArrayList<>(found);
    }
    public static List<String> displays(String a,String b){
        LinkedHashSet<String> found=new LinkedHashSet<>();
        for(String text:new String[]{a,b}) for(String line:text.split("\\r?\\n")) {
            if(TARGET.matcher(line).find() || Pattern.compile("(?i)physicaldisplay|displaydevice|displayinfo|virtualdisplay").matcher(line).find())
                found.add(clip(line.trim(),180));
            if(found.size()>=20)break;
        }
        return new ArrayList<>(found);
    }
    private static String clip(String s,int n){return s.length()>n?s.substring(0,n):s;}
}
