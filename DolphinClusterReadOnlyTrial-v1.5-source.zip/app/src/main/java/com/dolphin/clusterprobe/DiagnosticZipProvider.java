package com.dolphin.clusterprobe;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Exposes only an app-generated ZIP to a user-selected share target; never exports sensitive app files. */
public final class DiagnosticZipProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dolphin.clusterprobe.v15.diagnostics";
    public static final Uri ZIP_URI = Uri.parse("content://" + AUTHORITY + "/DolphinCluster-V1.5-Diagnostic.zip");
    private File zip(Uri uri) throws FileNotFoundException {
        if (!ZIP_URI.equals(uri)) throw new FileNotFoundException("Invalid diagnostic URI");
        File f=new File(new File(getContext().getCacheDir(), "diagnostics"), "DolphinCluster-V1.5-Diagnostic.zip");
        if(!f.isFile() || !f.canRead()) throw new FileNotFoundException("Diagnostic ZIP not generated");
        return f;
    }
    @Override public boolean onCreate() {return true;}
    @Override public String getType(Uri uri) {return "application/zip";}
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if(!"r".equals(mode)) throw new FileNotFoundException("Read-only share");
        return ParcelFileDescriptor.open(zip(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        try {
            File file=zip(uri);
            String[] cols=projection!=null?projection:new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};
            MatrixCursor c=new MatrixCursor(cols); Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++) {
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i]="DolphinCluster-V1.5-Diagnostic.zip";
                if(OpenableColumns.SIZE.equals(cols[i])) row[i]=file.length();
            }
            c.addRow(row);return c;
        } catch(FileNotFoundException e){return null;}
    }
    @Override public Uri insert(Uri uri, ContentValues v) {throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String s,String[] a){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
