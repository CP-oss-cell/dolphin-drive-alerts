# Dolphin Cluster V1.5 — 차량 단독 다단계 탐색·선택 진단

- 대상: 한국 출시 BYD Dolphin Standard / 사용자의 DiLink 글로벌 2602 / Android 10 / PC 연결 불가
- **차량의 5인치 계기판을 변경하지 않는 READ-ONLY 테스트 앱**. Main display UI only.
- 독립 패키지 `com.dolphin.clusterprobe.v15`. 기존 V1.2~1.4 보존.
- **새 기능**: 하나의 앱에서 ADB 인증 → Fission 서비스 + 실행 프로세스 후보 목록 → 사용자 PID 선택 → 선택 PID의 `/proc/PID/exe/cmdline/maps` 분석 → 연관 라이브러리 선택 → 기존 RCC/호스트 파일 존재 확인 → Android display/SurfaceFlinger 출력 단서 선택 → NO-GO 판정 및 선택 경로 ZIP 공유.
- 후보 선택으로 다음 단계에 **즉시 진행**. 단계 결과가 BLOCKED면 다른 읽기 전용 경로로 진행. 앱을 재설치할 필요 없음.
- `추가 검사 플랜` 버튼으로 허용된 진단 명령 ID만 포함된 JSON 파일을 불러오기. 가져온 플랜은 앱 내부에 저장되어 재시작해도 사용 가능. 테스트 그룹/순서 변경은 APK 업데이트 불필요.
- JSON으로 **새 종류의 임의 ADB 셸 명령을 실행하는 기능은 제공하지 않음**. 앱에 없는 검사 종류는 코드 변경 필요. 차량 시스템 명령/쓰기 전부 금지.
- ZIP `DolphinCluster-V1.5-StageWizard.zip`: diagnostics.txt / candidates.json / events.json / README_KO.txt.
- ZIP 공유 전 프로세스 명·빌드 지문·출력 텍스트에 개인 식별 가능 정보가 없는지 확인.

## 관련 실제 연구

- Stage114~117: 테마 QML→메시지30과 SPI 키 코드 경로 정적 확인. 인위적 메시지 송신 금지.
- Stage119~120: `libBydCluster.so::main`/QML 로더 경로 정적 확인; 실제 호스트 PID·5인치 매핑 불명.
- Stage121: RC 서비스 선언을 발견, `fissiond=/system/bin/fissiond`, `FissionHostSvc=/system/bin/fission_service`. 이 앱이 해당 상태를 직접 확인할 수 있게 함.
- Stage122~123: 파일 inode·크기 정보 보유, **호스트 ELF 원본 바이트 미확보**. APK가 ELF를 가져오거나 차량 플래시를 수정하지 않음.
- Launcher V1 Evolution 1.2.20 Registry: `CLUSTER_TBT=BETA`, `CLUSTER_FULL_MIRROR_THEME=BLOCKED`. 재사용은 진단/테스트 체계만.
- DA-025: `CLUSTER 5INCH OEM THEME NO-GO` 유지. 속도·기어·필수 경고 무변경.

## 빌드

1. GitHub 저장소 최상위에 `DolphinClusterReadOnlyTrial-v1.5-source.zip` 업로드.
2. `.github/workflows/build-cluster-v15-stage-wizard.yml`에 별도 YML 등록.
3. Actions > `Build Dolphin Cluster V1.5 Read-only Stage Wizard` > Run workflow.
4. 성공 시 Artifacts에서 ZIP 다운로드, 안의 `DolphinCluster-v1.5-VEHICLE-DEBUG.apk` 추출.
5. USB나 차량 다운로드 폴더로 옮겨 차량 파일관리자로 **한 번** 설치. PC ADB 명령 필요 없음.
6. 이 빌드는 앱 자체를 제공할 뿐, GitHub CI 성공과 차량 정상 동작은 실제 수행 전까지 미확인.

## 차량 단독 1회 설치 후의 조작

1. 안전하게 정차하고 P단. V1.5 앱을 실행.
2. `연속 1→5단계 시험 (후보 선택)` 누르기.
3. `① ADB 연결 후 서비스 자동 탐색` 누르고 차량에서 새 RSA 승인창이 뜨면 허용. 1.4와 앱 ID/인증키가 달라 최초 승인 필요할 수 있음.
4. 자동 표시되는 `fissiond`, `FissionHostSvc` 및 프로세스 후보 중 가장 관계 있는 `fission_service`, `fissiond`, `cluster` 후보를 눌러 **즉시 2단계** 진행.
5. 맵에서 나온 Qt/cluster 라이브러리 후보를 누르면 **즉시 3단계**. 후보가 없거나 권한이 거부되면 `화면 단서 확인` 클릭.
6. `④ 화면 출력 경로 탐색` 클릭. 목록에 실제 출력 단서가 있으면 선택하고, 없으면 `화면 단서 없음` 클릭. 이후 최종 판정.
7. `진단 ZIP 공유` 또는 `ZIP 저장`으로 선택 경로와 실패 사유 전달.
8. 다른 후보 시험은 `재탐색: 호스트·프로세스` 누르기. APK를 삭제/재설치할 필요 없음.
9. 나중에 새 읽기전용 진단 계획이 오면 JSON을 USB로 옮겨 `추가 검사 플랜`으로 가져오기. 같은 설치본에서 계속 사용.

### 실패/복구
- 첫 접속 실패 → 버튼 다시 누르기. 승인창 확인. 연결 불가 또는 인증 지연은 차량마다 다름.
- `Permission denied`는 해당 정보에 접근할 수 없다는 사실; **root/권한 우회를 시도하지 않음**.
- `ps -A`에서 관련 PID 없음 → `화면 단서 확인`으로 진행해 실패 증거 기록.
- 모든 단계에서 `READ_ONLY_EVIDENCE_COLLECTED / OEM_5INCH_MAPPING_UNVERIFIED / OEM_THEME_WRITE_NO_GO`를 유지.
- 강제 종료 시 원래 계기판은 변경되지 않아야 함. 설치 앱 제거는 차량 Android 앱 관리의 제거 기능 이용.

## 개발·검증 상태
- Java local `LocalAdb` 기존 RSA handshake + 재연결 mock 통과; 신규 세션 지속 상태에서 `id → ps -A → cat /proc/123/maps → dumpsys display` 연속 실행 모의시험 통과, 위험 명령 거부 통과.
- `CandidateParser` 분기·접근거부/후보없음 단위시험 통과.
- 코드 정적 gate 통과.
- Android Gradle 전체 컴파일 / 실제 BYD 차량 V1.5 설치 / 물리 계기판 표시 연결: **미검증**.

안전: Android OEM 디스플레이/ADAs/CAN/SPI/Qt 메시지/시스템 파티션 수정·서비스 재시작 동작 없음.
