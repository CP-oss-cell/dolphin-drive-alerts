# v0.17.39 GitHub에서 빌드
1. 저장소 루트에 `DolphinDrive_v01739_source.zip` 업로드.
2. `.github/workflows/build-v01739-dpi-audio-dashboard.yml` 업로드.
3. Actions의 `Build Dolphin Drive Alerts v0.17.39 Audio DPI Dashboard` 실행.
4. 성공 artifact `DolphinDrive_v01739-SIGNED`에서 APK 다운로드.
5. 설치 전 기존 설치 APK와 서명 인증서 동일한지 확인. 한 번 설치한 앱 삭제/초기화는 피하세요.
앱 컴파일/차량 동작은 GitHub 빌드+실차까지 미검증. 기본 음량은 기존 보통.
