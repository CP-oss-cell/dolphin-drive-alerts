# Dolphin Drive Alerts v0.17.40 — AutoSplit 동작 이식, ECO 해제 규칙, 시동 OFF 지정 앱 종료, BSD 메뉴 통합

- 버전: 0.17.40 / versionCode 66; 패키지 `com.byd.dolphin.drivealerts` 유지
- 기준: v0.17.39 전체 소스 + 2026-11-02 실차 로그, 라이브러리 연구자료, 사용자가 제공한 AutoSplit 1.2.0 APK의 동작 명령/상태 구조
- 개발 상태: **소스 수정 및 정적/일부 Kotlin 검사 PASS, Android Gradle assembleDebug 미실행, 실차 미검증**.

## 1. 실제 코드 변경
1. 기존 `VehicleSplitEngine.kt` 및 구형 `SplitTaskReadback.kt` 파일 제거. `AutoSplitBehaviorEngine.kt`에서 플랫폼 자체 분할 스택 API 사용: `am start --windowingMode 3/4`, `am stack move-task`, `am stack resize-docked-stack`, Task 모드·소유권과 비율 readback. AutoSplit APK는 **실행/설치/라이브러리 포함하지 않음**. 소스 코드를 그대로 복제하지 않고 공개 시스템 호출의 관측된 동작을 독립 구현한 후보.
2. 분할 프로필 UI/바로가기/시동 자동 실행/360 복원 서비스 전체가 새 내부 엔진을 호출. 카메라 화면 중에는 Task·비율 변경 금지. 카메라 종료 후 연속 2회 화면 확인 후 최대 2회만 복원 시도.
3. 주행모드 `EcoOffNormalMachine`: ECO ON→OFF + SPORT OFF면 NORMAL, SPORT ON이면 SPORT, SPORT ON 상태에서는 ECO-OFF에 NORMAL 발화 금지, SPORTS OFF + ECO OFF면 NORMAL. 직접 신호 `0`이 확인된 경우 기존 NORMAL 디코딩 유지. **2026-11-02 로그에서는 독립 ECO OFF 이벤트를 확인하지 못했으므로 상태 처리기 도입만으로 노멀 발화 성공을 보장하지 못함**. 기존 raw 1=ECO, raw 2=SPORT 해석 보존. 364 계기판 후보는 기존 명시적 시험 옵트인 그대로 유지.
4. `IgnitionOffAppStopper` + `IgnitionOffStopService`: 사용자가 체크한 설치된 일반 앱만 시동 OFF(`com.byd.action.ACC_OFF`) 수신 후 승인 ADB의 `am force-stop --user 0 <패키지>`로 종료 요청. 순정/시스템/우리 앱/차량 앱 제외, 기본 OFF, 일회성 command, 실패 기록. **차량이 이 OFF 브로드캐스트를 실제 전송하지 않거나 ADB 권한이 없으면 종료 불가**.
5. BootReceiver 자동 시작에서 SCREEN_ON/USER_PRESENT/USER_UNLOCKED/BOOT_COMPLETED/QUICKBOOT 웨이크 제거, `ACC_ON` 또는 `IGN_ON`만 자동 실행 신호로 수락. 이로써 주차 중 화면 깨어남에 음악 재시작하는 직접 경로 제거. 다만 차량에서 ACC_ON/IGN_ON을 보내지 않으면 자동 실행이 누락될 수 있음.
6. BSD 설정을 주행보조 카드로 이동. 홈에는 BSD 전용 카드가 나오지 않으며 기존 세 옵션/저장 설정은 유지. 홈 카드는 5개(주행보조·화면·오디오·자동 실행·진단).
7. v0.17.39 음량 4단계, 타사 앱 임시 전역 DPI·전체 DPI, 순정 DPI 복구, 23종 알림, 내비 5종, 로그 수집, 통합 대시보드 기존 기능 보존.

## 2. AutoSplit 분석의 경계
APK DEX에서 확인된 실행 계열: Task 이동, windowingMode 3/4, docked-stack 크기 조절, 카메라 복원 서비스, 바로가기. 구현은 이 호출 흐름을 바탕으로 작성된 별도 Android 앱 코드. **원본 AutoSplit 모든 내부 화면/기능의 완전 동일 재현, 3·4분할/팝업, 이식 완료·실차 검증을 주장하지 않음.** Android OEM 권한, ADB stack 지원 여부, 360 화면 이름에 따라 결과가 달라질 수 있음.

## 3. 시동 OFF 안전·설정
- 기본값 OFF. 자동 실행 메뉴 → 시동 OFF 지정 앱 종료 사용 ON → 앱 선택/저장.
- 시동 OFF는 BYD `com.byd.action.ACC_OFF`만 인정; 화면 켜짐·문 열림·USB 전원 분리로 앱을 강제 종료하지 않음.
- `am force-stop` 성공 반환은 실제 모든 스피커 출력 차단의 직접 청취 증거가 아니며 다른 앱의 미디어 자동 재개 정책을 제어하지 못함.
- 기존 설치 앱의 서명키가 다르면 업데이트 설치 불가. GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64` 필요.

## 4. 검증
- 신규 소스 연결 규칙 20건 PASS + ECO/SPORT 상태 머신 Kotlin 실행 PASS.
- 이전 23종 알림 연결/앱 자기 DPI/통합 로그 회귀 검사 PASS.
- YAML 파싱, bash 구문, 소스 ZIP 테스트 필요 시 패키징 후 수행.
- **APK CI 빌드·실차 정상 동작 미검증**. 비교적 위험도가 높은 전역 DPI/스택 제어는 기존 사용자 설정 범위에서만 수행.
