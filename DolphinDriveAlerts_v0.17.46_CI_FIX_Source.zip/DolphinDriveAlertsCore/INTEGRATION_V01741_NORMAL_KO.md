# Dolphin Drive Alerts v0.17.41 — Audio Feedback/실차 로그 근거 주행모드 통합 수정

- 대상: 한국형 돌핀 Android 10 글로벌 2602, `com.byd.dolphin.drivealerts`.
- 기준: v0.17.40 / versionCode 66. 결과: v0.17.41 / versionCode 67.
- **배포 상태: 소스 변경·Kotlin 단위 실행 검증 PASS / Android APK 빌드 및 실차 동작 미검증.**

## 1. 원본 Audio Feedback v1.0 APK 전체 경로 재확인

사용자 라이브러리의 `Byd_AutoFeedBack_v1.0.apk` `classes.dex`에서 사용자 코드 `com.poorgrammera.adasnoti.BydAutoService`와 BYD 에너지 콜백을 추적했다.

- `BydAutoService$5.onOperationModeChanged` → `BydAutoService.handleOperationMode`.
- 이 메서드에서는 값 `1`에 `R.raw.operation_mode_1_sports_mode_off`, 값 `2`에 `R.raw.operation_mode_2_sports_mode_on` 음원을 선택한다.
- `initSoundPool`에서 두 리소스를 함께 등록한다. **이 APK의 해당 콜백 자체에 명시된 ECO/NORMAL/SPORT 3상태 단독 분기는 없다.** 사용자가 차량에 설치한 앱에서 세 상태가 잘 들린다는 실차 보고는 그대로 보존하되, APK에 존재하지 않는 제3의 로우 값/메서드는 지어내지 않는다.
- APK의 독점 소스·음성파일을 앱에 복사하지 않았다. 기능의 입력/출력 상태 처리 방식만 참고했다.

## 2. 2026-11-02 직접 제공 실차 ZIP에서 다시 추출한 독립 증거

원본: `DolphinDriveLogs_20261102_070725_331_e2644b99.zip`의 `logs/vehicle_events.jsonl`.

| 시각 (KST) | 출처 | 값 |
|---|---|---|
| 07:07:30.084 | 계기판 `0x26100008` | `364` (노멀 후보) |
| 07:07:32.093 | 계기판 | `365` (스포츠 후보) |
| 07:07:32.797 | 에너지 `onOperationModeChanged` | `2` (SPORT 실차 보고) |
| 07:07:34.104 | 계기판 | `363` (에코 후보) |
| 07:07:35.004 | 에너지 콜백 | `1` (ECO 실차 보고) |
| **07:07:37.165** | **계기판** | **`364` (원시 에너지 변경 없음 → 기존 앱은 무음)** |
| 07:07:39.408 | 계기판 | `365` |
| 07:07:40.198 | 에너지 콜백 | `2` |
| 07:07:41.269 | 계기판 | `363` |
| 07:07:42.102 | 에너지 콜백 | `1` |

이 패턴은 사용자가 제시한 **ECO ON → ECO 해제/NORMAL → SPORT ON → ECO ON** 가설을 뒷받침한다. 그러나 BYD SDK의 정식 주행모드 enum이라고 확정된 것은 아니며 `0x26100008` 명칭은 `INSTRUMENT_DD_FAULT_NOTICE_261`이다.

## 3. 이번에 수정한 실제 코드

1. `ModeNoticeCorrelator.kt`: `363` 표시 후 2.8초 이내 에너지 `1`이 들어와 ECO 매칭되고, 6초 이내 `364`로 전환되면 **NORMAL 1회 요청**. 같은 `364` 반복·다른 계기판 공지·오래된 ECO·SPORT에서 `364`로 바로 이동은 차단. 해당 세션의 SPORT 사전 확인은 필수가 아님.
2. `ReferenceVehicleEventBridge.kt`: 확인된 ECO→364 시퀀스에서만 `DRIVE_NORMAL` 발화 요청. 이미 작동하는 `1→ECO`, `2→SPORT` 콜백은 기존 동작 보존.
3. `AlertPreferences.kt`: 해당 NORMAL 교차확인 기능 신규 설치 기본 ON. 기존 사용자가 명시적으로 OFF 저장했다면 그대로 존중.
4. `MainActivity.kt`: 기존 한 화면의 중복 실험/확인 메뉴를 **주행모드·에코/노멀/스포츠** 한 설정으로 정리하고 자동 판정/수동 해제 설명 제공. 별도 대시보드 카드 추가 없음.
5. `tools/verify_v01741_normal_transition.py`: 실제 Kotlin 소스 컴파일·실행 및 정적 연결 검사. GitHub Actions 사전 검증에 추가.
6. 기존 5개 카드 대시보드, 내부 AutoSplit 유사 분할 엔진, 시동 OFF 지정 앱 종료, 4단계 알림 음량, DPI 설정, 23종 알림은 유지.

## 4. 검증 및 한계

- `verify_v01741_normal_transition.py`: 정적 12개 PASS + Kotlin 모의 시간 이벤트 9개 상황 PASS.
- `verify_v01740_safeguards.py`: 기존 자체 분할·시동/화면 켜짐·BSD 메뉴 20개 PASS.
- `verify_v01735_feature_integration.py`: 23개 음성 이벤트와 대시보드 회귀 PASS.
- `verify_v01733_self_app_dpi.py`, `verify_v01729_unified_evidence.py`: PASS.
- GitHub Actions YAML/셸 파싱, ZIP CRC·SHA 검사 (별도 실행).
- **APK `assembleDebug`/실차 음성은 실행하거나 확인하지 못했다.** 정상 3모드 발화를 최종 VERIFIED로 올리지 않는다.
- 계기판 코드 364가 다른 컨텍스트에서도 나타나면 오인 가능성이 남아 있으므로, ECO 콜백과 시간·순서 교차확인 없이 단독 발화하지 않는다.
- 개발자가 차를 직접 제어하거나 OEM 설정값을 바꾸는 코드 없음.

## 5. 설치·빌드

GitHub 저장소 루트에 `DolphinDrive_v01741_source.zip`, `.github/workflows/build_v01741.yml` 두 파일을 넣어 Actions 실행. 기존 설치 앱을 유지하려면 `DOLPHIN_DEBUG_KEYSTORE_B64` Secret에 **동일한 원본 서명키**가 필요하다. Secret 없으면 생성되는 임시 디버그 키는 인플레이스 업데이트에 사용할 수 없다.
