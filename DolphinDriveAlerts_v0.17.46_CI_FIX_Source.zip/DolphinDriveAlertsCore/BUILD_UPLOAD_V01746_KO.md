# v0.17.46 GitHub 통합 빌드 안내

바깥 `DolphinDrive_v01746_buildpack.zip`을 **한 번만 압축 해제**하면 다음 두 파일이 나옵니다.

1. `DolphinDriveAlerts_v0.17.46_Source.zip` — 전체 Android Studio/Gradle 프로젝트
2. `DolphinDriveAlerts_v0.17.46_Source.yml` — 이 소스 ZIP을 컴파일하는 GitHub Actions 워크플로

저장소 `CP-oss-cell/dolphin-drive-alerts`에서 첫 번째 ZIP을 저장소 루트에 올리고, 두 번째 YML은 `.github/workflows/DolphinDriveAlerts_v0.17.46_Source.yml`에 올립니다. GitHub의 Actions 탭에서 **Build Dolphin Drive Alerts v0.17.46 Dashboard and Runtime Safeguards**를 실행하면 APK를 생성하는 작업이 시작됩니다.

신규 APK 패키지 버전은 `versionName=0.17.46 / versionCode=72`입니다. 파일 이름은 워크플로의 `SOURCE_ZIP`과 일치해야 합니다.

## 주의

- **기존 설치 앱을 지우지 마세요.** 앱의 설정을 보존하려면 기존 설치본과 동일한 서명키가 필요합니다. 이전 서명키가 GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64`에 등록되지 않았으면 새 APK가 기존 설치본에 업데이트되지 않을 수 있습니다.
- 차량 주행 중에는 분할 또는 차량 전체 DPI 변경을 실행하지 마세요.
- 현재 CI는 Android API 34 SDK로 Android 10 호환 소스의 컴파일을 수행합니다. 본 자료 생성 환경에서는 Android APK 실제 컴파일을 완료하지 않았습니다.
- 23종 알림·음성·설정 보존은 소스/순수 Kotlin 검사로 확인했지만 AutoSplit Ghost/차량 NORMAL/DPI 실제 적용은 실차 검증 완료가 아닙니다.
