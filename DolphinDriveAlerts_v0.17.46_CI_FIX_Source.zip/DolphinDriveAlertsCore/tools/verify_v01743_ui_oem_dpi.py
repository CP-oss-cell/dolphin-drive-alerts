#!/usr/bin/env python3
"""New package classification + OEM rule, and safe menu styling gate."""
from pathlib import Path
import tempfile, subprocess, shutil
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda x:(src/x).read_text()
ui=read('ui/AppPolicyActivity.kt');rules=read('dpi/ThirdPartyDpiRules.kt');catalog=read('dpi/DpiAppCatalog.kt')
checks={
 'OEM apps not blanket-excluded': 'pkg.startsWith("com.byd.") ||' not in rules and 'info.flags and ApplicationInfo.FLAG_SYSTEM == 0' not in rules,
 'protect core automotive UI': 'isProtected(pkg)' in rules and 'cluster' in rules and 'com.android.systemui' in rules,
 'category filters': all(x in ui for x in ['내가 설치한 앱','순정/시스템 앱','전체 설치 앱 + 순정']),
 'async package lookup': 'Thread {' in ui and 'DpiAppCatalog.load(applicationContext)' in ui,
 'OEM app without launcher icon supported': 'pm.getInstalledApplications(0)' in catalog and 'getLaunchIntentForPackage' in catalog,
 'safe manual package entry': '패키지 직접 선택' in ui and 'ThirdPartyDpiRules.allowed(this,pkg)' in ui,
 'OEM consent before saving': '순정 앱 DPI 설정 주의' in ui and 'ThirdPartyDpiRules.isSystem(this,pkg)' in ui,
 'no original signal regression': (src/'vehicle/ModeNoticeCorrelator.kt').is_file(),
 'single theme application': 'private var detailThemeApplied = false' in read('dpi/SelfAppDensity.kt'),
 'avoid spinner destructive style': 'is Spinner -> return' in read('ui/DashboardTheme.kt'),
 'dark dropdown text': 'override fun getDropDownView' in read('ui/DarkSpinnerAdapter.kt'),
 'foreground debounce': 'postDelayed(task,350L)' in read('dpi/ForegroundPolicyAccessibilityService.kt'),
 'no stale foreground cache': 'lastPackage' not in read('dpi/TemporaryAppDpiController.kt'),
 'last crash in ZIP': 'diagnostics/$name' in read('log/UnifiedLogCapture.kt'),
 'crash recorder registered': 'android:name=".util.DolphinDriveApplication"' in (root/'app/src/main/AndroidManifest.xml').read_text(),
 'new version': 'versionCode = 69' in (root/'app/build.gradle.kts').read_text()
}
for key,ok in checks.items():print(('PASS ' if ok else 'FAIL ')+key)
assert all(checks.values()), 'UI/OEM integration regression'
if shutil.which('kotlinc'):
 with tempfile.TemporaryDirectory(prefix='oem-dpi-') as tmp:
  work=Path(tmp)
  (work/'Stub.kt').write_text('''package android.content.pm
class ApplicationInfo(val packageName:String,val flags:Int=0) {
 companion object { const val FLAG_SYSTEM=1; const val FLAG_UPDATED_SYSTEM_APP=128 }
}
class PackageManager(val apps:List<ApplicationInfo>) {
 fun getInstalledApplications(flags:Int)=apps
 fun getApplicationInfo(pkg:String,flags:Int):ApplicationInfo=apps.find {it.packageName==pkg}?:throw Exception("missing")
 fun getApplicationLabel(info:ApplicationInfo):CharSequence=info.packageName
 fun getLaunchIntentForPackage(pkg:String):Any?=if(pkg.contains("nav"))null else Any()
}
''')
  (work/'Context.kt').write_text('''package android.content
import android.content.pm.*
open class Context {
 companion object { const val MODE_PRIVATE=0 }
 open val packageName="com.byd.dolphin.drivealerts"
 val packageManager=PackageManager(listOf(
   ApplicationInfo("com.byd.navigation",ApplicationInfo.FLAG_SYSTEM),
   ApplicationInfo("com.byd.media",ApplicationInfo.FLAG_SYSTEM),
   ApplicationInfo("com.acme.music"),
   ApplicationInfo("com.android.systemui",ApplicationInfo.FLAG_SYSTEM),
   ApplicationInfo("com.byd.cluster",ApplicationInfo.FLAG_SYSTEM)
 ))
 fun getSharedPreferences(n:String,m:Int):Prefs=Store.p
}
class Prefs {
 val all:Map<String,Any> get()=props
 private val props=mutableMapOf<String,Any>()
 fun getBoolean(key:String,def:Boolean)=props[key] as? Boolean ?: def
 fun getInt(key:String,def:Int)=props[key] as? Int ?: def
 fun edit()=this
 fun putBoolean(key:String,value:Boolean):Prefs {props[key]=value;return this}
 fun putInt(key:String,value:Int):Prefs {props[key]=value;return this}
 fun commit()=true
}
object Store {val p=Prefs()}
''')
  (work/'Main.kt').write_text('''import android.content.Context
import com.byd.dolphin.drivealerts.dpi.*
fun main() {
 val c=Context()
 check(ThirdPartyDpiRules.allowed(c,"com.byd.navigation"))
 check(!ThirdPartyDpiRules.allowed(c,"com.android.systemui"))
 check(!ThirdPartyDpiRules.allowed(c,"com.byd.cluster"))
 check(ThirdPartyDpiRules.save(c,"com.byd.navigation",140))
 check(ThirdPartyDpiRules.rule(c,"com.byd.navigation")==140)
 check(ThirdPartyDpiRules.save(c,"com.acme.music",200))
 val apps=DpiAppCatalog.load(c)
 check(apps.size==3)
 check(DpiAppCatalog.find(apps,2,"byd").size==2)
 check(DpiAppCatalog.find(apps,1,"").size==1)
 check(DpiAppCatalog.find(apps,0,"navig")[0].launchable==false)
 check(!ThirdPartyDpiRules.save(c,"com.byd.cluster",200))
 println("PASS OEM inclusion, safe exclusion, package search, persistence, launchless app")
}
''')
  jar=work/'test.jar'
  cp=subprocess.run(['kotlinc',str(src/'dpi/ThirdPartyDpiRules.kt'),str(src/'dpi/DpiAppCatalog.kt'),str(work/'Stub.kt'),str(work/'Context.kt'),str(work/'Main.kt'),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=90)
  if cp.returncode:raise RuntimeError(cp.stderr[-5000:])
  rp=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=15)
  if rp.returncode:raise RuntimeError(rp.stderr)
  print(rp.stdout.strip())
print('V01743_OEM_UI_GATES_PASS',len(checks))
