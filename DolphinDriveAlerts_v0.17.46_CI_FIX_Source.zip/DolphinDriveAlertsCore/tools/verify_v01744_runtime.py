from pathlib import Path
import subprocess, tempfile, json, re, sys
from zipfile import ZipFile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
checks=[]
def check(name,good):
 checks.append((name,bool(good)))
 print(('PASS ' if good else 'FAIL ')+name)
 if not good:raise AssertionError(name)
def read(x):return (src/x).read_text()
check('theme is natively dark, not per-resume recursive paint', 'Theme.Material.NoActionBar' in (root/'app/src/main/res/values/styles.xml').read_text() and 'DashboardTheme.decorate' not in read('dpi/SelfAppDensity.kt'))
check('prevent detail view parent crash on re-enter', '(child.parent as? android.view.ViewGroup)?.removeView(child)' in read('ui/MainActivity.kt'))
check('detail groups collapsed but original settings kept', 'activeSection=panel' in read('ui/MainActivity.kt') and 'groups.getValue(id)' in read('ui/MainActivity.kt'))
check('app catalog loaded outside UI thread', '"autolaunch-app-catalog"' in read('automation/AutoLaunchSettingsActivity.kt'))
check('voice tier labels exact', 'listOf("많이 작게", "아주 작게", "조금 작게", "보통")' in read('config/AlertVolume.kt'))
check('previous normal unchanged', 'else -> 0.88f' in read('config/AlertVolume.kt'))
check('split parser understands real am stack list', 'taskPatterns=listOf' in read('automation/LegacySplitTaskLocator.kt') and 'taskId' in read('automation/LegacySplitTaskLocator.kt'))
check('second app launch no longer blocked by first-mode readback', 'if(!firstReady) CoreLog.w' in read('automation/AutoSplitBehaviorEngine.kt'))
check('old split engine not referenced', 'VehicleSplitEngine.' not in read('automation/AutoSplitBehaviorEngine.kt'))
check('external AutoSplit not launched', 'com.sspark.bydautosplit' not in read('automation/AutoSplitBehaviorEngine.kt'))
check('DPI explicit apply before launch', 'applyForLaunch' in read('dpi/TemporaryAppDpiController.kt') and 'startActivity(launch)' in read('ui/AppPolicyActivity.kt'))
check('external OEM system packages enumerated via ADB', 'pm list packages' in read('dpi/DpiAppCatalog.kt'))
check('accessibility foreground observer preserved', 'TYPE_WINDOW_STATE_CHANGED' in read('dpi/ForegroundPolicyAccessibilityService.kt'))
check('normal mode signal left untouched', 'versionCode = 70' in (root/'app/build.gradle.kts').read_text())
# Kotlin exercise: parser real am stack list variants + screen ratio geometry.
with tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp)/'Smoke.kt'
 t.write_text('''package com.byd.dolphin.drivealerts.automation
fun main() {
    val snapshot = """Stack id=2 bounds=[0,0][512,720] mWindowingMode=split-screen-primary
      taskId=81: com.nav.mconk/.MainActivity
      Stack id=4 bounds=[512,0][1280,720] mWindowingMode=split-screen-secondary
      taskId=91: com.maps.tmap/.MainActivity
    """.trimIndent()
    val a=LegacySplitTaskLocator.findTask(snapshot,"com.nav.mconk")
    val b=LegacySplitTaskLocator.findTask(snapshot,"com.maps.tmap")
    require(a.taskId==81 && a.stackId==2 && a.mode==3) { "primary=$a" }
    require(b.taskId==91 && b.stackId==4 && b.mode==4) { "secondary=$b" }
    require(LegacySplitTaskLocator.findStack(snapshot,3)==2)
    require(LegacySplitTaskLocator.findStack(snapshot,4)==4)
    require(!LegacySplitTaskLocator.findTask(snapshot,"com.unknown").found)
    val pair=SplitGeometry.parse(snapshot)
    require(pair != null) { "stack geometry missing" }
    require(SplitGeometry.percent(pair) == 40)
    require(SplitGeometry.resize(pair,60)!!.command.startsWith("am stack resize-docked-stack"))
    println("PASS Kotlin real am stack layout / task parser / ratio")
}''')
 cmd=['kotlinc',str(src/'automation/LegacySplitTaskLocator.kt'),str(src/'automation/SplitGeometry.kt'),str(t),'-include-runtime','-d',str(Path(tmp)/'smoke.jar')]
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=35)
 check('Kotlin split parser compiles',p.returncode==0)
 if p.returncode!=0:print(p.stderr)
 if p.returncode==0:
  p=subprocess.run(['java','-jar',str(Path(tmp)/'smoke.jar')],capture_output=True,text=True,timeout=10)
  print(p.stdout or p.stderr)
  check('Kotlin legacy stack runtime smoke',p.returncode==0)
print(f'{len(checks)}/{len(checks)} static/Kotlin tests passed')
(root/'V01744_STATIC_GATE.log').write_text('\n'.join(('PASS ' if x else 'FAIL ')+n for n,x in checks)+'\n')
