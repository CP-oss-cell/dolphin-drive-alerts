#!/usr/bin/env python3
"""Prevent bridge additions from silently dropping companion sources in partial Kotlin build."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'tools/verify_v0179_callback_kotlin_compile.py').read_text()
b=(p/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ReferenceVehicleEventBridge.kt').read_text()
v=(p/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/AudioFeedbackReference.kt').read_text()
g=(p/'app/build.gradle.kts').read_text()
assert 'AudioFeedbackReference.classify(type)' in b
assert "'vehicle/AudioFeedbackReference.kt'" in s
assert "'vehicle/AudioFeedbackReference.kt'" in (p/'tools/verify_v01711_bsd_any_indicator.py').read_text()
assert 'object AudioFeedbackReference' in v
assert 'versionCode = 65' in g
assert 'DensityAwareActivity:android.app.Activity()' in (p/'tools/verify_v01716_manager_kotlin_compile.py').read_text()
assert 'com.byd.dolphin.drivealerts' in g
assert 'verify_v0179_callback_kotlin_compile.py' in (p/'.github/workflows/build-v01739-dpi-audio-dashboard.yml').read_text()
print('PASS: v0.17.38 callback compiler source dependency closure / package / code')
