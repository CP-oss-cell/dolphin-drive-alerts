from pathlib import Path
root=Path(__file__).resolve().parents[1]
g=(root/'app/build.gradle.kts').read_text()
w=(root/'.github/workflows/build_v01745.yml').read_text()
assert 'System.getenv("DOLPHIN_SIGNING_KEYSTORE_PATH")' in g
assert 'storeFile = file(ciSigningFile)' in g
assert 'signingConfig = signingConfigs.getByName("debug")' in g
assert 'versionCode = 71' in g and 'versionName = "0.17.45"' in g
assert 'SOURCE_ZIP: v01745_source.zip' in w
assert 'DOLPHIN_SIGNING_KEYSTORE_PATH=$HOME/.android/debug.keystore' in w
assert 'if [ "$SIGNING_CERT_SHA256" != "$DOLPHIN_CERT_SHA256" ]; then' in w
assert 'DOLPHIN_INSTALLED_CERT_SHA256' in w
assert 'FRESH-INSTALL ONLY' in w
assert ':app:assembleDebug' in w and 'APK_VOICE_PACK_INTEGRITY' in w
assert 'EXPECTED_CODE=$(sed' in w and 'EXPECTED_NAME=$(sed' in w
print('V01745_CI_SIGNING_GATE PASS')
