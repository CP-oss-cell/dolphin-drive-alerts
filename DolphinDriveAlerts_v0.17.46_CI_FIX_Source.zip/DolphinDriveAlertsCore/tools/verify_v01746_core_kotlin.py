#!/usr/bin/env python3
"""Pure-Kotlin regression suite: no Android SDK or real-car availability claimed."""
from pathlib import Path
import shutil,subprocess,tempfile,sys
root=Path(__file__).resolve().parents[1]
b=root/'app/src/main/java/com/byd/dolphin/drivealerts'
if not (shutil.which('kotlinc') and shutil.which('java')):
 print('KOTLINC_UNAVAILABLE: pure Kotlin fixtures skipped; Gradle compileDebugKotlin remains required')
 sys.exit(0)
fixtures=[
 ('alerts', ['model/AlertModels.kt','model/AlertEventCatalog.kt'], '''package com.byd.dolphin.drivealerts.model
 fun main(){ val l=AlertEventCatalog.entries;check(l.size==23);check(l.map{it.event}.toSet()==AlertEvent.values().toSet());println("PASS 23 alert inventory") }'''),
 ('normal', ['vehicle/ModeNoticeCorrelator.kt'], '''package com.byd.dolphin.drivealerts.vehicle
 fun main(){ val m=ModeNoticeCorrelator();check(!m.onDisplay(364,1000L));check(!m.onDisplay(363,2000L));m.onEnergy(1,2500L);check(m.onDisplay(364,150000L));check(!m.onDisplay(364,151000L));m.reset();check(!m.onDisplay(364,1000L));println("PASS NORMAL correlation proof (requires 364)") }'''),
 ('split', ['automation/LegacySplitTaskLocator.kt','automation/SplitGeometry.kt'], '''package com.byd.dolphin.drivealerts.automation
 fun main(){ val dump="""Stack id=2 bounds=[0,0][512,720] mWindowingMode=split-screen-primary
 taskId=81: com.maps.first/.MainActivity
 Stack id=4 bounds=[512,0][1280,720] mWindowingMode=split-screen-secondary
 taskId=91: com.maps.second/.MainActivity""";val a=LegacySplitTaskLocator.findTask(dump,"com.maps.first");val b=LegacySplitTaskLocator.findTask(dump,"com.maps.second");check(a.mode==3&&b.mode==4);check(SplitGeometry.percent(SplitGeometry.parse(dump)!!)==40);println("PASS Android10 split ownership/geometry fixture") }'''),
]
with tempfile.TemporaryDirectory(prefix='v01746-core-') as td:
 for name,sources,fixture in fixtures:
  work=Path(td);file=work/(name+'.kt');file.write_text(fixture)
  jar=work/(name+'.jar')
  cp=subprocess.run(['kotlinc',*(str(b/x) for x in sources),str(file),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=80)
  if cp.returncode:raise RuntimeError(name+': '+cp.stdout+cp.stderr)
  rp=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
  if rp.returncode:raise RuntimeError(name+': '+rp.stdout+rp.stderr)
  print(rp.stdout.strip())
print('V01746_PURE_KOTLIN_REGRESSION_PASS',len(fixtures))
