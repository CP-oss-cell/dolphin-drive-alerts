#!/usr/bin/env python3
"""Checks the Nov 02 correlated NORMAL transition without requiring any APK or car log."""
from pathlib import Path
import re,shutil,subprocess,tempfile
root=Path(__file__).resolve().parents[1]
mode=(root/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ModeNoticeCorrelator.kt').read_text()
bridge=(root/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ReferenceVehicleEventBridge.kt').read_text()
prefs=(root/'app/src/main/java/com/byd/dolphin/drivealerts/config/AlertPreferences.kt').read_text()
ui=(root/'app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt').read_text()
tests={
 '365-sport/363-eco/364-normal': 'code==364 && previous==363 && currentEnergy==1' in mode,
 'eco-callback-pair': 'lastNotice==363 && value==1' in mode,
 'sport-callback-pair': 'lastNotice==365 && value==2' in mode,
 'no-immediate-bare-364': 'ecoMatchedAt>0' in mode,
 'no-sport-precondition': 'sportMatchedAt>0 &&' not in mode,
 'stale-eco-guard': 'now-ecoMatchedAt in 0L..6000L' in mode,
 'no-other-notice': 'if (code !in 363..365)' in mode,
 'app-preference-on-by-default': 'getBoolean("normal_notice_candidate_opt_in", true)' in prefs,
 'opt-out-available': 'setNormalNoticeCandidateEnabled' in ui,
 'normal-voice-emitted': 'emit(AlertEvent.DRIVE_NORMAL,"audiofeedback_style:eco1_confirmed_then_notice364")' in bridge,
 'raw2-still-sport': 'DriveModeDecoder.fromEnergyOperationMode(type)' in bridge,
 'no-BYD-write': 'BYDAutoEnergyDevice.set' not in mode,
}
for name,ok in tests.items():
 print(('PASS' if ok else 'FAIL')+' '+name)
assert all(tests.values())
if shutil.which('kotlinc') and shutil.which('java'):
 harness='''package com.byd.dolphin.drivealerts.vehicle
fun main(){
 val g=ModeNoticeCorrelator()
 check(!g.onDisplay(365,1000));g.onEnergy(2,1500)
 check(!g.onDisplay(363,3000));g.onEnergy(1,3900)
 check(g.onDisplay(364,5100));check(!g.onDisplay(364,5300))
 check(!g.onDisplay(365,6400));g.onEnergy(2,6700)
 check(!g.onDisplay(364,7000))
 g.reset();check(!g.onDisplay(364,8000))
 g.reset();check(!g.onDisplay(363,1000));g.onEnergy(1,1300)
 check(!g.onDisplay(364,8000))
 g.reset();check(!g.onDisplay(363,1000));g.onEnergy(1,1300)
 check(g.onDisplay(364,1800))
 println("PASS native Kotlin NORMAL transition")
}
'''
 with tempfile.TemporaryDirectory() as td:
  path=Path(td)/'Harness.kt';path.write_text(harness)
  subprocess.run(['kotlinc',str(root/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ModeNoticeCorrelator.kt'),str(path),'-include-runtime','-d',str(Path(td)/'check.jar')],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
  subprocess.run(['java','-jar',str(Path(td)/'check.jar')],check=True,timeout=30)
else:print('SKIP native Kotlin simulation (kotlinc or java not present; static gates PASSED)')
print('V01741_MODE_GATES_PASS')
