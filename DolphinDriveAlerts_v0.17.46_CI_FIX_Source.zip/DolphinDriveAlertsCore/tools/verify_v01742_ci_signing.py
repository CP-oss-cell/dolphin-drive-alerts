#!/usr/bin/env python3
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
g = (root/'app/build.gradle.kts').read_text()
w = (root/'.github/workflows/build_v01742.yml').read_text()
checks = {
  'gradle CI key path': 'System.getenv("DOLPHIN_SIGNING_KEYSTORE_PATH")' in g,
  'gradle uses validated debug key': 'storeFile = file(ciSigningFile)' in g and 'signingConfig = signingConfigs.getByName("debug")' in g,
  'gradle debug key credentials': all(x in g for x in ['keyAlias = "androiddebugkey"','storePassword = "android"','keyPassword = "android"']),
  'release identity': 'versionCode = 68' in g and 'versionName = "0.17.42"' in g,
  'workflows key environment': 'DOLPHIN_SIGNING_KEYSTORE_PATH=$HOME/.android/debug.keystore' in w,
  'workflows compare actual APK cert': 'if [ "$SIGNING_CERT_SHA256" != "$DOLPHIN_CERT_SHA256" ]; then' in w,
  'existing installed cert check': 'DOLPHIN_INSTALLED_CERT_SHA256' in w,
  'ephemeral warning': 'FRESH-INSTALL ONLY' in w,
  'actual APK build': ':app:assembleDebug' in w,
  'APK voice package check': 'APK_VOICE_PACK_INTEGRITY' in w,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values()), 'CI signing regression'
