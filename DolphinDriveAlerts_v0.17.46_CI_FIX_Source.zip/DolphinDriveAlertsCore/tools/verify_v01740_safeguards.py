from pathlib import Path
import subprocess, tempfile, shutil
root=Path(__file__).resolve().parent.parent
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda p:(src/p).read_text()
checks={
    'own_split_engine': 'object AutoSplitBehaviorEngine' in read('automation/AutoSplitBehaviorEngine.kt'),
    'no_legacy_split_engine': not (src/'automation/VehicleSplitEngine.kt').exists(),
    'no_external_autosplit_invoke': 'com.byd.autosplit' not in read('automation/AutoSplitBehaviorEngine.kt').lower(),
    'split_task_move': 'am stack move-task' in read('automation/AutoSplitBehaviorEngine.kt'),
    'split_primary_secondary': '--windowingMode 3' in read('automation/AutoSplitBehaviorEngine.kt') and '--windowingMode 4' in read('automation/AutoSplitBehaviorEngine.kt'),
    'split_resize_docked': 'SplitGeometry.resize(' in read('automation/AutoSplitBehaviorEngine.kt'),
    'split_external_zero': all('AutoSplitBehaviorEngine.' in read('automation/'+name) for name in ['SplitProfilesActivity.kt','AutoLaunchSequenceService.kt','SplitRecoveryService.kt']),
    'ignition_on_only': '"com.byd.action.ACC_ON", "com.byd.action.IGN_ON"' in read('service/BootReceiver.kt').split('private val AUTO_SEQUENCE_ACTIONS = setOf(')[1].split(')')[0],
    'no_on_door_wake': 'Intent.ACTION_SCREEN_ON' not in read('service/BootReceiver.kt').split('private val AUTO_SEQUENCE_ACTIONS = setOf(')[1].split(')')[0],
    'ignition_off_gate': 'com.byd.action.ACC_OFF' in read('automation/IgnitionOffAppStopper.kt'),
    'ignore_usb_power_off': 'source != "com.byd.action.ACC_OFF"' in read('automation/IgnitionOffAppStopper.kt'),
    'user_selected': 'fun selected(' in read('automation/IgnitionOffAppStopper.kt') and 'AppSelection.launchable' in read('automation/IgnitionOffAppStopper.kt'),
    'protect_oem_system': '!p.startsWith("com.byd.")' in read('automation/IgnitionOffAppStopper.kt'),
    'force_stop_via_adb': 'am force-stop --user 0 $pkg' in read('automation/IgnitionOffAppStopper.kt'),
    'stop_service_lifecycle': 'class IgnitionOffStopService : Service()' in read('automation/IgnitionOffStopService.kt'),
    'no_duplicate_bsd_card': 'listOf(1,3,4,5,6).chunked(cardsPerLine)' in read('ui/MainActivity.kt'),
    'bsd_controls_join_alert': '"후측방 경고 · 두 가지 독립 설정" to 1' in read('ui/MainActivity.kt'),
    'mode_edge_state': 'internal class EcoOffNormalMachine' in read('vehicle/EcoOffNormalMachine.kt'),
    'mode_no_blind_transition': 'ecoOffNeedsDistinctSignal=true' in read('vehicle/ReferenceVehicleEventBridge.kt'),
    'native_app_dpi_kept': (src/'dpi/SelfAppDensity.kt').exists(),
}
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values()), 'preflight failed'
# Compile the pure state machine with Kotlin to verify on/off transitions.
code='''package com.byd.dolphin.drivealerts.vehicle
fun main(){
 val m=EcoOffNormalMachine()
 check(m.ecoState(true)==EcoOffNormalMachine.Mode.ECO)
 check(m.ecoState(false)==EcoOffNormalMachine.Mode.NORMAL)
 check(m.ecoState(false)==null)
 check(m.ecoState(true)==EcoOffNormalMachine.Mode.ECO)
 check(m.sportState(true)==EcoOffNormalMachine.Mode.SPORT)
 check(m.ecoState(false)==null)
 check(m.sportState(false)==EcoOffNormalMachine.Mode.NORMAL)
 m.reset()
 check(m.ecoState(false)==null)
 println("PASS mode-edge kotlin execution")
}'''
if shutil.which('kotlinc') and shutil.which('java'):
 with tempfile.TemporaryDirectory() as d:
  fn=Path(d)/'Test.kt';fn.write_text(code)
  exe=Path(d)/'test.jar'
  subprocess.run(['kotlinc',str(src/'vehicle/EcoOffNormalMachine.kt'),str(fn),'-include-runtime','-d',str(exe)],check=True,stdout=subprocess.DEVNULL)
  subprocess.run(['java','-jar',str(exe)],check=True)
else:
 print('SKIP isolated Kotlin test: compiler missing; full Gradle compileDebugKotlin mandatory')
print('ALL_V01740_GATES_PASS')
