#!/usr/bin/env python3
"""Non-Android static integration checks; never calls these real-car verified."""
from pathlib import Path
r=Path(__file__).resolve().parents[1];base=r/'app/src/main/java/com/byd/dolphin/drivealerts'
f=lambda x:(base/x).read_text()
checks={
 'four-alert-volume-tiers':all(x in f('config/AlertVolume.kt') for x in ['조금 작게','작게','보통','크게','getInt(KEY, 2)']),
 'audio-volume-to-pcm': f('audio/AlertAudioPlayer.kt').count('AlertVolume.trackGain(')>=3,
 'loud-peak-limiter':'safeLoudPcm' in f('audio/AlertAudioPlayer.kt') and '30000.0 / peak' in f('config/AlertVolume.kt'),
 'global-density-write-confirmed':'wm density $requested' in f('dpi/DisplaySettingsController.kt') and 'after.override == requested' in f('dpi/DisplaySettingsController.kt'),
 'temporary-app-rules-opt-in':'getBoolean(ENABLED,false)' in f('dpi/ThirdPartyDpiRules.kt'),
 'temporary-rules-readback-restore':'now?.override == assigned' in f('dpi/TemporaryAppDpiController.kt') and 'restore(app)' in f('dpi/TemporaryAppDpiController.kt'),
 'adb-only-no-oem-write':'AuthorizedAdbRuntime.writeOnce' in f('dpi/TemporaryAppDpiController.kt'),
 'per-app-accessibility-live':'TemporaryAppDpiController.onForeground(this,pkg)' in f('dpi/ForegroundPolicyAccessibilityService.kt'),
 'separate-own-app-dpi':'SelfAppDensity.save' in f('ui/AppPolicyActivity.kt'),
 'user-opt-in-normal':'normal_notice_candidate_opt_in", false' in f('config/AlertPreferences.kt'),
 'normal-multi-evidence':'ecoMatchedAt>0 && sportMatchedAt>0' in f('vehicle/ModeNoticeCorrelator.kt'),
 'normal-source-connected':'modeNoticeCorrelator.onDisplay' in f('vehicle/ReferenceVehicleEventBridge.kt') and 'modeNoticeCorrelator.onEnergy' in f('vehicle/ReferenceVehicleEventBridge.kt'),
 'all-detail-dashboard':'DashboardTheme.decorate(this)' in f('dpi/SelfAppDensity.kt') and 'DashboardTheme.kt' in [p.name for p in (base/'ui').iterdir()],
 'log-includes-new-settings': all(t in f('log/RuntimeFeatureSnapshot.kt') for t in ['alertVolumeTier','thirdPartyDpiAutoEnabled','normalNoticeExperimentalEnabled']),
 'six-cards': 'val titles = listOf("주행 알림", "BSD 알림", "화면 · 분할", "오디오 · 내비", "자동 실행 · 권한", "로그 · 진단")' in f('ui/MainActivity.kt'),
 'internal-split-preserved':'VehicleSplitEngine' in f('automation/SplitProfilesActivity.kt'),
 'vcode-65':'versionCode = 65' in (r/'app/build.gradle.kts').read_text()
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' '+k)
assert all(checks.values())
print('TOTAL',len(checks),'source-level ONLY')
