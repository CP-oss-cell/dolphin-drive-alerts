#!/usr/bin/env python3
"""v0.17.46 source audit + real Kotlin fixtures. NOT an Android Gradle or car test."""
from pathlib import Path
import subprocess,tempfile,shutil,re,json
root=Path(__file__).resolve().parents[1]
s=root/'app/src/main/java/com/byd/dolphin/drivealerts'
old=Path(__file__).resolve().parents[2] if False else None
read=lambda x:(s/x).read_text(encoding='utf8')
main=read('ui/MainActivity.kt')
ui=read('ui/DashboardUi.kt')
auto=read('automation/AutoSplitBehaviorEngine.kt')
foreground=read('automation/ForegroundResolver.kt')
dpi=read('dpi/TemporaryAppDpiController.kt')
media=read('automation/MediaPlaybackObserver.kt')
boot=read('service/BootReceiver.kt')
mode=read('vehicle/ModeNoticeCorrelator.kt')
checks={
 'scrollview-android-java-setter': 'ScrollView(this).apply{setFillViewport(true)' in main and 'fillViewport=true' not in main,
 'v01746-code72':'versionCode = 72' in (root/'app/build.gradle.kts').read_text() and 'versionName = "0.17.46"' in (root/'app/build.gradle.kts').read_text(),
 'full-native-main-dashboard': 'private fun showCategory' in main and 'private fun showHome' in main and 'fun showDashboard' not in main,
 'remove-legacy-menu-relocation': 'private fun organizeUi(' not in main and 'makeLegacyTextReadable' not in main and 'legacyToCategory' not in main,
 'all-five-dashboard-categories':all(x in main for x in ['주행 알림','시동 자동 실행','화면 · 분할 · DPI','오디오 · 내비','권한 · 로그 · 진단']),
 'no-old-six-page-source':'groups.getValue' not in main and 'titles = listOf("주행 알림 · BSD", "",' not in main,
 'all-menus-dark-cards':'fun panel(' in ui and 'fun mount(' in ui and 'fun refresh(' in ui,
 'nine-detail-activities-mounted':sum('DashboardUi.mount(' in (s/x).read_text() for x in [
   'ui/AdbSetupActivity.kt','ui/AlertEventSettingsActivity.kt','ui/AppPermissionManagerActivity.kt',
   'ui/AppPolicyActivity.kt','ui/AudioTuningActivity.kt','ui/DriveModeCalibrationActivity.kt',
   'ui/NavAudioLabActivity.kt','automation/AutoLaunchSettingsActivity.kt','automation/SplitProfilesActivity.kt'])==9,
 'maintain-23-alert-control':'AlertEventSettingsActivity::class.java' in main and 'AlertEventCatalog.entries.groupBy' in read('ui/AlertEventSettingsActivity.kt'),
 'keep-normal-and-volume-4':all(t in main for t in ['normalNoticeCandidateEnabled','많이 작게','아주 작게','조금 작게','보통']) or ('AlertVolume.labels' in main and 'normalNoticeCandidateEnabled' in main),
 'keep-bsd-three-controls':all(k in main for k in ['bsdBlinkerEnabled','bsdTurnSoundExperimentalEnabled','bsdInstantEnabled']),
 'keep-steering': 'SteeringTriggerPreferences.enabled' in main,
 'keep-ignition-media-nav-eq':all(k in main for k in ['AutoLaunchSettingsActivity::class.java','NavAudioLabActivity::class.java','AudioTuningActivity::class.java']),
 'keep-split-dpi-rotation':all(k in main for k in ['SplitProfilesActivity::class.java','AppPolicyActivity::class.java','RotationPolicy.setEnabled']),
 'keep-ADB-permission':all(k in main for k in ['AdbSetupActivity::class.java','AppPermissionManagerActivity::class.java','PermissionBootstrapper.apply']),
 'keep-logging-and-avas':all(k in main for k in ['beginUnifiedCapture','endUnifiedCapture','captureQuick','captureWindow','shareLatestLogZip']),
 'android-10-multi-resume-aware':'topResumedActivity' in foreground and 'distinct()' in foreground and 'lastOrNull' not in foreground,
 'split-avoid-fullscreen-flags':'--windowingMode 3 -n' in auto and '--windowingMode 4 -n' in auto and '-f 0x18000000' not in auto,
 'camera-avc-detection':'com\\\\.byd\\\\.avc' in foreground or 'com\\.byd\\.avc' in foreground,
 'dpi-recovery-retry':'restoreOrRetry' in dpi and 'scheduleRestore(c,id,attempt+1)' in dpi and 'RESTORE_RETRY_EXHAUSTED' in dpi,
 'DPI-target-topresumed':'ForegroundResolver.topToken' in dpi,
 'media-played-not-buffering': 'val accepted = status == PlaybackState.STATE_PLAYING' in media and 'it.playbackState?.state == PlaybackState.STATE_PLAYING' in media,
 'generic-power-disconnect-not-ignition-off':'private val STOP_SIDE_ACTIONS = setOf("com.byd.action.ACC_OFF")' in boot,
 'feature-journal-expands':all(tag in read('log/FeatureActionJournal.kt') for tag in ['"SPLIT_RESTORE"','"ADB_RUNTIME"']),
 'OEM-read-only':'BYDAutoEnergyDevice.set' not in auto+dpi+mode,
 'event-23-complete':len(re.findall(r'Entry\(AlertEvent\.',read('model/AlertEventCatalog.kt')))==23,
 'manifest-retained': all(k in (root/'app/src/main/AndroidManifest.xml').read_text() for k in ['.service.DrivingAlertService','.automation.SplitRecoveryService','.automation.AutoLaunchSequenceService','.ui.NavAudioLabActivity']),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+'  '+k)
assert all(checks.values()),'source gate failed'
if shutil.which('kotlinc'):
 with tempfile.TemporaryDirectory(prefix='v01746-kotlin-') as d:
  path=Path(d);(path/'Fixture.kt').write_text('''package com.byd.dolphin.drivealerts.automation
fun main() {
 val x="""mResumedActivity: ActivityRecord{a u0 com.nav.one/.Main t1}
 mResumedActivity: ActivityRecord{b u0 com.media.two/.Main t2}"""
 require(ForegroundResolver.topToken(x)==null) // ambiguous Android 10 multi-resume
 val top="""$x\n topResumedActivity=ActivityRecord{b u0 com.media.two/.Main t2}"""
 require(ForegroundResolver.packageName(ForegroundResolver.topToken(top)!!) == "com.media.two")
 require(ForegroundResolver.camera("topResumedActivity com.byd.avc/.Camera"))
 require(!ForegroundResolver.camera("topResumedActivity com.music.player/.Main"))
 println("PASS ForegroundResolver: top-resumed, ambiguity, camera")
}
''')
  jar=path/'fixture.jar'
  a=subprocess.run(['kotlinc',str(s/'automation/ForegroundResolver.kt'),str(path/'Fixture.kt'),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=80)
  assert a.returncode==0,a.stdout+a.stderr
  b=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=15)
  assert b.returncode==0,b.stdout+b.stderr
  print(b.stdout.strip())
print('V01746_GATES_PASS',len(checks))
