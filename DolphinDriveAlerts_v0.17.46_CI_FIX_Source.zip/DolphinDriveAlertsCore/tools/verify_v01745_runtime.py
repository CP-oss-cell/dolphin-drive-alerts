#!/usr/bin/env python3
"""v0.17.45 regression checks: source invariants and actual pure-Kotlin execution.
Android Gradle compile + BYD car remain separate required verification.
"""
from pathlib import Path
import subprocess, tempfile, shutil
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
checks=[]
def assert_gate(k,ok):
 print(('PASS ' if ok else 'FAIL ')+k)
 checks.append((k,ok))
 if not ok:raise AssertionError(k)
def read(p):return (src/p).read_text(encoding='utf-8')
mode=read('vehicle/ModeNoticeCorrelator.kt')
bridge=read('vehicle/ReferenceVehicleEventBridge.kt')
split=read('automation/AutoSplitBehaviorEngine.kt')
dpi=read('dpi/TemporaryAppDpiController.kt')
ui=read('ui/AppPolicyActivity.kt')
media=read('automation/AutoLaunchSequenceService.kt')
observer=read('automation/MediaPlaybackObserver.kt')
exporter=read('log/UnifiedLogCapture.kt')
core=read('util/CoreLog.kt')
assert_gate('versionName_01745', 'versionCode = 71' in (root/'app/build.gradle.kts').read_text() and 'versionName = "0.17.45"' in (root/'app/build.gradle.kts').read_text())
assert_gate('normal_requires_real_364_event', 'code==364' in mode and 'ecoMatchedAt>0L' in mode and 'normalEmittedForEco' in mode and 'emit(AlertEvent.DRIVE_NORMAL' in bridge)
assert_gate('normal_no_6second_expiry', '6000L' not in mode and 'now>=ecoMatchedAt' in mode)
assert_gate('normal_not_blindly_announced', 'needsLive364=true' in mode)
assert_gate('split_reference_launch_flags', '--windowingMode 3 -f 0x18000000' in split and '--windowingMode 4 -f 0x18000000' in split)
assert_gate('split_no_ghost_or_third_party', 'SplitGhostActivity' not in split and 'com.sspark.bydautosplit' not in split)
assert_gate('split_two_stages_early', split.index('write(c,primary)')<split.index('write(c,secondary)')<split.index('var a=state('))
assert_gate('split_ownership_strict', 'a.taskId!=b.taskId && a.stackId!=b.stackId' in split and 'SPLIT_NOT_CONFIRMED' in split)
assert_gate('dpi_transaction_launch_inside_worker', 'am start -W --user 0' in dpi and 'onResult(DisplaySettingsController.Result(true' in dpi and 'startActivity(launch)' not in ui)
assert_gate('dpi_failure_rolls_back', 'LAUNCH_FAILED' in dpi and 'restore(app)' in dpi and 'RESTORE_FAILED' in dpi)
assert_gate('dpi_foreground_watchdog', 'target-not-foreground' in dpi and 'app-left' in dpi and 'absoluteExpiry' in dpi)
assert_gate('dpi_preserves_auto_preference', 'ThirdPartyDpiRules.setEnabled(app,true)' not in dpi)
assert_gate('media_fallback_guarded', 'MEDIA_KEY_SKIPPED_OTHER_FOREGROUND' in media and 'input keyevent 126' in media and 'ignition_sequence_guard' in media)
assert_gate('media_playback_readback', 'MediaPlaybackObserver.isPlaybackActive(this,pkg)' in media and 'fun isPlaybackActive' in observer)
assert_gate('unified_capture_actions', 'logs/feature_actions.jsonl' in exporter and 'FeatureActionJournal.selection' in exporter and 'FeatureActionJournal.record' in core)
assert_gate('alert_and_split_settings_unchanged', (src/'automation/SplitProfilesActivity.kt').exists() and (src/'config/AlertVolume.kt').exists())
assert_gate('no_oem_vehicle_write_added', 'BYDAutoEnergyDevice.set' not in mode+split+dpi+media)
if shutil.which('kotlinc') and shutil.which('java'):
 with tempfile.TemporaryDirectory() as d:
  t=Path(d)/'Test.kt'
  t.write_text('''package com.byd.dolphin.drivealerts.vehicle
fun main(){
 val m=ModeNoticeCorrelator()
 check(!m.onDisplay(364,1000L)) // standalone 364 never plays
 check(!m.onDisplay(363,2000L));m.onEnergy(1,3000L)
 check(!m.onDisplay(990,50_000L)) // unrelated instrument notices no longer erase ECO
 check(m.onDisplay(364,3_600_000L)) // ECO to NORMAL after dashboard label disappears
 check(!m.onDisplay(364,3_601_000L)) // no duplicate
 check(!m.onDisplay(365,3_602_000L));m.onEnergy(2,3_602_500L)
 check(!m.onDisplay(364,3_603_000L)) // sport disarms eco
 m.reset();check(!m.onDisplay(363,1_000L));m.onEnergy(2,2_000L)
 check(!m.onDisplay(364,3_000L))
 println("PASS native Kotlin delayed NORMAL, duplicate rejection, SPORT guard")
}''')
  jar=Path(d)/'mode.jar'
  proc=subprocess.run(['kotlinc',str(src/'vehicle/ModeNoticeCorrelator.kt'),str(t),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=75)
  assert_gate('Kotlin-mode-compile',proc.returncode==0)
  if proc.returncode!=0:print(proc.stderr)
  proc=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=15)
  assert_gate('Kotlin-mode-execute',proc.returncode==0)
  print(proc.stdout or proc.stderr)
  z=Path(d)/'Split.kt'
  z.write_text('''package com.byd.dolphin.drivealerts.automation
fun main() {
 val x="""Stack id=2 bounds=[0,0][512,720] mWindowingMode=split-screen-primary
  taskId=81: com.maps.first/.MainActivity
  Stack id=4 bounds=[512,0][1280,720] mWindowingMode=split-screen-secondary
  taskId=91: com.maps.second/.MainActivity""".trimIndent()
 val a=LegacySplitTaskLocator.findTask(x,"com.maps.first")
 val b=LegacySplitTaskLocator.findTask(x,"com.maps.second")
 require(a.taskId==81 && a.stackId==2 && a.mode==3)
 require(b.taskId==91 && b.stackId==4 && b.mode==4)
 require(SplitGeometry.percent(SplitGeometry.parse(x)!!)==40)
 require(SplitGeometry.resize(SplitGeometry.parse(x)!!,60)!!.command.contains("resize-docked-stack"))
 println("PASS Kotlin split stack ownership/geometry")
}''')
  jar=Path(d)/'split.jar'
  proc=subprocess.run(['kotlinc',str(src/'automation/LegacySplitTaskLocator.kt'),str(src/'automation/SplitGeometry.kt'),str(z),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=75)
  assert_gate('Kotlin-split-compile',proc.returncode==0)
  if proc.returncode!=0:print(proc.stderr)
  proc=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=15)
  assert_gate('Kotlin-split-execute',proc.returncode==0)
  print(proc.stdout or proc.stderr)
else:print('SKIP native Kotlin command-line tests: GitHub Gradle compile mandatory')
print(f'V01745_SOURCE_GATES_PASS {len(checks)}')
