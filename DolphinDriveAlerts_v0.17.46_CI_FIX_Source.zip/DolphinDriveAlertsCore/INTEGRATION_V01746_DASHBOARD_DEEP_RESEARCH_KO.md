# Dolphin Drive Alerts v0.17.46 — 대시보드 전면 교체 및 전체 기능 심화 연구

- 연구 차수: DDA-R20261103-06
- 빌드 기준: v0.17.45 (versionCode 71) → **v0.17.46 (versionCode 72)**
- 차량 대상: 한국 출시 BYD 돌핀, Android 10/DiLink 3, 1280×720·기본 DPI 160, 글로벌 2602 사용자 연구 환경
- 검토 원천: v0.17.45 전체 Kotlin·Gradle·Manifest 소스, 2026-11-02 및 11-03 실차 진단 ZIP, 연구 R01~R05, 원본 AutoSplit 1.2.0 APK와 BYD Audio Feedback v1.0 APK에 관한 이전 DEX 보고서, Android 10 공식 multi-resume/미디어 세션 문서.
- 안전 원칙: **차량 ECU·순정 안전 설정·계기판에 쓰기 명령 추가 금지.** 화면 분할과 일시적 DPI 등은 Android 화면 작업이며 로컬 ADB 승인 필요. 정상 동작하는 23종 알림 구현과 차량 콜백 코드는 이번 버전에서 변경하지 않음.

## A. 사용자 보고 재발의 원인과 UI 구조 전면 교체

### 확인된 원인
- 이전 MainActivity는 `buildUi()`에서 17개 구형 섹션과 버튼·체크박스를 전부 만든 뒤 `organizeUi()`에서 재사용할 뷰를 6개 그룹으로 옮기는 구조였다. 그래서 카드 첫 화면에 진입해도 세부 메뉴는 옛 목록 그대로 표시됐다.
- 이전 페이지를 다시 열 때 뷰 소유권과 이전 부모 관계를 관리해야 했으므로, 화면 재진입 충돌 위험이 있었다. AndroidRuntime 크래시 스택과 직접 1:1 대조한 원인 확정은 아님.
- ADB·분할·DPI·앱 자동실행 등 별도 Activity 9개는 각자 평면 목록을 만들고 있었으므로, 메인만 바꿔도 전체 화면이 통일되지 않았다.

### v0.17.46에 실제 반영
1. **MainActivity 구형 `organizeUi`와 `legacyToCategory`를 제거**하고 다섯 카테고리를 직접 생성하는 구조로 전체 교체: ①주행 알림 ②시동 자동 실행 ③화면·분할·DPI ④오디오·내비 ⑤권한·로그·진단.
2. 메인·상세를 열 때 설정 뷰를 이전 페이지에서 떼어 재활용하지 않고 새로 만든다. 저장된 설정값은 기존 `AlertPreferences`, `FeatureProfiles`, `RotationPolicy` 등에서 읽는다.
3. 공통 `DashboardUi.kt` 추가: 한국어 고정 헤더, 뒤로가기, 네이비 배경, 글자가 보이는 카드형 버튼·토글·라벨, 기존 드롭다운의 전용 다크 어댑터 유지.
4. **별도 Activity 9개**(ADB 연결, 23종 알림, 앱 권한, 앱 DPI, 이퀄라이저, 주행모드 읽기, 내비 오디오, 자동 실행, 분할 프로필)를 공통 대시보드 셸로 표시하고 제목별 섹션 카드로 정리한다. 사용자 이벤트 리스너와 설정 저장 로직은 유지.
5. 예전의 독립 BSD 메인 진입, 중복 내비 체크 화면, 일회성 설명 섹션을 주요 메뉴에서 제거/통합했다. **차량 이벤트 처리 코드·저장 옵션 자체를 삭제하지 않는다.**

### 화면별 기능 보존 맵

| 대시보드 | 실제 연결된 기존 기능 |
|---|---|
| 주행 알림 | 전체 음성 ON/OFF, 23종 개별 스위치, 운전석 stream14/raw14/미디어 출력, 여성/남성/효과음, 4단계 조용한 음량, ECO→NORMAL 후보, 3종 BSD 설정, 핸들 단발음, 주행모드 원시값 읽기 |
| 자동 실행 | 시동 시 서비스 자동 시작, 등록 앱 순서·지연, 미디어 세션 재생, 시동 OFF 대상 앱 종료 설정, 권한 화면 |
| 화면·분할·DPI | 2앱 프로필·비율·바로가기·카메라 복귀, 주행보조 자체 DPI, 선택 앱 임시 DPI/순정 앱 검색, 회전, 오버레이 권한 |
| 오디오·내비 | 내비 5종 대상 ON/OFF, OEM/타사 안내음 경로 진단, 운전석 출력 후보, 3밴드 EQ/음장 |
| 권한·로그 | ADB/RSA/권한 관리, 통합 로그 수집 시작·종료, ZIP 공유, 읽기 전용 점검, 순정 내비·외부 AVAS 기록 버튼 |

## B. 전체 기능 심화 연구 및 변경 사항

### B1. 23종 운전 알림 / ECO·NORMAL·SPORT — 핵심 안전 경로 불변
- `AlertEventCatalog`에 기어/회생/스노우 8, 주행모드 3, 오토홀드/EPB 6, ADAS/BSD 6 = 총 23개가 중복 없이 등록돼 있다. 사용자 스위치·재생 카탈로그와 기존 차량 이벤트 감지는 그대로 유지.
- 오토홀드 작동/해제와 회생제동 하이/스탠다드, 일부 ECO/SPORT와 회전은 **과거 실차에서 동작 보고**, 현재 새 버전의 실차 재확인과 구분해야 한다.
- `ModeNoticeCorrelator`는 ECO/SPORT 후보와 계기판 `364`를 상관시켜 NORMAL을 추정한다. 계기판 표시가 사라진 뒤에도 `364` 이벤트 자체가 없으면 발화할 수 없다. **새 버전에서 이 미확정 판단을 강제로 개선했다고 주장하지 않는다.**
- Audio Feedback v1.0 DEX 연구에서 `onOperationModeChanged(1/2)`는 스포츠 OFF/ON 음원 두 개만 직접 확인됐다. ECO·NORMAL·SPORT 세 개의 독립 신호를 그 APK로부터 얻었다고 볼 수 없다. 값 1을 무조건 독립 NORMAL로 바꾸는 것은 오탐 우려가 있어 보류.
- BSD 좌우, ICC 차선/앞차출발 원시 신호 및 독립 NORMAL 확정은 실차 미검증. 순정 주행 경고 억제·제어는 하지 않는다.

### B2. AutoSplit 1.2.0 / 화면 분할·360 복귀
- 원본 AutoSplit DEX 분석의 분할 순서에는 1번 Task 조회 → 모드3 → Ghost 스택 생성·탐색 → Task 이동 → 모드4 → 상태 판독 → 비율 변경 → 카메라 전환 후 복원이 들어 있다. 우리 v0.17.45는 **Ghost 스택을 실제로 호출하지 않는다.** 원본 전체 기능을 복사했다고 표현하면 틀리다.
- 참고 앱의 **분할 실행에서 확인되지 않은** `-W`와 `-f 0x18000000`을 제거하고, `am start --user 0 --windowingMode 3/4 -n ...` 호출로 복원했다. 0x18000000은 참고 APK의 전체화면 복귀 명령에서 관찰됐다.
- Android 10에서는 두 앱이 동시에 RESUMED 될 수 있다. `RESUMED` 마지막 줄을 전면 앱으로 취급하던 로직을 공통 `ForegroundResolver.topToken`으로 대체: top-resumed 우선, 복수 모호성에서는 앱 식별을 포기.
- 360 패키지 식별에 원본 AutoSplit의 `com.byd.avc`를 추가했다.
- **미완:** 참고 앱의 Ghost 스택 생성·완전한 task fallback은 아직 재구성되지 않았으며, 차량의 실제 2앱 분할·비율·360 복원 성공 증거가 없다. 이 기능은 빌드 후보 수준이다.

### B3. 지정 앱 DPI / MCONK / 순정 내비
- Android 10의 `wm density`는 **디스플레이 전체 설정**이다. 선택한 앱만 독립 적용되는 진정한 앱별 DPI가 아니다. 순정 앱 검색 가능 여부와 독립 실행 가능한 Activity 존재 여부는 별개다.
- v0.17.45는 DPI를 먼저 바꾼 뒤 `am start`를 보냈다. v0.17.46은 **대상 앱 실행 명령 성공을 먼저 확인한 뒤** 원래 DPI를 영속 기록하고 density 변경을 진행한다. 앱 실행 명령이 실패하면 차량 화면 DPI는 바꾸지 않는다.
- 공통 전면 앱 해석 적용, 대상 앱 이탈 확인 후 이전 override 복원. 복원 ADB 오류 시 저널을 지우지 않고 제한된 자동 재시도(최대 20회, 간격 확대) 및 다음 앱 시작 시 복구.
- 이전 코드의 15분 강제 원복을 제거해 대상 앱 전면 유지 시 설정을 조기에 바꾸지 않는다. 전면 판정 자체가 불명확할 때는 안전 제한을 둔다.
- **미완:** MCONK 200DPI 실차 적용 성공, 순정 내비 독립 액티비티 및 OEM 태스크 감지는 확인되지 않았다. 성공을 보장하지 않는다.

### B4. 시동 자동 실행 / 미디어
- 기존 주행보조 서비스 시작과 사용자 등록 앱 실행 시퀀스는 분리돼 있다. 미디어 재생은 MediaSession/MediaBrowserService 지원과 세션 생성 타이밍에 영향을 받는다.
- `MediaPlaybackObserver`는 기존에 `BUFFERING`도 성공으로 보아 백그라운드 복귀가 빨라질 수 있었다. 이제 **`PLAYING`일 때만 재생 성공**으로 판단한다. 단, 실제 스피커 출력은 별도 문제다.
- Android의 일반 `ACTION_POWER_DISCONNECTED`는 차량의 실제 시동 OFF가 아니므로 자동 시퀀스 취소 조건에서 제외하고, **명시적 BYD ACC_OFF만 STOP-side 조건**으로 남겼다. 주차 중 음악을 무조건 켜도록 변경하지 않는다.
- 새 로그 대상에 `ADB_RUNTIME`/`SPLIT_RESTORE`를 추가해 기존 실패의 누락을 줄였다.
- **미완:** 차량에서 특정 시동 신호가 실제 언제 발송되는지, 음악 앱별 재생 성공·미디어 라우팅은 실제 재검증 필요.

### B5. EQ / 내비 운전석 라우팅 / 외부 AVAS
- 기존 EQ 프리셋과 3밴드 오디오 코드, 5종 내비 대상 설정, Route5/6 음향 진단 기능은 수정하지 않았다.
- 사용자가 예전에 보고한 ‘운전석 시험음은 나오지만 미디어 스피커도 동시 출력’ 문제는 **실제 타사 UID를 단독 운전석 출력하는 기능이 확인되지 않은 상태**다. 체크박스를 통한 대상 선택은 강제 출력이 아니다.
- AVAS 외부 스피커에 임의 음성 송신 구현을 추가하지 않았다. 순정 AVAS 상태는 읽기 전용 진단만 유지.

### B6. 로그 수집·ADB·권한·안전
- 로그 수집의 시작/종료 2버튼과 Downloads ZIP, 차량 RAW 기록, 세션 진단, AndroidRuntime 오류 기록은 유지.
- 로컬 ADB 권한 승인을 우회하거나 차량 ECU 쓰기를 추가하지 않았다. 분할 및 density는 사용자의 명시적 Android 화면 변경 액션에만 의존.
- 무의미한 사용자 반복 테스트 메뉴를 추가하지 않고 기존 통합 ZIP의 `feature_actions.jsonl`에 스택 복원·ADB 진단을 추가한다.

## C. 검증 결과와 증거 등급

1. v0.17.45 대비 Kotlin **105개 파일 내용 그대로**, 화면/런타임 관련 **17개 변경**, `DashboardUi.kt`·`ForegroundResolver.kt` **2개 신규**. 주행 이벤트 브리지·23종 카탈로그·음성 재생 엔진·EQ 처리 원천은 불변.
2. `tools/verify_v01746_dashboard_deep.py`: **26개 정적 소스 게이트 통과**. JVM `kotlinc`로 실제 `ForegroundResolver`의 다중 RESUMED·topResumed·360 패키지 검사를 컴파일하고 실행해 PASS.
3. `gradlew compileDebugKotlin / assembleDebug` 및 APK 서명은 **GitHub Actions에 포함**됐으나 이 오프라인 컨테이너에는 Android SDK/Gradle이 없어 실제 Android APK 컴파일 **미실시**. GitHub 빌드가 끝나기 전 APK 성공이라고 표시하지 않음.
4. Android 10 BYD 실차 분할·DPI·미디어·NORMAL 검증은 **아직 성공 확인 아님**. 이번 수정은 정적·JVM 수준의 빌드 후보다.
5. 2026-11-02/03 실차 로그를 토대로 앱 전면 판정/버전별 문제를 검토했으나, 해당 로그에 Ghost/Stack 실제 명령·오디오 세션 출력이 누락된 일부 구간의 원인을 단정하지 않았다.

## D. 우선순위별 남은 P0/P1 이슈

| 등급 | 남은 기능 | 필요한 실증·구현 |
|---|---|---|
| P0 | AutoSplit 완전 동등 분할 | Ghost 스택 식별·Task move·비율 readback의 OEM Android10 실차 지원 검증 |
| P0 | NORMAL 독립 전환 | 표시 코드와 관계 없는 확정 3상태 원시 신호 획득 및 오발화 억제 |
| P0 | 선택 앱 DPI 복원 | MCONK 및 순정 앱의 실제 Task/전면 판정과 override 원복 readback 검증 |
| P1 | 시동 미디어 자동재생 | 실제 ACC_ON/IGN_ON 발생 빈도와 MediaSession PLAYING readback |
| P1 | 운전석 단독 내비 음성 | 타사 UID 라우팅 권한 확인, 동시 미디어 출력 분리 |
| P1 | UI 안정성 | 검은 글자/크래시가 새 구조에서 재현되는지 AndroidRuntime 로그 확인 |

## E. GitHub 빌드·업데이트 설치

바깥 통합 ZIP을 한 번 풀면 같은 기본 이름의 두 파일만 나온다.

- `DolphinDriveAlerts_v0.17.46_Source.zip`: 전체 Android Studio/Gradle 프로젝트 ZIP. ZIP 내부에 이 보고서와 회귀 검사 소스가 있음.
- `DolphinDriveAlerts_v0.17.46_Source.yml`: GitHub Actions 워크플로. 저장소 `.github/workflows/`에 이 이름으로 넣는다.

소스 ZIP은 저장소 **루트**에 업로드한다. 두 파일 이름이 정확히 일치하도록 YML의 `SOURCE_ZIP`이 고정돼 있으며, 이전과 같은 파일명 불일치면 해당 단계에서 즉시 명확하게 실패한다.

**서명 중요:** 기존 차량 앱의 설치값을 유지하며 업데이트하려면 GitHub Actions가 기존 APK와 동일한 서명키를 사용해야 한다. 고정 키를 등록하지 않은 새 디버그 키는 기존 앱 위에 업데이트 설치할 수 없으며, 문제 해결을 위해 기존 앱을 무작정 삭제하라고 권하지 않는다.

### 근거 문서
- Android 10 다중 재개: https://source.android.com/docs/core/display/multi_display/multi-resume
- Android 멀티윈도 동작: https://developer.android.com/develop/ui/views/layout/support-multi-window-mode
- Android MediaSession PlaybackState: https://developer.android.com/reference/android/media/session/PlaybackState
- 기존 연구팩: `DDA-R20261103-02`, `-03`, `-04`, `-05` 및 11월 2/3일 실차 로그. 타사 APK는 배포하지 않음.
