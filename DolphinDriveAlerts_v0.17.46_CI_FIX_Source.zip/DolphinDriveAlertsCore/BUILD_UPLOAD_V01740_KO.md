# GitHub 빌드
1. 저장소 루트에 `DolphinDrive_v01740_source.zip` 업로드.
2. `.github/workflows/build_v01740.yml`로 함께 제공된 `build_v01740.yml` 업로드.
3. Actions의 v0.17.40 워크플로 수동 실행. APK 및 로그는 Artifact에서 확인.
4. 기존 설치 앱 유지 업데이트에는 **동일한 서명키** `DOLPHIN_DEBUG_KEYSTORE_B64` Secret 설정 필요.
5. 앱 자동 실행은 BYD ACC_ON/IGN_ON으로 한정하므로, 그 방송이 나오지 않는 차량에선 자동 실행되지 않을 수 있음.
