# Dolphin Drive Alerts v0.17.43 — 메뉴 안정화 및 순정 앱 DPI 목록

## 실차 확인사항 유지
- 사용자 실차 보고: ECO/NORMAL/SPORT 음성, 특히 NORMAL 안내 정상. v0.17.42 주행모드 판정 코드 수정하지 않음.
- 기존 5개 대시보드 카드, BSD 통합, 내부 분할, 시동 OFF 종료, 4단계 음량을 유지.

## 1. 상세 메뉴 검은 화면·강제 종료 예방 수정
- 기존 DensityAwareActivity.onResume()이 화면에 돌아올 때마다 무조건 전체 자식 뷰를 재귀 스타일링하던 동작 제거. Activity당 최초 한 번만 적용하고 종료 중인 Activity는 건너뜀.
- DashboardTheme가 Spinner 내부 선택 화면/팝업, EditText 배경을 임의로 재설정하던 동작 제거. UI 컨트롤의 작동 상태 보존.
- 상세 설정 화면들의 Spinner를 일관된 짙은 배경/밝은 글씨(선택된 행 + 펼친 목록)로 교체하여 '검은 글씨에 어두운 배경' 예방.
- AppPolicyActivity의 전체 설치 앱 읽기/라벨 조회는 UI 스레드 대신 백그라운드 실행; 최대 100개 검색 결과만 Spinner에 표시해 뷰/메모리 부하 제한.
- 전역 DPI 자동 적용: 접근성의 TYPE_WINDOWS_CHANGED 잡음은 제외, TYPE_WINDOW_STATE_CHANGED 안정화(350ms debounce). 도중 복원 실패 시 기존 override 유지한 채 신규 override를 겹쳐 쓰지 않음. 동일 패키지 변경 규칙이 과거 캐시 때문에 재적용 차단되던 문제 제거.
- 오류 원인 입증에 필요한 '마지막 앱 비정상 종료/테마 오류'를 앱 내부 저장소에 자동 기록, 다음 통합 로그 ZIP에 포함.
- 위 변경은 크래시 스택이 없는 상태에서 코드상 위험을 낮추는 수정입니다. 실제 비정상 종료의 확정 원인 및 실차 재현 해결은 아직 미검증입니다.

## 2. 순정 앱 DPI 목록 및 선택
- v0.17.42에서는 ThirdPartyDpiRules.allowed의 FLAG_SYSTEM 및 com.byd.* 거부로 순정 앱이 모두 숨겨짐. 해당 제한을 제거했습니다.
- 앱 검색: '전체 설치 앱 + 순정 / 내가 설치한 앱 / 순정·시스템 앱', 앱 이름 또는 패키지명 검색, 수동 패키지 지정. 런처 아이콘이 없는 순정 시스템 앱도 목록에서 검색 가능.
- 차량에 위험한 Android SystemUI, 차량 클러스터/계기판/에어백 관련 패키지와 우리 앱 자체는 적용 금지.
- 순정 앱 규칙 저장 전에 위험 확인 다이얼로그 표시. 기본 자동 변경 OFF 유지, 기존 설정 저장소 및 120~320 DPI 범위 보존.
- 중요: 별도 앱의 독립 DPI가 아니라 `wm density`로 **차량 전체 화면 DPI를 임시 변경**합니다. ADB 승인 + 접근성 전면 패키지 이벤트 + 해당 패키지의 독립 전면 창이 있어야 적용되며, OEM 런처 안에 포함된 화면 등은 감지 실패 가능. 차량의 UI·카메라 잘림 위험, 복구 버튼 사용.

## 3. 개발 검증 범위
- Android Context/PackageManager 모의 객체 기반 실제 Kotlin 컴파일·실행으로 BYD 순정 앱 포함, 아이콘 없는 앱 검색, 보호 패키지 제외, 규칙 저장을 검증.
- 이전 버전 NORMAL, 자체 분할, UI/권한·음성 이벤트, 앱 DPI, 통합 로그 회귀 검사, YML/bash 구문 및 ZIP 무결성 검사.
- 실제 Android Gradle compileDebugKotlin/assembleDebug 및 실차 UI 재현 테스트는 이 컨테이너에 Android SDK가 없어 미실행. GitHub Actions의 Kotlin 실컴파일과 APK 빌드를 거쳐야 합니다.
- 기존 서명을 유지하려면 DOLPHIN_DEBUG_KEYSTORE_B64에 원래 키를 구성하세요. 새 임시 키는 기존 설치 APK 업데이트와 호환되지 않습니다.
