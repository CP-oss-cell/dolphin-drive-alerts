# Dolphin Drive Alerts v0.17.46: GitHub Actions 빌드 실패 수정

## 근거
- 업로드된 `byd1.zip`(GitHub Actions 실패 로그, 2026-11-03)에서 `:app:compileDebugKotlin` 실패.
- `ui/MainActivity.kt:59:41`의 `Unresolved reference: fillViewport`가 유일하게 표시된 Kotlin 컴파일 오류.
- `v0.17.46` 원본 Source ZIP SHA-256 = `bdabd2f2baaf159ab3481251e4f39b88b03dd4e0e53008dd6611420bcd69720b`, 로그와 일치.

## 코드 수정
- `ScrollView(this).apply{fillViewport=true; ...}` → `ScrollView(this).apply{setFillViewport(true); ...}`.
- `ScrollView.setFillViewport(boolean)`은 Android SDK 정식 Java API. Kotlin synthetic-property 판별에 의존하지 않게 직접 setter 호출.
- `tools/verify_v01746_dashboard_deep.py`에 해당 Java setter 사용 회귀 검사 추가.
- 기존 versionCode `72`, versionName `0.17.46`, 앱 패키지명, 기존 런타임 로직 및 트리거 변경 없음.

## 빌드 방법
1. 바깥 통합 ZIP을 **한 번만** 풀면 `DolphinDriveAlerts_v0.17.46_CI_FIX_Source.zip`과 `DolphinDriveAlerts_v0.17.46_CI_FIX_Source.yml` 두 파일이 나옵니다.
2. `DolphinDriveAlerts_v0.17.46_CI_FIX_Source.zip`을 GitHub 저장소 **루트**에 업로드합니다. (압축 해제하지 않음)
3. `DolphinDriveAlerts_v0.17.46_CI_FIX_Source.yml`을 `.github/workflows/` 경로에 업로드합니다.
4. GitHub Actions에서 `Build Dolphin Drive Alerts v0.17.46 CI FIX (ScrollView)` → `Run workflow` 실행.
5. `Compile real Android Kotlin with API 34` 및 `Build installable debug APK` 성공 후 `DolphinDriveAlerts_v0.17.46-SIGNED` Artifacts에서 APK 확인.

## 검증 수준 및 유의사항
- GitHub 로그를 통해 원인 확정. 새 소스 내 기존 정적/독립 Kotlin 회귀 검사를 실행.
- 현지 작업 환경에는 Android SDK가 없어 `:app:compileDebugKotlin` 및 APK 실제 빌드는 직접 수행하지 못함. GitHub Actions가 최종 검증.
- 기존 GitHub 로그에서 서명 모드는 `ONE_TIME_EPHEMERAL`. 이전 설치본에 대한 덮어쓰기 업데이트는 서명 키가 동일해야 가능하며, 재설치가 필요할 수 있음.
- 차량 실차 동작에 대한 검증 주장은 하지 않음.
