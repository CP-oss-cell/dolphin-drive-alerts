package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/** User-selected non-system apps only. OFF means explicit BYD ACC_OFF, never SCREEN_ON/door/wake. */
object IgnitionOffAppStopper {
    private const val PREF = "ignition_off_user_apps_v1"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun enabled(c: Context): Boolean = prefs(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, enabled: Boolean) = prefs(c).edit().putBoolean("enabled", enabled).apply()
    fun selected(c: Context): Set<String> = prefs(c).getStringSet("packages", emptySet())?.toSet().orEmpty()
    fun save(c: Context, packages: Set<String>) = prefs(c).edit().putStringSet("packages", packages.filter(::isSafePackage).toSet()).commit()
    fun isSafePackage(pkg: String): Boolean {
        if (!pkg.matches(Regex("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+"))) return false
        val p = pkg.lowercase()
        return p != "android" && !p.startsWith("com.android.") && !p.startsWith("com.byd.") &&
            !p.startsWith("com.qualcomm.") && !p.startsWith("com.google.android.gms") &&
            !p.startsWith("com.google.android.gsf") && !p.startsWith("com.mediatek.") &&
            !p.startsWith("com.samsung.") && !p.startsWith("com.car.") &&
            !p.startsWith("android.")
    }
    /** Caller MUST run on a background thread; no retries of state changing shell commands. */
    fun onConfirmedOff(c: Context, source: String) {
        if (source != "com.byd.action.ACC_OFF" || !enabled(c)) return
        val allowed = AppSelection.launchable(c).map { it.packageName }.toSet()
        val targets = selected(c).filter { it in allowed && it != c.packageName && isSafePackage(it) }
        CoreLog.i("IGN_OFF", "confirmed=$source selected=${targets.size}; wake/door ignored")
        if (targets.isEmpty()) return
        val auth = AuthorizedAdbRuntime.health(c)
        if (auth.state != AuthorizedAdbRuntime.State.READY) {
            CoreLog.w("IGN_OFF", "ADB_NOT_READY=${auth.state}; no false stop success")
            return
        }
        targets.forEach { pkg ->
            val result = AuthorizedAdbRuntime.writeOnce(c, "am force-stop --user 0 $pkg", timeoutMs=7_000L)
            CoreLog.i("IGN_OFF", "pkg=$pkg commandAccepted=${result.result.success} adb=${result.state} output=${result.result.output.take(200)}")
        }
    }
}
