package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/**
 * Single native Dashboard design system for every detail Activity.
 * It keeps existing live listeners and preference models intact. No recursive
 * recoloring of spinner popups, dialogs, or view reuse across screens.
 */
object DashboardUi {
    const val BACKGROUND = 0xFF0B111D.toInt()
    const val PANEL = 0xFF17263A.toInt()
    const val PANEL_ALT = 0xFF21344C.toInt()
    const val TEXT = 0xFFEDF4FA.toInt()
    const val MUTED = 0xFFB3C4D9.toInt()
    const val ACCENT = 0xFF58D5DC.toInt()
    private fun dp(a: Activity, n:Int) = (a.resources.displayMetrics.density * n + .5f).toInt()
    fun bg(a:Activity, color:Int=PANEL, radius:Int=14):GradientDrawable = GradientDrawable().apply {
        setColor(color);cornerRadius=dp(a,radius).toFloat()
    }
    fun label(a:Activity,text:String,size:Float=15f,bold:Boolean=false):TextView = TextView(a).apply {
        this.text=text;this.textSize=size;setTextColor(if(bold)TEXT else MUTED)
        if(bold)setTypeface(typeface,Typeface.BOLD)
        setPadding(dp(a,6),dp(a,7),dp(a,6),dp(a,7))
    }
    fun panel(a:Activity,title:String,description:String="",build:(LinearLayout)->Unit):LinearLayout {
        return LinearLayout(a).apply {
            orientation=LinearLayout.VERTICAL
            background=bg(a)
            setPadding(dp(a,14),dp(a,12),dp(a,14),dp(a,14))
            addView(label(a,title,18f,true))
            if(description.isNotBlank())addView(label(a,description,13f))
            build(this)
        }
    }
    fun action(a:Activity,text:String,onClick:()->Unit):Button=Button(a).apply {
        this.text=text;isAllCaps=false;textSize=15f;setTextColor(TEXT)
        background=bg(a,PANEL_ALT,10);minHeight=dp(a,48)
        setOnClickListener { onClick() }
    }
    fun spacing(a:Activity)=View(a).apply {layoutParams=LinearLayout.LayoutParams(1,dp(a,10))}
    fun addPanel(parent:LinearLayout,a:Activity,panel:View) {
        parent.addView(panel, LinearLayout.LayoutParams(-1,-2).apply {setMargins(0,0,0,dp(a,10))})
    }
    fun toggle(a:Activity,text:String,initial:Boolean,onChange:(Boolean)->Unit):Switch = Switch(a).apply {
        this.text=text;isChecked=initial;setTextColor(TEXT);textSize=15f
        setPadding(dp(a,7),dp(a,8),dp(a,7),dp(a,8))
        setOnCheckedChangeListener{_,v->onChange(v)}
    }
    /**
     * Adapt old subpages to the NEW dashboard shell without moving their live
     * controls out of the Activity's original parent; dynamic redraw remains valid.
     */
    fun mount(a:Activity, content:View, title:String, subtitle:String="") {
        val shell=LinearLayout(a).apply {
            orientation=LinearLayout.VERTICAL;setBackgroundColor(BACKGROUND)
        }
        val heading=LinearLayout(a).apply {
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(a,12),dp(a,12),dp(a,12),dp(a,10))
            setBackgroundColor(BACKGROUND)
        }
        heading.addView(action(a,"‹",{ a.finish() }),LinearLayout.LayoutParams(dp(a,55),dp(a,50)))
        val copy=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(a,12),0,0,0)}
        copy.addView(label(a,title,22f,true))
        copy.addView(label(a,subtitle.ifBlank { "DOLPHIN DRIVE  ·  상세 설정" },12f))
        heading.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
        shell.addView(heading)
        shell.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        a.setContentView(shell)
        // Post after onCreate has finished appending its live settings and adapters.
        content.post { if(!a.isFinishing && !a.isDestroyed) {
            sectionize(a,content)
            refresh(a,content)
        } }
    }
    /**
     * Turn the actual old flat detail layouts into clearly separated native
     * dashboard panels. No old list view is presented. Every live listener,
     * view object and setting stays inside exactly one panel. Safe to call after
     * a detail screen rebuilds its list; already grouped panels are ignored.
     */
    fun sectionize(a:Activity,content:View) {
        val body=when(content) {
            is ScrollView -> content.getChildAt(0) as? LinearLayout
            is LinearLayout -> content
            else -> null
        } ?: return
        val original=(0 until body.childCount).map { body.getChildAt(it) }
        if(original.isEmpty())return
        if(original.all { it.getTag() == "DOLPHIN_DASH_PANEL" })return
        body.removeAllViews()
        var title="기본 설정"
        var panelBody:LinearLayout?=null
        fun start(name:String) {
            val sectionPanel=panel(a,name) { }
            sectionPanel.setTag("DOLPHIN_DASH_PANEL")
            addPanel(body,a,sectionPanel)
            panelBody=sectionPanel
        }
        original.forEachIndexed { index,child ->
            val t=child as? TextView
            val titleText=t?.text?.toString()?.trim().orEmpty()
            val size=t?.textSize?.div(a.resources.displayMetrics.scaledDensity)?:0f
            val profileHeading=titleText.matches(Regex("^[0-9]+\\. \\S.*")) ||
                (titleText.contains(": ") && titleText.contains(" / ") && size>=16f)
            val isSection=t!=null && t !is EditText && t !is Button &&
                (size>=18f || profileHeading)
            if(index==0 && isSection) {
                // The fixed dashboard header already replaces the old page title.
                return@forEachIndexed
            }
            if(isSection) {
                title=titleText.take(72)
                start(title)
            } else {
                if(panelBody==null)start(title)
                (child.parent as? ViewGroup)?.removeView(child)
                panelBody?.addView(child)
            }
        }
    }

    /** Restyle newly redrawn controls. No in-place parent relocation or popup recoloring. */
    fun refresh(a:Activity,root:View) {
        val p=root.parent
        if(p is LinearLayout && p.parent is ScrollView) {
            val lp=root.layoutParams as? LinearLayout.LayoutParams
            lp?.setMargins(0,dp(a,5),0,dp(a,5))
        }
        when(root) {
            is Spinner -> return // the dark adapter owns both selected/dropdown rows
            is EditText -> {root.setTextColor(TEXT);root.setHintTextColor(MUTED)
                root.setPadding(dp(a,12),dp(a,12),dp(a,12),dp(a,12))
                root.background=bg(a,PANEL_ALT,9)
            }
            is Switch -> {root.setTextColor(TEXT);root.textSize=15f
                root.setPadding(dp(a,12),dp(a,10),dp(a,12),dp(a,10));root.background=bg(a)
            }
            is CheckBox -> {root.setTextColor(TEXT);root.textSize=15f
                root.setPadding(dp(a,12),dp(a,9),dp(a,12),dp(a,9));root.background=bg(a)
            }
            is RadioButton -> root.setTextColor(TEXT)
            is Button -> {root.isAllCaps=false;root.setTextColor(TEXT);root.textSize=15f
                root.minHeight=dp(a,48);root.background=bg(a,PANEL_ALT,10)
            }
            is TextView -> {
                root.setTextColor(if(root.textSize/a.resources.displayMetrics.scaledDensity>=18f)ACCENT else MUTED)
                root.setPadding(dp(a,10),dp(a,10),dp(a,10),dp(a,10))
                root.background=bg(a,if(root.textSize/a.resources.displayMetrics.scaledDensity>=18f)PANEL_ALT else PANEL)
            }
            is ScrollView -> root.setBackgroundColor(BACKGROUND)
            is LinearLayout -> if(root.parent is ScrollView) root.setBackgroundColor(BACKGROUND)
        }
        if(root is ViewGroup)for(i in 0 until root.childCount)refresh(a,root.getChildAt(i))
    }
}
