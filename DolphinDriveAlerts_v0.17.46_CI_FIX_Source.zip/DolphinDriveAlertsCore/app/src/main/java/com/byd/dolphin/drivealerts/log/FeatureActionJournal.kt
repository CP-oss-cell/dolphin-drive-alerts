package com.byd.dolphin.drivealerts.log

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Automatic execution proof for split, per-app density, ignition and media.
 * Captured into the normal four-step diagnostics ZIP, no extra user tests.
 */
object FeatureActionJournal {
    @Volatile private var root:File?=null
    private val tags=setOf("SPLIT_NATIVE","DPI","AUTO_SEQUENCE","MEDIA_START","BOOT","SPLIT_RESTORE","ADB_RUNTIME")
    fun install(context:Context) {root=context.applicationContext.filesDir}
    @Synchronized fun record(tag:String,message:String) {
        if(tag !in tags)return
        val directory=root?:return
        try {
            val current=File(directory,"feature_actions.jsonl")
            val previous=File(directory,"feature_actions.prev.jsonl")
            if(current.length()>550_000L) {
                if(previous.isFile)previous.delete()
                current.renameTo(previous)
            }
            val row=JSONObject().put("ts",System.currentTimeMillis())
                .put("tag",tag).put("detail",message.take(1_500))
            current.appendText(row.toString()+"\n",Charsets.UTF_8)
        } catch (_:Throwable) { /* logging must never break driving alerts */ }
    }
    @Synchronized fun selection(context:Context,from:Long,to:Long):ByteArray {
        val root=context.applicationContext.filesDir
        val lines=ArrayList<String>()
        for(name in listOf("feature_actions.prev.jsonl","feature_actions.jsonl")) {
            val f=File(root,name)
            if(!f.isFile)continue
            f.forEachLine(Charsets.UTF_8) { s ->
                val ts=runCatching{JSONObject(s).optLong("ts",0L)}.getOrDefault(0L)
                if(ts in from..to)lines.add(s)
            }
        }
        return (if(lines.isEmpty())"" else lines.joinToString("\n",postfix="\n"))
            .toByteArray(Charsets.UTF_8)
    }
}
