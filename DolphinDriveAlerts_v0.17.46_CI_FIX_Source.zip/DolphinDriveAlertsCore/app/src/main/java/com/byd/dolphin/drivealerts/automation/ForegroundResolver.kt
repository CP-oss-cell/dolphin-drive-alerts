package com.byd.dolphin.drivealerts.automation

/** Android 10 multi-resume: the LAST resumed line is not necessarily the focused task. */
object ForegroundResolver {
    private fun candidates(raw:String, marker:String):List<String> = raw.lineSequence()
        .filter { it.contains(marker,true) }.map { it.trim() }.filter { it.isNotBlank() }.toList()
    fun topToken(raw:String):String? {
        // Strongest: ActivityTaskManager's top-resumed activity (one per display).
        val top = candidates(raw,"topResumedActivity") + candidates(raw,"mTopResumedActivity")
        top.firstOrNull { it.contains("/",true) }?.let{return it.take(500)}
        // Fallback only where the same component appears across all resumed lines.
        val resumed = (candidates(raw,"mResumedActivity") + candidates(raw,"ResumedActivity:"))
            .filter { it.contains("/") }
        val unique = resumed.mapNotNull { component(it) }.distinct()
        return if(unique.size==1)resumed.firstOrNull()?.take(500) else null
    }
    fun component(token:String):String? = Regex("([A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+)+/[A-Za-z0-9_.$]+)")
        .find(token)?.groupValues?.getOrNull(1)
    fun packageName(token:String):String? = component(token)?.substringBefore('/')
    fun camera(raw:String):Boolean = Regex("(?i)(com\\.byd\\.avc|com\\.byd\\.cdr|surroundview|\\bavm\\b|360.?camera)").containsMatchIn(raw)
}
