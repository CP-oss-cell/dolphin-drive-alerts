package com.byd.dolphin.drivealerts.vehicle

/**
 * Evidence from user-supplied Byd_AutoFeedBack_v1.0.apk DEX:
 * BydAutoService$5.onOperationModeChanged -> handleOperationMode.
 * value=1 triggers operation_mode_1_sports_mode_off, value=2 triggers
 * operation_mode_2_sports_mode_on. The raw-mode callback uses TWO audio resources, not a three-state enum.
 * Our NORMAL is therefore inferred only with additional instrument transition
 * evidence (363 -> 1 -> 364) captured in the user's real-car log.
 */
object AudioFeedbackReference {
    enum class Signal { SPORTS_MODE_OFF, SPORTS_MODE_ON, UNKNOWN }
    fun classify(raw: Int): Signal = when(raw) {
        1 -> Signal.SPORTS_MODE_OFF
        2 -> Signal.SPORTS_MODE_ON
        else -> Signal.UNKNOWN
    }
}
