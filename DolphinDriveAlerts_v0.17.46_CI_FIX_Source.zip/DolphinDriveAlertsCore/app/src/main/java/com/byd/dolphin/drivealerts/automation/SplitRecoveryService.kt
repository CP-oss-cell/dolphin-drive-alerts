package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.util.CoreLog

/** Observes fullscreen transition and restores the *saved* percent only after leaving it.
 * Never interferes while the 360 camera is foreground. Needs BYD-local ADB authorization.
 */
class SplitRecoveryService : Service() {
    @Volatile private var running=false
    @Volatile private var generation=0
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val manager=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel("split_recovery","분할 화면 복원",NotificationManager.IMPORTANCE_LOW))
        startForeground(762, Notification.Builder(this,"split_recovery")
            .setContentTitle("분할 비율 복원 감시")
            .setSmallIcon(android.R.drawable.ic_menu_crop).build())
    }
    override fun onStartCommand(intent: Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_STOP){running=false;generation++;stopSelf();return START_NOT_STICKY}
        val id=intent?.getStringExtra("id") ?: return START_NOT_STICKY
        val p=FeatureProfiles.splits(this).firstOrNull{it.id==id} ?: return START_NOT_STICKY
        running=true;val local=++generation
        Thread({watch(p,local)},"split-ratio-recovery").start()
        return START_NOT_STICKY
    }
    private fun watch(p:SplitProfile,token:Int) {
        var cameraSeen=false
        var nonCameraSamples=0
        var restores=0
        val cameraPattern=Regex("(?i)(com\\.byd\\.avc|com\\.byd\\.cdr|camera|surroundview|\\bavm\\b)")
        while(running && token==generation && FeatureProfiles.splitEnabled(this)) {
            try {
                Thread.sleep(2_000L)
                val foreground=AutoSplitBehaviorEngine.screenToken(this) ?: continue
                if(cameraPattern.containsMatchIn(foreground)) {
                    cameraSeen=true
                    nonCameraSamples=0
                    CoreLog.i("SPLIT_RESTORE","camera visible, no resize or task launch")
                    continue
                }
                if(!cameraSeen) continue
                nonCameraSamples++
                if(nonCameraSamples<2) continue  // debounce transient OEM 360 transitions
                if(restores>=2) {
                    CoreLog.w("SPLIT_RESTORE","restore budget exhausted; profile=${p.id}")
                    cameraSeen=false
                    continue
                }
                restores++
                // Camera has exited. Reconstruct the selected pair only now; never seize 360 foreground.
                val result=AutoSplitBehaviorEngine.launch(this,p)
                CoreLog.i("SPLIT_RESTORE","postCamera=${p.id} attempt=$restores status=${result.success} detail=${result.message}")
                cameraSeen=false
                nonCameraSamples=0
            }catch(_:InterruptedException){Thread.currentThread().interrupt();break}
            catch(t:Throwable){CoreLog.w("SPLIT_RESTORE","watch failure: ${t.message}")}
        }
        if(token==generation)stopSelf()
    }
    override fun onDestroy(){running=false;generation++;super.onDestroy()}
    companion object {
        const val ACTION_STOP="com.byd.dolphin.drivealerts.SPLIT_STOP"
        fun start(context:Context,id:String) {
            val i=Intent(context,SplitRecoveryService::class.java).putExtra("id",id)
            try {context.startForegroundService(i)} catch(t:Throwable){CoreLog.w("SPLIT_RESTORE","service start failed: ${t.message}")}
        }
    }
}
