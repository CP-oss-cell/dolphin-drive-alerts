package com.byd.dolphin.drivealerts.util

import android.app.Application
import android.content.Context
import java.io.File
import java.io.StringWriter
import java.io.PrintWriter
import java.util.concurrent.atomic.AtomicBoolean

/** Preserve last fatal stack for automatic inclusion in next ordinary log ZIP. */
object UiCrashEvidence {
    private val installed=AtomicBoolean(false)
    private const val FILE="ui_last_crash.txt"
    fun install(context:Context) {
        if(!installed.compareAndSet(false,true)) return
        val previous=Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, thrown ->
            try {
                val out=StringWriter()
                thrown.printStackTrace(PrintWriter(out))
                val report="timeMs=${System.currentTimeMillis()}\nthread=${thread.name}\n" + out.toString().take(32_000)
                File(context.filesDir,FILE).writeText(report)
            } catch (_:Throwable) { }
            previous?.uncaughtException(thread,thrown)
        }
    }
    fun noteNonFatal(context:Context, thrown:Throwable) {
        try {
            val out=StringWriter()
            thrown.printStackTrace(PrintWriter(out))
            File(context.filesDir,"ui_last_theme_error.txt").writeText(out.toString().take(16_000))
        } catch (_:Throwable) { }
    }
}

class DolphinDriveApplication:Application() {
    override fun onCreate() {
        super.onCreate()
        UiCrashEvidence.install(this)
        com.byd.dolphin.drivealerts.log.FeatureActionJournal.install(this)
    }
}
