package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog
import kotlin.math.abs

/**
 * Direct in-app integration of observed AutoSplit 1.2 command semantics.
 * NO dependency on / launch of AutoSplit itself, and NO old ghost-task route.
 * Platform success is always conditional on actual BYD windowing support.
 */
object AutoSplitBehaviorEngine {
    data class Result(val success:Boolean,val message:String)
    private fun read(c:Context,cmd:String)=AuthorizedAdbRuntime.read(c,cmd,timeoutMs=4_000L).result
    private fun write(c:Context,cmd:String):Boolean {
        val r=AuthorizedAdbRuntime.writeOnce(c,cmd,timeoutMs=12_000L)
        val out=r.result.output
        val ok=r.state==AuthorizedAdbRuntime.State.READY &&
            !Regex("(?i)(Error:|Exception|Permission Denial|Unknown option|not supported|invalid input bounds)").containsMatchIn(out)
        CoreLog.i("SPLIT_NATIVE","command=$cmd;state=${r.state};exit=${r.result.exitCode};ok=$ok;output=${out.take(450)}")
        return ok
    }
    private fun snap(c:Context):String = read(c,"am stack list").output + "\n" + read(c,"dumpsys activity activities").output
    private fun state(c:Context,pkg:String):LegacySplitTaskLocator.State=
        LegacySplitTaskLocator.findTask(snap(c),pkg)
    private fun camera(s:String)=ForegroundResolver.camera(s)
    fun screenToken(c:Context):String? = ForegroundResolver.topToken(read(c,"dumpsys activity activities").output)
    fun capabilities(c:Context):String {
        val adb=AuthorizedAdbRuntime.health(c)
        if(adb.state!=AuthorizedAdbRuntime.State.READY)return "ADB=${adb.state}: 차량 분할 명령 사용 불가"
        val help=read(c,"am start --help").output
        val stacks=read(c,"am stack list")
        return "ADB=READY; windowingMode=${help.contains("windowingMode",true)};"+
            " stackList=${stacks.success};split=${stacks.output.contains("split-screen",true)};"+
            " 직전 빌드 동작 결과와 무관하게 실제 분할은 실행 후 두 Task 확인이 필요합니다"
    }

    fun launch(c:Context,profile:SplitProfile):Result {
        val firstComp=AppSelection.safeComponent(c,profile.firstPackage)
            ?:return Result(false,"첫 번째 앱 실행 Activity가 없습니다")
        val secondComp=AppSelection.safeComponent(c,profile.secondPackage)
            ?:return Result(false,"두 번째 앱 실행 Activity가 없습니다")
        if(profile.firstPackage==profile.secondPackage ||
            profile.firstPackage==c.packageName || profile.secondPackage==c.packageName)
            return Result(false,"서로 다른 외부 앱 2개를 선택하세요")
        if(camera(screenToken(c).orEmpty()))return Result(false,"360 카메라 동작 중에는 분할을 시작하지 않습니다")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)
            return Result(false,"로컬 ADB 승인 필요")

        // Reference APK split launches use modes 3/4. The FULLSCREEN-only
        // 0x18000000 flag and blocking -W were not observed on its split start.
        val primary="am start --user 0 --windowingMode 3 -n '$firstComp'"
        val secondary="am start --user 0 --windowingMode 4 -n '$secondComp'"
        CoreLog.i("SPLIT_NATIVE","BEGIN profile=${profile.id} first=${profile.firstPackage} second=${profile.secondPackage}")
        if(!write(c,primary))return Result(false,"1단계: primary split 실행 명령 거부. SPLIT_NATIVE 로그 확인")
        // Start second quickly. The old 12x dumpsys-read loops caused a long delay
        // and frequently let the primary return fullscreen before secondary appeared.
        Thread.sleep(500L)
        if(!write(c,secondary))return Result(false,"2단계: secondary split 실행 명령 거부. SPLIT_NATIVE 로그 확인")
        var a=state(c,profile.firstPackage)
        var b=state(c,profile.secondPackage)
        CoreLog.i("SPLIT_NATIVE","INITIAL_OWNERSHIP first=$a second=$b")
        // Reuse visible split stack if the OEM firmware reused a prior app task.
        if(a.mode!=3 && a.found) {
            val stack=LegacySplitTaskLocator.findStack(snap(c),3)
            if(stack>=0) {
                write(c,"am stack move-task ${a.taskId} $stack true")
                a=state(c,profile.firstPackage)
            }
        }
        if(b.mode!=4 && b.found) {
            val stack=LegacySplitTaskLocator.findStack(snap(c),4)
            if(stack>=0) {
                write(c,"am stack move-task ${b.taskId} $stack true")
                b=state(c,profile.secondPackage)
            }
        }
        // At most two short reads, not a minute of silent waiting.
        if(a.mode!=3 || b.mode!=4) {
            Thread.sleep(450L)
            a=state(c,profile.firstPackage)
            b=state(c,profile.secondPackage)
        }
        val separated=a.found && b.found && a.mode==3 && b.mode==4 &&
            a.taskId!=b.taskId && a.stackId!=b.stackId
        if(!separated) {
            val raw=read(c,"am stack list").output
            val modes=raw.lineSequence().filter{
                it.contains("Stack id=",true)||it.contains("windowingMode",true)
            }.take(8).joinToString(" | ").take(340)
            CoreLog.w("SPLIT_NATIVE","SPLIT_NOT_CONFIRMED first=$a second=$b stack=$modes")
            return Result(false,"분할 실패: 첫 앱=${a.mode}/${a.stackId}, 둘째 앱=${b.mode}/${b.stackId}. 차량 창 스택 명령·권한 확인 필요")
        }
        FeatureProfiles.markSplit(c,profile.id)
        val ratio=applyRatio(c,profile.primaryPercent)
        if(!ratio.success)return Result(true,"두 앱 분할 확인, 비율은 미확인: ${ratio.message}")
        return Result(true,"두 앱 분할 확인: ${ratio.message}")
    }

    fun applyRatio(c:Context,percentage:Int):Result {
        if(percentage !in 10..90)return Result(false,"비율은 10~90%입니다")
        if(camera(screenToken(c).orEmpty()))return Result(false,"카메라 화면에서 비율 변경 보류")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)return Result(false,"ADB 승인 필요")
        fun measure():SplitGeometry.PairBounds? {
            val stack=read(c,"am stack list")
            val activities=read(c,"dumpsys activity activities")
            return ReferenceAutoSplitRatio.parse(stack.output)
                ?:SplitGeometry.parse(stack.output,activities.output)
        }
        val bounds=measure()?:return Result(false,"분할 스택 좌표를 확인하지 못했습니다")
        val before=SplitGeometry.percent(bounds)?:return Result(false,"분할 방향 확인 실패")
        if(abs(before-percentage)<=2)return Result(true,"현재 비율 $before:${100-before}")
        val resize=SplitGeometry.resize(bounds,percentage)?:return Result(false,"비율 좌표 계산 실패")
        if(!write(c,resize.command) && !write(c,resize.fourArgCommand))
            return Result(false,"비율 변경 명령이 거부됐습니다")
        repeat(3) {
            Thread.sleep(450L)
            val measured=measure()?.let(SplitGeometry::percent)
            if(measured!=null && abs(measured-percentage)<=3)return Result(true,"실제 비율 $measured:${100-measured}")
        }
        return Result(false,"비율 조절은 시도했으나 readback 미확인")
    }
}
