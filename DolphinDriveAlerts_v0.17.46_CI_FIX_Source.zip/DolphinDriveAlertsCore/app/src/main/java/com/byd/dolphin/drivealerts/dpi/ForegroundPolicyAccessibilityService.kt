package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.dpi.ThirdPartyDpiRules
import com.byd.dolphin.drivealerts.util.CoreLog

/** Accessibility is used for steering-key monitoring, NEVER for per-app display rules. */
class ForegroundPolicyAccessibilityService : AccessibilityService() {
    private val foregroundHandler=Handler(Looper.getMainLooper())
    private var pendingForeground:Runnable?=null
    override fun onServiceConnected() {
        super.onServiceConnected()
        TemporaryAppDpiController.recoverOnStartup(this)
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        }.onFailure { CoreLog.w("ACCESSIBILITY", "Key events unavailable: ${it.message}") }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg=event?.packageName?.toString() ?: return
        // TYPE_WINDOWS_CHANGED includes transient/system overlays; acting on those causes
        // repeated wm density apply/restore during a single app visit (black-screen flicker).
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // A system popup or a rotation/DPI redraw does not represent a settled foreground app.
        // Collapse noisy changes, including Android/SystemUI, before apply OR restore.
        pendingForeground?.let { foregroundHandler.removeCallbacks(it) }
        val task=Runnable { TemporaryAppDpiController.onForeground(applicationContext,pkg) }
        pendingForeground=task
        foregroundHandler.postDelayed(task,350L)
    }
    override fun onKeyEvent(event: KeyEvent): Boolean {
        runCatching { SteeringTripleTapDetector.onKeyEvent(this,event) }
            .onFailure { CoreLog.w("ACCESSIBILITY", "key error=${it.message}") }
        return false
    }
    override fun onInterrupt() {
        pendingForeground?.let { foregroundHandler.removeCallbacks(it) }
        pendingForeground=null
    }
    override fun onDestroy() {
        onInterrupt()
        super.onDestroy()
    }
}
