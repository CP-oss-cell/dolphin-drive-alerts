package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.byd.dolphin.drivealerts.util.CoreLog

/** Keeps the selected-app stop operation in a short foreground service, not a broadcast thread. */
class IgnitionOffStopService : Service() {
    override fun onBind(intent:Intent?):IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val manager=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(
            NotificationChannel("ignition_off_apps","시동 OFF 지정 앱 종료",NotificationManager.IMPORTANCE_LOW))
        startForeground(766,Notification.Builder(this,"ignition_off_apps")
            .setContentTitle("시동 OFF · 선택 앱 종료 중")
            .setSmallIcon(android.R.drawable.ic_menu_close_clear_cancel).build())
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action!="com.byd.action.ACC_OFF") {stopSelf(startId);return START_NOT_STICKY}
        Thread({
            val lock=(getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Dolphin:IgnitionOffAppStop")
            try {lock.acquire(60_000L);IgnitionOffAppStopper.onConfirmedOff(applicationContext,"com.byd.action.ACC_OFF")}
            catch(t:Throwable){CoreLog.w("IGN_OFF","stop service failure: ${t.message}")}
            finally {if(lock.isHeld)lock.release();stopSelf(startId)}
        },"ignition-off-stop-selected-apps").start()
        return START_NOT_STICKY
    }
    companion object {
        fun start(c:Context) {
            try {c.startForegroundService(Intent(c,IgnitionOffStopService::class.java)
                .setAction("com.byd.action.ACC_OFF"))}
            catch(t:Throwable){CoreLog.w("IGN_OFF","service start blocked: ${t.message}")}
        }
    }
}
