package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** Read-only global display diagnostics and explicit legacy forced-density recovery only. */
object DisplaySettingsController {
    private const val PREF = "display_global_v0169"
    data class DensitySnapshot(val physical: Int?, val override: Int?)
    data class Result(val ok: Boolean, val message: String)
    private val physicalRegex = Regex("""(?i)physical density:\s*(\d+)""")
    private val overrideRegex = Regex("""(?i)override density:\s*(\d+)""")
    fun parseDensity(raw: String): DensitySnapshot = DensitySnapshot(
        physicalRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull(),
        overrideRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull()
    )
    fun readDensity(context: Context): DensitySnapshot? {
        val res = AuthorizedAdbRuntime.read(context, "wm density").result
        if (!res.success) return null
        return parseDensity(res.output).takeIf { it.physical != null }
    }
    fun readSize(context: Context): String {
        val res = AuthorizedAdbRuntime.read(context, "wm size").result
        return if (res.success) res.output.trim().take(240) else "해상도 조회 실패: ${res.message}"
    }
    fun readDisplayHardware(context: Context): String {
        // ADB read only: physical panel / logical mode / OEM profile must not be guessed.
        val res = AuthorizedAdbRuntime.read(context, "dumpsys display", timeoutMs = 6_000L).result
        if (!res.success) return "BYD 디스플레이 정보 읽기 실패: ${res.message}"
        val lines = res.output.lineSequence().filter { line ->
            listOf("DisplayDeviceInfo", "mBaseDisplayInfo", "DisplayInfo{", "supportedModes", "physicalWidth", "logicalWidth", "logicalHeight")
                .any { line.contains(it, ignoreCase = true) }
        }.take(18).joinToString("\n")
        return lines.ifBlank { "디스플레이 모드 정보가 dumpsys에서 노출되지 않음" }.take(2400)
    }
    fun applyDensity(context: Context, requested: Int?): Result {
        if (requested != null && requested !in 120..320) {
            return Result(false, "DPI는 120~320 범위만 허용합니다")
        }
        val app = context.applicationContext
        // Explicit user-confirmed global setting. Third-party rules use separate temporary manager.
        // This is invoked solely by the user-confirmed device-wide recovery button.
        val before = readDensity(app) ?: return Result(false, "ADB로 현재 DPI 확인 불가: 변경하지 않았습니다")
        val prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        // Capture original override exactly once; do not overwrite on every subsequent change.
        if (!prefs.contains("baseline_captured")) {
            prefs.edit().putBoolean("baseline_captured", true)
                .putInt("baseline_physical", before.physical ?: -1)
                .putInt("baseline_override", before.override ?: -1).apply()
        }
        // Explicit OEM recovery always clears global override, even when old baseline captured a bad override.
        val command = if (requested == null) "wm density reset" else "wm density $requested"
        val ready = AuthorizedAdbRuntime.health(app)
        if (ready.state != AuthorizedAdbRuntime.State.READY) return Result(false, "ADB 연결 상태: ${ready.state}")
        val changed = AuthorizedAdbRuntime.writeOnce(app, command).result
        if (!changed.success) return Result(false, "명령 거부: ${changed.message}")
        val after = readDensity(app)
        val actual = after?.override ?: after?.physical
        val verified = after?.physical != null && (if (requested == null) after.override == null else after.override == requested)
        CoreLog.i("DPI", "before=$before cmd=$command after=$after verified=$verified")
        if (!verified) {
            val restore = if (before.override == null) "wm density reset" else "wm density ${before.override}"
            AuthorizedAdbRuntime.writeOnce(app, restore)
            return Result(false, "DPI 적용값 검증 실패. 직전 설정으로 복구를 시도했습니다. 실제=${after ?: "조회 실패"}")
        }
        return Result(true, "${if (requested == null) "전역 DPI 강제설정 해제" else "전역 DPI ${requested} 적용"} 확인. 물리 DPI=$actual. 순정 런처/공조/360 표시가 잘릴 수 있습니다.")
    }
}
