package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.os.SystemClock
import com.byd.dolphin.drivealerts.automation.AppSelection
import com.byd.dolphin.drivealerts.automation.ForegroundResolver
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** One transaction: save OEM density -> change -> actually start chosen app -> restore.
 * Density remains display-wide, never an isolated package DPI. Read-only
 * foreground polling is a fallback when OEM accessibility events are absent.
 */
object TemporaryAppDpiController {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r,"temporary-app-dpi") }
    private val watchdog = Executors.newSingleThreadScheduledExecutor { r -> Thread(r,"dpi-restore-watchdog") }
    private const val PREF = "temporary_app_dpi_session"
    @Volatile private var launchGraceUntil:Long=0L
    private var session=0L
    private var targetSeen=false
    private var offTargetPolls=0
    private var launchedAt=0L
    private fun prefs(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)

    fun onForeground(context:Context,pkg:String) {
        val app=context.applicationContext
        worker.execute { process(app,pkg) }
    }
    fun applyForLaunch(context:Context,pkg:String,dpi:Int,onResult:(DisplaySettingsController.Result)->Unit) {
        val app=context.applicationContext
        worker.execute {
            if (!ThirdPartyDpiRules.allowed(app,pkg) || dpi !in 120..320) {
                onResult(DisplaySettingsController.Result(false,"앱 또는 DPI 값이 올바르지 않습니다"));return@execute
            }
            val component=AppSelection.safeComponent(app,pkg)
            if(component==null) {
                onResult(DisplaySettingsController.Result(false,"실행 Activity 없음: $pkg. 전역 DPI는 변경하지 않았습니다"));return@execute
            }
            if(!ThirdPartyDpiRules.save(app,pkg,dpi)) {
                onResult(DisplaySettingsController.Result(false,"DPI 규칙 저장 실패"));return@execute
            }
            restoreOrRetry(app)
            if(prefs(app).contains("target")) {
                onResult(DisplaySettingsController.Result(false,"이전 DPI가 복원되지 않아 변경을 차단했습니다"));return@execute
            }
            if(AuthorizedAdbRuntime.health(app).state!=AuthorizedAdbRuntime.State.READY) {
                onResult(DisplaySettingsController.Result(false,"ADB 미연결: DPI 변경을 차단했습니다"));return@execute
            }
            val before=DisplaySettingsController.readDensity(app)
            if(before==null) {
                onResult(DisplaySettingsController.Result(false,"현재 DPI 확인 실패: 변경하지 않았습니다"));return@execute
            }
            // Launch FIRST. Previous implementation changed the dashboard density
            // before app start, so an OEM activity failure left this page resized.
            val opened=AuthorizedAdbRuntime.writeOnce(app,
                "am start --user 0 -n '$component'",timeoutMs=12_000L)
            val out=opened.result.output
            val rejected=out.contains("Error:",true)||out.contains("Exception",true)||
                out.contains("Permission Denial",true)||out.contains("does not exist",true)
            if(!opened.result.success || rejected) {
                CoreLog.w("DPI","LAUNCH_FAILED pkg=$pkg state=${opened.state} output=${out.take(350)}")
                onResult(DisplaySettingsController.Result(false,"앱 실행에 실패했으므로 DPI를 변경하지 않았습니다: ${out.take(120)}"));return@execute
            }
            val pref=prefs(app)
            if(!pref.edit().putString("target",pkg).putInt("value",dpi)
                    .putInt("beforeOverride",before.override?:-1).commit()) {
                onResult(DisplaySettingsController.Result(false,"복원 기록 저장 실패: DPI 변경하지 않음"));return@execute
            }
            val changed=AuthorizedAdbRuntime.writeOnce(app,"wm density $dpi",timeoutMs=8_000L)
            val readback=DisplaySettingsController.readDensity(app)
            if(!changed.result.success || readback?.override!=dpi) {
                CoreLog.w("DPI","APPLY_FAILED pkg=$pkg dpi=$dpi adb=${changed.state} readback=$readback")
                restoreOrRetry(app)
                onResult(DisplaySettingsController.Result(false,"DPI 적용 실패: 이전 설정 자동 복원 중"));return@execute
            }
            launchedAt=SystemClock.elapsedRealtime()
            launchGraceUntil=launchedAt+12_000L
            targetSeen=false
            offTargetPolls=0
            val id=++session
            CoreLog.i("DPI","APP_STARTED_THEN_DPI pkg=$pkg dpi=$dpi component=$component;restoreWatchdog=ON")
            armWatchdog(app,id)
            onResult(DisplaySettingsController.Result(true,"$pkg 실행 명령 완료 · $dpi DPI 적용 · 이탈 시 원래 DPI 복원 감시"))
        }
    }

    /** ADB read-only foreground check: independent of accessibility permission. */
    private fun foreground(c:Context):String {
        val r=AuthorizedAdbRuntime.read(c,"dumpsys activity activities",timeoutMs=5_000L).result
        if(!r.success)return ""
        return ForegroundResolver.topToken(r.output).orEmpty()
    }
    private fun armWatchdog(c:Context,id:Long) {
        watchdog.schedule({ worker.execute { checkSession(c,id) } },3,TimeUnit.SECONDS)
    }
    private fun checkSession(c:Context,id:Long) {
        if(id!=session)return
        val target=prefs(c).getString("target",null)?:return
        val now=SystemClock.elapsedRealtime()
        val top=foreground(c)
        val inside=top.contains("$target/")
        if(inside) {targetSeen=true;offTargetPolls=0}
        else if(top.isNotBlank() && now>=launchGraceUntil) offTargetPolls++
        // Do not trap the vehicle UI indefinitely if OEM foreground detection fails.
        val neverOpened=!targetSeen && now-launchedAt>20_000L
        val switched=targetSeen && offTargetPolls>=2
        // Hold while target app remains foreground. If no trustworthy top activity
        // is available for 45 seconds, restore for safety instead of trapping OEM UI.
        val unknownTimeout = top.isBlank() && now-launchedAt>45_000L
        if(neverOpened || switched || unknownTimeout) {
            CoreLog.i("DPI","AUTO_RESTORE reason=${if(neverOpened)"target-not-foreground" else if(switched)"app-left" else "foreground-unknown"};top=${top.take(140)}")
            restoreOrRetry(c)
        } else armWatchdog(c,id)
    }

    fun disableAndRestore(context:Context) {val app=context.applicationContext;worker.execute{session++;restoreOrRetry(app)}}
    fun recoverOnStartup(context:Context) {val app=context.applicationContext;worker.execute{session++;restoreOrRetry(app)}}
    fun applyExplicitGlobal(context:Context,dpi:Int?,onResult:(DisplaySettingsController.Result)->Unit) {
        val app=context.applicationContext
        worker.execute {
            session++;restoreOrRetry(app)
            val result=if(prefs(app).contains("target"))
                DisplaySettingsController.Result(false,"기존 임시 DPI 복원 실패. 전역 DPI 변경을 중단했습니다")
            else DisplaySettingsController.applyDensity(app,dpi)
            onResult(result)
        }
    }
    private fun process(c:Context,pkg:String) {
        val current=prefs(c).getString("target",null)
        if(current!=null) {
            // NEVER restore on the original app's own transition during the launch transaction.
            if(pkg==current) {targetSeen=true;offTargetPolls=0;return}
            if(SystemClock.elapsedRealtime()<launchGraceUntil) return
            // Actual on-screen state is confirmed by watchdog, not a single transient popup.
            return
        }
        if(!ThirdPartyDpiRules.enabled(c))return
        val dpi=ThirdPartyDpiRules.rule(c,pkg)
        if(dpi==0)return
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)return
        val before=DisplaySettingsController.readDensity(c)?:return
        val pref=prefs(c)
        if(!pref.edit().putString("target",pkg).putInt("value",dpi)
                .putInt("beforeOverride",before.override?:-1).commit())return
        launchGraceUntil=SystemClock.elapsedRealtime()+5_000L
        launchedAt=SystemClock.elapsedRealtime()
        targetSeen=true;offTargetPolls=0
        val changed=AuthorizedAdbRuntime.writeOnce(c,"wm density $dpi")
        if(!changed.result.success || DisplaySettingsController.readDensity(c)?.override!=dpi) {
            restoreOrRetry(c);return
        }
        armWatchdog(c,++session)
        CoreLog.i("DPI","AUTO_APPLY pkg=$pkg dpi=$dpi (whole display)")
    }
    /** Persistent recovery journal is only cleared after readback confirms OEM density. */
    private fun restoreOrRetry(c:Context) {
        restore(c)
        if(prefs(c).contains("target")) scheduleRestore(c,session,1)
    }
    private fun scheduleRestore(c:Context,id:Long,attempt:Int) {
        if(attempt>20) {
            CoreLog.w("DPI","RESTORE_RETRY_EXHAUSTED; journal preserved for next app start")
            return
        }
        val delay=when {attempt<=3->3L;attempt<=8->8L;else->20L}
        watchdog.schedule({ worker.execute {
            if(id!=session || !prefs(c).contains("target"))return@execute
            restore(c)
            if(prefs(c).contains("target"))scheduleRestore(c,id,attempt+1)
        } },delay,TimeUnit.SECONDS)
    }

    private fun restore(c:Context) {
        val pref=prefs(c)
        if(!pref.contains("target"))return
        val assigned=pref.getInt("value",0)
        val before=pref.getInt("beforeOverride",-1)
        val now=DisplaySettingsController.readDensity(c)
        if(now?.override==assigned) {
            val command=if(before<0)"wm density reset" else "wm density $before"
            val changed=AuthorizedAdbRuntime.writeOnce(c,command)
            val after=DisplaySettingsController.readDensity(c)
            if(!changed.result.success || after?.override!=before.takeIf{it>=0}) {
                CoreLog.w("DPI","RESTORE_FAILED target=${pref.getString("target",null)} before=$before after=$after")
                return
            }
        } else if(now==null)return
        else if(now.override != before.takeIf { it>=0 }) {
            // An unrelated actor changed display density. Keep our durable journal;
            // never mark a different, unverified setting as successfully restored.
            CoreLog.w("DPI","RESTORE_UNVERIFIED target=${pref.getString("target",null)} before=$before current=$now")
            return
        }
        pref.edit().clear().commit()
        launchGraceUntil=0L
        CoreLog.i("DPI","RESTORED_PREVIOUS_DENSITY override=${before.takeIf{it>=0}}")
    }
}
