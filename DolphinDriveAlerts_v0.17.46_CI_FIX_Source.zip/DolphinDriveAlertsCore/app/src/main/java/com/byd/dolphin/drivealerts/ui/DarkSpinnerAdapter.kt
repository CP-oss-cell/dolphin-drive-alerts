package com.byd.dolphin.drivealerts.ui

import android.content.Context
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/** Keep selected text and Android 10 dropdown rows readable on a dark screen. */
object DarkSpinnerAdapter {
    fun labels(context:Context, data:List<String>):ArrayAdapter<String> =
        object:ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, data) {
            private fun style(v:View, dropdown:Boolean):View {
                if(v is TextView) {
                    v.setTextColor(Color.rgb(237,244,250))
                    v.setBackgroundColor(if(dropdown) Color.rgb(24,39,60) else Color.rgb(28,46,70))
                    val pad=(12*context.resources.displayMetrics.density).toInt()
                    v.setPadding(pad,pad,pad,pad)
                    v.minimumHeight=(44*context.resources.displayMetrics.density).toInt()
                }
                return v
            }
            override fun getView(position:Int, convertView:View?, parent:ViewGroup):View =
                style(super.getView(position,convertView,parent),false)
            override fun getDropDownView(position:Int, convertView:View?, parent:ViewGroup):View =
                style(super.getDropDownView(position,convertView,parent),true)
        }
}
