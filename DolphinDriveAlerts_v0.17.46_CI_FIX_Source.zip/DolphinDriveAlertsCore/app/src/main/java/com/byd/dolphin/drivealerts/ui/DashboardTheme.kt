package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Conservative, one-shot theme. Never re-theme popup internals or mutate running adapters. */
object DashboardTheme {
    private val navy=Color.rgb(11,17,29)
    private val tile=Color.rgb(28,46,70)
    private val fg=Color.rgb(237,244,250)
    private val muted=Color.rgb(176,193,213)
    private val accent=Color.rgb(84,212,220)
    private fun dp(activity:Activity,n:Int)=(n*activity.resources.displayMetrics.density).toInt()
    private fun rounded(activity:Activity):GradientDrawable = GradientDrawable().apply {
        setColor(tile);cornerRadius=dp(activity,10).toFloat()
    }
    fun decorate(activity:Activity) {
        if(activity.isFinishing || activity.isDestroyed) return
        activity.window.statusBarColor=navy
        activity.window.navigationBarColor=navy
        val content=activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        visit(activity,content,0)
    }
    private fun visit(activity:Activity,v:View,depth:Int) {
        // Styling Spinner internals while an Android popup is open causes dark/invisible rows.
        // The adapter itself owns BOTH selected and drop-down row colors.
        when(v) {
            is Spinner -> return
            is EditText -> {
                v.setTextColor(fg);v.setHintTextColor(muted)
                // Preserve cursor, text selection, background state and input-method layout.
            }
            is Button -> {
                v.isAllCaps=false;v.setTextColor(fg)
                v.background=rounded(activity)
                v.minHeight=dp(activity,44)
            }
            is CheckBox -> v.setTextColor(fg)
            is RadioButton -> v.setTextColor(fg)
            is TextView -> v.setTextColor(if(v.textSize/activity.resources.displayMetrics.scaledDensity>=18f) accent else muted)
            is ScrollView -> v.setBackgroundColor(navy)
            is LinearLayout -> if(depth<=2) v.setBackgroundColor(navy)
        }
        // Do not visit Spinner/dropdown internal children or windows owned by dialogs.
        if(v is ViewGroup) for(i in 0 until v.childCount) visit(activity,v.getChildAt(i),depth+1)
    }
}
