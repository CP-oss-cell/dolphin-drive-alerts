package com.byd.dolphin.drivealerts.config

import android.content.Context

/** App voice/effects only. Does not touch vehicle media/safety alert volume. */
object AlertVolume {
    private const val PREF="drive_alert_core"
    private const val KEY="alert_volume_tier"
    private const val MIGRATED="alert_volume_v01744_migrated"
    val labels = listOf("많이 작게", "아주 작게", "조금 작게", "보통")
    fun tier(context: Context): Int {
        val pref=context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        // Previous tiers: 0 조금 작게, 1 작게, 2 보통, 3 크게.
        // Preserve user intent, never silently make sound louder.
        if (!pref.getBoolean(MIGRATED,false)) {
            val old=pref.getInt(KEY,2).coerceIn(0,3)
            val mapped=when(old){ 0 -> 2; 1 -> 1; 2 -> 3; else -> 3 }
            pref.edit().putInt(KEY,mapped).putBoolean(MIGRATED,true).commit()
        }
        return pref.getInt(KEY,3).coerceIn(0,3)
    }
    fun setTier(context:Context,value:Int):Boolean = value in 0..3 &&
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putInt(KEY,value).putBoolean(MIGRATED,true).commit()
    fun trackGain(tier:Int):Float = when(tier.coerceIn(0,3)) {
        0 -> 0.12f  // 많이 작게
        1 -> 0.25f  // 아주 작게
        2 -> 0.48f  // 조금 작게
        else -> 0.88f // 보통 == previous normal, never boosted
    }
    // Deprecated loud-level compatibility stub for historic call sites; no amplification.
    fun safeLoudPcm(samples:ShortArray):ShortArray = samples
}
