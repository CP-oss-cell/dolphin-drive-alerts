package com.byd.dolphin.drivealerts.ui

import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.Manifest
import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.content.Context
import android.os.Build
import com.byd.dolphin.drivealerts.audio.NavPlaybackCaptureRelayService
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.audio.NavRouteCaptureService
import com.byd.dolphin.drivealerts.audio.NavRouteEvidence
import com.byd.dolphin.drivealerts.audio.NavRouteLabPlayer
import com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Integrated navigation-audio lab. No misleading cross-UID redirect claims. */
class NavAudioLabActivity : DensityAwareActivity() {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r,"nav-route-lab") }
    private lateinit var status: TextView
    private lateinit var routeSpinner: Spinner
    private lateinit var navSpinner: Spinner
    private lateinit var routes: List<NavRouteLabPlayer.Route>
    private var lastOwnPlayed = false
    private var requestedNavPkg = ""
    private var requestedNavUid = -1

    private val records: File by lazy { File(filesDir,"nav_audio_lab").apply { mkdirs() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,20,28,28) }
        root.addView(box); DashboardUi.mount(this,root,"내비 음성 경로", "운전석 · 미디어 · 5종 내비")
        fun label(s: String, size: Float=15f): TextView = TextView(this).apply { text=s; textSize=size; setPadding(0,7,0,8) }
        fun button(s: String, f: ()->Unit) { box.addView(Button(this).apply { text=s; isAllCaps=false; setOnClickListener { f() } }) }
        box.addView(label("내비 오디오 라우팅 실험실 · v0.17.27",22f))
        if (!com.byd.dolphin.drivealerts.config.AlertPreferences.neuralVoicePackPresent(this)) {
            box.addView(label("음성 상태: 검증된 남녀 Neural 음성팩 없음. 임시 효과음만 재생.\n성별 미검증 대체 목소리는 사용하지 않습니다.",14f))
        }
        box.addView(label("한 번 설치 후 순정 내비 분석 → Route 5/6 등 후보 직접 청취 → 지정 내비 실행 중 자동 수집 → 비교·내보내기를 반복합니다. 정차(P) 상태에서만 시험하세요.",13f))
        box.addView(label("STEP 1 · 순정 내비 및 5종 내비 경로 스캔",18f))
        box.addView(label("스캔은 3·8·15초에 dumpsys audio/policy/flinger 및 UID 목록을 기록합니다. 차량 ADB가 허용되어야 합니다. 순정은 스캔 시작 후 직접 실행해 안내음을 재생하세요.",13f))
        button("순정 내비 15초 자동 스캔 시작") { capture("STOCK_TMAP", ""); status.text="순정 내비 스캔 예약. 앱을 전환해 실제 안내음이 나오는 상황을 만들어주세요." }
        val appNames = ExternalAppAudioRouter.NAVIGATION_APPS
        navSpinner = Spinner(this).apply { adapter=DarkSpinnerAdapter.labels(this@NavAudioLabActivity,appNames.map { "${it.title} (${it.pkg})" }) }
        box.addView(navSpinner)
        button("선택한 내비 실행 + 자동 스캔") {
            val entry=appNames[navSpinner.selectedItemPosition]
            val launch=packageManager.getLaunchIntentForPackage(entry.pkg)
            if (launch == null) {
                status.text="${entry.title}: 실행 Intent 없음 · 실제 설치 패키지/앱 식별 필요. 스캔만 수행 가능합니다."
                capture("THIRD_${entry.pkg.replace('.', '_')}",entry.pkg)
            } else {
                capture("THIRD_${entry.pkg.replace('.', '_')}",entry.pkg)
                status.text="${entry.title} 실행 후 안내음을 발생시키세요. 오디오 상태는 3·8·15초에 자동 저장됩니다."
                runCatching { startActivity(launch) }.onFailure { status.text="실행 오류 ${it.message} (수집은 예약됨)" }
            }
        }
        box.addView(label("STEP 2 · 운전석 출력 후보를 골라 즉시 시험",18f))
        box.addView(label("Route 5·6은 기존 Assistant에서 성공한 우리 앱 자체 시험음입니다. 아래 결과가 타사 내비 음성이 전환됐다는 뜻은 아닙니다.",13f))
        routes=NavRouteLabPlayer.routes(this)
        routeSpinner=Spinner(this).apply { adapter=DarkSpinnerAdapter.labels(this@NavAudioLabActivity,routes.map { it.label }); setSelection(3) }
        box.addView(routeSpinner)
        button("선택 경로로 시험음 재생 (1.2초 · 증폭)") {
            val selected=routes[routeSpinner.selectedItemPosition]
            status.text="${selected.label} 시험음 출력 요청 중"
            worker.execute {
                val result=NavRouteLabPlayer.play(applicationContext,selected)
                lastOwnPlayed=result.ok
                record("OWN_TONE", selected.id, "playCall=${result.ok} ${result.message}")
                runOnUiThread { status.text=result.message }
            }
        }
        box.addView(label("실제 귀로 들은 위치를 기록하세요. Android routedDevice 값만으로 운전석 단독 출력임을 증명할 수 없습니다.",13f))
        button("청취 결과: 운전석에서만 들림") { audible("DRIVER_ONLY_HEARD") }
        button("청취 결과: 미디어/전체 스피커에서 들림") { audible("MEDIA_OR_ALL_HEARD") }
        button("청취 결과: 무음 또는 불명") { audible("SILENT_OR_UNKNOWN") }
        box.addView(label("STEP 3 · 타사 내비 출력 가능 여부 확인",18f))
        box.addView(label("선택한 내비의 실제 UID 출력 경로를 자동 분석합니다. 그러나 일반 앱은 타 UID의 AudioTrack을 마음대로 옮길 수 없습니다. 권한 없는데 '적용 성공'으로 표시하거나 차량 전체 믹서를 강제 변경하지 않습니다.",13f))
        button("현재 권한·실제 연결 가능 상태 확인") {
            status.text="ADB와 OEM 오디오 권한 조회 중"
            worker.execute {
                val perm=checkSelfPermission("android.permission.MODIFY_AUDIO_ROUTING") == PackageManager.PERMISSION_GRANTED
                val adb=NativeAdbClient.executeShell(applicationContext,"echo NAV_AUDIO_LAB_ADB_OK",timeoutMs=4_000L)
                val accepted=adb.success && adb.output.contains("NAV_AUDIO_LAB_ADB_OK")
                val verdict=NavRouteEvidence.classify(perm,accepted,lastOwnPlayed)
                record("PERMISSION","CROSS_UID", "permission=$perm adb=$accepted $verdict")
                runOnUiThread { status.text="권한: MODIFY_AUDIO_ROUTING=$perm / ADB=$accepted\n$verdict\n선택한 경로의 시험음 재생과 타 앱 안내음 강제 라우팅은 다른 기능입니다." }
            }
        }
        box.addView(label("STEP 3B · 실험: 선택한 내비 음성을 stream14로 재생 (사용자 승인 필요)",18f))
        box.addView(label("Android 10에서 재생 캡처를 허용하고 MEDIA/UNKNOWN/GAME으로 출력하는 앱만 가능합니다. NAVIGATION_GUIDANCE 출력·캡처 금지 앱은 불가능합니다. 원래 미디어 출력도 계속 들릴 수 있습니다. 정차 중 시험하고 종료하세요. 기본 OFF입니다.",13f))
        button("선택한 내비 운전석 안내음 실험 시작 · 화면 캡처 권한 승인") {
            val entry=appNames[navSpinner.selectedItemPosition]
            val uid=runCatching { packageManager.getApplicationInfo(entry.pkg,0).uid }.getOrNull()
            if(uid == null) { status.text="${entry.title} 설치 또는 UID 확인 실패" }
            else if(checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED){
                status.text="음성 저장 없이 출력 재생 캡처에 필요한 RECORD_AUDIO 권한을 승인하고 다시 누르세요."
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),REQ_RECORD_AUDIO)
            } else {
                requestedNavPkg=entry.pkg; requestedNavUid=uid
                val mp=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mp.createScreenCaptureIntent(),REQ_AUDIO_PROJECTION)
                status.text="${entry.title}: Android 시스템 재생 캡처 동의 화면 확인 필요"
            }
        }
        button("운전석 오디오 릴레이 실험 종료") {
            startService(Intent(this,NavPlaybackCaptureRelayService::class.java)
                .setAction(NavPlaybackCaptureRelayService.ACTION_STOP))
            status.text="릴레이 종료 요청 완료"
        }
        button("릴레이 실제 입력량 · 오류 읽기") {
            status.text=File(filesDir,"nav_audio_lab/uid_relay_status.log")
                .takeIf { it.isFile }?.readLines()?.takeLast(8)?.joinToString("\n")
                ?: "릴레이 시험 기록 없음"
        }
        button("순정/선택한 내비 최근 캡처 비교") {
            worker.execute {
                val selected=appNames[navSpinner.selectedItemPosition]
                val stock=latest("STOCK_TMAP")
                val third=latest("THIRD_${selected.pkg.replace('.', '_')}")
                val msg=if(stock == null || third == null) "비교 자료 부족: 순정 및 선택한 내비 자동 스캔을 각각 완료하세요."
                    else compare(stock,third)
                record("COMPARE",selected.pkg,msg)
                runOnUiThread { AlertDialog.Builder(this@NavAudioLabActivity).setTitle("읽기 전용 오디오 비교 · ${selected.title}")
                    .setMessage(msg.take(8_000)).setPositiveButton("닫기",null).show() }
            }
        }
        box.addView(label("STEP 4 · 결과 보존 및 원복",18f))
        button("실험실 자료 ZIP 저장 · 파일 위치 직접 선택") {
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/zip"; putExtra(Intent.EXTRA_TITLE,"DolphinNavAudioLab_${System.currentTimeMillis()}.zip") }
            startActivityForResult(intent,REQUEST_EXPORT)
        }
        button("앱 오디오 기본값 유지 · 시험 종료") {
            record("RESTORE","NO_GLOBAL_CHANGES","no UID or vehicle mixer routing changed; own AudioTrack released per test")
            status.text="글로벌 AudioPolicy/순정 차량 설정은 변경하지 않았습니다. 앱 시험용 AudioTrack은 매 테스트 종료 시 release됩니다."
        }
        status=label("준비: 권한 확인 및 스캔 선택. 실제 성공 여부는 실차 청취 기록으로 판정합니다.",14f)
        box.addView(status)
    }

    private fun capture(label:String,pkg:String) {
        val i=Intent(this,NavRouteCaptureService::class.java).putExtra(NavRouteCaptureService.EXTRA_LABEL,label)
            .putExtra(NavRouteCaptureService.EXTRA_PACKAGE,pkg)
        try { startForegroundService(i) } catch(e:Exception) { status.text="수집 서비스 시작 실패: ${e.message}" }
    }
    private fun audible(verdict:String) {
        val route=routes[routeSpinner.selectedItemPosition]
        record("LISTENING",route.id, "manual=$verdict (self-generated 1.2s tone, not third-party app)")
        status.text="청취 기록: ${route.label} → $verdict (사용자 실차 판정, 타 앱 라우팅 확증 아님)"
    }
    private fun record(event:String, target:String, detail:String) = runCatching {
        synchronized(NavAudioLabActivity::class.java) { File(records,"observations.tsv").appendText("${System.currentTimeMillis()}\t${event.replace('\t',' ')}\t${target.replace('\t',' ')}\t${detail.replace(Regex("[\\t\\r\\n]")," ")}\n") }
    }
    private fun latest(tag:String):File? = records.listFiles()?.filter { it.isDirectory && it.name.endsWith("_$tag") && File(it,"COMPLETE.txt").isFile }?.maxByOrNull { it.name }
    private fun compare(stock:File, third:File):String {
        fun lines(dir:File):Set<String> = (1..3).flatMap { i ->
            listOf("policy.txt","flinger.txt","audio.txt").flatMap { file ->
                val p=File(dir,"snapshot_$i/$file")
                if(p.isFile) NavRouteEvidence.relevantLines(p.readText(),80) else emptyList()
            }
        }.toSet()
        val a=lines(stock);val b=lines(third)
        return "순정: ${stock.name} (${a.size} 유관 텍스트)\n대상: ${third.name} (${b.size} 유관 텍스트)\n\n" +
            "대상에만 관측되는 문자열 (값/UID/타이밍의 우연 차이 가능):\n" +
            b.minus(a).take(28).joinToString("\n").take(5_000) +
            "\n\n※ 출력 장치가 같아 보여도 물리 운전석 라우팅과 UID 강제 전환은 입증되지 않습니다. 전체 원본 로그는 ZIP으로 보존됩니다."
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==REQ_RECORD_AUDIO) status.text=if(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)
            "녹음 권한 승인. 내비 릴레이 시작 버튼을 다시 누르세요." else "권한 거부: 릴레이 미실행"
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        if(requestCode==REQ_AUDIO_PROJECTION) {
            if(resultCode!=RESULT_OK || data==null || requestedNavUid<0){
                status.text="Android 재생 캡처 미승인. 릴레이 시작하지 않음."
                return
            }
            val i=Intent(this,NavPlaybackCaptureRelayService::class.java)
                .setAction(NavPlaybackCaptureRelayService.ACTION_START)
                .putExtra(NavPlaybackCaptureRelayService.EXTRA_PACKAGE,requestedNavPkg)
                .putExtra(NavPlaybackCaptureRelayService.EXTRA_UID,requestedNavUid)
                .putExtra(NavPlaybackCaptureRelayService.EXTRA_RESULT_CODE,resultCode)
                .putExtra(NavPlaybackCaptureRelayService.EXTRA_RESULT_DATA,data)
            runCatching { startForegroundService(i) }.onSuccess {
                status.text="${requestedNavPkg}: 릴레이 시작 요청. 앱 안내음을 재생하고 5초 뒤 입력량을 확인하세요. 무음이면 UID 또는 오디오 사용 유형/캡처 정책을 검사해야 합니다."
            }.onFailure { status.text="릴레이 시작 실패: ${it.javaClass.simpleName} ${it.message}" }
            return
        }

        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=REQUEST_EXPORT || resultCode!=RESULT_OK || data?.data==null)return
        val uri=data.data!!
        status.text="저장 중…"
        worker.execute {
            val result=runCatching {
                contentResolver.openOutputStream(uri)?.use { stream ->
                    ZipOutputStream(stream).use { zip ->
                        records.walkTopDown().filter { it.isFile }.forEach { file ->
                            val name=file.relativeTo(records).invariantSeparatorsPath
                            zip.putNextEntry(ZipEntry(name))
                            file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                        }
                        zip.putNextEntry(ZipEntry("README_STATUS.txt"))
                        zip.write("DA-010: Android output paths and own-tone verification only. Cross-UID nav redirect NOT IMPLEMENTED / NOT REALCAR VERIFIED. No MCU/AVAS write.\n".toByteArray())
                        zip.closeEntry()
                    }
                } ?: error("파일 저장 권한 없음")
                "ZIP 내보내기 완료 · 사용자가 지정한 위치"
            }.getOrElse { "ZIP 내보내기 실패: ${it.message}" }
            runOnUiThread { status.text=result }
        }
    }
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
    companion object { private const val REQUEST_EXPORT=721; private const val REQ_AUDIO_PROJECTION=728; private const val REQ_RECORD_AUDIO=729 }
}
