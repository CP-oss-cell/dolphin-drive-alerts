package com.byd.dolphin.drivealerts.util

import android.util.Log
import com.byd.dolphin.drivealerts.log.FeatureActionJournal

object CoreLog {
    private const val ROOT="DriveAlerts"
    private fun record(tag:String,msg:String) { FeatureActionJournal.record(tag,msg) }
    fun d(tag:String,msg:String):Int {record(tag,msg);return Log.d("$ROOT/$tag",msg)}
    fun i(tag:String,msg:String):Int {record(tag,msg);return Log.i("$ROOT/$tag",msg)}
    fun w(tag:String,msg:String,tr:Throwable?=null):Int {record(tag,msg);return Log.w("$ROOT/$tag",msg,tr)}
    fun e(tag:String,msg:String,tr:Throwable?=null):Int {record(tag,msg);return Log.e("$ROOT/$tag",msg,tr)}
}
