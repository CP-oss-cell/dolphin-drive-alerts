package com.byd.dolphin.drivealerts.vehicle

/** A NORMAL sound is allowed only on an observed ECO falling edge with SPORT inactive.
 * This is a decoder, not a substitute for an unverified car signal; unresolved -> no alert.
 */
internal class EcoOffNormalMachine {
    enum class Mode { ECO, NORMAL, SPORT }
    private var eco: Boolean? = null
    private var sport: Boolean? = null
    fun ecoState(active: Boolean): Mode? {
        val before=eco
        eco=active
        if (active) { sport=false; return if (before!=true) Mode.ECO else null }
        if (before==true && sport==false) return Mode.NORMAL
        return null
    }
    fun sportState(active: Boolean): Mode? {
        val before=sport
        sport=active
        if (active) { eco=false; return if (before!=true) Mode.SPORT else null }
        if (before==true && eco==false) return Mode.NORMAL
        return null
    }
    fun explicitNormal(): Mode? {
        val changed=eco!=false || sport!=false
        eco=false; sport=false
        return if (changed) Mode.NORMAL else null
    }
    fun reset() { eco=null; sport=null }
}
