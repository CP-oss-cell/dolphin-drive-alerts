package com.byd.dolphin.drivealerts.vehicle

/**
 * Candidate association based on the supplied 2602 logs, not an OEM-certified
 * mode signal. Once ECO has been corroborated, losing the short-lived dashboard
 * toast must not automatically erase that corroboration. An actual 364 event is
 * STILL mandatory; we never generate NORMAL merely because time passes.
 */
internal class ModeNoticeCorrelator {
    private var lastNotice = 0
    private var noticeAt = 0L
    private var ecoMatchedAt = 0L
    private var currentEnergy = -1
    private var normalEmittedForEco = false

    fun reset() { lastNotice=0;noticeAt=0L;ecoMatchedAt=0L;currentEnergy=-1;normalEmittedForEco=false }

    fun onDisplay(code: Int, now: Long): Boolean {
        if (code !in 363..365) return false
        if (code == lastNotice) return false
        lastNotice=code
        noticeAt=now
        if (code==365) { ecoMatchedAt=0L;normalEmittedForEco=false;return false }
        if (code==363) { normalEmittedForEco=false;return false }
        // 364 is an observed instrument candidate, NOT a proven mode ID.
        // ECO evidence is sticky, so a driver can remain ECO for many minutes
        // before selecting NORMAL; 364 still has to be observed after that.
        val accept = code==364 && ecoMatchedAt>0L && currentEnergy==1 &&
            !normalEmittedForEco && now>=ecoMatchedAt
        if (accept) normalEmittedForEco=true
        return accept
    }

    fun onEnergy(value:Int, now:Long) {
        if (value==2) {currentEnergy=value;ecoMatchedAt=0L;normalEmittedForEco=false;return}
        currentEnergy=value
        if (value==1) {
            if(lastNotice==363 && now-noticeAt in 0L..2800L) {
                ecoMatchedAt=now
                normalEmittedForEco=false
            }
        } else if(value==0) { ecoMatchedAt=0L }
    }
    fun status():String = "ecoPaired=${ecoMatchedAt>0L};normalAlreadyEmitted=$normalEmittedForEco;lastNotice=$lastNotice;energy=$currentEnergy;needsLive364=true;independentOEMSignalUnverified=true"
}
