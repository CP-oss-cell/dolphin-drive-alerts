package com.byd.dolphin.drivealerts.automation

import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.ui.DashboardUi

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper
import android.widget.*

/** Multi-app ignition launch playlist. Each delay is relative to the previous action. */
class AutoLaunchSettingsActivity:DensityAwareActivity() {
    private lateinit var panel:LinearLayout
    private var apps:List<AppSelection.App> = emptyList()
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,28)}
        DashboardUi.mount(this,ScrollView(this).apply{addView(panel)},"시동 자동 실행", "등록 앱 · 순서 · 재생 · 종료")
        redraw()
        Thread({
            val loaded=runCatching { AppSelection.launchable(applicationContext) }.getOrDefault(emptyList())
            runOnUiThread {
                if (!isFinishing && !isDestroyed) apps = loaded + FeatureProfiles.splits(this).map {
                    AppSelection.App("분할 프로필: ${it.title}","split:${it.id}")
                }
            }
        },"autolaunch-app-catalog").start()
    }
    private fun label(s:String)=TextView(this).apply{text=s;textSize=16f;setTextColor(0xFFEDF4FA.toInt());setPadding(0,8,0,8)}
    private fun button(s:String,f:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{f()}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun redraw(){
        panel.removeAllViews()
        panel.addView(label("시동 자동 실행  ·  등록 앱 ${FeatureProfiles.steps(this).size}개"))
        panel.addView(Switch(this).apply{
            text="시동 자동 실행 시퀀스 ON/OFF"
            isChecked=FeatureProfiles.sequenceEnabled(this@AutoLaunchSettingsActivity)
            setOnCheckedChangeListener{_,v->FeatureProfiles.setSequenceEnabled(this@AutoLaunchSettingsActivity,v)}
        })
        panel.addView(label("시동 ON 때 등록 순서로 실행합니다. 상세 지연·백그라운드 설정은 각 앱의 ‘편집’에서 변경하세요."))
        panel.addView(label("시동 OFF · 지정 앱 종료 (주차감시·문 열림 재생 방지)"))
        panel.addView(Switch(this).apply {
            text="확인된 시동 OFF 신호에서 지정 앱 강제 종료 사용"
            isChecked=IgnitionOffAppStopper.enabled(this@AutoLaunchSettingsActivity)
            setOnCheckedChangeListener { _, v -> IgnitionOffAppStopper.setEnabled(this@AutoLaunchSettingsActivity,v) }
        })
        panel.addView(label("시동 OFF 종료 대상 ${IgnitionOffAppStopper.selected(this).size}개 · 차량 ACC_OFF + 승인된 ADB 필요"))
        panel.addView(button("시동 OFF에 종료할 앱 선택", {
            val choices=apps.filter { !it.packageName.startsWith("split:") && IgnitionOffAppStopper.isSafePackage(it.packageName) }
            if (choices.isEmpty()) { toast("선택 가능한 일반 앱 없음"); return@button }
            val names=choices.map { "${it.title} (${it.packageName})" }.toTypedArray()
            val selected=IgnitionOffAppStopper.selected(this).toMutableSet()
            val checked=choices.map { it.packageName in selected }.toBooleanArray()
            AlertDialog.Builder(this).setTitle("시동 OFF에 강제 종료할 앱")
                .setMultiChoiceItems(names,checked) { _, index, on ->
                    if (on) selected.add(choices[index].packageName) else selected.remove(choices[index].packageName)
                }.setNegativeButton("취소",null).setPositiveButton("저장") { _, _ ->
                    if (IgnitionOffAppStopper.save(this,selected)) redraw() else toast("종료 대상 저장 실패")
                }.show()
        }))
        panel.addView(button("+ 앱 추가",{edit(null)}))
        panel.addView(button("ADB 미디어 알림 권한 적용·확인",{
            Thread({
                val result = PermissionBootstrapper.apply(applicationContext)
                runOnUiThread { toast(result.lines.filter{it.contains("미디어 알림") || it.contains("로컬 ADB")}.joinToString(" / ").take(200)) }
            },"media-adb-permission").start()
        }))
        panel.addView(button("저장된 시퀀스 지금 수동 실행",{AutoLaunchSequenceService.start(this,true)}))
        panel.addView(button("자동 실행 취소",{
            stopService(Intent(this,AutoLaunchSequenceService::class.java))
            toast("실행 중단 요청")
        }))
        FeatureProfiles.steps(this).forEachIndexed{idx,step->
            panel.addView(label("${idx+1}. ${step.packageName}\n${step.delaySeconds}초 뒤 실행 / 미디어=${step.isMedia} / 재생 ${step.playDelaySeconds}초 뒤 / 백그라운드=${step.restoreBackground} / 사용=${step.enabled}"))
            panel.addView(button("편집",{edit(step)}))
            panel.addView(button("위로",{move(step,-1)}))
            panel.addView(button("아래로",{move(step,1)}))
            panel.addView(button("삭제",{FeatureProfiles.saveSteps(this,FeatureProfiles.steps(this).filterNot{it.id==step.id});redraw()}))
        }
        panel.addView(label("재생 성공은 MediaSession의 PLAYING 상태로 확인합니다. 미지원 앱은 재생할 수 없을 수 있습니다."))
        DashboardUi.sectionize(this,panel)
        DashboardUi.refresh(this,panel)
    }
    private fun move(step:LaunchStep,direction:Int){
        val list=FeatureProfiles.steps(this).toMutableList()
        val from=list.indexOfFirst{it.id==step.id};val to=from+direction
        if(from>=0&&to in list.indices){val old=list.removeAt(from);list.add(to,old);FeatureProfiles.saveSteps(this,list);redraw()}
    }
    private fun edit(old:LaunchStep?){
        if(apps.isEmpty()){toast("실행 가능한 앱을 찾을 수 없습니다");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,6,24,6)}
        val packages=apps.map{"${it.title} (${it.packageName})"}
        val chooser=Spinner(this).apply{adapter=com.byd.dolphin.drivealerts.ui.DarkSpinnerAdapter.labels(this@AutoLaunchSettingsActivity,packages)}
        old?.let {chooser.setSelection(apps.indexOfFirst{a->a.packageName==old.packageName}.coerceAtLeast(0))}
        val delay=EditText(this).apply{hint="앱 실행 전 지연 (초, 0~600)";inputType=2;setText("${old?.delaySeconds?:0}")}
        val media=CheckBox(this).apply{text="미디어 앱 (재생 명령 추가)";isChecked=old?.isMedia?:false}
        val play=EditText(this).apply{hint="앱 실행 후 재생 지연 (초, 0~600)";inputType=2;setText("${old?.playDelaySeconds?:3}")}
        val background=CheckBox(this).apply{text="미디어 앱 화면 열지 않고 백그라운드 재생 우선 (실패 시 선택 앱 화면을 열고 재생 후 HOME 복귀 시도)";isChecked=old?.restoreBackground?:false}
        val enabled=CheckBox(this).apply{text="이 앱 자동실행 사용";isChecked=old?.enabled?:true}
        box.addView(label("실행할 앱"));box.addView(chooser);box.addView(label("실행 전 지연(초)"));box.addView(delay)
        box.addView(media);box.addView(label("미디어 재생 지연(초)"));box.addView(play);box.addView(background);box.addView(enabled)
        AlertDialog.Builder(this).setTitle(if(old==null)"앱 실행 추가" else "앱 실행 변경")
            .setView(ScrollView(this).apply{addView(box)}).setNegativeButton("취소",null)
            .setPositiveButton("저장"){_,_->
                val a=apps[chooser.selectedItemPosition].packageName
                val seconds=delay.text.toString().toIntOrNull()?.coerceIn(0,600)?:0
                val playSeconds=play.text.toString().toIntOrNull()?.coerceIn(0,600)?:0
                val step=LaunchStep(old?.id?:java.util.UUID.randomUUID().toString(),a,seconds,media.isChecked,playSeconds,enabled.isChecked,background.isChecked)
                val list=FeatureProfiles.steps(this).toMutableList()
                val idx=list.indexOfFirst{it.id==step.id}
                if(idx>=0)list[idx]=step else list.add(step)
                FeatureProfiles.saveSteps(this,list);redraw()
            }.show()
    }
}
