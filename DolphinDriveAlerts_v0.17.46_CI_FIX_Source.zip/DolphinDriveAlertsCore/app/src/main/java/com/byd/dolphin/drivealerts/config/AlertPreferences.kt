package com.byd.dolphin.drivealerts.config

import android.content.Context
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.OutputRoute

object AlertPreferences {
    private const val PREF = "drive_alert_core"
    private const val KEY_ROUTE = "route"
    private const val KEY_STYLE = "style"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_AUTOSTART = "auto_start"
    private const val KEY_BSD_INDICATOR = "bsd_blinker_enabled"
    private const val KEY_BSD_INSTANT = "bsd_instant_enabled"
    private const val KEY_BSD_TURN_SOUND_EXPERIMENTAL = "bsd_turn_click_candidate_opt_in"

    fun route(context: Context): OutputRoute = runCatching {
        OutputRoute.valueOf(prefs(context).getString(KEY_ROUTE, OutputRoute.DRIVER_STREAM14.name)!!)
    }.getOrDefault(OutputRoute.DRIVER_STREAM14)

    fun setRoute(context: Context, route: OutputRoute) =
        prefs(context).edit().putString(KEY_ROUTE, route.name).apply()

    fun style(context: Context): AlertStyle {
        val requested = runCatching {
            AlertStyle.valueOf(prefs(context).getString(KEY_STYLE, AlertStyle.FEMALE.name)!!)
        }.getOrDefault(AlertStyle.FEMALE)
        // v0.17.22: never play gender-mislabelled synthetic speech from a pack
        // with unverified provenance. Effects-only build ships no voice manifest.
        if (requested == AlertStyle.EFFECT) return requested
        return if (neuralVoicePackPresent(context)) requested else AlertStyle.EFFECT
    }

    fun neuralVoicePackPresent(context: Context): Boolean = runCatching {
        context.assets.open("voice/voice_pack_manifest.generated.json").use { input ->
            val text = input.bufferedReader().readText()
            // The build has already checked hashes/provenance; this guard prevents
            // silent missing voice assets at runtime in effects-only builds.
            text.contains("ko-KR-InJoonNeural") && text.contains("ko-KR-SunHiNeural") &&
                !text.contains("gtts-fallback")
        }
    }.getOrDefault(false)

    fun setStyle(context: Context, style: AlertStyle) =
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

    /** Enabled by default: after first install/open, vehicle boot/quick-boot starts the service automatically. */
    fun autoStartEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTOSTART, true)
    fun setAutoStartEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_AUTOSTART, enabled).apply()

    /** Left/right *blinker* presence only; does NOT identify BSD hazard side. */
    fun bsdBlinkerEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INDICATOR, true)
    fun setBsdBlinkerEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INDICATOR, enabled).apply()

    /** The turn-click candidate also fires under some hazard-lamp conditions; explicit opt-in only. */
    fun bsdTurnSoundExperimentalEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BSD_TURN_SOUND_EXPERIMENTAL, false)
    fun setBsdTurnSoundExperimentalEnabled(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_TURN_SOUND_EXPERIMENTAL, value).apply()

    /** Optional generic immediate voice, OFF by default until each car's BSD raw is verified. */
    fun bsdInstantEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INSTANT, false)
    fun setBsdInstantEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INSTANT, enabled).apply()

    /** Default ON per owner's request: a recent 363+ECO(1) match followed by 364
     * enables NORMAL; opt-out is kept. Not an OEM-verified raw mode code. */
    fun normalNoticeCandidateEnabled(context: Context): Boolean =
        prefs(context).getBoolean("normal_notice_candidate_opt_in", true)
    fun setNormalNoticeCandidateEnabled(context: Context, value:Boolean) =
        prefs(context).edit().putBoolean("normal_notice_candidate_opt_in", value).apply()

    /** Each known alert can be muted without altering OEM monitoring or event decoding.
     * Defaults to ON so existing real-car-verified outputs are unchanged on upgrade. */
    fun eventEnabled(context: Context, event: AlertEvent): Boolean =
        prefs(context).getBoolean("alert_event_" + event.name, true)

    /** commit for immediate consistent preference after user taps. */
    fun setEventEnabled(context: Context, event: AlertEvent, enabled: Boolean): Boolean =
        prefs(context).edit().putBoolean("alert_event_" + event.name, enabled).commit()

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
