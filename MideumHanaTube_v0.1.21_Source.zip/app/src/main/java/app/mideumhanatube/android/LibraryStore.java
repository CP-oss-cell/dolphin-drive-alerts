package app.mideumhanatube.android;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

/** Private, local-only bookmarks and recent history. No accounts or network sync. */
public final class LibraryStore {
    private static final String PREF = "mideumhanatube_private_library";
    private static final int MAX_HISTORY = 80;
    private static final int MAX_BOOKMARKS = 200;
    private final SharedPreferences prefs;

    public LibraryStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static final class Entry {
        public final String title;
        public final String url;

        public Entry(String title, String url) {
            this.title = title;
            this.url = url;
        }

        @Override public String toString() { return title; }
    }

    private List<Entry> read(String key) {
        List<Entry> entries = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                String url = obj.optString("url", "");
                if (!url.startsWith("https://")) continue;
                entries.add(new Entry(obj.optString("title", url), url));
            }
        } catch (Exception ignored) { }
        return entries;
    }

    private void write(String key, List<Entry> entries, int max) {
        JSONArray arr = new JSONArray();
        for (int i = 0; i < entries.size() && i < max; i++) {
            Entry entry = entries.get(i);
            JSONObject obj = new JSONObject();
            try {
                obj.put("title", entry.title);
                obj.put("url", entry.url);
                arr.put(obj);
            } catch (Exception ignored) { }
        }
        prefs.edit().putString(key, arr.toString()).apply();
    }

    public List<Entry> history() { return read("history"); }
    public List<Entry> bookmarks() { return read("bookmarks"); }

    public void addHistory(String title, String url) {
        if (!isYoutubeUrl(url)) return;
        List<Entry> items = history();
        String resolved = safeTitle(title, url);
        for (Entry old : items) {
            if (old.url.equals(url) && BookmarkTitleResolver.isFallback(resolved)
                    && !BookmarkTitleResolver.isFallback(old.title)) {
                resolved = old.title;
                break;
            }
        }
        items.removeIf(e -> e.url.equals(url));
        items.add(0, new Entry(resolved, url));
        write("history", items, MAX_HISTORY);
    }

    public boolean isBookmarked(String url) {
        if (url == null) return false;
        for (Entry item : bookmarks()) if (url.equals(item.url)) return true;
        return false;
    }

    public void addBookmark(String title, String url) {
        if (!isYoutubeUrl(url)) return;
        List<Entry> items = bookmarks();
        items.removeIf(e -> e.url.equals(url));
        items.add(0, new Entry(safeTitle(title, url), url));
        write("bookmarks", items, MAX_BOOKMARKS);
    }

    public void removeBookmark(String url) {
        List<Entry> items = bookmarks();
        if (items.removeIf(e -> e.url.equals(url))) write("bookmarks", items, MAX_BOOKMARKS);
    }

    public void renameBookmark(String url, String name) {
        if (name == null || name.trim().isEmpty()) return;
        List<Entry> items = bookmarks();
        boolean changed = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).url.equals(url)) {
                items.set(i, new Entry(safeTitle(name, url), url));
                changed = true;
            }
        }
        if (changed) write("bookmarks", items, MAX_BOOKMARKS);
    }

    /** Upgrade legacy 'YouTube' bookmark labels only if they were not renamed by the user. */
    public void repairGenericTitles(String url, String newTitle) {
        if (!isYoutubeUrl(url) || BookmarkTitleResolver.isFallback(newTitle)) return;
        for (String key : new String[] {"bookmarks", "history"}) {
            List<Entry> items = read(key);
            boolean changed = false;
            for (int i = 0; i < items.size(); i++) {
                Entry item = items.get(i);
                if (item.url.equals(url) &&
                        (BookmarkTitleResolver.isGeneric(item.title) ||
                                BookmarkTitleResolver.isFallback(item.title))) {
                    items.set(i, new Entry(safeTitle(newTitle, url), url));
                    changed = true;
                }
            }
            if (changed) write(key, items, key.equals("bookmarks") ? MAX_BOOKMARKS : MAX_HISTORY);
        }
    }

    /** Music collections are separate from legacy bookmarks ("나중에 보기").
     * Existing users keep all original bookmarks with no migration or destructive rewrite.
     */
    private static final String MUSIC_KEY = "music_collections_v1";
    public static final String DEFAULT_MUSIC = "내 음악";
    public List<String> musicPlaylistNames() {
        List<String> names = new ArrayList<>();
        names.add(DEFAULT_MUSIC);
        try {
            JSONObject all = new JSONObject(prefs.getString(MUSIC_KEY, "{}"));
            java.util.Iterator<String> it = all.keys();
            while (it.hasNext()) {
                String n = it.next();
                if (!DEFAULT_MUSIC.equals(n) && validPlaylistName(n)) names.add(n);
            }
        } catch (Exception ignored) { }
        java.util.Collections.sort(names.subList(1, names.size()));
        return names;
    }
    private static boolean validPlaylistName(String name) {
        return name != null && !name.trim().isEmpty() && name.length() <= 40
                && !name.contains("/") && !name.contains("\\");
    }
    public boolean createMusicPlaylist(String name) {
        if (!validPlaylistName(name)) return false;
        String clean = name.trim();
        if (musicPlaylistNames().contains(clean) || musicPlaylistNames().size() >= 25) return false;
        try {
            JSONObject all = new JSONObject(prefs.getString(MUSIC_KEY, "{}"));
            all.put(clean, new JSONArray());
            prefs.edit().putString(MUSIC_KEY, all.toString()).apply();
            return true;
        } catch (Exception ignored) { return false; }
    }
    public List<Entry> musicTracks(String playlist) {
        List<Entry> result = new ArrayList<>();
        if (!validPlaylistName(playlist)) return result;
        try {
            JSONObject all = new JSONObject(prefs.getString(MUSIC_KEY, "{}"));
            JSONArray arr = all.optJSONArray(playlist);
            if (arr == null) return result;
            for (int i=0;i<arr.length() && result.size()<200;i++) {
                JSONObject obj=arr.optJSONObject(i);
                if (obj == null) continue;
                String url=obj.optString("url", "");
                if (isYoutubeUrl(url)) result.add(new Entry(safeTitle(obj.optString("title", "음악"),url),url));
            }
        } catch (Exception ignored) { }
        return result;
    }
    public void saveMusicTrack(String playlist, String title, String url) {
        if (!validPlaylistName(playlist) || !isYoutubeUrl(url)) return;
        List<Entry> entries=musicTracks(playlist);
        entries.removeIf(e->e.url.equals(url));
        entries.add(0,new Entry(safeTitle(title,url),url));
        saveMusicTracks(playlist,entries);
    }
    public boolean containsMusicTrack(String url) {
        for (String name : musicPlaylistNames())
            for (Entry e : musicTracks(name)) if (e.url.equals(url)) return true;
        return false;
    }
    public boolean isSavedAnywhere(String url) { return isBookmarked(url) || containsMusicTrack(url); }
    public void saveMusicTracks(String playlist, List<Entry> entries) {
        if (!validPlaylistName(playlist)) return;
        try {
            JSONObject all = new JSONObject(prefs.getString(MUSIC_KEY, "{}"));
            JSONArray arr = new JSONArray();
            if (entries != null) for (Entry e : entries) {
                if (e==null || !isYoutubeUrl(e.url)) continue;
                JSONObject item=new JSONObject();
                item.put("title",safeTitle(e.title,e.url)); item.put("url",e.url); arr.put(item);
                if (arr.length()>=200) break;
            }
            all.put(playlist,arr);
            prefs.edit().putString(MUSIC_KEY, all.toString()).apply();
        } catch (Exception ignored) { }
    }
    public boolean renameMusicPlaylist(String oldName, String newName) {
        if (DEFAULT_MUSIC.equals(oldName) || !validPlaylistName(newName) ||
                musicPlaylistNames().contains(newName.trim())) return false;
        try {
            JSONObject all=new JSONObject(prefs.getString(MUSIC_KEY,"{}"));
            JSONArray records=all.optJSONArray(oldName);
            if(records==null)return false;
            all.remove(oldName);all.put(newName.trim(),records);
            prefs.edit().putString(MUSIC_KEY,all.toString()).apply();
            return true;
        } catch(Exception e) {return false;}
    }
    public boolean removeMusicPlaylist(String playlist) {
        if (DEFAULT_MUSIC.equals(playlist) || !validPlaylistName(playlist)) return false;
        try {
            JSONObject all=new JSONObject(prefs.getString(MUSIC_KEY,"{}"));
            if (!all.has(playlist)) return false;
            all.remove(playlist); prefs.edit().putString(MUSIC_KEY,all.toString()).apply();
            return true;
        } catch (Exception ignored) { return false; }
    }
    public JSONObject exportLibrary() {
        JSONObject result=new JSONObject();
        try {
            result.put("schema",2);
            result.put("watchLater",new JSONArray(prefs.getString("bookmarks","[]")));
            result.put("history",new JSONArray(prefs.getString("history","[]")));
            result.put("music",new JSONObject(prefs.getString(MUSIC_KEY,"{}")));
        } catch (Exception ignored) { }
        return result;
    }
    /** Imports ONLY valid https YouTube URLs and text. Never imports tokens or credentials. */
    public boolean importLibrary(JSONObject data) {
        if (data == null || data.optInt("schema",0) != 2) return false;
        try {
            JSONObject music = data.optJSONObject("music");
            JSONArray watch=data.optJSONArray("watchLater"),history=data.optJSONArray("history");
            if (watch == null || music == null || history == null) return false;
            write("bookmarks",validatedEntries(watch),MAX_BOOKMARKS);
            write("history",validatedEntries(history),MAX_HISTORY);
            JSONObject cleaned=new JSONObject();
            java.util.Iterator<String> names=music.keys();
            int count=0;
            while (names.hasNext() && count<25) {
                String name=names.next();
                if (!validPlaylistName(name)) continue;
                JSONArray items=music.optJSONArray(name);
                if (items == null) continue;
                JSONArray out=new JSONArray();
                for (Entry e : validatedEntries(items)) {
                    JSONObject obj=new JSONObject();obj.put("title",e.title);obj.put("url",e.url);out.put(obj);
                    if (out.length()>=200) break;
                }
                cleaned.put(name,out);count++;
            }
            prefs.edit().putString(MUSIC_KEY,cleaned.toString()).apply();
            return true;
        } catch (Exception ignored) { return false; }
    }
    private List<Entry> validatedEntries(JSONArray source) {
        List<Entry> result=new ArrayList<>();
        if (source == null) return result;
        for (int i=0;i<source.length() && result.size()<200;i++) {
            JSONObject obj=source.optJSONObject(i);if(obj==null)continue;
            String url=obj.optString("url","");
            if (!isYoutubeUrl(url) || url.length()>2048) continue;
            result.add(new Entry(safeTitle(obj.optString("title","영상"),url),url));
        }
        return result;
    }

    public void clearHistory() { prefs.edit().remove("history").apply(); }
    public void clearBookmarks() { prefs.edit().remove("bookmarks").apply(); }

    private static String safeTitle(String title, String url) {
        if (title == null || title.trim().isEmpty()) return url;
        String cleaned = title.trim();
        return cleaned.length() > 110 ? cleaned.substring(0, 110) : cleaned;
    }

    public static boolean isYoutubeUrl(String url) {
        try {
            android.net.Uri uri = android.net.Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
            String host = uri.getHost();
            return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                    || AdBlockEngine.isHostOrSubdomain(host, "youtu.be");
        } catch (Exception ignored) {
            return false;
        }
    }
}
