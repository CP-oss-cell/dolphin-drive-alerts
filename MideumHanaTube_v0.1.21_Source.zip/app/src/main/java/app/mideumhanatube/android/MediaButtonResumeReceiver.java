package app.mideumhanatube.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.KeyEvent;

/** Best-effort restart after the UI has closed. Active MediaSession handles
 * normal Bluetooth headset/car commands first; OS routing is device-controlled.
 * Never autoplay on mere connection or boot.
 */
public final class MediaButtonResumeReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_MEDIA_BUTTON.equals(intent.getAction())) return;
        KeyEvent key = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
        if (key == null || key.getAction() != KeyEvent.ACTION_DOWN || key.getRepeatCount() != 0) return;
        String action;
        switch(key.getKeyCode()) {
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                action=BackgroundAudioService.ACTION_RESUME_LAST; break;
            default:return;
        }
        // Prevent creating a FGS without a valid saved session.
        String saved=context.getSharedPreferences("mht_last_music_resume",Context.MODE_PRIVATE)
                .getString("last", "");
        if(saved==null || saved.length()<20) return;
        try {
            String url=new org.json.JSONObject(saved).optString("url","");
            if(!YouTubeStreamResolver.isSupportedVideoUrl(url))return;
        } catch(Exception invalid){return;}
        Intent service=new Intent(context,BackgroundAudioService.class).setAction(action);
        try {
            if (Build.VERSION.SDK_INT>=26) context.startForegroundService(service);
            else context.startService(service);
        } catch(RuntimeException ignored) {
            // Background-start restrictions may refuse this implicit routing.
        }
    }
}
