package app.mideumhanatube.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Native drawn picture-in-picture pictogram (no emoji font dependency). */
public final class PipIconButton extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    public PipIconButton(Context context) {
        super(context);
        setContentDescription("작은 화면(PIP)");
        setClickable(true);
        setFocusable(true);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density=getResources().getDisplayMetrics().density;
        float cx=getWidth()/2f, cy=getHeight()/2f;
        paint.setColor(Color.rgb(237,242,249));
        paint.setStrokeWidth(Math.max(1.5f,1.8f*density));
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRoundRect(new RectF(cx-13*density,cy-9*density,cx+13*density,cy+9*density),
            2*density,2*density,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(25,36,52));
        canvas.drawRect(cx-1*density,cy+1*density,cx+16*density,cy+12*density,paint);
        paint.setColor(Color.rgb(96,165,250));
        canvas.drawRoundRect(new RectF(cx,cy+2*density,cx+14*density,cy+11*density),
            1.5f*density,1.5f*density,paint);
    }
}
