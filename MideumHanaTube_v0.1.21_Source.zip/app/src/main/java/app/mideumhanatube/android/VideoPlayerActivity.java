package app.mideumhanatube.android;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.RemoteAction;
import android.net.Uri;
import java.io.IOException;
import android.graphics.drawable.Icon;
import android.media.session.MediaController;
import java.util.ArrayList;
import android.app.PictureInPictureParams;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

/** A video-only PiP surface, independent of WebView and its toolbars. */
public final class VideoPlayerActivity extends Activity {
    public static final String EXTRA_PAGE_URL = "page_url";
    public static final String EXTRA_START_MS = "start_ms";
    public static final String EXTRA_START_IN_PIP = "enter_pip_on_ready";
    public static final String EXTRA_PAGE_TITLE = "page_title";
    public static final String EXTRA_REATTACH = "reattach_existing_native_player";
    private PlayerView playerView;
    private LinearLayout controls;
    private TextView banner;
    private boolean bound;
    private String latestPageUrl;
    private String latestTitle;
    private long latestPositionMs;
    private boolean snapshotPlaying;
    private boolean receiverRegistered;
    private final BroadcastReceiver mediaEvents = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BackgroundAudioService.ACTION_NATIVE_FAILURE.equals(intent.getAction())) {
                String why = intent.getStringExtra(BackgroundAudioService.EXTRA_ERROR);
                banner.setText(why == null ? "독립 영상 연결 실패 · 웹으로 돌아가 주세요." : why);
                startInPip = false;
            } else if (BackgroundAudioService.ACTION_NATIVE_READY.equals(intent.getAction())) {
                updateState();
            } else if (BackgroundAudioService.ACTION_NATIVE_SNAPSHOT.equals(intent.getAction())) {
                if (!intent.getBooleanExtra(BackgroundAudioService.EXTRA_NATIVE_ACTIVE, false)) return;
                latestPageUrl = intent.getStringExtra(BackgroundAudioService.EXTRA_ACTIVE_PAGE);
                latestTitle = intent.getStringExtra(BackgroundAudioService.EXTRA_TITLE);
                latestPositionMs = intent.getLongExtra(BackgroundAudioService.EXTRA_POSITION_MS, 0L);
                snapshotPlaying = intent.getBooleanExtra(BackgroundAudioService.EXTRA_PLAYING, false);
                updateState();
            }
        }
    };
    private ExoPlayer player;
    private boolean startInPip;
    private boolean enteredInitialPip;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            if (!(binder instanceof BackgroundAudioService.LocalBinder)) return;
            player = ((BackgroundAudioService.LocalBinder) binder).player();
            playerView.setPlayer(player);
            if (player != null) {
                player.addListener(listener);
                updateState();
                setPipActions();
            }
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            if (player != null) player.removeListener(listener);
            playerView.setPlayer(null);
            player = null;
        }
    };
    private final Player.Listener listener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int state) { updateState(); }
        @Override public void onIsPlayingChanged(boolean playing) { updateState(); setPipActions(); }
        @Override public void onMediaItemTransition(androidx.media3.common.MediaItem item, int reason) {
            updateState(); setPipActions();
        }
        @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
            banner.setText("영상 연결에 실패했습니다. 웹 영상으로 돌아갈 수 있습니다.");
        }
    };
    private void updateState() {
        if (banner == null || player == null) return;
        latestPositionMs = Math.max(0L, player.getCurrentPosition());
        if (startInPip && !enteredInitialPip && player.isPlaying()) {
            enteredInitialPip = true;
            banner.post(this::enterPipNow);
        }
        switch (player.getPlaybackState()) {
            case Player.STATE_READY:
                banner.setText(player.isPlaying() ? "영상 재생 중 · 전체화면에서 구간 탐색 가능" : "일시정지 · 전체화면에서 구간 탐색 가능");
                break;
            case Player.STATE_BUFFERING: banner.setText("영상 준비 중…"); break;
            case Player.STATE_ENDED: banner.setText("재생 완료"); break;
            default: banner.setText("영상 연결 대기 중…");
        }
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String url = getIntent().getStringExtra(EXTRA_PAGE_URL);
        boolean reattach = getIntent().getBooleanExtra(EXTRA_REATTACH, false);
        latestPageUrl = url;
        latestTitle = getIntent().getStringExtra(EXTRA_PAGE_TITLE);
        if (!reattach && !YouTubeStreamResolver.isSupportedVideoUrl(url)) {
            Toast.makeText(this, "먼저 유튜브 영상을 선택해 주세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        startInPip = getIntent().getBooleanExtra(EXTRA_START_IN_PIP, false);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(12, 6, 12, 6);
        controls.setBackgroundColor(0xCC0F1723);
        banner = new TextView(this);
        banner.setTextColor(Color.WHITE);
        banner.setText("영상 연결 대기 중…");
        controls.addView(banner, new LinearLayout.LayoutParams(0, -2, 1f));
        Button pip = new Button(this);
        pip.setText("작은 화면");
        pip.setOnClickListener(v -> enterPipNow());
        controls.addView(pip);
        Button web = new Button(this);
        web.setText("웹으로");
        web.setOnClickListener(v -> {
            String address = latestPageUrl;
            if (address == null || !YouTubeStreamResolver.isSupportedVideoUrl(address)) {
                Toast.makeText(this, "복귀할 영상 주소를 찾지 못했습니다.", Toast.LENGTH_SHORT).show();
                return;
            }
            long position = player == null ? latestPositionMs : Math.max(0L,player.getCurrentPosition());
            Intent back = new Intent(this,MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(MainActivity.EXTRA_NATIVE_VIDEO_RETURN_URL, address)
                    .putExtra(MainActivity.EXTRA_NATIVE_VIDEO_RETURN_MS, position);
            if (player != null) player.pause();
            startActivity(back);
            // MainActivity owns the return handoff and pauses/stops native after
            // WebView playback has been confirmed, avoiding an audible overlap.
            finish();
        });
        controls.addView(web);
        Button diagnostics = new Button(this);
        diagnostics.setText("진단");
        diagnostics.setOnClickListener(v -> shareQuickDiagnostics());
        controls.addView(diagnostics);
        root.addView(controls, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        setContentView(root);
        IntentFilter mediaFilter = new IntentFilter(BackgroundAudioService.ACTION_NATIVE_FAILURE);
        mediaFilter.addAction(BackgroundAudioService.ACTION_NATIVE_READY);
        mediaFilter.addAction(BackgroundAudioService.ACTION_NATIVE_SNAPSHOT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(mediaEvents, mediaFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(mediaEvents, mediaFilter);
        receiverRegistered = true;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                setPictureInPictureParams(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(16, 9)).setAutoEnterEnabled(true)
                        .setActions(pipRemoteActions()).build());
            } catch (RuntimeException ignored) { }
        }
        Intent start = new Intent(this, BackgroundAudioService.class)
                .setAction(reattach ? BackgroundAudioService.ACTION_NATIVE_QUERY :
                        BackgroundAudioService.ACTION_NATIVE_VIDEO_START)
                .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL, url)
                .putExtra(BackgroundAudioService.EXTRA_POSITION_MS,
                        Math.max(0L, getIntent().getLongExtra(EXTRA_START_MS, 0L)))
                .putExtra(BackgroundAudioService.EXTRA_TITLE,
                        getIntent().getStringExtra(EXTRA_PAGE_TITLE));
        if (!reattach) {
            ArrayList<String> urls = getIntent().getStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS);
            ArrayList<String> titles = getIntent().getStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_TITLES);
            if (urls != null) start.putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS, urls);
            if (titles != null) start.putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_TITLES, titles);
            start.putExtra(BackgroundAudioService.EXTRA_QUEUE_START,
                    getIntent().getIntExtra(BackgroundAudioService.EXTRA_QUEUE_START, 0));
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
            else startService(start);
            bound = bindService(new Intent(this, BackgroundAudioService.class), connection,
                    Context.BIND_AUTO_CREATE);
        } catch (RuntimeException error) {
            banner.setText("영상 서비스 실행 실패. 웹 영상으로 돌아가 주세요.");
        }
    }
    private void shareQuickDiagnostics() {
        PlaybackDiagnostics.event(this,0L,"QUICK_DIAGNOSTICS_REQUESTED","VIDEO_SURFACE",player);
        if (Build.VERSION.SDK_INT < 29) {
            Intent main=new Intent(this,MainActivity.class)
                    .putExtra(MainActivity.EXTRA_OPEN_DIAGNOSTICS,true)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(main);
            return;
        }
        try {
            Uri saved=PlaybackDiagnostics.saveToDownloads(this);
            Intent share=new Intent(Intent.ACTION_SEND).setType("application/zip")
                    .putExtra(Intent.EXTRA_STREAM,saved)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"진단 ZIP 공유"));
        } catch(IOException | RuntimeException error) {
            Toast.makeText(this,"진단 ZIP 저장·공유에 실패했습니다.",Toast.LENGTH_LONG).show();
        }
    }

    private ArrayList<RemoteAction> pipRemoteActions() {
        // Android PiP supplies at most a small number of system actions; it has
        // no arbitrary seek-bar View. Seek via the full PlayerView or media notice.
        ArrayList<RemoteAction> actions = new ArrayList<>();
        actions.add(pipAction(BackgroundAudioService.ACTION_QUEUE_PREVIOUS,
                android.R.drawable.ic_media_previous, "이전 영상", 301));
        boolean isPlaying = player != null ? player.isPlaying() : snapshotPlaying;
        actions.add(pipAction(isPlaying ? BackgroundAudioService.ACTION_PAUSE : BackgroundAudioService.ACTION_PLAY,
                isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                isPlaying ? "일시정지" : "재생", 302));
        actions.add(pipAction(BackgroundAudioService.ACTION_QUEUE_NEXT,
                android.R.drawable.ic_media_next, "다음 영상", 303));
        return actions;
    }
    private RemoteAction pipAction(String action, int drawable, String label, int requestId) {
        PendingIntent click = PendingIntent.getService(this, requestId,
                new Intent(this, BackgroundAudioService.class).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new RemoteAction(Icon.createWithResource(this,drawable), label, label, click);
    }
    private void setPipActions() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            PictureInPictureParams.Builder options = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16,9)).setActions(pipRemoteActions());
            if (Build.VERSION.SDK_INT >= 31) options.setAutoEnterEnabled(true);
            setPictureInPictureParams(options.build());
        } catch (RuntimeException ignored) { }
    }
    private void enterPipNow() {
        if (Build.VERSION.SDK_INT < 26 ||
                !getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            Toast.makeText(this, "이 기기는 작은 화면을 지원하지 않습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            PictureInPictureParams.Builder b = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(true);
            b.setActions(pipRemoteActions());
            boolean entered = enterPictureInPictureMode(b.build());
            if (!entered) Toast.makeText(this, "작은 화면 진입이 허용되지 않았습니다.", Toast.LENGTH_LONG).show();
        } catch (RuntimeException error) {
            Toast.makeText(this, "Android 설정에서 PIP 허용을 확인해 주세요.", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT < 31 && player != null && player.isPlaying()) enterPipNow();
    }
    @Override public void onPictureInPictureModeChanged(boolean inPip, Configuration config) {
        super.onPictureInPictureModeChanged(inPip, config);
        if (controls != null) controls.setVisibility(inPip ? View.GONE : View.VISIBLE);
        if (playerView != null) playerView.setUseController(!inPip);
    }
    @Override protected void onDestroy() {
        if (player != null) player.removeListener(listener);
        if (playerView != null) playerView.setPlayer(null);
        if (bound) { unbindService(connection); bound = false; }
        if (receiverRegistered) { unregisterReceiver(mediaEvents); receiverRegistered = false; }
        super.onDestroy();
    }
}
