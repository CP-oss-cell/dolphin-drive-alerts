# 믿음하나튜브 v0.1.20 검증 및 제한 사항

## 버전
- app.mideumhanatube.android / versionName 0.1.20 / versionCode 21
- Android 8(API 26) 이상 / target 36 / 자동 Debug APK (고정 서명키 없음)

## 실제 소스에 구현
- PIP 고정 아이콘을 마이크 왼편에 배치. 중복 메뉴 정리, 설정 통합.
- 최초 실행 권한 안내 (알림→마이크 순차 요청), 기존 허용 항목 생략, PIP 특수 설정 링크.
- 나중에 보기와 음악 플레이리스트 분리 / 이름 지정 목록 추가·변경·삭제 / 곡 순서 이동·다중선택.
- 화면 재생 이력 및 페이지에 이미 보이는 관련 영상 링크를 대기열 후보로 사용(추천 항상 제공되는 것은 아님).
- 알림과 Android MediaSession 이전·재생·다음·반복·랜덤 명령을 공통 대기열에 연결.
- 블루투스 출력 끊김 시 자동 일시정지; 마지막 트랙·위치·대기열·반복·랜덤 저장 및 재개 시도.
- 15/30/60분 취침 타이머. 데이터 백업/복원(JSON, 사용자 직접 파일 위치 선택).
- 자동 PIP 실행 조건 미충족 시 백그라운드 오디오 전환 허용.
- 외부 광고 요청 필터 / 영상 광고 요소 발견 / 광고 건너뛰기 버튼 클릭 시도를 서로 다른 진단 항목으로 기록.

## 미완료 또는 외부 조건 의존
- GitHub 실제 Android APK 빌드 미실행: 컴파일 성공 여부 미확정.
- 실제 Galaxy 기종 및 차량에서 자동 PIP 성공 검증 없음. 홈 제스처 도중 새 Activity 생성 제한은 잔존.
- 블루투스 연결 자체를 감지해 무조건 자동 재생하지 않음; Android가 미디어 버튼을 이 앱으로 전달했을 때만 제어 또는 재개 시도.
- YouTube 추천목록·스트림은 서버 응답/페이지 구조에 따라 확보하지 못할 수 있음.
- 광고 차단 100% 불가능하며 영상 광고 감지·클릭 기록은 광고 차단 성공 증명이 아님.
- Android 13+ 시스템 알림창은 시스템이 버튼 슬롯을 결정하므로 반복/셔플이 항상 바로 표시되지는 않음.
- 백업·복원은 수동이고 사용자 계정·쿠키는 포함하지 않음.
- 영구 서명키 없이 빌드되므로 삭제 후 재설치할 수 있으며, 삭제 전에 설정→백업 저장 필요.

## 검사
- test-background.sh: PASS
- test-bookmarks-navigation.sh: PASS
- test-ci-version-consistency.sh: PASS
- test-controls-voice.sh: PASS
- test-exit-confirmation.sh: PASS
- test-filter.sh: PASS
- test-gradle-config.sh: PASS
- test-native-audio.sh: PASS
- test-playback-state.sh: PASS
- test-service-java-initializers.sh: PASS
- test-source-syntax.sh: PASS
- test-v0111-regression.sh: PASS
- test-v0112-regression.sh: PASS
- test-v0113-regression.sh: PASS
- test-v0114-receiver-context.sh: PASS
- test-v0115-home-audio.sh: PASS
- test-v0116-log-verified.sh: PASS
- test-v0117-queue-nativepip.sh: PASS
- test-v0118-regression.sh: PASS
- test-v0119-native-home-pip.sh: PASS
- test-v0120-integration.sh: PASS

Android SDK/기기 실사용/광고 성공률 검증: **수행하지 않음**. 기존 회귀 검사는 주로 소스 구조 및 순수 Java 동작 확인이며 전체 Android 컴파일을 대체하지 않습니다.
