#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
python3 - "$ROOT" "$TMP_DIR" <<'PY'
from pathlib import Path
import re,sys
root,tmp=map(Path,sys.argv[1:])
s=(root/'app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text(encoding='utf-8')
callback=re.search(r'(?ms)^\s*private\s+final\s+Runnable\s+sleepStop\s*=\s*\(\)\s*->\s*\{.*?^\s*\};',s)
assert callback, 'Sleep timer Runnable initializer missing'
fields={
 'traceSession':r'(?m)^\s*private\s+long\s+traceSession\s*;',
 'nativePlayer':r'(?m)^\s*private\s+ExoPlayer\s+nativePlayer\s*;',
 'nativeMode':r'(?m)^\s*private\s+boolean\s+nativeMode\s*;',
}
for name,rx in fields.items():
    m=re.search(rx,s)
    assert m, f'Missing referenced field: {name}'
    assert m.start()<callback.start(), f'Illegal forward reference in sleepStop: {name} declared after timer initializer'
# Compile the real sleepStop initializer extracted from the app, not a rewritten approximation.
body=callback.group().strip()
probe='''public class SleepTimerInitializerProbe {
  static class ExoPlayer {}
  static class PlaybackDiagnostics {
    static void event(Object context, long session, String stage, String reason, ExoPlayer player) {}
  }
  private static final String ACTION_PAUSE = "pause";
  private long traceSession;
  private ExoPlayer nativePlayer;
  private boolean nativeMode;
  void stopNativeAudio() {}
  void requestPlayerControl(String action) {}
''' + body + '''
}
'''
(tmp/'SleepTimerInitializerProbe.java').write_text(probe, encoding='utf-8')
PY
javac --release 17 -encoding UTF-8 -d "$TMP_DIR" "$TMP_DIR/SleepTimerInitializerProbe.java"
echo 'Sleep timer illegal-forward-reference regression: PASS'
