#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY2'
from pathlib import Path
main=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
service=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
assert 'private LinearLayout toolbarRow;' in main
assert 'toolbarRow = new LinearLayout(this)' in main
# WebView PiP is intentionally removed; only the separate native video surface remains.
assert 'private void enterPip()' not in main
assert 'configureWebAutoPip' not in main
assert '"웹 PIP"' not in main
assert 'HOME_NATIVE_PIP_REQUESTED' in main
assert 'openNativeVideo(true)' in main
assert 'DefaultHttpDataSource.Factory' in service
assert 'setDefaultRequestProperties' in service
assert 'describePlaybackFailure(error)' in service
assert 'HTTP 403' in service and 'HTTP 401' in service
assert 'noteAudioStage("독립 재생 중단", "스트림 버퍼링 중")' in service
assert 'PlaybackStatePolicy.classify' in service
assert '오디오 전환 시간 초과' in service
assert 'startForeground(NOTIFICATION_ID, notification)' in service
assert 'ACTION_NATIVE_READY' in service
assert 'wasPlayingImmediatelyBeforeLeaving()' in main
assert 'lastForegroundPauseAt' in main and 'lastConfirmedPlaybackAt' in main
assert "versionName '0.1.21'" in Path('app/build.gradle').read_text()
assert 'versionCode 22' in Path('app/build.gradle').read_text()
print('PASS: inherited v0.1.12 PiP, stream delivery & diagnostics regression assertions')
PY2
