#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/mht-v0110-voice-test
javac -encoding UTF-8 -d /tmp/mht-v0110-voice-test \
 app/src/main/java/app/mideumhanatube/android/VoicePermissionPolicy.java \
 tools/TestVoicePermissionPolicy.java
java -cp /tmp/mht-v0110-voice-test TestVoicePermissionPolicy
python3 - <<'PY'
from pathlib import Path
p=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
m=Path('app/src/main/AndroidManifest.xml').read_text()
tests = {
 'removed duplicate search row': 'searchBar' not in p and 'searchInput' not in p,
 'toolbar back long press': 'backButton.setOnLongClickListener' in p and 'showExitConfirmation(); return true' in p,
 'hardware long press key tracking': 'onKeyLongPress(int keyCode, KeyEvent event)' in p and 'event.startTracking()' in p,
 'predictive back still registered': 'registerOnBackInvokedCallback' in p,
 'setting adjacent to exit': 'v -> showSettings());\n        addAction(actions, "앱 종료"' in p and 'v -> showExitConfirmation());' in p,
 'exit tears down media service': 'stopBackgroundService();\n        finishAndRemoveTask();' in p,
 'exit prevents native handoff': 'if (!exiting && !launchingNativeVideo && backgroundAudio && wasPlayingImmediatelyBeforeLeaving()' in p,
 'YouTube web microphone request': 'onPermissionRequest(PermissionRequest request)' in p,
 'WebView audio-only grant': 'request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE})' in p,
 'microphone runtime permission callback': 'onRequestPermissionsResult' in p,
 'native speech fallback': 'RecognizerIntent.ACTION_RECOGNIZE_SPEECH' in p,
 'native speech result opens YouTube search': 'webView.loadUrl("https://m.youtube.com/results?search_query=" + Uri.encode(words))' in p,
 'settings includes mic control': '유튜브 음성 검색 마이크 사용' in p,
 'app requests android record audio': 'android.permission.RECORD_AUDIO' in m,
 'mic hardware optional for vehicles': 'android.hardware.microphone" android:required="false"' in m,
 'back button nav preserved': 'webView.goBack()' in p,
 'existing background native player preserved': 'beginNativeHandoff();' in p,
 'no wildcard permission grant': 'request.grant(request.getResources())' not in p,
}
for name, success in tests.items():
 if not success: raise AssertionError(name)
print('Toolbar, exit, back and voice structural tests:', len(tests), 'PASS')
PY
