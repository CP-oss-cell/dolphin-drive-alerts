package app.mideumhanatube.android;

import java.util.Arrays;

/** Pure-Java queue contract for native PiP/notification controls. */
public final class TestVideoQueueHandoff {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        PlaybackQueue q = new PlaybackQueue();
        PlaybackQueue.Track a = new PlaybackQueue.Track("https://youtube.com/watch?v=AAAAAAAAAAA", "A");
        PlaybackQueue.Track b = new PlaybackQueue.Track("https://youtube.com/watch?v=BBBBBBBBBBB", "B");
        PlaybackQueue.Track c = new PlaybackQueue.Track("https://youtube.com/watch?v=CCCCCCCCCCC", "C");
        q.setTracks(Arrays.asList(a,b,c),1);
        check(q.size()==3,"PiP must receive actual multi-track queue");
        check(q.current()==b,"PiP starts at selected video B");
        check(q.next(false)==c,"PiP next moves to C");
        check(q.currentIndex()==2,"snapshot index follows next");
        check(q.next(false)==null,"end of queue must not silently restart old track");
        check(q.previous()==b,"PiP previous returns to B");
        check(q.previous()==a,"PiP previous returns to A");
        check(q.previous()==null,"beginning of queue requires user feedback");
        q.setRepeatMode(PlaybackQueue.ALL);
        check(q.previous()==c,"repeat-all wraps backwards");
        check(q.next(true)==a,"repeat-all wraps at end");
        System.out.println("Video/native/PiP queue change cases PASS");
    }
}
