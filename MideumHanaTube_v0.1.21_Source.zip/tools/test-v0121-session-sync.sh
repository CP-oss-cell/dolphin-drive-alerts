#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP_DIR" \
    app/src/main/java/app/mideumhanatube/android/PlaybackQueue.java tools/TestVideoQueueHandoff.java
java -cp "$TMP_DIR" app.mideumhanatube.android.TestVideoQueueHandoff
python3 - <<'PY'
from pathlib import Path
p=Path('app/src/main/java/app/mideumhanatube/android')
s=(p/'BackgroundAudioService.java').read_text()
m=(p/'MainActivity.java').read_text()
v=(p/'VideoPlayerActivity.java').read_text()
d=(p/'PlaybackDiagnostics.java').read_text()
y=Path('.github/workflows/MideumHanaTube_v0.1.21_Source.yml').read_text()
a=Path('app/src/main/assets/cleaner.js').read_text()
assert 'versionCode 22' in Path('app/build.gradle').read_text()
assert "versionName '0.1.21'" in Path('app/build.gradle').read_text()
assert 'MideumHanaTube_v0.1.21_Source.zip' in y and 'assembleDebug' in y
start=s.split('} else if (ACTION_NATIVE_VIDEO_START.equals(action)) {',1)[1].split('} else if (ACTION_QUEUE_PLAY.equals(action))',1)[0]
assert 'playbackQueue.clear()' not in start and 'acceptQueueFromIntent(intent)' in start
assert 'boolean continueVideoSurface = nativeVideoMode;' in s
assert 'nativeVideoMode = continueVideoSurface;' in s
assert 'sendNativeSnapshot()' in s and 'ACTION_NATIVE_SNAPSHOT' in s
assert 'ACTION_NATIVE_QUERY.equals(action)' in s and 'sendNativeSnapshot();' in s
assert '.setActions(pipRemoteActions())' in v and 'ACTION_QUEUE_NEXT' in v and 'ACTION_QUEUE_PREVIOUS' in v
assert 'EXTRA_REATTACH' in v and 'setUseController(!inPip)' in v
assert 'setUseController(true)' in v
assert 'ACTION_SEEK_TO' in s and 'void onSeekTo(long pos)' in s
assert 'ACTION_SEEK_BACKWARD' in s and 'ACTION_SEEK_FORWARD' in s
assert 'METADATA_KEY_DURATION' in s
assert 'nativeSnapshotOnResumePending' in m and 'applyNativeSnapshot(intent)' in m
assert 'handleExplicitVideoReturn' in m and 'nativePendingReturnUrl' in m
assert 'requestNativeReturnPosition' in m and 'seekWebAndConfirm' in m
assert 'if (!nativeAudioActive && !nativeHandoffRequested)' in m
assert 'collectPlaybackQueue(url)' in m and 'EXTRA_QUEUE_URLS,candidates.urls' in m
assert 'quickShareDiagnostics()' in m and 'toolbarRow.addView(quickDiagnostics' in m
assert 'PlaybackDiagnostics.saveToDownloads(this)' in m
assert 'Intent.ACTION_SEND' in m and 'FLAG_GRANT_READ_URI_PERMISSION' in m
assert 'shareQuickDiagnostics()' in v and 'webview_version' in d
assert 'VIDEO_AD_NO_LONGER_VISIBLE' in m and 'AD_SKIP_ATTEMPT' in m
assert 'AD_SKIP_CLICKED", "CLICK_NOT_VERIFIED"' not in m
assert 'MHT_AD_NO_LONGER_VISIBLE_0121' in a
print('v0.1.21 sync / PiP / diagnostics / regression assertions PASS (29 groups)')
PY
node --check app/src/main/assets/cleaner.js
