package com.byd.dolphin.drivealerts.dock

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog
import java.lang.reflect.Method

/**
 * Clean-Room BYDAuto Comfort / HVAC / Seat / Mirror-Defrost / Bodywork Controller.
 * Strictly limited to passenger comfort controls (AC, temp, fan, wind mode, recirculation,
 * steering wheel heat, driver/passenger seat heat, rear+mirror defrost, windows/sunshade).
 * Never issues driving-safety or propulsion CAN/ECU writes.
 */
class BydComfortController(context: Context) {
    data class ComfortSnapshot(
        val acOn: Boolean = false,
        val acCompressorOn: Boolean = false,
        val heaterOn: Boolean = false,
        val acAuto: Boolean = false,
        val tempC: Float = 22.0f,
        val fanLevel: Int = 2,
        val windMode: Int = WIND_FACE,         // 0=FACE, 1=FACE_FOOT, 2=FOOT, 3=DEFROST_FOOT, 4=DEFROST
        val recirculation: Boolean = false,
        val steeringHeat: Boolean = false,
        val driverSeatHeat: Int = 0,           // 0=OFF, 1=LOW, 2=HIGH
        val passengerSeatHeat: Int = 0,        // 0=OFF, 1=LOW, 2=HIGH
        val rearMirrorDefrost: Boolean = false,
        val frontDefrost: Boolean = false
    )

    private val app = context.applicationContext
    @Volatile private var acDev: Any? = null
    @Volatile private var bodyDev: Any? = null
    @Volatile private var snap = ComfortSnapshot()

    private fun getAcDevice(): Any? {
        acDev?.let { return it }
        val dev = resolveDevice("android.hardware.bydauto.ac.BYDAutoAcDevice")
        acDev = dev
        return dev
    }

    private fun getBodyDevice(): Any? {
        bodyDev?.let { return it }
        val dev = resolveDevice("android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice")
        bodyDev = dev
        return dev
    }

    private fun resolveDevice(className: String): Any? = runCatching {
        val cls = Class.forName(className)
        cls.getMethod("getInstance", Context::class.java).invoke(null, app)
    }.getOrNull()

    fun refreshSnapshot(): ComfortSnapshot {
        val ac = getAcDevice()
        if (ac != null) {
            val power = callInt(ac, listOf("getAcStartState", "getAcPowerState"))
            val auto = callInt(ac, listOf("getAcControlMode"))
            val temp = callInt(ac, listOf("getTemprature", "getTemperature"), 1) // area=1 main
            val fan = callInt(ac, listOf("getAcWindLevel"))
            val mode = callInt(ac, listOf("getAcWindMode"))
            val cycle = callInt(ac, listOf("getAcCycleMode"))
            val rearDef = callInt(ac, listOf("getAcDefrostState"), 2)
            val frontDef = callInt(ac, listOf("getAcDefrostState"), 1)
            snap = snap.copy(
                acOn = if (power != null) power == 1 else snap.acOn,
                acAuto = if (auto != null) auto == 0 else snap.acAuto,
                tempC = if (temp != null && temp in 15..33) temp.toFloat() else snap.tempC,
                fanLevel = if (fan != null && fan in 0..7) fan else snap.fanLevel,
                windMode = mapBydWindToLocal(mode) ?: snap.windMode,
                recirculation = if (cycle != null) cycle == 1 else snap.recirculation,
                rearMirrorDefrost = if (rearDef != null) rearDef == 1 else snap.rearMirrorDefrost,
                frontDefrost = if (frontDef != null) frontDef == 1 else snap.frontDefrost
            )
        }
        return snap
    }

    fun snapshot(): ComfortSnapshot = snap

    fun setClimatePowerDirect(on: Boolean) {
        getAcDevice()?.let { ac ->
            if (on) callVoidOrInt(ac, listOf("start", "setAcStartState"), intArrayOf(1))
            else callVoidOrInt(ac, listOf("stop", "setAcStartState"), intArrayOf(0))
        }
        snap = snap.copy(acOn = on)
    }

    fun setAcCompressorDirect(on: Boolean) {
        val st = if (on) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), 1, st) ||
                callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), st)
        }
        snap = snap.copy(acCompressorOn = on)
    }

    fun setHeaterDirect(on: Boolean) {
        val st = if (on) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), 1, st) ||
                callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), st)
        }
        snap = snap.copy(heaterOn = on)
    }

    fun setTemperatureDirect(tempC: Float) {
        val clamped = tempC.coerceIn(17.0f, 31.0f)
        getAcDevice()?.let { ac ->
            val intTemp = clamped.toInt()
            callIntArgs(ac, listOf("setAcTemperature", "setTemprature"), 1, intTemp, 1, 1) ||
                callIntArgs(ac, listOf("setAcTemperature", "setTemprature"), 1, intTemp)
        }
        snap = snap.copy(tempC = clamped)
    }

    fun setFanLevelDirect(level: Int) {
        val clamped = level.coerceIn(0, 7)
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcWindLevel"), 1, clamped) ||
                callIntArgs(ac, listOf("setAcWindLevel"), clamped)
        }
        snap = snap.copy(fanLevel = clamped, acOn = clamped > 0)
    }

    fun setCycleModeDirect(recirc: Boolean) {
        val mode = if (recirc) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcCycleMode"), 1, mode) ||
                callIntArgs(ac, listOf("setAcCycleMode"), mode)
        }
        snap = snap.copy(recirculation = recirc)
    }

    fun setSteeringHeatDirect(on: Boolean) {
        val st = if (on) 1 else 0
        getAcDevice()?.let { ac -> callIntArgs(ac, listOf("setSteeringWheelHeatState", "setSteeringHeatState"), st) }
        getBodyDevice()?.let { bw -> callIntArgs(bw, listOf("setSteeringWheelHeatState", "setSteeringHeat"), st) }
        snap = snap.copy(steeringHeat = on)
    }

    fun setSeatHeatDirect(area: Int, level: Int) {
        setSeatHeat(area, level.coerceIn(0, 2))
        snap = if (area == 1) snap.copy(driverSeatHeat = level) else snap.copy(passengerSeatHeat = level)
    }

    fun toggleAcPower(): ComfortSnapshot {
        val next = !snap.acOn
        val ac = getAcDevice()
        if (ac != null) {
            val ok = if (next) {
                callVoidOrInt(ac, listOf("start", "setAcStartState"), intArrayOf(1))
            } else {
                callVoidOrInt(ac, listOf("stop", "setAcStartState"), intArrayOf(0))
            }
            CoreLog.i("COMFORT", "toggleAcPower next=$next ok=$ok")
        }
        snap = snap.copy(acOn = next)
        return snap
    }

    fun toggleAcCompressor(): ComfortSnapshot {
        val next = !snap.acCompressorOn
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), 1, st) ||
                callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), st)
        }
        snap = snap.copy(acCompressorOn = next, acOn = if (next) true else snap.acOn)
        return snap
    }

    fun toggleHeater(): ComfortSnapshot {
        val next = !snap.heaterOn
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), 1, st) ||
                callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), st)
        }
        snap = snap.copy(heaterOn = next, acOn = if (next) true else snap.acOn)
        return snap
    }

    fun toggleAcAuto(): ComfortSnapshot {
        val next = !snap.acAuto
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcControlMode"), 1, if (next) 0 else 1)
        }
        snap = snap.copy(acAuto = next, acOn = if (next) true else snap.acOn)
        return snap
    }

    fun adjustTemp(delta: Float): ComfortSnapshot {
        val next = (snap.tempC + delta).coerceIn(17.0f, 31.0f)
        getAcDevice()?.let { ac ->
            val intTemp = next.toInt()
            callIntArgs(ac, listOf("setAcTemperature", "setTemprature"), 1, intTemp, 1, 1) ||
                callIntArgs(ac, listOf("setAcTemperature", "setTemprature"), 1, intTemp)
        }
        snap = snap.copy(tempC = next, acOn = true)
        return snap
    }

    fun adjustFan(delta: Int): ComfortSnapshot {
        val next = (snap.fanLevel + delta).coerceIn(0, 7)
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcWindLevel"), 1, next) ||
                callIntArgs(ac, listOf("setAcWindLevel"), next)
        }
        snap = snap.copy(fanLevel = next, acOn = next > 0)
        return snap
    }

    /** Tap cycle: 정면(0) -> 정면+아래(1) -> 아래(2) -> 위+아래(3) -> 정면(0). */
    fun cycleWindModeTap(): ComfortSnapshot {
        val next = when (snap.windMode) {
            WIND_FACE -> WIND_FACE_FOOT
            WIND_FACE_FOOT -> WIND_FOOT
            WIND_FOOT -> WIND_DEFROST_FOOT
            else -> WIND_FACE
        }
        return setWindMode(next)
    }

    fun setWindMode(mode: Int): ComfortSnapshot {
        val bydVal = when (mode) {
            WIND_FACE -> 1
            WIND_FACE_FOOT -> 2
            WIND_FOOT -> 3
            WIND_DEFROST_FOOT -> 4
            WIND_DEFROST -> 5
            else -> 1
        }
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcWindMode"), 1, bydVal) ||
                callIntArgs(ac, listOf("setAcWindMode"), bydVal)
        }
        snap = snap.copy(windMode = mode, acOn = true)
        return snap
    }

    fun toggleRecirculation(): ComfortSnapshot {
        val next = !snap.recirculation
        getAcDevice()?.let { ac ->
            val mode = if (next) 1 else 0 // 1=INLOOP, 0=OUTLOOP
            callIntArgs(ac, listOf("setAcCycleMode"), 1, mode) ||
                callIntArgs(ac, listOf("setAcCycleMode"), mode)
        }
        snap = snap.copy(recirculation = next)
        return snap
    }

    fun toggleSteeringHeat(): ComfortSnapshot {
        val next = !snap.steeringHeat
        val targetVal = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setSteeringWheelHeatState", "setSteeringHeatState"), targetVal)
        }
        getBodyDevice()?.let { bw ->
            callIntArgs(bw, listOf("setSteeringWheelHeatState", "setSteeringHeat"), targetVal)
        }
        snap = snap.copy(steeringHeat = next)
        return snap
    }

    fun cycleDriverSeatHeat(): ComfortSnapshot {
        val next = (snap.driverSeatHeat + 1) % 3 // 0 -> 1 -> 2 -> 0
        setSeatHeat(area = 1, level = next)
        snap = snap.copy(driverSeatHeat = next)
        return snap
    }

    fun cyclePassengerSeatHeat(): ComfortSnapshot {
        val next = (snap.passengerSeatHeat + 1) % 3
        setSeatHeat(area = 2, level = next)
        snap = snap.copy(passengerSeatHeat = next)
        return snap
    }

    private fun setSeatHeat(area: Int, level: Int) {
        val ac = getAcDevice() ?: return
        callIntArgs(ac, listOf("setSeatHeatLevel", "setAcSeatHeatLevel"), area, level) ||
            callIntArgs(ac, listOf("setSeatHeatingLevel"), area, level)
    }

    /** Side-mirror + Rear windshield defrost toggle. */
    fun toggleRearMirrorDefrost(): ComfortSnapshot {
        val next = !snap.rearMirrorDefrost
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcDefrostState"), 1, 2, st) ||
                callIntArgs(ac, listOf("setAcDefrostState"), 2, st)
        }
        snap = snap.copy(rearMirrorDefrost = next)
        return snap
    }

    fun toggleFrontDefrost(): ComfortSnapshot {
        val next = !snap.frontDefrost
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcDefrostState"), 1, 1, st) ||
                callIntArgs(ac, listOf("setAcDefrostState"), 1, st)
        }
        snap = snap.copy(frontDefrost = next)
        return snap
    }

    /** Crack all windows slightly (~15%) for cabin ventilation. */
    fun ventilateWindows() {
        getBodyDevice()?.let { bw ->
            for (area in 1..4) {
                callIntArgs(bw, listOf("setWindowOpenPercent"), area, 15)
            }
        }
    }

    fun closeAllWindows() {
        getBodyDevice()?.let { bw ->
            for (area in 1..4) {
                callIntArgs(bw, listOf("setWindowOpenPercent"), area, 0)
            }
        }
    }

    fun toggleSunshade(open: Boolean) {
        getBodyDevice()?.let { bw ->
            callIntArgs(bw, listOf("setSunshadePosition", "setSunroofCurtainPosition"), if (open) 100 else 0)
        }
    }

    private fun mapBydWindToLocal(bydMode: Int?): Int? = when (bydMode) {
        1 -> WIND_FACE
        2 -> WIND_FACE_FOOT
        3 -> WIND_FOOT
        4 -> WIND_DEFROST_FOOT
        5 -> WIND_DEFROST
        else -> null
    }

    private fun callInt(target: Any, names: List<String>, vararg args: Int): Int? {
        val cls = target.javaClass
        val types = Array<Class<*>>(args.size) { Int::class.javaPrimitiveType!! }
        for (name in names) {
            val m: Method = runCatching { cls.getMethod(name, *types) }.getOrNull() ?: continue
            val boxed = args.map { it as Any }.toTypedArray()
            val v = runCatching { m.invoke(target, *boxed) }.getOrNull()
            if (v is Number) return v.toInt()
        }
        return null
    }

    private fun callVoidOrInt(target: Any, names: List<String>, args: IntArray): Boolean {
        val cls = target.javaClass
        for (name in names) {
            val m0 = runCatching { cls.getMethod(name) }.getOrNull()
            if (m0 != null && runCatching { m0.invoke(target); true }.getOrDefault(false)) return true
            if (args.size == 1) {
                val m1 = runCatching { cls.getMethod(name, Int::class.javaPrimitiveType) }.getOrNull()
                if (m1 != null && runCatching { m1.invoke(target, args[0]); true }.getOrDefault(false)) return true
            }
        }
        return false
    }

    private fun callIntArgs(target: Any, names: List<String>, vararg args: Int): Boolean {
        val cls = target.javaClass
        val types = Array<Class<*>>(args.size) { Int::class.javaPrimitiveType!! }
        val boxed = args.map { it as Any }.toTypedArray()
        for (name in names) {
            val m = runCatching { cls.getMethod(name, *types) }.getOrNull() ?: continue
            if (runCatching { m.invoke(target, *boxed); true }.getOrDefault(false)) return true
        }
        return false
    }

    companion object {
        const val WIND_FACE = 0
        const val WIND_FACE_FOOT = 1
        const val WIND_FOOT = 2
        const val WIND_DEFROST_FOOT = 3
        const val WIND_DEFROST = 4

        fun windLabel(mode: Int): String = when (mode) {
            WIND_FACE -> "정면"
            WIND_FACE_FOOT -> "정면+아래"
            WIND_FOOT -> "아래"
            WIND_DEFROST_FOOT -> "위+아래"
            WIND_DEFROST -> "위(앞유리)"
            else -> "정면"
        }
    }
}
