package com.byd.dolphin.drivealerts.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.camera.BsdCameraOverlayController
import com.byd.dolphin.drivealerts.camera.BsdCameraPreferences
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.model.Side

/** Hyundai/Kia BVM-Style Blind-Spot Camera Settings, Calibration & Live Preview. */
class BsdCameraSettingsActivity : DensityAwareActivity() {
    private var controller: BsdCameraOverlayController? = null
    private lateinit var probeView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controller = BsdCameraOverlayController(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@BsdCameraSettingsActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@BsdCameraSettingsActivity, 18), DashboardUi.dp(this@BsdCameraSettingsActivity, 14),
                DashboardUi.dp(this@BsdCameraSettingsActivity, 18), DashboardUi.dp(this@BsdCameraSettingsActivity, 24))
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "깜박이 후측방 카메라 (BVM)", "현대·기아 스타일 시야각 · 반전 · 밝기/대비/채도 보정")

        val accent = DashboardUi.accentColor(this)

        // 1. Master Toggle + Permissions + One-tap Hyundai/Kia BVM Preset
        val mainPanel = DashboardUi.panel(
            this,
            "방향지시등 연동 후측방 카메라",
            "좌/우 깜박이 작동 시 플로팅 카메라 창을 표시하고, 후진(R) 진입 시 순정 카메라에 즉시 양보합니다.",
            DashboardIcons.IconKind.RADAR_BSD,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "깜박이 사용 시 후측방 카메라 자동 표시", BsdCameraPreferences.enabled(this)) {
                BsdCameraPreferences.setEnabled(this, it)
            })
            p.addView(
                DashboardUi.action(this, "카메라 ID 자동 감지 · 전방/좌/우/후방 · 원터치 자동 보정", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
                    val msg = controller?.autoDetectAndCalibrate() ?: "자동 감지 실패"
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    recreate()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this@BsdCameraSettingsActivity, 48)).apply { setMargins(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 6), 0, DashboardUi.dp(this@BsdCameraSettingsActivity, 6)) }
            )
            val permRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            permRow.addView(
                DashboardUi.action(this, "카메라 권한 요청", DashboardIcons.IconKind.KEY_PERM, accent) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "카메라 권한이 이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show()
                    } else requestPermissions(arrayOf(Manifest.permission.CAMERA), 9101)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 48), 1f).apply { setMargins(0, 0, DashboardUi.dp(this@BsdCameraSettingsActivity, 4), 0) }
            )
            permRow.addView(
                DashboardUi.action(this, "화면 위 표시 권한", DashboardIcons.IconKind.SHIELD_ADB, accent) {
                    SafeSettingsLauncher.open(this, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 48), 1f).apply { setMargins(DashboardUi.dp(this@BsdCameraSettingsActivity, 4), 0, 0, 0) }
            )
            p.addView(permRow)
        }
        mainPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, mainPanel)

        // 2. Geometry & Color Calibration (Mirror, Flip, Zoom, Pan X/Y, Brightness, Contrast, Saturation)
        val calPanel = DashboardUi.panel(
            this,
            "시야각 · 반전 · 밝기 · 대비 · 채도 정밀 보정",
            "사이드미러처럼 자연스러운 좌우 반전과 사각지대 시야각·색감을 실시간 보정합니다.",
            DashboardIcons.IconKind.SPLIT_DISPLAY,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "좌/우 반전 (사이드미러 미러링 · 권장)", BsdCameraPreferences.mirrorHorizontal(this)) {
                BsdCameraPreferences.setMirrorHorizontal(this, it)
            })
            p.addView(DashboardUi.toggle(this, "상/하 반전 (카메라 장착 방향 보정)", BsdCameraPreferences.flipVertical(this)) {
                BsdCameraPreferences.setFlipVertical(this, it)
            })

            fun addSlider(label: String, minVal: Int, maxVal: Int, currentVal: Int, suffix: String, onSave: (Int) -> Unit) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val tv = DashboardUi.label(this, "$label: $currentVal$suffix", 13f, true)
                row.addView(tv, LinearLayout.LayoutParams(DashboardUi.dp(this@BsdCameraSettingsActivity, 160), -2))
                row.addView(SeekBar(this).apply {
                    max = maxVal - minVal
                    progress = (currentVal - minVal).coerceIn(0, maxVal - minVal)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                            if (fromUser) {
                                val v = minVal + prog
                                tv.text = "$label: $v$suffix"
                                onSave(v)
                            }
                        }
                        override fun onStartTrackingTouch(sb: SeekBar?) {}
                        override fun onStopTrackingTouch(sb: SeekBar?) {}
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                p.addView(row)
            }

            addSlider("시야각 확대(줌)", 100, 220, BsdCameraPreferences.zoomPercent(this), "%") { BsdCameraPreferences.setZoomPercent(this, it) }
            addSlider("좌/우 각도 이동", -40, 40, BsdCameraPreferences.panX(this), "%") { BsdCameraPreferences.setPanX(this, it) }
            addSlider("상/하 각도 이동", -40, 40, BsdCameraPreferences.panY(this), "%") { BsdCameraPreferences.setPanY(this, it) }
            addSlider("밝기 (노출 보정)", -50, 50, BsdCameraPreferences.brightness(this), "") { BsdCameraPreferences.setBrightness(this, it) }
            addSlider("대비 (Contrast)", 50, 180, BsdCameraPreferences.contrastPercent(this), "%") { BsdCameraPreferences.setContrastPercent(this, it) }
            addSlider("채도 (Saturation)", 0, 200, BsdCameraPreferences.saturationPercent(this), "%") { BsdCameraPreferences.setSaturationPercent(this, it) }
        }
        calPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, calPanel)

        // 3. Camera ID, Crop Mode, Size & Speed Filter
        val configPanel = DashboardUi.panel(
            this,
            "카메라 ID · 크롭 · 창 크기 · 작동 속도 조건",
            "차량 Camera2 장치 목록을 확인한 뒤 알맞은 ID와 크롭 방식을 선택하세요.",
            DashboardIcons.IconKind.GAUGE,
            accent
        ) { p ->
            probeView = DashboardUi.label(this, controller?.probeCameras() ?: "탐색 실패", 12.5f)
            p.addView(probeView)

            p.addView(DashboardUi.label(this, "좌측 카메라 ID / 우측 카메라 ID", 13f))
            val idRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val leftInput = EditText(this).apply { setText(BsdCameraPreferences.leftCameraId(this@BsdCameraSettingsActivity)); hint = "좌측 ID (0)" }
            val rightInput = EditText(this).apply { setText(BsdCameraPreferences.rightCameraId(this@BsdCameraSettingsActivity)); hint = "우측 ID (0)" }
            idRow.addView(leftInput, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, DashboardUi.dp(this@BsdCameraSettingsActivity, 6), 0) })
            idRow.addView(rightInput, LinearLayout.LayoutParams(0, -2, 1f))
            p.addView(idRow)

            p.addView(DashboardUi.label(this, "영상 크롭 방식", 13f))
            val cropSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@BsdCameraSettingsActivity, BsdCameraPreferences.cropLabels)
                setSelection(BsdCameraPreferences.cropMode(this@BsdCameraSettingsActivity))
            }
            p.addView(cropSpinner)

            p.addView(DashboardUi.label(this, "오버레이 창 크기", 13f))
            val sizeSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@BsdCameraSettingsActivity, BsdCameraPreferences.sizeLabels)
                setSelection(BsdCameraPreferences.sizeTier(this@BsdCameraSettingsActivity))
            }
            p.addView(sizeSpinner)

            p.addView(DashboardUi.label(this, "작동 속도 조건", 13f))
            val speedSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@BsdCameraSettingsActivity, BsdCameraPreferences.speedLabels)
                setSelection(BsdCameraPreferences.speedFilterMode(this@BsdCameraSettingsActivity))
            }
            p.addView(speedSpinner)

            p.addView(
                DashboardUi.action(this, "카메라 기본 설정 저장", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
                    BsdCameraPreferences.setLeftCameraId(this, leftInput.text.toString())
                    BsdCameraPreferences.setRightCameraId(this, rightInput.text.toString())
                    BsdCameraPreferences.setCropMode(this, cropSpinner.selectedItemPosition)
                    BsdCameraPreferences.setSizeTier(this, sizeSpinner.selectedItemPosition)
                    BsdCameraPreferences.setSpeedFilterMode(this, speedSpinner.selectedItemPosition)
                    Toast.makeText(this, "후측방 카메라 설정 저장 완료", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this@BsdCameraSettingsActivity, 48)).apply { setMargins(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 8), 0, 0) }
            )
        }
        configPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, configPanel)

        // 4. Live 5s Preview Test
        val previewPanel = DashboardUi.panel(
            this,
            "보정 결과 실시간 미리보기 (5초)",
            "설정한 시야각·반전·밝기/대비/채도가 적용된 오버레이를 즉시 확인합니다.",
            DashboardIcons.IconKind.PLAY,
            DashboardUi.okColor(this)
        ) { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(
                DashboardUi.action(this, "◀ 좌측 5초 미리보기", DashboardIcons.IconKind.PLAY, accent) { controller?.startPreview(Side.LEFT, 5_000L) },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 48), 1f).apply { setMargins(0, 0, DashboardUi.dp(this@BsdCameraSettingsActivity, 4), 0) }
            )
            row.addView(
                DashboardUi.action(this, "우측 5초 미리보기 ▶", DashboardIcons.IconKind.PLAY, accent) { controller?.startPreview(Side.RIGHT, 5_000L) },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 48), 1f).apply { setMargins(DashboardUi.dp(this@BsdCameraSettingsActivity, 4), 0, 0, 0) }
            )
            p.addView(row)
            p.addView(
                DashboardUi.action(this, "오버레이 즉시 닫기", DashboardIcons.IconKind.STOP, DashboardUi.dangerColor(this)) {
                    controller?.hide("manual_button")
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this@BsdCameraSettingsActivity, 48)).apply { setMargins(0, DashboardUi.dp(this@BsdCameraSettingsActivity, 6), 0, 0) }
            )
        }
        previewPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, previewPanel)
    }

    override fun onDestroy() {
        runCatching { controller?.shutdown() }
        controller = null
        super.onDestroy()
    }
}
