package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.config.AlertVolume
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter
import com.byd.dolphin.drivealerts.dpi.OrientationMode
import com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper
import com.byd.dolphin.drivealerts.dpi.RotationPolicy
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.dpi.TemporaryAppDpiController
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal
import com.byd.dolphin.drivealerts.log.BydFeatureIdScanner
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

/**
 * v0.17.53 BYD Dolphin 10.1" (1280x720) Automotive Cockpit Dashboard.
 * 6 deduplicated functional categories, custom vector icons, Dark/Light theme toggle,
 * live status strip, segmented audio controls, and unified rotation/navigation management.
 */
class MainActivity : DensityAwareActivity() {
    private data class CategorySpec(
        val id: Int,
        val title: String,
        val summary: String,
        val icon: DashboardIcons.IconKind,
        val accentDark: Int,
        val accentLight: Int
    )

    private val categories = listOf(
        CategorySpec(1, "주행 알림", "23종 음성 · 출력 · 볼륨 · 주행모드 · BSD", DashboardIcons.IconKind.CAR_ALERT, 0xFF38D9E6.toInt(), 0xFF00869B.toInt()),
        CategorySpec(2, "시동 · 자동 실행", "시동 감지 · 등록 앱 순서 · 미디어 · OFF 종료", DashboardIcons.IconKind.POWER_LAUNCH, 0xFF2EE59D.toInt(), 0xFF0D9F6E.toInt()),
        CategorySpec(3, "화면 · 분할 · 독바", "순정 바 숨김 · 하단 독바 · 2앱 분할 · 가로 고정", DashboardIcons.IconKind.SPLIT_DISPLAY, 0xFF5B9BFF.toInt(), 0xFF2563EB.toInt()),
        CategorySpec(4, "오디오 · 이퀄라이저", "10밴드 정밀 EQ · 볼륨 보상 · 입체 음장 · 밸런스", DashboardIcons.IconKind.AUDIO_NAV, 0xFFA78BFA.toInt(), 0xFF7C3AED.toInt()),
        CategorySpec(5, "권한 · ADB · 백업", "차량 로컬 ADB 연결 · 앱 권한 · 일괄 검증", DashboardIcons.IconKind.SHIELD_ADB, 0xFFFFB84D.toInt(), 0xFFC97A00.toInt()),
        CategorySpec(6, "진단 · 로그", "통합 로그 상태 · 시동 구조 · 자동 점검 · BYD 스캔", DashboardIcons.IconKind.DIAG_LOG, 0xFFFF7A7A.toInt(), 0xFFD93838.toInt()),
        CategorySpec(7, "블랙박스 · 센트리 · 카메라", "주행 녹화 · 영상 뷰어 · 센트리 · BVM · 앞차 AI · 텔레그램", DashboardIcons.IconKind.RECORD_DOT, 0xFFFF5A5F.toInt(), 0xFFD93838.toInt())
    )

    private lateinit var rootShell: LinearLayout
    private lateinit var headerSlot: FrameLayout
    private lateinit var scroller: ScrollView
    private lateinit var screen: LinearLayout
    private lateinit var unifiedCaptureStatus: TextView
    private var homeCapturePill: TextView? = null
    private val statusValueViews = mutableMapOf<String, TextView>()
    private val statusDotViews = mutableMapOf<String, View>()
    private var adbCheckGeneration = 0
    private var currentCategoryId = 0
    private var detailVisible = false
    private var dashboardBack: (() -> Unit)? = { goHome() }
    private var previewPlayer: AlertAudioPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        previewPlayer = AlertAudioPlayer(applicationContext)
        setContentView(buildShell())
        showHome()

        TemporaryAppDpiController.recoverOnStartup(this)
        if (AdbSetupActivity.shouldShowFirstRun(this)) {
            AdbSetupActivity.markFirstRunShown(this)
            AlertDialog.Builder(this).setTitle("최초 실행 · ADB 권한")
                .setMessage("분할 화면과 시동 자동 실행에는 로컬 ADB 승인이 필요할 수 있습니다. 먼저 연결을 확인하시겠습니까?")
                .setPositiveButton("ADB 연결") { _, _ -> open(AdbSetupActivity::class.java) }
                .setNegativeButton("나중에", null).show()
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure { Toast.makeText(this, "주행 알림 서비스 시작 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        runCatching { previewPlayer?.shutdown() }
        previewPlayer = null
        super.onDestroy()
    }

    private fun appVersionName(): String = runCatching {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(packageName, 0).versionName
    }.getOrNull()?.takeIf { it.isNotBlank() } ?: "0.17.81"

    private fun appVersionCode(): Int = runCatching {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(packageName, 0).longVersionCode.toInt()
    }.getOrDefault(105)

    private fun accentFor(spec: CategorySpec): Int =
        if (DashboardUi.isLightMode(this)) spec.accentLight else spec.accentDark

    private fun open(type: Class<out android.app.Activity>) {
        runCatching { startActivity(Intent(this, type)) }
            .onFailure { Toast.makeText(this, "화면 열기 오류: ${it.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
    }

    private fun dp(v: Int) = DashboardUi.dp(this@MainActivity, v)

    private fun buildShell(): View {
        DashboardUi.applyWindowChrome(this)
        rootShell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(DashboardUi.bgColor(this@MainActivity))
        }
        headerSlot = FrameLayout(this)
        rootShell.addView(headerSlot, LinearLayout.LayoutParams(-1, -2))
        rootShell.addView(
            View(this).apply { setBackgroundColor(DashboardUi.borderColor(this@MainActivity)) },
            LinearLayout.LayoutParams(-1, dp(1).coerceAtLeast(1))
        )
        scroller = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(DashboardUi.bgColor(this@MainActivity))
        }
        screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(22))
        }
        scroller.addView(screen)
        rootShell.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        return rootShell
    }

    private fun rerenderCurrentScreen() {
        DashboardUi.applyWindowChrome(this)
        rootShell.setBackgroundColor(DashboardUi.bgColor(this))
        scroller.setBackgroundColor(DashboardUi.bgColor(this))
        if (currentCategoryId == 0) showHome() else showCategory(currentCategoryId)
    }

    private fun setHeader(
        title: String,
        subtitle: String,
        icon: DashboardIcons.IconKind,
        accent: Int,
        onBack: (() -> Unit)?
    ) {
        headerSlot.removeAllViews()
        headerSlot.addView(
            DashboardUi.headerBar(
                this, title, subtitle, icon, accent,
                onBack = onBack,
                onThemeToggled = { rerenderCurrentScreen() }
            )
        )
    }

    private fun addPanel(
        title: String,
        caption: String = "",
        icon: DashboardIcons.IconKind? = null,
        accent: Int = DashboardUi.accentColor(this),
        make: (LinearLayout) -> Unit
    ) {
        DashboardUi.addPanel(screen, this, DashboardUi.panel(this, title, caption, icon, accent, make))
    }

    private fun button(
        parent: LinearLayout,
        text: String,
        icon: DashboardIcons.IconKind? = null,
        tint: Int = DashboardUi.accentColor(this),
        onClick: () -> Unit
    ) {
        parent.addView(
            DashboardUi.action(this, text, icon, tint, onClick),
            LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(0, dp(4), 0, dp(4)) }
        )
    }

    private fun actionRow(
        parent: LinearLayout,
        title: String,
        subtitle: String,
        icon: DashboardIcons.IconKind,
        accent: Int = DashboardUi.accentColor(this),
        badge: String = "",
        onClick: () -> Unit
    ) {
        parent.addView(
            DashboardUi.actionRow(this, title, subtitle, icon, accent, badge, onClick),
            LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }
        )
    }

    private fun toggle(parent: LinearLayout, text: String, on: Boolean, save: (Boolean) -> Unit) {
        parent.addView(
            DashboardUi.toggle(this, text, on, save).apply {
                background = DashboardUi.cardBg(this@MainActivity, DashboardUi.surfaceAltColor(this@MainActivity), DashboardUi.borderColor(this@MainActivity), 11)
            },
            LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }
        )
    }

    private fun hint(parent: LinearLayout, text: String) {
        parent.addView(DashboardUi.label(this, text, 12.5f))
    }

    private fun goHome() {
        currentCategoryId = 0
        detailVisible = false
        showHome()
    }

    private fun resetScreen() {
        screen.removeAllViews()
        statusValueViews.clear()
        statusDotViews.clear()
        homeCapturePill = null
        ++adbCheckGeneration
    }

    private fun showHome() {
        resetScreen()
        currentCategoryId = 0
        detailVisible = false
        setHeader(
            "DOLPHIN DRIVE",
            "주행보조 통합 콕핏  ·  v${appVersionName()}",
            DashboardIcons.IconKind.CAR_ALERT,
            DashboardUi.accentColor(this),
            onBack = null
        )

        // 0. Post-Update BYD Background-Block Reset Reminder Banner (shown once per versionCode)
        val currentCode = appVersionCode()
        if (AlertPreferences.lastSeenVersionCode(this) != currentCode) {
            addPanel(
                "업데이트 후 필수 확인 · BYD 자동 실행 허용",
                "BYD 헤드유닛은 앱 업데이트 시 '백그라운드 앱 차단' 스위치가 초기화될 수 있습니다.",
                DashboardIcons.IconKind.POWER_LAUNCH,
                DashboardUi.warnColor(this)
            ) { p ->
                hint(p, "차량 설정 → 앱 자동 실행(백그라운드 앱 차단)에서 '주행 보조 알림' 차단을 해제해야 시동 자동 실행이 정상 작동합니다.")
                button(p, "확인 완료 · 이 안내 닫기", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
                    AlertPreferences.setLastSeenVersionCode(this, currentCode)
                    showHome()
                }
            }
        }

        // 0b. BYD Secondary User (e.g. user 999) Duplicate-Install Diagnostic Banner
        val userId = android.os.Process.myUserHandle().hashCode()
        if (userId != 0) {
            addPanel(
                "주의 · 보조 사용자(user $userId) 실행 감지",
                "BYD 헤드유닛의 보조 유저(예: 999)에 설치되면 시동 자동 실행이 꼬일 수 있습니다.",
                DashboardIcons.IconKind.SHIELD_ADB,
                DashboardUi.dangerColor(this)
            ) { p ->
                hint(p, "메인 사용자(user 0)에만 설치되도록 adb install -r --user 0 설치를 권장합니다.")
            }
        }

        // 1. Live Telemetry Status Strip (6 compact visual indicators)
        addPanel(
            "실시간 시스템 상태",
            "상태 표시는 기능별 실차 검증 완료 여부를 뜻하지 않습니다.",
            DashboardIcons.IconKind.GAUGE,
            DashboardUi.accentColor(this)
        ) { panel ->
            val keys = listOf(
                Triple("서비스", DashboardIcons.IconKind.CAR_ALERT, "확인 중"),
                Triple("자동실행", DashboardIcons.IconKind.POWER_LAUNCH, "확인 중"),
                Triple("ADB", DashboardIcons.IconKind.USB_TERMINAL, "확인 중"),
                Triple("로그", DashboardIcons.IconKind.DIAG_LOG, "대기"),
                Triple("회전", DashboardIcons.IconKind.ROTATE, "확인 중"),
                Triple("출력", DashboardIcons.IconKind.SPEAKER, "확인 중")
            )
            val cols = if (resources.configuration.screenWidthDp >= 720) 3 else 2
            keys.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { (key, icon, initial) ->
                    val chip = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        background = DashboardUi.cardBg(
                            this@MainActivity,
                            DashboardUi.surfaceAltColor(this@MainActivity),
                            DashboardUi.borderColor(this@MainActivity),
                            12
                        )
                        setPadding(dp(10), dp(8), dp(10), dp(8))
                    }
                    val dot = View(this).apply {
                        background = DashboardUi.cardBg(this@MainActivity, DashboardUi.mutedColor(this@MainActivity), 0, 99)
                    }
                    statusDotViews[key] = dot
                    chip.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { setMargins(0, 0, dp(8), 0) })
                    chip.addView(ImageView(this).apply {
                        setImageDrawable(DashboardIcons.drawable(this@MainActivity, icon, DashboardUi.mutedColor(this@MainActivity), 17, 2.0f))
                    }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { setMargins(0, 0, dp(8), 0) })
                    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    col.addView(TextView(this).apply {
                        text = key; textSize = 11f; setTextColor(DashboardUi.mutedColor(this@MainActivity))
                    })
                    val valTv = TextView(this).apply {
                        text = initial; textSize = 13f; setTypeface(typeface, Typeface.BOLD)
                        setTextColor(DashboardUi.textColor(this@MainActivity))
                        maxLines = 1
                    }
                    statusValueViews[key] = valTv
                    col.addView(valTv)
                    chip.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(chip, LinearLayout.LayoutParams(0, dp(54), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                }
                repeat(cols - rowItems.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
                panel.addView(row)
            }
        }

        // 2. One-Tap Diagnostic Quick Control Bar
        addPanel(
            "원터치 진단 제어",
            "실차 로그 수집 시작·종료·ZIP 공유를 한 번에 실행합니다.",
            DashboardIcons.IconKind.RECORD_DOT,
            DashboardUi.dangerColor(this)
        ) { p ->
            val pill = DashboardUi.pill(this, "로그 대기", DashboardUi.mutedColor(this))
            homeCapturePill = pill
            p.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 0, dp(8)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val actions = listOf(
                Triple("수집 시작", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this) to { performCapture(true) }),
                Triple("수집 종료", DashboardIcons.IconKind.STOP, DashboardUi.dangerColor(this) to { performCapture(false) }),
                Triple("ZIP 공유", DashboardIcons.IconKind.SHARE, DashboardUi.accentColor(this) to { shareLatestLogZip() })
            )
            actions.forEach { (label, icon, pair) ->
                val (tint, act) = pair
                row.addView(
                    DashboardUi.action(this, label, icon, tint, act),
                    LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
                )
            }
            p.addView(row)
        }

        // 3. 6 Symmetric Functional Cockpit Category Cards (3x2 on 10.1" 1280x720)
        val sectionHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(6), dp(2), dp(8))
        }
        sectionHeader.addView(TextView(this).apply {
            text = "기능별 설정 메뉴"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(DashboardUi.textColor(this@MainActivity))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        sectionHeader.addView(DashboardUi.pill(this, "6개 영역 · 중복 제거", DashboardUi.accentColor(this)))
        screen.addView(sectionHeader)

        val columns = when {
            resources.configuration.screenWidthDp >= 820 -> 3
            resources.configuration.screenWidthDp >= 500 -> 2
            else -> 1
        }
        categories.chunked(columns).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { spec ->
                val accent = accentFor(spec)
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    isClickable = true
                    isFocusable = true
                    background = DashboardUi.interactiveBg(
                        this@MainActivity,
                        DashboardUi.surfaceColor(this@MainActivity),
                        DashboardUi.borderColor(this@MainActivity),
                        16
                    )
                    setPadding(dp(15), dp(14), dp(15), dp(14))
                    setOnClickListener { showCategory(spec.id) }
                }
                val topRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                topRow.addView(
                    DashboardIcons.badge(
                        this, spec.icon, accent,
                        DashboardUi.alphaColor(accent, if (DashboardUi.isLightMode(this)) 26 else 36),
                        DashboardUi.alphaColor(accent, 90),
                        boxDp = 44, iconDp = 23, radiusDp = 12
                    )
                )
                topRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                topRow.addView(DashboardUi.pill(this, categoryBadgeText(spec.id), accent))
                card.addView(topRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) })

                card.addView(TextView(this).apply {
                    text = spec.title
                    textSize = 17f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(DashboardUi.textColor(this@MainActivity))
                })
                card.addView(TextView(this).apply {
                    text = spec.summary
                    textSize = 12.5f
                    setTextColor(DashboardUi.mutedColor(this@MainActivity))
                    maxLines = 2
                    setPadding(0, dp(3), 0, dp(8))
                })
                val footer = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                footer.addView(TextView(this).apply {
                    text = "상세 설정 열기"
                    textSize = 12.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(accent)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                footer.addView(ImageView(this).apply {
                    setImageDrawable(DashboardIcons.drawable(this@MainActivity, DashboardIcons.IconKind.CHEVRON_RIGHT, accent, 16, 2.2f))
                }, LinearLayout.LayoutParams(dp(16), dp(16)))
                card.addView(footer)

                row.addView(card, LinearLayout.LayoutParams(0, dp(156), 1f).apply {
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            repeat(columns - group.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            screen.addView(row)
        }

        hint(screen, "차량 안전 필수 표시와 순정 경고는 변경하지 않습니다. 일부 OEM 기능은 아직 실차 검증되지 않았습니다.")
        refreshDashboardStatus()
        scroller.post { scroller.scrollTo(0, 0) }
    }

    private fun categoryBadgeText(id: Int): String = when (id) {
        1 -> if (AlertPreferences.isEnabled(this)) "알림 ON" else "알림 OFF"
        2 -> if (FeatureProfiles.sequenceEnabled(this)) "시퀀스 ON" else "대기"
        3 -> if (com.byd.dolphin.drivealerts.dock.DockPreferences.enabled(this)) "독바 ON" else if (RotationPolicy.enabled(this)) "가로 고정" else "표준"
        4 -> if (com.byd.dolphin.drivealerts.audio.EqPreferences.read(this).enabled) "EQ ON" else "표준"
        5 -> "ADB · 권한"
        7 -> when {
            com.byd.dolphin.drivealerts.camera.DashcamPreferences.enabled(this) && com.byd.dolphin.drivealerts.sentry.SentryPreferences.enabled(this) -> "녹화+센트리"
            com.byd.dolphin.drivealerts.camera.DashcamPreferences.enabled(this) -> "녹화 ON"
            com.byd.dolphin.drivealerts.sentry.SentryPreferences.enabled(this) -> "센트리 ON"
            else -> "대기"
        }
        else -> when (UnifiedLogCapture.state(this).status) {
            UnifiedLogCapture.RECORDING -> "수집 중"
            UnifiedLogCapture.SAVING -> "저장 중"
            UnifiedLogCapture.FAILED -> "재저장 필요"
            else -> "대기"
        }
    }

    private fun showCategory(id: Int) {
        resetScreen()
        currentCategoryId = id
        detailVisible = true
        val spec = categories.firstOrNull { it.id == id } ?: categories.first()
        val accent = accentFor(spec)
        setHeader(spec.title, spec.summary, spec.icon, accent, onBack = { goHome() })
        when (id) {
            1 -> drivingCards(accent)
            2 -> autostartCards(accent)
            3 -> displayCards(accent)
            4 -> audioCards(accent)
            5 -> permissionAdbCards(accent)
            6 -> diagnosticsLogCards(accent)
            7 -> dashcamCameraCards(accent)
        }
        scroller.post { scroller.scrollTo(0, 0) }
    }

    private fun drivingCards(accent: Int) {
        val activeCount = AlertEventCatalog.entries.count { AlertPreferences.eventEnabled(this, it.event) }
        addPanel("주행 보조 음성 알림", "기어 · 회생제동 · 오토홀드 · 주행모드 · BSD 등 23종 기능 유지", DashboardIcons.IconKind.CAR_ALERT, accent) { p ->
            toggle(p, "주행보조 음성 알림 전체 ON/OFF", AlertPreferences.isEnabled(this)) { AlertPreferences.setEnabled(this, it) }
            actionRow(
                p, "23종 알림 개별 설정 및 음성 테스트",
                "항목별 ON/OFF와 개별 미리듣기 지원",
                DashboardIcons.IconKind.CHECKLIST, accent, "$activeCount/23 활성"
            ) { open(AlertEventSettingsActivity::class.java) }
        }

        addPanel("음성 출력 · 스타일 · 볼륨", "차량 미디어와 순정 안전 경고 음량은 임의로 변경하지 않습니다.", DashboardIcons.IconKind.SPEAKER, accent) { p ->
            hint(p, "출력 경로")
            val routeOptions = listOf("운전석" to OutputRoute.DRIVER_STREAM14, "운전석(raw)" to OutputRoute.DRIVER_RAW14, "미디어" to OutputRoute.MEDIA)
            val currentRouteIdx = routeOptions.indexOfFirst { it.second == AlertPreferences.route(this) }.coerceAtLeast(0)
            p.addView(DashboardUi.segmentedBar(this, routeOptions.map { it.first }, currentRouteIdx, accent) { idx ->
                AlertPreferences.setRoute(this, routeOptions[idx].second)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(8)) })

            hint(p, "음성 스타일")
            val styleOptions = listOf("여성" to AlertStyle.FEMALE, "남성" to AlertStyle.MALE, "효과음" to AlertStyle.EFFECT)
            val currentStyleIdx = styleOptions.indexOfFirst { it.second == AlertPreferences.style(this) }.coerceAtLeast(0)
            p.addView(DashboardUi.segmentedBar(this, styleOptions.map { it.first }, currentStyleIdx, accent) { idx ->
                AlertPreferences.setStyle(this, styleOptions[idx].second)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(8)) })

            hint(p, "주행 알림 소리 크기 (보통도 기존 기준보다 과도하게 증폭하지 않습니다)")
            p.addView(DashboardUi.segmentedBar(this, AlertVolume.labels.toList(), AlertVolume.tier(this), accent) { idx ->
                AlertVolume.setTier(this, idx)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(10)) })

            toggle(p, "음성 출력 시 기존 미디어 자동 볼륨 낮춤 (덕킹)", AlertPreferences.mediaDuckingEnabled(this)) {
                AlertPreferences.setMediaDuckingEnabled(this, it)
            }
            button(p, "현재 설정으로 음성 테스트 재생", DashboardIcons.IconKind.PLAY, accent) {
                runCatching { previewPlayer?.play(AlertRequest(AlertEvent.GEAR_D)) }
                    .onFailure { Toast.makeText(this, "음성 테스트 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
            }
        }

        addPanel("주행모드 (ECO · NORMAL · SPORT)", "NORMAL은 독립 확정 신호 미발견 · 기존 실험 옵션 유지", DashboardIcons.IconKind.GAUGE, accent) { p ->
            toggle(p, "노멀 전환 후보 알림", AlertPreferences.normalNoticeCandidateEnabled(this)) {
                AlertPreferences.setNormalNoticeCandidateEnabled(this, it)
            }
            actionRow(
                p, "에코 · 노멀 · 스포츠 원시 신호 확인",
                "주차 상태에서 모드별 원본 신호 기록 및 판별 확인",
                DashboardIcons.IconKind.GAUGE, accent, "고급"
            ) { open(DriveModeCalibrationActivity::class.java) }
        }

        addPanel("BSD 후측방 감지", "좌우 위험 방향은 아직 실차 확정되지 않았습니다.", DashboardIcons.IconKind.RADAR_BSD, accent) { p ->
            toggle(p, "BSD 감지 + 방향지시등 연동 알림", AlertPreferences.bsdBlinkerEnabled(this)) { AlertPreferences.setBsdBlinkerEnabled(this, it) }
            toggle(p, "BSD 감지 즉시 알림", AlertPreferences.bsdInstantEnabled(this)) { AlertPreferences.setBsdInstantEnabled(this, it) }
            toggle(p, "후측방 좌/우 구분 (후방 센서 · 사이드 카메라)", com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.enabled(this)) {
                com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.setEnabled(this, it)
            }
            hint(p, "좌/우 판별 방식 (근거 부족 시 기존 '후측방 조심'으로 안전 출력)")
            val bsdModeSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@MainActivity, com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.modeLabels)
                setSelection(com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.mode(this@MainActivity))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.setMode(this@MainActivity, pos)
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            p.addView(bsdModeSpinner, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })
            val bsdLayoutSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@MainActivity, com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.layoutLabels)
                setSelection(com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.layout(this@MainActivity))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences.setLayout(this@MainActivity, pos)
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            p.addView(bsdLayoutSpinner, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) })
            val bsdTestRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            bsdTestRow.addView(
                DashboardUi.action(this, "◀ 왼쪽 후측방 테스트", DashboardIcons.IconKind.PLAY, accent) {
                    runCatching { previewPlayer?.play(AlertRequest(AlertEvent.BSD_WARNING, Side.LEFT)) }
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(2), dp(4), dp(2)) }
            )
            bsdTestRow.addView(
                DashboardUi.action(this, "오른쪽 후측방 테스트 ▶", DashboardIcons.IconKind.PLAY, accent) {
                    runCatching { previewPlayer?.play(AlertRequest(AlertEvent.BSD_WARNING, Side.RIGHT)) }
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(2), 0, dp(2)) }
            )
            p.addView(bsdTestRow)
        }

        addPanel("앞차 출발 감지 (자율주행 ICC · 일반 주행)", "D 기어 정차 시 전방 카메라·센서 융합 감시 · 주행/후진 시 카메라 자동 반납", DashboardIcons.IconKind.CAR_ALERT, accent) { p ->
            actionRow(
                p, "앞차 출발 융합 감지 설정",
                "융합 / 카메라 전용 / 센서 전용 / 교차 확인 · 민감도 · 음성 테스트",
                DashboardIcons.IconKind.CAR_ALERT, accent,
                if (com.byd.dolphin.drivealerts.camera.LeadCarDeparturePreferences.enabled(this)) "ON" else "OFF"
            ) { open(LeadCarDepartureActivity::class.java) }
        }

        addPanel("핸들 버튼 연타 · 지정 앱 빠른 실행", "핸들 버튼 연타 시 선택한 앱 또는 분할 프로필을 즉시 실행합니다.", DashboardIcons.IconKind.STEERING, accent) { p ->
            toggle(p, "핸들 버튼 연타로 지정 앱 실행 사용", SteeringTriggerPreferences.enabled(this)) { SteeringTriggerPreferences.setEnabled(this, it) }
            val currentTargetTv = DashboardUi.label(this, "현재 지정: ${SteeringTriggerPreferences.launchTargetLabel(this)}", 13.5f, true)
            p.addView(currentTargetTv)
            val sRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            sRow.addView(
                DashboardUi.action(this, "실행할 앱 선택", DashboardIcons.IconKind.POWER_LAUNCH, accent) {
                    pickSteeringLaunchApp(currentTargetTv)
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(4), dp(4), dp(4)) }
            )
            sRow.addView(
                DashboardUi.action(this, "바로 실행 테스트", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                    val pkg = SteeringTriggerPreferences.launchTargetPackage(this)
                    if (pkg.isBlank()) {
                        Toast.makeText(this, "먼저 실행할 앱을 선택하세요.", Toast.LENGTH_SHORT).show()
                    } else if (pkg.startsWith("split:")) {
                        val id = pkg.removePrefix("split:")
                        val prof = FeatureProfiles.splits(this).firstOrNull { it.id == id }
                        if (prof != null) Thread { com.byd.dolphin.drivealerts.automation.AutoSplitBehaviorEngine.launch(applicationContext, prof) }.start()
                    } else {
                        runCatching {
                            val i = packageManager.getLaunchIntentForPackage(pkg) ?: error("실행 불가 앱")
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                        }.onFailure { Toast.makeText(this, "앱 실행 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
                    }
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(4), 0, dp(4)) }
            )
            p.addView(sRow)
        }
    }

    private fun autostartCards(accent: Int) {
        addPanel("주행보조 자동 시작", "시동 ON 상태에서 주행보조 서비스를 자동으로 시작합니다.", DashboardIcons.IconKind.POWER_LAUNCH, accent) { p ->
            toggle(p, "시동 시 주행보조 자동 실행", AlertPreferences.autoStartEnabled(this)) { AlertPreferences.setAutoStartEnabled(this, it) }
        }
        addPanel("실행 앱 · 순서 · 미디어 재생 · OFF 종료", "시동 ON/OFF 규칙, 지연 시간, 백그라운드 재생을 한 곳에서 관리합니다.", DashboardIcons.IconKind.PLAY, accent) { p ->
            actionRow(
                p, "자동 실행 앱 및 시퀀스 관리",
                "등록 앱 ${FeatureProfiles.steps(this).size}개 · 순서 편집 · 수동 실행",
                DashboardIcons.IconKind.POWER_LAUNCH, accent,
                if (FeatureProfiles.sequenceEnabled(this)) "ON" else "OFF"
            ) { open(AutoLaunchSettingsActivity::class.java) }
            hint(p, "로컬 ADB 연결 및 미디어 알림 권한은 메인 메뉴 [권한 · ADB]에서 통합 관리합니다.")
        }
    }

    private fun dashcamCameraCards(accent: Int) {
        addPanel("주행 녹화 (블랙박스)", "공용 AVM Zero-Copy 허브 · 후측방·센트리와 무끊김 동시 작동 · H.264 순환 저장", DashboardIcons.IconKind.RECORD_DOT, accent) { p ->
            actionRow(
                p, "주행 녹화 설정 · USB/SD 저장 · 포맷",
                "초저리소스 H.264 · G-센서/급제동 보호 · 1Hz GPS 궤적",
                DashboardIcons.IconKind.RECORD_DOT, accent,
                if (com.byd.dolphin.drivealerts.camera.DashcamPreferences.enabled(this)) "ON" else "OFF"
            ) { open(DashcamActivity::class.java) }
            actionRow(
                p, "녹화 영상 · GPS 주행 뷰어",
                "일반 녹화 / 이벤트·센트리 보호 영상 즉시 재생 및 경로 지도 확인",
                DashboardIcons.IconKind.PLAY, DashboardUi.accentColor(this)
            ) { open(DashcamViewerActivity::class.java) }
        }

        addPanel("센트리 모드 (주차 감시)", "P단 주차 시 4방향 모션·IMU 충격 감시 · 경고 화면 · 시동 OFF 유지 · 12V/HV 보호", DashboardIcons.IconKind.RECORD_DOT, accent) { p ->
            actionRow(
                p, "센트리 모드 설정 및 경고 화면 미리보기",
                "2fps 초저부하 감시 · GPS 제외 구역 · 탑승 시 녹화 건수 음성 안내",
                DashboardIcons.IconKind.RECORD_DOT, accent,
                if (com.byd.dolphin.drivealerts.sentry.SentryPreferences.enabled(this)) "ON" else "OFF"
            ) { open(SentrySettingsActivity::class.java) }
        }

        addPanel("텔레그램 실시간 알림 봇", "센트리 감지·현장 사진·배터리 보호 차단·블랙박스 충격을 스마트폰으로 즉시 전송", DashboardIcons.IconKind.SHARE, DashboardUi.accentColor(this)) { p ->
            actionRow(
                p, "텔레그램 봇 연결 및 알림 항목 설정",
                "Bot Token · Chat ID 자동 찾기 · 연결 테스트",
                DashboardIcons.IconKind.SHARE, DashboardUi.accentColor(this),
                if (com.byd.dolphin.drivealerts.notify.TelegramPreferences.isConfigured(this)) "ON" else "OFF"
            ) { open(TelegramSettingsActivity::class.java) }
        }

        addPanel("깜박이 후측방 카메라 (BVM)", "공용 AVM + OpenGL ES 3.0 LUT 어안·선명도 보정 · 후진 시 순정 360 자동 양보", DashboardIcons.IconKind.RADAR_BSD, DashboardUi.accentColor(this)) { p ->
            actionRow(
                p, "후측방 카메라 설정 및 5초 미리보기",
                "카메라 자동 감지·보정 · 시야각 · 밝기/명암/채도 조절",
                DashboardIcons.IconKind.RADAR_BSD, DashboardUi.accentColor(this),
                if (com.byd.dolphin.drivealerts.camera.BsdCameraPreferences.enabled(this)) "ON" else "OFF"
            ) { open(BsdCameraSettingsActivity::class.java) }
        }

        addPanel("앞차 출발 AI 감지", "D단 정차 시 4fps 경량 TFLite + 야간 후미등 추적 · 주행 중 CPU 0%", DashboardIcons.IconKind.CAR_ALERT, DashboardUi.okColor(this)) { p ->
            actionRow(
                p, "앞차 출발 융합 감지 설정",
                "융합 / 카메라 전용 / 센서 전용 / 교차 확인 · 민감도 · 음성 테스트",
                DashboardIcons.IconKind.CAR_ALERT, DashboardUi.okColor(this),
                if (com.byd.dolphin.drivealerts.camera.LeadCarDeparturePreferences.enabled(this)) "ON" else "OFF"
            ) { open(LeadCarDepartureActivity::class.java) }
        }
    }

    private fun displayCards(accent: Int) {

        addPanel("순정 바 숨김 · 하단 플로팅 독바", "상·하단바 숨김 · 공조/열선 하단 고정 바 · 팝업 앱 폴더 · 가로 스와이프", DashboardIcons.IconKind.SPLIT_DISPLAY, accent) { p ->
            actionRow(
                p, "순정 바 숨김 및 하단 독바 설정",
                "접기/자동접기 · 공조/온도/풍량/바람방향 · 열선 · 앱 추가 · 폴더",
                DashboardIcons.IconKind.SPLIT_DISPLAY, accent,
                if (com.byd.dolphin.drivealerts.dock.DockPreferences.enabled(this)) "ON" else "OFF"
            ) { open(DockBarSettingsActivity::class.java) }
        }

        addPanel("공조 자동화 · 애프터 블로우 · 후진 비상등", "추울 때 열선·히터(HI) / 더울 때 에어컨(LOW) 자동 · 에어컨 건조 · 후진 시 비상등", DashboardIcons.IconKind.CAR_ALERT, accent) { p ->
            actionRow(
                p, "자동 냉난방 · 애프터 블로우 · 후진 비상등 설정",
                "핸들/시트 열선 개별 선택 · HI/LOW 풍량 · 송풍 시간",
                DashboardIcons.IconKind.CAR_ALERT, accent
            ) { open(ClimateAutomationActivity::class.java) }
        }

        addPanel("2앱 화면 분할", "프로필 · 분할 비율 · 바로가기 · 360 카메라 복원", DashboardIcons.IconKind.SPLIT_DISPLAY, accent) { p ->
            actionRow(
                p, "화면 분할 프로필 설정",
                "등록 프로필 ${FeatureProfiles.splits(this).size}개 · 1% 단위 비율 조절",
                DashboardIcons.IconKind.SPLIT_DISPLAY, accent
            ) { open(SplitProfilesActivity::class.java) }
        }

        // Strict Landscape-Lock Panel (forces portrait-only apps like APKPure into landscape, never gets stuck in portrait)
        addPanel("가로 화면 강제 고정 (세로 앱 대응)", "APKPure 등 강제 세로 앱이 실행되어도 전체 UI가 세로로 돌아가지 않고 가로를 유지합니다.", DashboardIcons.IconKind.ROTATE, accent) { p ->
            val rotStatus = DashboardUi.label(this, "끄면 즉시 순정 방향 정책으로 원복됩니다. (화면 위 표시 권한 필요)", 12.5f)
            val rotToggle = DashboardUi.toggle(this, "모든 앱 가로 화면 강제 고정 (ON/OFF)", RotationPolicy.enabled(this)) { on ->
                RotationPolicy.setSelected(this, if (on) OrientationMode.LANDSCAPE else OrientationMode.STOCK)
                RotationPolicy.setEnabled(this, on)
                val ok = RotationPolicy.applyCurrent(this)
                rotStatus.text = when {
                    !on -> "가로 고정 해제됨 · 순정 화면 방향으로 원복 완료"
                    ok -> "가로 화면 강제 고정 적용됨 (세로 전용 앱도 가로로 표시)"
                    else -> "적용 실패: 아래 '화면 위 표시 권한'을 먼저 허용해 주세요."
                }
            }.apply {
                background = DashboardUi.cardBg(this@MainActivity, DashboardUi.surfaceAltColor(this@MainActivity), DashboardUi.borderColor(this@MainActivity), 11)
            }
            p.addView(rotToggle, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(6)) })
            p.addView(rotStatus)
            button(p, "화면 위 표시 권한 열기", DashboardIcons.IconKind.KEY_PERM, accent) {
                SafeSettingsLauncher.open(this, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
            }
        }
    }

    private fun audioCards(accent: Int) {
        addPanel("이퀄라이저 · 음장 (Sound Focus)", "차량형 간편 3밴드 저·중·고음 및 공간감 조절", DashboardIcons.IconKind.EQUALIZER, accent) { p ->
            actionRow(
                p, "이퀄라이저 · 음장 상세 설정",
                "10밴드 정밀 EQ · 볼륨 보상 리미터 · 입체 음장 · 좌/우 밸런스",
                DashboardIcons.IconKind.EQUALIZER, accent
            ) { open(AudioTuningActivity::class.java) }
        }
    }

    private fun permissionAdbCards(accent: Int) {
        addPanel("필수 앱 권한 즉시 승인 (카메라 · 위치 · 저장소)", "ADB 연결 전에도 블랙박스·후측방 카메라·GPS·USB 저장소 권한을 한 번에 요청합니다.", DashboardIcons.IconKind.KEY_PERM, DashboardUi.okColor(this)) { p ->
            button(p, "필수 앱 권한 즉시 승인 (카메라·위치·저장소)", DashboardIcons.IconKind.KEY_PERM, DashboardUi.okColor(this)) {
                val req = arrayOf(
                    android.Manifest.permission.CAMERA,
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
                )
                runCatching { requestPermissions(req, 6901) }
                    .onFailure { Toast.makeText(this, "권한 창 열기 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
            }
        }
        addPanel("차량 로컬 ADB · 앱 권한 통합 관리", "분할화면, 시동 자동 실행, 미디어 알림 권한을 한 곳에서 관리합니다.", DashboardIcons.IconKind.SHIELD_ADB, accent) { p ->
            actionRow(
                p, "차량 로컬 ADB 연결 및 RSA 승인",
                "PC 없이 127.0.0.1:5555 로컬 연결 및 인증 확인",
                DashboardIcons.IconKind.USB_TERMINAL, accent
            ) { open(AdbSetupActivity::class.java) }
            actionRow(
                p, "선택 앱 권한 관리",
                "ADB 권한 상태 조회 · 알림 접근 · 위치 서비스 설정",
                DashboardIcons.IconKind.KEY_PERM, accent
            ) { open(AppPermissionManagerActivity::class.java) }
            button(p, "ADB 필수 권한 일괄 적용 · 검증", DashboardIcons.IconKind.SHIELD_ADB, accent) {
                Thread {
                    val msg = runCatching { PermissionBootstrapper.apply(applicationContext).lines.joinToString("\n") }
                        .getOrElse { "권한 검사 오류: ${it.message}" }
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) {
                            AlertDialog.Builder(this).setTitle("ADB 권한 검증")
                                .setMessage(msg).setPositiveButton("확인", null).show()
                        }
                    }
                }.start()
            }
        }
        addPanel("전체 설정 원터치 백업 · 복원 (JSON)", "알림 23종 · 10밴드 EQ · 블랙박스 · BVM 카메라 · 테마 설정을 한 번에 보관합니다.", DashboardIcons.IconKind.RESCUE, DashboardUi.okColor(this)) { p ->
            val bRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            bRow.addView(
                DashboardUi.action(this, "설정 JSON 백업", DashboardIcons.IconKind.SHARE, DashboardUi.okColor(this)) {
                    com.byd.dolphin.drivealerts.config.SettingsBackupManager.exportToJson(this).fold(
                        { loc -> Toast.makeText(this, "설정 백업 완료: $loc", Toast.LENGTH_LONG).show() },
                        { err -> Toast.makeText(this, "백업 실패: ${err.message}", Toast.LENGTH_LONG).show() }
                    )
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(4), dp(4), dp(4)) }
            )
            bRow.addView(
                DashboardUi.action(this, "최근 백업 복원", DashboardIcons.IconKind.RESCUE, accent) {
                    AlertDialog.Builder(this).setTitle("전체 설정 복원")
                        .setMessage("저장된 DolphinDriveSettings_backup.json 파일에서 앱 설정을 복원하시겠습니까?")
                        .setPositiveButton("복원") { _, _ ->
                            com.byd.dolphin.drivealerts.config.SettingsBackupManager.importFromLatestBackup(this).fold(
                                { cnt -> Toast.makeText(this, "설정 ${cnt}개 항목 복원 완료", Toast.LENGTH_LONG).show(); rerenderCurrentScreen() },
                                { err -> Toast.makeText(this, "복원 실패: ${err.message}", Toast.LENGTH_LONG).show() }
                            )
                        }.setNegativeButton("취소", null).show()
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(4), 0, dp(4)) }
            )
            p.addView(bRow)
        }
    }

    private fun diagnosticsLogCards(accent: Int) {
        addPanel("통합 로그 · 시동 구조 · 자동 점검", "저장 결과는 Downloads 폴더에 ZIP으로 보관됩니다.", DashboardIcons.IconKind.DIAG_LOG, accent) { p ->
            unifiedCaptureStatus = DashboardUi.label(this, "로그 상태 확인 중", 13.5f, true).apply {
                background = DashboardUi.cardBg(this@MainActivity, DashboardUi.surfaceAltColor(this@MainActivity), DashboardUi.borderColor(this@MainActivity), 10)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            p.addView(unifiedCaptureStatus, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) })
            updateCaptureStatus()

            val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            quickRow.addView(
                DashboardUi.action(this, "수집 시작", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                    performCapture(true); updateCaptureStatus()
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, 0, dp(3), dp(4)) }
            )
            quickRow.addView(
                DashboardUi.action(this, "종료 · ZIP", DashboardIcons.IconKind.STOP, DashboardUi.dangerColor(this)) {
                    performCapture(false); updateCaptureStatus()
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, dp(3), dp(4)) }
            )
            quickRow.addView(
                DashboardUi.action(this, "ZIP 공유", DashboardIcons.IconKind.SHARE, DashboardUi.accentColor(this)) {
                    shareLatestLogZip()
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), 0, 0, dp(4)) }
            )
            p.addView(quickRow)

            button(p, "시동 기록만 ZIP 저장 (수집 실패 시)", DashboardIcons.IconKind.RESCUE, DashboardUi.warnColor(this)) { exportIgnitionRescue() }
            button(p, "자동 점검 (읽기 전용)", DashboardIcons.IconKind.SEARCH_CHECK, accent) { runReadOnlyAutoCheck() }
            button(p, "BYD 권한 · FeatureIds 전수 스캔 (읽기 전용)", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) { runBydFeatureIdScan() }
        }

    }

    private fun pickSteeringLaunchApp(targetLabelView: TextView) {
        Toast.makeText(this, "설치된 앱 목록을 불러오는 중…", Toast.LENGTH_SHORT).show()
        Thread({
            val apps = runCatching { com.byd.dolphin.drivealerts.automation.AppSelection.launchable(applicationContext) }
                .getOrDefault(emptyList())
            val splits = FeatureProfiles.splits(applicationContext).map {
                com.byd.dolphin.drivealerts.automation.AppSelection.App("분할 프로필: ${it.title}", "split:${it.id}")
            }
            val all = splits + apps
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (all.isEmpty()) {
                    Toast.makeText(this, "실행 가능한 앱이 없습니다.", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val labels = all.map { "${it.title} (${it.packageName})" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("핸들 연타 시 실행할 앱 선택")
                    .setItems(labels) { _, which ->
                        val chosen = all[which]
                        SteeringTriggerPreferences.setLaunchTarget(this, chosen.packageName, chosen.title)
                        targetLabelView.text = "현재 지정: ${chosen.title}"
                        Toast.makeText(this, "핸들 연타 실행 앱 지정: ${chosen.title}", Toast.LENGTH_SHORT).show()
                    }
                    .setNeutralButton("지정 해제") { _, _ ->
                        SteeringTriggerPreferences.clearLaunchTarget(this)
                        targetLabelView.text = "현재 지정: ${SteeringTriggerPreferences.launchTargetLabel(this)}"
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }, "steering-app-picker").start()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (detailVisible) dashboardBack?.invoke() ?: goHome() else super.onBackPressed()
    }

    private fun exportIgnitionRescue() {
        Toast.makeText(this, "기존 시동 기록을 확인하고 있습니다", Toast.LENGTH_SHORT).show()
        Thread({
            val result = IgnitionAuditJournal.exportRecent(applicationContext)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                result.fold(
                    { location -> Toast.makeText(this, "시동 기록 저장 확인: $location", Toast.LENGTH_LONG).show() },
                    { error ->
                        AlertDialog.Builder(this).setTitle("시동 기록 ZIP 저장 실패")
                            .setMessage(error.message ?: error.javaClass.simpleName)
                            .setPositiveButton("확인", null).show()
                    }
                )
                updateCaptureStatus()
            }
        }, "dolphin-ignition-audit-export").start()
    }

    private fun performCapture(start: Boolean) {
        runCatching {
            if (start) DrivingAlertService.beginUnifiedCapture(this)
            else DrivingAlertService.endUnifiedCapture(this)
        }.onSuccess {
            Toast.makeText(this, if (start) "수집 시작 요청 전달" else "수집 종료 · ZIP 저장 요청 전달", Toast.LENGTH_SHORT).show()
            refreshDashboardStatus()
            for (delay in listOf(1_500L, 6_000L, 17_000L)) {
                scroller.postDelayed({
                    if (!isFinishing && !isDestroyed) {
                        updateCaptureStatus(); refreshDashboardStatus()
                    }
                }, delay)
            }
        }.onFailure { Toast.makeText(this, "요청 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    private fun setStatusTile(key: String, value: String, dotColor: Int) {
        statusValueViews[key]?.text = value
        statusDotViews[key]?.background = DashboardUi.cardBg(this, dotColor, 0, 99)
    }

    private fun refreshDashboardStatus() {
        val record = UnifiedLogCapture.state(this)
        homeCapturePill?.let { pill ->
            val (label, tint) = when (record.status) {
                UnifiedLogCapture.RECORDING -> "수집 중 · ${record.id}" to DashboardUi.okColor(this)
                UnifiedLogCapture.SAVING -> "ZIP 저장 중…" to DashboardUi.warnColor(this)
                UnifiedLogCapture.FAILED -> "저장 실패 · 재시도 필요" to DashboardUi.dangerColor(this)
                else -> "로그 대기 중" to DashboardUi.mutedColor(this)
            }
            pill.text = label
            pill.setTextColor(tint)
            pill.background = DashboardUi.cardBg(this, DashboardUi.alphaColor(tint, 32), DashboardUi.alphaColor(tint, 90), 99)
        }
        if (statusValueViews.isEmpty()) return

        val alive = DrivingAlertService.activeLogger != null
        setStatusTile("서비스", if (alive) "프로세스 활성" else "확인 필요", if (alive) DashboardUi.okColor(this) else DashboardUi.warnColor(this))

        val autoOn = AlertPreferences.autoStartEnabled(this)
        val seqOn = FeatureProfiles.sequenceEnabled(this)
        setStatusTile(
            "자동실행",
            "보조 ${if (autoOn) "ON" else "OFF"} / 지정 ${if (seqOn) "ON" else "OFF"}",
            if (autoOn || seqOn) DashboardUi.okColor(this) else DashboardUi.mutedColor(this)
        )

        val (logText, logColor) = when (record.status) {
            UnifiedLogCapture.RECORDING -> "수집 중" to DashboardUi.okColor(this)
            UnifiedLogCapture.SAVING -> "저장 중" to DashboardUi.warnColor(this)
            UnifiedLogCapture.FAILED -> "저장 실패" to DashboardUi.dangerColor(this)
            else -> "대기" to DashboardUi.mutedColor(this)
        }
        setStatusTile("로그", logText, logColor)

        val rotOn = RotationPolicy.enabled(this)
        setStatusTile("회전", if (rotOn) "ON" else "OFF", if (rotOn) DashboardUi.accentColor(this) else DashboardUi.mutedColor(this))

        val routeText = when (AlertPreferences.route(this)) {
            OutputRoute.MEDIA -> "미디어"
            OutputRoute.DRIVER_RAW14 -> "운전석 raw14"
            else -> "운전석 stream14"
        }
        setStatusTile("출력", routeText, DashboardUi.accentColor(this))

        setStatusTile("ADB", "확인 중", DashboardUi.mutedColor(this))
        val generation = ++adbCheckGeneration
        Thread({
            val result = runCatching { AuthorizedAdbRuntime.health(applicationContext).state }.getOrNull()
            runOnUiThread {
                if (isFinishing || isDestroyed || generation != adbCheckGeneration) return@runOnUiThread
                val (adbText, adbColor) = when (result) {
                    AuthorizedAdbRuntime.State.READY -> "인증 완료" to DashboardUi.okColor(this)
                    AuthorizedAdbRuntime.State.AUTH_REQUIRED -> "승인 필요" to DashboardUi.warnColor(this)
                    AuthorizedAdbRuntime.State.PORT_CLOSED -> "연결 안 됨" to DashboardUi.dangerColor(this)
                    AuthorizedAdbRuntime.State.PERMISSION_DENIED -> "권한 부족" to DashboardUi.dangerColor(this)
                    else -> "확인 불가" to DashboardUi.mutedColor(this)
                }
                setStatusTile("ADB", adbText, adbColor)
            }
        }, "dashboard-adb-readonly").start()
    }

    private fun runReadOnlyAutoCheck() {
        val installed = ExternalAppAudioRouter.NAVIGATION_APPS.map { app ->
            val exists = runCatching {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(app.pkg, 0) != null
            }.getOrDefault(false)
            "${app.title}: ${if (exists) "설치 확인" else "미설치/조회 불가"}"
        }
        val audio = getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
        val devices = runCatching {
            audio?.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)?.joinToString(", ") {
                "${it.type}:${it.productName}"
            }.orEmpty()
        }.getOrDefault("")
        val message = buildString {
            val events = AlertEventCatalog.entries
            val active = events.count { AlertPreferences.eventEnabled(this@MainActivity, it.event) }
            appendLine("추가 음성 23종: 사용자 허용 $active / ${events.size} (발화 성공 의미 아님)")
            appendLine("분할 비율/복원: 실제 Task bounds readback 필요")
            appendLine("NORMAL: 보조 후보=${AlertPreferences.normalNoticeCandidateEnabled(this@MainActivity)} (364+에코/스포츠 교차확인, 실차 미확정)")
            appendLine("음성 볼륨: ${AlertVolume.labels[AlertVolume.tier(this@MainActivity)]}")
            appendLine("BSD 좌우/ADAS: 실차 신호 판정 미완료 · 순정 안전 기능 유지")
            appendLine("Android SDK: ${android.os.Build.VERSION.SDK_INT}")
            appendLine("부팅 자동 실행: ${AlertPreferences.autoStartEnabled(this@MainActivity)}")
            appendLine("전역 회전: ${RotationPolicy.enabled(this@MainActivity)}")
            appendLine("로그 상태: ${UnifiedLogCapture.state(this@MainActivity).status}")
            appendLine("후측방 1번: ${AlertPreferences.bsdBlinkerEnabled(this@MainActivity)}")
            appendLine("후측방 2번: ${AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)}")
            appendLine("후측방 3번: ${AlertPreferences.bsdInstantEnabled(this@MainActivity)}")
            appendLine("\n내비 5종 설치 확인\n${installed.joinToString("\n")}")
            appendLine("\n오디오 출력장치: ${devices.ifBlank { "조회 불가" }}")
            appendLine("\n이것은 읽기 전용 상태 점검입니다. 실제 차량 신호 발화/오디오 라우팅의 성공 여부는 판정하지 않습니다.")
        }
        AlertDialog.Builder(this).setTitle("자동 점검 결과")
            .setMessage(message).setPositiveButton("확인", null).show()
        if (UnifiedLogCapture.state(this).status == UnifiedLogCapture.RECORDING) {
            runCatching { DrivingAlertService.captureQuick(this, "USER_AUTOMATED_READONLY_CHECK") }
        }
    }

    private fun runBydFeatureIdScan() {
        Toast.makeText(this, "BYD 권한 및 FeatureIds 읽기 전용 스캔 중…", Toast.LENGTH_SHORT).show()
        Thread({
            val report = runCatching { BydFeatureIdScanner.runReadOnlyScan(applicationContext) }
                .getOrElse {
                    BydFeatureIdScanner.ScanReport(
                        summary = "스캔 오류: ${it.javaClass.simpleName}",
                        fullText = it.message ?: it.javaClass.simpleName,
                        savedPath = "NONE"
                    )
                }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                AlertDialog.Builder(this)
                    .setTitle("BYD 권한 · FeatureIds 스캔")
                    .setMessage("${report.summary}\n저장 위치: ${report.savedPath}\n\n${report.fullText.take(6_000)}")
                    .setPositiveButton("확인", null)
                    .show()
            }
        }, "dolphin-byd-feature-scan").start()
    }

    private fun shareLatestLogZip() {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            AlertDialog.Builder(this).setTitle("로그 공유")
                .setMessage("Android 9 이하에서는 다운로드 폴더의 파일 관리자에서 DolphinDriveLogs_ ZIP을 선택해 공유하세요.")
                .setPositiveButton("확인", null).show()
            return
        }
        val uri = runCatching {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("DolphinDriveLogs_%.zip")
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    ContentUris.withAppendedId(collection, cursor.getLong(0))
                } else null
            }
        }.getOrNull()
        if (uri == null) {
            AlertDialog.Builder(this).setTitle("로그 ZIP 없음")
                .setMessage("먼저 수집 시작 → 필요한 테스트 → 수집 종료를 완료하세요. ZIP 저장이 끝나면 다시 공유할 수 있습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, "실차 로그 ZIP 공유")) }
            .onFailure { Toast.makeText(this, "공유 앱 열기 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
        refreshDashboardStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        val last = UnifiedLogCapture.lastResult(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 세션 ${state.id} · 재시동 복구 대상 · $last"
            UnifiedLogCapture.SAVING -> "저장 중 · 동일 세션 ZIP 검증 중 · 완료 후 상태를 다시 확인하세요"
            UnifiedLogCapture.FAILED -> "저장 실패 · $last · '종료 · ZIP'으로 원본 기록 재저장"
            else -> "대기 중 · 마지막 결과: $last · 시동 기록은 자동 보관 중"
        }
    }
}
