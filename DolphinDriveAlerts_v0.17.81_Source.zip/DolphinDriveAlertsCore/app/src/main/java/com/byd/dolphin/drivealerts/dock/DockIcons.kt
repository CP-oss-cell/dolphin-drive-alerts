package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/**
 * High-contrast, cockpit-grade Canvas vector icon kit for the Fixed Bottom Floating Dock Bar.
 * Designed for instant 0.3s glance recognition on BYD Dolphin 10.1" (1280x720, DPI 160).
 */
object DockIcons {
    enum class Kind {
        COLLAPSE,
        EXPAND,
        HOME,
        BACK,
        AC,
        FAN,
        WIND_FACE,
        WIND_FACE_FOOT,
        WIND_FOOT,
        WIND_DEFROST_FOOT,
        WIND_DEFROST,
        RECIRC,
        FRESH_AIR,
        STEERING_HEAT,
        SEAT_HEAT_L,
        SEAT_HEAT_R,
        REAR_MIRROR_DEFROST,
        FRONT_DEFROST,
        SETTINGS,
        APP_DRAWER,
        FOLDER,
        WINDOW_VENT,
        WINDOW_CLOSE,
        SUNSHADE,
        DASHCAM_LOCK,
        SPLIT_QUICK,
        AC_AUTO
    }

    fun drawable(context: Context, kind: Kind, color: Int, sizeDp: Int = 24): Drawable {
        val d = context.resources.displayMetrics.density
        return DockIconDrawable(
            kind = kind,
            color = color,
            sizePx = (d * sizeDp + 0.5f).toInt().coerceAtLeast(18),
            strokePx = (d * 2.1f).coerceAtLeast(1.8f)
        )
    }

    private class DockIconDrawable(
        private val kind: Kind,
        private val color: Int,
        private val sizePx: Int,
        private val strokePx: Float
    ) : Drawable() {
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = this@DockIconDrawable.color
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = this@DockIconDrawable.color
        }

        override fun getIntrinsicWidth(): Int = sizePx
        override fun getIntrinsicHeight(): Int = sizePx

        override fun draw(canvas: Canvas) {
            val b = bounds
            val w = b.width().toFloat().coerceAtLeast(1f)
            val h = b.height().toFloat().coerceAtLeast(1f)
            val s = minOf(w, h)
            val cx = b.exactCenterX()
            val cy = b.exactCenterY()
            val r = s * 0.42f

            when (kind) {
                Kind.COLLAPSE -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.7f, cy - r * 0.25f)
                        lineTo(cx, cy + r * 0.45f)
                        lineTo(cx + r * 0.7f, cy - r * 0.25f)
                    }
                    canvas.drawPath(p, stroke)
                    canvas.drawLine(cx - r * 0.6f, cy + r * 0.72f, cx + r * 0.6f, cy + r * 0.72f, stroke)
                }
                Kind.EXPAND -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.7f, cy + r * 0.35f)
                        lineTo(cx, cy - r * 0.35f)
                        lineTo(cx + r * 0.7f, cy + r * 0.35f)
                    }
                    canvas.drawPath(p, stroke)
                    canvas.drawLine(cx - r * 0.6f, cy - r * 0.68f, cx + r * 0.6f, cy - r * 0.68f, stroke)
                }
                Kind.HOME -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.85f, cy - r * 0.05f)
                        lineTo(cx, cy - r * 0.82f)
                        lineTo(cx + r * 0.85f, cy - r * 0.05f)
                        moveTo(cx - r * 0.58f, cy - r * 0.22f)
                        lineTo(cx - r * 0.58f, cy + r * 0.75f)
                        lineTo(cx + r * 0.58f, cy + r * 0.75f)
                        lineTo(cx + r * 0.58f, cy - r * 0.22f)
                    }
                    canvas.drawPath(p, stroke)
                }
                Kind.BACK -> {
                    val p = Path().apply {
                        moveTo(cx + r * 0.15f, cy - r * 0.7f)
                        lineTo(cx - r * 0.58f, cy)
                        lineTo(cx + r * 0.15f, cy + r * 0.7f)
                    }
                    canvas.drawPath(p, stroke)
                    canvas.drawLine(cx - r * 0.5f, cy, cx + r * 0.75f, cy, stroke)
                }
                Kind.AC, Kind.AC_AUTO -> {
                    // Snowflake
                    for (deg in listOf(0f, 60f, 120f)) {
                        canvas.save()
                        canvas.rotate(deg, cx, cy)
                        canvas.drawLine(cx, cy - r * 0.85f, cx, cy + r * 0.85f, stroke)
                        canvas.drawLine(cx - r * 0.22f, cy - r * 0.6f, cx, cy - r * 0.42f, stroke)
                        canvas.drawLine(cx + r * 0.22f, cy - r * 0.6f, cx, cy - r * 0.42f, stroke)
                        canvas.drawLine(cx - r * 0.22f, cy + r * 0.6f, cx, cy + r * 0.42f, stroke)
                        canvas.drawLine(cx + r * 0.22f, cy + r * 0.6f, cx, cy + r * 0.42f, stroke)
                        canvas.restore()
                    }
                }
                Kind.FAN -> {
                    canvas.drawCircle(cx, cy, r * 0.18f, fill)
                    for (deg in listOf(0f, 90f, 180f, 270f)) {
                        canvas.save()
                        canvas.rotate(deg, cx, cy)
                        val blade = RectF(cx - r * 0.22f, cy - r * 0.86f, cx + r * 0.34f, cy - r * 0.14f)
                        canvas.drawOval(blade, stroke)
                        canvas.restore()
                    }
                }
                Kind.WIND_FACE, Kind.WIND_FACE_FOOT, Kind.WIND_FOOT, Kind.WIND_DEFROST_FOOT, Kind.WIND_DEFROST -> {
                    // Seated driver silhouette on right + airflow arrows on left
                    canvas.drawCircle(cx + r * 0.38f, cy - r * 0.52f, r * 0.22f, stroke)
                    val seat = Path().apply {
                        moveTo(cx + r * 0.45f, cy - r * 0.18f)
                        lineTo(cx + r * 0.18f, cy + r * 0.32f)
                        lineTo(cx - r * 0.28f, cy + r * 0.32f)
                        lineTo(cx - r * 0.42f, cy + r * 0.78f)
                    }
                    canvas.drawPath(seat, stroke)
                    if (kind == Kind.WIND_FACE || kind == Kind.WIND_FACE_FOOT) {
                        drawArrowRight(canvas, cx - r * 0.88f, cy - r * 0.22f, cx - r * 0.12f, cy - r * 0.22f, r * 0.2f)
                    }
                    if (kind == Kind.WIND_FOOT || kind == Kind.WIND_FACE_FOOT || kind == Kind.WIND_DEFROST_FOOT) {
                        drawArrowDown(canvas, cx - r * 0.68f, cy + r * 0.15f, cx - r * 0.68f, cy + r * 0.78f, r * 0.2f)
                    }
                    if (kind == Kind.WIND_DEFROST || kind == Kind.WIND_DEFROST_FOOT) {
                        drawArrowUp(canvas, cx - r * 0.65f, cy - r * 0.15f, cx - r * 0.65f, cy - r * 0.82f, r * 0.2f)
                    }
                }
                Kind.RECIRC -> {
                    // Car outline + circular U-turn arrow inside
                    val car = RectF(cx - r * 0.85f, cy - r * 0.45f, cx + r * 0.85f, cy + r * 0.52f)
                    canvas.drawRoundRect(car, r * 0.32f, r * 0.32f, stroke)
                    val arc = RectF(cx - r * 0.35f, cy - r * 0.22f, cx + r * 0.35f, cy + r * 0.28f)
                    canvas.drawArc(arc, -150f, 260f, false, stroke)
                    canvas.drawCircle(cx - r * 0.32f, cy - r * 0.08f, r * 0.1f, fill)
                }
                Kind.FRESH_AIR -> {
                    // Car outline + outside-in arrow
                    val car = RectF(cx - r * 0.85f, cy - r * 0.45f, cx + r * 0.85f, cy + r * 0.52f)
                    canvas.drawRoundRect(car, r * 0.32f, r * 0.32f, stroke)
                    drawArrowRight(canvas, cx - r * 0.92f, cy - r * 0.78f, cx + r * 0.28f, cy + r * 0.12f, r * 0.2f)
                }
                Kind.STEERING_HEAT -> {
                    canvas.drawCircle(cx, cy + r * 0.12f, r * 0.66f, stroke)
                    canvas.drawCircle(cx, cy + r * 0.12f, r * 0.16f, fill)
                    canvas.drawLine(cx - r * 0.6f, cy + r * 0.12f, cx + r * 0.6f, cy + r * 0.12f, stroke)
                    canvas.drawLine(cx, cy + r * 0.12f, cx, cy + r * 0.75f, stroke)
                    drawHeatWaves(canvas, cx, cy - r * 0.68f, r * 0.38f, r * 0.25f)
                }
                Kind.SEAT_HEAT_L, Kind.SEAT_HEAT_R -> {
                    val dir = if (kind == Kind.SEAT_HEAT_L) 1f else -1f
                    val seat = Path().apply {
                        moveTo(cx - dir * r * 0.48f, cy - r * 0.65f)
                        lineTo(cx - dir * r * 0.22f, cy + r * 0.45f)
                        lineTo(cx + dir * r * 0.62f, cy + r * 0.45f)
                    }
                    canvas.drawPath(seat, stroke)
                    drawHeatWaves(canvas, cx + dir * r * 0.18f, cy - r * 0.22f, r * 0.45f, r * 0.34f)
                }
                Kind.REAR_MIRROR_DEFROST -> {
                    val glass = RectF(cx - r * 0.82f, cy - r * 0.48f, cx + r * 0.82f, cy + r * 0.52f)
                    canvas.drawRoundRect(glass, r * 0.16f, r * 0.16f, stroke)
                    drawHeatWaves(canvas, cx, cy + r * 0.02f, r * 0.56f, r * 0.44f)
                }
                Kind.FRONT_DEFROST -> {
                    val ws = Path().apply {
                        moveTo(cx - r * 0.8f, cy + r * 0.32f)
                        lineTo(cx - r * 0.52f, cy - r * 0.55f)
                        quadTo(cx, cy - r * 0.72f, cx + r * 0.52f, cy - r * 0.55f)
                        lineTo(cx + r * 0.8f, cy + r * 0.32f)
                        quadTo(cx, cy + r * 0.15f, cx - r * 0.8f, cy + r * 0.32f)
                    }
                    canvas.drawPath(ws, stroke)
                    drawHeatWaves(canvas, cx, cy + r * 0.12f, r * 0.5f, r * 0.42f)
                }
                Kind.SETTINGS -> {
                    canvas.drawCircle(cx, cy, r * 0.32f, stroke)
                    for (deg in 0 until 360 step 45) {
                        canvas.save()
                        canvas.rotate(deg.toFloat(), cx, cy)
                        canvas.drawLine(cx, cy - r * 0.82f, cx, cy - r * 0.55f, stroke)
                        canvas.restore()
                    }
                }
                Kind.APP_DRAWER -> {
                    val step = r * 0.56f
                    val dotR = r * 0.14f
                    for (ix in -1..1) for (iy in -1..1) {
                        canvas.drawCircle(cx + ix * step, cy + iy * step, dotR, fill)
                    }
                }
                Kind.FOLDER -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.82f, cy - r * 0.58f)
                        lineTo(cx - r * 0.18f, cy - r * 0.58f)
                        lineTo(cx, cy - r * 0.36f)
                        lineTo(cx + r * 0.82f, cy - r * 0.36f)
                        lineTo(cx + r * 0.82f, cy + r * 0.62f)
                        lineTo(cx - r * 0.82f, cy + r * 0.62f)
                        close()
                    }
                    canvas.drawPath(p, stroke)
                }
                Kind.WINDOW_VENT, Kind.WINDOW_CLOSE -> {
                    val win = Path().apply {
                        moveTo(cx - r * 0.7f, cy + r * 0.62f)
                        lineTo(cx - r * 0.7f, cy - r * 0.1f)
                        lineTo(cx - r * 0.1f, cy - r * 0.65f)
                        lineTo(cx + r * 0.7f, cy - r * 0.65f)
                        lineTo(cx + r * 0.7f, cy + r * 0.62f)
                        close()
                    }
                    canvas.drawPath(win, stroke)
                    if (kind == Kind.WINDOW_VENT) {
                        drawArrowDown(canvas, cx, cy - r * 0.25f, cx, cy + r * 0.35f, r * 0.2f)
                    } else {
                        drawArrowUp(canvas, cx, cy + r * 0.35f, cx, cy - r * 0.25f, r * 0.2f)
                    }
                }
                Kind.SUNSHADE -> {
                    val roof = RectF(cx - r * 0.8f, cy - r * 0.55f, cx + r * 0.8f, cy + r * 0.55f)
                    canvas.drawRoundRect(roof, r * 0.2f, r * 0.2f, stroke)
                    canvas.drawLine(cx, cy - r * 0.55f, cx, cy + r * 0.55f, stroke)
                }
                Kind.DASHCAM_LOCK -> {
                    canvas.drawCircle(cx, cy, r * 0.7f, stroke)
                    canvas.drawCircle(cx, cy, r * 0.28f, fill)
                }
                Kind.SPLIT_QUICK -> {
                    val box = RectF(cx - r * 0.82f, cy - r * 0.62f, cx + r * 0.82f, cy + r * 0.62f)
                    canvas.drawRoundRect(box, r * 0.18f, r * 0.18f, stroke)
                    canvas.drawLine(cx, cy - r * 0.62f, cx, cy + r * 0.62f, stroke)
                }
            }
        }

        private fun drawArrowRight(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, head: Float) {
            c.drawLine(x1, y1, x2, y2, stroke)
            c.drawLine(x2 - head, y2 - head * 0.7f, x2, y2, stroke)
            c.drawLine(x2 - head, y2 + head * 0.7f, x2, y2, stroke)
        }

        private fun drawArrowDown(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, head: Float) {
            c.drawLine(x1, y1, x2, y2, stroke)
            c.drawLine(x2 - head * 0.7f, y2 - head, x2, y2, stroke)
            c.drawLine(x2 + head * 0.7f, y2 - head, x2, y2, stroke)
        }

        private fun drawArrowUp(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, head: Float) {
            c.drawLine(x1, y1, x2, y2, stroke)
            c.drawLine(x2 - head * 0.7f, y2 + head, x2, y2, stroke)
            c.drawLine(x2 + head * 0.7f, y2 + head, x2, y2, stroke)
        }

        private fun drawHeatWaves(c: Canvas, cx: Float, cy: Float, spanW: Float, spanH: Float) {
            for (i in -1..1) {
                val x = cx + i * (spanW * 0.45f)
                val p = Path().apply {
                    moveTo(x, cy + spanH * 0.5f)
                    quadTo(x - spanW * 0.12f, cy, x, cy - spanH * 0.5f)
                }
                c.drawPath(p, stroke)
            }
        }

        override fun setAlpha(alpha: Int) { stroke.alpha = alpha; fill.alpha = alpha }
        override fun setColorFilter(cf: ColorFilter?) { stroke.colorFilter = cf; fill.colorFilter = cf }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}
