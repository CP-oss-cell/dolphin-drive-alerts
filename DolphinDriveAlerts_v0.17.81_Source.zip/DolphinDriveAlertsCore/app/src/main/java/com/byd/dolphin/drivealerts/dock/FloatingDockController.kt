package com.byd.dolphin.drivealerts.dock

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.automation.AutoSplitBehaviorEngine
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.ForegroundPolicyAccessibilityService
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Fixed Bottom-Docked Floating Cockpit Dock Bar Overlay (v0.17.67):
 * - Matches stock DiLink bottom bar size & position (Gravity.BOTTOM | FILL_HORIZONTAL).
 * - Collapse/Expand toggle with translucent floating handle + optional Auto-Collapse timer.
 * - Fixed compact controls:
 *   Collapse, Home, Back, AC ON/OFF, Temp (-/value/+), Fan (-/value/+),
 *   Wind Direction (tap cycles FACE -> FACE+FOOT -> FOOT -> UP+FOOT; long-press picks any),
 *   Recirc/Fresh toggle, Steering Heat, Driver Seat Heat, Passenger Seat Heat,
 *   Side-Mirror + Rear Defrost, Stock Settings, App Drawer,
 *   plus horizontally swipeable Pinned Apps, Popup App Folders (with real app icons),
 *   and user-selected Extra Stock BYD Functions.
 */
class FloatingDockController(
    context: Context,
    private val onDashcamEventLock: (() -> Unit)? = null
) {
    private val app = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val comfort = BydComfortController(app)

    private var dockView: View? = null
    private var collapsedHandle: View? = null
    private var popupOverlay: View? = null

    // Live indicator references inside dock bar
    private var acIconView: ImageView? = null
    private var tempValueView: TextView? = null
    private var fanValueView: TextView? = null
    private var windIconView: ImageView? = null
    private var windLabelView: TextView? = null
    private var recircIconView: ImageView? = null
    private var recircLabelView: TextView? = null
    private var steerIconView: ImageView? = null
    private var driverSeatView: TextView? = null
    private var driverSeatIcon: ImageView? = null
    private var passSeatView: TextView? = null
    private var passSeatIcon: ImageView? = null
    private var rearDefIconView: ImageView? = null

    @Volatile private var collapsed = false
    @Volatile private var attached = false

    private val autoCollapseRunnable = Runnable {
        if (attached && !collapsed && DockPreferences.autoCollapse(app) && popupOverlay == null) {
            collapse()
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!attached) return
            if (!collapsed) {
                comfort.refreshSnapshot()
                renderComfortIndicators()
            }
            mainHandler.postDelayed(this, 3_000L)
        }
    }

    fun refreshFromPreferences() {
        mainHandler.post {
            if (DockPreferences.enabled(app)) {
                showOrRebuild()
            } else {
                hideAll()
            }
        }
    }

    fun shutdown() {
        mainHandler.post { hideAll() }
    }

    private fun showOrRebuild() {
        if (!Settings.canDrawOverlays(app)) {
            CoreLog.w("DOCK", "SYSTEM_ALERT_WINDOW permission missing")
            return
        }
        hideAll()
        attached = true
        collapsed = false
        attachDockBar()
        comfort.refreshSnapshot()
        renderComfortIndicators()
        scheduleAutoCollapse()
        mainHandler.removeCallbacks(pollRunnable)
        mainHandler.postDelayed(pollRunnable, 3_000L)
    }

    private fun hideAll() {
        attached = false
        mainHandler.removeCallbacks(autoCollapseRunnable)
        mainHandler.removeCallbacks(pollRunnable)
        dismissPopup()
        removeWindowView(dockView); dockView = null
        removeWindowView(collapsedHandle); collapsedHandle = null
    }

    private fun collapse() {
        dismissPopup()
        collapsed = true
        removeWindowView(dockView); dockView = null
        attachCollapsedHandle()
    }

    private fun expand() {
        collapsed = false
        removeWindowView(collapsedHandle); collapsedHandle = null
        attachDockBar()
        comfort.refreshSnapshot()
        renderComfortIndicators()
        scheduleAutoCollapse()
    }

    private fun scheduleAutoCollapse() {
        mainHandler.removeCallbacks(autoCollapseRunnable)
        if (DockPreferences.autoCollapse(app)) {
            mainHandler.postDelayed(autoCollapseRunnable, DockPreferences.autoCollapseSeconds(app) * 1000L)
        }
    }

    private fun dp(v: Int): Int = (app.resources.displayMetrics.density * v + 0.5f).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun attachCollapsedHandle() {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val handle = FrameLayout(app).apply {
            background = GradientDrawable().apply {
                setColor(0x780E1624.toInt()) // Translucent glass pill
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0x8838D9E6.toInt())
            }
            addView(ImageView(app).apply {
                setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.EXPAND, 0xCCFFFFFF.toInt(), 22))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            setOnClickListener { expand() }
        }
        val lp = WindowManager.LayoutParams(
            dp(54), dp(40), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = dp(12)
            y = dp(6)
        }
        runCatching {
            wm.addView(handle, lp)
            collapsedHandle = handle
        }.onFailure { CoreLog.w("DOCK", "attachCollapsedHandle failed: ${it.message}") }
    }

    private fun attachDockBar() {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val barH = dp(DockPreferences.heightDp(app))
        val alphaByte = ((DockPreferences.opacityPercent(app) / 100f) * 255f).toInt().coerceIn(130, 255)
        val bgColor = (alphaByte shl 24) or 0x0B1220

        val root = FrameLayout(app).apply {
            background = GradientDrawable().apply {
                setColor(bgColor)
                setStroke(dp(1), 0x4438D9E6)
            }
        }

        val hsv = HorizontalScrollView(app).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
        }
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(10), dp(2))
        }

        // 1. 접기
        row.addView(iconTile(DockIcons.Kind.COLLAPSE, "접기", 0xFF94A3B8.toInt()) {
            collapse()
        })
        // 2. 홈
        row.addView(iconTile(DockIcons.Kind.HOME, "홈", 0xFFE2E8F0.toInt()) {
            scheduleAutoCollapse()
            performHome()
        })
        // 3. 이전
        row.addView(iconTile(DockIcons.Kind.BACK, "이전", 0xFFE2E8F0.toInt()) {
            scheduleAutoCollapse()
            performBack()
        })
        row.addView(divider())

        // 4. 공조 ON/OFF (탭=공조 전체 ON/OFF, 길게 누름=에어컨·히터 개별 ON/OFF 선택)
        val (acTile, acIv, _) = iconTileWithBothRefs(
            DockIcons.Kind.AC, "공조", 0xFFCBD5E1.toInt(),
            onClick = {
                scheduleAutoCollapse()
                comfort.toggleAcPower()
                renderComfortIndicators()
            },
            onLongClick = {
                showClimateDetailPopup()
                true
            }
        )
        acIconView = acIv
        row.addView(acTile)

        // 5. 온도 조절 (- / 값 / +)
        val tempGroup = stepperGroup(
            labelPrefix = "",
            onMinus = { scheduleAutoCollapse(); comfort.adjustTemp(-0.5f); renderComfortIndicators() },
            onPlus = { scheduleAutoCollapse(); comfort.adjustTemp(0.5f); renderComfortIndicators() }
        ) { tv -> tempValueView = tv }
        row.addView(tempGroup)

        // 6. 풍량 조절 (- / 값 / +)
        val fanGroup = stepperGroup(
            labelPrefix = "풍량",
            onMinus = { scheduleAutoCollapse(); comfort.adjustFan(-1); renderComfortIndicators() },
            onPlus = { scheduleAutoCollapse(); comfort.adjustFan(1); renderComfortIndicators() }
        ) { tv -> fanValueView = tv }
        row.addView(fanGroup)

        // 7. 바람 방향 (짧게 탭=순환, 길게 누름=팝업 선택)
        val (windTile, windIv, windTv) = iconTileWithBothRefs(
            DockIcons.Kind.WIND_FACE, "정면", 0xFF38D9E6.toInt(),
            onClick = {
                scheduleAutoCollapse()
                comfort.cycleWindModeTap()
                renderComfortIndicators()
            },
            onLongClick = {
                showWindPickerPopup()
                true
            }
        )
        windIconView = windIv
        windLabelView = windTv
        row.addView(windTile)

        // 8. 외기/내기 전환
        val (recTile, recIv, recTv) = iconTileWithBothRefs(
            DockIcons.Kind.FRESH_AIR, "외기", 0xFF93C5FD.toInt(),
            onClick = {
                scheduleAutoCollapse()
                comfort.toggleRecirculation()
                renderComfortIndicators()
            }
        )
        recircIconView = recIv
        recircLabelView = recTv
        row.addView(recTile)

        row.addView(divider())

        // 9. 핸들 열선
        val (steerTile, steerIv) = iconTileWithRef(DockIcons.Kind.STEERING_HEAT, "핸들", 0xFFCBD5E1.toInt()) {
            scheduleAutoCollapse()
            comfort.toggleSteeringHeat()
            renderComfortIndicators()
        }
        steerIconView = steerIv
        row.addView(steerTile)

        // 10. 운전석 열선
        val (drvTile, drvIv, drvTv) = iconTileWithBothRefs(
            DockIcons.Kind.SEAT_HEAT_L, "운전", 0xFFCBD5E1.toInt(),
            onClick = {
                scheduleAutoCollapse()
                comfort.cycleDriverSeatHeat()
                renderComfortIndicators()
            }
        )
        driverSeatIcon = drvIv
        driverSeatView = drvTv
        row.addView(drvTile)

        // 11. 동승석 열선
        val (pasTile, pasIv, pasTv) = iconTileWithBothRefs(
            DockIcons.Kind.SEAT_HEAT_R, "동승", 0xFFCBD5E1.toInt(),
            onClick = {
                scheduleAutoCollapse()
                comfort.cyclePassengerSeatHeat()
                renderComfortIndicators()
            }
        )
        passSeatIcon = pasIv
        passSeatView = pasTv
        row.addView(pasTile)

        // 12. 사이드미러 + 후방 열선
        val (rearTile, rearIv) = iconTileWithRef(DockIcons.Kind.REAR_MIRROR_DEFROST, "미러·후방", 0xFFCBD5E1.toInt()) {
            scheduleAutoCollapse()
            comfort.toggleRearMirrorDefrost()
            renderComfortIndicators()
        }
        rearDefIconView = rearIv
        row.addView(rearTile)

        row.addView(divider())

        // 13. 순정 설정
        row.addView(iconTile(DockIcons.Kind.SETTINGS, "설정", 0xFFE2E8F0.toInt()) {
            scheduleAutoCollapse()
            launchStockSettings()
        })

        // 14. 앱서랍
        row.addView(iconTile(DockIcons.Kind.APP_DRAWER, "앱서랍", 0xFF38D9E6.toInt()) {
            showAppDrawerPopup()
        })

        // 15. 추가 설치된 앱 (실제 앱 아이콘 표시, 오른쪽 스와이프 가능)
        val pinned = DockPreferences.pinnedApps(app)
        if (pinned.isNotEmpty()) {
            row.addView(divider())
            for (pkg in pinned) {
                row.addView(installedAppTile(pkg))
            }
        }

        // 16. 사용자 생성 폴더 (2x2 미니 아이콘 미리보기 -> 탭 시 팝업폴더)
        val folders = DockPreferences.folders(app)
        if (folders.isNotEmpty()) {
            row.addView(divider())
            for (folder in folders) {
                row.addView(folderTile(folder))
            }
        }

        // 17. 선택된 추가 순정 기능들 (오른쪽 스와이프 확장 영역)
        val extras = DockPreferences.extraStockActions(app)
        if (extras.isNotEmpty()) {
            row.addView(divider())
            for (action in DockPreferences.ExtraStockAction.values()) {
                if (action.key in extras) {
                    row.addView(extraStockTile(action))
                }
            }
        }

        hsv.addView(row, FrameLayout.LayoutParams(-2, -1))
        root.addView(hsv, FrameLayout.LayoutParams(-1, -1))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            barH,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = 0
            y = 0
        }
        runCatching {
            wm.addView(root, lp)
            dockView = root
        }.onFailure { CoreLog.w("DOCK", "attachDockBar failed: ${it.message}") }
    }

    private fun renderComfortIndicators() {
        val s = comfort.snapshot()
        val onCyan = 0xFF38D9E6.toInt()
        val onHeat = 0xFFFF6B35.toInt()
        val onWarn = 0xFFFFB84D.toInt()
        val offGray = 0xFF94A3B8.toInt()

        acIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.AC, if (s.acOn) onCyan else offGray, 22))
        tempValueView?.text = "${"%.1f".format(s.tempC)}°"
        fanValueView?.text = "${s.fanLevel}단"

        val wKind = when (s.windMode) {
            BydComfortController.WIND_FACE_FOOT -> DockIcons.Kind.WIND_FACE_FOOT
            BydComfortController.WIND_FOOT -> DockIcons.Kind.WIND_FOOT
            BydComfortController.WIND_DEFROST_FOOT -> DockIcons.Kind.WIND_DEFROST_FOOT
            BydComfortController.WIND_DEFROST -> DockIcons.Kind.WIND_DEFROST
            else -> DockIcons.Kind.WIND_FACE
        }
        windIconView?.setImageDrawable(DockIcons.drawable(app, wKind, onCyan, 22))
        windLabelView?.text = when (s.windMode) {
            BydComfortController.WIND_FACE -> "정면"
            BydComfortController.WIND_FACE_FOOT -> "정·하"
            BydComfortController.WIND_FOOT -> "아래"
            BydComfortController.WIND_DEFROST_FOOT -> "상·하"
            else -> "앞유리"
        }

        recircIconView?.setImageDrawable(
            DockIcons.drawable(app, if (s.recirculation) DockIcons.Kind.RECIRC else DockIcons.Kind.FRESH_AIR,
                if (s.recirculation) onWarn else 0xFF60A5FA.toInt(), 22)
        )
        recircLabelView?.text = if (s.recirculation) "내기" else "외기"

        steerIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.STEERING_HEAT, if (s.steeringHeat) onHeat else offGray, 22))
        driverSeatIcon?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SEAT_HEAT_L, if (s.driverSeatHeat > 0) onHeat else offGray, 22))
        driverSeatView?.text = if (s.driverSeatHeat > 0) "운전${s.driverSeatHeat}" else "운전"
        passSeatIcon?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SEAT_HEAT_R, if (s.passengerSeatHeat > 0) onHeat else offGray, 22))
        passSeatView?.text = if (s.passengerSeatHeat > 0) "동승${s.passengerSeatHeat}" else "동승"
        rearDefIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.REAR_MIRROR_DEFROST, if (s.rearMirrorDefrost) onWarn else offGray, 22))
    }

    private fun divider(): View = View(app).apply {
        setBackgroundColor(0x3364748B)
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(30)).apply { setMargins(dp(4), 0, dp(4), 0) }
    }

    private fun iconTile(kind: DockIcons.Kind, label: String, color: Int, onClick: () -> Unit): View =
        iconTileWithBothRefs(kind, label, color, onClick, null).first

    private fun iconTileWithRef(kind: DockIcons.Kind, label: String, color: Int, onClick: () -> Unit): Pair<View, ImageView> {
        val t = iconTileWithBothRefs(kind, label, color, onClick, null)
        return t.first to t.second
    }

    private fun iconTileWithBothRefs(
        kind: DockIcons.Kind,
        label: String,
        color: Int,
        onClick: () -> Unit,
        onLongClick: (() -> Boolean)? = null
    ): Triple<View, ImageView, TextView> {
        val box = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(2), dp(7), dp(2))
            layoutParams = LinearLayout.LayoutParams(-2, -1).apply { setMargins(dp(1), 0, dp(1), 0) }
            setOnClickListener { onClick() }
            if (onLongClick != null) setOnLongClickListener { onLongClick() }
        }
        val iv = ImageView(app).apply {
            setImageDrawable(DockIcons.drawable(app, kind, color, 22))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val tv = TextView(app).apply {
            text = label
            textSize = 10f
            setTextColor(0xFFCBD5E1.toInt())
            maxLines = 1
            gravity = Gravity.CENTER
        }
        box.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
        box.addView(tv, LinearLayout.LayoutParams(-2, -2))
        return Triple(box, iv, tv)
    }

    private fun stepperGroup(
        labelPrefix: String,
        onMinus: () -> Unit,
        onPlus: () -> Unit,
        bindValue: (TextView) -> Unit
    ): View {
        val wrap = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF152033.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(4), dp(2), dp(4), dp(2))
            layoutParams = LinearLayout.LayoutParams(-2, dp(42)).apply { setMargins(dp(3), 0, dp(3), 0) }
        }
        fun stepBtn(sym: String, act: () -> Unit): TextView = TextView(app).apply {
            text = sym
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF38D9E6.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { act() }
        }
        val mid = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), 0, dp(4), 0)
        }
        if (labelPrefix.isNotEmpty()) {
            mid.addView(TextView(app).apply {
                text = labelPrefix
                textSize = 9.5f
                setTextColor(0xFF94A3B8.toInt())
                gravity = Gravity.CENTER
            })
        }
        val valTv = TextView(app).apply {
            text = "--"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        bindValue(valTv)
        mid.addView(valTv)

        wrap.addView(stepBtn("−", onMinus), LinearLayout.LayoutParams(dp(28), -1))
        wrap.addView(mid, LinearLayout.LayoutParams(-2, -2))
        wrap.addView(stepBtn("+", onPlus), LinearLayout.LayoutParams(dp(28), -1))
        return wrap
    }

    private fun installedAppTile(pkg: String): View {
        val pm = app.packageManager
        val appIcon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
        val appName = runCatching {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg.substringAfterLast('.'))
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(54), -1)
            addView(ImageView(app).apply {
                if (appIcon != null) setImageDrawable(appIcon)
                else setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.APP_DRAWER, Color.WHITE, 24))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(TextView(app).apply {
                text = appName
                textSize = 9.5f
                setTextColor(0xFFE2E8F0.toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            setOnClickListener {
                scheduleAutoCollapse()
                launchPackage(pkg)
            }
        }
    }

    private fun folderTile(folder: DockPreferences.AppFolder): View {
        val pm = app.packageManager
        val miniGrid = GridLayout(app).apply {
            columnCount = 2
            rowCount = 2
            background = GradientDrawable().apply {
                setColor(0xFF1A2840.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), 0x8838D9E6.toInt())
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val previewPkgs = folder.packages.take(4)
        for (i in 0 until 4) {
            val iv = ImageView(app).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                val pkg = previewPkgs.getOrNull(i)
                if (pkg != null) {
                    runCatching { pm.getApplicationIcon(pkg) }.getOrNull()?.let { setImageDrawable(it) }
                }
            }
            miniGrid.addView(iv, GridLayout.LayoutParams().apply {
                width = dp(12); height = dp(12)
                setMargins(dp(1), dp(1), dp(1), dp(1))
            })
        }
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(56), -1)
            addView(miniGrid, LinearLayout.LayoutParams(dp(30), dp(30)))
            addView(TextView(app).apply {
                text = folder.name
                textSize = 9.5f
                setTextColor(0xFF38D9E6.toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            setOnClickListener { showFolderPopup(folder) }
        }
    }

    private fun extraStockTile(action: DockPreferences.ExtraStockAction): View {
        val (kind, shortLabel, color) = when (action) {
            DockPreferences.ExtraStockAction.AC_AUTO -> Triple(DockIcons.Kind.AC_AUTO, "AUTO", 0xFF38D9E6.toInt())
            DockPreferences.ExtraStockAction.FRONT_DEFROST -> Triple(DockIcons.Kind.FRONT_DEFROST, "앞성에", 0xFFFFB84D.toInt())
            DockPreferences.ExtraStockAction.VENTILATE -> Triple(DockIcons.Kind.WINDOW_VENT, "환기", 0xFF60A5FA.toInt())
            DockPreferences.ExtraStockAction.CLOSE_WINDOWS -> Triple(DockIcons.Kind.WINDOW_CLOSE, "창닫기", 0xFF94A3B8.toInt())
            DockPreferences.ExtraStockAction.SUNSHADE_OPEN -> Triple(DockIcons.Kind.SUNSHADE, "썬열기", 0xFF2EE59D.toInt())
            DockPreferences.ExtraStockAction.SUNSHADE_CLOSE -> Triple(DockIcons.Kind.SUNSHADE, "썬닫기", 0xFF94A3B8.toInt())
            DockPreferences.ExtraStockAction.DASHCAM_LOCK -> Triple(DockIcons.Kind.DASHCAM_LOCK, "녹화잠금", 0xFFFF7A7A.toInt())
            DockPreferences.ExtraStockAction.SPLIT_QUICK -> Triple(DockIcons.Kind.SPLIT_QUICK, "분할실행", 0xFFA78BFA.toInt())
        }
        return iconTile(kind, shortLabel, color) {
            scheduleAutoCollapse()
            when (action) {
                DockPreferences.ExtraStockAction.AC_AUTO -> { comfort.toggleAcAuto(); renderComfortIndicators() }
                DockPreferences.ExtraStockAction.FRONT_DEFROST -> { comfort.toggleFrontDefrost(); renderComfortIndicators() }
                DockPreferences.ExtraStockAction.VENTILATE -> comfort.ventilateWindows()
                DockPreferences.ExtraStockAction.CLOSE_WINDOWS -> comfort.closeAllWindows()
                DockPreferences.ExtraStockAction.SUNSHADE_OPEN -> comfort.toggleSunshade(true)
                DockPreferences.ExtraStockAction.SUNSHADE_CLOSE -> comfort.toggleSunshade(false)
                DockPreferences.ExtraStockAction.DASHCAM_LOCK -> onDashcamEventLock?.invoke()
                DockPreferences.ExtraStockAction.SPLIT_QUICK -> {
                    val prof = FeatureProfiles.splits(app).firstOrNull()
                    if (prof != null) Thread { AutoSplitBehaviorEngine.launch(app, prof) }.start()
                }
            }
        }
    }

    /** Long-press Climate button: toggle 전체 공조 / 에어컨(A/C) / 히터 individually. */
    private fun showClimateDetailPopup() {
        showPopupCard("공조 · 에어컨 · 히터 제어", widthDp = 340, maxHeightDp = 240) { body ->
            val s = comfort.snapshot()
            val rows = listOf(
                Triple("전체 공조", s.acOn) { comfort.toggleAcPower() },
                Triple("에어컨 (A/C 냉방)", s.acCompressorOn) { comfort.toggleAcCompressor() },
                Triple("히터 (난방)", s.heaterOn) { comfort.toggleHeater() }
            )
            for ((label, isOn, act) in rows) {
                body.addView(TextView(app).apply {
                    text = if (isOn) "● $label  [ON]" else "○ $label  [OFF]"
                    textSize = 15f
                    setTypeface(typeface, if (isOn) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (isOn) 0xFF38D9E6.toInt() else Color.WHITE)
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = GradientDrawable().apply {
                        setColor(if (isOn) 0xFF1A2D46.toInt() else 0xFF131D2E.toInt())
                        cornerRadius = dp(10).toFloat()
                    }
                    setOnClickListener {
                        act()
                        renderComfortIndicators()
                        dismissPopup()
                        scheduleAutoCollapse()
                    }
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
        }
    }

    /** Long-press Wind Direction popup: pick 위(앞유리), 정면, 정면+아래, 아래, 위+아래 directly. */
    private fun showWindPickerPopup() {
        val options = listOf(
            BydComfortController.WIND_DEFROST to "위 (앞유리)",
            BydComfortController.WIND_FACE to "정면",
            BydComfortController.WIND_FACE_FOOT to "정면 + 아래",
            BydComfortController.WIND_FOOT to "아래",
            BydComfortController.WIND_DEFROST_FOOT to "위 + 아래"
        )
        showPopupCard("바람 방향 직접 선택", widthDp = 340, maxHeightDp = 240) { body ->
            val row = LinearLayout(app).apply {
                orientation = LinearLayout.VERTICAL
            }
            for ((mode, label) in options) {
                val active = comfort.snapshot().windMode == mode
                row.addView(TextView(app).apply {
                    text = if (active) "● $label" else label
                    textSize = 15f
                    setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (active) 0xFF38D9E6.toInt() else Color.WHITE)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    background = GradientDrawable().apply {
                        setColor(if (active) 0xFF1A2D46.toInt() else 0xFF131D2E.toInt())
                        cornerRadius = dp(10).toFloat()
                    }
                    setOnClickListener {
                        comfort.setWindMode(mode)
                        renderComfortIndicators()
                        dismissPopup()
                        scheduleAutoCollapse()
                    }
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
            body.addView(row)
        }
    }

    /** Popup folder overlay with live Cols(2~6) x Rows(2~5) & Translucent Opacity controls right inside the popup. */
    private fun showFolderPopup(folder: DockPreferences.AppFolder) {
        val pm = app.packageManager
        val cols = DockPreferences.popupCols(app)
        val rows = DockPreferences.popupRows(app)
        val cellW = 92
        val cellH = 86
        val cardW = (cols * (cellW + 8) + 34).coerceIn(260, 720)
        val bodyMaxH = rows * (cellH + 8) + 8

        showPopupCard("폴더 · ${folder.name}", widthDp = cardW, maxHeightDp = bodyMaxH + 92) { body ->
            // Inline 2(col) x 2(row) & Transparency bar inside the popup itself
            body.addView(buildPopupControlsBar(
                onGridChanged = { showFolderPopup(folder) },
                onOpacityChanged = { showFolderPopup(folder) }
            ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

            if (folder.packages.isEmpty()) {
                body.addView(TextView(app).apply {
                    text = "폴더에 등록된 앱이 없습니다. 독바 설정에서 앱을 추가하세요."
                    textSize = 13.5f
                    setTextColor(0xFF94A3B8.toInt())
                    setPadding(dp(8), dp(14), dp(8), dp(14))
                })
                return@showPopupCard
            }
            val scroll = ScrollView(app)
            val grid = GridLayout(app).apply { columnCount = cols }
            for (pkg in folder.packages) {
                grid.addView(popupAppCell(pm, pkg), GridLayout.LayoutParams().apply {
                    width = dp(cellW); height = dp(cellH)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            scroll.addView(grid)
            body.addView(scroll, LinearLayout.LayoutParams(-1, dp(bodyMaxH).coerceAtMost(dp(440))))
        }
    }

    private fun buildPopupControlsBar(onGridChanged: () -> Unit, onOpacityChanged: () -> Unit): View {
        val cols = DockPreferences.popupCols(app)
        val rows = DockPreferences.popupRows(app)
        val op = DockPreferences.popupOpacityPercent(app)
        val bar = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0x66152033)
                cornerRadius = dp(8).toFloat()
            }
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        fun chipBtn(txt: String, onClick: () -> Unit): TextView = TextView(app).apply {
            text = txt
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF38D9E6.toInt())
            background = GradientDrawable().apply {
                setColor(0x991C2A42.toInt())
                cornerRadius = dp(6).toFloat()
            }
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { onClick() }
        }
        // Cols cycle (2..6) x Rows cycle (2..5)
        bar.addView(chipBtn("가로 ${cols}칸") {
            val next = if (cols >= 6) 2 else cols + 1
            DockPreferences.setPopupCols(app, next)
            onGridChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(TextView(app).apply {
            text = "×"
            textSize = 13f
            setTextColor(0xFF94A3B8.toInt())
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(chipBtn("세로 ${rows}줄") {
            val next = if (rows >= 5) 2 else rows + 1
            DockPreferences.setPopupRows(app, next)
            onGridChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) })

        bar.addView(View(app), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(chipBtn("투명−") {
            DockPreferences.setPopupOpacityPercent(app, (op - 10).coerceAtLeast(40))
            onOpacityChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(TextView(app).apply {
            text = "${op}%"
            textSize = 12f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(chipBtn("진하게+") {
            DockPreferences.setPopupOpacityPercent(app, (op + 10).coerceAtMost(100))
            onOpacityChanged()
        })
        return bar
    }

    /** Full installed App Drawer floating overlay with real app icons. */
    private fun showAppDrawerPopup() {
        val pm = app.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = runCatching {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .sortedBy { p ->
                    runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() }.getOrDefault(p)
                }
        }.getOrDefault(emptyList())

        showPopupCard("앱 서랍 (${apps.size}개)", widthDp = 640, maxHeightDp = 420) { body ->
            val scroll = ScrollView(app)
            val grid = GridLayout(app).apply { columnCount = 6 }
            for (pkg in apps) {
                grid.addView(popupAppCell(pm, pkg), GridLayout.LayoutParams().apply {
                    width = dp(96); height = dp(86)
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            scroll.addView(grid)
            body.addView(scroll, LinearLayout.LayoutParams(-1, dp(340)))
        }
    }

    private fun popupAppCell(pm: PackageManager, pkg: String): View {
        val icon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
        val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xFF131E30.toInt())
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(4), dp(6), dp(4), dp(4))
            addView(ImageView(app).apply {
                if (icon != null) setImageDrawable(icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(TextView(app).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            setOnClickListener {
                dismissPopup()
                scheduleAutoCollapse()
                launchPackage(pkg)
            }
        }
    }

    private fun showPopupCard(title: String, widthDp: Int, maxHeightDp: Int, fill: (LinearLayout) -> Unit) {
        dismissPopup()
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val card = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                val popAlpha = ((DockPreferences.popupOpacityPercent(app) / 100f) * 255f).toInt().coerceIn(100, 255)
                setColor((popAlpha shl 24) or 0x0B1220)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(2), 0xFF38D9E6.toInt())
            }
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        val head = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(app).apply {
            text = title
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(app).apply {
            text = "✕"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { dismissPopup() }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        val body = LinearLayout(app).apply { orientation = LinearLayout.VERTICAL }
        fill(body)
        card.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val lp = WindowManager.LayoutParams(
            dp(widthDp),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(DockPreferences.heightDp(app) + 12)
        }
        runCatching {
            wm.addView(card, lp)
            popupOverlay = card
        }.onFailure { CoreLog.w("DOCK", "showPopupCard failed: ${it.message}") }
    }

    private fun dismissPopup() {
        removeWindowView(popupOverlay)
        popupOverlay = null
    }

    private fun performHome() {
        if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_HOME)) return
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ok = runCatching { app.startActivity(homeIntent); true }.getOrDefault(false)
        if (!ok) Thread { AuthorizedAdbRuntime.writeOnce(app, "input keyevent 3") }.start()
    }

    private fun performBack() {
        if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_BACK)) return
        Thread { AuthorizedAdbRuntime.writeOnce(app, "input keyevent 4") }.start()
    }

    private fun launchStockSettings() {
        val intent = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { app.startActivity(intent) }
            .onFailure { Toast.makeText(app, "순정 설정 열기 실패", Toast.LENGTH_SHORT).show() }
    }

    private fun launchPackage(pkg: String) {
        val intent = app.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent != null) {
            runCatching { app.startActivity(intent) }
        }
    }

    private fun removeWindowView(v: View?) {
        if (v == null) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        runCatching { wm.removeViewImmediate(v) }
    }
}
