package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Clean-Room Climate & Reverse-Hazard Automation Engine (v0.17.76):
 * 1. Cold/Hot Weather Auto-Climate: once per trip when driving begins (or ignition ON), reads
 *    outside temperature and independently engages configured heating (steering wheel, driver/pass
 *    seats, HI heater + fan) or cooling (LOW A/C + fan).
 * 2. After-Blow: if A/C was active during the trip, on ACC_OFF runs fresh-air blower (compressor OFF)
 *    for configured minutes under a bounded PartialWakeLock, then turns climate OFF.
 *    Automatically cancels if the driver returns / shifts back into gear.
 * 3. Reverse Hazard Light: opt-in only; turns hazard lights ON while in Reverse (gearRaw == 1)
 *    and OFF immediately when shifting out of Reverse.
 */
class ClimateAutomationController(context: Context) {
    private val app = context.applicationContext
    private val comfort = BydComfortController(app)
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var acUsedThisTrip = false
    @Volatile private var weatherAutoAppliedTrip = false
    @Volatile private var afterBlowActive = false
    @Volatile private var hazardAppliedByUs = false
    @Volatile private var lastTempCheckMs = 0L
    private var afterBlowWakeLock: PowerManager.WakeLock? = null

    @Volatile private var lastGearRaw: Int? = null
    private val afterBlowStopRunnable = Runnable { finishAfterBlow("timer_done") }
    private val hazardOffRunnable = Runnable { turnOffHazardNow("nd_10s_timer_done") }

    fun onVehicleFrame(frame: RawVehicleFrame, blinkerSide: Side = Side.UNKNOWN) {
        val now = frame.timestampMs
        val gear = frame.gearRaw
        val isReverse = gear == 1
        val isPark = gear == 3
        val isND = gear == 2 || gear == 4
        val isDrivingOrReady = gear in listOf(1, 2, 4) // R, D, N

        // 1. Reverse-gear hazard light state machine (opt-in):
        //    - R gear: ON continuously while in R (cancels any pending off timer)
        //    - R -> N/D: hold 10s then auto-OFF, with immediate early-cancel on turn signal or speed >= 12 km/h
        //    - P gear / ACC_OFF / feature OFF: immediate OFF
        if (ClimateAutomationPreferences.reverseHazardEnabled(app)) {
            when {
                isReverse -> {
                    handler.removeCallbacks(hazardOffRunnable)
                    if (!hazardAppliedByUs && setHazardLights(true)) {
                        hazardAppliedByUs = true
                    }
                }
                isPark -> {
                    if (hazardAppliedByUs) turnOffHazardNow("gear_P_immediate")
                }
                isND && hazardAppliedByUs -> {
                    val blinkerOn = blinkerSide == Side.LEFT || blinkerSide == Side.RIGHT
                    val speedUp = (frame.speedKmH ?: 0f) >= 12f
                    if (blinkerOn || speedUp) {
                        turnOffHazardNow(if (blinkerOn) "blinker_early_cancel" else "speed_12kmh_early_cancel")
                    } else if (lastGearRaw == 1) {
                        // Just shifted from R -> N/D: schedule single 10s hold timer
                        handler.removeCallbacks(hazardOffRunnable)
                        handler.postDelayed(hazardOffRunnable, 10_000L)
                        CoreLog.i("CLIMATE_AUTO", "HAZARD_HOLD_10S gear=$gear")
                    }
                }
            }
        } else if (hazardAppliedByUs) {
            turnOffHazardNow("feature_disabled")
        }
        lastGearRaw = gear

        // 2. Cancel After-Blow immediately if driver re-enters / shifts out of P
        if (afterBlowActive && isDrivingOrReady) {
            finishAfterBlow("driver_returned")
        }

        // 3. Track A/C usage & apply Cold/Hot auto climate once per trip
        if (now - lastTempCheckMs >= 5_000L) {
            lastTempCheckMs = now
            val snap = comfort.refreshSnapshot()
            if (snap.acOn || snap.acCompressorOn) {
                acUsedThisTrip = true
            }
            if (isDrivingOrReady && !weatherAutoAppliedTrip) {
                weatherAutoAppliedTrip = true
                applyWeatherAutomation()
            }
        }
    }

    fun applyWeatherAutomation(): String {
        val outC = readOutsideTempC() ?: return "외기 온도 미수신 (적용 보류)"
        if (ClimateAutomationPreferences.coldAutoEnabled(app) && outC <= ClimateAutomationPreferences.coldThresholdC(app)) {
            if (ClimateAutomationPreferences.coldSteeringHeat(app)) comfort.setSteeringHeatDirect(true)
            val drv = ClimateAutomationPreferences.coldDriverSeat(app)
            if (drv > 0) comfort.setSeatHeatDirect(1, drv)
            val pas = ClimateAutomationPreferences.coldPassengerSeat(app)
            if (pas > 0) comfort.setSeatHeatDirect(2, pas)
            if (ClimateAutomationPreferences.coldHeaterHi(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(31.0f) // HI
                comfort.setHeaterDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.coldHeaterFan(app))
            }
            val msg = "추위 자동 난방 적용 (${outC.toInt()}°C ≤ ${ClimateAutomationPreferences.coldThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        if (ClimateAutomationPreferences.hotAutoEnabled(app) && outC >= ClimateAutomationPreferences.hotThresholdC(app)) {
            if (ClimateAutomationPreferences.hotAcLow(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(17.0f) // LOW
                comfort.setAcCompressorDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.hotAcFan(app))
                acUsedThisTrip = true
            }
            val msg = "더위 자동 냉방 적용 (${outC.toInt()}°C ≥ ${ClimateAutomationPreferences.hotThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        return "외기 ${outC.toInt()}°C · 기준 온도 범위 외 (자동 공조 대기)"
    }

    fun onIgnitionOff() {
        weatherAutoAppliedTrip = false
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
        if (ClimateAutomationPreferences.afterBlowEnabled(app) && acUsedThisTrip) {
            acUsedThisTrip = false
            startAfterBlow()
        }
    }

    fun startAfterBlow(forceTest: Boolean = false) {
        if (afterBlowActive) return
        if (!forceTest && !ClimateAutomationPreferences.afterBlowEnabled(app)) return
        val minutes = ClimateAutomationPreferences.afterBlowMinutes(app)
        val fan = ClimateAutomationPreferences.afterBlowFanLevel(app)
        afterBlowActive = true

        runCatching {
            val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
            afterBlowWakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Dolphin:AfterBlow")
                ?.apply { setReferenceCounted(false); acquire((minutes + 1) * 60_000L) }
        }

        // Fresh air (OUTLOOP) + A/C compressor OFF + gentle blower fan
        comfort.setClimatePowerDirect(true)
        comfort.setAcCompressorDirect(false)
        comfort.setCycleModeDirect(recirc = false)
        comfort.setFanLevelDirect(fan)

        handler.removeCallbacks(afterBlowStopRunnable)
        handler.postDelayed(afterBlowStopRunnable, minutes * 60_000L)
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_STARTED minutes=$minutes fan=$fan forceTest=$forceTest")
    }

    private fun finishAfterBlow(reason: String) {
        if (!afterBlowActive) return
        afterBlowActive = false
        handler.removeCallbacks(afterBlowStopRunnable)
        if (reason == "timer_done") {
            comfort.setClimatePowerDirect(false)
        }
        runCatching { afterBlowWakeLock?.let { if (it.isHeld) it.release() } }
        afterBlowWakeLock = null
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_FINISHED reason=$reason")
    }

    private fun readOutsideTempC(): Float? = runCatching {
        val cls = Class.forName("android.hardware.bydauto.ac.BYDAutoAcDevice")
        val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, app) ?: return@runCatching null
        for (name in listOf("getOutCarTemperature", "getOutSideTemperature", "getOutsideTemperature")) {
            val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
            val v = (m.invoke(inst) as? Number)?.toFloat()
            if (v != null && v in -35f..60f) return@runCatching v
        }
        null
    }.getOrNull()

    private fun turnOffHazardNow(reason: String) {
        handler.removeCallbacks(hazardOffRunnable)
        if (hazardAppliedByUs) {
            setHazardLights(false)
            hazardAppliedByUs = false
            CoreLog.i("CLIMATE_AUTO", "HAZARD_OFF reason=$reason")
        }
    }

    private fun setHazardLights(on: Boolean): Boolean = runCatching {
        val cls = Class.forName("android.hardware.bydauto.light.BYDAutoLightDevice")
        val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, app) ?: return@runCatching false
        val st = if (on) 1 else 0
        for (mName in listOf("setHazardLightState", "setDoubleFlashState", "setWarningLightState")) {
            val m = runCatching { cls.getMethod(mName, Int::class.javaPrimitiveType) }.getOrNull()
            if (m != null) {
                m.invoke(inst, st)
                CoreLog.i("CLIMATE_AUTO", "HAZARD $mName($st)")
                return@runCatching true
            }
        }
        val setLight = runCatching {
            cls.getMethod("setLightState", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        }.getOrNull()
        if (setLight != null) {
            setLight.invoke(inst, 4, st) // area 4 = hazard/double-flash on BYD light HAL
            return@runCatching true
        }
        false
    }.getOrDefault(false)

    fun shutdown() {
        finishAfterBlow("shutdown")
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
    }
}
