package com.byd.dolphin.drivealerts.camera

import android.content.Context
import android.view.Surface
import com.byd.dolphin.drivealerts.util.CoreLog
import dalvik.system.PathClassLoader
import java.io.File
import java.lang.reflect.Method

/**
 * Clean-Room BYD DiLink 3 BmmCamera / AVMCamera Vendor Framework Backend.
 *
 * On BYD Dolphin (DiLink 3.0 / firmware 2602~2608), the 4-channel 360 surround cameras
 * (2560x1920 quad or 5120x960 strip) are exposed through /system/framework/bmmcamera.jar
 * (android.hardware.AVMCamera / android.hardware.BmmCameraInfo) rather than standard Camera2.
 *
 * This backend probes and loads the vendor JAR cleanly via reflection, opens the AVM or
 * normal front dashcam channel onto an arbitrary Surface (such as our OpenGL ES 3.0 LUT
 * SurfaceTexture), and releases cleanly on Reverse gear or shutdown.
 */
class BydAvmCameraBackend(context: Context) {
    data class ProbeInfo(
        val available: Boolean,
        val jarPath: String?,
        val avmClassName: String?,
        val hasBmmInfo: Boolean,
        val detail: String
    )

    private val app = context.applicationContext
    @Volatile private var cachedLoader: ClassLoader? = null
    @Volatile private var activeCameraObj: Any? = null
    @Volatile private var activeOpen = false

    val isOpen: Boolean get() = activeOpen && activeCameraObj != null

    private val candidateJars = listOf(
        "/system/framework/bmmcamera.jar",
        "/system/framework/AVMCamera.jar",
        "/system/framework/com.byd.camera.jar",
        "/system/framework/bydcamera.jar",
        "/system/framework/byd_avm.jar",
        "/vendor/framework/bmmcamera.jar",
        "/vendor/framework/AVMCamera.jar"
    )

    private val candidateClasses = listOf(
        "android.hardware.AVMCamera",
        "android.hardware.avm.AVMCamera"
    )

    private fun resolveClassLoader(): Pair<ClassLoader, String?> {
        cachedLoader?.let { return it to candidateJars.firstOrNull { p -> File(p).canRead() } }
        val existingJars = candidateJars.filter { File(it).canRead() }
        if (existingJars.isEmpty()) {
            return app.classLoader to null
        }
        val joined = existingJars.joinToString(File.pathSeparator)
        val loader = runCatching { PathClassLoader(joined, app.classLoader) }.getOrDefault(app.classLoader)
        cachedLoader = loader
        return loader to existingJars.first()
    }

    private fun loadClassOrNull(loader: ClassLoader, name: String): Class<*>? =
        runCatching { loader.loadClass(name) }.getOrNull()
            ?: runCatching { Class.forName(name) }.getOrNull()

    fun probe(): ProbeInfo {
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { name -> loadClassOrNull(loader, name)?.let { name to it } }
        val bmmInfo = loadClassOrNull(loader, "android.hardware.BmmCameraInfo") != null
        val available = avmCls != null
        val detail = if (available) {
            "BYD AVM 프레임워크 감지됨 (${avmCls!!.first}${if (jar != null) " · ${File(jar).name}" else ""}${if (bmmInfo) " · BmmCameraInfo OK" else ""})"
        } else {
            val readable = candidateJars.filter { File(it).canRead() }.map { File(it).name }
            "BYD AVM 미감지 (읽기 가능 JAR=${if (readable.isEmpty()) "없음" else readable.joinToString(",")})"
        }
        return ProbeInfo(available, jar, avmCls?.first, bmmInfo, detail)
    }

    /**
     * Open BYD AVM 4-channel surround camera (2560x1920 quad) onto the provided Surface.
     * Returns pair of (success, diagnosticMessage).
     */
    fun openAvm(surface: Surface, viewMode: Int = 0): Pair<Boolean, String> {
        close()
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { loadClassOrNull(loader, it) }
            ?: return false to "AVMCamera 클래스를 찾을 수 없음"

        return runCatching {
            val camObj = instantiateAvmCamera(avmCls)
                ?: return false to "AVMCamera 인스턴스 생성 실패"
            activeCameraObj = camObj

            // Try setPreviewSurface(Surface) or setPreviewDisplay variants
            val bound = bindSurface(avmCls, camObj, surface)
            if (!bound) {
                close()
                return false to "AVMCamera setPreviewSurface 바인딩 실패"
            }

            // Optional view-mode selection if supported (quad = 0 or 4)
            invokeOptionalInt(avmCls, camObj, listOf("setViewMode", "setCameraMode", "setDisplayMode"), viewMode)

            // Start preview
            val started = invokeOptionalNoArg(avmCls, camObj, listOf("startPreview", "start", "openPreview"))
            activeOpen = true
            val msg = "AVMCamera 오픈 성공 (${File(jar ?: "uses-library").name}, startPreview=$started)"
            CoreLog.i("BYD_AVM", msg)
            true to msg
        }.getOrElse { e ->
            close()
            val msg = "AVMCamera 오픈 예외: ${e.javaClass.simpleName}: ${e.message}"
            CoreLog.w("BYD_AVM", msg)
            false to msg
        }
    }

    /**
     * Open normal single-channel BYD camera (e.g. front dashcam) if exposed via open(int) / openCamera(int).
     */
    fun openNormal(camId: Int, surface: Surface): Pair<Boolean, String> {
        close()
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { loadClassOrNull(loader, it) }
            ?: return false to "AVMCamera 클래스 없음"

        return runCatching {
            val openInt: Method? = listOf("open", "openCamera").firstNotNullOfOrNull { m ->
                runCatching { avmCls.getMethod(m, Int::class.javaPrimitiveType) }.getOrNull()
            }
            val camObj = if (openInt != null) {
                openInt.invoke(null, camId)
            } else {
                instantiateAvmCamera(avmCls)
            } ?: return false to "일반 채널(ID=$camId) 오픈 실패"

            activeCameraObj = camObj
            if (!bindSurface(avmCls, camObj, surface)) {
                close()
                return false to "일반 채널 Surface 바인딩 실패"
            }
            invokeOptionalNoArg(avmCls, camObj, listOf("startPreview", "start"))
            activeOpen = true
            val msg = "BYD 일반 채널(ID=$camId) 오픈 성공 (${File(jar ?: "uses-library").name})"
            CoreLog.i("BYD_AVM", msg)
            true to msg
        }.getOrElse { e ->
            close()
            false to "BYD 일반 채널 예외: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    fun close() {
        val obj = activeCameraObj
        activeCameraObj = null
        activeOpen = false
        if (obj == null) return
        val cls = obj.javaClass
        invokeOptionalNoArg(cls, obj, listOf("stopPreview", "stop"))
        invokeOptionalNoArg(cls, obj, listOf("release", "close"))
        CoreLog.i("BYD_AVM", "AVMCamera closed")
    }

    private fun instantiateAvmCamera(cls: Class<*>): Any? {
        // 1. Static open() / open(int) / getInstance()
        val staticNoArg = listOf("open", "openAvm", "getInstance").firstNotNullOfOrNull { name ->
            runCatching { cls.getMethod(name) }.getOrNull()
        }
        if (staticNoArg != null) {
            runCatching { staticNoArg.invoke(null) }.getOrNull()?.let { return it }
        }
        val staticInt = listOf("open", "openCamera").firstNotNullOfOrNull { name ->
            runCatching { cls.getMethod(name, Int::class.javaPrimitiveType) }.getOrNull()
        }
        if (staticInt != null) {
            runCatching { staticInt.invoke(null, 0) }.getOrNull()?.let { return it }
        }
        // 2. Constructor fallback (zero-arg or Context-arg)
        runCatching { cls.getDeclaredConstructor().apply { isAccessible = true }.newInstance() }
            .getOrNull()?.let { return it }
        runCatching { cls.getDeclaredConstructor(Context::class.java).apply { isAccessible = true }.newInstance(app) }
            .getOrNull()?.let { return it }
        return null
    }

    private fun bindSurface(cls: Class<*>, obj: Any, surface: Surface): Boolean {
        val candidates = listOf("setPreviewSurface", "setSurface", "addPreviewSurface", "setPreviewTarget")
        for (name in candidates) {
            val m = runCatching { cls.getMethod(name, Surface::class.java) }.getOrNull() ?: continue
            val ok = runCatching { m.invoke(obj, surface); true }.getOrDefault(false)
            if (ok) return true
        }
        return false
    }

    private fun invokeOptionalNoArg(cls: Class<*>, obj: Any, names: List<String>): Boolean {
        for (n in names) {
            val m = runCatching { cls.getMethod(n) }.getOrNull() ?: continue
            if (runCatching { m.invoke(obj); true }.getOrDefault(false)) return true
        }
        return false
    }

    private fun invokeOptionalInt(cls: Class<*>, obj: Any, names: List<String>, value: Int): Boolean {
        for (n in names) {
            val m = runCatching { cls.getMethod(n, Int::class.javaPrimitiveType) }.getOrNull() ?: continue
            if (runCatching { m.invoke(obj, value); true }.getOrDefault(false)) return true
        }
        return false
    }
}
