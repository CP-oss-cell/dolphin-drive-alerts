# Dolphin OEM HUD Bridge v0.9.5 — 검증 결과

입력: 2026-11-02 실차 진단 ZIP 2개, 펌웨어 2602 BydAutoTMap.apk 원본, v0.9.4 소스.

## 확인된 문제
- 원본 APK 패키지 `com.tmap.auto.byd` 직접 확인.
- 이전 앱 진단: OEM AutoNavi TBT 방송 0회, 기존 안내 0회, HUD Q BLE FFF2 준비/설정 GATT 쓰기는 정상 기록, 접근성 최종 NOT_ENABLED.
- 순정 TMAP이 AutoNavi 방송을 사용한다는 근거 없음.

## 소스 변경 후 실제 수행한 로컬 검사
- 사전 검사 57/57 PASS.
- NavCue 파서 47 PASS (대각 방향 포함).
- HUD 설정 인코딩 12 PASS.
- 순정 내비 이름/패키지 선택 8 PASS, 설치앱 카탈로그 15 assertions PASS.
- BLE 실시간 모의 실행 45 PASS.
- 실제 BridgeService+HudConnector 모의 통합 7 PASS.
- Kotlin ADB 소스 오프라인 타입 검사 PASS.
- 대시보드+앱 목록 Java 오프라인 타입 검사 PASS.
- TMAP 접근성·알림 수신기 + 실제 BridgeLog Java 오프라인 타입 검사 PASS.
- CI 중복 리소스 패키징 규칙 검사 PASS.

## 미검증/제약
- Android SDK 실제 `gradle :app:assembleDebug` 빌드는 로컬에서 수행하지 못함. GitHub Actions 수행 필요.
- 접근성 서비스가 사용자의 차량에서 TMAP 길안내 텍스트에 접근할 수 있는지는 실차 미확인.
- TMAP의 공개 Binder 서비스 존재는 확인했지만 회전/거리 read-only API와 호출 권한 검증 못함. 임의 호출하지 않음.
- HUD 실물에 회전 방향이 표시되는지 미확인. GATT write만으로 물리 표시 성공 판단 불가.

**판정:** 컴파일 일부·로컬 시뮬레이션 통과. 실차 HUD 출력 완료 판정 금지.
