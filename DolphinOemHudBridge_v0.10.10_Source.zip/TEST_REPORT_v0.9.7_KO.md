# Dolphin OEM HUD Bridge v0.9.7 — 재검증 보고

## 발견한 실제 CI 실패
- 사용자 GitHub Actions 로그 2026-11-02 07:41:31 UTC: ZIP 압축 해제 후 `cmp -s .github/workflows/build-oem-hud-bridge.yml hud-bridge-build/.github/workflows/build-oem-hud-bridge.yml` 거짓으로 종료 코드 1. Gradle 빌드 미시작.
- 배포된 원본 v0.9.6 ZIP 내부 YML과 별도로 제공된 v0.9.6 YML은 로컬에서 SHA-256이 동일함. GitHub 브랜치에 실존한 YML이 달랐을 수 있으나, 로그만으로 변경 원인 확정 불가.

## 이번 수정
- CI의 원문 YML `cmp -s` 비교 삭제. 안전한 버전 확인은 `RELEASE_BUNDLE.json`과 실제 `app/build.gradle` 버전 검사를 사용.
- 필수 TMAP 소스 존재와 패키지값 직접 검증 및 59항목 사전 검사 수행.
- 별도의 패키징 회귀검사 `check_packaging_ci_fix.py`가 기대하는 APK 산출물 확인 구문을 워크플로에 유지.
- v0.9.7, versionCode17. 앱 런타임 기능은 v0.9.6과 동일.

## 로컬 확인
- RELEASE IDENTITY v0.9.7 / versionCode17: PASS.
- 소스 preflight: 59/59 PASS.
- v0.9.6 기능 유지 확인: TBT/HUD 설정/NAVPKG 파서, BLE GATT 모의 45개, 서비스+실제 커넥터 모의 7개, ADB Kotlin stub compile: PASS.
- 대시보드+앱선택 Java 스텁 타입 검사: PASS.
- 순정 TMAP 접근성·알림 수신기 Java 스텁 타입 검사: PASS.
- Java-resource packaging 규칙: PASS.
- ZIP 압축 해제 후 릴리스 ID 검사: 별도 PASS 대상.

## 아직 확인되지 않은 항목
- 실제 Android SDK/Gradle `assembleDebug` 및 GitHub Actions 전체 성공은 현재 오프라인 환경에서 미확인.
- 실차 순정 TMAP TBT 수신과 HUD 화면 출력은 미확인. v0.9.7은 CI 수정 릴리스이며 새 TMAP 기능 구현을 주장하지 않음.
