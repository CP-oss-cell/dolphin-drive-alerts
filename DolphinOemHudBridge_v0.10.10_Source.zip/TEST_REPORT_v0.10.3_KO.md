# v0.10.3 검증 항목
`byd2.zip` 실패: compileDebugJavaWithJavac OemVehicleIpcProbe.java:31 ProviderInfo.permission 미존재.
본 버전은 SDK 정적 검사 + 기존 단위/모의 회귀 테스트를 추가/유지하며, 실제 Android 34 SDK 컴파일 및 APK 빌드는 GitHub Actions에서 확인한다.
