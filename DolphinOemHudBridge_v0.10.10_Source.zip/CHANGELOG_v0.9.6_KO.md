# v0.9.6 — GitHub 사전 검사 56/57 실패 수정

## 실제 실패 원인
- 2026-11-02 GitHub Actions: `FAIL PREFLIGHT Navigation receiver type-check in CI` (56/57), 이후 APK 빌드 미실행.
- `preflight.py`가 추출한 소스의 YML 문자열을 검사했지만, CI가 실행 도중 저장소 YML로 소스 YML을 덮어쓸 수 있었음. 구버전 YML에서 해당 검사 단계가 빠지면 Java를 컴파일하지도 않고 거짓 실패가 발생.

## 수정
1. ZIP/YML을 `cmp -s`로 빌드 초기에 강제 대조. 일치하지 않으면 명확한 안내로 중단.
2. 빌드 중 ZIP 내부 YML을 저장소 YML로 덮어쓰는 동작 제거.
3. 수신기 검사 구현(`javac` 대상 파일)을 자체 검증하고, 별도 CI step에서 실제 실행.
4. 앱 버전 v0.9.6 (versionCode 16)로 구분.
5. v0.9.5 순정 TMAP 접근성·알림 로직 / HUD BLE 기능 그대로 유지.

## 검증 경계
- 로컬 preflight 및 오프라인 시뮬레이션과 파일 일치성만 검증; GitHub `assembleDebug`, 실차 순정 TMAP → HUD 화면 출력은 아직 검증 전.
