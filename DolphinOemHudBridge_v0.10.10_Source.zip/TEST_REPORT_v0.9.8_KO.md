# v0.9.8 검사 결과 및 실차 미확인 항목

## 근거: 업로드 2026-11-02 20:21 실차 진단
- GATT FFF2 준비, 완료 16회, 오류 0회. 실제 장치 밝기/소리 적용 및 화면 출력 미확인.
- 순정 OEM 방송 0회, 내비 알림 5회, 접근성 이벤트 2271회, 화면트리 522회, 폴링 218회.
- **방향·거리 해석 성공 0회 / HUD 길안내 전송 시도 0회**. 따라서 네이버/일반 TMAP이 TBT 안내를 완전히 파싱했다는 주장은 기록과 일치하지 않음.
- `com.tmap.auto.byd` / `com.nhn.android.nmap` / `com.skt.tmap.ku` 각각 선택 이력 확인됨.

## 로컬 검사
- `tools/run_all_simulations.sh`: PASS (자바 파서, BLE 48, 서비스·HUD 통합 7, Android 모의, ADB Kotlin 스텁).
- `tools/run_dashboard_typecheck.sh`: PASS.
- `tools/run_nav_receiver_typecheck.sh`: PASS.
- `tools/preflight.py`: 64/64 PASS.
- `tools/verify_release_bundle.py --version v0.9.8 --code 18`: PASS.
- ZIP 구성 및 CRC 검사는 산출물 생성 후 재확인.

## 미검증
- 실제 Android SDK/Gradle `assembleDebug` 컴파일: 로컬 환경에 Android SDK/Gradle 부재.
- BLE FFF2가 HUD의 실제 설정·길안내 제어 경로인지와 HUD 펌웨어/차량 기본 블루투스 선연결 공존.
- OEM 순정 TMAP이 텍스트 접근성으로 실제 방향/거리를 제공하는지. 사용자 주행/정차 중의 독립적 실차 확인 필요.
