# v0.10.2 / HUD-RE-012 검증 보고

기준: 2026-11-03, 정적 연구 및 오프라인 컴파일·모의 검사. 실제 APK 빌드와 차량 검증은 아직 수행되지 않음.

## 검증된 범위

- 소스 사전 검사: **84/84 통과** (`tools/preflight.py`)
- MCon HUD GATT 연결·명령 시뮬레이션: **53개 통과** (`run_ble_simulation.sh`)
- 서비스+실제 HudConnector 오프라인 통합 검사: **9개 통과** (`run_integrated_simulation.sh`, 새 OEM AutoNavi 차단 케이스 2개 포함)
- 순정 TMAP 상태 방송 파서: **12개 통과** (`OemTmapStateSignalTest`)
- OEM 차량 Manifest 읽기 진단: **6개 통과** (`VehicleProbeRuntimeTest`); OEM Binder 기존 8개도 통과
- 대시보드 UI 및 내비 앱 선택: 독립 Java 타입 검사 **통과** (`run_dashboard_typecheck.sh`)
- 접근성·알림 수신기: 독립 Java 타입 검사 **통과** (`run_nav_receiver_typecheck.sh`, 전 단계 실행 확인)
- HUD-RE-012 12차수 근거표·원본 성공 소스 SHA256 7/7 검사 **통과** (`validate_re012_evidence.py`)
- AndroidManifest/소스 버전 일치: versionCode=22, versionName=0.10.2-oem-tbt-boundary

## 검사 제한

- 일부 전체 모의 테스트 실행에서 선택적 독립 `kotlinc` 오프라인 검사가 실행 시간을 초과해 종료되었으며, **그 검사가 통과했다고 주장하지 않는다**. Github CI에서는 실제 Gradle SDK 빌드가 Kotlin 컴파일을 검증하도록 선택적 사전 검사를 건너뛴다.
- Android SDK와 Gradle 설치 환경이 없어서 **`:app:assembleDebug` 자체는 이곳에서 완료하지 못함**. GitHub CI APK 산출 여부는 GitHub 실행 결과에 따라 결정된다.
- 차량에 v0.10.2를 설치하여 순정 내비 TBT 자동 수신·표시를 성공 확인한 적이 **없음**. HUD 수동 표시 등 기존 실차 성공은 사용자 이전 버전 보고 근거임.
- OEM 상태 방송은 송신자를 cryptographic/authenticated하게 확인할 수 없다. `packageName` extra는 필터일 뿐 실제 패키지 소유 증명이 아님.
- 설치된 DiCar Provider exported 확인은 권한/호출 가능성, TBT 조회 기능 확인과 구별한다. 차량 CAN/SPI/ECU 신호 전송 없음.
