package android.os;public class SystemClock{public static long elapsedRealtime(){return 100000L;}}
