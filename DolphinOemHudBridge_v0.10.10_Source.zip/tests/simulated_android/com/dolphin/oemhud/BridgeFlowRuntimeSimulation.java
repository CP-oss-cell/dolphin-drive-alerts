package com.dolphin.oemhud;
import android.os.Bundle;
import android.content.*;
public class BridgeFlowRuntimeSimulation {
  public static void main(String[]args){
    BridgeService bridge=new BridgeService();
    bridge.getSharedPreferences(BridgeLog.STORE,0).edit()
      .putBoolean("enabled",true).putString("nav_package","com.skt.tmap.ku").apply();
    bridge.onCreate();
    Bundle b=new Bundle();b.putInt("KEY_TYPE",10001);b.putInt("NEW_ICON",5);b.putInt("SEG_REMAIN_DIS_AUTO",300);
    Intent i=new Intent().setAction("AUTONAVI_STANDARD_BROADCAST_SEND");
    i.putExtra("KEY_TYPE",10001);i.putExtra("NEW_ICON",5);i.putExtra("SEG_REMAIN_DIS_AUTO",300);
    bridge.registered.onReceive(bridge,i);
    if(BridgeLog.cues!=0 || HudConnector.sent!=0)throw new AssertionError("unauthenticated broadcast must not become HUD cue");
    System.out.println("SIM1 unverified broadcast ignored for auto HUD");
    NavCue raw=NavCue.fromAutonavi(b);
    if(raw==null||raw.distanceMeters!=300)throw new AssertionError("diagnostic decode failed");
    System.out.println("SIM2 decode still available for read-only diagnostics");
    NavCue text=NavCue.fromText("TMAP 화면:com.skt.tmap.ku","300m 앞에서 우회전");
    BridgeLog.cue(bridge,text);
    if(HudConnector.sent!=1)throw new AssertionError("known synthetic cue must reach HUD mock exactly once");
    System.out.println("SIM3 explicit valid parsed cue reaches mock HUD");
    bridge.onDestroy();
  }
}
