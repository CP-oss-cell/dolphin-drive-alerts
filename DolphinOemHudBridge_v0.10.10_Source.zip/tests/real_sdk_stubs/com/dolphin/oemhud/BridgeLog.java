package com.dolphin.oemhud;
import android.content.Context;
final class BridgeLog { static final String STORE = "hud_test"; static void event(Context c,String m) {} }
