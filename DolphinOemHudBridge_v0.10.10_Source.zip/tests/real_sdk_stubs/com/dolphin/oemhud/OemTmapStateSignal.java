package com.dolphin.oemhud;
final class OemTmapStateSignal { static final String PACKAGE = "com.tmap.auto.byd"; }
