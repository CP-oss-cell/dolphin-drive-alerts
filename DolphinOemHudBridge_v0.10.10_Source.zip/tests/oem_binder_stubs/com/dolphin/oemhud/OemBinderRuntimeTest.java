package com.dolphin.oemhud;
import android.content.*;import android.content.pm.*;import android.os.*;import java.util.*;
public final class OemBinderRuntimeTest {
 static class Pref implements SharedPreferences{Map<String,Object> v=new HashMap<>();public Editor edit(){return new Editor(){public Editor putString(String k,String z){v.put(k,z);return this;}public Editor putLong(String k,long z){v.put(k,z);return this;}public void apply(){}};}}
 static class Ctx extends Context {final Pref prefs=new Pref();PackageManager pm=new PackageManager();boolean bind=true,deny=false;int commands=0;int bindCount=0;int unbindCount=0;String descriptor="com.byd.naviserviceapi.INaviService";
 public PackageManager getPackageManager(){return pm;}public SharedPreferences getSharedPreferences(String s,int i){return prefs;}
 public boolean bindService(Intent i,ServiceConnection c,int f){bindCount++;if(deny)throw new SecurityException();if(!bind)return false;c.onServiceConnected(i.component,()->descriptor);return true;}
 public void unbindService(ServiceConnection c){unbindCount++;}}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);System.out.println("PASS "+m);}
 public static void main(String[]args){
 Ctx yes=new Ctx();OemTmapBinderProbe.start(yes);check("AIDL_BOUND_NO_TBT".equals(yes.prefs.v.get("oem_binder_state")),"known AIDL descriptor, no TBT claimed");check(yes.unbindCount==1,"session closed");check(yes.commands==0,"no OEM custom transactions");
 Ctx deny=new Ctx();deny.deny=true;OemTmapBinderProbe.start(deny);check("BIND_DENIED".equals(deny.prefs.v.get("oem_binder_state")),"permission denial reported, no bypass");
 Ctx other=new Ctx();other.descriptor="other.interface";OemTmapBinderProbe.start(other);check("BOUND_DESCRIPTOR_MISMATCH".equals(other.prefs.v.get("oem_binder_state")),"mismatched descriptor rejected");
 Ctx nope=new Ctx();nope.bind=false;OemTmapBinderProbe.start(nope);check("BIND_FALSE".equals(nope.prefs.v.get("oem_binder_state")),"bind false distinct from permission denied");
 Ctx hidden=new Ctx();hidden.pm=new PackageManager(){public ServiceInfo getServiceInfo(ComponentName c,int n){ServiceInfo s=new ServiceInfo();s.exported=false;return s;}};OemTmapBinderProbe.start(hidden);check("BLOCKED_NOT_EXPORTED".equals(hidden.prefs.v.get("oem_binder_state")),"non-exported service not bound");check(hidden.bindCount==0,"blocked gate never invokes bind");
 }}