package com.dolphin.oemhud;import android.content.Context;
public final class NavAccessibilityService {
 public static boolean isReceiverAttached(){return false;}
 public static long receiverConnectedElapsed(){return 0;}
 public static long receiverLastPollElapsed(){return 0;}
 public static boolean requestSafePollRecovery(Context c){return false;}
}
