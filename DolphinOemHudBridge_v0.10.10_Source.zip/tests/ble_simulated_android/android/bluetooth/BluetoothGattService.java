package android.bluetooth;import java.util.*;public class BluetoothGattService{
 private final List<BluetoothGattCharacteristic> chars=new ArrayList<>();private final UUID uuid;
 public BluetoothGattService(){this(UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb"));}
 public BluetoothGattService(UUID u){uuid=u;}
 public UUID getUuid(){return uuid;}
 public void add(BluetoothGattCharacteristic c){chars.add(c);}public List<BluetoothGattCharacteristic> getCharacteristics(){return chars;}
}