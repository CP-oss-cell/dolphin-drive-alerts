package com.dolphin.oemhud;
/** Test-only seam; the actual sensor controller is compiled in run_auto_brightness_typecheck.sh. */
public final class HudAutoBrightness {
    public HudAutoBrightness(android.content.Context context,HudConnector connector){}
    public static boolean clockIsNight(){return false;}
    public void refresh(){} public void clockChanged(){}
    public void stop(){}
}
