package com.dolphin.oemhud;
public final class NavPackageMatcherTest {
    static int n=0;
    static void test(boolean v,String caseName){if(!v)throw new AssertionError(caseName);n++;System.out.println("PASS NAVPKG "+caseName);}
    public static void main(String[] args){
        test(NavPackageMatcher.likely("com.tmap.auto.byd",null),"real OEM TMAP package from firmware manifest");
        test(NavPackageMatcher.likely("com.byd.tmap",null),"OEM TMAP by package");
        test(NavPackageMatcher.likely("com.byd.mapsystem","순정 내비게이션"),"OEM name without nav + Korean label");
        test(NavPackageMatcher.likely("com.unknown.MapUI","地图"),"OEM foreign label");
        test(!NavPackageMatcher.likely("com.dolphin.oemhud","지도"),"ignore ourselves");
        test(!NavPackageMatcher.likely("com.android.systemui","지도"),"ignore system UI");
        test(!NavPackageMatcher.likely("com.messenger.chat","새 메시지"),"ignore messages");
        test(!NavPackageMatcher.likely("com.byd.someapp",null),"ignore unknown BYD app");
        System.out.println("NAV PACKAGE "+n+" PASS");
    }
}
