package com.dolphin.oemhud;
public final class HudBrightnessScheduleTest {
    private static int tested=0;
    private static void verify(boolean yes,String name){tested++;if(!yes)throw new AssertionError(name);}
    public static void main(String[] args){
        int d=HudBrightnessSchedule.DEFAULT_DAY_START,n=HudBrightnessSchedule.DEFAULT_NIGHT_START;
        verify(HudBrightnessSchedule.isNight(0,d,n),"midnight night");
        verify(HudBrightnessSchedule.isNight(419,d,n),"before day boundary");
        verify(!HudBrightnessSchedule.isNight(420,d,n),"day boundary inclusive");
        verify(!HudBrightnessSchedule.isNight(1139,d,n),"last day minute");
        verify(HudBrightnessSchedule.isNight(1140,d,n),"night boundary inclusive");
        verify(!HudBrightnessSchedule.isNight(430,430,1260),"custom day 07:10");
        verify(HudBrightnessSchedule.isNight(1260,430,1260),"custom night 21:00");
        verify(!HudBrightnessSchedule.isNight(1380,1320,360),"overnight daytime");
        verify(!HudBrightnessSchedule.isNight(30,1320,360),"overnight daytime after midnight");
        verify(HudBrightnessSchedule.isNight(361,1320,360),"overnight nighttime");
        verify(!HudBrightnessSchedule.isNight(720,600,600),"invalid equal falls back to default");
        verify(HudBrightnessSchedule.validMinute(-1,420)==420,"negative ignored");
        verify(HudBrightnessSchedule.validMinute(1440,1140)==1140,"overflow ignored");
        verify(HudBrightnessSchedule.validPair(420,1140),"valid pair");
        verify(!HudBrightnessSchedule.validPair(420,420),"equal invalid");
        verify(!HudBrightnessSchedule.validPair(-10,200),"out of range invalid");
        verify("06:05".equals(HudBrightnessSchedule.clockLabel(365)),"label");
        System.out.println("PASS HUD TIME SCHEDULE "+tested+" cases");
    }
}
