package com.dolphin.oemhud;

import java.util.Arrays;
import java.util.List;

public final class NavAppCatalogTest {
    private static int checks=0;
    private static void check(boolean ok,String name){
        checks++;if(!ok)throw new AssertionError(name);
    }
    public static void main(String[] args){
        NavAppCatalog.Entry nav=new NavAppCatalog.Entry("com.byd.autonavi","순정 내비",false);
        NavAppCatalog.Entry hidden=new NavAppCatalog.Entry("com.oem.hidden","OEM 화면",false);
        NavAppCatalog.Entry maps=new NavAppCatalog.Entry("com.google.android.apps.maps","지도",true);
        NavAppCatalog.Entry regular=new NavAppCatalog.Entry("com.example.music","음악",true);
        NavAppCatalog.Entry current=new NavAppCatalog.Entry("com.example.selected","내 차량 내비",false);
        List<NavAppCatalog.Entry> base=Arrays.asList(regular,hidden,nav,maps,current,nav,
            new NavAppCatalog.Entry("com.dolphin.oemhud","HUD Bridge",true));
        List<NavAppCatalog.Entry> visible=NavAppCatalog.visible(base,"",false,"com.example.selected");
        check(visible.size()==4,"normal list excludes hidden/system and own app and duplicates");
        check(visible.get(0).packageName.equals("com.example.selected"),"selected app stays visible and first");
        check(visible.get(1).navigationCandidate,"navigation first among others");
        check(NavAppCatalog.visible(base,"oem",false,"").size()==0,"hidden system excluded when toggled off");
        check(NavAppCatalog.visible(base,"oem",true,"").size()==1,"hidden system included on toggle");
        check(NavAppCatalog.visible(base,"순정",false,"").size()==1,"Korean label search");
        check(NavAppCatalog.visible(base,"google.android",false,"").size()==1,"package search");
        check(NavAppCatalog.visible(base,"MaPS",false,"").size()==1,"case insensitive search");
        check(NavAppCatalog.visible(base," ",true,"").size()==5,"all list deduplicated");
        check(NavAppCatalog.visible(base,"",true,"").size()==5,"default all list can include unlaunchable OEM apps");
        check(!new NavAppCatalog.Entry("com.oem.disabled","순정 내비",false,false).enabled,"disabled app shown with explicit status");
        check(NavAppCatalog.visible(null,"",false,"").isEmpty(),"null list safe");
        check(new NavAppCatalog.Entry("com.foo.bar"," ",true).label.equals("com.foo.bar"),"empty label fallback");
        check(NavAppCatalog.visible(base,"지 도",false,"").isEmpty(),"no fuzzy guesses");
        check(NavAppCatalog.visible(base,"",false,"com.example.selected").get(0).packageName.equals("com.example.selected"),"non launcher chosen persists");
        System.out.println("PASS NavAppCatalogTest "+checks+" assertions");
    }
}
