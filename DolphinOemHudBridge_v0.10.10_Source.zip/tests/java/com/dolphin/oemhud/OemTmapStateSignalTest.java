package com.dolphin.oemhud;
public final class OemTmapStateSignalTest {
 private static int pass;
 static void ok(boolean good,String reason){if(!good)throw new AssertionError(reason);pass++;System.out.println("PASS OEM STATE "+reason);}
 public static void main(String[] args){
  OemTmapStateSignal n=OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.tmap.auto.byd",1);
  ok(n!=null,"valid OEM navigation state accepted");
  ok(n.isNavigationState(),"navigation distinguished from map UI status");
  ok(n.diagnostic().contains("TBT 방향/거리 아님"),"explicitly not a TBT cue");
  OemTmapStateSignal m=OemTmapStateSignal.read(OemTmapStateSignal.MAP_ACTIVITY_STATE,"com.tmap.auto.byd","0");
  ok(m!=null,"map activity state accepted");
  ok(!m.isNavigationState(),"map activity not coerced into navigation");
  ok(OemTmapStateSignal.read("AUTONAVI_STANDARD_BROADCAST_SEND","com.tmap.auto.byd",1)==null,"unsupported AutoNavi broadcast rejected");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.other.nav",1)==null,"spoofed package field rejected");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,null,1)==null,"missing package rejected");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.tmap.auto.byd",null)==null,"missing state rejected");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.tmap.auto.byd","  ")==null,"blank state rejected");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.tmap.auto.byd","\n1\r")!=null,"state sanitized");
  ok(OemTmapStateSignal.read(OemTmapStateSignal.NAVIGATION_STATE,"com.tmap.auto.byd",new String(new char[100]).replace('\0','x')).reportedState.length()==40,"diagnostic bounded");
  System.out.println("OEM NAV STATE "+pass+" PASS; no turn direction output is created.");
 }
}
