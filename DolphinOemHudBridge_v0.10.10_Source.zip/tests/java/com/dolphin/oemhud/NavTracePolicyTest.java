package com.dolphin.oemhud;
public final class NavTracePolicyTest {
  static int passed=0;
  static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);passed++;}
  public static void main(String[]args){
    check(NavTracePolicy.OEM.equals(NavTracePolicy.group("com.tmap.auto.byd")),"OEM");
    check(NavTracePolicy.GENERAL.equals(NavTracePolicy.group("com.skt.tmap.ku")),"general");
    check(NavTracePolicy.OTHER.equals(NavTracePolicy.group("com.fake.tmap.ku")),"not fake");
    check(NavTracePolicy.OTHER.equals(NavTracePolicy.group(null)),"null");
    check(NavTracePolicy.GENERAL.equals(NavTracePolicy.fromCueSource("TMAP 화면:com.skt.tmap.ku")),"cue general");
    check(NavTracePolicy.OEM.equals(NavTracePolicy.fromCueSource("TMAP 알림:com.tmap.auto.byd")),"cue OEM");
    check(NavTracePolicy.OTHER.equals(NavTracePolicy.fromCueSource("AutoNavi 방송")),"unverified");
    check("NO_VISIBLE_TEXT".equals(NavTracePolicy.stage(false,false,false,false)),"no text");
    check("DISTANCE_ONLY".equals(NavTracePolicy.stage(true,false,true,false)),"distance only");
    check("DIRECTION_ONLY".equals(NavTracePolicy.stage(true,true,false,false)),"dir only");
    check("BOTH_TOKENS_UNPAIRED".equals(NavTracePolicy.stage(true,true,true,false)),"not parsed despite words");
    check("VALID_CUE".equals(NavTracePolicy.stage(true,true,true,true)),"parsed");
    check("NO_INPUT_EVENTS".equals(NavTracePolicy.diagnosis(0,0,0,0,0,0)),"no events");
    check("INPUT_NO_TEXT".equals(NavTracePolicy.diagnosis(2,0,0,0,0,0)),"no text event");
    check("DISTANCE_WITHOUT_DIRECTION".equals(NavTracePolicy.diagnosis(2,1,0,1,0,0)),"only distance");
    check("UNPAIRED_OR_REJECTED".equals(NavTracePolicy.diagnosis(2,1,1,1,0,0)),"paired words not verified");
    check("PARSED_NOT_QUEUED".equals(NavTracePolicy.diagnosis(2,1,1,1,1,0)),"parsed not queued");
    check("QUEUED_NOT_HUD_CONFIRMED".equals(NavTracePolicy.diagnosis(2,1,1,1,1,1)),"queue not screen");
    System.out.println("PASS NavTracePolicy "+passed+" cases");
  }
}
