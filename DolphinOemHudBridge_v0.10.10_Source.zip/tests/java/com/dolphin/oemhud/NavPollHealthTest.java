package com.dolphin.oemhud;
public final class NavPollHealthTest {
    static int n;
    static void check(boolean v){if(!v)throw new AssertionError("case "+(++n));n++;}
    public static void main(String[] args){
        check(NavPollHealth.OFF.equals(NavPollHealth.classify(false,false,0,0,100000)));
        check(NavPollHealth.DISCONNECTED.equals(NavPollHealth.classify(true,false,0,0,100000)));
        check(NavPollHealth.STARTING.equals(NavPollHealth.classify(true,true,1000,0,4000)));
        check(NavPollHealth.STALE.equals(NavPollHealth.classify(true,true,1000,0,22000)));
        check(NavPollHealth.ACTIVE.equals(NavPollHealth.classify(true,true,1000,1500,20000)));
        check(NavPollHealth.STALE.equals(NavPollHealth.classify(true,true,1000,1500,21600)));
        check(NavPollHealth.STARTING.equals(NavPollHealth.classify(true,true,100000,90000,101000)));
        check(NavPollHealth.STARTING.equals(NavPollHealth.classify(true,true,1000,1500,900)));
        check(NavPollHealth.allowRepair(NavPollHealth.STALE,100000,0));
        check(!NavPollHealth.allowRepair(NavPollHealth.OFF,100000,0));
        check(!NavPollHealth.allowRepair(NavPollHealth.STALE,100000,90000));
        check(NavPollHealth.allowRepair(NavPollHealth.STALE,160000,90000));
        check(!NavPollHealth.allowRepair(NavPollHealth.STALE,0,0));
        check(NavPollHealth.userLabel(NavPollHealth.STALE).contains("복구"));
        System.out.println("PASS NavPollHealth "+n+" cases (actual production Java)");
    }
}
