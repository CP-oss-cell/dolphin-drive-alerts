package com.dolphin.oemhud;
public final class WindowProbePolicyTest {
    private static int passed=0;
    private static void check(String name,boolean yes){
        if(!yes)throw new AssertionError(name);
        System.out.println("PASS WINDOW " + name);passed++;
    }
    public static void main(String[] a){
        check("no request cannot capture",!WindowProbePolicy.canSample(100,0,0,0));
        check("beginning can capture",WindowProbePolicy.canSample(100,8100,0,0));
        check("first follow-up too early",!WindowProbePolicy.canSample(120,8100,1,100));
        check("follow-up after 250ms",WindowProbePolicy.canSample(350,8100,1,100));
        check("bounded by time",!WindowProbePolicy.canSample(8101,8100,5,7800));
        check("bounded by sample count",!WindowProbePolicy.canSample(500,8100,WindowProbePolicy.MAX_SAMPLES,0));
        check("unknown window owner",WindowProbePolicy.safePackage(null).equals("UNKNOWN"));
        check("package name preserved",WindowProbePolicy.safePackage("com.tmap.auto.byd").equals("com.tmap.auto.byd"));
        check("control characters scrubbed",WindowProbePolicy.safePackage("com.x\nroute=Home").equals("com.x?route?Home"));
        check("long owner clipped",WindowProbePolicy.safePackage("p".repeat(200)).length()==90);
        check("normal poll every 1.8s",WindowProbePolicy.pollInterval(1)==1800);
        check("empty poll backs off to 6s",WindowProbePolicy.pollInterval(4)==6000);
        check("read-only sample window cap",WindowProbePolicy.MAX_WINDOWS_PER_SAMPLE<=12);
        System.out.println("WINDOW PROBE POLICY "+passed+" PASS");
    }
}
