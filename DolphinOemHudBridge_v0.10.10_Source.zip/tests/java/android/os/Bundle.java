package android.os;
import java.util.HashMap;
public class Bundle extends HashMap<String,Object> {
    public void putInt(String k,int v){put(k,v);}
    public void putString(String k,String v){put(k,v);}
}
