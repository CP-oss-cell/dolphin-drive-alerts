package android.util;public class Log{public static int w(String a,String b){return 0;}public static int i(String a,String b){return 0;}}
