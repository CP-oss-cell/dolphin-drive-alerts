# byd2.zip 빌드 실패 원인·수정 내역 (v0.10.3)

## 확인한 실제 GitHub 로그
- CI `:app:compileDebugKotlin` 통과, `:app:compileDebugJavaWithJavac` 실패.
- `app/src/main/java/com/dolphin/oemhud/OemVehicleIpcProbe.java:31`
- `cannot find symbol: variable permission; location: ProviderInfo`
- 실패 원인: Android의 `ProviderInfo`는 `readPermission`, `writePermission`이 있지만 `permission` 필드는 없음. 기존 로컬 모의 SDK가 실제로 존재하지 않는 permission 필드를 정의하여 미탐지.
- 후처리 Gradle 캐시 오류는 주요 원인이 아니며, 본 소스 수정과 직접 관련 없음.

## 개선
1. 없는 `i.permission` 참조 제거. 기존 읽기 전용 Manifest 메타데이터 조회 기능 및 카운트 유지.
2. 가짜 Android 클래스에서 잘못된 필드 제거, 읽기/쓰기 permission 2건 카운트 테스트 추가.
3. `tools/check_providerinfo_api.py` 정적 회귀 차단 검사와 `tools/run_android_sdk_providerinfo_check.sh` 실제 Android SDK 34 컴파일 게이트 추가.
4. 앱 식별자 동일, versionCode 22→23. 기존 코드 기반 BLE·전송·자체 HUD 테스트 불변.

## 검증 제한
- 이 보고서의 오프라인 테스트는 실제 APK 빌드를 대신하지 않음. Android SDK 34 설치 및 `:app:assembleDebug`는 GitHub Actions에서 확인해야 함.
- 순정 내비 TBT를 실차 HUD에 자동 표시하는 문제는 별도로 미해결임.
