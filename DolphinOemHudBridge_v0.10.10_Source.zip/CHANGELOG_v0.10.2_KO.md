# v0.10.2 / HUD-RE-012 최종 심화 통합

- 순정 2602/2606 원본 APK의 실제 NAVIGATION_STATE_CHANGED, MAP_ACTIVITY_STATE_CHANGED 상태 방송을 수신하고 안내 TBT와 엄격히 구분.
- 순정 내비 또는 자동 감지에서 AutoNavi(KEY_TYPE=10001) 미확인 호환 방송을 원본 TBT로 수용하지 않도록 수정. 서드파티용 기존 호환 경로는 유지.
- 접근성 view ID를 현재 drawable ID로 오인하는 방향 추론 제거. 이미지 기반 TBT의 원본 방향은 미확정으로 기록.
- DiCarServer의 설치된 Provider 및 ClusterActivity의 Manifest 메타데이터를 읽기 전용 조회. 서비스 메서드/차량 신호 미호출.
- HUD 연결·우회전 수동 시험·MCon 프로토콜·자동밝기 관련 7개 소스 SHA256 동일성 확인.
- 정적 교차 연구 001~011을 `research/HUD-RE-012`로 정리, 근거 재검증 스크립트 추가.
- 타깃 Android 10 (API29), 기존 앱 패키지 `com.dolphin.oemhud` 유지, versionCode=22.
- 순정 TMAP의 구조화된 TBT 외부 수신 API는 여전히 **미발견/미검증**. 실차 자동 HUD 표시를 완료했다고 주장하지 않음.
