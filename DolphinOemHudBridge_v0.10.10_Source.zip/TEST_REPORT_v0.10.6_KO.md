# Dolphin OEM HUD Bridge v0.10.6 — 로컬 검증 보고서

- 기준: v0.10.5(versionCode25) → v0.10.6(versionCode26).
- Java UI 및 접근성 타입 검사: 오프라인 Android 서명 스텁 기반 통과. 실제 Android SDK 빌드는 아직 실행하지 않음.
- 소스 사전검사: 118/118 통과.
- 새 `WindowProbePolicy` 실제 Java JVM 검사: 13개 통과.
- 기존 안내 파서: 67개 통과.
- BLE 런타임 모의검사: 59개 통과.
- 서비스·실제 BLE 소스 결합 모의검사: 15개 통과.
- 시간표 경계: 17개 통과. 조도센서 히스테리시스: 5개 통과.
- 핵심 8개 파일 원본 SHA256 100% 동일: `MconHudQProtocol`, `MconBleProfiles`, `HudConnector`, `HudAutoBrightness`, `HudBrightnessSchedule`, `NavCue`, `BridgeService`, `OemTmapBinderProbe`.
- 사용자 정차 수동 시험에서만 창 패키지·타입·레이어·사각형 영역을 8초간 기록하도록 제어. 실제 화면 오버레이가 감지됐다는 증거는 아직 없음.
- 원본 순정 TMAP TBT 읽기 경로는 미해결. 앱 및 차량 검증되지 않았음.

**경고:** 실차에서 정상 안내 연동/새 검은 중앙 창 감지가 성공했다는 주장은 없음. 이 파일은 설치 APK가 아니라 GitHub Actions 빌드 소스다. 기존 앱 설치본과 Android debug 서명키가 다르면 업데이트 설치할 수 없음.
