# v0.9.7 — GitHub YML/소스 ZIP 비교 오류 수정

- 2026-11-02 16:41 KST GitHub Actions 로그: ZIP 압축 해제 성공 후 `cmp -s` 검사에서 exit 1 발생. Gradle APK 빌드 미진입.
- 이전 배포 파일 검증: ZIP 내부 YML SHA-256과 독립 배포 YML SHA-256은 동일했음. GitHub 체크아웃 파일이 달랐던 원인은 배포 브랜치/실제 업로드 불일치 가능성 포함, 로그만으로 단정 불가.
- 개선: 두 파일의 바이트 동일성 검사는 완전히 제거. `RELEASE_BUNDLE.json`과 `app/build.gradle`의 versionName/code, 필수 수신기·APK UI 소스 일치 여부 검사로 대체.
- v0.9.7/versionCode 17로 이전 산출물 오용 방지. 앱 기능 소스는 v0.9.6 유지.
- CI 작업명과 업로드 ZIP명을 한 버전으로 고정. 실제 APK 버전과 선택 화면이 들어갔는지 빌드 후 검증.
- 실제 GitHub Actions 및 실차 안내 출력 성공은 본 파일의 로컬 검사만으로 주장하지 않음.
