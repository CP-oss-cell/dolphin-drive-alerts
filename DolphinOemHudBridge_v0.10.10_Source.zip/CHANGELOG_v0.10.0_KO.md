# v0.10.0 — 순정 TMAP TBT IPC 경계 연구 통합

- HUD-RE-005: 2602/2606 TMAP, DiCarServer, MCon K 원본 DEX 총 8개 교차 인덱스 및 분석 결과를 소스에 동봉.
- 순정 TMAP `NaviService` Binder의 설치 여부·exported·permission·descriptor를 읽기 전용으로 자동 진단.
- `AIDL_BOUND_NO_TBT` 상태를 도입하여 Binder 연결과 TBT 데이터 접근을 구분.
- 기존 AutoNavi 방송은 순정 TMAP의 실제 출력으로 미확인임을 UI 진단에 표시.
- MCon K BLE 모델별 UUID, 설정, 접근성/알림 보조 수신 및 다크 모드 유지.
- 새 차량 제어 코드, 순정 앱 패치, 부정확한 Binder transact, CAN/SPI 전송 없음.
- 실제 순정 내비 회전·거리 실시간 수신 및 실물 HUD 표시: **미완료**.
