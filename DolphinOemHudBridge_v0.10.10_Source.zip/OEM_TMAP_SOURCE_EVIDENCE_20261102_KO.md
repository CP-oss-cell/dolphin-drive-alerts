# 순정 TMAP 원본 검토 — 2026-11-02

대상: 연결된 사용자 Google Drive 펌웨어 원본 `2602/system/system/app/BydAutoTMap/BydAutoTMap.apk`.
SHA-256: `a5fced7c9b2dcda8df920ff9c123e04e0c5c3b2fb9b9c32b595d2e50082780df`.

원본 AndroidManifest.xml (binary AXML 직접 분석):
- package `com.tmap.auto.byd`
- versionName `1.0.3.R`
- service `com.tmap.auto.byd.NaviService` / exported true / intent action `com.tmap.auto.byd.NaviService`
- activity `com.skt.tmap.auto.activity.TmapAutoNaviActivity` / exported true
- provider `com.skt.tmap.util.ClusterContentProvider` / exported true / authority `com.skt.tmap.auto.clustercontentprovider`

원본 classes.dex 문자열/타입 인덱스 직접 확인:
- `com.skt.tmap.auto.customView.TmapAutoTbtView`
- `com.skt.tmap.auto.customView.TbtDistanceTextView`
- `com.byd.naviserviceapi.INaviService`
- `android.car.navigation.CarNavigationStatusManager`

이 증거는 순정 TMAP 앱과 내부 TBT 구성요소가 존재함을 입증하지만, 외부 앱에서 읽을 수 있는 통신 계약/권한/실차 이벤트를 입증하지 않음. 무검증 컴포넌트 접근·Binder transact·차량 신호 송신은 구현하지 않음.
