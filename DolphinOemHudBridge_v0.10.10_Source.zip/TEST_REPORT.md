# v0.9.2 실차 로그 기반 수정 검증

- 입력: 2026-11-02 HUD 진단 ZIP (`TBT 0`, BLE GATT 16/0, 최종 접근성 비활성)
- 소스 사전 검사 38/38 통과
- TBT 파서 45개 통과
- HUD 설정 패킷 12개 통과
- 내비 앱 패키지/표시 이름 분류 7개 통과
- 실제 `HudConnector` 소스 모의 GATT 테스트 45개 통과 (중복 연결 차단 2개 추가)
- 기존 서비스/알림 수신 경로 모의 실행 통과
- 실제 `BridgeService` + 실제 `HudConnector` 결합 7개 통과
- 대시보드 Java 오프라인 API 스텁 타입 검사 통과
- ADB Kotlin 오프라인 API 스텁 타입 검사 통과
- JUnit Android 리소스 병합 사전 검사 통과
- Android `assembleDebug` **미실행** / 실차 TBT·HUD 화면 표시 **미검증**

## 주의
모의 Android 스텁 테스트는 화면 접근성 서비스가 순정 앱에서 실제로 데이터를 얻는다는 증거가 아님.

---
이전 테스트 기록은 git history / 이전 v0.9.1 빌드팩에서 확인할 수 있음.

## v0.9.3 앱 선택 추가 검사 (2026-11-02)

- 앱 목록: 설치된 앱 이름·아이콘·패키지 표시, 이름·패키지 검색, 내비 후보 우선, 숨김 OEM 시스템 앱 토글
- 기존 입력 메뉴 제거, 동일 `nav_package` 저장키 유지, `자동 감지` 복원
- Java 단위: NavAppCatalogTest 13개 검증 (중복 제거, 비공개 앱, 한국어/영문 검색, 선택 우선)
- Java UI Android 대체 스텁: MainActivity + NavAppPickerActivity 타입 검사 완료
- Android APK 전체 CI 빌드 및 실물 내비/HUD 표시: 검증하지 않음
