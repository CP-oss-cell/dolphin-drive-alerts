# HUD-RE-012 최종 심화 · 소스 통합

대상: BYD Dolphin 글로벌 2602, 원본 순정 TMAP TBT → TPLAY HUD Q.

- `TECHNICAL_REPORT_KO.md`: RE-001~011 교차 결론, 미확정 경계, v0.10.2 수정 사항.
- `evidence/RESEARCH_001_012_DECISION_MATRIX.csv`: 이전 연구 차수별 직접 확인 범위와 최종 판단.
- `evidence/VERIFIED_BASE_COMPONENT_SHA256.json`: 실차에서 성공했던 HUD BLE/프로토콜 관련 파일의 원본 보존 증거.
- `HUD-RE-010/evidence`, `HUD-RE-011/evidence`: 선행 분석에서 실제 검증한 일부 표(원본 APK 제외).
- `tools/validate_re012_evidence.py`: README/코드/무변경 SHA 검증.

순정 TBT 앱 간 직접 수신과 실차 자동 HUD 표시는 **미해결**. 실제 문제를 해결했다고 표시한 빌드가 아니다.
