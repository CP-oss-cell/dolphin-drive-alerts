# HUD-RE-012 — 최종 심화 교차 분석 · v0.10.2 소스 통합

**연구일:** 2026-11-03 (KST)  
**가장 중요한 개발 목적:** 글로벌 2602 `com.tmap.auto.byd` 순정 내비의 `nTBTTurnType` + `nTBTDist`를 실물 **TPLAY HUD Q**에 자동 표시. 일반 TMAP·네이버지도·아틀란·카카오맵은 부가 기능.

## I. 실차에서 입증된 사실과 원본 경계

- 사용자 보고: TPLAY HUD Q GATT `FFEA`/TX `FFF2`/RX `FFF1`, 수동 밝기 및 우회전 300m 시험 표시 성공. v0.10.1 HUD 송신기·설정·자동밝기 코드는 그대로 보존했다. 기존 실차 로그의 GATT 성공을 실제 자동 내비 출력으로 오인하지 않았다.
- 원본 TMAP 2602/2606은 **구조화된 TBT 숫자를 앱 내부 RGData/ViewModel/LiveData에 유지**하지만, 외부 앱이 다음 회전 방향과 회전까지 거리를 묶어서 구독하는 읽기 전용 IPC는 확인되지 않았다.
- `NaviService` Binder AIDL에는 74개 분기(각 버전)와 콜백은 있다. `reqNaviInfo`는 경로/목적지, `reqNaviRemainTimeDistance`는 남은 시간·총 주행 거리 관련 수치이고 **다음 회전 전용 TBT 쌍이 확인되지 않는다.** 트랜잭션 번호를 임의로 TBT라고 부르거나 호출하지 않는다.
- RE-006에서 **실제 송신 코드가 검증된 두 방송은 상태 전용**: `byd.intent.action.NAVIGATION_STATE_CHANGED`와 `byd.intent.action.MAP_ACTIVITY_STATE_CHANGED` (`packageName`,`state` 등). 원본 두 APK 모두 `AUTONAVI_STANDARD_BROADCAST_SEND` 직접 문자열 참조 0건. 이 부재는 검사한 DEX 범위에 한정한다.
- RE-008/010: 첫 번째·두 번째 TBT 화살표는 **동적으로 변경되는 ImageView**, 거리 표기는 **TbtDistanceTextView**. TBT 화살표는 조사한 화면에서 접근성 설명 및 개별 View ID가 없다. `getViewIdResourceName()`으로 현재 drawable를 읽을 수 없다.
- RE-009/010: `tbt_1_st_N` 이름 65종, 코드끼리 이미지 바이트가 동일한 그룹 9개. 2602/2606 Android 리소스 ID는 달라 숫자를 하드코딩하면 안 된다. 이미지 인식만으로 원본 65코드 전부를 구별할 수는 없다.
- RE-011: `DiCarServer.apk`의 `CarServiceProvider`/`VehicleServiceProvider`는 서비스 Binder 중계이며, SPI 등록 23개/고유 인터페이스 메서드 91개. **등록 목록에 TBT 수신 인터페이스 직접 근거 없음.** `IAppFocusService`의 패키지 정보는 다음 회전 데이터가 아니다.
- `ClusterActivity`/`android.car.cluster.NAVIGATION`은 **지도 화면을 계기판에 렌더링하는 경로**이며, HUD Bridge가 TBT를 구독하는 경로로 입증되지 않았다.

## II. 이번 빌드에서 바로잡은 실제 코드 오류

| 수정 | v0.10.1 | v0.10.2 | 안전/검증 |
|---|---|---|---|
| **AutoNavi를 순정 TBT로 오인** | OEM 선택 시에도 `KEY_TYPE=10001`을 HUD에 전달할 수 있음 | 순정 패키지를 선택하거나 자동 선택인 경우 호환 방송을 무시·계수; 다른 내비의 레거시 후보만 보존 | 가짜 순정 TBT 출력 차단 |
| **OEM 내비 상태 미관측** | 실제 OEM 방송 등록 없음 | 검증된 두 액션을 수신, `packageName`/`state` 확인 후 상태만 기록 | 송신자는 OS API만으로 인증할 수 없음. TBT 추출 아님 |
| **View ID에서 drawable 방향 추정** | 접근성에서 `getViewIdResourceName()`을 방향 후보로 연결 | 해당 연결 완전 제거; 원본 거리 전용 뷰/라벨 없는 이미지의 개수만 진단 | 거짓 화살표 추론 제거 |
| **DiCarService 접근 가능성 추측** | 원본 Binder 경계만 확인 | DiCar 공개 Provider와 OEM `ClusterActivity`의 **설치 Manifest 정보만** 자동 읽음 | `Provider.query`, Binder `transact`, 차량 메서드 실행 없음 |
| **실차 성공 BLE 보존** | 수동 HUD 표시 성공 | `HudConnector`, MCon 프로토콜/프로필, 설정, 자동밝기 코드는 **원본과 SHA-256 동일** | 회귀 위험 최소화 |

## III. 잔여 P0 기술 경계 및 실제 성공 기준

**앱 내부 TBT 원본** → **외부 앱이 접근 가능한 검증된 구조화 TBT 수신 경로** [여전히 미확정] → **MCon HUD 메시지 구성** [실차 수동 성공] → **실물 HUD 표시** [자동 안내 미완료].

후보별 판정:

1. 공개 `NaviService` AIDL: 일부 경로 정보 수신 가능성은 있지만 다음 회전 방향/거리 반환/콜백 미확정. 무근거 Binder 명령 전송 금지.
2. DiCar SPI 제공자: 장치 메타데이터만 조회. 권한·Binder 소유자·필드별 매핑이 없으므로 TBT 소스가 아니다.
3. Android Auto CarNavigationStatusManager/ClusterActivity: 내비→계기판 렌더러 송신·Activity 배치이지 임의 타 앱의 TBT 수신 API가 아니다.
4. Android 10 접근성 텍스트: 거리는 보일 수 있으나, 방향 화살표의 drawable/의미가 노출되지 않으면 자동 TBT 복원 불가. 현재 소스는 값을 추측하지 않는다.
5. Android 10 `MediaProjection`: 명시적 **매 세션 사용자 동의**가 필요한 보조 화면 캡처 경로. 무인 시동 자동 실행의 해결책으로 간주하지 않는다. 정확도·차량 화면 캡처 지원을 입증하지 못해 본 릴리스에는 넣지 않는다.
6. 제조사 서명·OEM 앱 내부 코드 수정·루트 주입: 제한을 피할 수 있다고 단정하지 않으며 이번 소스의 일반 사용자 기능에 포함하지 않는다.

**실차 자동 성공 판정 조건**: 순정 TMAP으로 실제 경로 안내 시 유효한 **현재 회전 유형 + 해당 회전까지 거리**가 실시간 들어오고, 같은 시점의 데이터만 HUD 프레임에 담겨 기기가 실제 표시해야 한다. 현재는 **미달**.

## IV. 안전 원칙 · 출처 및 재현

- 차량 CAN/SPI/ECU, 순정 계기판 표시, OEM 내비 설정 및 경로를 변경하지 않는다. 연구에 임의의 Binder 트랜잭션이 없다.
- 앱이 자동으로 확인하는 DiCar Provider는 `PackageManager`의 설치 선언에 한정. `exported=true`는 호출 권한 또는 TBT 제공을 의미하지 않는다.
- OEM 방송은 동적 일반 방송이므로 발신자 인증이 되지 않는다. 안내값으로 승격하지 않으며 화면/진단에 '상태/TBT 아님'을 표시한다.
- 프로젝트 내 `tools/validate_re012_evidence.py`로 증거·실차 검증 코드의 무변경 해시와 상태 처리 경계를 검사한다. 이는 정적 코드 검증이지 차량 성공 검증이 아니다.
- 기존 독립 연구팩 `/Dolphin OEM HUD Bridge/`의 RE-001~011에 원본 분석 자료가 보관되어 있다. 이번 소스에는 관련 요약과 선택된 CSV/JSON 증거만 포함한다. 저작권이 있는 OEM APK, MCON K APK, 펌웨어 파일은 재배포하지 않는다.

**검증과 한계:** Android SDK·실차 장치가 없는 실행환경이므로 Gradle 실제 APK 컴파일과 실차 TBT 자동 표시를 검증했다고 말하지 않는다. MCon BLE/구조 분석의 기기 작동 범위는 사용자 보고에 근거한다.

## V. 플랫폼 문서

- Android Automotive Cluster API: https://source.android.com/docs/automotive/displays/cluster_api
- AccessibilityNodeInfo.getViewIdResourceName: https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo
- Android 10 화면 캡처 동의: https://source.android.com/docs/core/permissions/restricted-screen-reading
- MediaProjection: https://developer.android.com/media/grow/media-projection
