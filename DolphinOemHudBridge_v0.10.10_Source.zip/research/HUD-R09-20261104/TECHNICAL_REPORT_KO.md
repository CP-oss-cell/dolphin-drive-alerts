# HUD-R09 — BYD 돌핀 HUD 심화 교차분석 및 v0.10.4 구현 근거

연구일: 2026-11-04 | 차량: 한국 BYD Dolphin Standard, 글로벌 2602, Android 10 DiLink 3 | HUD: TPLAY HUD Q | 기존 v0.10.3(versionCode23) → 신규 v0.10.4(versionCode24)

## 1. 근거 출처와 판단 경계

- 사용자 실차 사진(19:20) 및 `DolphinOemHud_20261104_193315.zip`, R08 보고서: 자동 밝기 **실차 정상**(이때 시간대 대체 방식); 순정 TMAP HUD **미표시**.
- R08 기록: FFF2 GATT 설정·밝기 위주의 완료 59 / 오류 1. OEM 상태방송 24회. 접근성 이벤트 누적 2353회 / 화면트리 조회 누적 684회 / 유효 방향-거리 해석 0회 / 자동 안내 HUD 접수 0회. GATT 완료 59회는 자동 TBT 출력 성공이 아니다.
- `research/HUD-RE-012/TECHNICAL_REPORT_KO.md`와 HUD-RE-001~011 종합: 원본 TMAP 내부 `RGData.stGuidePoint.nTBTTurnType / nTBTDist`는 정적 확인. 순정 상태방송은 TBT가 아니며, `INaviService` Binder 연결은 안내값 수신이 아니다. 계기판 렌더링/V2V 내부 소비자 경로는 외부 안드로이드 앱의 공개 읽기 전용 구독 경로가 아니다.
- R01~R07 차수별 확인: 문자열 기반 방향-거리 오결합 가능성, 미인증 호환방송, 누락된 BLE 상태별 계측, 재시작 후 만료·덮어쓰기. 아직 모두 실차 자동 길안내 성공 근거가 아니다.

## 2. 이번 연구의 새 결론: 센서/시간표 우선순위가 기능 요구에 직결

기존 코드 `HudAutoBrightness.clockIsNight()`는 07:00~19:00를 고정 사용했고 메뉴에서 조정할 수 없었다. 또한 화면의 '자동'만으로 센서 기반 동작인지 시간대 대체인지 사용자가 쉽게 알기 어려웠다. 사용자 11/04 실차 정상 확인의 **입력 원인**은 '시간대 대체'다. 센서 기반 광량 적응의 실차 성공으로 확대해서는 안 된다.

신규 동작:

1. `자동 · 조도 센서 우선 (시간표 대체)` = 유효한 조도센서 샘플이 있으면 기존 20/85 lux 히스테리시스 유지. 센서가 없거나 120초 이상 샘플이 없으면 **사용자 지정 주간/야간 시작 시간표** 사용.
2. `자동 · 사용자 시간표만` = 센서 등록하지 않고 장치의 **현지 시각**으로만 주간/야간 전환. 순정 차량의 전조등/ECU/위치정보는 사용하지 않는다.
3. `고정 밝기` = 주간 밝기 수준을 항상 사용. 기존 로직 유지.
4. 별도 주간/야간 시작 시각 **24시간 시각 선택기(TimePickerDialog)**, 기본 07:00·19:00. 자정을 넘는 시간표도 지원하고 시작 시각 두 개가 같으면 저장 거부.
5. 설정은 앱 SharedPreferences에 저장, 기존 `BridgeService.ACTION_BRIGHTNESS`를 통해 한 번에 반영. 엔진의 60초 주기 검사 및 Android 시스템의 시간/시간대/날짜 변경 방송을 처리. 실제 전환은 Android 스케줄링에 따라 지연될 수 있어 초 단위 정확성은 보장하지 않는다.
6. BLE 재연결에서 시간표로 계산한 현재 밝기를 사용하되 MCon HUD 방향 패킷 및 GATT 서비스/특성 프로파일과 설정 바이트 인코더는 원본 유지.

## 3. R08 실차에서 새로 확인한 진단상의 맹점 및 수정

- 기존 `a11y_runtime_connected=true`는 과거 연결만 뜻하고, 오전 누적 2353회가 19:20 실시간 TBT 수신을 증명하지 않는다.
- 기존 폴링은 화면 문자열이 빈 경우 횟수·시각을 갱신하지 않아 **현재 순정 내비 화면이 비가시 상태**인지 수신기가 멈춘 것인지 구분하기 어려웠다.
- 신규: 세션 시작일시, 이번 세션 신규 이벤트/조회 횟수, 마지막 조회 **시도/성공/빈 화면** 시각, 마지막 실제 이벤트 시각, 이전 세션 최종 이벤트 시각을 개인정보 비수집 카운터/타임스탬프로 추가.
- 대시보드는 과거 누적 카운터와 최근 30초 이벤트/폴링을 구분한다. 다만 '조회 중'은 실제 회전·거리 수신이 아니다. 텍스트나 경로/좌표 원본은 신규 진단 값에 저장하지 않는다.

## 4. 버전별 실제 수정 범위

변경: `HudAutoBrightness.java`, `HudConnector.java`(replay 시 시간표 적용만), `BridgeService.java`(시간표 저장·시간변경 수신), `MainActivity.java`(메뉴·진단), `NavAccessibilityService.java`(현재 생존시간 계측), 신규 `HudBrightnessSchedule.java`.

**절대 변경하지 않은 검증 핵심:** `MconHudQProtocol.java`, `MconBleProfiles.java`, `HudSettingsProtocol.java`, `NavCue.java`, `OemTmapBinderProbe.java`는 v0.10.3과 SHA-256 동일. `COMPONENT_DIFF_SHA256.json`에 10개 주요 파일 비교를 제공한다.

## 5. 가설 반증 및 남은 미해결 과제

- 가설 'GATT 완료 59회면 자동 내비 안내는 출력되었어야 한다': **반증** — 실제 `nav_parsed_count=0`, `nav_tbt_hud_attempts=0`; 59회는 주로 설정 프레임.
- 가설 'OEM 상태 방송 24회면 회전 정보를 읽은 것이다': **반증** — 검증된 두 OEM 방송은 지도/내비 상태만 전달.
- 가설 'Binder 접속 성공 = 내비 안내 수신 성공': **반증** — 인터페이스 descriptor 바인딩 확인만 존재.
- 가설 '접근성 2353회 = 19시대에도 방향/거리 실시간 취득': **입증되지 않음** — 누적이며 사진/로그는 19시대 방향·거리 수신을 보여주지 않는다.
- 가설 '자동 밝기 정상 = 조도 센서 정상': **입증되지 않음** — 시간대 대체 정상 확인. 사용자가 센서 전용 작동을 확인한 것은 아니다.
- 미해결 P0: 글로벌 2602의 원본 TBT 생산자→외부 앱 읽기 경로. 원본 값이 공개 안 되면 안전한 화면 노출 정보/알림 외의 무근거 전송은 하지 않는다. 안내 이미지의 `getViewIdResourceName()`만으로 방향을 만들어선 안 된다.
- 미해결 P1: 방향·거리 동일 안내 영역 매칭, 레거시 AutoNavi 호환 방송의 발신자 검증, BLE 안내 큐 ACK 단계별 상태 계측. 새 버전에서 **미구현**이며 성공 표시 금지.

## 6. 재현성과 판정 기준

- 실제 소스의 독립 시간표 계산 17개 경계 검사, 조도센서 히스테리시스 5개, BLE GATT 53개, 실서비스+BLE 결합 13개, 사전검사 101개를 실행하도록 스크립트 보유.
- `tools/run_all_simulations.sh`, `tools/run_dashboard_typecheck.sh`, `tools/run_nav_receiver_typecheck.sh`, `tools/validate_re012_evidence.py` 등. 리포트와 테스트는 실제 SDK/하드웨어를 대신하지 못한다.
- Android SDK 34/JDK17/Gradle 8.6/GitHub Actions에서 실 APK 빌드 확인. 현 환경은 **Android SDK 플랫폼을 설치하지 않아** 실제 assembleDebug를 실행하지 못했다. CI APK 성공은 확인되지 않았다.
- OEM/ECU/계기판 신호 조작, Binder 임의 transact, root, 펌웨어 변조, 소유자 인증 없는 '순정 TBT 성공' 주장 없음.

## 플랫폼 공식 참고

- `Intent.ACTION_TIME_CHANGED`, `ACTION_TIMEZONE_CHANGED`, 동적 broadcast: https://developer.android.com/reference/android/content/Intent
- Android AccessibilityNodeInfo: https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo
- Android MediaProjection: https://developer.android.com/media/grow/media-projection

안전 주의: 차량 주행 중에는 순정 내비 및 순정 경고 표시를 우선 사용한다.
