# HUD-RE-005 — 순정 TMAP TBT 데이터의 IPC 경계 재감사 및 HUD Bridge 적용

- 연구 기준: BYD 돌핀 글로벌 2602/2606 순정 `BydAutoTMap.apk`의 각 2개 DEX, 2602 DiCarServer DEX 2개, MCon K 2.1.5.004 DEX 2개 (총 8개 DEX)
- 대상: 순정 `com.tmap.auto.byd`의 회전 방향·다음 회전까지 거리 → ARIA/TPLAY HUD Q. 외부 지도는 부가 기능.
- 원본 실행이나 자동차 CAN/SPI 쓰기 없음. DRM·서명·시스템 권한 우회 없음.

## 재현한 정적 증거

`evidence/SOURCE_SCAN.json`에 입력 DEX SHA256, 코드 보유 메서드 수, 관련 스캔 수치를 보관하였다. 대상 8 DEX에서 TBT 관련 필드 참조 1,997개, 통신 후보 호출 74개, TBT 소유 클래스에서 검사한 메서드 92개를 CSV로 수록하였다. **해당 건수는 호출 횟수나 활성 송신 경로 수가 아니다.**

- 2602 순정 TMAP `classes.dex`: 관련 메서드 308개, TBT 관련 필드 메서드 248개, IPC 관련 메서드 15개.
- 2606 순정 TMAP `classes.dex`: 관련 메서드 305개, TBT 관련 필드 메서드 245개, IPC 관련 메서드 15개.
- `TBT_CONTEXT_IPC_CANDIDATES.csv`의 2602/2606 외부 전송 후보는 대부분 *프로세스 내부* `LiveData.postValue()`임. `CarNavigationStatusManager.sendNavigationStateChange()`는 시스템 SDK 래퍼 `sendEvent` 내부에 존재하는 참조이며, 순정 TBT 생산 메서드에서 직접 호출되었다는 증거가 아님.
- `RGData.stGuidePoint` / `TBTInfo.nTBTTurnType` / `TBTInfo.nTBTDist`의 실제 소비는 RE-003의 순정 ViewModel 경로에서 확인됨. 외부 공개 Binder 74개 트랜잭션/콜백에서 직접 TBT 쌍을 반환하는 기능은 RE-004에서 확인되지 않음.
- MCon K의 `RubieyaHudService` → `THBTManager` → GATT 전송 호출 관계(RE-001/002)는 독립적으로 보존. 이는 MCon K가 BYD 순정 TMAP의 TBT를 읽고 있다는 증거는 아님.

## 기존 앱에 반영한 부분

1. `OemTmapBinderProbe.java`를 추가. 사용자가 앱 화면을 열면 `com.tmap.auto.byd.NaviService`의 설치/공개 여부 및 요구 permission을 읽고, 공개 시 명시적 `bindService()` 후 **`IBinder.getInterfaceDescriptor()`만 확인**한다.
2. `AIDL_BOUND_NO_TBT`, `BIND_DENIED`, `BIND_TIMEOUT`, `BIND_FALSE`, `BLOCKED_NOT_EXPORTED` 등을 구분하고 기존 진단 ZIP에 자동 기록한다. 74개 OEM 트랜잭션 중 **어느 번호도 호출하지 않음**. 내비 길찾기·주행 상태 명령도 호출하지 않음. 서비스 자동 생성은 발생할 수 있지만 내비의 길안내를 변경하지 않는다.
3. 기존 AutoNavi 호환 방송의 표시를 ‘순정 TBT 확정 방송’이 아닌 **‘순정 송출 미확인’**으로 바로잡는다.
4. MCon K 기반 모델별 GATT 프로필, HUD 설정, 접근성 보조 수신, 다크 모드 등 v0.9.9 기존 기능 유지.

## 반드시 남는 차단 조건

- 이 변경은 **순정 TMAP의 실시간 회전 방향·거리 수신 기능을 새로 확보한 것이 아니다.** 현재 순정 TMAP 프로세스 내부의 `RGData`/`LiveData` 값을 별도 앱이 읽을 수 있는 외부 IPC가 정적으로 입증되지 않았다.
- Binder의 interface descriptor만 얻는다고 TBT가 전달되지는 않는다. 허용 가능한 OEM IPC가 없다면 차량이 허용하는 읽기 전용 진단이나 사용자 동의를 받은 화면 기반 보조 수신을 더 조사해야 한다.
- HUD GATT 쓰기 완료와 실물 HUD 표시 성공은 여전히 별개이며, 사용자 HUD에서 명령 수락은 확인되지 않았다.
- 패키지 안의 분석 스크립트는 입력 바이너리에서 **직접 참조만** 조사한다. JNI, reflection, 비동기 간접 경로까지 부재를 입증하지 않는다.

## 재현

원본 APK/DEX는 저작권 이유로 배포하지 않는다. 사용자가 소유한 원본을 `inputs/` 아래에 `tm2602_classes.dex`, `tm2606_classes.dex`, `mcon_classes.dex` 등으로 배치하고 다음을 실행한다.

```bash
python3 research/HUD-RE-005/scripts/re005_boundary_audit.py inputs evidence_rebuilt
python3 tools/validate_re005_evidence.py
bash tools/run_oem_binder_probe_typecheck.sh
```

검증 결과는 연구팩과 실제 APK 소스에 포함된다. **실차 TBT 및 HUD 화면 표시 검증은 아직 미완료**.
