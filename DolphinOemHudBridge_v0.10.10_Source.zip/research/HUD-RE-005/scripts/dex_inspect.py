import struct,sys

def uleb(data,pos):
 val=0;shift=0
 for i in range(5):
  b=data[pos];pos+=1;val|=(b&127)<<shift
  if not b&128:return val,pos
  shift+=7
 raise ValueError('uleb')
class Dex:
 def __init__(self,p):
  self.data=open(p,'rb').read(); d=self.data
  self.str_offs=[struct.unpack_from('<I',d,struct.unpack_from('<I',d,0x3c)[0]+4*i)[0] for i in range(struct.unpack_from('<I',d,0x38)[0])]
  self.strs=[]
  for pos in self.str_offs:
   sz,pos=uleb(d,pos);end=d.index(0,pos);self.strs.append(d[pos:end].decode('utf8','replace'))
  typ_off=struct.unpack_from('<I',d,0x44)[0]
  self.types=[self.strs[struct.unpack_from('<I',d,typ_off+4*i)[0]] for i in range(struct.unpack_from('<I',d,0x40)[0])]
  moff=struct.unpack_from('<I',d,0x5c)[0]
  self.methods=[]
  for i in range(struct.unpack_from('<I',d,0x58)[0]):
   clazz,proto,name=struct.unpack_from('<HHI',d,moff+i*8)
   self.methods.append((self.types[clazz],self.strs[name],proto))
  self.code={}
  coff=struct.unpack_from('<I',d,0x64)[0]
  for i in range(struct.unpack_from('<I',d,0x60)[0]):
   cidx,flags,sidx,iidx,aidx,annotations,classoff,static=struct.unpack_from('<IIIIIIII',d,coff+32*i)
   if not classoff: continue
   pos=classoff
   sizes=[]
   for j in range(4):
    n,pos=uleb(d,pos); sizes.append(n)
   for count in sizes[:2]:
    idx=0
    for j in range(count):
     dif,pos=uleb(d,pos);access,pos=uleb(d,pos);idx+=dif
   for count in sizes[2:]:
    idx=0
    for j in range(count):
     dif,pos=uleb(d,pos);access,pos=uleb(d,pos);cp,pos=uleb(d,pos);idx+=dif
     if cp:self.code[idx]=cp
 def insns(self,midx):
  off=self.code.get(midx)
  if not off:return []
  n=struct.unpack_from('<I',self.data,off+12)[0]
  return struct.unpack_from('<'+'H'*n,self.data,off+16)
 def references(self,midx):
  code=self.insns(midx);refs=[]
  for i,w in enumerate(code):
   op=w&255
   if op==0x1a and i+1<len(code):
    idx=code[i+1]
    if idx<len(self.strs):refs.append(('string',self.strs[idx],i))
   if op==0x1b and i+2<len(code):
    idx=code[i+1]|code[i+2]<<16
    if idx<len(self.strs):refs.append(('string',self.strs[idx],i))
   if (0x6e<=op<=0x72 or 0x74<=op<=0x78) and i+1<len(code):
    idx=code[i+1]
    if idx<len(self.methods):refs.append(('call',self.methods[idx][:2],i))
  return refs
if __name__=='__main__':
 d=Dex(sys.argv[1]); print('strings',len(d.strs),'methods',len(d.methods),'defined with code',len(d.code))
 kw=sys.argv[2:]
 for i,(c,m,pr) in enumerate(d.methods):
  if not d.code.get(i):continue
  refs=d.references(i)
  s=' '.join(str(v) for _,v,_ in refs)
  if any(k.lower() in (c+' '+m+' '+s).lower() for k in kw):
   if any(k.lower() in s.lower() or k.lower() in m.lower() or k.lower() in c.lower() for k in kw):
    print('\n',i,c,m,'insns',len(d.insns(i)))
    for t,v,pc in refs:
     if t=='string' and (any(k.lower() in v.lower() for k in kw) or '0000fff' in v.lower()):print(' str ',pc,repr(v[:250]))
     if t=='call' and any(k.lower() in str(v).lower() for k in kw):print(' call',pc,v)
