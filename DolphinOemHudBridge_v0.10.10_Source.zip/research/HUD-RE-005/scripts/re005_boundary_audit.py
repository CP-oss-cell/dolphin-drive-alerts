#!/usr/bin/env python3
import sys, csv, json, pathlib, collections, hashlib, struct
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from dex_inspect import Dex
from dex_call_audit import scan
P=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path('inputs')
O=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path('evidence');O.mkdir(parents=True,exist_ok=True)
FOCUS=('TBTInfo','RGData','ObservableTBTData','NavigationManager','CarNavigationStatusManager','TmapDrivingData')
external=('sendBroadcast','sendOrderedBroadcast','sendStickyBroadcast','startService','bindService','transact','query','insert','notifyChange','sendNavigationStateChange','postValue','writeCharacteristic')
summary=[];calls=[];tbt_ipc=[];owner_callers=[]
for path in sorted(P.glob('*_classes*.dex')):
 d=Dex(str(path));fields=[]
 nf,fo=struct.unpack_from('<II',d.data,0x50)
 for k in range(nf):
  cl,typ,nm=struct.unpack_from('<HHI',d.data,fo+k*8);fields.append((d.types[cl],d.strs[nm],d.types[typ]))
 stats=collections.Counter()
 for idx,(cl,name,_) in enumerate(d.methods):
  if idx not in d.code: continue
  field_refs=[];call_refs=[];str_refs=[]
  for t,v,off in scan(d,idx):
   if t=='field' and v<len(fields):
    f=fields[v];target=f[0]+'->'+f[1]
    if any(q.lower() in target.lower() for q in FOCUS):field_refs.append((off,target))
   elif t=='call':
    target=v[0]+'->'+v[1]
    call_refs.append((off,target))
   elif t=='string':
    if any(q in v for q in ['AUTONAVI','TBT','NAVI_INFO','naviInfo','carNavigation','CLUSTER']):str_refs.append((off,v[:120]))
  if not field_refs and not str_refs and not any(any(q.lower() in c.lower() for q in FOCUS) for _,c in call_refs) and not any(q.lower() in cl.lower() for q in FOCUS):continue
  stats['tbt_related_method_count']+=1
  outgoing=[(o,c) for o,c in call_refs if any(v in c for v in external)]
  if field_refs:
   stats['field_read_write_methods']+=1
   for off,target in field_refs:calls.append([path.name,idx,cl+'->'+name,off,target])
  if outgoing:
   stats['tbt_method_with_ipc_call']+=1
   for off,c in outgoing:tbt_ipc.append([path.name,idx,cl+'->'+name,off,c,' | '.join(f[1] for f in field_refs[:8]),' | '.join(v[1] for v in str_refs[:5])])
  if (cl.startswith('Lcom/tmap') or cl.startswith('Lcom/skt/')) and ('TBT' in cl or 'RGData' in cl):owner_callers.append([path.name,idx,cl+'->'+name,len(field_refs),len(outgoing)])
 summary.append({'source':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'coded_methods':len(d.code),**stats})
for nm,rows,head in [('TBT_FIELD_XREFS.csv',calls,['dex','method_id','caller','code_unit','field']),('TBT_CONTEXT_IPC_CANDIDATES.csv',tbt_ipc,['dex','method_id','caller','code_unit','callee','tbt_fields_in_same_method','related_strings']),('TBT_OWNER_METHODS.csv',owner_callers,['dex','method_id','owner','tbt_fields_in_method','ipc_calls_in_method'])]:
 with (O/nm).open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(head);w.writerows(rows)
(O/'SOURCE_SCAN.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('summary',summary,'TBT xref',len(calls),'candidate IPC',len(tbt_ipc),'owner',len(owner_callers))
for row in tbt_ipc:
 if row[0].startswith('tm'):print('candidate',row[:5],row[5][:100])
