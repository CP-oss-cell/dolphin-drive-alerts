#!/usr/bin/env python3
"""Standalone DEX references / xrefs for analysis; no APK code execution. Base code scanner; payload widths handled."""
import sys,struct,json,csv,collections
from dex_inspect import Dex
one={0x00,0x01,0x04,0x07,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10,0x11,0x12,0x1d,0x1e,0x21,0x27,0x28}
one.update(range(0x7b,0x90));one.update(range(0xb0,0xd0))
two={0x02,0x05,0x08,0x13,0x15,0x16,0x19,0x1a,0x1c,0x1f,0x20,0x22,0x23,0x29,0x2d,0x2e,0x2f,0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3a,0x3b,0x3c,0x3d}
two.update(range(0x44,0x6e));two.update(range(0x90,0xb0));two.update(range(0xd0,0xe3))
three={0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c}
three.update(range(0x6e,0x73));three.update(range(0x74,0x79));sizes={**{v:1 for v in one},**{v:2 for v in two},**{v:3 for v in three},0x18:5}
for n in range(0x3e,0x44):sizes[n]=1

def scan(d,m):
 ins=d.insns(m); refs=[];p=0
 while p<len(ins):
  op=ins[p]&255;k=sizes.get(op,1);w=ins[p]
  if not op and (w>>8):
   typ=w>>8
   if typ==1 and p+2<len(ins):k=4+2*ins[p+1]
   elif typ==2 and p+2<len(ins):k=2+4*ins[p+1]
   elif typ==3 and p+3<len(ins):k=4+((ins[p+1]*ins[p+2]+1)//2)
  if p+1<len(ins):
   v=ins[p+1]
   if op==0x1a and v<len(d.strs):refs.append(('string',d.strs[v],p))
   elif op==0x1b and p+2<len(ins):
    idx=v+65536*ins[p+2]
    if idx<len(d.strs):refs.append(('string',d.strs[idx],p))
   elif op in list(range(0x6e,0x73))+list(range(0x74,0x79)) and v<len(d.methods):refs.append(('call',d.methods[v][:2],p))
   elif 0x52<=op<=0x6d:refs.append(('field',v,p))
  p+=max(k,1)
 return refs

def extract(path,out):
 d=Dex(path)
 n,off=struct.unpack_from('<II',d.data,0x50)
 fields=[]
 for i in range(n):
  c,t,name=struct.unpack_from('<HHI',d.data,off+8*i);fields.append((d.types[c],d.strs[name],d.types[t]))
 focus=['tbt','navigationstate','navigations','cluster','naviService','binder','INaviService','TbtMConData','TbtThudData','RubieyaHudService','BluetoothGatt','f7d72c','ffea','fff2','TPLAY HUD Q','HUD Q MAX','Lma/b;','Lsa/l;','Lsa/m;','car/navigation','notification','turncode','tbtres','sms','NAVI_']
 callrows=[];strrows=[];fieldrows=[];target_callers=collections.defaultdict(list)
 for i,(cl,name,pr) in enumerate(d.methods):
  if i not in d.code:continue
  caller=cl+'->'+name
  for typ,val,pos in scan(d,i):
   if typ=='call':
    callee=val[0]+'->'+val[1];target_callers[callee].append((caller,pos));
    if any(k.lower() in (caller+' '+callee).lower() for k in focus):callrows.append((i,caller,callee,pos))
   elif typ=='string':
    if any(k.lower() in (caller+' '+val).lower() for k in focus):strrows.append((i,caller,val[:600],pos))
   elif typ=='field' and val<len(fields):
    f=fields[val];field=f[0]+'->'+f[1]+':'+f[2]
    if any(k.lower() in (caller+' '+field).lower() for k in focus):fieldrows.append((i,caller,field,pos))
 for filename,rows,header in [('calls.csv',callrows,['method_id','caller','callee','code_unit_offset']),('strings.csv',strrows,['method_id','caller','string','code_unit_offset']),('fields.csv',fieldrows,['method_id','caller','field','code_unit_offset'])]:
  with open(out+'_'+filename,'w',newline='',encoding='utf-8-sig') as f:
   w=csv.writer(f);w.writerow(header);w.writerows(rows)
 queries=['Landroid/car/navigation/CarNavigationStatusManager;->sendNavigationStateChange','Lcom/skt/tmap/engine/navigation/listeners/TBTChangedListener;->onTBTChangedListener', 'Lcom/skt/tmap/engine/navigation/livedata/ObservableTBTData;->getFirstTBTInfo','Lcom/tmap/auto/byd/NaviService;->onBind','Lcom/skt/tmap/engine/navigation/SDKManager;->getObservableTBTData','Landroid/bluetooth/BluetoothGatt;->writeCharacteristic','Landroid/bluetooth/BluetoothGatt;->discoverServices','Lkr/co/telecons/mcon/model/TbtThudData;->getThbtThudTurnCode','Lkr/co/telecons/mcon/model/TbtMConData;->getThbtMconTurnCode','Lma/b;->invoke']
 summary=[]
 for q in queries:
  callers=target_callers.get(q,[])
  summary.append({'target':q,'count':len(callers),'callers':callers[:130]})
 json.dump({'source':path,'stats':{'methods':len(d.methods),'classes':len(set(d.types)),'codedMethods':len(d.code),'focusedCalls':len(callrows),'focusedFields':len(fieldrows),'focusedStrings':len(strrows)},'queries':summary},open(out+'_summary.json','w'),ensure_ascii=False,indent=2)
 print(path, 'FOCUS refs',len(callrows),len(strrows),len(fieldrows),'queries',[(s['target'].split('->')[-1],s['count']) for s in summary])
if __name__=='__main__':extract(sys.argv[1],sys.argv[2])
