# HUD-R13 · v0.10.5 — 내비 안내 오인 차단 및 BLE 관측 보완

일자: 2026-11-04. 기준: BYD Dolphin 글로벌 2602, Android 10 DiLink 3, TPLAY HUD Q BLE.
전 버전: v0.10.4(versionCode24). 새 버전: v0.10.5(versionCode25).

## 실차 검증 완료 사항(사용자 제보, 재시험은 아님)
- BLE 연결, 수동 우회전 300m, 자동 밝기(시간대 대체), 수동 밝기 정상.
- 11월 4일 실차 로그: 순정 TMAP 상태 방송 24건, 화면 접근성 이벤트 누적 2,353건, 화면 검색 누적 684건, 방향·거리 유효 해석 0건, 자동 HUD 접수 0건.
- 순정 TMAP 실제 TBT와 일반 내비 4종 자동 HUD 출력은 여전히 미해결. Binder 연결 및 상태 방송은 TBT 수신 증거가 아님.

## R10~R12 교차 검증의 신규 코드 반영
1. `NavCue.fromText`: 선별적 문장 단위 해석. 서로 다른 화면 노드/알림 필드의 문자 결합을 금지. 차선·총 잔여거리·목적지까지의 거리·`우회전 후 300m` 등 안내 모호한 텍스트는 차단. 독립적인 회전 설명과 거리값이 확실할 때만 후보 안내를 생성.
2. `NavAccessibilityService`: 전체 창의 문자열을 무차별 이어 붙이지 않음. 활성창에 목표 내비 문자가 없을 때만 다른 창을 확인. 개별 노드마다 줄바꿈을 유지. 방향을 제공하지 않는 순정 이미지 화살표 값은 계속 불명으로 표기.
3. `NavNotificationService`: 제목/본문/부제의 텍스트를 서로 다른 경계로 유지. 방향과 거리가 다른 필드에서 발견되더라도 임의 조합하지 않음.
4. `MainActivity`/수신기: 마지막 안내 해석의 실제 시각과 접근성 세션/알림 해석 건수를 별도 추적. 누적 성공이 최근 성공인 것처럼 표시되는 분기 제거.
5. `HudConnector`: 실제 BLE 전송을 안내 vs 설정으로 분리하여 요청/전송 완료/콜백 확인/전송 오류 계수를 남김. `PROPERTY_WRITE_NO_RESPONSE`의 시간 경과 처리는 명시적으로 콜백 성공과 구별. GATT 성공은 HUD 화면 표시 입증이 아님.
6. `BridgeLog`/`BridgeService`: 새로 생성되는 TBT 진단 메시지에서 도로명/원문을 제거. 이전 버전의 과거 로그는 자동 삭제/소급 수정하지 않음.

## 실차 및 안전상 한계
- 원본 순정 내비의 nTBTTurnType/nTBTDist가 HUD 앱까지 도달하는 API는 확보되지 않음. 이번 릴리스가 순정내비 자동 TBT 수신에 성공한 것은 아님.
- 보수적인 판정으로 인해 실제로 타당한 일부 문자 안내도 전송하지 않을 수 있음(오전송 방지 우선).
- 실제 Android Gradle assembleDebug APK 빌드 및 BYD 실차 동작은 실행하지 않음. 코드·오프라인 모의 검사와 실제 앱 빌드는 다른 기준임.
- OEM Binder/계기판은 읽기 전용 조사 상태 유지. 순정 차량 신호 송신, 펌웨어 변경 없음.

## 실험·회귀 검사
- 전체 프로젝트 사전 검사: 112/112 통과.
- 실제 NavCue 생산 코드 Java 합성입력/위험 문구 검사: 67 PASS.
- 실제 HudConnector Java 시뮬레이션: 59 PASS.
- 실제 BridgeService + HudConnector 결합 모의: 15 PASS.
- 자동 밝기 히스테리시스 5 PASS, 시간표 17 PASS.
- 대시보드, 접근성/알림 수신기, OEM Binder·Provider, SDK 서명 관련 기초 소스 검사 통과. 모두 오프라인 코드검사임.
- CI는 Android SDK34 실제 빌드·매니페스트·버전 검사를 실행하도록 구성.

## 기존 v0.10.4 대비 변경된 앱 생산 소스 (10개)
- `app/src/main/java/com/dolphin/oemhud/BridgeLog.java`
- `app/src/main/java/com/dolphin/oemhud/BridgeService.java`
- `app/src/main/java/com/dolphin/oemhud/HudConnector.java`
- `app/src/main/java/com/dolphin/oemhud/MainActivity.java`
- `app/src/main/java/com/dolphin/oemhud/NavAccessibilityService.java`
- `app/src/main/java/com/dolphin/oemhud/NavCue.java`
- `app/src/main/java/com/dolphin/oemhud/NavNotificationService.java`
- `tests/ble_simulated_android/com/dolphin/oemhud/BleRuntimeTest.java`
- `tests/combined_android/com/dolphin/oemhud/EndToEndRuntimeTest.java`
- `tests/java/com/dolphin/oemhud/NavCueSelfTest.java`

## 다음 미해결 연구
1. 글로벌 2602 OEM `RGData` → `nTBTTurnType`/`nTBTDist` 외부 읽기 경계 확보.
2. 방향 이미지가 접근성 트리에 노출되지 않는 현재 제약 확인/해소(읽기 전용), 다른 창과 방향/거리 병합 금지 유지.
3. 실제 GATT 패킷 전송과 물리적 HUD 표시 성공을 구별하는 기술적 근거 확보.
