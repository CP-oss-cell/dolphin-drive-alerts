package com.dolphin.oemhud;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import com.dolphin.oemhud.adb.HudAdbPermissions;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/**
 * Simple, single-screen Korean dashboard. Each setting has exactly one owner:
 * connection, operation, HUD display/sound, permissions, advanced diagnostics.
 * This UI does not change OEM vehicle signals or promise hardware confirmation.
 */
public final class MainActivity extends Activity {
    private static final int BT_REQ = 305;
    private static final int SCREEN_PROBE_REQ = 306;
    // Low-glare dashboard palette for the 10-inch in-car display, day or night.
    private static final int NAVY=Color.rgb(17,26,41), INK=Color.rgb(234,242,250);
    private static final int MUTED=Color.rgb(160,177,196), TEAL=Color.rgb(0,122,132);
    private static final int SURFACE=Color.rgb(11,16,24), WHITE=Color.rgb(27,38,53);
    private static final int LIGHT=Color.rgb(250,252,255), SECONDARY=Color.rgb(39,54,73);
    private final ArrayList<BluetoothDevice> devices=new ArrayList<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable refreshTask=new Runnable(){@Override public void run(){updateStatus();main.postDelayed(this,3000);}};
    private HudConnector scanner;
    private SharedPreferences prefs;
    private TextView hudState, navState, rightsState, brightnessState, details, operationDescription;
    private Spinner hudPicker;
    private Switch buzzerEnabled;
    private Spinner volume, brightnessMode, brightnessDay, brightnessNight;
    private Button dayStartButton, nightStartButton;
    private TextView brightnessScheduleStatus, brightnessRuntimeStatus;
    private int dayStartMinutes, nightStartMinutes;
    private TextView navSelection, guidanceState, oemBinderState, tbtCompareState;
    private Button operationButton, adbButton;
    private LinearLayout advancedContent;
    private boolean advancedVisible;

    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        prefs=getSharedPreferences(BridgeLog.STORE,0);
        dayStartMinutes=HudBrightnessSchedule.validMinute(prefs.getInt(HudBrightnessSchedule.KEY_DAY_START,HudBrightnessSchedule.DEFAULT_DAY_START),HudBrightnessSchedule.DEFAULT_DAY_START);
        nightStartMinutes=HudBrightnessSchedule.validMinute(prefs.getInt(HudBrightnessSchedule.KEY_NIGHT_START,HudBrightnessSchedule.DEFAULT_NIGHT_START),HudBrightnessSchedule.DEFAULT_NIGHT_START);
        if(dayStartMinutes==nightStartMinutes){dayStartMinutes=HudBrightnessSchedule.DEFAULT_DAY_START;nightStartMinutes=HudBrightnessSchedule.DEFAULT_NIGHT_START;}
        scanner=new HudConnector(this);
        buildDashboard();
        // OEM IPC boundary check is observational; no INaviService transaction is sent.
        OemTmapBinderProbe.start(this);
        OemVehicleIpcProbe.inspect(this);
        if(!hasBluetoothPermission())requestBluetoothPermission();
        if(prefs.getBoolean("enabled",false)){
            try{startServiceSafely(new Intent(this,BridgeService.class));}
            catch(Exception e){BridgeLog.event(this,"자동 시작 실패: "+e.getClass().getSimpleName());}
        }
        if(!prefs.getBoolean("adb_first_run_prompt",false)){
            prefs.edit().putBoolean("adb_first_run_prompt",true).apply();
            new AlertDialog.Builder(this).setTitle("차량 ADB 권한 설정")
                .setMessage("순정 내비 안내 수신을 위해 차량 로컬 ADB 승인이 필요할 수 있습니다. 차량이 ADB를 제공하는 경우에만 승인창이 나타납니다. 지금 진행할까요?")
                .setNegativeButton("나중에",null)
                .setPositiveButton("승인 및 권한 설정",(d,w)->requestAdbSetup()).show();
        }
    }
    private void openNavPicker(){
        BridgeLog.event(this,"내비 앱 목록 화면 열기 · "+installedVersion());
        startActivity(new Intent(this,NavAppPickerActivity.class));
    }
    private String installedVersion(){
        try{
            PackageInfo info=getPackageManager().getPackageInfo(getPackageName(),0);
            long code=Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode;
            return info.versionName+" ("+code+")";
        }catch(Exception e){return "버전 확인 불가";}
    }
    private void buildDashboard(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout root=column();root.setPadding(dp(16),dp(18),dp(16),dp(28));root.setBackgroundColor(SURFACE);
        scroll.addView(root);

        LinearLayout hero=column();hero.setPadding(dp(20),dp(19),dp(20),dp(18));
        hero.setBackground(rounded(NAVY,20));
        TextView small=label("BYD DOLPHIN  ·  HUD Q",12,Color.rgb(127,219,220),true);hero.addView(small);
        TextView title=label("순정 내비 HUD 대시보드",23,LIGHT,true); title.setPadding(0,dp(7),0,dp(5));hero.addView(title);
        hero.addView(label("앱 실행 버전: "+installedVersion(),13,Color.rgb(217,231,240),false));
        // Deliberately place the ONLY app-selection entry above the dashboard fold.
        Button navPickButton=button(hero,"① 설치된 내비 앱 목록 열기",true,this::openNavPicker);
        navPickButton.setMinHeight(dp(60));
        root.addView(hero,margin(0,0,0,8));
        button(root,"② 자동 진단 ZIP 생성·공유 (테스트 불필요)",true,this::quickDiagnosticZip);
        button(root,"③ 화면 캡처 가능 여부 1회 진단 (동의 필요)",false,this::requestScreenProbe);

        LinearLayout statusRow=new LinearLayout(this);statusRow.setOrientation(LinearLayout.HORIZONTAL);
        hudState=smallStatus(statusRow,"HUD 연결");
        navState=smallStatus(statusRow,"TBT 안내");
        rightsState=smallStatus(statusRow,"권한");
        brightnessState=smallStatus(statusRow,"자동 밝기");
        root.addView(statusRow,margin(0,0,0,13));

        LinearLayout operation=card(root,"운행 연동","시동 후 백그라운드 자동 연결·안내 중계",false);
        operationDescription=label("현재 상태를 확인하는 중입니다.",13,MUTED,false);operation.addView(operationDescription,margin(0,0,0,8));
        navSelection=label("내비 앱: 자동 감지",13,INK,true);
        operation.addView(navSelection,margin(0,4,0,3));
        guidanceState=label("순정 TMAP 수신 상태 확인 중",13,INK,false);
        operation.addView(guidanceState,margin(0,4,0,7));
        tbtCompareState=label("순정/일반 TMAP 수신 비교 대기",12,MUTED,false);
        operation.addView(tbtCompareState,margin(0,2,0,8));
        oemBinderState=label("순정 TMAP Binder 경계 확인 중 · TBT 조회 미확인",12,MUTED,false);
        operation.addView(oemBinderState,margin(0,1,0,7));
        operation.addView(label("앱 목록은 화면 맨 위의 ① 버튼에서 선택합니다.",12,MUTED,false),margin(0,2,0,5));
        operation.addView(label("화면 이벤트 수신과 회전·거리 해석은 다릅니다. 실제 안내가 해석되지 않으면 HUD에 가짜 화살표를 보내지 않습니다.",12,MUTED,false),margin(0,2,0,6));
        operationButton=button(operation,"연동 시작",true,()->toggleRunning());
        operation.addView(label("일반 티맵 비교: ① 내비 앱 목록에서 일반 티맵 선택 후 평소처럼 길안내 사용. 같은 방식으로 순정 티맵도 선택 가능합니다. 두 앱이 동시에 수신되는 것은 아닙니다.",12,MUTED,false),margin(0,8,0,4));
        operation.addView(label("순정 내비와 HUD를 대신 실행하지 않습니다. 차량 내비는 평소대로 사용하세요.",12,MUTED,false),margin(0,8,0,0));

        LinearLayout connection=card(root,"HUD 연결","BLE FFF2 채널 · 기기 적용 여부 확인 · 연결 해제",false);
        LinearLayout searchRow=new LinearLayout(this);searchRow.setOrientation(LinearLayout.HORIZONTAL);
        addWeightedButton(searchRow,"HUD 검색",false,()->loadPaired());
        addWeightedButton(searchRow,"블루투스 설정",false,()->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        connection.addView(searchRow);
        hudPicker=spinner(connection,new String[]{"HUD 검색을 눌러 기기를 선택하세요"},0);
        button(connection,"선택한 HUD 연결·자동 연결 저장",true,()->connectSelected());
        button(connection,"HUD 연결 진단 · 우회전 300m 신호 1회 보내기 (정차 시)",false,()->{
            new AlertDialog.Builder(this).setTitle("HUD 출력 경로 확인")
                .setMessage("차량을 안전하게 정차(P)한 상태에서만 실행하세요. 실제 길안내가 아닌 '우회전 300m' 명령을 한 번 전송합니다. 블루투스 쓰기가 성공해도 HUD 화면 표시 여부는 별도로 확인되어야 합니다. 동의하면 8초간 접근 가능한 화면 창의 소유 앱·창 종류·영역만 기록합니다. 글자·목적지·화면 사진은 기록하지 않습니다.")
                .setNegativeButton("취소",null)
                .setPositiveButton("1회 전송",(d,w)->{
                    NavAccessibilityService.requestWindowProbe(this);
                    startServiceSafely(new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_DEMO));
                    toast("HUD 전송 요청 · 상태와 응답은 아래 진단에서 확인");
                }).show();
        });
        connection.addView(label("차량 기본 블루투스가 HUD에 먼저 연결된 경우, 그 연결과 이 앱의 BLE GATT는 다를 수 있습니다. GATT 쓰기 완료만으로 화면 표시나 밝기 변경을 보증하지 않습니다.",12,MUTED,false),margin(0,8,0,5));
        button(connection,"HUD 연결 해제",false,()->{
            Intent svc=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_DISCONNECT);
            startServiceSafely(svc);toast("HUD 자동 연결 해제");updateStatus();
        });

        LinearLayout settings=card(root,"경보음·밝기","하나의 설정 화면에서 한 번에 저장",false);
        buzzerEnabled=new Switch(this);buzzerEnabled.setText("HUD 경보음 사용");
        buzzerEnabled.setTextColor(INK);buzzerEnabled.setChecked(prefs.getBoolean("hud_buzzer_enabled",true));
        settings.addView(buzzerEnabled,margin(0,0,0,5));
        settings.addView(label("경보음 크기",13,INK,true),margin(0,7,0,2));
        volume=spinner(settings,new String[]{"작게","보통","크게"},prefs.getInt("hud_buzzer_level",1));
        settings.addView(label("밝기 모드",13,INK,true),margin(0,10,0,2));
        int sourceMode=prefs.getInt(HudBrightnessSchedule.KEY_SOURCE,0);
        int selectedMode=prefs.getBoolean("hud_brightness_auto",true)?(sourceMode==1?1:0):2;
        brightnessMode=spinner(settings,new String[]{"자동 · 조도 센서 우선 (시간표 대체)","자동 · 사용자 시간표만","고정 밝기"},selectedMode);
        settings.addView(label("주간 / 고정 밝기",13,INK,true),margin(0,10,0,2));
        brightnessDay=spinner(settings,levels(),prefs.getInt("hud_brightness_day",2));
        settings.addView(label("야간 밝기",13,INK,true),margin(0,10,0,2));
        brightnessNight=spinner(settings,levels(),prefs.getInt("hud_brightness_night",0));
        settings.addView(label("자동 밝기 시간 설정",13,INK,true),margin(0,13,0,3));
        LinearLayout scheduleRow=new LinearLayout(this);scheduleRow.setOrientation(LinearLayout.HORIZONTAL);
        dayStartButton=addWeightedButton(scheduleRow,"주간 시작",false,()->pickBrightnessTime(true));
        nightStartButton=addWeightedButton(scheduleRow,"야간 시작",false,()->pickBrightnessTime(false));
        settings.addView(scheduleRow);
        brightnessScheduleStatus=label("",12,MUTED,false);
        settings.addView(brightnessScheduleStatus,margin(0,5,0,7));
        updateScheduleLabels();
        brightnessRuntimeStatus=label("실제 자동 밝기 상태 확인 중",12,INK,false);
        settings.addView(brightnessRuntimeStatus,margin(0,0,0,7));
        brightnessMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
            @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){
                brightnessNight.setEnabled(position!=2);
            }
        });
        button(settings,"경보음·밝기 함께 저장 및 전송",true,this::saveHudSettings);
        settings.addView(label("센서 우선: 조도 센서가 없거나 2분 이상 값이 없으면 설정한 시간표를 사용합니다. 시간표만: 조도 센서를 사용하지 않습니다. 시간표는 차량 현지 시각을 따르며 전조등 상태는 읽지 않습니다.",12,MUTED,false),margin(0,8,0,0));

        LinearLayout permission=card(root,"권한 관리","ADB 승인 및 필수 권한을 한 번에 확인",false);
        adbButton=button(permission,"ADB 연결·권한 적용",true,this::requestAdbSetup);
        permission.addView(label("동의 시 ADB·알림 접근·위치·내비 화면 읽기 접근성 권한을 한 번에 적용합니다. 다른 접근성 서비스 설정은 보존합니다.",12,MUTED,false),margin(0,8,0,0));

        LinearLayout advanced=card(root,"고급 설정 · 진단","일반 사용 중에는 열 필요 없음",false);
        advancedContent=column();advancedContent.setVisibility(View.GONE);
        button(advanced,"고급 설정 및 진단 보기",false,()->{
            advancedVisible=!advancedVisible;
            advancedContent.setVisibility(advancedVisible?View.VISIBLE:View.GONE);
            if(advancedVisible)updateStatus();
        });
        advanced.addView(advancedContent);
        button(advancedContent,"알림 접근 권한 설정 열기",false,()->startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        button(advancedContent,"접근성 설정 열기",false,()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button(advancedContent,"권한 상태 다시 확인",false,()->{
            HudAdbPermissions.audit(this,(msg,done)->runOnUiThread(()->{refreshDetails(msg);updateStatus();}));
        });
        details=label("",12,INK,false);details.setTextIsSelectable(true);details.setPadding(0,dp(12),0,dp(8));
        advancedContent.addView(details);
        advancedContent.addView(label("창 출처 진단은 정차 시 수동 우회전 시험을 눌렀을 때만 8초 동안 기록합니다. 앱 이름과 창 유형은 단서일 뿐, 검은 안내창의 생성 앱을 확정하는 자료는 아닙니다.",12,MUTED,false));
        button(advancedContent,"진단 ZIP 저장·공유",true,this::exportZip);
        advancedContent.addView(label("카메라 단속 정보 전달, 실물 HUD 표시, 아리아 음성인식은 확인되거나 구현된 기능으로 표시하지 않습니다.",12,MUTED,false),margin(0,8,0,0));

        root.addView(label("차량 ECU·계기판 제어 없음 · 경고/방향 안내는 순정 내비 화면을 우선하세요.",12,MUTED,false),margin(2,4,2,0));
        setContentView(scroll);updateStatus();
    }
    private void toggleRunning(){
        boolean enabled=!prefs.getBoolean("enabled",false);
        prefs.edit().putBoolean("enabled",enabled)
            .putLong("nav_last_enabled_changed_at",System.currentTimeMillis()).apply();
        try{if(enabled)startServiceSafely(new Intent(this,BridgeService.class));
            else stopService(new Intent(this,BridgeService.class));
            toast(enabled?"HUD 길안내 연동 시작":"HUD 길안내 연동 중지");
        }catch(Exception e){prefs.edit().putBoolean("enabled",!enabled).apply();toast("작동 변경 실패: "+e.getClass().getSimpleName());}
        updateStatus();
    }
    private void connectSelected(){
        int pos=hudPicker.getSelectedItemPosition();
        if(pos<0||pos>=devices.size()){toast("먼저 HUD를 검색하고 선택하세요");return;}
        if(!hasBluetoothPermission()){requestBluetoothPermission();return;}
        try{
            BluetoothDevice d=devices.get(pos);
            if(!HudConnector.isSupportedName(d.getName())){toast("지원 대상 HUD Q가 아닙니다");return;}
            String addr=d.getAddress();prefs.edit().putString("hud_mac",addr).apply();
            Intent intent=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_CONNECT);
            intent.putExtra(BridgeService.EXTRA_ADDRESS,addr);startServiceSafely(intent);
            scanner.stopScanning();toast("HUD 연결·자동 연결 저장");updateStatus();
        }catch(Exception ex){toast("HUD 연결 요청 실패: "+ex.getClass().getSimpleName());}
    }
    private void pickBrightnessTime(boolean day){
        int selected=day?dayStartMinutes:nightStartMinutes;
        new TimePickerDialog(this,(picker,hour,minute)->{
            int value=hour*60+minute;
            int nextDay=day?value:dayStartMinutes;
            int nextNight=day?nightStartMinutes:value;
            if(!HudBrightnessSchedule.validPair(nextDay,nextNight)){
                toast("주간 시작과 야간 시작은 다른 시간이어야 합니다");return;
            }
            dayStartMinutes=nextDay;nightStartMinutes=nextNight;
            updateScheduleLabels();
        },selected/60,selected%60,true).show();
    }
    private void updateScheduleLabels(){
        if(dayStartButton!=null)dayStartButton.setText("주간 시작 "+HudBrightnessSchedule.clockLabel(dayStartMinutes));
        if(nightStartButton!=null)nightStartButton.setText("야간 시작 "+HudBrightnessSchedule.clockLabel(nightStartMinutes));
        if(brightnessScheduleStatus!=null)brightnessScheduleStatus.setText(
            HudBrightnessSchedule.summary(dayStartMinutes,nightStartMinutes)+" · 아래 저장 버튼을 눌러 적용");
    }
    private void saveHudSettings(){
        // Saved by BridgeService: original wire format and reconnection replay preserved.
        Intent buzzer=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_BUZZER);
        buzzer.putExtra("enabled",buzzerEnabled.isChecked());buzzer.putExtra("level",volume.getSelectedItemPosition());
        Intent bright=new Intent(this,BridgeService.class).setAction(BridgeService.ACTION_BRIGHTNESS);
        int mode=brightnessMode.getSelectedItemPosition();
        if(!HudBrightnessSchedule.validPair(dayStartMinutes,nightStartMinutes)){
            toast("주간 시작과 야간 시작을 다르게 선택하세요");return;
        }
        bright.putExtra("auto",mode!=2);
        bright.putExtra("source_mode",mode==1?1:0);
        bright.putExtra("day_start",dayStartMinutes);
        bright.putExtra("night_start",nightStartMinutes);
        bright.putExtra("day",brightnessDay.getSelectedItemPosition());
        bright.putExtra("night",brightnessNight.getSelectedItemPosition());
        try{startServiceSafely(buzzer);startServiceSafely(bright);
            toast("HUD 경보음·밝기 저장 및 전송 요청");updateStatus();
        }catch(Exception e){toast("설정 전송 오류: "+e.getClass().getSimpleName());}
    }
    private void requestAdbSetup(){
        new AlertDialog.Builder(this).setTitle("차량 ADB 연결 및 권한 적용")
            .setMessage("차량 로컬 ADB(127.0.0.1:5555)에 연결하고, 동의하면 알림 접근·위치·순정 내비 화면 텍스트 읽기(접근성) 권한을 적용합니다. 다른 앱의 화면 내용은 길안내로 처리하지 않으며 차량 ECU를 변경하지 않습니다. 이 권한들을 허용하시겠습니까?")
            .setNegativeButton("취소",null).setPositiveButton("연결·적용",(d,w)->startAdbSetup()).show();
    }
    private void startAdbSetup(){
        adbButton.setEnabled(false);adbButton.setText("ADB 연결 중...");
        HudAdbPermissions.connect(this,(msg,done)->runOnUiThread(()->{
            prefs.edit().putString("adb_last_result",msg).apply();updateStatus();
            if(!done)return;
            if(!msg.startsWith("ADB_READY:")){
                adbButton.setEnabled(true);adbButton.setText("ADB 연결·권한 적용");
                new AlertDialog.Builder(this).setTitle("ADB 연결 실패").setMessage(msg).setPositiveButton("확인",null).show();
                return;
            }
            adbButton.setText("필수 권한 적용 중...");
            HudAdbPermissions.apply(this,true,(result,finished)->runOnUiThread(()->{
                prefs.edit().putString("adb_last_result",result).apply();updateStatus();
                if(finished){
                    adbButton.setEnabled(true);adbButton.setText("ADB 연결·권한 적용");
                    new AlertDialog.Builder(this).setTitle("ADB 권한 적용 결과").setMessage(result)
                        .setPositiveButton("확인",null).show();
                }
            }));
        }));
    }
    private void loadPaired(){
        if(!hasBluetoothPermission()){requestBluetoothPermission();return;}
        scanner.scan(new HudConnector.ScanListener(){
            @Override public void found(ArrayList<BluetoothDevice> found){runOnUiThread(()->{
                devices.clear();devices.addAll(found);ArrayList<String> names=new ArrayList<>();
                for(BluetoothDevice d:found){
                    try{String a=d.getAddress(),n=d.getName();
                        names.add((n==null?"HUD Q":n)+" ("+a.substring(0,Math.min(5,a.length()))+"…)");}
                    catch(Exception ex){names.add("HUD Q 기기");}
                }
                if(names.isEmpty())names.add("검색된 HUD 없음");
                ArrayAdapter<String> adapter=new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_item,names);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);hudPicker.setAdapter(adapter);
            });}
            @Override public void status(String message){runOnUiThread(()->{
                BridgeLog.event(MainActivity.this,message);
                if(!message.startsWith("검색 중"))toast(message);
            });}
        });
    }
    private boolean hasBluetoothPermission(){
        return (Build.VERSION.SDK_INT<31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED))
            && (Build.VERSION.SDK_INT>=31 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED);
    }
    private void requestBluetoothPermission(){
        if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},BT_REQ);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},BT_REQ);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==BT_REQ){if(hasBluetoothPermission())loadPaired();else toast("HUD 검색을 위해 블루투스·위치 권한을 허용하세요");}
        updateStatus();
    }
    private void startServiceSafely(Intent i){
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }
    private void updateStatus(){
        if(prefs==null||operationButton==null)return;
        boolean running=prefs.getBoolean("enabled",false);
        operationButton.setText(running?"연동 중지":"연동 시작 · 자동 실행");
        operationDescription.setText(running?"안내 수신 및 HUD 연결 유지 사용 중":"연동 꺼짐 · 누르면 자동 실행 설정도 함께 켜집니다");
        String navPkg=prefs.getString("nav_package","").trim();
        String navLabel=prefs.getString("selected_nav_label","");
        navSelection.setText(navPkg.isEmpty()?"내비 앱: 자동 감지":
            "내비 앱: "+(navLabel.isEmpty()?navPkg:navLabel));
        if(brightnessRuntimeStatus!=null){
            brightnessRuntimeStatus.setText("현재 적용: "+prefs.getString("hud_auto_status","저장 후 확인")+
                " · "+prefs.getString("hud_auto_sensor","센서/시간표 확인 중"));
        }
        String hud=prefs.getString("hud_status","연결 전");
        hudState.setText(hud.contains("준비")?"BLE 연결 · 적용 미확인":hud.length()>25?hud.substring(0,24)+"…":hud);
        int count=prefs.getInt("oem_tbt_count",0);
        int a11y=prefs.getInt("nav_accessibility_count",0);
        int notif=prefs.getInt("nav_notification_count",0);
        int parsed=prefs.getInt("nav_parsed_count",0);
        long now=System.currentTimeMillis();
        boolean recentNavEvent=recent(now,prefs.getLong("last_nav_event_at",0),30000L);
        boolean recentPoll=recent(now,prefs.getLong("nav_poll_last_attempt_at",0),30000L);
        boolean recentParsed=recent(now,prefs.getLong("nav_last_parsed_at",0),30000L);
        navState.setText(recentParsed?"최근 안내 해석됨 · HUD 표시 미확인":recentNavEvent?"화면 최근 수신":recentPoll?"화면 조회 중":
            parsed>0?"과거 안내 누적 "+parsed+"회 (최근 수신 아님)":
            a11y+notif+count>0?"과거 누적 기록":"수신 전");
        String adb=prefs.getString("adb_last_result","");
        String currentRights=HudAdbPermissions.readStatus(this);
        boolean accessEnabled=currentRights.contains("화면 접근성: ENABLED");
        boolean runtime=prefs.getBoolean("a11y_runtime_connected",false);
        String watchState=prefs.getString("nav_watchdog_state","");
        boolean monitorCurrent=recent(now,prefs.getLong("nav_watchdog_last_check_at",0),60000L);
        if(running && monitorCurrent && NavPollHealth.STALE.equals(watchState))
            navState.setText("화면 조회 지연 · TBT 미확인");
        if(brightnessState!=null)brightnessState.setText(
            prefs.getBoolean("hud_brightness_auto",true)?
                "자동 · "+prefs.getString("hud_auto_sensor","시간표/센서 확인 중"):
                "고정 밝기");
        rightsState.setText(!accessEnabled?"접근성 꺼짐":
            running&&monitorCurrent&&NavPollHealth.STALE.equals(watchState)?"화면 조회 지연":
            running&&monitorCurrent&&NavPollHealth.DISCONNECTED.equals(watchState)?"수신기 미연결":
            runtime&&recentPoll?"수신기 조회 중":runtime?"수신기 상태 오래됨":"수신기 대기");
        if(tbtCompareState!=null)tbtCompareState.setText(
            "내비별 단계별 진단 (이번 버전부터 누적)\n"+
            NavInputTrace.oneLine(prefs,NavTracePolicy.OEM)+"\n"+
            NavInputTrace.oneLine(prefs,NavTracePolicy.GENERAL)+
            "\n※ 입력 수는 실제 TBT나 HUD 표시 성공이 아닙니다.");
        if(guidanceState!=null){
            String message=!running?"연동이 꺼져 있습니다":recentParsed?
                "최근 안내 해석됨 · HUD 접수 " + prefs.getInt("nav_tbt_hud_attempts",0)+"회(누적), HUD 표시 미확인":
                !accessEnabled?"순정 TMAP 화면 접근성 OFF · 권한 관리에서 활성화 필요":
                !runtime?"접근성 설정은 ON, 실제 수신기 연결을 기다리는 중":
                monitorCurrent&&NavPollHealth.STALE.equals(watchState)?
                    "화면 조회 지연 감지 · 안전한 루프 복구 시도 중 (TBT 수신 미확인)":
                !recentNavEvent && !recentPoll?"최근 30초 화면 수신·조회 확인 없음 (과거 누적과 구분)":
                recentPoll&&!recentNavEvent?"수신기 조회 중 · 새 화면 이벤트가 없거나 내비 화면 비가시":
                (OemTmapStateSignal.PACKAGE.equals(navPkg)||navPkg.isEmpty()) &&
                    prefs.getBoolean("nav_distance_token_seen",false) &&
                    !prefs.getBoolean("nav_direction_token_seen",false)?
                    "순정 TMAP 거리 확인 · 이미지 화살표의 실제 방향값 미확보":
                recentNavEvent?"최근 내비 화면 이벤트 · 방향/거리 해석 전":
                notif>0?"내비 알림 "+notif+"회 감지 · 방향/거리 해석 전":
                "순정 TMAP 안내 데이터 수신 전 (경로 검색만으로는 안내가 나오지 않을 수 있음)";
            guidanceState.setText(message);
        }
        if(oemBinderState!=null){
            String bind=prefs.getString("oem_binder_state","NOT_CHECKED");
            oemBinderState.setText("순정 TMAP 서비스: "+bind+" · Binder 접속은 TBT 수신이 아닙니다");
        }
        if(advancedVisible)refreshDetails("");
    }
    private static boolean recent(long now,long observedAt,long limit){
        return observedAt>0 && observedAt<=now && now-observedAt<=limit;
    }
    private String statusText(){
        return HudAdbPermissions.readStatus(this)+"\n\n"+
            "실행 APK 버전: "+installedVersion()+"\n"+
            "앱 선택 기능: 대시보드 상단 ① 설치된 내비 앱 목록 열기\n"+
            "브리지 자동 실행: "+(prefs.getBoolean("enabled",false)?"ON":"OFF")+"\n"+
            "HUD: "+prefs.getString("hud_status","연결 전")+"\n"+
            "경보음: "+(prefs.getBoolean("hud_buzzer_saved",false)?(prefs.getBoolean("hud_buzzer_enabled",true)?"ON":"OFF")+" / "+(prefs.getInt("hud_buzzer_level",1)+1)+"단계":"미설정")+"\n"+
            "밝기: "+(prefs.getBoolean("hud_brightness_saved",false)?(prefs.getBoolean("hud_brightness_auto",true)?"주야간 프로필":"고정")+" / 주간 "+(prefs.getInt("hud_brightness_day",2)+1)+" / 야간 "+(prefs.getInt("hud_brightness_night",0)+1):"미설정")+"\n"+
            "자동 밝기: "+prefs.getString("hud_auto_status","미실행")+" / "+prefs.getString("hud_auto_sensor","미확인")+"\n"+
            "자동 밝기 입력 방식: "+(prefs.getInt(HudBrightnessSchedule.KEY_SOURCE,0)==1?"사용자 시간표만":"센서 우선/시간표 대체")+"\n"+
            "밝기 시간표: "+HudBrightnessSchedule.summary(
                prefs.getInt(HudBrightnessSchedule.KEY_DAY_START,HudBrightnessSchedule.DEFAULT_DAY_START),
                prefs.getInt(HudBrightnessSchedule.KEY_NIGHT_START,HudBrightnessSchedule.DEFAULT_NIGHT_START))+" (기기 현지 시각)\n"+
            "설정 송신: "+prefs.getString("hud_setting_status","없음")+"\n"+
            "실제 HUD 이름: "+prefs.getString("hud_device_name","미확인")+"\n"+
            "MCon 예상 프로필: "+prefs.getString("hud_model_expected","미확인")+"\n"+
            "실제 GATT 서비스: "+prefs.getString("hud_services_found","미확인")+"\n"+
            "BLE 쓰기 특성: "+prefs.getString("hud_write_channel","미확인")+"\n"+
            "HUD FFF1 기기 알림: "+prefs.getInt("hud_notify_count",0)+"회 (없어도 미지원일 수 있음)"+"\n"+
            "최근 FFF1 응답: "+prefs.getString("hud_last_notify","없음")+"\n"+
            "수동 출력 진단: "+prefs.getString("hud_demo_status","미실행")+"\n"+
            "창 출처 진단 상태: "+prefs.getString("window_probe_status","수동 시험 전")+"\n"+
            "창 출처 샘플: "+prefs.getInt("window_probe_samples",0)+"회 / 마지막 시각(ms): "+prefs.getLong("window_probe_last_at",0)+"\n"+
            "창 변경 이벤트(8초 창): "+prefs.getInt("window_probe_change_events",0)+"회 · window id/layer는 소유 단서일 뿐 내부 팝업 생성자를 보증하지 않음\n"+
            "창 출처 기록(앱·종류·표시 영역, 화면 텍스트 없음):\n"+
                prefs.getString("window_probe_history","")+"\n"+
            "순정 TMAP 서비스 바인딩: "+prefs.getString("oem_binder_state","NOT_CHECKED")+" / "+prefs.getString("oem_binder_detail","없음")+"\n"+
            "순정 TMAP Binder 공개 여부: "+prefs.getString("oem_binder_exported","미확인")+" / 요구 권한: "+prefs.getString("oem_binder_permission","미확인")+"\n"+
            "순정 TMAP TBT 직접 수신: 미확인 (Binder 연결과 구별)"+"\n"+
            "DiCar Provider 선언 조회: "+prefs.getString("oem_vehicle_provider_probe","미확인")+"\n"+
            "계기판 전용 Activity 선언 조회: "+prefs.getString("oem_cluster_activity_probe","미확인")+"\n"+
            "순정 TMAP 상태 방송(TBT 아님): "+prefs.getInt("oem_state_observed_count",0)+"회 / "+prefs.getString("oem_state_last","없음")+"\n"+
            "순정 상태 방송 무효/다른 출처: "+prefs.getInt("oem_state_ignored",0)+"회 (발신자 인증 불가)"+"\n"+
            "AutoNavi 호환 방송(순정 송출 근거 없음): "+prefs.getInt("oem_tbt_count",0)+"회"+"\n"+
            "OEM 우선 원칙으로 무시한 호환 방송: "+prefs.getInt("autonavi_ignored_for_oem",0)+"회"+"\n"+
            "내비 알림 이벤트: "+prefs.getInt("nav_notification_count",0)+"회"+"\n"+
            "내비 접근성 이벤트: "+prefs.getInt("nav_accessibility_count",0)+"회"+"\n"+
            "화면 수신기 과거 연결 플래그: "+prefs.getString("a11y_runtime_state","미확인")+" (현재 생존 증명이 아님)\n"+
            "접근성 세션 시작(epoch ms): "+prefs.getLong("a11y_session_started_at",0)+"\n"+
            "이번 서비스 세션 내비 이벤트: "+prefs.getInt("nav_session_events",0)+"회\n"+
            "이번 서비스 세션 화면 조회: "+prefs.getInt("nav_session_polls",0)+"회\n"+
            "연동 설정 마지막 변경(epoch ms): "+prefs.getLong("nav_last_enabled_changed_at",0)+"\n"+
            "수신 감시 상태: "+prefs.getString("nav_watchdog_state","아직 검사 전")+" / 마지막 검사(epoch ms): "+prefs.getLong("nav_watchdog_last_check_at",0)+"\n"+
            "수신 감시 접근성 붙음: "+prefs.getBoolean("nav_watchdog_attached",false)+" / 복구 요청(epoch ms): "+prefs.getLong("nav_watchdog_repair_requested_at",0)+"\n"+
            "수신기 루프 재예약 횟수: "+prefs.getInt("nav_poll_repair_count",0)+" / 마지막 시각: "+prefs.getLong("nav_poll_repair_last_at",0)+"\n"+
            "수신기 루프 마지막 tick(epoch ms): "+prefs.getLong("nav_poll_loop_last_tick_at",0)+" / 종료: "+prefs.getLong("nav_poll_loop_last_finished_at",0)+" / 다음 예약: "+prefs.getLong("nav_poll_next_due_at",0)+"\n"+
            "수신기 루프 마지막 결과: "+prefs.getString("nav_poll_last_outcome","없음")+" / 실행시간(ms): "+prefs.getLong("nav_poll_duration_ms",0)+"\n"+
            "원클릭 진단(epoch ms): "+prefs.getLong("hud_quick_diagnostic_at",0)+" / "+prefs.getString("hud_quick_diagnostic_state","없음")+"\n"+
            "마지막 내비 이벤트(epoch ms): "+prefs.getLong("last_nav_event_at",0)+"\n"+
            "이전 접근성 세션 최종 이벤트(epoch ms): "+prefs.getLong("nav_previous_session_last_event_at",0)+"\n"+
            "마지막 화면 조회 시도(epoch ms): "+prefs.getLong("nav_poll_last_attempt_at",0)+"\n"+
            "마지막 텍스트 유효 조회(epoch ms): "+prefs.getLong("nav_poll_last_success_at",0)+"\n"+
            "마지막 빈 화면 조회(epoch ms): "+prefs.getLong("nav_poll_last_empty_at",0)+"\n"+
            "TMAP 화면트리 검색: "+prefs.getInt("nav_tree_scan_count",0)+"회"+"\n"+
            "TMAP 화면 주기 조회: "+prefs.getInt("nav_poll_scans_count",0)+"회"+"\n"+
            "순정 TBT 거리 전용 뷰 관측(최근 조회): "+prefs.getInt("oem_tbt_distance_widgets_last",0)+"개"+"\n"+
            "순정 라벨 없는 이미지 뷰(회전임을 보증 안함): "+prefs.getInt("oem_unlabeled_images_last",0)+"개"+"\n"+
            "순정 화살표 원본 값: "+prefs.getString("oem_direction_access","NOT_VERIFIED")+"\n"+
            "방향·거리 해석 누적: "+prefs.getInt("nav_parsed_count",0)+"회"+"\n"+
            "접근성 이번 세션 해석: "+prefs.getInt("nav_session_parsed",0)+"회 / 알림 해석 누적: "+prefs.getInt("nav_notification_parsed",0)+"회\n"+
            "마지막 해석 시각(epoch ms): "+prefs.getLong("nav_last_parsed_at",0)+"\n"+
            "내비 화면 텍스트 길이: "+prefs.getInt("nav_visible_text_chars",0)+"자"+"\n"+
            "거리 표기 감지: "+prefs.getBoolean("nav_distance_token_seen",false)+" / 방향 문구 감지: "+prefs.getBoolean("nav_direction_token_seen",false)+" (최근 화면)"+"\n"+
            "HUD 안내 전송 접수 시도: "+prefs.getInt("nav_tbt_hud_attempts",0)+"회"+"\n"+
            "최근 안내 입력 경로: "+prefs.getString("last_nav_input_source","없음")+"\n"+
            "선택한 내비 앱: "+prefs.getString("nav_package","")+"\n"+
            "최근 감지 내비 앱: "+prefs.getString("last_nav_package","없음")+"\n"+
            "마지막 순정 방송: "+prefs.getString("last_oem_tbt","없음")+"\n"+
            "GATT 전체 쓰기 완료: "+prefs.getInt("hud_tx_completed",0)+" / 오류: "+prefs.getInt("hud_tx_errors",0)+"\n"+
            "안내 전송 요청: "+prefs.getInt("hud_nav_write_requests",0)+" / 완료: "+prefs.getInt("hud_nav_write_completed",0)+" / 콜백 확인: "+prefs.getInt("hud_nav_callback_confirmed",0)+" / 오류: "+prefs.getInt("hud_nav_transport_errors",0)+"\n"+
            "밝기·경보음 설정 요청: "+prefs.getInt("hud_setting_write_requests",0)+" / 완료: "+prefs.getInt("hud_setting_write_completed",0)+" / 콜백 확인: "+prefs.getInt("hud_setting_callback_confirmed",0)+" / 오류: "+prefs.getInt("hud_setting_transport_errors",0)+"\n"+
            "설정 큐 대기 중 동일 프레임 차단: "+prefs.getInt("hud_setting_pending_duplicates_suppressed",0)+"회 (실제 전송 후 재적용과 구분)\n"+
            "최근 전송: "+prefs.getString("last_tx","없음")+"\n"+
            "최근 안내: "+prefs.getString("last_cue","없음")+"\n"+
            "최근 ADB 결과: "+prefs.getString("adb_last_result","없음")+"\n"+
            "※ GATT 완료는 실물 HUD 화면 표시 성공을 증명하지 않습니다.\n"+
            "※ 순정 상태 방송·Binder 연결·화면 이미지 요소는 TBT 방향·거리 수신 성공이 아닙니다.\n"+
            "화면 캡처 1회 진단: "+prefs.getString("screen_probe_status","NOT_TESTED")+"\n\n"+
            NavInputTrace.report(prefs);
    }
    private void refreshDetails(String extra){
        if(details!=null)details.setText((extra.isEmpty()?"":extra+"\n\n")+statusText());
    }
    private void requestScreenProbe(){
        new AlertDialog.Builder(this).setTitle("화면 캡처 가능 여부 진단")
            .setMessage("Android의 화면 공유 동의창이 나타납니다. 동의하면 현재 화면을 단 한 장 분석해 검은 화면 여부와 크기만 기록합니다. 이미지·글자·목적지는 저장하거나 전송하지 않습니다. HUD 안내는 자동 송신하지 않습니다. 순정 TMAP 안내창을 표시한 상태에서 진행하세요.")
            .setNegativeButton("취소",null)
            .setPositiveButton("화면 공유 동의 요청",(d,w)->{
                try{
                    android.media.projection.MediaProjectionManager mgr=(android.media.projection.MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if(mgr==null)throw new IllegalStateException("MediaProjection 서비스 없음");
                    startActivityForResult(mgr.createScreenCaptureIntent(),SCREEN_PROBE_REQ);
                }catch(Exception e){BridgeLog.event(this,"화면 진단 시작 실패 "+e.getClass().getSimpleName());toast("화면 진단 시작 실패");}
            }).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=SCREEN_PROBE_REQ)return;
        if(resultCode!=RESULT_OK||data==null){
            prefs.edit().putString("screen_probe_status","USER_DECLINED").apply();
            toast("화면 공유 동의가 취소되었습니다");return;
        }
        toast("화면 캡처 권한을 즉시 연결합니다. 5초 안에 순정 TMAP으로 전환하세요.");
        ScreenCaptureProbe.runOnce(this,resultCode,data,(status)->runOnUiThread(()->{
            prefs.edit().putString("screen_probe_status",status).putLong("screen_probe_time",System.currentTimeMillis()).apply();
            BridgeLog.event(this,"화면 캡처 진단: "+status);
            toast("진단 완료. ② 자동 진단 ZIP에서 결과를 공유하세요.");
        }));
    }
    private void quickDiagnosticZip(){
        long now=System.currentTimeMillis();
        String watchdog=prefs.getString("nav_watchdog_state","감시 시작 전");
        String observation="순정="+NavInputTrace.oneLine(prefs,NavTracePolicy.OEM)+
            " / 일반="+NavInputTrace.oneLine(prefs,NavTracePolicy.GENERAL)+
            " / HUD="+prefs.getString("hud_status","미연결")+
            " / TBT해석="+prefs.getInt("nav_session_parsed",0)+
            " / 수신기="+watchdog+
            " / 마지막 조회="+prefs.getLong("nav_poll_last_attempt_at",0)+
            " / 화면캡처="+prefs.getString("screen_probe_status","NOT_TESTED");
        prefs.edit().putLong("hud_quick_diagnostic_at",now)
            .putString("hud_quick_diagnostic_state",observation).apply();
        exportZip();
    }
    private void exportZip(){
        Uri uri=null;boolean completed=false;
        try{
            String name="DolphinOemHud_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.KOREA).format(new Date())+".zip";
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,name);
            values.put(MediaStore.Downloads.MIME_TYPE,"application/zip");
            values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.Downloads.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("다운로드 저장소 생성 실패");
            try(OutputStream out=getContentResolver().openOutputStream(uri);ZipOutputStream zip=new ZipOutputStream(out)){
                zip.putNextEntry(new ZipEntry("report.txt"));
                String report="Dolphin OEM HUD Bridge "+installedVersion()+"\n"+statusText()+"\n\n=== EVENTS ===\n"+
                    prefs.getString("history","")+"\n=== NOTE ===\nGATT write != HUD screen confirmation.\n";
                zip.write(report.getBytes(StandardCharsets.UTF_8));zip.closeEntry();
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.Downloads.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);completed=true;
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("application/zip");
            share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"HUD 진단 ZIP 공유"));
        }catch(Exception e){toast("ZIP 저장/공유 실패: "+e.getMessage());}
        finally{if(!completed&&uri!=null)getContentResolver().delete(uri,null,null);}
    }
    @Override protected void onResume(){super.onResume();main.removeCallbacks(refreshTask);main.post(refreshTask);}
    @Override protected void onPause(){main.removeCallbacks(refreshTask);super.onPause();}
    @Override protected void onDestroy(){main.removeCallbacks(refreshTask);scanner.stopScanning();super.onDestroy();}

    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private GradientDrawable rounded(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout.LayoutParams margin(int left,int top,int right,int bottom){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;
    }
    private TextView label(String value,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout card(LinearLayout root,String title,String sub,boolean ignored){
        LinearLayout card=column();card.setBackground(rounded(WHITE,18));card.setPadding(dp(17),dp(17),dp(17),dp(17));
        card.setElevation(dp(2));card.addView(label(title,18,INK,true));
        card.addView(label(sub,12,MUTED,false),margin(0,3,0,12));root.addView(card,margin(0,0,0,12));return card;
    }
    private TextView smallStatus(LinearLayout parent,String heading){
        LinearLayout wrapper=column();wrapper.setGravity(Gravity.CENTER_VERTICAL);
        wrapper.setPadding(dp(10),dp(12),dp(9),dp(12));wrapper.setBackground(rounded(WHITE,14));
        wrapper.setElevation(dp(1));
        wrapper.addView(label(heading,11,MUTED,false));
        TextView result=label("확인 중",12,INK,true);result.setSingleLine(true);result.setEllipsize(android.text.TextUtils.TruncateAt.END);
        wrapper.addView(result,margin(0,5,0,0));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(66),1f);
        p.setMargins(dp(2),0,dp(2),0);parent.addView(wrapper,p);return result;
    }
    private Button button(LinearLayout host,String title,boolean primary,Runnable action){
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTextSize(13);b.setMinHeight(dp(45));
        b.setTextColor(LIGHT);
        GradientDrawable background=rounded(primary?TEAL:SECONDARY,12);
        b.setBackground(background);host.addView(b,margin(0,5,0,2));
        b.setOnClickListener(v->action.run());return b;
    }
    private Button addWeightedButton(LinearLayout host,String title,boolean primary,Runnable action){
        Button b=new Button(this);b.setText(title);b.setTextSize(12);b.setAllCaps(false);
        b.setTextColor(LIGHT);b.setBackground(rounded(primary?TEAL:SECONDARY,12));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1f);p.setMargins(dp(2),0,dp(2),0);
        host.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private Spinner spinner(LinearLayout host,String[] choices,int selected){
        Spinner s=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,choices);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);s.setSelection(Math.max(0,Math.min(choices.length-1,selected)));
        host.addView(s,margin(0,3,0,8));return s;
    }
    private String[] levels(){return new String[]{"1단계 · 어둡게","2단계 · 보통","3단계 · 밝게"};}
    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
}
