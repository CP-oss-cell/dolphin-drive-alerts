package com.dolphin.oemhud;

/** In-process, monotonic-clock monitor. Never elevates privileges or starts an OEM service. */
public final class NavPollHealth {
    public static final long STALE_MS=20000L;
    public static final long REPAIR_COOLDOWN_MS=60000L;
    public static final long MONITOR_INTERVAL_MS=20000L;
    public static final String OFF="OFF", DISCONNECTED="ACCESSIBILITY_UNAVAILABLE",
        STARTING="WAITING_FOR_FIRST_POLL", ACTIVE="POLL_ACTIVE", STALE="POLL_STALE";
    private NavPollHealth(){}
    public static String classify(boolean enabled, boolean connected,
                                  long connectedElapsed, long polledElapsed, long nowElapsed){
        if(!enabled)return OFF;
        if(!connected)return DISCONNECTED;
        if(connectedElapsed<=0 || nowElapsed<connectedElapsed)return STARTING;
        if(polledElapsed<=0 || polledElapsed<connectedElapsed){
            return nowElapsed-connectedElapsed>STALE_MS?STALE:STARTING;
        }
        if(nowElapsed<polledElapsed)return STARTING; // monotonic after process reset
        return nowElapsed-polledElapsed>STALE_MS?STALE:ACTIVE;
    }
    public static boolean allowRepair(String state,long nowElapsed,long lastRepairElapsed){
        return STALE.equals(state) && nowElapsed>0 &&
            (lastRepairElapsed<=0 || nowElapsed<lastRepairElapsed ||
             nowElapsed-lastRepairElapsed>=REPAIR_COOLDOWN_MS);
    }
    public static String userLabel(String s){
        if(OFF.equals(s))return "연동 꺼짐";
        if(DISCONNECTED.equals(s))return "접근성 서비스 미연결 (설정 확인)";
        if(STARTING.equals(s))return "첫 화면 조회 대기";
        if(ACTIVE.equals(s))return "화면 조회 루프 동작 중 (TBT 수신과 별개)";
        if(STALE.equals(s))return "화면 조회 지연 · 자동 복구 시도";
        return "상태 확인 중";
    }
}
