package com.dolphin.oemhud;

import java.util.Calendar;
import java.util.Locale;

/** User-defined, local-wall-clock fallback. No network, GPS or OEM vehicle I/O. */
public final class HudBrightnessSchedule {
    public static final int DEFAULT_DAY_START=7*60;
    public static final int DEFAULT_NIGHT_START=19*60;
    public static final String KEY_DAY_START="hud_brightness_day_start_mins";
    public static final String KEY_NIGHT_START="hud_brightness_night_start_mins";
    /** 0 = Android light sensor priority, clock fallback; 1 = local clock only. */
    public static final String KEY_SOURCE="hud_brightness_source_mode";
    private HudBrightnessSchedule(){}
    public static int validMinute(int m,int defaultValue){return m>=0&&m<24*60?m:defaultValue;}
    public static boolean validPair(int dayStart,int nightStart){
        return dayStart>=0&&dayStart<1440&&nightStart>=0&&nightStart<1440&&dayStart!=nightStart;
    }
    /** The daytime window goes from dayStart inclusive to nightStart exclusive, wrapping midnight if needed. */
    public static boolean isNight(int minute,int dayStart,int nightStart){
        minute=validMinute(minute,0);
        dayStart=validMinute(dayStart,DEFAULT_DAY_START);
        nightStart=validMinute(nightStart,DEFAULT_NIGHT_START);
        if(dayStart==nightStart){dayStart=DEFAULT_DAY_START;nightStart=DEFAULT_NIGHT_START;}
        boolean day=(dayStart<nightStart)
            ?minute>=dayStart&&minute<nightStart
            :minute>=dayStart||minute<nightStart;
        return !day;
    }
    public static boolean nowIsNight(int dayStart,int nightStart){
        Calendar now=Calendar.getInstance();
        return isNight(now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE),dayStart,nightStart);
    }
    public static String clockLabel(int minute){
        int value=validMinute(minute,0);
        return String.format(Locale.KOREA,"%02d:%02d",value/60,value%60);
    }
    public static String summary(int dayStart,int nightStart){
        return "주간 시작 "+clockLabel(dayStart)+" · 야간 시작 "+clockLabel(nightStart);
    }
}
