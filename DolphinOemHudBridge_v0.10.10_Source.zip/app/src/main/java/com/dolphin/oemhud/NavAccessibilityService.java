package com.dolphin.oemhud;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.graphics.Rect;
import java.util.ArrayList;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

/** TMAP/selected navigator: read-only visible guidance, only with user-enabled accessibility.
 * Never taps the OEM UI, sends a vehicle signal, or reads unrelated windows' text. */
public final class NavAccessibilityService extends AccessibilityService {
    // Explicit, parked-only window ownership evidence. Not a screenshot, OCR, or a TBT source.
    // The instance exists only while Android has the accessibility service connected.
    private static volatile NavAccessibilityService probeInstance;
    private final ArrayList<Runnable> probeTasks=new ArrayList<>();
    private long probeUntilElapsed, probeLastCaptureElapsed;
    private int probeSamples;
    private String lastCueKey="";
    private long lastCueAt, lastObservationAt, lastTreeAt;
    private int lastEventCount;
    private int emptyPollStreak;
    private volatile long connectedElapsed, lastPollElapsed;
    private volatile boolean receiverAttached;
    /** Only same-process, already-authorized accessibility instance can be restarted. */
    public static boolean isReceiverAttached(){
        NavAccessibilityService s=probeInstance;
        return s!=null && s.receiverAttached;
    }
    public static long receiverConnectedElapsed(){
        NavAccessibilityService s=probeInstance;
        return s==null?0:s.connectedElapsed;
    }
    public static long receiverLastPollElapsed(){
        NavAccessibilityService s=probeInstance;
        return s==null?0:s.lastPollElapsed;
    }
    public static boolean requestSafePollRecovery(Context requester){
        NavAccessibilityService s=probeInstance;
        if(s==null || !s.receiverAttached)return false;
        s.pollHandler.post(()->{
            if(probeInstance!=s || !s.receiverAttached ||
                !s.getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
            s.pollHandler.removeCallbacks(s.periodicGuideScan);
            s.pollHandler.post(s.periodicGuideScan);
            android.content.SharedPreferences p=s.getSharedPreferences(BridgeLog.STORE,0);
            p.edit().putInt("nav_poll_repair_count",p.getInt("nav_poll_repair_count",0)+1)
                .putLong("nav_poll_repair_last_at",System.currentTimeMillis()).apply();
            BridgeLog.event(s,"화면 조회 루프 재예약 · Android 접근성 권한/서비스 강제 시작 없음");
        });
        return true;
    }
    private final Handler pollHandler=new Handler(Looper.getMainLooper());
    private final Runnable periodicGuideScan=new Runnable(){
        @Override public void run(){
            String outcome="DISABLED";
            long startedElapsed=SystemClock.elapsedRealtime();
            try{
                android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
                p.edit().putLong("nav_poll_loop_last_tick_at",System.currentTimeMillis()).apply();
                if(p.getBoolean("enabled",false)){
                    lastPollElapsed=startedElapsed;
                    String nav=p.getString("nav_package","").trim();
                    if(nav.isEmpty())nav="com.tmap.auto.byd";
                    long scanWallTime=System.currentTimeMillis();
                    p.edit().putLong("nav_poll_last_attempt_at",scanWallTime)
                        .putInt("nav_session_polls",p.getInt("nav_session_polls",0)+1).apply();
                    String text=readNavigatorWindows(nav);
                    NavCue pollCue=NavCue.fromText("TMAP 자동화면:"+nav,text);
                    NavInputTrace.observe(NavAccessibilityService.this,nav,"access_poll",text.length(),
                        NavCue.hasDirectionToken(text),NavCue.hasDistanceToken(text),
                        pollCue!=null&&pollCue.isUsable());
                    if(!text.isEmpty()){
                        outcome="TEXT";
                        emptyPollStreak=0;
                        p.edit().putLong("nav_poll_last_success_at",scanWallTime)
                            .putInt("nav_poll_scans_count",p.getInt("nav_poll_scans_count",0)+1)
                            .putString("last_nav_package",nav)
                            .putInt("nav_visible_text_chars",text.length())
                            .putBoolean("nav_distance_token_seen",NavCue.hasDistanceToken(text))
                            .putBoolean("nav_direction_token_seen",NavCue.hasDirectionToken(text)).apply();
                        publish(pollCue,p);
                    }else{
                        outcome="EMPTY";
                        emptyPollStreak=Math.min(5,emptyPollStreak+1);
                        p.edit().putLong("nav_poll_last_empty_at",scanWallTime)
                            .putInt("nav_visible_text_chars",0)
                            .putBoolean("nav_distance_token_seen",false)
                            .putBoolean("nav_direction_token_seen",false).apply();
                    }
                }
            }catch(Exception e){
                outcome="ERROR:"+e.getClass().getSimpleName();
                BridgeLog.event(NavAccessibilityService.this,"화면 자동 조회 오류: "+e.getClass().getSimpleName());
            }finally{
                // Disabled is not a watchdog failure; avoid busy looping when manually stopped.
                long next=WindowProbePolicy.pollInterval(emptyPollStreak);
                getSharedPreferences(BridgeLog.STORE,0).edit()
                    .putString("nav_poll_last_outcome",outcome)
                    .putLong("nav_poll_loop_last_finished_at",System.currentTimeMillis())
                    .putLong("nav_poll_duration_ms",Math.max(0,SystemClock.elapsedRealtime()-startedElapsed))
                    .putLong("nav_poll_next_due_at",System.currentTimeMillis()+next).apply();
                pollHandler.removeCallbacks(this); // only one periodic runnable queued
                pollHandler.postDelayed(this,next);
            }
        }
    };

    /** Called only after the user confirms the existing parked-only manual HUD test.
     * Captures window ownership metadata for at most eight seconds. Never captures text,
     * screenshots, image contents, road names, GPS, or any vehicle signals.
     */
    public static void requestWindowProbe(Context requester){
        android.content.SharedPreferences p=requester.getSharedPreferences(BridgeLog.STORE,0);
        NavAccessibilityService svc=probeInstance;
        if(svc==null){
            p.edit().putString("window_probe_status","접근성 서비스 미연결 · 창 출처 기록 불가")
                .putLong("window_probe_last_at",System.currentTimeMillis()).apply();
            BridgeLog.event(requester,"수동 시험 창 출처 수집 불가: 접근성 서비스 미연결");
            return;
        }
        svc.pollHandler.post(()->svc.beginWindowProbe());
    }

    private void beginWindowProbe(){
        for(Runnable task:probeTasks)pollHandler.removeCallbacks(task);
        probeTasks.clear();probeSamples=0;probeLastCaptureElapsed=0;
        probeUntilElapsed=SystemClock.elapsedRealtime()+WindowProbePolicy.WINDOW_MS;
        android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
        p.edit().putString("window_probe_status","수동 테스트 후 8초 동안 창 출처 수집 중")
            .putString("window_probe_history","")
            .putInt("window_probe_samples",0)
            .putInt("window_probe_change_events",0).apply();
        for(int ms:new int[]{0,300,1000,3000,5000,7500}){
            final int scheduled=ms;
            Runnable task=()->captureWindowMetadata("+"+scheduled+"ms");
            probeTasks.add(task);pollHandler.postDelayed(task,ms);
        }
        Runnable done=()->{
            p.edit().putString("window_probe_status",probeSamples>0?
                "창 메타데이터 "+probeSamples+"회 기록 완료 · 생성 앱 확정 아님":
                "접근 가능한 창 없음 · 확인 불가").apply();
            probeUntilElapsed=0;
        };
        probeTasks.add(done);pollHandler.postDelayed(done,8100);
    }

    private void captureWindowMetadata(String stage){
        long elapsed=SystemClock.elapsedRealtime();
        if(!WindowProbePolicy.canSample(elapsed,probeUntilElapsed,probeSamples,probeLastCaptureElapsed))return;
        probeLastCaptureElapsed=elapsed;
        StringBuilder sample=new StringBuilder(stage).append(" ");
        int count=0;
        try{
            List<AccessibilityWindowInfo> windows=getWindows();
            if(windows!=null){
                for(AccessibilityWindowInfo window:windows){
                    if(window==null||count>=WindowProbePolicy.MAX_WINDOWS_PER_SAMPLE||sample.length()>350)break;
                    AccessibilityNodeInfo root=null;
                    try{
                        root=window.getRoot();
                        String pkg=WindowProbePolicy.safePackage(root!=null?root.getPackageName():null);
                        Rect bounds=new Rect();window.getBoundsInScreen(bounds);
                        sample.append("w").append(count++).append("[")
                            .append(pkg).append(",id=").append(window.getId())
                            .append(",type=").append(window.getType())
                            .append(",layer=").append(window.getLayer())
                            .append(",rect=").append(bounds.left).append(":")
                            .append(bounds.top).append(":").append(bounds.right)
                            .append(":").append(bounds.bottom).append("] ");
                    }finally{if(root!=null)root.recycle();}
                }
            }
        }catch(Exception ex){sample.append("API_UNAVAILABLE:").append(ex.getClass().getSimpleName());}
        if(count==0)sample.append("NO_ACCESSIBLE_WINDOWS");
        probeSamples++;
        android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
        String old=p.getString("window_probe_history","");
        String line=sample.toString();
        String combined=old+(old.isEmpty()?"":"\n")+line;
        if(combined.length()>4500)combined=combined.substring(combined.length()-4500);
        p.edit().putString("window_probe_history",combined)
            .putLong("window_probe_last_at",System.currentTimeMillis())
            .putInt("window_probe_samples",probeSamples).apply();
        BridgeLog.event(this,"창 출처 "+line);
    }

    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        probeInstance=this;
        receiverAttached=true;
        connectedElapsed=SystemClock.elapsedRealtime();
        lastPollElapsed=0;
        AccessibilityServiceInfo info=getServiceInfo();
        if(info!=null){
            info.flags|=AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            setServiceInfo(info);
        }
        android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
        p.edit()
            .putLong("nav_previous_session_last_event_at",p.getLong("last_nav_event_at",0))
            .putLong("last_nav_event_at",0)
            .putLong("nav_poll_last_attempt_at",0)
            .putLong("nav_poll_last_success_at",0)
            .putLong("nav_poll_last_empty_at",0)
            .putInt("nav_visible_text_chars",0)
            .putBoolean("nav_distance_token_seen",false)
            .putBoolean("nav_direction_token_seen",false)
            .putBoolean("a11y_runtime_connected",true)
            .putString("a11y_runtime_state","CONNECTED")
            .putLong("a11y_runtime_at",System.currentTimeMillis())
            .putLong("a11y_session_started_at",System.currentTimeMillis())
            .putLong("nav_poll_loop_last_tick_at",0)
            .putLong("nav_poll_next_due_at",0)
            .putString("nav_poll_last_outcome","AWAITING_FIRST_POLL")
            .putInt("nav_session_events",0)
            .putInt("nav_session_polls",0)
            .putInt("nav_session_parsed",0).apply();
        BridgeLog.event(this,"순정 TMAP 화면 수신기 실제 연결");
        pollHandler.removeCallbacks(periodicGuideScan);
        pollHandler.postDelayed(periodicGuideScan,700);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null)return;
        // Short-window window ownership events are independent of navigation text parsing.
        int eventType=event.getEventType();
        if(probeUntilElapsed>0 && (eventType==AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            eventType==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)){
            android.content.SharedPreferences wp=getSharedPreferences(BridgeLog.STORE,0);
            wp.edit().putInt("window_probe_change_events",wp.getInt("window_probe_change_events",0)+1).apply();
            captureWindowMetadata("WINDOW_CHANGE");
        }
        if(event.getPackageName()==null)return;
        if(!getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
        final String pkg=String.valueOf(event.getPackageName());
        if(!BridgeLog.isNavPackage(this,pkg))return;
        android.content.SharedPreferences prefs=getSharedPreferences(BridgeLog.STORE,0);
        lastEventCount=prefs.getInt("nav_accessibility_count",0)+1;
        prefs.edit().putInt("nav_accessibility_count",lastEventCount)
            .putInt("nav_session_events",prefs.getInt("nav_session_events",0)+1)
            .putString("last_nav_package",pkg)
            .putString("last_nav_input_source","TMAP 접근성 이벤트")
            .putLong("last_nav_event_at",System.currentTimeMillis()).apply();

        StringBuilder eventText=new StringBuilder();
        List<CharSequence> lines=event.getText();
        if(lines!=null)for(CharSequence s:lines){
            if(s!=null && eventText.length()<1000)eventText.append(s).append('\n');
        }
        if(event.getContentDescription()!=null)eventText.append(event.getContentDescription()).append('\n');
        String eventTextValue=eventText.toString();
        NavCue cue=NavCue.fromText("TMAP 화면:"+pkg,eventTextValue);
        NavInputTrace.observe(this,pkg,"access_event",eventTextValue.length(),
            NavCue.hasDirectionToken(eventTextValue),NavCue.hasDistanceToken(eventTextValue),
            cue!=null&&cue.isUsable());
        if(cue==null || !cue.isUsable()){
            // An OEM TBT may consist of separate TextViews: distance, direction, lane.
            // Gather only nodes that belong to the selected navigator window.
            long now=SystemClock.elapsedRealtime();
            if(now-lastTreeAt>=450){
                lastTreeAt=now;
                String visible=readNavigatorWindows(pkg);
                NavCue treeCue=NavCue.fromText("TMAP 화면트리:"+pkg,visible);
                NavInputTrace.observe(this,pkg,"access_tree",visible.length(),
                    NavCue.hasDirectionToken(visible),NavCue.hasDistanceToken(visible),
                    treeCue!=null&&treeCue.isUsable());
                if(!visible.isEmpty()){
                    prefs.edit().putInt("nav_tree_scan_count",prefs.getInt("nav_tree_scan_count",0)+1)
                        .putInt("nav_visible_text_chars",visible.length())
                        .putBoolean("nav_distance_token_seen",NavCue.hasDistanceToken(visible))
                        .putBoolean("nav_direction_token_seen",NavCue.hasDirectionToken(visible)).apply();
                    cue=treeCue;
                }
            }
        }
        if(cue==null || !cue.isUsable()){
            if(lastEventCount%15==1) prefs.edit()
                .putInt("nav_parse_missing_count",prefs.getInt("nav_parse_missing_count",0)+1).apply();
            long now=SystemClock.elapsedRealtime();
            if(now-lastObservationAt>15000){
                lastObservationAt=now;
                BridgeLog.event(this,"순정 내비 화면 이벤트 감지, 회전/거리 짝 미확인 · pkg="+pkg+
                    " / event="+lastEventCount+" / tree="+prefs.getInt("nav_tree_scan_count",0));
            }
            return;
        }
        publish(cue,prefs);
    }
    private void publish(NavCue cue,android.content.SharedPreferences prefs){
        if(cue==null||!cue.isUsable())return;
        String key=cue.direction+"/"+cue.distanceMeters;
        long now=SystemClock.elapsedRealtime();
        // A stationary turn label must not flood the BLE queue every polling cycle.
        if(key.equals(lastCueKey)&&now-lastCueAt<15000)return;
        lastCueKey=key;lastCueAt=now;
        prefs.edit().putInt("nav_parsed_count",prefs.getInt("nav_parsed_count",0)+1)
            .putInt("nav_session_parsed",prefs.getInt("nav_session_parsed",0)+1)
            .putLong("nav_last_parsed_at",System.currentTimeMillis())
            .putString("last_nav_input_source",cue.source).apply();
        BridgeLog.cue(this,cue);
    }

    /** Restrict content collection to nodes labelled with the exact emitting navigation package. */
    private String readNavigatorWindows(String pkg){
        StringBuilder all=new StringBuilder();
        int[] screenEvidence=new int[]{0,0}; // OEM distance widgets, unlabeled images (not actual TBT direction)
        AccessibilityNodeInfo root=null;
        try{
            root=getRootInActiveWindow();
            if(root!=null)collect(root,pkg,all,0,new int[]{0},screenEvidence);
        }catch(Exception ignored){}
        finally{if(root!=null)root.recycle();}
        if(all.length()==0){
            // The active root is read first; only scan other windows if it yielded no
            // navigator-labelled text. Prevent duplicate/mixed maneuver candidates.
            try{
                List<AccessibilityWindowInfo> windows=getWindows();
                if(windows!=null)for(AccessibilityWindowInfo window:windows){
                    if(all.length()>=1500)break;
                    AccessibilityNodeInfo r=window.getRoot();
                    if(r!=null)try{collect(r,pkg,all,0,new int[]{0},screenEvidence);}finally{r.recycle();}
                }
            }catch(Exception ignored){}
        }
        if(OemTmapStateSignal.PACKAGE.equals(pkg)){
            getSharedPreferences(BridgeLog.STORE,0).edit()
                .putInt("oem_tbt_distance_widgets_last",screenEvidence[0])
                .putInt("oem_unlabeled_images_last",screenEvidence[1])
                .putString("oem_direction_access","NOT_EXPOSED_BY_TEXT_OR_VIEW_ID")
                .apply();
        }
        return all.length()>1600?all.substring(0,1600):all.toString();
    }
    private static void collect(AccessibilityNodeInfo n,String pkg,StringBuilder out,int depth,int[] seen,int[] screenEvidence){
        if(n==null||depth>12||seen[0]++>300||out.length()>1500)return;
        CharSequence owner=n.getPackageName();
        if(owner!=null && pkg.contentEquals(owner)){
            append(out,n.getText());append(out,n.getContentDescription());
            // HUD-RE-008/010: getViewIdResourceName() is a VIEW ID, NEVER the
            // current ImageView.setImageResource() drawable. OEM TBT arrows
            // have neither view IDs nor contentDescription. Do not create
            // fake turns from this value. Only record non-sensitive counts.
            if(OemTmapStateSignal.PACKAGE.equals(pkg)){
                CharSequence klass=n.getClassName();
                if(klass!=null){
                    String type=String.valueOf(klass);
                    if(type.endsWith("TbtDistanceTextView"))screenEvidence[0]++;
                    if(type.endsWith("ImageView")&&n.getContentDescription()==null)screenEvidence[1]++;
                }
            }
        }
        for(int i=0;i<n.getChildCount()&&i<60&&out.length()<1500;i++){
            AccessibilityNodeInfo child=n.getChild(i);
            if(child!=null)try{collect(child,pkg,out,depth+1,seen,screenEvidence);}finally{child.recycle();}
        }
    }
    private static void append(StringBuilder out,CharSequence s){
        if(s!=null&&s.length()>0&&out.length()<1500)out.append(s).append('\n');
    }
    @Override public void onInterrupt(){BridgeLog.event(this,"순정 TMAP 화면 수신 일시 중단");}
    @Override public void onDestroy(){
        pollHandler.removeCallbacks(periodicGuideScan);
        for(Runnable task:probeTasks)pollHandler.removeCallbacks(task);
        probeTasks.clear();probeUntilElapsed=0;
        receiverAttached=false;
        if(probeInstance==this)probeInstance=null;
        getSharedPreferences(BridgeLog.STORE,0).edit()
            .putBoolean("a11y_runtime_connected",false)
            .putString("a11y_runtime_state","DISCONNECTED")
            .putLong("a11y_disconnected_at",System.currentTimeMillis()).apply();
        super.onDestroy();
    }
}
