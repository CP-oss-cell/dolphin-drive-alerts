package com.dolphin.oemhud;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Pick a navigation app by visible name/icon, never by typing its package name. */
public final class NavAppPickerActivity extends Activity {
    private static final int INK = Color.rgb(235,242,250);
    private static final int MUTED = Color.rgb(163,179,198);
    private static final int TEAL = Color.rgb(102,214,212);
    private final ArrayList<NavAppCatalog.Entry> installed = new ArrayList<>();
    private final ArrayList<NavAppCatalog.Entry> filtered = new ArrayList<>();
    private SharedPreferences prefs;
    private AppAdapter adapter;
    private TextView summary, counter;
    private EditText search;
    private Switch includeSystem;
    private boolean loaded;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences(BridgeLog.STORE,0);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(14),dp(16),dp(10));
        root.setBackgroundColor(Color.rgb(11,16,24));
        TextView title=text("① 내비 앱 선택 · 전체 설치 앱",22,INK,true);
        root.addView(title);
        root.addView(text("앱 이름과 아이콘을 확인한 후 선택하세요. 패키지명은 자동 저장됩니다.",13,MUTED,false));
        summary=text("",14,TEAL,true);
        summary.setPadding(0,dp(10),0,dp(4));root.addView(summary);
        Button automatic=new Button(this);automatic.setAllCaps(false);
        automatic.setText("자동 감지 사용 (앱 지정 해제)");
        root.addView(automatic);
        automatic.setOnClickListener(v -> saveSelection("","자동 감지"));
        search=new EditText(this);search.setSingleLine(true);
        search.setTextSize(15);search.setHint("앱 이름 또는 패키지명 검색");
        search.setTextColor(INK);search.setHintTextColor(MUTED);
        search.setBackgroundColor(Color.rgb(39,54,73));
        root.addView(search);
        includeSystem=new Switch(this);
        includeSystem.setText("시스템 앱 포함 · 전체 목록 표시");includeSystem.setTextColor(INK);
        includeSystem.setChecked(true);
        root.addView(includeSystem);
        counter=text("설치된 앱을 불러오는 중...",12,MUTED,false);
        root.addView(counter);
        Button reload=new Button(this);reload.setAllCaps(false);reload.setText("목록 새로고침");
        root.addView(reload);
        reload.setOnClickListener(v -> loadPackages());
        ListView list=new ListView(this);
        adapter=new AppAdapter();list.setAdapter(adapter);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1f);
        root.addView(list,lp);
        list.setOnItemClickListener((parent,view,position,id)->{
            NavAppCatalog.Entry e=(NavAppCatalog.Entry)adapter.getItem(position);
            if(e==null)return;
            if(!e.enabled){new AlertDialog.Builder(this).setTitle("사용 중지된 앱").setMessage("이 앱은 현재 비활성 상태여서 선택할 수 없습니다.\n"+e.label).setPositiveButton("확인",null).show();return;}
            new AlertDialog.Builder(this)
                .setTitle("이 앱을 내비게이션으로 지정할까요?")
                .setMessage(e.label+"\n"+e.packageName+"\n\n선택 후 길안내가 없는 앱은 HUD에 표시되지 않습니다.")
                .setNegativeButton("취소",null)
                .setPositiveButton("선택",(d,w)->saveSelection(e.packageName,e.label))
                .show();
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){render();}
            @Override public void afterTextChanged(Editable s){}
        });
        includeSystem.setOnCheckedChangeListener((button,checked)->render());
        setContentView(root);refreshSummary();loadPackages();
    }

    private void loadPackages(){
        new Thread(() -> {
            ArrayList<NavAppCatalog.Entry> result=new ArrayList<>();
            String error=null;
            try {
                PackageManager pm=getPackageManager();
                List<ApplicationInfo> infos=pm.getInstalledApplications(0);
                for(ApplicationInfo info:infos){
                    if(info==null || info.packageName==null)continue;
                    String label=info.packageName;
                    try {CharSequence name=pm.getApplicationLabel(info);
                        if(name!=null && name.length()>0)label=name.toString();}catch(Exception ignored){}
                    boolean launchable=false;
                    try{launchable=pm.getLaunchIntentForPackage(info.packageName)!=null;}catch(Exception ignored){}
                    result.add(new NavAppCatalog.Entry(info.packageName,label,launchable,info.enabled));
                }
            } catch (Exception e) {error=e.getClass().getSimpleName();}
            String finalError=error;
            runOnUiThread(() -> {
                if(isFinishing() || isDestroyed())return;
                installed.clear();installed.addAll(result);loaded=true;render();
                if(finalError!=null)counter.setText("앱 목록 조회 실패: "+finalError);
            });
        },"hud-nav-app-picker").start();
    }

    private void saveSelection(String packageName,String label){
        prefs.edit().putString("nav_package",packageName)
            .putString("selected_nav_label",packageName.isEmpty()?"":label).apply();
        BridgeLog.event(this,packageName.isEmpty()?"내비 자동 감지로 변경":"사용자가 내비 앱 선택: "+packageName);
        setResult(RESULT_OK);
        finish();
    }
    private void refreshSummary(){
        String pkg=prefs.getString("nav_package","");
        String label=prefs.getString("selected_nav_label","");
        summary.setText(pkg.isEmpty()?"현재: 자동 감지": "현재 선택: "+(label.isEmpty()?pkg:label));
    }
    private void render(){
        if(adapter==null || search==null || includeSystem==null)return;
        String pkg=prefs.getString("nav_package","");
        List<NavAppCatalog.Entry> shown=NavAppCatalog.visible(installed,
            search.getText().toString(),includeSystem.isChecked(),pkg);
        filtered.clear();filtered.addAll(shown);
        adapter.notifyDataSetChanged();
        if(loaded)counter.setText(filtered.isEmpty()?"표시할 앱이 없습니다 · 전체 목록 표시 또는 검색어를 확인하세요":"설치 앱 "+installed.size()+"개 · 표시 "+filtered.size()+"개 (내비 후보 우선)");
    }
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private final class AppAdapter extends BaseAdapter {
        @Override public int getCount(){return filtered.size();}
        @Override public Object getItem(int position){return position>=0 && position<filtered.size()?filtered.get(position):null;}
        @Override public long getItemId(int position){return position;}
        @Override public View getView(int position,View recycled,ViewGroup parent){
            NavAppCatalog.Entry entry=filtered.get(position);
            LinearLayout line=new LinearLayout(NavAppPickerActivity.this);
            line.setGravity(Gravity.CENTER_VERTICAL);line.setOrientation(LinearLayout.HORIZONTAL);
            line.setPadding(dp(8),dp(8),dp(8),dp(8));
            line.setBackgroundColor(position%2==0?Color.rgb(26,37,52):Color.rgb(34,46,63));
            ImageView icon=new ImageView(NavAppPickerActivity.this);
            try {Drawable d=getPackageManager().getApplicationIcon(entry.packageName);
                icon.setImageDrawable(d);}catch(Exception ignored){}
            line.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
            LinearLayout labels=new LinearLayout(NavAppPickerActivity.this);
            labels.setOrientation(LinearLayout.VERTICAL);labels.setPadding(dp(12),0,0,0);
            labels.addView(text(entry.label+(entry.navigationCandidate?" · 내비 후보":"")+(entry.enabled?"":" · 사용 중지"),15,INK,true));
            labels.addView(text(entry.packageName,11,MUTED,false));
            line.addView(labels,new LinearLayout.LayoutParams(0,-2,1f));
            return line;
        }
    }
}
