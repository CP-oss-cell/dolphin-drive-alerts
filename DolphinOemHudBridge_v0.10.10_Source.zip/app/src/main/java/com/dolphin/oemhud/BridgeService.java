package com.dolphin.oemhud;

import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.os.*;
import java.util.*;

/** Keeps the TBT->HUD link running without MCon K. No OEM vehicle writes. */
public final class BridgeService extends Service {
    public static final String ACTION_CONNECT="com.dolphin.oemhud.CONNECT";
    public static final String ACTION_DISCONNECT="com.dolphin.oemhud.DISCONNECT";
    public static final String ACTION_DEMO="com.dolphin.oemhud.DEMO";
    public static final String ACTION_BUZZER="com.dolphin.oemhud.SET_BUZZER";
    public static final String ACTION_BRIGHTNESS="com.dolphin.oemhud.SET_BRIGHTNESS";
    public static final String ACTION_BRIGHTNESS_REFRESH="com.dolphin.oemhud.REFRESH_BRIGHTNESS";
    public static final String EXTRA_ADDRESS="address";
    private static volatile BridgeService active;
    private static final String CH="navbridge_status";
    private BroadcastReceiver receiver;
    private BroadcastReceiver bluetoothReceiver;
    private BroadcastReceiver timeReceiver;
    private BroadcastReceiver oemStateReceiver;
    private HudConnector hud;
    private HudAutoBrightness autoBrightness;
    private String lastCueKey="";
    private long lastCueAt;
    private final Handler healthHandler=new Handler(Looper.getMainLooper());
    private long lastRepairElapsed;
    private final Runnable healthMonitor=new Runnable(){
        @Override public void run(){
            try{checkNavReceiverHealth();}
            catch(Exception e){BridgeLog.event(BridgeService.this,
                "수신기 상태 확인 예외: "+e.getClass().getSimpleName());}
            finally{healthHandler.postDelayed(this,NavPollHealth.MONITOR_INTERVAL_MS);}
        }
    };
    private void checkNavReceiverHealth(){
        android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
        long nowElapsed=SystemClock.elapsedRealtime();
        long nowWall=System.currentTimeMillis();
        boolean enabled=p.getBoolean("enabled",false);
        boolean connected=NavAccessibilityService.isReceiverAttached();
        String state=NavPollHealth.classify(enabled,connected,
            NavAccessibilityService.receiverConnectedElapsed(),
            NavAccessibilityService.receiverLastPollElapsed(),nowElapsed);
        String previous=p.getString("nav_watchdog_state","");
        p.edit().putString("nav_watchdog_state",state)
            .putLong("nav_watchdog_last_check_at",nowWall)
            .putBoolean("nav_watchdog_attached",connected).apply();
        if(!previous.equals(state))BridgeLog.event(this,"화면 수신 감시: "+state);
        if(NavPollHealth.allowRepair(state,nowElapsed,lastRepairElapsed)){
            lastRepairElapsed=nowElapsed;
            p.edit().putLong("nav_watchdog_repair_requested_at",nowWall).apply();
            if(!NavAccessibilityService.requestSafePollRecovery(this))
                BridgeLog.event(this,"수신기 루프 복구 불가: 접근성 서비스 미연결");
        }
    }
    @Override public void onCreate(){
        super.onCreate();active=this;hud=new HudConnector(this);
        autoBrightness=new HudAutoBrightness(this,hud);
        autoBrightness.refresh();
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel(CH,"내비 HUD 연결",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder nb=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);
        Notification n=nb.setContentTitle("돌핀 순정내비 → HUD Q").setContentText("TBT 수신 및 HUD 연결 유지")
            .setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pending).setOngoing(true).build();
        startForeground(4109,n);
        healthHandler.removeCallbacks(healthMonitor);
        healthHandler.postDelayed(healthMonitor,12000L);
        receiver=new BroadcastReceiver(){
            @Override public void onReceive(Context context,Intent intent){
                if(!getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
                Bundle b=intent.getExtras();if(b==null)return;
                try{
                    // HUD-RE-006/012: the actual 2602/2606 OEM TMAP APK has
                    // NO reference to this AutoNavi broadcast action. Do not
                    // interpret a spoofable broadcast as OEM TBT when OEM is
                    // selected (or when automatic app detection is selected).
                    android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
                    String selected=p.getString("nav_package","").trim();
                    if(selected.isEmpty() || OemTmapStateSignal.PACKAGE.equals(selected)){
                        p.edit().putInt("autonavi_ignored_for_oem",p.getInt("autonavi_ignored_for_oem",0)+1).apply();
                        return;
                    }
                    int type=NavCue.number(b,-1,"KEY_TYPE");
                    if(type==10001){
                        // Android 10 unprotected dynamic broadcasts do not authenticate a
                        // sender. Do NOT create an automatic turn from an unverified frame.
                        // Count fields only, without value disclosure or pretending OEM TBT.
                        int count=p.getInt("compat_broadcast_observed",0)+1;
                        NavInputTrace.observe(context,"unverified.broadcast","compat_broadcast",0,
                            false,false,false);
                        p.edit().putInt("compat_broadcast_observed",count)
                          .putString("compat_broadcast_auth","UNVERIFIED_DIAGNOSTIC_ONLY").apply();
                        BridgeLog.event(context,"호환 AutoNavi 방송 관측#"+count+" · 발신 미인증/자동 HUD 차단 "+safeExtras(b));
                    }else if(type==10019){BridgeLog.event(context,"AutoNavi 호환 상태 방송 관측(진단 전용)");}
                }catch(Exception e){BridgeLog.event(context,"순정방송 해석 오류: "+e.getClass().getSimpleName());}
            }
        };
        IntentFilter f=new IntentFilter("AUTONAVI_STANDARD_BROADCAST_SEND");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_EXPORTED);else registerReceiver(receiver,f);
        // Directly observed in the 2602/2606 BydAutoTMap.apk, these two
        // actions publish navigation/map ACTIVITY STATUS, not TBT. Strictly
        // keep them out of the NavCue/HUD transmit path.
        oemStateReceiver=new BroadcastReceiver(){
            @Override public void onReceive(Context context,Intent intent){
                if(intent==null)return;
                android.content.SharedPreferences prefs=getSharedPreferences(BridgeLog.STORE,0);
                if(!prefs.getBoolean("enabled",false))return;
                String selected=prefs.getString("nav_package","").trim();
                if(!selected.isEmpty()&&!OemTmapStateSignal.PACKAGE.equals(selected))return;
                Bundle extras=intent.getExtras();
                if(extras==null)return;
                Object pkg=extras.get("packageName");
                OemTmapStateSignal signal=OemTmapStateSignal.read(intent.getAction(),
                    pkg==null?null:String.valueOf(pkg),extras.get("state"));
                if(signal==null){
                    prefs.edit().putInt("oem_state_ignored",prefs.getInt("oem_state_ignored",0)+1).apply();
                    return;
                }
                int count=prefs.getInt("oem_state_observed_count",0)+1;
                prefs.edit().putInt("oem_state_observed_count",count)
                    .putString("oem_state_last",signal.diagnostic())
                    .putLong("oem_state_last_at",System.currentTimeMillis()).apply();
                BridgeLog.event(context,signal.diagnostic());
            }
        };
        IntentFilter oemStatusFilter=new IntentFilter(OemTmapStateSignal.NAVIGATION_STATE);
        oemStatusFilter.addAction(OemTmapStateSignal.MAP_ACTIVITY_STATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(oemStateReceiver,oemStatusFilter,Context.RECEIVER_EXPORTED);
        else registerReceiver(oemStateReceiver,oemStatusFilter);
        bluetoothReceiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent i){
                if(BluetoothAdapter.ACTION_STATE_CHANGED.equals(i.getAction()) &&
                   i.getIntExtra(BluetoothAdapter.EXTRA_STATE,0)==BluetoothAdapter.STATE_ON)
                   hud.retryWhenBluetoothEnabled();
            }
        };
        registerReceiver(bluetoothReceiver,new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED));
        // Dynamic registration: Android system clock/timezone events, not vehicle data.
        timeReceiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent intent){
                autoBrightness.clockChanged();
            }
        };
        IntentFilter timeFilter=new IntentFilter(Intent.ACTION_TIME_CHANGED);
        timeFilter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        timeFilter.addAction(Intent.ACTION_DATE_CHANGED);
        registerReceiver(timeReceiver,timeFilter);
        BridgeLog.event(this,"HUD 브리지 서비스 가동 · 순정 상태 방송(TBT 아님)/알림/접근성 수신 대기");
    }
    private static String safeExtras(Bundle b){
        // A debug ZIP may be shared. Log names and total count, never road names,
        // destination, raw coordinates, or untrusted string values.
        int total=b==null?0:b.keySet().size();
        return "extras_count="+total+" (values_redacted)";
    }
    public static boolean onCue(NavCue cue){
        BridgeService a=active;
        if(a==null)return false;
        a.acceptCue(cue);
        return true;
    }
    private void deliverPending(){
        android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
        long at=p.getLong("pending_at",0);
        if(at<=0)return;
        String direction=p.getString("pending_direction","");
        int meters=p.getInt("pending_distance",-1);
        String source=p.getString("pending_source","재시작 전 TMAP");
        p.edit().remove("pending_at").remove("pending_direction")
            .remove("pending_distance").remove("pending_source").apply();
        if(System.currentTimeMillis()-at>5000 || at>System.currentTimeMillis()+5000)return;
        NavCue cue=new NavCue(source,direction,meters,"",-1,-1,"");
        if(cue.isUsable())acceptCue(cue);
    }
    private synchronized void acceptCue(NavCue cue){
        if(cue==null||!cue.isUsable())return;
        if(!getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
        String key=cue.direction+"/"+cue.distanceMeters;
        long now=System.currentTimeMillis();
        if(key.equals(lastCueKey)&&now-lastCueAt<1800)return;
        lastCueKey=key;lastCueAt=now;
        getSharedPreferences(BridgeLog.STORE,0).edit()
            .putInt("nav_tbt_hud_attempts",getSharedPreferences(BridgeLog.STORE,0).getInt("nav_tbt_hud_attempts",0)+1).apply();
        boolean result=hud.sendTurn(cue);
        NavInputTrace.queueResult(this,cue.source,result);
        BridgeLog.event(this,result?"TBT→HUD 큐 접수 (GATT 완료 여부 별도 확인)":"TBT→HUD 전송 대기 (BLE 연결/패킷 확인 필요)");
    }
    private void connect(String mac){
        if(mac==null || mac.isEmpty())return;
        try{
            BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
            if(adapter==null||!adapter.isEnabled())return;
            BluetoothDevice d=adapter.getRemoteDevice(mac);
            hud.connect(d,s->{});
        }catch(Exception e){BridgeLog.event(this,"HUD 자동 연결 실패 "+e.getClass().getSimpleName()+": "+e.getMessage());}
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?null:intent.getAction();
        if(ACTION_DISCONNECT.equals(action)){hud.disconnect();getSharedPreferences(BridgeLog.STORE,0).edit().remove("hud_mac").apply();}
        else if(ACTION_CONNECT.equals(action)){
            String mac=intent.getStringExtra(EXTRA_ADDRESS);
            if(mac!=null){getSharedPreferences(BridgeLog.STORE,0).edit().putString("hud_mac",mac).apply();connect(mac);}
        }else if(ACTION_BUZZER.equals(action)){
            boolean enabled=intent.getBooleanExtra("enabled",true);
            int level=intent.getIntExtra("level",1);
            try{
                byte[] frame=HudSettingsProtocol.buzzer(enabled,level);
                getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("hud_buzzer_saved",true)
                    .putBoolean("hud_buzzer_enabled",enabled).putInt("hud_buzzer_level",level)
                    .putString("hud_setting_status","부저 설정 전송 대기 / 전송 시도").apply();
                if(!hud.isReady())connect(getSharedPreferences(BridgeLog.STORE,0).getString("hud_mac",""));
                else hud.sendSetting(frame);
            }catch(IllegalArgumentException e){BridgeLog.event(this,"잘못된 부저 설정 차단");}
        }else if(ACTION_BRIGHTNESS.equals(action)){
            boolean auto=intent.getBooleanExtra("auto",true);
            int day=intent.getIntExtra("day",2),night=intent.getIntExtra("night",0);
            int dayStart=intent.getIntExtra("day_start",HudBrightnessSchedule.DEFAULT_DAY_START);
            int nightStart=intent.getIntExtra("night_start",HudBrightnessSchedule.DEFAULT_NIGHT_START);
            int source=intent.getIntExtra("source_mode",0);
            try{
                if(!HudBrightnessSchedule.validPair(dayStart,nightStart) || source<0 || source>1){
                    BridgeLog.event(this,"잘못된 시간표/밝기 모드 차단");return START_STICKY;
                }
                byte[] frame=HudSettingsProtocol.brightness(day,day);
                getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("hud_brightness_saved",true)
                    .putBoolean("hud_brightness_auto",auto).putInt("hud_brightness_day",day)
                    .putInt("hud_brightness_night",night)
                    .putInt(HudBrightnessSchedule.KEY_DAY_START,dayStart)
                    .putInt(HudBrightnessSchedule.KEY_NIGHT_START,nightStart)
                    .putInt(HudBrightnessSchedule.KEY_SOURCE,source)
                    .putString("hud_setting_status","밝기 설정 전송 대기 / 전송 시도").apply();
                if(auto){
                    autoBrightness.refresh();
                }else{
                    autoBrightness.stop();
                    hud.sendSetting(frame);
                }
                if(!hud.isReady())connect(getSharedPreferences(BridgeLog.STORE,0).getString("hud_mac",""));
            }catch(IllegalArgumentException e){BridgeLog.event(this,"잘못된 밝기 설정 차단");}
        }else if(ACTION_BRIGHTNESS_REFRESH.equals(action)){
            autoBrightness.refresh();
        }else if(ACTION_DEMO.equals(action)){
            // One explicit, parked-only probe separates missing TBT from BLE output.
            // Does not touch vehicle OEM settings.
            if(!hud.isReady())connect(getSharedPreferences(BridgeLog.STORE,0).getString("hud_mac",""));
            NavCue demo=new NavCue("수동 시험","우회전",300,"HUD 시험",-1,-1,"");
            boolean ready=hud.sendTurn(demo);
            getSharedPreferences(BridgeLog.STORE,0).edit().putString("hud_demo_status",
                ready?"우회전 300m BLE 쓰기 요청됨 · 표시 미확인":"우회전 300m 연결 대기 · 표시 미확인").apply();
            BridgeLog.event(this,"사용자 요청 HUD 출력 경로 시험 · "+(ready?"GATT 쓰기 요청":"BLE 연결 대기"));
        }else{
            connect(getSharedPreferences(BridgeLog.STORE,0).getString("hud_mac",""));
        }
        deliverPending();
        return START_STICKY;
    }
    @Override public void onDestroy(){
        active=null;
        if(receiver!=null)unregisterReceiver(receiver);
        if(oemStateReceiver!=null)unregisterReceiver(oemStateReceiver);
        if(bluetoothReceiver!=null)unregisterReceiver(bluetoothReceiver);
        if(timeReceiver!=null)unregisterReceiver(timeReceiver);
        healthHandler.removeCallbacks(healthMonitor);
        getSharedPreferences(BridgeLog.STORE,0).edit()
            .putString("nav_watchdog_state","BRIDGE_STOPPED")
            .putLong("nav_watchdog_last_check_at",System.currentTimeMillis()).apply();
        autoBrightness.stop();hud.disconnect();super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
