package com.dolphin.oemhud;

import android.content.Context;
import android.content.SharedPreferences;

/** Per-navigator, per-channel diagnostic counters. No notification text, screenshot, URL,
 * coordinates, navigation destination or road name is persisted. Counts mean observations,
 * not authenticated TBT source or HUD screen success. */
public final class NavInputTrace {
    private static final String[] GROUPS={NavTracePolicy.OEM,NavTracePolicy.GENERAL,NavTracePolicy.OTHER};
    private static final String[] CHANNELS={"access_event","access_tree","access_poll","notification","compat_broadcast"};
    private NavInputTrace(){}
    private static String prefix(String group, String channel){return "trace_v18_"+group+"_"+channel+"_";}
    private static void inc(SharedPreferences p,SharedPreferences.Editor ed,String key){ed.putInt(key,p.getInt(key,0)+1);}
    public static synchronized void observe(Context ctx,String pkg,String channel,int length,boolean direction,boolean distance,boolean parsed){
        String group=NavTracePolicy.group(pkg);
        boolean validChannel=false;
        for(String candidate:CHANNELS)if(candidate.equals(channel)){validChannel=true;break;}
        if(!validChannel)return;
        SharedPreferences p=ctx.getSharedPreferences(BridgeLog.STORE,0);
        SharedPreferences.Editor ed=p.edit();
        String k=prefix(group,channel);
        boolean text=length>0;
        inc(p,ed,k+"events");
        if(text)inc(p,ed,k+"text");
        if(direction)inc(p,ed,k+"direction");
        if(distance)inc(p,ed,k+"distance");
        if(direction && distance)inc(p,ed,k+"both");
        if(parsed)inc(p,ed,k+"parsed");
        ed.putString(k+"stage",NavTracePolicy.stage(text,direction,distance,parsed))
          .putInt(k+"last_length",Math.min(1600,Math.max(0,length)))
          .putLong(k+"last_at",System.currentTimeMillis());
        if(p.getLong("trace_v18_first_at",0)==0)ed.putLong("trace_v18_first_at",System.currentTimeMillis());
        ed.apply();
    }
    public static synchronized void queueResult(Context ctx,String source,boolean accepted){
        String group=NavTracePolicy.fromCueSource(source);
        SharedPreferences p=ctx.getSharedPreferences(BridgeLog.STORE,0);
        SharedPreferences.Editor ed=p.edit();
        String k="trace_v18_"+group+"_";
        inc(p,ed,k+"queue_attempts");
        if(accepted)inc(p,ed,k+"queue_accepted");
        ed.putLong(k+"queue_last_at",System.currentTimeMillis()).apply();
    }
    private static int val(SharedPreferences p,String group,String channel,String suffix){return p.getInt(prefix(group,channel)+suffix,0);}
    private static int total(SharedPreferences p,String group,String suffix){
        int sum=0;for(String c:CHANNELS)sum+=val(p,group,c,suffix);return sum;
    }
    private static String shortLabel(String group){return NavTracePolicy.OEM.equals(group)?"순정 TMAP":NavTracePolicy.GENERAL.equals(group)?"일반 TMAP":"기타 선택 내비";}
    public static String oneLine(SharedPreferences p,String group){
        return shortLabel(group)+" · 입력 "+total(p,group,"events")+
            " / 문자 "+total(p,group,"text")+
            " / 방향 "+total(p,group,"direction")+
            " / 거리 "+total(p,group,"distance")+
            " / 유효 안내 "+total(p,group,"parsed")+
            " / BLE 큐 "+p.getInt("trace_v18_"+group+"_queue_accepted",0)+" (누적)";
    }
    public static String report(SharedPreferences p){
        StringBuilder out=new StringBuilder();
        out.append("=== 순정/일반 TMAP 독립 입력 진단 (v0.10.8 계수, 누적) ===\n")
            .append("주의: 이벤트/문자/방향 단어/거리 단어 감지는 실제 TBT 수신 성공이 아닙니다.\n")
            .append("순정과 일반 TMAP은 각각 선택·실행한 경우의 기록이며 동시에 수신한 것을 뜻하지 않습니다.\n")
            .append("TBT 없음, 개인정보 저장 없음, BLE 큐 접수도 HUD 화면 표시 확인 아님.\n")
            .append("최초 진단 계수 시각(ms): ").append(p.getLong("trace_v18_first_at",0)).append('\n');
        for(String group:GROUPS){
            int inputs=total(p,group,"events"),text=total(p,group,"text"),dir=total(p,group,"direction");
            int dist=total(p,group,"distance"),parsed=total(p,group,"parsed");
            int queued=p.getInt("trace_v18_"+group+"_queue_accepted",0);
            out.append('\n').append(shortLabel(group)).append(" [").append(group).append("]\n")
                .append("INPUT_DIAGNOSIS=").append(NavTracePolicy.diagnosis(inputs,text,dir,dist,parsed,queued)).append('\n')
                .append(oneLine(p,group)).append('\n')
                .append("BLE 큐 시도=").append(p.getInt("trace_v18_"+group+"_queue_attempts",0)).append('\n');
            for(String channel:CHANNELS){
                String k=prefix(group,channel);
                out.append("  ").append(channel)
                    .append(" events=").append(p.getInt(k+"events",0))
                    .append(" text=").append(p.getInt(k+"text",0))
                    .append(" dir=").append(p.getInt(k+"direction",0))
                    .append(" dist=").append(p.getInt(k+"distance",0))
                    .append(" both=").append(p.getInt(k+"both",0))
                    .append(" valid=").append(p.getInt(k+"parsed",0))
                    .append(" lastStage=").append(p.getString(k+"stage","NOT_OBSERVED"))
                    .append(" lastAtMs=").append(p.getLong(k+"last_at",0))
                    .append(" lastChars=").append(p.getInt(k+"last_length",0)).append('\n');
            }
        }
        out.append("BLE 전체 안내 요청/완료/콜백은 기존 HUD 카운터를 참조. 개별 내비에 GATT 성공을 귀속하지 않음.\n");
        return out.toString();
    }
}
