package com.dolphin.oemhud;

/** Pure Java, privacy-preserving identity and evidence labels; NOT a source authenticator. */
public final class NavTracePolicy {
    public static final String OEM="oem", GENERAL="general", OTHER="other";
    private NavTracePolicy() {}
    public static String group(String pkg) {
        if("com.tmap.auto.byd".equals(pkg))return OEM;
        if("com.skt.tmap.ku".equals(pkg))return GENERAL;
        return OTHER;
    }
    public static String fromCueSource(String source) {
        if(source==null)return OTHER;
        if(source.endsWith(":com.tmap.auto.byd"))return OEM;
        if(source.endsWith(":com.skt.tmap.ku"))return GENERAL;
        return OTHER;
    }
    public static String stage(boolean text, boolean direction, boolean distance, boolean parsed){
        if(parsed)return "VALID_CUE";
        if(!text)return "NO_VISIBLE_TEXT";
        if(direction && distance)return "BOTH_TOKENS_UNPAIRED";
        if(direction)return "DIRECTION_ONLY";
        if(distance)return "DISTANCE_ONLY";
        return "NO_TBT_TOKENS";
    }
    public static String diagnosis(int inputs,int text,int directions,int distances,int parsed,int queued){
        if(inputs<=0)return "NO_INPUT_EVENTS";
        if(text<=0)return "INPUT_NO_TEXT";
        if(parsed<=0 && directions<=0)return distances>0?"DISTANCE_WITHOUT_DIRECTION":"DIRECTION_NOT_EXPOSED";
        if(parsed<=0)return "UNPAIRED_OR_REJECTED";
        return queued>0?"QUEUED_NOT_HUD_CONFIRMED":"PARSED_NOT_QUEUED";
    }
}
