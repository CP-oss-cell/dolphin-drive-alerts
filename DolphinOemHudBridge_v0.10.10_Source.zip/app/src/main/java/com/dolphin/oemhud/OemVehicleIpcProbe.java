package com.dolphin.oemhud;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;

/** HUD-RE-011/012: runtime MANIFEST inspection of already-installed OEM components.
 * No ContentProvider.query(), Binder, vehicle-service calls, signal I/O, or
 * permission workarounds. Exported does NOT imply TBT access. */
public final class OemVehicleIpcProbe {
    private static final String DICAR="com.byd.car.server";
    private static final String CLUSTER="com.skt.tmap.auto.activity.ClusterActivity";
    private OemVehicleIpcProbe(){}
    public static void inspect(Context ctx){
        SharedPreferences p=ctx.getSharedPreferences(BridgeLog.STORE,0);
        PackageManager pm=ctx.getPackageManager();
        String providerStatus="DICAR_NOT_CHECKED",clusterStatus="CLUSTER_NOT_CHECKED";
        try{
            PackageInfo car=pm.getPackageInfo(DICAR,PackageManager.GET_PROVIDERS);
            int known=0,exported=0,permissionDeclared=0;
            if(car.providers!=null)for(ProviderInfo i:car.providers){
                if(i==null||i.name==null)continue;
                if(i.name.equals("com.byd.car.server.provider.CarServiceProvider")||
                   i.name.equals("com.gpack.service.provider.VehicleServiceProvider")){
                    known++;
                    if(i.exported)exported++;
                    if(i.readPermission!=null||i.writePermission!=null)permissionDeclared++;
                }
            }
            providerStatus="MANIFEST_ONLY "+known+"/2 providers · exported="+exported+
                " · declaredPermission="+permissionDeclared+" · TBT capability UNKNOWN";
        }catch(PackageManager.NameNotFoundException e){providerStatus="DICAR_NOT_INSTALLED_OR_NOT_VISIBLE";}
        catch(SecurityException e){providerStatus="DICAR_METADATA_ACCESS_DENIED";}
        catch(Exception e){providerStatus="DICAR_METADATA_ERROR_"+e.getClass().getSimpleName();}
        try{
            ActivityInfo a=pm.getActivityInfo(new ComponentName(OemTmapStateSignal.PACKAGE,CLUSTER),0);
            clusterStatus="CLUSTER_ACTIVITY_"+(a.exported?"EXPORTED":"NOT_EXPORTED")+
                " · rendered map path, NOT TBT read API";
        }catch(PackageManager.NameNotFoundException e){clusterStatus="CLUSTER_ACTIVITY_NOT_FOUND";}
        catch(SecurityException e){clusterStatus="CLUSTER_METADATA_DENIED";}
        catch(Exception e){clusterStatus="CLUSTER_METADATA_ERROR_"+e.getClass().getSimpleName();}
        p.edit().putString("oem_vehicle_provider_probe",providerStatus)
            .putString("oem_cluster_activity_probe",clusterStatus)
            .putLong("oem_vehicle_manifest_checked_at",System.currentTimeMillis()).apply();
        BridgeLog.event(ctx,"BYD OEM IPC 선언 조회 · "+providerStatus+" · "+clusterStatus);
    }
}
