package com.dolphin.oemhud;

import java.util.Locale;

/** Conservative app identity filter for notification / accessibility TBT sources.
 * No reading of arbitrary third-party messages or apps. */
public final class NavPackageMatcher {
    private NavPackageMatcher() {}
    public static boolean likely(String packageName, String label) {
        if (packageName==null || packageName.trim().isEmpty()) return false;
        String p=packageName.toLowerCase(Locale.ROOT);
        if (p.equals("com.tmap.auto.byd")) return true;
        if (p.equals("com.dolphin.oemhud") || p.contains("settings") || p.contains("systemui")) return false;
        if (p.contains("tmap") || p.contains("autonavi") || p.contains("amap") ||
            p.contains("navigation") || p.contains("navi") || p.contains("gaode") ||
            p.equals("com.google.android.apps.maps") || p.equals("com.nhn.android.nmap")) return true;
        String l=label==null?"":label.toLowerCase(Locale.ROOT);
        return l.contains("내비") || l.contains("네비") || l.contains("길안내") ||
               l.contains("navigation") || l.contains("地图") || l.contains("导航") ||
               l.equals("지도") || l.equals("maps") || l.equals("map") ||
               l.contains("tmap") || l.contains("티맵") || l.contains("고덕지도");
    }
}
