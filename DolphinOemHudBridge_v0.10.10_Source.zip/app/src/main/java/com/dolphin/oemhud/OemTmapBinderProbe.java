package com.dolphin.oemhud;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Passive OEM TMAP service boundary check from HUD-RE-004/005.
 * It ONLY reads package service metadata, binds to exported NaviService, and
 * asks the Binder for its interface descriptor. It never invokes custom
 * INaviService transactions, navigation actions, CAN, or cluster writes.
 * A successful bind is NOT evidence that OEM turn-by-turn data is accessible.
 */
public final class OemTmapBinderProbe {
    static final String PACKAGE="com.tmap.auto.byd";
    static final String SERVICE="com.tmap.auto.byd.NaviService";
    static final String DESCRIPTOR="com.byd.naviserviceapi.INaviService";
    private OemTmapBinderProbe() {}

    public static void start(Context context) {
        Context app=context.getApplicationContext();
        SharedPreferences prefs=app.getSharedPreferences(BridgeLog.STORE,0);
        ComponentName component=new ComponentName(PACKAGE,SERVICE);
        try {
            ServiceInfo info=app.getPackageManager().getServiceInfo(component,0);
            String permission=info.permission==null?"없음":info.permission;
            prefs.edit().putString("oem_binder_exported",String.valueOf(info.exported))
                .putString("oem_binder_permission",permission).apply();
            if(!info.exported){state(app,"BLOCKED_NOT_EXPORTED","외부 공개 서비스가 아님");return;}
        }catch(PackageManager.NameNotFoundException missing){
            state(app,"SERVICE_NOT_FOUND","순정 TMAP 서비스가 설치된 패키지에서 확인되지 않음");return;
        }catch(Exception e){state(app,"PACKAGE_INSPECTION_FAILED",e.getClass().getSimpleName());return;}

        final Handler main=new Handler(Looper.getMainLooper());
        final AtomicBoolean finished=new AtomicBoolean(false);
        final ServiceConnection conn=new ServiceConnection(){
            @Override public void onServiceConnected(ComponentName name,IBinder binder){
                if(!finished.compareAndSet(false,true))return;
                String descriptor="";
                try{descriptor=binder==null?"NULL_BINDER":binder.getInterfaceDescriptor();}
                catch(Exception e){descriptor="DESCRIPTOR_ERROR_"+e.getClass().getSimpleName();}
                boolean matches=DESCRIPTOR.equals(descriptor);
                state(app,matches?"AIDL_BOUND_NO_TBT":"BOUND_DESCRIPTOR_MISMATCH",
                    "Binder="+descriptor+" / 순정 TBT 조회는 아직 미확인");
                try{app.unbindService(this);}catch(Exception ignored){}
            }
            @Override public void onServiceDisconnected(ComponentName name){
                // We never issue an INaviService command, even after reconnection.
                if(finished.compareAndSet(false,true))state(app,"SERVICE_DISCONNECTED","서비스 연결 해제");
            }
        };
        state(app,"BIND_REQUEST","순정 TMAP Binder 읽기 전용 접속 확인 중");
        boolean bound;
        try {
            bound=app.bindService(new Intent().setComponent(component),conn,Context.BIND_AUTO_CREATE);
        }catch(SecurityException denied){
            finished.set(true);state(app,"BIND_DENIED","순정 서비스 권한 제한: SecurityException");return;
        }catch(Exception e){
            finished.set(true);state(app,"BIND_ERROR",e.getClass().getSimpleName());return;
        }
        if(!bound){finished.set(true);state(app,"BIND_FALSE","서비스 바인딩 거부 또는 사용 불가");return;}
        main.postDelayed(()->{
            if(finished.compareAndSet(false,true)){
                try{app.unbindService(conn);}catch(Exception ignored){}
                state(app,"BIND_TIMEOUT","6초 이내 Binder 연결 응답 없음");
            }
        },6000);
    }
    private static void state(Context app,String code,String message){
        SharedPreferences p=app.getSharedPreferences(BridgeLog.STORE,0);
        p.edit().putString("oem_binder_state",code)
            .putString("oem_binder_detail",message)
            .putLong("oem_binder_checked_at",System.currentTimeMillis()).apply();
        BridgeLog.event(app,"순정 TMAP IPC 진단 "+code+" · "+message);
    }
}
