package com.dolphin.oemhud;

/** Pure-Java boundaries for parked-only, user-confirmed window owner metadata collection.
 * No screen text, navigation routes, screenshots, GPS or vehicle messages are handled here.
 */
public final class WindowProbePolicy {
    public static final long WINDOW_MS = 8000L;
    public static final int MAX_SAMPLES = 14;
    public static final int MAX_WINDOWS_PER_SAMPLE = 12;
    private WindowProbePolicy(){}

    public static boolean canSample(long elapsed, long until, int count, long last){
        return until > 0 && elapsed <= until && count < MAX_SAMPLES &&
            (count == 0 || elapsed - last >= 250L);
    }
    public static String safePackage(CharSequence input){
        if(input==null)return "UNKNOWN";
        String pkg=input.toString().replaceAll("[^A-Za-z0-9._-]", "?");
        return pkg.length()>90?pkg.substring(0,90):pkg;
    }
    public static long pollInterval(int emptyStreak){
        return emptyStreak>=4?6000L:1800L;
    }
}
