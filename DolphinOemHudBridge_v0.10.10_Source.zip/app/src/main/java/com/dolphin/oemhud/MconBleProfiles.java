package com.dolphin.oemhud;

import java.util.Locale;
import java.util.UUID;

/**
 * Transport model identifiers verified against the user's MCon K 2.1.5.004 APK.
 * These are BLE transport profiles, NOT evidence that the external device accepted
 * any given navigation frame. Unrecognised device names remain unclassified.
 */
public final class MconBleProfiles {
    private MconBleProfiles() {}
    public static final UUID STANDARD_TX=UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb");
    public static final UUID STANDARD_RX=UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb");
    public static final UUID TPLAY_SERVICE=UUID.fromString("0000ffea-0000-1000-8000-00805f9b34fb");
    public static final UUID TMAP_SERVICE=UUID.fromString("0000fee9-0000-1000-8000-00805f9b34fb");
    public static final UUID MAX_SERVICE=UUID.fromString("0000fff0-0000-1000-8000-f7d72c3c02a3");
    public static final UUID MAX_TX=UUID.fromString("0000fff2-0000-1000-8000-f7d72c3c02a3");
    public static final UUID MAX_RX=UUID.fromString("0000fff1-0000-1000-8000-f7d72c3c02a3");

    public static final class Profile {
        public final String label;
        public final UUID service;
        public final UUID tx;
        public final UUID rx;
        Profile(String label,UUID service,UUID tx,UUID rx) {
            this.label=label;this.service=service;this.tx=tx;this.rx=rx;
        }
    }
    public static Profile fromDeviceName(String name) {
        if (name==null) return null;
        String n=name.toUpperCase(Locale.ROOT).replaceAll("[\\s_-]+"," ").trim();
        if (n.contains("HUD Q MAX")) return new Profile("HUD Q MAX",MAX_SERVICE,MAX_TX,MAX_RX);
        if (n.contains("TMAP API HUD")) return new Profile("TMAP API HUD",TMAP_SERVICE,STANDARD_TX,STANDARD_RX);
        if (n.contains("TPLAY HUD Q") || n.contains("VOICE HUD") || n.contains("GENIUS HUD Q")
                || n.contains("HUD-I") || n.contains("RUBIE HUD") || n.contains("MANDO HUD"))
            return new Profile("TPLAY/VOICE HUD",TPLAY_SERVICE,STANDARD_TX,STANDARD_RX);
        return null;
    }
    public static Profile fromService(UUID service) {
        if (MAX_SERVICE.equals(service))return new Profile("MCon MAX",MAX_SERVICE,MAX_TX,MAX_RX);
        if (TPLAY_SERVICE.equals(service))return new Profile("MCon FFEA",TPLAY_SERVICE,STANDARD_TX,STANDARD_RX);
        if (TMAP_SERVICE.equals(service))return new Profile("MCon FEE9",TMAP_SERVICE,STANDARD_TX,STANDARD_RX);
        return null;
    }
}
