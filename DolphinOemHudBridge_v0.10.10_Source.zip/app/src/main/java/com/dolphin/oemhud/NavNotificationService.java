package com.dolphin.oemhud;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.*;

/** Reads only notifications belonging to the selected/recognized navigator. */
public final class NavNotificationService extends NotificationListenerService {
    @Override public void onListenerConnected(){
        BridgeLog.event(this,"순정 내비 알림 수신기 연결");
        try{
            StatusBarNotification[] existing=getActiveNotifications();
            if(existing!=null)for(StatusBarNotification sbn:existing)readNavigationNotification(sbn);
        }catch(Exception e){BridgeLog.event(this,"기존 내비 알림 조회 불가: "+e.getClass().getSimpleName());}
    }
    @Override public void onNotificationPosted(StatusBarNotification sbn){readNavigationNotification(sbn);}
    private void readNavigationNotification(StatusBarNotification sbn){
        if(sbn==null || !getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
        try{
            String pkg=sbn.getPackageName();
            if(!BridgeLog.isNavPackage(this,pkg))return;
            android.content.SharedPreferences prefs=getSharedPreferences(BridgeLog.STORE,0);
            prefs.edit().putInt("nav_notification_count",prefs.getInt("nav_notification_count",0)+1)
                .putString("last_nav_package",pkg)
                .putString("last_nav_input_source","TMAP 알림")
                .putLong("last_nav_event_at",System.currentTimeMillis()).apply();
            Notification n=sbn.getNotification();if(n==null||n.extras==null)return;
            Bundle b=n.extras;
            CharSequence title=b.getCharSequence(Notification.EXTRA_TITLE,"");
            CharSequence big=b.getCharSequence(Notification.EXTRA_BIG_TEXT,"");
            if(big==null||big.length()==0)big=b.getCharSequence(Notification.EXTRA_TEXT,"");
            CharSequence subtitle=b.getCharSequence(Notification.EXTRA_SUB_TEXT,"");
            CharSequence compact=b.getCharSequence(Notification.EXTRA_TEXT,"");
            String content=String.valueOf(title)+"\n"+String.valueOf(big==null?"":big)+"\n"+
                String.valueOf(subtitle==null?"":subtitle)+"\n"+String.valueOf(compact==null?"":compact);
            NavCue cue=NavCue.fromText("TMAP 알림:"+pkg,content);
            NavInputTrace.observe(this,pkg,"notification",content.length(),
                NavCue.hasDirectionToken(content),NavCue.hasDistanceToken(content),
                cue!=null&&cue.isUsable());
            if(cue!=null&&cue.isUsable()){
                prefs.edit().putInt("nav_parsed_count",prefs.getInt("nav_parsed_count",0)+1)
                    .putInt("nav_notification_parsed",prefs.getInt("nav_notification_parsed",0)+1)
                    .putLong("nav_last_parsed_at",System.currentTimeMillis()).apply();
                BridgeLog.cue(this,cue);
            }
        }catch(Exception e){BridgeLog.event(this,"알림 추출 오류: "+e.getClass().getSimpleName());}
    }
}
