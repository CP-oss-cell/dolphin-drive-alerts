package com.dolphin.oemhud;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** Pure, testable app-list policy. Package names remain exact; only search is folded. */
public final class NavAppCatalog {
    private NavAppCatalog() {}

    public static final class Entry {
        public final String packageName;
        public final String label;
        public final boolean launchable;
        public final boolean navigationCandidate;
        public final boolean enabled;
        public Entry(String packageName, String label, boolean launchable) {
            this(packageName,label,launchable,true);
        }
        public Entry(String packageName, String label, boolean launchable, boolean enabled) {
            this.enabled = enabled;
            this.packageName = packageName == null ? "" : packageName.trim();
            String title = label == null ? "" : label.trim();
            this.label = title.isEmpty() ? this.packageName : title;
            this.launchable = launchable;
            this.navigationCandidate = NavPackageMatcher.likely(this.packageName, this.label);
        }
    }

    public static List<Entry> visible(List<Entry> installed, String search,
                                      boolean includeSystem, String selectedPackage) {
        if (installed == null) return Collections.emptyList();
        String q = search == null ? "" : search.trim().toLowerCase(Locale.ROOT);
        ArrayList<Entry> out = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        for (Entry e : installed) {
            if (e == null || e.packageName.isEmpty() ||
                e.packageName.equals("com.dolphin.oemhud") || !seen.add(e.packageName)) continue;
            boolean selected = e.packageName.equals(selectedPackage);
            if (!includeSystem && !e.launchable && !e.navigationCandidate && !selected) continue;
            if (!q.isEmpty() && !e.label.toLowerCase(Locale.ROOT).contains(q)
                    && !e.packageName.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(e);
        }
        Collator korean = Collator.getInstance(Locale.KOREAN);
        out.sort((a,b) -> {
            boolean aSelected = a.packageName.equals(selectedPackage);
            boolean bSelected = b.packageName.equals(selectedPackage);
            if (aSelected != bSelected) return aSelected ? -1 : 1;
            if (a.navigationCandidate != b.navigationCandidate)
                return a.navigationCandidate ? -1 : 1;
            int names = korean.compare(a.label,b.label);
            return names != 0 ? names : a.packageName.compareTo(b.packageName);
        });
        return out;
    }
}
