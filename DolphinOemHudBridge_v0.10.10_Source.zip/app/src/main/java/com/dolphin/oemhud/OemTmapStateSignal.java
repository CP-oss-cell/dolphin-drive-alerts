package com.dolphin.oemhud;

/** HUD-RE-006/012: known BYD TMAP *status* broadcasts, NOT turn-by-turn cues.
 * An implicit Android broadcast does not authenticate its sender; never use this
 * data to construct a HUD turn, run an OEM command, or infer real navigation focus. */
public final class OemTmapStateSignal {
    public static final String PACKAGE="com.tmap.auto.byd";
    public static final String NAVIGATION_STATE="byd.intent.action.NAVIGATION_STATE_CHANGED";
    public static final String MAP_ACTIVITY_STATE="byd.intent.action.MAP_ACTIVITY_STATE_CHANGED";
    public final String action;
    public final String reportedState;
    private OemTmapStateSignal(String a,String s){action=a;reportedState=s;}
    public static OemTmapStateSignal read(String action,String reportedPackage,Object state){
        if(!(NAVIGATION_STATE.equals(action)||MAP_ACTIVITY_STATE.equals(action)))return null;
        if(!PACKAGE.equals(reportedPackage)||state==null)return null;
        String s=String.valueOf(state).trim().replace('\r',' ').replace('\n',' ');
        if(s.isEmpty())return null;
        // Real state codes are not reverse-mapped to ON/OFF without OEM evidence.
        if(s.length()>40)s=s.substring(0,40);
        return new OemTmapStateSignal(action,s);
    }
    public boolean isNavigationState(){return NAVIGATION_STATE.equals(action);}
    public String diagnostic(){return (isNavigationState()?"순정 안내 상태 방송":"순정 지도 화면 상태 방송")+" = "+reportedState+" (TBT 방향/거리 아님 · 발신자 미인증)";}
}
