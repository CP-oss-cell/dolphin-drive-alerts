# R17 | Dolphin OEM HUD Bridge v0.10.8: 일반 TMAP TBT 수신 집중 계측

## 실차 근거와 개발 결정
- 이전 실차: TPLAY HUD Q BLE 연결, 수동 우회전 300m 및 자동 밝기 정상. 순정/일반 TMAP의 자동 방향·거리 연동 실패.
- R15: 화면 조회 기록과 접근성 이벤트의 갱신 시각 불일치. v0.10.7에서 조회 감시·복구 시도 구현.
- 이번에는 유효 TBT가 처음 들어오는 **실제 지점**을 찾을 수 있게 일반/순정 TMAP을 분리 계측.
- 유효 TBT의 구조화된 송신 경로 미확정. 실차 자동 전송 성공으로 해석하지 않음.

## v0.10.8 실제 변경 파일
- `NavTracePolicy.java`: 정확한 순정(`com.tmap.auto.byd`), 일반(`com.skt.tmap.ku`), 기타 출처 분리. 화면 글자와 방향·거리 단서가 같아도 VALID_CUE 여부 별도로 판단.
- `NavInputTrace.java`: 각 출처별 access_event, access_tree, access_poll, notification, compat_broadcast 이벤트 및 text/direction/distance/both/parsed 개수·시각 저장. 직접 화면 텍스트, 위치·도로명, URL은 수집하지 않음.
- `NavAccessibilityService.java`/`NavNotificationService.java`: 실제 읽힌 선택 내비 앱 자료에 대해서만 계측. 기존 방향 추측 방지 로직 보존.
- `BridgeService.java`: 유효한 안내의 BLE 전송 **접수 여부**와 앱 출처별 결과 기록. 출처 인증 불가능한 호환 AutoNavi 방송을 진단 전용으로 변경해 실차 HUD로 전송하지 않음. OEM 순정 TMAP 상태 방송은 계속 TBT로 해석하지 않음.
- `MainActivity.java`: 각 내비의 입력·문자·방향·거리·유효 안내·BLE 큐 단계 간단 상태 표시, 원클릭 진단 ZIP에 전체 비교표 포함.
- `tests/`·`tools/`: 출처 및 단계 구분 회귀검사 추가, 기존 실제 서비스/실제 BLE 연결기 모의 테스트를 새로운 안전 정책에 맞게 개선.

## 검증 수준과 제한
- JVM 프로덕션 정책 테스트 18개 PASS; 생산 서비스+BLE 결합 테스트 18개 PASS; BLE 시뮬레이션 64개 PASS.
- 기존 순정/일반 수신부 및 대시보드에 대한 Android API 오프라인 타입 검사 PASS. 사전검사 135/135 PASS.
- 이전 NavCue, MConHudQProtocol, HudConnector, MconBleProfiles, HudBrightnessSchedule, HudAutoBrightness, HudSettingsProtocol 코드는 **변경하지 않음**.
- 로컬 환경에 Gradle/Android SDK가 없어 진짜 `assembleDebug`는 실행하지 못함. GitHub Actions에서 Android SDK 34를 설치해 빌드하도록 설정함.
- 실제 순정 TMAP의 원본 TBT·일반 티맵의 길안내 수신 및 HUD 실물 표시 성공 **모두 미검증**. BLE GATT 완료는 HUD 화면 반영과 다름.
- 전송 파이프라인의 중간 단계만 관측함. BLE GATT 콜백은 현재 per-app 소유 분리가 불가능하므로 전체 값으로 표시함.
- 호환 방송을 인증할 수 없어 그 경로에서 자동 HUD 안내를 보내지 않는 것이 이번 버전의 의도적인 안전 변경.
- 계수는 v0.10.8 설치 이후 누적이며, 두 앱의 수신 경로는 사용자가 앱을 선택/사용한 시점에만 비교 가능.

## 1회 사용자 워크플로
일반 티맵을 평소에 사용 → 안내가 나타난 뒤 메인 상단 `② 자동 진단 ZIP 생성·공유` 클릭 → ZIP 제공.
(순정 TMAP도 평소 사용했다면 순정 기록을 자동으로 별도 분류. 불필요한 우회전 수동 테스트 반복 금지.)
