# v0.9.4 소스 검증 · 2026-11-02

원본: `/mnt/data/Dolphin_OEM_HUD_Bridge_v0.9.3_SOURCE.zip`
실차 기록: `DolphinOemHud_20261102_113942.zip`의 `report.txt`

## 사실 확인
- 진단 첫 줄은 `Dolphin OEM HUD Bridge v0.9`이고, `v0.9.3`이 아닙니다.
- `v0.9.3_SOURCE.zip` 원본에는 앱 목록 선택 버튼과 picker Activity가 실제 소스상 존재합니다.
- 즉 실차에 구버전 APK가 설치되거나 실행된 정황이 가장 강하지만, 구버전이 선택된 정확한 경위까지는 해당 보고서만으로 확정할 수 없습니다.

## 수정
- 첫 화면 상단 메뉴로 내비 앱 목록 버튼 이동, 중복 메뉴는 제거.
- 시스템 앱 포함 전체 목록 기본 노출, 재검색, 비활성 표시.
- 런타임 설치 APK 버전/코드를 UI와 ZIP에 기록.
- 빌드 시 실제 APK 버전 및 등록 Activity 확인.
- versionCode 14, versionName 0.9.4-picker-verified.

## 한계
- 사전 검사/오프라인 Java 컴파일은 Android 정식 APK 빌드를 대체하지 않습니다.
- OEM 앱이 별도 사용자/차량 권한으로 격리돼 있으면 공개 설치 목록만으로 찾을 수 없습니다.
- 기존 설치 버전과 서명이 다른 APK는 자동 업데이트할 수 없습니다.

## 실행한 로컬 검증 결과
- `python3 tools/preflight.py`: 48/48 PASS
- `bash tools/run_dashboard_typecheck.sh`: PASS (Android API 스텁 기반, 실제 APK 컴파일 아님)
- `bash tools/run_all_simulations.sh`: PASS (TBT·BLE·서비스 통합·ADB 오프라인 타입 검사)
- 변경된 카탈로그 단위 테스트: 15개 assertion PASS
- `.github/workflows/build-oem-hud-bridge.yml`: YAML 로드 PASS
- 실제 GitHub Actions `assembleDebug`: 미실행

로컬 테스트 출력 끝부분:

```text
PASS INTEGRATION unverified turn icon fails closed
PASS INTEGRATION user stop blocks OEM broadcasts
PASS INTEGRATION disconnect clears auto-connect MAC
REAL SERVICE + REAL CONNECTOR 7 PASS
SIM1 broadcast received: cueRecords=1; hudSendAttempts=1
SIM2 decoded direction=??? icon=5 meters=300 encoded=194D0105000400012C2F
SIM3 notification path: cueRecords=2; hudSendAttempts=2 hudPackets=2
PASS ADB Kotlin source type/syntax check against OFFLINE Android/Dadb stubs (NOT an Android SDK build)

ALL AVAILABLE LOCAL SIMULATIONS PASS. ANDROID APK ASSEMBLE / REAL CAR / HUD HARDWARE ARE NOT VERIFIED.
```
