# v0.10.0 연구/빌드 검증

- 순정 TMAP·MCon·DiCar DEX 직접 인용 근거: `research/HUD-RE-005/evidence`.
- 사전 검사, JVM 파서, 서비스 시뮬레이션, BLE 시뮬레이션, 통합 시뮬레이션, 대시보드 및 접근성 소스 타입 검사, Binder 안전성 시뮬레이션, Kotlin 소스 검사, 패키징 검사: 아래 빌드 검증 로그 참조.
- `OemTmapBinderProbe`: `getInterfaceDescriptor`만 호출하며 임의의 `IBinder.transact`를 수행하지 않음.
- 현재 환경에서 Android SDK 및 Gradle 실제 APK 빌드 미실행. GitHub Actions 결과에 따라 실제 성공 여부가 결정됨.
- OEM TBT 데이터 수신 및 실물 HUD 출력: 아직 검증되지 않음.

## 이번 실행의 실제 로컬 검사 기록

- `python3 tools/preflight.py` — **73/73 PASS**
- `bash tools/run_jvm_tests.sh` — TBT 파서/프레임·앱 패키지 카탈로그 검사 통과
- `bash tools/run_service_simulation.sh` — 방송 입력 → 큐 접수 모의 통과
- `bash tools/run_ble_simulation.sh` — **53 PASS** (모델별 GATT 프로필 포함)
- `bash tools/run_integrated_simulation.sh` — **7 PASS**
- `bash tools/run_dashboard_typecheck.sh` — 오프라인 UI Java 타입 검사 PASS
- `bash tools/run_nav_receiver_typecheck.sh` — 접근성·알림 Java 타입 검사 PASS
- `bash tools/run_oem_binder_probe_typecheck.sh` — **8 PASS** (정상/권한거부/비공개/식별자 불일치/무명령)
- `bash tools/run_adb_kotlin_syntax.sh` — 오프라인 Kotlin 타입 검사 PASS
- `python3 tools/check_packaging_ci_fix.py` — PASS
- `python3 tools/validate_re005_evidence.py` — PASS

검사는 SDK 실물 APK 빌드 또는 차량 실물 성공을 대체하지 않는다.
