# v0.9.6 CI 복구 검증

대상 오류: GitHub Actions (2026-11-02 06:04 UTC), `FAIL PREFLIGHT Navigation receiver type-check in CI` / 사전검사 56/57. APK 작업은 실행되지 않았음.

## 수정
- CI가 SOURCE ZIP의 `.github/workflows/build-oem-hud-bridge.yml`을 외부 구버전 YML로 덮어쓰지 않음.
- GitHub 저장소 YML과 SOURCE ZIP 내부 YML의 동일성 검증 후 빌드 시작.
- `preflight.py`는 타입 검사 스크립트와 실제 CI 실행 단계를 모두 검사하고, CI 단계는 실제 `javac` 검사를 실행함.
- v0.9.6 / versionCode 16. v0.9.5 순정 TMAP 수신 기능과 HUD BLE 통신 코드 불변.

## 확인한 결과 (로컬)
- `python3 tools/preflight.py`: **58/58 PASS**.
- `bash tools/run_nav_receiver_typecheck.sh`: PASS (오프라인 stub Java 타입 검사).
- `bash tools/run_dashboard_typecheck.sh`: PASS.
- `bash tools/run_all_simulations.sh`: PASS (TBT parser 47 / BLE 45 / service integration 7 / 기타 검사).
- `python3 tools/check_packaging_ci_fix.py`: PASS.
- 외부 YML과 ZIP 내부 YML 바이트 동일.

## 검증하지 못한 결과
GitHub Actions 실제 Android SDK `gradle :app:assembleDebug` 실행, 생성 APK 설치, 실차 순정 TMAP 안내 데이터 수신 및 HUD 표시.
오프라인 테스트 PASS는 위 세 가지의 성공을 보증하지 않음.
