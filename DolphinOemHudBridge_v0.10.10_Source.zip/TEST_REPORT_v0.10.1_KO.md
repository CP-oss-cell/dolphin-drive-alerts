# HUD Bridge v0.10.1 검증표

실행환경: Linux/JDK, offline Android API stubs; 실제 Android SDK 및 차량 HUD 없음.

| 검사 | 결과 |
|---|---|
| `python3 tools/preflight.py` | 77/77 PASS |
| `bash tools/run_jvm_tests.sh` | NavCue 56 PASS / HUD 설정 12 / 패키지 8 / 앱 카탈로그 15 asserts |
| `bash tools/run_ble_simulation.sh` | BLE 53 PASS |
| `bash tools/run_integrated_simulation.sh` | 서비스+BLE 7 PASS |
| `bash tools/run_service_simulation.sh` | 3단계 시뮬레이션 통과 |
| `bash tools/run_nav_receiver_typecheck.sh` | PASS |
| `bash tools/run_dashboard_typecheck.sh` | PASS |
| `bash tools/run_oem_binder_probe_typecheck.sh` | 8개 PASS |
| `bash tools/run_auto_brightness_typecheck.sh` | 조도 정책 5개 + 실제 Java 파일 스텁 컴파일 PASS |
| `python3 tools/validate_re005_evidence.py` | PASS |
| `python3 tools/check_packaging_ci_fix.py` | PASS |
| `python3 tools/verify_release_bundle.py --version v0.10.1 --code 21` | PASS |
| Android SDK 실제 Gradle `assembleDebug` | **NOT RUN** |
| 실차 순정 TMAP → 실물 HUD 자동 안내 | **NOT VERIFIED / 계속 미완료** |
| 실차 자동 밝기 | **NOT VERIFIED** |

모의 검사들은 사용자의 실차 결과를 대체하지 않으며 실제 TBT 경로가 열린 것으로 간주하지 않음.
