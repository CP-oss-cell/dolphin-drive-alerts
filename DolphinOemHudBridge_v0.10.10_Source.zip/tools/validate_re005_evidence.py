#!/usr/bin/env python3
from pathlib import Path
import json,csv
root=Path(__file__).resolve().parent.parent/'research/HUD-RE-005/evidence'
data=json.loads((root/'SOURCE_SCAN.json').read_text())
files={r['source']:r for r in data}
for x in ('tm2602_classes.dex','tm2606_classes.dex','tm2602_classes2.dex','tm2606_classes2.dex','dicar2602_classes.dex','mcon_classes.dex'):
 assert x in files and len(files[x]['sha256'])==64,x
for x in ('TBT_FIELD_XREFS.csv','TBT_CONTEXT_IPC_CANDIDATES.csv','TBT_OWNER_METHODS.csv'):
 with (root/x).open(encoding='utf-8-sig') as f:
  rows=list(csv.DictReader(f));assert rows,x
assert files['tm2602_classes.dex']['tbt_related_method_count']>=200
assert files['tm2606_classes.dex']['tbt_related_method_count']>=200
print('PASS HUD-RE-005 recorded evidence integrity: two OEM TMAP versions and MCon verified')
print('NOTE: static direct references are not an OEM IPC access proof')
