#!/usr/bin/env python3
"""Fail fast if a fake Android ProviderInfo grows invented fields again."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent.parent
prod=(ROOT/'app/src/main/java/com/dolphin/oemhud/OemVehicleIpcProbe.java').read_text()
stub=(ROOT/'tests/oem_binder_stubs/android/content/pm/ProviderInfo.java').read_text()
workflow=(ROOT/'.github/workflows/build-oem-hud-bridge.yml').read_text()
assert not re.search(r'\bi\.permission\b',prod), 'ProviderInfo.permission is not in Android SDK'
assert 'readPermission' in prod and 'writePermission' in prod
assert not re.search(r'\bpermission\b',stub), 'Fake ProviderInfo contains invented permission field'
assert 'run_android_sdk_providerinfo_check.sh' in workflow, 'Real Android API check not configured in workflow'
print('PASS ProviderInfo API offline static guard; actual android.jar javac gate configured')
