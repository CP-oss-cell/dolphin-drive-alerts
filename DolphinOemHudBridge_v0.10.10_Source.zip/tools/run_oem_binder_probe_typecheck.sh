#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
find tests/oem_binder_stubs -name '*.java' -print > "$tmp/files.txt"
echo app/src/main/java/com/dolphin/oemhud/OemTmapBinderProbe.java >> "$tmp/files.txt"
echo app/src/main/java/com/dolphin/oemhud/OemVehicleIpcProbe.java >> "$tmp/files.txt"
javac -encoding UTF-8 -d "$tmp/classes" @"$tmp/files.txt"
java -cp "$tmp/classes" com.dolphin.oemhud.OemBinderRuntimeTest
java -cp "$tmp/classes" com.dolphin.oemhud.VehicleProbeRuntimeTest
