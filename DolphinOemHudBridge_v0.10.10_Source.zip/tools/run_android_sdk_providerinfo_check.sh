#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
ANDROID_JAR="${SDK_ROOT}/platforms/android-34/android.jar"
if [[ ! -f "$ANDROID_JAR" ]]; then
  echo "FAIL: Actual Android SDK 34 android.jar not installed at $ANDROID_JAR" >&2
  exit 1
fi
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac -source 17 -target 17 -encoding UTF-8 -cp "$ANDROID_JAR" -d "$TEMP" \
  tests/real_sdk_stubs/com/dolphin/oemhud/BridgeLog.java \
  tests/real_sdk_stubs/com/dolphin/oemhud/OemTmapStateSignal.java \
  app/src/main/java/com/dolphin/oemhud/OemVehicleIpcProbe.java
echo "PASS actual Android SDK 34 ProviderInfo Java compile (not a fake android.content.pm.ProviderInfo)"
