#!/usr/bin/env python3
"""Source/package preflight, not a replacement for Android assembleDebug."""
from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
checks=[]
def check(name,condition):
    checks.append((name,bool(condition)))
    print(('PASS' if condition else 'FAIL')+' PREFLIGHT '+name)
manifest=root/'app/src/main/AndroidManifest.xml'
xml=ET.parse(manifest).getroot()
ns='{http://schemas.android.com/apk/res/android}'
pkg='com.dolphin.oemhud'
base=root/'app/src/main/java/com/dolphin/oemhud'
code=lambda n:(base/n).read_text(encoding='utf-8')
check('Manifest XML parse',xml.tag=='manifest')
permissions={x.attrib.get(ns+'name') for x in xml.findall('uses-permission')}
for permission in ['android.permission.INTERNET','android.permission.FOREGROUND_SERVICE','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.BLUETOOTH','android.permission.BLUETOOTH_ADMIN','android.permission.ACCESS_FINE_LOCATION','android.permission.WRITE_SECURE_SETTINGS']:
    check('Manifest permission '+permission,permission in permissions)
for tag,klass in [('activity','.MainActivity'),('service','.BridgeService'),('service','.NavAccessibilityService'),('service','.NavNotificationService'),('receiver','.BootReceiver')]:
    present=any(x.attrib.get(ns+'name')==klass for x in xml.findall('.//'+tag))
    check('Manifest component '+klass,present)
check('Android minSDK 29',"minSdk 29" in (root/'app/build.gradle').read_text())
check('Android targetSDK 29',"targetSdk 29" in (root/'app/build.gradle').read_text())
check('App version 0.10.10',"versionCode 30" in (root/'app/build.gradle').read_text() and "versionName '0.10.10-screen-capture-stage-diagnostic'" in (root/'app/build.gradle').read_text())
check('Legacy AutoNavi compatibility isolated from OEM','AUTONAVI_STANDARD_BROADCAST_SEND' in code('BridgeService.java') and 'autonavi_ignored_for_oem' in code('BridgeService.java'))
check('TBT accepted only while enabled','getBoolean("enabled",false)' in code('BridgeService.java'))
check('Off state blocks TBT history','getBoolean("enabled",false)' in code('BridgeLog.java'))
check('MCon known packet prefix','0x19' in code('MconHudQProtocol.java') and '0x4d' in code('MconHudQProtocol.java'))
check('BLE FFF2 characteristic','0000fff2-0000-1000-8000-00805f9b34fb' in code('HudConnector.java'))
check('Monotonic BLE TTL','android.os.SystemClock.elapsedRealtime()' in code('HudConnector.java'))
check('CCCD serialization gate','descriptorPending' in code('HudConnector.java') and 'FFF1 알림 설정 응답 시간 초과' in code('HudConnector.java'))
check('Old GATT discarded on ACK timeout','GATT ACK 없음 → 새 연결에서 재전송' in code('HudConnector.java'))
check('ADB CAS gate','compareAndSet(false,true)' in code('adb/HudAdbPermissions.kt'))
check('ADB connection keeps persistent RSA files','adbkey.pub' in code('adb/NativeAdbClient.kt'))
check('No root request in runtime','su -c' not in '\n'.join(p.read_text(errors='ignore') for p in base.rglob('*') if p.is_file()))
check('CI workflow exists',(root/'.github/workflows/build-oem-hud-bridge.yml').is_file())
check('HUD setting validated protocol', 'isSettingsFrame' in code('HudSettingsProtocol.java'))
check('Camera buzzer / brightness controls', 'ACTION_BUZZER' in code('MainActivity.java') and 'ACTION_BRIGHTNESS' in code('MainActivity.java'))

# v0.9 dashboard contract: one owner for each feature, no legacy duplicate action menus.
ui=code('MainActivity.java')
check('Dashboard single owner for buzzer + brightness',ui.count('경보음·밝기 함께 저장 및 전송')==1)
check('Dashboard ADB single setup action',ui.count('ADB 연결·권한 적용')>=1 and 'HudAdbPermissions.connect' in ui and 'HudAdbPermissions.apply(this,true' in ui)
check('Dashboard operational start/stop single toggle','toggleRunning()' in ui and '운행 연동' in ui)
check('Dashboard advanced diagnostics collapsed by default','advancedContent.setVisibility(View.GONE)' in ui)
check('Navigation package fallback', 'NavPackageMatcher.likely' in code('BridgeLog.java'))
check('BLE duplicate connection suppression','desired.getAddress().equalsIgnoreCase' in code('HudConnector.java'))
check('Accessibility diagnostics','nav_accessibility_count' in code('NavAccessibilityService.java'))
check('Picker registered not exported',any(x.attrib.get(ns+'name')=='.NavAppPickerActivity' and x.attrib.get(ns+'exported')=='false' for x in xml.findall('.//activity')))
check('Picker clearly visible once at top',ui.count('① 설치된 내비 앱 목록 열기')>=1 and 'button(hero' in ui and 'new Intent(this,NavAppPickerActivity.class)' in ui and 'button(operation,"설치된' not in ui)
check('No duplicate manual package edit','packageInput' not in ui and '내비 앱 지정 저장' not in ui)
check('App picker stores exact existing preference key','putString("nav_package",packageName)' in code('NavAppPickerActivity.java'))
check('App picker explicitly supports automatic detection','자동 감지 사용 (앱 지정 해제)' in code('NavAppPickerActivity.java'))
check('Picker defaults to all apps including OEM','includeSystem.setChecked(true)' in code('NavAppPickerActivity.java') and 'getInstalledApplications(0)' in code('NavAppPickerActivity.java'))
check('App picker shows icons and labels','getApplicationIcon' in code('NavAppPickerActivity.java') and 'getApplicationLabel' in code('NavAppPickerActivity.java'))
check('App search and dedup support','NavAppCatalog.visible' in code('NavAppPickerActivity.java') and 'HashSet<String> seen' in code('NavAppCatalog.java'))
check('Dashboard v0.9 branding','순정 내비 HUD 대시보드' in ui)
check('Runtime APK version shown and saved','installedVersion()' in ui and '실행 APK 버전' in ui and 'String report="Dolphin OEM HUD Bridge "+installedVersion()' in ui)
check('Version code in build and picker diagnostic', 'versionCode 30' in (root/'app/build.gradle').read_text() and '내비 앱 목록 화면 열기' in ui)
check('OEM TMAP manifest-confirmed package recognized', 'com.tmap.auto.byd' in code('NavPackageMatcher.java'))
check('Accessibility reads only navigator labelled nodes', 'pkg.contentEquals(owner)' in code('NavAccessibilityService.java'))
check('Accessibility event-independent polling', 'periodicGuideScan' in code('NavAccessibilityService.java'))
check('Accessibility multiple window fallback', 'getWindows()' in code('NavAccessibilityService.java'))
nav_checker=root/'tools/run_nav_receiver_typecheck.sh'
nav_checker_content=nav_checker.read_text(encoding='utf-8') if nav_checker.exists() else ''
check('Navigation receiver type-check implementation exists', nav_checker.is_file() and 'javac -encoding UTF-8' in nav_checker_content and 'NavAccessibilityService.java' in nav_checker_content and 'NavNotificationService.java' in nav_checker_content and 'BridgeLog.java' in nav_checker_content)
check('Navigation receiver type-check step in bundled CI', 'bash tools/run_nav_receiver_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8'))
check('OEM Binder probe is metadata and descriptor only',
    'getInterfaceDescriptor()' in code('OemTmapBinderProbe.java')
    and 'INaviService' in code('OemTmapBinderProbe.java')
    and 'transact(' not in code('OemTmapBinderProbe.java')
    and 'bindService(' in code('OemTmapBinderProbe.java'))
check('OEM Binder probe starts in dashboard', 'OemTmapBinderProbe.start(this)' in ui)
check('OEM service probe failure and success explicitly separated',
    'BIND_DENIED' in code('OemTmapBinderProbe.java') and 'AIDL_BOUND_NO_TBT' in code('OemTmapBinderProbe.java'))
check('OEM Binder diagnosis in exported report', 'oem_binder_state' in ui and 'oem_binder_permission' in ui)
check('MCon model-aware transport retained', 'MconBleProfiles.fromService' in code('HudConnector.java'))
check('HUD-RE-005 verification in CI', 'bash tools/run_oem_binder_probe_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text())
check('No hidden TMAP Binder calls', 'transact(' not in '\n'.join(code(n) for n in ('BridgeService.java','NavAccessibilityService.java')))
check('Accessibility windows requested', 'flagRetrieveInteractiveWindows' in (root/'app/src/main/res/xml/nav_accessibility.xml').read_text())
check('Missing foreground bridge restarted on cue', 'pending_direction' in code('BridgeLog.java') and 'deliverPending()' in code('BridgeService.java'))
check('TBT stages separately counted', 'nav_parsed_count' in ui and 'nav_tbt_hud_attempts' in ui)
# v0.9.7: release metadata is authoritative; raw YML bytes must never gate the build.
check('Dark theme applied to both activities', 'Theme.Material.NoActionBar' in (root/'app/src/main/AndroidManifest.xml').read_text() and 'SURFACE=Color.rgb(11,16,24)' in ui and 'root.setBackgroundColor(Color.rgb(11,16,24))' in code('NavAppPickerActivity.java'))
check('HUD incoming FFF1 notification diagnostics', 'onCharacteristicChanged' in code('HudConnector.java') and 'hud_notify_count' in ui)
check('User-initiated parked HUD output check', 'HUD 연결 진단' in ui and 'ACTION_DEMO' in ui)
check('Selected FFF1+FFF2 same service', 'notifyCandidate' in code('HudConnector.java') and 'chosenService' in code('HudConnector.java'))
check('Navigation exposed text marker diagnostics', 'nav_distance_token_seen' in code('NavAccessibilityService.java') and 'nav_direction_token_seen' in ui)
check('MCon device BLE profile table based on actual APK', '0000ffea-0000-1000-8000-00805f9b34fb' in code('MconBleProfiles.java') and 'f7d72c3c02a3' in code('MconBleProfiles.java'))
check('Actual MCon GATT model-aware characteristic selection', 'MconBleProfiles.fromDeviceName' in code('HudConnector.java') and 'MconBleProfiles.fromService' in code('HudConnector.java') and 'hud_services_found' in code('HudConnector.java'))
check('Device identity and discovered GATT services included in user diagnostics', 'hud_device_name' in ui and 'hud_services_found' in ui)
check('CI release gate uses version metadata not byte comparison', 'tools/verify_release_bundle.py' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8') and 'cmp -s' not in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8'))
check('App-managed automatic brightness uses light sensor or clock',
    'Sensor.TYPE_LIGHT' in code('HudAutoBrightness.java')
    and 'clockIsNight()' in code('HudAutoBrightness.java')
    and 'updateForNight' in code('HudAutoBrightness.java')
    and 'autoBrightness.refresh()' in code('BridgeService.java'))
check('Auto brightness replays actual level rather than HUD-only profile',
    'hud_auto_night_active' in code('HudConnector.java')
    and 'HudSettingsProtocol.brightness(level,level)' in code('HudAutoBrightness.java'))
check('OEM drawable NEVER inferred from accessibility view ID',
    'append(out,NavCue.maneuverFromResourceId' not in code('NavAccessibilityService.java')
    and 'oem_direction_access' in code('NavAccessibilityService.java'))
check('OEM NAVIGATION_STATE_CHANGED status is not TBT',
    'OemTmapStateSignal.NAVIGATION_STATE' in code('BridgeService.java')
    and 'OemTmapStateSignal.MAP_ACTIVITY_STATE' in code('BridgeService.java')
    and 'NavCue' not in code('OemTmapStateSignal.java')
    and 'oem_state_observed_count' in ui)
check('OEM status parser strict package and state checks',
    'PACKAGE.equals(reportedPackage)' in code('OemTmapStateSignal.java')
    and 'state==null' in code('OemTmapStateSignal.java'))
check('OEM image and TBT distance view diagnostics preserved',
    'oem_tbt_distance_widgets_last' in code('NavAccessibilityService.java')
    and 'oem_unlabeled_images_last' in ui)
check('BYD DiCar manifest-only probe, never execute query', 'PackageManager.GET_PROVIDERS' in code('OemVehicleIpcProbe.java') and 'getActivityInfo(' in code('OemVehicleIpcProbe.java') and 'contentResolver' not in code('OemVehicleIpcProbe.java') and 'transact(' not in code('OemVehicleIpcProbe.java'))
check('BYD DiCar read-only probe shown in report', 'OemVehicleIpcProbe.inspect(this)' in ui and 'oem_vehicle_provider_probe' in ui and 'oem_cluster_activity_probe' in ui)
check('HUD-RE-012 evidence audit in CI', 'tools/validate_re012_evidence.py' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text() and (root/'research/HUD-RE-012/TECHNICAL_REPORT_KO.md').is_file())
check('OEM state tests wired into JVM suite', 'OemTmapStateSignalTest.java' in (root/'tools/run_jvm_tests.sh').read_text())
check('Auto brightness tests in CI',
    'bash tools/run_auto_brightness_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text())
check('ProviderInfo API-compatible fields only', 'i.permission' not in code('OemVehicleIpcProbe.java') and 'i.readPermission' in code('OemVehicleIpcProbe.java') and 'i.writePermission' in code('OemVehicleIpcProbe.java'))
check('Android SDK compile gate in CI', 'run_android_sdk_providerinfo_check.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text())
# v0.10.4: user-configured, local-wall-clock fallback + truthful R08 live-event telemetry.
schedule=code('HudBrightnessSchedule.java')
auto=code('HudAutoBrightness.java')
svc=code('BridgeService.java')
a11y=code('NavAccessibilityService.java')
check('Clock configuration stays inside HUD app', 'KEY_DAY_START' in schedule and 'KEY_NIGHT_START' in schedule and 'validPair(' in schedule)
check('App exposes two real time pickers', 'new TimePickerDialog(' in ui and '주간 시작' in ui and '야간 시작' in ui)
check('Three clear brightness sources', '자동 · 조도 센서 우선' in ui and '자동 · 사용자 시간표만' in ui and '고정 밝기' in ui)
check('Selection saved through service only', 'bright.putExtra("day_start",dayStartMinutes)' in ui and 'HudBrightnessSchedule.KEY_DAY_START' in svc)
check('Service rejects equal brightness boundary', 'HudBrightnessSchedule.validPair(dayStart,nightStart)' in svc)
check('Clock/timezone recalculation registered dynamically', 'Intent.ACTION_TIME_CHANGED' in svc and 'Intent.ACTION_TIMEZONE_CHANGED' in svc and 'registerReceiver(timeReceiver,timeFilter)' in svc)
check('Automatic brightness remains sensor-first', 'Sensor.TYPE_LIGHT' in auto and 'ensureSensorMode(!scheduleOnly())' in auto)
check('Clock-only mode never reads sensor value', 'scheduleOnly() || event==null' in auto)
check('Brightness replay uses configured fallback', 'HudBrightnessSchedule.nowIsNight' in code('HudConnector.java'))
check('Accessibility attempts counted even for empty screen', 'nav_poll_last_attempt_at' in a11y and 'nav_poll_last_empty_at' in a11y)
check('Service session diagnostics stored separately', 'nav_session_events' in a11y and 'a11y_session_started_at' in a11y)
check('Live state never based solely on historical count', 'recentNavEvent' in ui and 'recentPoll' in ui and '과거 누적 기록' in ui)
check('R08 diagnostic fields included in exported ZIP report', 'nav_poll_last_attempt_at' in ui and 'nav_session_polls' in ui)
check('Clock schedule JVM test wired in CI', 'HudBrightnessScheduleTest' in (root/'tools/run_jvm_tests.sh').read_text())
check('HUD packet protocol retains proven real-car implementation', '0x19' in code('MconHudQProtocol.java') and '0000fff2-0000-1000-8000-00805f9b34fb' in code('HudConnector.java'))
# v0.10.5 fail-closed guide extraction and honest transport telemetry.
cue=code('NavCue.java')
check('Cross-node text segments parsed separately','parseOneTextSegment' in cue and 'value.split("[\\\\r\\\\n|]+")' in cue)
check('Lane/remaining-distance text blocked','AMBIGUOUS_GUIDANCE' in cue and '차선|차로|' in cue)
check('Unverified left/right direction blocked','k.equals("오른쪽")||k.equals("우측")' in cue)
check('Ambiguous post-turn distance blocked','between.contains("후")' in cue and 'between.contains("별도")' in cue)
check('New route content excluded from persistent cue','cue.safeDisplay()' in code('BridgeLog.java') and 'new NavCue(origin,dir,meters,"",-1,-1,"")' in cue)
check('Notification fields kept independent','String.valueOf(title)+"\\n"' in code('NavNotificationService.java'))
check('Navigator accessibility nodes separated',"out.append(s).append('\\n')" in a11y)
check('Current parsed state not purely historical', 'recentParsed' in ui and '과거 안내 누적' in ui)
check('Navigation and setting BLE counters separate','hud_nav_write_requests' in code('HudConnector.java') and 'hud_setting_write_requests' in code('HudConnector.java'))
check('Navigation transport callbacks counted separately','hud_nav_callback_confirmed' in code('HudConnector.java') and 'hud_setting_callback_confirmed' in code('HudConnector.java'))
check('Read-only OEM chain unchanged','transact(' not in code('OemTmapBinderProbe.java') and 'OemTmapStateSignal.NAVIGATION_STATE' in svc)

# v0.10.6 privacy-preserving window ownership probe, triggered ONLY by user confirmation.
check('Window probe only starts after confirmed manual HUD test', 'NavAccessibilityService.requestWindowProbe(this)' in ui and '.setPositiveButton("1회 전송"' in ui)
check('Window probe bounded in time', 'probeUntilElapsed=SystemClock.elapsedRealtime()+WindowProbePolicy.WINDOW_MS' in a11y and 'pollHandler.postDelayed(done,8100)' in a11y)
check('Window probe stores metadata, not node text', 'window.getBoundsInScreen(bounds)' in a11y and 'window.getType()' in a11y and 'window.getLayer()' in a11y and 'append(out,root.getText())' not in a11y)
check('Window probe status exported with user ZIP', 'window_probe_history' in ui and 'window_probe_samples' in ui)
check('Empty navigation poll backed off', 'WindowProbePolicy.pollInterval(emptyPollStreak)' in a11y and 'now-lastTreeAt>=450' in a11y) # event scan uses now-lastTreeAt

check('Window probe policy exercised in CI', 'WindowProbePolicyTest.java' in (root/'tools/run_jvm_tests.sh').read_text())
fail=[n for n,good in checks if not good]
print('DASHBOARD PREFLIGHT SUMMARY', len(checks)-len(fail),'/',len(checks),'PASS')
if fail:sys.exit(1)


# v0.10.7: read-only watchdog, no accessibility privilege escalation.
health=code('NavPollHealth.java')
check('Monotonic receiver health policy uses elapsedRealtime', 'STALE_MS=20000L' in health and 'REPAIR_COOLDOWN_MS=60000L' in health)
check('Health monitor runs inside existing foreground bridge', 'checkNavReceiverHealth' in svc and 'NavPollHealth.allowRepair' in svc)
check('Safe recovery only restarts authorized polling runnable', 'requestSafePollRecovery' in a11y and 'removeCallbacks(s.periodicGuideScan)' in a11y)
check('Runtime does not force-enable AccessibilityService', 'Settings.Secure' not in a11y and 'startService(' not in health)
check('Disabled mode keeps truthful status', 'DISABLED' in a11y and 'nav_last_enabled_changed_at' in ui)
check('Poll loop callback and outcome in diagnostics', 'nav_poll_last_outcome' in a11y and 'nav_poll_last_outcome' in ui)
check('One tap quick diagnosis exports ZIP without manual tests', 'quickDiagnosticZip' in ui and 'this::quickDiagnosticZip' in ui and 'exportZip()' in ui)
check('Window probe IDs but no new content capture', 'window.getId()' in a11y and 'window_probe_change_events' in a11y)
check('Pending identical setting commands suppressed only', 'pendingWrite && inFlightSetting' in code('HudConnector.java') and 'recordSuppressedSetting()' in code('HudConnector.java'))
check('Watchdog state machine JVM tests wired', 'NavPollHealthTest' in (root/'tools/run_jvm_tests.sh').read_text())
fail=[n for n,good in checks if not good]
if fail:
    print('v0.10.7 FAILURES:',fail)
    sys.exit(1)
print('v0.10.7 EXTRA GATES PASS',len(checks)-len(fail),'/',len(checks))

# v0.10.8: explicit independent source and channel evidence, never invented success.
trace=code('NavInputTrace.java')
policy=code('NavTracePolicy.java')
check('OEM and general TMAP exact packages separately tracked', 'com.tmap.auto.byd' in policy and 'com.skt.tmap.ku' in policy)
check('Independent notification evidence', 'NavInputTrace.observe(this,pkg,"notification"' in code('NavNotificationService.java'))
check('Independent accessibility evidence', 'NavInputTrace.observe(this,pkg,"access_event"' in a11y and 'NavInputTrace.observe(NavAccessibilityService.this,nav,"access_poll"' in a11y)
check('Compatibility broadcast is diagnostic ONLY', 'UNVERIFIED_DIAGNOSTIC_ONLY' in svc and 'BridgeLog.cue(context,cue)' not in svc)
check('BLE queue not confused with HUD screen', 'QUEUE' not in trace.upper() or 'HUD 화면 표시 확인 아님' in trace)
check('Per navigator report included in ZIP', 'NavInputTrace.report(prefs)' in ui and 'report.txt' in ui)
check('Source policy test wired in CI','NavTracePolicyTest.java' in (root/'tools/run_jvm_tests.sh').read_text())
fail=[n for n,good in checks if not good]
if fail: print('v0.10.8 additional failed:', fail);sys.exit(1)
print('v0.10.8 validation PASS',len(checks),'/',len(checks))
