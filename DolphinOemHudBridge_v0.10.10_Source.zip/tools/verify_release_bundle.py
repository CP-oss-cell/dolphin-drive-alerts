#!/usr/bin/env python3
"""CI release identity validation: verify unpacked source, not byte-for-byte duplicate YML."""
from pathlib import Path
import argparse, json, re, sys
ap=argparse.ArgumentParser()
ap.add_argument('--version', required=True)
ap.add_argument('--code', required=True, type=int)
a=ap.parse_args()
root=Path(__file__).resolve().parent.parent
metadata=json.loads((root/'RELEASE_BUNDLE.json').read_text(encoding='utf-8'))
assert metadata.get('release')==a.version, f"Release metadata mismatch: {metadata.get('release')} != {a.version}"
assert metadata.get('versionCode')==a.code, 'Version code in metadata mismatch'
assert metadata.get('applicationId')=='com.dolphin.oemhud', 'Unexpected application ID'
source=(root/'app/build.gradle').read_text(encoding='utf-8')
assert re.search(r'\bversionCode\s+'+str(a.code)+r'\b',source), 'Gradle versionCode mismatch'
assert re.search(r"\bversionName\s+['\"]"+re.escape(metadata['versionName'])+r"['\"]", source), 'Gradle versionName mismatch'
mandatory=['app/src/main/AndroidManifest.xml','tools/preflight.py','tools/run_nav_receiver_typecheck.sh',
           'app/src/main/java/com/dolphin/oemhud/MainActivity.java',
           'app/src/main/java/com/dolphin/oemhud/NavPackageMatcher.java',
           'app/src/main/java/com/dolphin/oemhud/NavAccessibilityService.java']
for rel in mandatory:
    assert (root/rel).is_file(), 'Missing required file: '+rel
code=(root/'app/src/main/java/com/dolphin/oemhud/NavPackageMatcher.java').read_text(encoding='utf-8')
assert 'com.tmap.auto.byd' in code, 'OEM TMAP package missing'
print(f"PASS CI RELEASE IDENTITY: {a.version} versionCode={a.code} package={metadata['applicationId']}")
print('PASS required sources and OEM TMAP package verified; no source-vs-YML byte compare')
