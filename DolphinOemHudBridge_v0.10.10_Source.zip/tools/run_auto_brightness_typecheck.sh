#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src" "$TMP/classes"
python3 - "$TMP/src" <<'PY'
from pathlib import Path
import sys
r=Path(sys.argv[1])
stubs={
'android/content/Context.java':'''package android.content;public class Context{public static final String SENSOR_SERVICE="sensor";public Context getApplicationContext(){return this;}public Object getSystemService(String s){return null;}public SharedPreferences getSharedPreferences(String n,int m){return null;}}''',
'android/content/SharedPreferences.java':'''package android.content;public interface SharedPreferences{boolean getBoolean(String k,boolean d);int getInt(String k,int d);Editor edit();interface Editor{Editor putString(String k,String v);Editor putLong(String k,long v);Editor putBoolean(String k,boolean v);void apply();}}''',
'android/hardware/Sensor.java':'''package android.hardware;public class Sensor{public static final int TYPE_LIGHT=5;public int getType(){return TYPE_LIGHT;}}''',
'android/hardware/SensorEvent.java':'''package android.hardware;public class SensorEvent{public Sensor sensor;public float[] values;}''',
'android/hardware/SensorEventListener.java':'''package android.hardware;public interface SensorEventListener{void onSensorChanged(SensorEvent e);void onAccuracyChanged(Sensor s,int a);}''',
'android/hardware/SensorManager.java':'''package android.hardware;public class SensorManager{public static final int SENSOR_DELAY_NORMAL=3;public Sensor getDefaultSensor(int t){return null;}public boolean registerListener(SensorEventListener l,Sensor s,int d){return true;}public void unregisterListener(SensorEventListener l){}}''',
'android/os/Looper.java':'''package android.os;public class Looper{public static Looper getMainLooper(){return null;}}''',
'android/os/Handler.java':'''package android.os;public class Handler{public Handler(Looper l){}public void postDelayed(Runnable r,long ms){}public void removeCallbacks(Runnable r){}}''',
'android/os/SystemClock.java':'''package android.os;public class SystemClock{public static long elapsedRealtime(){return 1000;}}''',
'com/dolphin/oemhud/BridgeLog.java':'''package com.dolphin.oemhud;public class BridgeLog{public static final String STORE="nav_bridge";public static void event(android.content.Context c,String x){}}''',
'com/dolphin/oemhud/HudConnector.java':'''package com.dolphin.oemhud;public class HudConnector{public boolean sendSetting(byte[] f){return true;}}''',
'com/dolphin/oemhud/AutoBrightnessTest.java':'''package com.dolphin.oemhud;public class AutoBrightnessTest{public static void main(String[]v){if(!HudAutoBrightness.sensorNight(10f,false))throw new RuntimeException("dark");if(!HudAutoBrightness.sensorNight(65f,true))throw new RuntimeException("hysteresis");if(HudAutoBrightness.sensorNight(90f,true))throw new RuntimeException("bright");if(HudAutoBrightness.sensorNight(50f,false))throw new RuntimeException("no false night");if(HudAutoBrightness.sensorNight(Float.NaN,false))throw new RuntimeException("nan");System.out.println("PASS AUTO BRIGHTNESS light hysteresis 5 cases");}}'''
}
for name,src in stubs.items():
 p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(src)
PY
find "$TMP/src" -name '*.java' > "$TMP/sources.txt"
printf '%s\n' app/src/main/java/com/dolphin/oemhud/HudSettingsProtocol.java app/src/main/java/com/dolphin/oemhud/HudAutoBrightness.java app/src/main/java/com/dolphin/oemhud/HudBrightnessSchedule.java >> "$TMP/sources.txt"
javac -encoding UTF-8 -d "$TMP/classes" @"$TMP/sources.txt"
java -cp "$TMP/classes" com.dolphin.oemhud.AutoBrightnessTest
echo 'PASS HUD auto brightness actual Java source Android API typecheck using offline stubs (SDK build unverified)'
