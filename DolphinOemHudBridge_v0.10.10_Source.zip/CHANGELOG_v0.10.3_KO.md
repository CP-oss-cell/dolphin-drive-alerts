# v0.10.3 변경 내역
- GitHub Actions `byd2.zip` Java 컴파일 에러 `ProviderInfo.permission` 수정.
- 테스트 ProviderInfo 스텁을 Android 실제 API에 맞춤.
- 실제 SDK `android.jar` 별도 컴파일 단계와 정적 회귀 방지 검사 추가.
- 설치 업데이트를 위한 versionCode 23.
- BLE/HUD 프로토콜 및 안전한 읽기 전용 네비·차량 코드 로직 유지.
