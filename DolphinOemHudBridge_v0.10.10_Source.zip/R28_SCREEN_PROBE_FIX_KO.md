# R28 / v0.10.10 화면 진단 개선

- 실차 v0.10.9: MediaProjection `SecurityException`, 정확한 실패 지점은 기존 로그로 미확정.
- 이전 구현은 화면 공유 승인 결과 Intent를 5초 지연 후 `getMediaProjection()`에 전달했음.
- 변경: 승인 결과 수신 즉시 `getMediaProjection()` 및 `createVirtualDisplay()` 수행, 5초 후 첫 프레임 검사.
- 실패 단계 구분: GET_MEDIA_PROJECTION, CREATE_VIRTUAL_DISPLAY, FRAME_LISTENER, FRAME_ERROR, TIMEOUT.
- 캡처 이미지, 안내 문구, 목적지 저장 금지. HUD 자동 TBT 전송 없음.
- 실차 테스트: 정차 중 HUD BLE/수동 안내/밝기 확인, 순정 TMAP 화면 캡처 동의 1회, 진단 ZIP 공유.
- 화면 캡처 성공은 TBT 방향/거리 자동 인식 성공을 뜻하지 않음.
- APK 컴파일은 별도 CI 실행 전까지 미검증.
