# v0.10.1 — 실차 BLE 확인 후 자동 밝기 및 화면 안내 보완

- `versionCode 21`, `versionName 0.10.1-auto-brightness-nav-hints`
- 2026-11-03 실차에서 TPLAY HUD Q 연결/수동 밝기/우회전 300m HUD 표시 확인. BLE 근본 통신 로직 변경하지 않음.
- 전 버전의 '자동 밝기'가 단순 주간·야간 프로필 저장이었던 것을 수정: Android 조도 센서 우선, 시간대 fallback, **현재 밝기 단계 재송신**, 재연결 복원, 상태 로깅.
- 순정 TMAP/부가 내비 화면에서 명시적 방향 텍스트, Unicode 방향 기호, 명확한 리소스 ID 방향 힌트를 처리. 보이지 않는 그래픽 화살표와 TBT 원본 IPC의 접근 문제는 여전히 미해결.
- 기존 `INaviService` Binder 관찰-only, TBT 미확정 송신 차단, 2602/2606 연구 근거, 다크 대시보드 유지.
- 앱 로컬 사전/모의 회귀 검사 추가. GitHub Actions APK 빌드 성공 및 실제 차량 자동 안내는 주장하지 않음.

읽을 것: `REALCAR_20261103_ROOT_CAUSE_KO.md`
