# v0.9.9 MCon K 원본 비교 및 수정 검증

- 원본: 사용자가 제공한 `MCon+K_2.1.5.004_APKPure.xapk`; APK `classes2.dex` 원본 정적 DEX 코드 구조 조사.
- DEX `Lma/b;invoke`: `TPLAY HUD Q` → `Lsa/l;`의 FFEA 서비스, 표준 FFF1/FFF2 특성. `HUD Q MAX` → `Lsa/m;`의 FFF0/FFF1/FFF2 및 `f7d72c3c02a3` 베이스 UUID. `Tmap api HUD` → `Lsa/n;`의 FEE9 서비스. *이름별 프로필 분기는 MCon K 전체 SDK 모델별 설정이며, 사용자의 실물 HUD 모델은 새 진단으로 확정 필요.*
- 기존 소스: 모델별 GATT 서비스 필터 없이 표준 FFF2 UUID를 어떤 서비스에서든 찾고, 알림은 표준 FFF1 UUID로 고정했음. 여러 서비스가 있는 경우 잘못된 채널을 선택할 가능성.
- v0.9.9: 기기명 분기를 통해 기대 서비스 우선, 실제 서비스 목록과 매칭 여부 로그, F7 베이스 UUID 지원. 알 수 없는 모델은 자동 관찰+보수적 선택. 차량 기본 블루투스 연결 끊기/임의 시스템 명령 없음.
- 외부 MCon K 성공은 HUD 통신 가능성의 근거이나, 순정 BYD TMAP에서 제3자 앱으로 TBT 정보를 제공한다는 근거는 아님. 두 경로를 별도로 검증해야 함.
- 실제 Android Gradle 빌드/차량/실물 HUD 표시 확인 전까지 성공으로 판정하지 않음.
