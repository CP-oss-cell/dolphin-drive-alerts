# BYD 돌핀 FSD 15 리얼뷰 — 통합 소스 + GitHub Actions 자동 APK 빌드 패키지

PC에 Android Studio를 설치하지 않고도 GitHub에 올리기만 하면 `.github/workflows/build-apk.yml`이 **BYD 돌핀용 ARM64 APK**와 **ADB UID 2000 브릿지 DEX**를 자동 빌드합니다.

## 포함 파일
- `app/src/main/java/com/byd/dolphin/fsd15/BydDolphinFsd15Unified.kt` — 앱 호스트 + ADB 브릿지 + WebGL 리얼뷰 엔진 단일 통합 소스
- `.github/workflows/build-apk.yml` — GitHub Actions 자동 APK/DEX 빌드 워크플로우
- `app/build.gradle.kts` / `AndroidManifest.xml` — BYD 돌핀 DiLink 3.0 (`minSdk 29`, `targetSdk 33`, `arm64-v8a`) 설정
- `adb-bridge/start_bridge.sh` — 돌핀 Wi-Fi ADB(`192.168.10.10:5555`) 실행 스크립트

## 3단계 자동 APK 빌드 및 돌핀 설치
1. 이 압축 파일을 풀어 새 GitHub 저장소에 업로드(Push)합니다.
2. GitHub 저장소의 **Actions** 탭 → **Build BYD Dolphin FSD 15 Reality View APK** 실행 완료 후 `byd-dolphin-fsd15-apk-and-dex` 아티팩트를 다운로드합니다.
3. 돌핀 Wi-Fi ADB 연결 후 설치 및 브릿지 실행:
   ```bash
   adb connect 192.168.10.10:5555
   adb install -r byd-dolphin-fsd15-reality-view.apk
   adb push byd_reality_bridge.dex /data/local/tmp/byd_reality_bridge.dex
   adb shell "nohup app_process -Djava.class.path=/data/local/tmp/byd_reality_bridge.dex:/system/framework/bmmcamera.jar / com.byd.dolphin.fsd15.BydRealityBridge >/data/local/tmp/bridge.log 2>&1 &"
   ```
