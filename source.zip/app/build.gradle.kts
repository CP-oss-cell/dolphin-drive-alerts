plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.byd.dolphin.fsd15"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.byd.dolphin.fsd15"
        minSdk = 29
        targetSdk = 33
        versionCode = 1
        versionName = "1.0.0-dolphin-adb"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Zero heavy UI frameworks — keeps RAM footprint minimal on BYD Dolphin (~3.5 GB RAM)
}
