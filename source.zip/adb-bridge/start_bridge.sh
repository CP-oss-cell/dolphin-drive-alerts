#!/usr/bin/env bash
# BYD Dolphin (DiLink 3.0 / QCM6125 / Android 10) — ADB UID 2000 Helper Launcher
# No root required. Run from PC/laptop connected to the Dolphin car Wi-Fi.

set -euo pipefail
HEAD_UNIT_IP="${1:-192.168.10.10}"
PORT="5555"

echo "[1/3] Connecting to BYD Dolphin DiLink via ADB (${HEAD_UNIT_IP}:${PORT})..."
adb connect "${HEAD_UNIT_IP}:${PORT}"

echo "[2/3] Pushing compiled DEX bridge to /data/local/tmp/..."
# Compile BydRealityBridge.java with Android SDK (minSdk 29, targetSdk 29) -> classes.dex
# adb push byd_reality_bridge.dex /data/local/tmp/byd_reality_bridge.dex

echo "[3/3] Starting shell-UID (2000) app_process bridge (binds 127.0.0.1:8765)..."
adb shell "nohup app_process -Djava.class.path=/data/local/tmp/byd_reality_bridge.dex:/system/framework/bmmcamera.jar / BydRealityBridge >/data/local/tmp/bridge.log 2>&1 &"
echo "Done. Check logs with: adb shell tail -f /data/local/tmp/bridge.log"
