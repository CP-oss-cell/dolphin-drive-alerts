package com.byd.dolphin.drivealerts.camera

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hardware H.264 MediaCodec (Surface input) + MediaMuxer MP4 Recorder (v0.17.104).
 *
 * Replaces Android MediaRecorder for BYD Dolphin DiLink 5.0 AVM Zero-Copy dashcam recording:
 * - MediaRecorder with EGL WindowSurface silently drops frames on Snapdragon DiLink 5.0.
 * - MediaCodec("video/avc") + createInputSurface() + MediaMuxer encodes real H.264 frames
 *   directly from GlLutDewarpRenderer with live encodedFrames & bytesWritten telemetry.
 */
class HardwareAvcMp4Recorder(
    private val outputFile: File,
    private val width: Int,
    private val height: Int,
    private val bitrate: Int,
    private val fps: Int = 24
) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var surface: Surface? = null
    private var drainThread: Thread? = null
    private val stopping = AtomicBoolean(false)
    private val released = AtomicBoolean(false)

    @Volatile var trackIndex: Int = -1
        private set
    @Volatile var muxerStarted: Boolean = false
        private set
    @Volatile var framesEncoded: Long = 0L
        private set
    @Volatile var bytesWritten: Long = 0L
        private set
    @Volatile var lastError: String? = null
        private set

    fun inputSurface(): Surface? = surface

    fun start(): Boolean {
        return runCatching {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val mc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            mc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf = mc.createInputSurface()
            mc.start()

            val mx = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            codec = mc
            surface = surf
            muxer = mx

            val t = Thread({ drainLoop(mc, mx) }, "avc-muxer-drain")
            drainThread = t
            t.start()
            CoreLog.i("DASHCAM", "AVC_CODEC_STARTED file=${outputFile.name} ${width}x${height}@${fps} br=$bitrate")
            true
        }.onFailure { e ->
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            CoreLog.w("DASHCAM", "AVC_CODEC_START_FAILED: $lastError", e)
            stopAndRelease()
        }.getOrDefault(false)
    }

    private fun drainLoop(mc: MediaCodec, mx: MediaMuxer) {
        val info = MediaCodec.BufferInfo()
        var lastPtsUs = 0L
        while (!released.get()) {
            val idx = try {
                mc.dequeueOutputBuffer(info, 25_000L)
            } catch (e: Throwable) {
                if (!stopping.get()) {
                    lastError = "${e.javaClass.simpleName}: ${e.message}"
                    CoreLog.w("DASHCAM", "AVC_DEQUEUE_ERR: $lastError")
                }
                break
            }
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (stopping.get()) break
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val fmt = mc.outputFormat
                        trackIndex = mx.addTrack(fmt)
                        mx.start()
                        muxerStarted = true
                        CoreLog.i("DASHCAM", "AVC_MUXER_STARTED track=$trackIndex file=${outputFile.name}")
                    }
                }
                idx >= 0 -> {
                    val buf = runCatching { mc.getOutputBuffer(idx) }.getOrNull()
                    if (buf != null) {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            info.size = 0
                        }
                        if (info.size > 0 && muxerStarted && trackIndex >= 0) {
                            // Guarantee strictly increasing PTS in microseconds for MediaMuxer
                            if (info.presentationTimeUs <= lastPtsUs) {
                                info.presentationTimeUs = lastPtsUs + (1_000_000L / fps.coerceAtLeast(1))
                            }
                            lastPtsUs = info.presentationTimeUs
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            runCatching {
                                mx.writeSampleData(trackIndex, buf, info)
                                framesEncoded++
                                bytesWritten += info.size
                            }.onFailure { e ->
                                lastError = "mux:${e.javaClass.simpleName}:${e.message}"
                            }
                        }
                    }
                    runCatching { mc.releaseOutputBuffer(idx, false) }
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    fun stopAndRelease() {
        if (!released.compareAndSet(false, true)) return
        stopping.set(true)
        runCatching { codec?.signalEndOfInputStream() }
        runCatching { drainThread?.join(1_500L) }
        drainThread = null
        if (muxerStarted) {
            runCatching { muxer?.stop() }.onFailure { CoreLog.w("DASHCAM", "muxer.stop failed: ${it.message}") }
        }
        runCatching { muxer?.release() }
        muxer = null
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
        runCatching { surface?.release() }
        surface = null
        CoreLog.i("DASHCAM", "AVC_CODEC_STOPPED file=${outputFile.name} frames=$framesEncoded bytes=$bytesWritten fileLen=${outputFile.length()}")
    }
}
