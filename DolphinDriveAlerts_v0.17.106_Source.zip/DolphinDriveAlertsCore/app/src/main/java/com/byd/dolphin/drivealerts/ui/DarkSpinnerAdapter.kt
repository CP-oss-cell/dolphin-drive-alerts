package com.byd.dolphin.drivealerts.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/** Concept A Dark-Glass Dual-Tone Luminous automotive dropdown styling (52dp touch height, frosted glass). */
object DarkSpinnerAdapter {
    fun labels(context: Context, data: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, data) {
            private fun style(v: View, dropdown: Boolean): View {
                if (v is TextView) {
                    val d = context.resources.displayMetrics.density
                    val padH = (16 * d).toInt()
                    val padV = (13 * d).toInt()
                    v.setTextColor(DashboardUi.textColor(context))
                    v.textSize = if (dropdown) 15f else 14.5f
                    v.setTypeface(v.typeface, if (dropdown) Typeface.NORMAL else Typeface.BOLD)
                    v.gravity = Gravity.CENTER_VERTICAL
                    v.setPadding(padH, padV, padH, padV)
                    v.minimumHeight = (52 * d).toInt()
                    v.background = if (dropdown) {
                        GradientDrawable().apply {
                            setColor(if (DashboardUi.isLightMode(context)) DashboardUi.surfaceColor(context) else 0xFF0E1728.toInt())
                            setStroke((1 * d).toInt().coerceAtLeast(1), DashboardUi.borderColor(context))
                        }
                    } else {
                        DashboardUi.glassPanelBg(context, 0, 14)
                    }
                }
                return v
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent), true)
        }
}
