package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.dock.DockPreferences
import com.byd.dolphin.drivealerts.dock.SystemBarController
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.service.DrivingAlertService

/**
 * Configuration screen for Stock System Bar Hide/Full-Hide and the Fixed Bottom Floating Dock Bar
 * (auto-collapse, height/opacity, extra stock BYD functions, pinned apps, and custom app folders).
 */
class DockBarSettingsActivity : DensityAwareActivity() {
    private lateinit var screen: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = DashboardUi.dp(this@DockBarSettingsActivity, v)

    private fun render() {
        val accent = DashboardUi.accentColor(this)
        screen = DashboardUi.page(
            this,
            "순정 바 숨김 · 하단 플로팅 독바",
            "상·하단바 숨김 · 하단 고정 공조/열선 바 · 앱 폴더 · 가로 스와이프",
            DashboardIcons.IconKind.SPLIT_DISPLAY,
            accent
        ) { render() }

        // 1. 순정 UI 상단바 / 하단바 숨김
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "순정 UI 상단바 · 하단바 숨김",
            "BYD 순정 상단바·하단바를 숨기거나 완전 숨김(몰입 모드)으로 전환합니다.",
            DashboardIcons.IconKind.SPLIT_DISPLAY,
            accent
        ) { p ->
            val statusTv = DashboardUi.label(this, "현재 설정: ${SystemBarController.modeLabels[DockPreferences.systemBarMode(this)]}", 13f, true)
            p.addView(statusTv)
            val shortSysLabels = listOf("순정 표시", "상단 숨김", "하단 숨김", "완전 숨김")
            p.addView(DashboardUi.segmentedBar(this, shortSysLabels, DockPreferences.systemBarMode(this), accent) { pos ->
                SystemBarController.apply(this@DockBarSettingsActivity, pos) { _, msg ->
                    runOnUiThread { statusTv.text = msg }
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(8)) })
            p.addView(DashboardUi.action(this, "현재 모드 다시 적용", DashboardIcons.IconKind.PLAY, accent) {
                SystemBarController.apply(this, DockPreferences.systemBarMode(this)) { _, msg ->
                    runOnUiThread {
                        statusTv.text = msg
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }, LinearLayout.LayoutParams(-1, dp(46)))
        })

        // 2. 고정형 하단 플로팅 독바 기본 설정
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "고정형 하단 플로팅 독바",
            "순정 하단바 위치·크기에 고정되며 접기(반투명 핸들), 공조/열선, 앱서랍, 폴더, 가로 스와이프를 지원합니다.",
            DashboardIcons.IconKind.CAR_ALERT,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "하단 플로팅 독바 켜기 (ON/OFF)", DockPreferences.enabled(this)) { on ->
                if (on && !Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "먼저 '화면 위 표시 권한'을 허용해 주세요.", Toast.LENGTH_LONG).show()
                    SafeSettingsLauncher.open(this, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
                    return@toggle
                }
                DockPreferences.setEnabled(this, on)
                DrivingAlertService.refreshDock(this)
            })

            p.addView(DashboardUi.label(this, "독바 화면 고정 위치 (터치 드래그로도 4곳 끝단 이동 가능)", 13f, true))
            val shortEdges = listOf("하단바", "상단바", "왼쪽 끝", "오른쪽 끝")
            p.addView(DashboardUi.segmentedBar(this, shortEdges, DockPreferences.edgePosition(this), accent) { pos ->
                DockPreferences.setEdgePosition(this@DockBarSettingsActivity, pos)
                DrivingAlertService.refreshDock(this@DockBarSettingsActivity)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(8)) })
            p.addView(DashboardUi.toggle(this, "자동 접기 사용 (일정 시간 후 반투명 아이콘으로 접힘)", DockPreferences.autoCollapse(this)) { on ->
                DockPreferences.setAutoCollapse(this, on)
                DrivingAlertService.refreshDock(this)
            })

            val secOpts = listOf(5, 8, 10, 15, 30)
            val curSecIdx = secOpts.indexOf(DockPreferences.autoCollapseSeconds(this)).coerceAtLeast(0)
            p.addView(DashboardUi.segmentedBar(this, secOpts.map { "${it}초" }, curSecIdx, accent) { pos ->
                DockPreferences.setAutoCollapseSeconds(this@DockBarSettingsActivity, secOpts[pos])
                DrivingAlertService.refreshDock(this@DockBarSettingsActivity)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(8)) })

            val hLabel = DashboardUi.label(this, "독바 높이: ${DockPreferences.heightDp(this)}dp (기본 68dp · 54~84dp)", 13f)
            p.addView(hLabel)
            p.addView(DashboardUi.styleSeekBar(this, SeekBar(this).apply {
                max = 30 // 54..84
                progress = (DockPreferences.heightDp(this@DockBarSettingsActivity) - 54).coerceIn(0, 30)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        val v = 54 + prog
                        hLabel.text = "독바 높이: ${v}dp (기본 68dp · 54~84dp)"
                        if (fromUser) {
                            DockPreferences.setHeightDp(this@DockBarSettingsActivity, v)
                            DrivingAlertService.refreshDock(this@DockBarSettingsActivity)
                        }
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }))

            val opLabel = DashboardUi.label(this, "독바 배경 불투명도: ${DockPreferences.opacityPercent(this)}%", 13f)
            p.addView(opLabel)
            p.addView(DashboardUi.styleSeekBar(this, SeekBar(this).apply {
                max = 45 // 55..100
                progress = (DockPreferences.opacityPercent(this@DockBarSettingsActivity) - 55).coerceIn(0, 45)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        val v = 55 + prog
                        opLabel.text = "독바 배경 불투명도: ${v}%"
                        if (fromUser) {
                            DockPreferences.setOpacityPercent(this@DockBarSettingsActivity, v)
                            DrivingAlertService.refreshDock(this@DockBarSettingsActivity)
                        }
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }))
        })

        // 3. 오른쪽 스와이프 영역에 추가할 순정 기능 선택
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "추가 순정 기능 선택 (오른쪽 스와이프 영역)",
            "기본 공조·열선 버튼 외에 독바 오른쪽으로 스와이프해 쓸 순정 기능을 선택합니다.",
            DashboardIcons.IconKind.CHECKLIST,
            accent
        ) { p ->
            val current = DockPreferences.extraStockActions(this).toMutableSet()
            val extraViews = DockPreferences.ExtraStockAction.values().map { act ->
                DashboardUi.toggle(this, act.label, act.key in current) { on ->
                    if (on) current.add(act.key) else current.remove(act.key)
                    DockPreferences.setExtraStockActions(this, current)
                    DrivingAlertService.refreshDock(this)
                }
            }
            DashboardUi.addTwoColumnGrid(p, this, extraViews)
        })

        // 4. 설치된 앱 바로 추가
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "독바에 설치된 앱 추가",
            "추가한 앱은 실제 앱 아이콘으로 독바 오른쪽 영역에 표시됩니다.",
            DashboardIcons.IconKind.POWER_LAUNCH,
            accent
        ) { p ->
            val pinned = DockPreferences.pinnedApps(this)
            p.addView(DashboardUi.label(this, "등록된 앱 ${pinned.size}개", 13f, true))
            for (pkg in pinned) {
                val name = appLabel(pkg)
                p.addView(DashboardUi.actionRow(this, name, "탭하여 독바에서 제거", DashboardIcons.IconKind.STOP, DashboardUi.dangerColor(this), "제거") {
                    DockPreferences.removePinnedApp(this, pkg)
                    DrivingAlertService.refreshDock(this)
                    render()
                })
            }
            p.addView(DashboardUi.action(this, "+ 설치된 앱 선택해서 추가", DashboardIcons.IconKind.PLAY, accent) {
                pickInstalledApp { pkg ->
                    DockPreferences.addPinnedApp(this, pkg)
                    DrivingAlertService.refreshDock(this)
                    render()
                }
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })
            val popOpLabel = DashboardUi.label(this, "팝업 폴더 기본 투명도: ${DockPreferences.popupOpacityPercent(this)}% (기본 반투명 78%)", 13f)
            p.addView(popOpLabel)
            p.addView(DashboardUi.styleSeekBar(this, SeekBar(this).apply {
                max = 60 // 40..100
                progress = (DockPreferences.popupOpacityPercent(this@DockBarSettingsActivity) - 40).coerceIn(0, 60)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        val v = 40 + prog
                        popOpLabel.text = "팝업 폴더 기본 투명도: ${v}% (기본 반투명 78%)"
                        if (fromUser) DockPreferences.setPopupOpacityPercent(this@DockBarSettingsActivity, v)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }))
            val colOpts = listOf(2, 3, 4, 5, 6)
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@DockBarSettingsActivity, colOpts.map { "팝업 가로 칸 수: ${it}칸" })
                setSelection(colOpts.indexOf(DockPreferences.popupCols(this@DockBarSettingsActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        DockPreferences.setPopupCols(this@DockBarSettingsActivity, colOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            val rowOpts = listOf(2, 3, 4, 5)
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@DockBarSettingsActivity, rowOpts.map { "팝업 세로 줄 수: ${it}줄" })
                setSelection(rowOpts.indexOf(DockPreferences.popupRows(this@DockBarSettingsActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        DockPreferences.setPopupRows(this@DockBarSettingsActivity, rowOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })
        })

        // 5. 팝업 폴더 생성 · 관리
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "독바 앱 폴더 관리 (팝업 폴더)",
            "폴더를 만들고 앱을 넣으면 독바에 미니 아이콘 폴더가 표시되며 누르면 팝업으로 열립니다.",
            DashboardIcons.IconKind.DPI_GRID,
            accent
        ) { p ->
            val folders = DockPreferences.folders(this)
            p.addView(DashboardUi.label(this, "생성된 폴더 ${folders.size}개", 13f, true))
            for (f in folders) {
                val names = f.packages.joinToString(", ") { appLabel(it) }.ifBlank { "비어 있음" }
                p.addView(DashboardUi.actionRow(this, "폴더: ${f.name} (${f.packages.size}개)", names, DashboardIcons.IconKind.DPI_GRID, accent, "편집") {
                    showFolderEditor(f)
                })
            }
            p.addView(DashboardUi.action(this, "+ 새 폴더 만들기", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                promptCreateFolder()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })
        })

    }

    private fun appLabel(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg.substringAfterLast('.'))

    private fun listLaunchablePackages(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return runCatching {
            packageManager.queryIntentActivities(intent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .map { it to appLabel(it) }
                .sortedBy { it.second }
        }.getOrDefault(emptyList())
    }

    private fun pickInstalledApp(onPick: (String) -> Unit) {
        val apps = listLaunchablePackages()
        val labels = apps.map { "${it.second} (${it.first})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("추가할 앱 선택")
            .setItems(labels) { _, which -> onPick(apps[which].first) }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun promptCreateFolder() {
        val input = EditText(this).apply { hint = "예: 내비 · 음악 · 유튜브" }
        AlertDialog.Builder(this)
            .setTitle("새 독바 폴더 이름")
            .setView(input)
            .setPositiveButton("만들기") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "앱 폴더" }
                val f = DockPreferences.AppFolder("f_${System.currentTimeMillis()}", name, emptyList())
                DockPreferences.upsertFolder(this, f)
                DrivingAlertService.refreshDock(this)
                showFolderEditor(f)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showFolderEditor(folder: DockPreferences.AppFolder) {
        val apps = listLaunchablePackages()
        val labels = apps.map { it.second }.toTypedArray()
        val checked = BooleanArray(apps.size) { i -> apps[i].first in folder.packages }
        AlertDialog.Builder(this)
            .setTitle("폴더 편집: ${folder.name}")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("저장") { _, _ ->
                val selected = apps.indices.filter { checked[it] }.map { apps[it].first }
                DockPreferences.upsertFolder(this, folder.copy(packages = selected))
                DrivingAlertService.refreshDock(this)
                render()
            }
            .setNeutralButton("폴더 삭제") { _, _ ->
                DockPreferences.deleteFolder(this, folder.id)
                DrivingAlertService.refreshDock(this)
                render()
            }
            .setNegativeButton("취소", null)
            .show()
    }
}
