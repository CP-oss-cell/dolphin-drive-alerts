package com.byd.dolphin.drivealerts.dock

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.content.ComponentName
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.automation.AutoSplitBehaviorEngine
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.ForegroundPolicyAccessibilityService
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors

/**
 * Fixed Bottom-Docked Floating Cockpit Dock Bar Overlay (v0.17.67):
 * - Matches stock DiLink bottom bar size & position (Gravity.BOTTOM | FILL_HORIZONTAL).
 * - Collapse/Expand toggle with translucent floating handle + optional Auto-Collapse timer.
 * - Fixed compact controls:
 *   Collapse, Home, Back, AC ON/OFF, Temp (-/value/+), Fan (-/value/+),
 *   Wind Direction (tap cycles FACE -> FACE+FOOT -> FOOT -> UP+FOOT; long-press picks any),
 *   Recirc/Fresh toggle, Steering Heat, Driver Seat Heat, Passenger Seat Heat,
 *   Side-Mirror + Rear Defrost, Stock Settings, App Drawer,
 *   plus horizontally swipeable Pinned Apps, Popup App Folders (with real app icons),
 *   and user-selected Extra Stock BYD Functions.
 */
class FloatingDockController(
    context: Context,
    private val onDashcamEventLock: (() -> Unit)? = null
) {
    private val app = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val comfort = BydComfortController(app)

    private var dockView: View? = null
    private var collapsedHandle: View? = null
    private var popupOverlay: View? = null

    // Live indicator references inside dock bar
    private var acIconView: ImageView? = null
    private var acLedView: View? = null
    private var tempValueView: TextView? = null
    private var fanValueView: TextView? = null
    private var windIconView: ImageView? = null
    private var windLedView: View? = null
    private var recircIconView: ImageView? = null
    private var recircLedView: View? = null
    private var steerIconView: ImageView? = null
    private var steerLedView: View? = null
    private var driverSeatIcon: ImageView? = null
    private var driverSeatDots: List<View> = emptyList()
    private var passSeatIcon: ImageView? = null
    private var passSeatDots: List<View> = emptyList()
    private var rearDefIconView: ImageView? = null
    private var rearDefLedView: View? = null
    private var drlIconView: ImageView? = null
    private var drlLedView: View? = null

    @Volatile private var collapsed = false
    @Volatile private var attached = false
    @Volatile private var appliedOverscanSpec = ""
    private val overscanExecutor = Executors.newSingleThreadExecutor()
    private var pendingOverscanRunnable: Runnable? = null

    private val autoCollapseRunnable = Runnable {
        if (attached && !collapsed && DockPreferences.autoCollapse(app) && popupOverlay == null) {
            collapse()
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!attached) return
            if (!collapsed) {
                comfort.refreshSnapshot()
                renderComfortIndicators()
            }
            mainHandler.postDelayed(this, 3_000L)
        }
    }

    fun refreshFromPreferences() {
        mainHandler.post {
            if (DockPreferences.enabled(app)) {
                showOrRebuild()
            } else {
                hideAll()
            }
        }
    }

    fun shutdown() {
        mainHandler.post { hideAll() }
    }

    private fun showOrRebuild() {
        if (!Settings.canDrawOverlays(app)) {
            CoreLog.w("DOCK", "SYSTEM_ALERT_WINDOW permission missing")
            return
        }
        hideAll(resetOverscan = false)
        attached = true
        collapsed = false
        attachDockBar()
        syncDockOverscan()
        comfort.refreshSnapshot()
        renderComfortIndicators()
        scheduleAutoCollapse()
        mainHandler.removeCallbacks(pollRunnable)
        mainHandler.postDelayed(pollRunnable, 3_000L)
    }

    private fun hideAll(resetOverscan: Boolean = true) {
        attached = false
        mainHandler.removeCallbacks(autoCollapseRunnable)
        mainHandler.removeCallbacks(pollRunnable)
        pendingOverscanRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingOverscanRunnable = null
        dismissPopup()
        removeWindowView(dockView); dockView = null
        removeWindowView(collapsedHandle); collapsedHandle = null
        if (resetOverscan) clearDockOverscan()
    }

    private fun collapse() {
        dismissPopup()
        collapsed = true
        removeWindowView(dockView); dockView = null
        clearDockOverscan()
        attachCollapsedHandle()
    }

    private fun expand() {
        collapsed = false
        removeWindowView(collapsedHandle); collapsedHandle = null
        attachDockBar()
        syncDockOverscan()
        comfort.refreshSnapshot()
        renderComfortIndicators()
        scheduleAutoCollapse()
    }

    private fun overscanSpecFor(edge: Int, barSizePx: Int): String = when (edge) {
        DockPreferences.EDGE_TOP -> "0,$barSizePx,0,0"
        DockPreferences.EDGE_LEFT -> "$barSizePx,0,0,0"
        DockPreferences.EDGE_RIGHT -> "0,0,$barSizePx,0"
        else -> "0,0,0,$barSizePx"
    }

    /**
     * Reserve screen inset via Android 10 `wm overscan` when dock is expanded so other apps
     * treat the dock like a stock navigation bar and never draw underneath it.
     */
    private fun syncDockOverscan() {
        // Overscan reservation removed per user request: never distort app window bounds
        clearDockOverscan()
        return
        @Suppress("UNREACHABLE_CODE")
        if (!attached || collapsed || !DockPreferences.reserveScreenSpace(app)) {
            clearDockOverscan()
            return
        }
        val edge = DockPreferences.edgePosition(app)
        val barPx = dp(DockPreferences.heightDp(app))
        val targetSpec = overscanSpecFor(edge, barPx)
        val task = Runnable {
            overscanExecutor.execute {
                if (!attached || collapsed || !DockPreferences.reserveScreenSpace(app)) return@execute
                if (appliedOverscanSpec == targetSpec) return@execute
                val report = AuthorizedAdbRuntime.writeOnce(app, "wm overscan $targetSpec")
                if (report.result.success) {
                    appliedOverscanSpec = targetSpec
                    CoreLog.i("DOCK_OVERSCAN", "Applied wm overscan $targetSpec")
                } else {
                    CoreLog.w("DOCK_OVERSCAN", "Failed wm overscan $targetSpec (${report.state})")
                }
            }
        }
        pendingOverscanRunnable = task
        mainHandler.postDelayed(task, 160L)
    }

    private fun clearDockOverscan() {
        pendingOverscanRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingOverscanRunnable = null
        overscanExecutor.execute {
            if (appliedOverscanSpec == "RESET") return@execute
            val report = AuthorizedAdbRuntime.writeOnce(app, "wm overscan reset")
            appliedOverscanSpec = "RESET"
            CoreLog.i("DOCK_OVERSCAN", "Reset wm overscan ok=${report.result.success}")
        }
    }

    private fun scheduleAutoCollapse() {
        mainHandler.removeCallbacks(autoCollapseRunnable)
        if (DockPreferences.autoCollapse(app)) {
            mainHandler.postDelayed(autoCollapseRunnable, DockPreferences.autoCollapseSeconds(app) * 1000L)
        }
    }

    private fun dp(v: Int): Int = (app.resources.displayMetrics.density * v + 0.5f).toInt()

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun edgeRotateDeg(edge: Int): Float = when (edge) {
        DockPreferences.EDGE_TOP -> 180f
        DockPreferences.EDGE_LEFT -> 90f
        DockPreferences.EDGE_RIGHT -> -90f
        else -> 0f
    }

    private fun snapRawTouchToEdge(rawX: Float, rawY: Float): Int {
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels.toFloat().coerceAtLeast(1f)
        val h = dm.heightPixels.toFloat().coerceAtLeast(1f)
        val distLeft = rawX / w
        val distRight = (w - rawX) / w
        val distTop = rawY / h
        val distBottom = (h - rawY) / h
        val minDist = minOf(distLeft, distRight, distTop, distBottom)
        return when (minDist) {
            distTop -> DockPreferences.EDGE_TOP
            distLeft -> DockPreferences.EDGE_LEFT
            distRight -> DockPreferences.EDGE_RIGHT
            else -> DockPreferences.EDGE_BOTTOM
        }
    }

    private fun applySnappedEdge(newEdge: Int) {
        if (newEdge != DockPreferences.edgePosition(app)) {
            DockPreferences.setEdgePosition(app, newEdge)
            Toast.makeText(app, "독바 위치: ${DockPreferences.edgeLabels[newEdge]}", Toast.LENGTH_SHORT).show()
            if (collapsed) {
                removeWindowView(collapsedHandle); collapsedHandle = null
                attachCollapsedHandle()
            } else {
                showOrRebuild()
            }
        }
    }

    private fun attachEdgeDragListener(view: View, onTap: () -> Unit, onLongTap: (() -> Unit)? = null) {
        var downX = 0f
        var downY = 0f
        var dragged = false
        var downTime = 0L
        val slop = dp(24).toFloat()
        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    downTime = System.currentTimeMillis()
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (dx * dx + dy * dy > slop * slop) {
                        dragged = true
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val held = System.currentTimeMillis() - downTime
                    if (dragged) {
                        val targetEdge = snapRawTouchToEdge(ev.rawX, ev.rawY)
                        applySnappedEdge(targetEdge)
                    } else if (held >= 480L && onLongTap != null) {
                        onLongTap()
                    } else {
                        onTap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun showEdgeSnapPopup() {
        dismissPopup()
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val cur = DockPreferences.edgePosition(app)
        val box = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply {
                setColor(0xEA0F172A.toInt())
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0xAA38D9E6.toInt())
            }
        }
        box.addView(TextView(app).apply {
            text = "독바 고정 위치 선택 (상단 · 하단 · 좌측 · 우측)"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, dp(10))
        })
        val row = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("하단바", "상단바", "왼쪽 끝", "오른쪽 끝")
        names.forEachIndexed { idx, label ->
            val active = idx == cur
            row.addView(TextView(app).apply {
                text = if (active) "✓ $label" else label
                gravity = Gravity.CENTER
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                setTextColor(if (active) 0xFF0B1220.toInt() else 0xFFE2E8F0.toInt())
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply {
                    setColor(if (active) 0xFF38D9E6.toInt() else 0xFF1E293B.toInt())
                    cornerRadius = dp(10).toFloat()
                }
                setOnClickListener {
                    dismissPopup()
                    applySnappedEdge(idx)
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        box.addView(row)
        val lp = WindowManager.LayoutParams(
            dp(420), -2, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        box.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE) { dismissPopup(); true } else false
        }
        runCatching { wm.addView(box, lp); popupOverlay = box }
    }

    private fun attachCollapsedHandle() {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val edge = DockPreferences.edgePosition(app)
        val handle = FrameLayout(app).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xCC162238.toInt(), 0xCC0A111F.toInt())
            ).apply {
                cornerRadius = dp(26).toFloat()
                setStroke(dp(2), 0xBB38D9E6.toInt())
            }
            addView(ImageView(app).apply {
                setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.DOCK_HANDLE, 0xFF5EEAD4.toInt(), 30, edgeRotateDeg(edge)))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        }
        attachEdgeDragListener(
            view = handle,
            onTap = { expand() },
            onLongTap = { showEdgeSnapPopup() }
        )
        val lp = WindowManager.LayoutParams(
            dp(60), dp(54), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = when (edge) {
                DockPreferences.EDGE_TOP -> Gravity.TOP or Gravity.START
                DockPreferences.EDGE_LEFT -> Gravity.START or Gravity.CENTER_VERTICAL
                DockPreferences.EDGE_RIGHT -> Gravity.END or Gravity.CENTER_VERTICAL
                else -> Gravity.BOTTOM or Gravity.START
            }
            x = dp(10)
            y = dp(8)
        }
        runCatching {
            wm.addView(handle, lp)
            collapsedHandle = handle
        }.onFailure { CoreLog.w("DOCK", "attachCollapsedHandle failed: ${it.message}") }
    }

    private fun attachDockBar() {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val edge = DockPreferences.edgePosition(app)
        val isVertical = edge == DockPreferences.EDGE_LEFT || edge == DockPreferences.EDGE_RIGHT
        val barSize = dp(DockPreferences.heightDp(app))
        val alphaByte = ((DockPreferences.opacityPercent(app) / 100f) * 255f).toInt().coerceIn(135, 255)
        val bgColor = (alphaByte shl 24) or 0x0B1220

        val root = FrameLayout(app).apply {
            background = GradientDrawable().apply {
                setColor(bgColor)
                setStroke(dp(1), 0x5538D9E6)
            }
        }

        val container = LinearLayout(app).apply {
            orientation = if (isVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = if (isVertical) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else (Gravity.START or Gravity.CENTER_VERTICAL)
            setPadding(dp(6), dp(3), dp(10), dp(3))
        }

        // 1. 접기 (독바 맨 첫번째 고정 — 짧게 탭=접기, 드래그=4방향 엣지 스냅, 길게 누름=4방향 위치 선택)
        val collapseTile = oemIconTile(DockIcons.Kind.COLLAPSE, 0xFF94A3B8.toInt()) { collapse() }.first
        attachEdgeDragListener(
            view = collapseTile,
            onTap = { collapse() },
            onLongTap = { showEdgeSnapPopup() }
        )
        container.addView(collapseTile)

        // 2..15. 사용자 순서 이동 가능 코어 아이템 (기본: 최근앱 → 홈 → 이전 → 공조 → 온도 → 풍량 → 바람 → 외기 → 핸들 → 운전석 → 동승석 → 미러·후방 → 주간등 → 설정 → 앱서랍)
        val order = DockPreferences.dockCoreOrder(app)
        for (key in order) {
            val tile: View? = when (key) {
                "recents" -> oemIconTile(DockIcons.Kind.RECENTS, 0xFFE2E8F0.toInt(), onLongClick = { showReorderPopup(key, "최근앱"); true }) {
                    scheduleAutoCollapse(); performRecents()
                }.first
                "home" -> oemIconTile(DockIcons.Kind.HOME, 0xFFE2E8F0.toInt(), onLongClick = { showReorderPopup(key, "홈"); true }) {
                    scheduleAutoCollapse(); performHome()
                }.first
                "back" -> oemIconTile(DockIcons.Kind.BACK, 0xFFE2E8F0.toInt(), onLongClick = { showReorderPopup(key, "이전"); true }) {
                    scheduleAutoCollapse(); performBack()
                }.first
                "ac" -> {
                    val (t, iv, led) = oemIconTile(
                        DockIcons.Kind.AC, 0xFFCBD5E1.toInt(),
                        onLongClick = { showClimateDetailPopup(); true }
                    ) {
                        scheduleAutoCollapse(); comfort.toggleAcPower(); renderComfortIndicators()
                    }
                    acIconView = iv; acLedView = led; t
                }
                "temp" -> tempStepperGroup(
                    onMinus = { scheduleAutoCollapse(); comfort.adjustTemp(-0.5f); renderComfortIndicators() },
                    onPlus = { scheduleAutoCollapse(); comfort.adjustTemp(0.5f); renderComfortIndicators() },
                    onLongPress = { scheduleAutoCollapse(); launchStockHvac() }
                ) { tv -> tempValueView = tv }
                "fan" -> fanStepperGroup(
                    onMinus = { scheduleAutoCollapse(); comfort.adjustFan(-1); renderComfortIndicators() },
                    onPlus = { scheduleAutoCollapse(); comfort.adjustFan(1); renderComfortIndicators() },
                    onLongPress = { scheduleAutoCollapse(); launchStockHvac() }
                ) { tv -> fanValueView = tv }
                "wind" -> {
                    val (t, iv, led) = oemIconTile(
                        DockIcons.Kind.WIND_FACE, 0xFF38D9E6.toInt(),
                        onLongClick = {
                            scheduleAutoCollapse(); comfort.setWindModeAll(); renderComfortIndicators()
                            Toast.makeText(app, "바람 방향: 전체 (정면+발+유리)", Toast.LENGTH_SHORT).show()
                            true
                        }
                    ) {
                        scheduleAutoCollapse(); comfort.cycleWindModeTap(); renderComfortIndicators()
                    }
                    windIconView = iv; windLedView = led; t
                }
                "recirc" -> {
                    val (t, iv, led) = oemIconTile(DockIcons.Kind.FRESH_AIR, 0xFF93C5FD.toInt(), onLongClick = { showReorderPopup(key, "외기/내기"); true }) {
                        scheduleAutoCollapse(); comfort.toggleRecirculation(); renderComfortIndicators()
                    }
                    recircIconView = iv; recircLedView = led; t
                }
                "steer" -> {
                    val (t, iv, led) = oemIconTile(DockIcons.Kind.STEERING_HEAT, 0xFFCBD5E1.toInt(), onLongClick = { scheduleAutoCollapse(); launchStockSeatHeat(); true }) {
                        scheduleAutoCollapse(); comfort.toggleSteeringHeat(); renderComfortIndicators()
                    }
                    steerIconView = iv; steerLedView = led; t
                }
                "seat_l" -> {
                    val (t, iv, dots) = seatHeatTile(DockIcons.Kind.SEAT_HEAT_L, onLongClick = { scheduleAutoCollapse(); launchStockSeatHeat(); true }) {
                        scheduleAutoCollapse(); comfort.cycleDriverSeatHeat(); renderComfortIndicators()
                    }
                    driverSeatIcon = iv; driverSeatDots = dots; t
                }
                "seat_r" -> {
                    val (t, iv, dots) = seatHeatTile(DockIcons.Kind.SEAT_HEAT_R, onLongClick = { scheduleAutoCollapse(); launchStockSeatHeat(); true }) {
                        scheduleAutoCollapse(); comfort.cyclePassengerSeatHeat(); renderComfortIndicators()
                    }
                    passSeatIcon = iv; passSeatDots = dots; t
                }
                "rear_def" -> {
                    val (t, iv, led) = oemIconTile(DockIcons.Kind.REAR_MIRROR_DEFROST, 0xFFCBD5E1.toInt(), onLongClick = { showReorderPopup(key, "미러·후방 열선"); true }) {
                        scheduleAutoCollapse(); comfort.toggleRearMirrorDefrost(); renderComfortIndicators()
                    }
                    rearDefIconView = iv; rearDefLedView = led; t
                }
                "drl" -> {
                    val (t, iv, led) = oemIconTile(DockIcons.Kind.DRL, 0xFFFBBF24.toInt(), onLongClick = { showReorderPopup(key, "주간주행등"); true }) {
                        scheduleAutoCollapse(); comfort.toggleDrl(); renderComfortIndicators()
                    }
                    drlIconView = iv; drlLedView = led; t
                }
                "screenshot" -> {
                    var shotIv: ImageView? = null
                    val (t, iv, _) = oemIconTile(DockIcons.Kind.SCREENSHOT, 0xFFE2E8F0.toInt(), onLongClick = { showReorderPopup(key, "스크린샷"); true }) {
                        scheduleAutoCollapse()
                        shotIv?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SCREENSHOT, 0xFF38D9E6.toInt(), 36))
                        mainHandler.postDelayed({ shotIv?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SCREENSHOT, 0xFFE2E8F0.toInt(), 36)) }, 420L)
                        captureScreenshot()
                    }
                    shotIv = iv
                    t
                }
                "settings" -> oemIconTile(DockIcons.Kind.SETTINGS, 0xFFE2E8F0.toInt(), onLongClick = {
                    scheduleAutoCollapse(); launchDriveAlertsApp(); true
                }) {
                    scheduleAutoCollapse(); launchStockSettings()
                }.first
                "drawer" -> oemIconTile(DockIcons.Kind.APP_DRAWER, 0xFFE2E8F0.toInt(), onLongClick = { showReorderPopup(key, "앱 서랍"); true }) {
                    showAppDrawerPopup()
                }.first
                else -> null
            }
            if (tile != null) container.addView(tile)
            if (key == "back" || key == "recirc" || key == "drl") {
                container.addView(divider(isVertical))
            }
        }

        // 16. 추가 설치된 앱 (스와이프 스크롤 확장)
        val pinned = DockPreferences.pinnedApps(app)
        if (pinned.isNotEmpty()) {
            container.addView(divider(isVertical))
            for (pkg in pinned) {
                container.addView(installedAppTile(pkg))
            }
        }

        // 17. 사용자 생성 폴더
        val folders = DockPreferences.folders(app)
        if (folders.isNotEmpty()) {
            container.addView(divider(isVertical))
            for (folder in folders) {
                container.addView(folderTile(folder))
            }
        }

        // 18. 선택된 추가 순정 기능들
        val extras = DockPreferences.extraStockActions(app)
        if (extras.isNotEmpty()) {
            container.addView(divider(isVertical))
            for (action in DockPreferences.ExtraStockAction.values()) {
                if (action.key in extras) {
                    container.addView(extraStockTile(action))
                }
            }
        }

        if (isVertical) {
            val sv = ScrollView(app).apply {
                isVerticalScrollBarEnabled = false
                isFillViewport = false
            }
            sv.addView(container, FrameLayout.LayoutParams(-1, -2))
            root.addView(sv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val hsv = HorizontalScrollView(app).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = false
            }
            hsv.addView(container, FrameLayout.LayoutParams(-2, -1))
            root.addView(hsv, FrameLayout.LayoutParams(-1, -1))
        }

        @Suppress("DEPRECATION")
        val dockFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN
        val lp = WindowManager.LayoutParams(
            if (isVertical) barSize else WindowManager.LayoutParams.MATCH_PARENT,
            if (isVertical) WindowManager.LayoutParams.MATCH_PARENT else barSize,
            overlayType(),
            dockFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = when (edge) {
                DockPreferences.EDGE_TOP -> Gravity.TOP or Gravity.START
                DockPreferences.EDGE_LEFT -> Gravity.TOP or Gravity.START
                DockPreferences.EDGE_RIGHT -> Gravity.TOP or Gravity.END
                else -> Gravity.BOTTOM or Gravity.START
            }
            x = 0
            y = 0
        }
        runCatching {
            wm.addView(root, lp)
            dockView = root
        }.onFailure { CoreLog.w("DOCK", "attachDockBar failed: ${it.message}") }
    }

    private fun setLed(led: View?, active: Boolean, activeColor: Int) {
        led ?: return
        led.background = GradientDrawable().apply {
            setColor(if (active) activeColor else 0x00000000)
            cornerRadius = dp(2).toFloat()
        }
    }

    private fun setSeatDots(dots: List<View>, level: Int, activeColor: Int) {
        dots.forEachIndexed { idx, v ->
            v.background = GradientDrawable().apply {
                setColor(if (idx < level) activeColor else 0x3364748B)
                cornerRadius = dp(2).toFloat()
            }
        }
    }

    private fun renderComfortIndicators() {
        val s = comfort.snapshot()
        val onCyan = 0xFF38D9E6.toInt()
        val onHeat = 0xFFFF6B35.toInt()
        val onWarn = 0xFFFFB84D.toInt()
        val onDrl = 0xFFFBBF24.toInt()
        val offGray = 0xFF94A3B8.toInt()
        val iconSz = 34

        acIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.AC, if (s.acOn) onCyan else offGray, iconSz))
        setLed(acLedView, s.acOn, onCyan)

        tempValueView?.text = comfort.formatTempLabel(s.tempC)
        fanValueView?.text = "${s.fanLevel}"

        val wKind = when (s.windMode) {
            BydComfortController.WIND_FACE_FOOT -> DockIcons.Kind.WIND_FACE_FOOT
            BydComfortController.WIND_FOOT -> DockIcons.Kind.WIND_FOOT
            BydComfortController.WIND_DEFROST_FOOT -> DockIcons.Kind.WIND_DEFROST_FOOT
            BydComfortController.WIND_DEFROST -> DockIcons.Kind.WIND_DEFROST
            BydComfortController.WIND_ALL -> DockIcons.Kind.WIND_ALL
            else -> DockIcons.Kind.WIND_FACE
        }
        windIconView?.setImageDrawable(DockIcons.drawable(app, wKind, if (s.acOn) onCyan else offGray, iconSz))
        setLed(windLedView, s.acOn, onCyan)

        recircIconView?.setImageDrawable(
            DockIcons.drawable(app, if (s.recirculation) DockIcons.Kind.RECIRC else DockIcons.Kind.FRESH_AIR,
                if (s.recirculation) onWarn else 0xFF60A5FA.toInt(), iconSz)
        )
        setLed(recircLedView, s.recirculation, onWarn)

        steerIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.STEERING_HEAT, if (s.steeringHeat) onHeat else offGray, iconSz))
        setLed(steerLedView, s.steeringHeat, onHeat)

        driverSeatIcon?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SEAT_HEAT_L, if (s.driverSeatHeat > 0) onHeat else offGray, iconSz))
        setSeatDots(driverSeatDots, s.driverSeatHeat, onHeat)

        passSeatIcon?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.SEAT_HEAT_R, if (s.passengerSeatHeat > 0) onHeat else offGray, iconSz))
        setSeatDots(passSeatDots, s.passengerSeatHeat, onHeat)

        rearDefIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.REAR_MIRROR_DEFROST, if (s.rearMirrorDefrost) onWarn else offGray, iconSz))
        setLed(rearDefLedView, s.rearMirrorDefrost, onWarn)

        drlIconView?.setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.DRL, if (s.drlOn) onDrl else offGray, iconSz))
        setLed(drlLedView, s.drlOn, onDrl)
    }

    private fun divider(vertical: Boolean = false): View = View(app).apply {
        setBackgroundColor(0x3364748B)
        layoutParams = if (vertical) {
            LinearLayout.LayoutParams(dp(34), dp(1)).apply { setMargins(0, dp(4), 0, dp(4)) }
        } else {
            LinearLayout.LayoutParams(dp(1), dp(36)).apply { setMargins(dp(4), 0, dp(4), 0) }
        }
    }

    private fun tactilePillBg(fillColor: Int = 0x16FFFFFF, radiusDp: Int = 12): RippleDrawable {
        val content = GradientDrawable().apply {
            setColor(fillColor)
            cornerRadius = dp(radiusDp).toFloat()
        }
        val mask = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(radiusDp).toFloat()
        }
        return RippleDrawable(ColorStateList.valueOf(0x6638D9E6), content, mask)
    }

    /** Label-free OEM automotive icon tile with 34dp crisp vector icon, tactile press ripple + top LED bar. */
    private fun oemIconTile(
        kind: DockIcons.Kind,
        color: Int,
        onLongClick: (() -> Boolean)? = null,
        onClick: () -> Unit
    ): Triple<View, ImageView, View> {
        val box = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tactilePillBg(0x0EFFFFFF, 12)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            minimumWidth = dp(52)
            layoutParams = LinearLayout.LayoutParams(-2, -1).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            setOnClickListener { v ->
                v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(60L).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80L).start()
                }.start()
                onClick()
            }
            if (onLongClick != null) setOnLongClickListener { onLongClick() }
        }
        val led = View(app).apply {
            background = GradientDrawable().apply {
                setColor(0x00000000)
                cornerRadius = dp(2).toFloat()
            }
        }
        val iv = ImageView(app).apply {
            setImageDrawable(DockIcons.drawable(app, kind, color, 34))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        box.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
        box.addView(led, LinearLayout.LayoutParams(dp(16), dp(3)).apply { topMargin = dp(3) })
        return Triple(box, iv, led)
    }

    /** Label-free OEM 2-stage seat-heater tile (Korean BYD Dolphin: 1단/2단) with 2 glowing LED bars. */
    private fun seatHeatTile(
        kind: DockIcons.Kind,
        onLongClick: (() -> Boolean)? = null,
        onClick: () -> Unit
    ): Triple<View, ImageView, List<View>> {
        val box = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = tactilePillBg(0x0EFFFFFF, 12)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            minimumWidth = dp(52)
            layoutParams = LinearLayout.LayoutParams(-2, -1).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
            setOnClickListener { v ->
                v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(60L).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80L).start()
                }.start()
                onClick()
            }
            if (onLongClick != null) setOnLongClickListener { onLongClick() }
        }
        val iv = ImageView(app).apply {
            setImageDrawable(DockIcons.drawable(app, kind, 0xFF94A3B8.toInt(), 34))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        val dotRow = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val dots = (0 until 2).map {
            View(app).apply {
                background = GradientDrawable().apply {
                    setColor(0x3364748B)
                    cornerRadius = dp(99).toFloat()
                }
            }.also { d ->
                dotRow.addView(d, LinearLayout.LayoutParams(dp(6), dp(6)).apply { setMargins(dp(4), 0, dp(4), 0) })
            }
        }
        box.addView(iv, LinearLayout.LayoutParams(dp(34), dp(34)))
        box.addView(dotRow, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        return Triple(box, iv, dots)
    }

    private fun tempStepperGroup(
        onMinus: () -> Unit,
        onPlus: () -> Unit,
        onLongPress: (() -> Unit)? = null,
        bindValue: (TextView) -> Unit
    ): View {
        val wrap = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF152033.toInt())
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0x3338D9E6)
            }
            setPadding(dp(4), dp(2), dp(4), dp(2))
            layoutParams = LinearLayout.LayoutParams(-2, dp(46)).apply { setMargins(dp(3), 0, dp(3), 0) }
        }
        fun stepBtn(sym: String, col: Int, act: () -> Unit): TextView = TextView(app).apply {
            text = sym
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(col)
            gravity = Gravity.CENTER
            background = tactilePillBg(0x00000000, 8)
            setOnClickListener { act() }
            if (onLongPress != null) setOnLongClickListener { onLongPress(); true }
        }
        if (onLongPress != null) wrap.setOnLongClickListener { onLongPress(); true }
        val valTv = TextView(app).apply {
            text = "--"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(4), 0, dp(4), 0)
            if (onLongPress != null) setOnLongClickListener { onLongPress(); true }
        }
        bindValue(valTv)
        wrap.addView(stepBtn("−", 0xFF38BDF8.toInt(), onMinus), LinearLayout.LayoutParams(dp(30), -1))
        wrap.addView(valTv, LinearLayout.LayoutParams(-2, -2))
        wrap.addView(stepBtn("+", 0xFFFF6B35.toInt(), onPlus), LinearLayout.LayoutParams(dp(30), -1))
        return wrap
    }

    private fun fanStepperGroup(
        onMinus: () -> Unit,
        onPlus: () -> Unit,
        onLongPress: (() -> Unit)? = null,
        bindValue: (TextView) -> Unit
    ): View {
        val wrap = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFF152033.toInt())
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0x3338D9E6)
            }
            setPadding(dp(5), dp(2), dp(5), dp(2))
            layoutParams = LinearLayout.LayoutParams(-2, dp(46)).apply { setMargins(dp(3), 0, dp(3), 0) }
        }
        if (onLongPress != null) wrap.setOnLongClickListener { onLongPress(); true }
        val smallFan = ImageView(app).apply {
            setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.FAN, 0xFF94A3B8.toInt(), 18))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            background = tactilePillBg(0x00000000, 8)
            setOnClickListener { onMinus() }
            if (onLongPress != null) setOnLongClickListener { onLongPress(); true }
        }
        val valTv = TextView(app).apply {
            text = "0"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(6), 0, dp(6), 0)
            if (onLongPress != null) setOnLongClickListener { onLongPress(); true }
        }
        bindValue(valTv)
        val bigFan = ImageView(app).apply {
            setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.FAN, 0xFF38D9E6.toInt(), 26))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            background = tactilePillBg(0x00000000, 8)
            setOnClickListener { onPlus() }
            if (onLongPress != null) setOnLongClickListener { onLongPress(); true }
        }
        wrap.addView(smallFan, LinearLayout.LayoutParams(dp(28), -1))
        wrap.addView(valTv, LinearLayout.LayoutParams(-2, -2))
        wrap.addView(bigFan, LinearLayout.LayoutParams(dp(32), -1))
        return wrap
    }

    private fun installedAppTile(pkg: String): View {
        val pm = app.packageManager
        val appIcon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
        val appName = runCatching {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg.substringAfterLast('.'))
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(54), -1)
            addView(ImageView(app).apply {
                if (appIcon != null) setImageDrawable(appIcon)
                else setImageDrawable(DockIcons.drawable(app, DockIcons.Kind.APP_DRAWER, Color.WHITE, 24))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(28), dp(28)))
            addView(TextView(app).apply {
                text = appName
                textSize = 9.5f
                setTextColor(0xFFE2E8F0.toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            setOnClickListener {
                scheduleAutoCollapse()
                launchPackage(pkg)
            }
        }
    }

    private fun folderTile(folder: DockPreferences.AppFolder): View {
        val pm = app.packageManager
        val miniGrid = GridLayout(app).apply {
            columnCount = 2
            rowCount = 2
            background = GradientDrawable().apply {
                setColor(0xFF1A2840.toInt())
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), 0x8838D9E6.toInt())
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val previewPkgs = folder.packages.take(4)
        for (i in 0 until 4) {
            val iv = ImageView(app).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                val pkg = previewPkgs.getOrNull(i)
                if (pkg != null) {
                    runCatching { pm.getApplicationIcon(pkg) }.getOrNull()?.let { setImageDrawable(it) }
                }
            }
            miniGrid.addView(iv, GridLayout.LayoutParams().apply {
                width = dp(12); height = dp(12)
                setMargins(dp(1), dp(1), dp(1), dp(1))
            })
        }
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(56), -1)
            addView(miniGrid, LinearLayout.LayoutParams(dp(30), dp(30)))
            addView(TextView(app).apply {
                text = folder.name
                textSize = 9.5f
                setTextColor(0xFF38D9E6.toInt())
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            setOnClickListener { showFolderPopup(folder) }
        }
    }

    private fun extraStockTile(action: DockPreferences.ExtraStockAction): View {
        val (kind, shortLabel, color) = when (action) {
            DockPreferences.ExtraStockAction.AC_AUTO -> Triple(DockIcons.Kind.AC_AUTO, "AUTO", 0xFF38D9E6.toInt())
            DockPreferences.ExtraStockAction.FRONT_DEFROST -> Triple(DockIcons.Kind.FRONT_DEFROST, "앞성에", 0xFFFFB84D.toInt())
            DockPreferences.ExtraStockAction.VENTILATE -> Triple(DockIcons.Kind.WINDOW_VENT, "환기", 0xFF60A5FA.toInt())
            DockPreferences.ExtraStockAction.CLOSE_WINDOWS -> Triple(DockIcons.Kind.WINDOW_CLOSE, "창닫기", 0xFF94A3B8.toInt())
            DockPreferences.ExtraStockAction.SUNSHADE_OPEN -> Triple(DockIcons.Kind.SUNSHADE, "썬열기", 0xFF2EE59D.toInt())
            DockPreferences.ExtraStockAction.SUNSHADE_CLOSE -> Triple(DockIcons.Kind.SUNSHADE, "썬닫기", 0xFF94A3B8.toInt())
            DockPreferences.ExtraStockAction.DASHCAM_LOCK -> Triple(DockIcons.Kind.DASHCAM_LOCK, "녹화잠금", 0xFFFF7A7A.toInt())
            DockPreferences.ExtraStockAction.SPLIT_QUICK -> Triple(DockIcons.Kind.SPLIT_QUICK, "분할실행", 0xFFA78BFA.toInt())
            DockPreferences.ExtraStockAction.MEDIA_PLAY_PAUSE -> Triple(DockIcons.Kind.MEDIA_PLAY_PAUSE, "재생/일시정지", 0xFFE2E8F0.toInt())
            DockPreferences.ExtraStockAction.MEDIA_NEXT -> Triple(DockIcons.Kind.MEDIA_NEXT, "다음 곡", 0xFFE2E8F0.toInt())
        }
        return oemIconTile(kind, color, onClick = {
            scheduleAutoCollapse()
            when (action) {
                DockPreferences.ExtraStockAction.AC_AUTO -> { comfort.toggleAcAuto(); renderComfortIndicators() }
                DockPreferences.ExtraStockAction.FRONT_DEFROST -> { comfort.toggleFrontDefrost(); renderComfortIndicators() }
                DockPreferences.ExtraStockAction.VENTILATE -> comfort.ventilateWindows()
                DockPreferences.ExtraStockAction.CLOSE_WINDOWS -> comfort.closeAllWindows()
                DockPreferences.ExtraStockAction.SUNSHADE_OPEN -> comfort.toggleSunshade(true)
                DockPreferences.ExtraStockAction.SUNSHADE_CLOSE -> comfort.toggleSunshade(false)
                DockPreferences.ExtraStockAction.DASHCAM_LOCK -> onDashcamEventLock?.invoke()
                DockPreferences.ExtraStockAction.SPLIT_QUICK -> {
                    val prof = FeatureProfiles.splits(app).firstOrNull()
                    if (prof != null) Thread { AutoSplitBehaviorEngine.launch(app, prof) }.start()
                }
                DockPreferences.ExtraStockAction.MEDIA_PLAY_PAUSE -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                DockPreferences.ExtraStockAction.MEDIA_NEXT -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            }
        }).first
    }

    /** Long-press Climate button: 에어컨(A/C) / 히팅(난방) / 순수 송풍 3가지 핵심 모드 제어. */
    private fun showClimateDetailPopup() {
        showPopupCard("공조 모드 선택 (냉방 · 히팅 · 송풍)", widthDp = 340, maxHeightDp = 240) { body ->
            val s = comfort.snapshot()
            val rows = listOf(
                Triple("에어컨 (A/C 냉방)", s.acCompressorOn) { comfort.toggleAcCompressor() },
                Triple("히팅 (난방 · 따뜻한 바람)", s.heaterOn) { comfort.startHeatingMode() },
                Triple("순수 송풍 모드 (A/C·히터 OFF)", s.acOn && !s.acCompressorOn && !s.heaterOn && !s.acAuto) { comfort.startPureVentilation(s.fanLevel.coerceAtLeast(3)) }
            )
            for ((label, isOn, act) in rows) {
                body.addView(TextView(app).apply {
                    text = if (isOn) "● $label  [ON]" else "○ $label  [OFF]"
                    textSize = 15f
                    setTypeface(typeface, if (isOn) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (isOn) 0xFF38D9E6.toInt() else Color.WHITE)
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    background = GradientDrawable().apply {
                        setColor(if (isOn) 0xFF1A2D46.toInt() else 0xFF131D2E.toInt())
                        cornerRadius = dp(10).toFloat()
                    }
                    setOnClickListener {
                        act()
                        renderComfortIndicators()
                        dismissPopup()
                        scheduleAutoCollapse()
                    }
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
        }
    }

    /** Long-press Wind Direction popup: pick 위(앞유리), 정면, 정면+아래, 아래, 위+아래 directly. */
    private fun showWindPickerPopup() {
        val options = listOf(
            BydComfortController.WIND_DEFROST to "위 (앞유리)",
            BydComfortController.WIND_FACE to "정면",
            BydComfortController.WIND_FACE_FOOT to "정면 + 아래",
            BydComfortController.WIND_FOOT to "아래",
            BydComfortController.WIND_DEFROST_FOOT to "위 + 아래"
        )
        showPopupCard("바람 방향 직접 선택", widthDp = 340, maxHeightDp = 240) { body ->
            val row = LinearLayout(app).apply {
                orientation = LinearLayout.VERTICAL
            }
            for ((mode, label) in options) {
                val active = comfort.snapshot().windMode == mode
                row.addView(TextView(app).apply {
                    text = if (active) "● $label" else label
                    textSize = 15f
                    setTypeface(typeface, if (active) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (active) 0xFF38D9E6.toInt() else Color.WHITE)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    background = GradientDrawable().apply {
                        setColor(if (active) 0xFF1A2D46.toInt() else 0xFF131D2E.toInt())
                        cornerRadius = dp(10).toFloat()
                    }
                    setOnClickListener {
                        comfort.setWindMode(mode)
                        renderComfortIndicators()
                        dismissPopup()
                        scheduleAutoCollapse()
                    }
                }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
            body.addView(row)
        }
    }

    /** Popup folder overlay with live Cols(2~6) x Rows(2~5) & Translucent Opacity controls right inside the popup. */
    private fun showFolderPopup(folder: DockPreferences.AppFolder) {
        val pm = app.packageManager
        val cols = DockPreferences.popupCols(app)
        val rows = DockPreferences.popupRows(app)
        val cellW = 92
        val cellH = 86
        val cardW = (cols * (cellW + 8) + 34).coerceIn(260, 720)
        val bodyMaxH = rows * (cellH + 8) + 8

        showPopupCard("폴더 · ${folder.name}", widthDp = cardW, maxHeightDp = bodyMaxH + 92) { body ->
            // Inline 2(col) x 2(row) & Transparency bar inside the popup itself
            body.addView(buildPopupControlsBar(
                onGridChanged = { showFolderPopup(folder) },
                onOpacityChanged = { showFolderPopup(folder) }
            ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

            if (folder.packages.isEmpty()) {
                body.addView(TextView(app).apply {
                    text = "폴더에 등록된 앱이 없습니다. 독바 설정에서 앱을 추가하세요."
                    textSize = 13.5f
                    setTextColor(0xFF94A3B8.toInt())
                    setPadding(dp(8), dp(14), dp(8), dp(14))
                })
                return@showPopupCard
            }
            val scroll = ScrollView(app)
            val grid = GridLayout(app).apply { columnCount = cols }
            for (pkg in folder.packages) {
                grid.addView(popupAppCell(pm, pkg), GridLayout.LayoutParams().apply {
                    width = dp(cellW); height = dp(cellH)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            scroll.addView(grid)
            body.addView(scroll, LinearLayout.LayoutParams(-1, dp(bodyMaxH).coerceAtMost(dp(440))))
        }
    }

    private fun buildPopupControlsBar(onGridChanged: () -> Unit, onOpacityChanged: () -> Unit): View {
        val cols = DockPreferences.popupCols(app)
        val rows = DockPreferences.popupRows(app)
        val op = DockPreferences.popupOpacityPercent(app)
        val bar = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0x66152033)
                cornerRadius = dp(8).toFloat()
            }
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        fun chipBtn(txt: String, onClick: () -> Unit): TextView = TextView(app).apply {
            text = txt
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF38D9E6.toInt())
            background = GradientDrawable().apply {
                setColor(0x991C2A42.toInt())
                cornerRadius = dp(6).toFloat()
            }
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { onClick() }
        }
        // Cols cycle (2..6) x Rows cycle (2..5)
        bar.addView(chipBtn("가로 ${cols}칸") {
            val next = if (cols >= 6) 2 else cols + 1
            DockPreferences.setPopupCols(app, next)
            onGridChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(TextView(app).apply {
            text = "×"
            textSize = 13f
            setTextColor(0xFF94A3B8.toInt())
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(chipBtn("세로 ${rows}줄") {
            val next = if (rows >= 5) 2 else rows + 1
            DockPreferences.setPopupRows(app, next)
            onGridChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) })

        bar.addView(View(app), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(chipBtn("투명−") {
            DockPreferences.setPopupOpacityPercent(app, (op - 10).coerceAtLeast(40))
            onOpacityChanged()
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(TextView(app).apply {
            text = "${op}%"
            textSize = 12f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
        bar.addView(chipBtn("진하게+") {
            DockPreferences.setPopupOpacityPercent(app, (op + 10).coerceAtMost(100))
            onOpacityChanged()
        })
        return bar
    }

    /** Full installed App Drawer floating overlay with Cols x Rows, Default/Custom Sort, and Long-Press App Info/Uninstall/Move. */
    private fun showAppDrawerPopup() {
        val pm = app.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val alphaApps = runCatching {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .sortedBy { p ->
                    runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() }.getOrDefault(p)
                }
        }.getOrDefault(emptyList())

        val isCustom = DockPreferences.drawerCustomSort(app)
        val savedOrder = DockPreferences.drawerCustomOrder(app)
        val apps = if (isCustom && savedOrder.isNotEmpty()) {
            savedOrder.filter { it in alphaApps } + alphaApps.filterNot { it in savedOrder }
        } else alphaApps

        val cols = DockPreferences.drawerCols(app)
        val rows = DockPreferences.drawerRows(app)
        val widthDp = (cols * 104 + 44).coerceIn(320, 680)
        val gridHeightDp = (rows * 94).coerceIn(190, 420)

        showPopupCard("앱 서랍 (${apps.size}개 · ${cols}×${rows})", widthDp = widthDp, maxHeightDp = gridHeightDp + 110) { body ->
            val ctrl = LinearLayout(app).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(8))
            }
            fun pillBtn(txt: String, active: Boolean = false, onClick: () -> Unit): TextView = TextView(app).apply {
                text = txt; textSize = 12f; setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (active) Color.WHITE else 0xFFCBD5E1.toInt())
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = GradientDrawable().apply {
                    setColor(if (active) 0x4438D9E6 else 0xFF152236.toInt())
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(1), if (active) 0xFF38D9E6.toInt() else 0xFF2E4666.toInt())
                }
                setOnClickListener { onClick() }
            }
            ctrl.addView(pillBtn("가로 ${cols}칸") {
                val next = if (cols >= 6) 2 else cols + 1
                DockPreferences.setDrawerCols(app, next)
                showAppDrawerPopup()
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            ctrl.addView(pillBtn("세로 ${rows}줄") {
                val next = if (rows >= 5) 2 else rows + 1
                DockPreferences.setDrawerRows(app, next)
                showAppDrawerPopup()
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            ctrl.addView(pillBtn(if (isCustom) "정렬: 자유 순서" else "정렬: 기본(이름순)", active = isCustom) {
                DockPreferences.setDrawerCustomSort(app, !isCustom)
                showAppDrawerPopup()
            })
            body.addView(ctrl)

            val scroll = ScrollView(app)
            val grid = GridLayout(app).apply { columnCount = cols }
            for (pkg in apps) {
                val cell = popupAppCell(pm, pkg)
                cell.setOnLongClickListener {
                    showDrawerAppActionPopup(pm, pkg, alphaApps)
                    true
                }
                grid.addView(cell, GridLayout.LayoutParams().apply {
                    width = dp(96); height = dp(86)
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            scroll.addView(grid)
            body.addView(scroll, LinearLayout.LayoutParams(-1, dp(gridHeightDp)))
        }
    }

    private fun showDrawerAppActionPopup(pm: PackageManager, pkg: String, allInstalled: List<String>) {
        val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        showPopupCard("$label 관리", widthDp = 340, maxHeightDp = 280) { body ->
            fun rowBtn(txt: String, col: Int, act: () -> Unit): TextView = TextView(app).apply {
                text = txt; textSize = 14.5f; setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply {
                    setColor(col); cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), 0x557BA0C0)
                }
                setOnClickListener { act() }
            }
            val moveRow = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
            moveRow.addView(rowBtn("◀ 앞으로 이동", 0xFF182942.toInt()) {
                DockPreferences.moveDrawerApp(app, pkg, -1, allInstalled)
                showAppDrawerPopup()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
            moveRow.addView(rowBtn("뒤로 이동 ▶", 0xFF182942.toInt()) {
                DockPreferences.moveDrawerApp(app, pkg, +1, allInstalled)
                showAppDrawerPopup()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
            body.addView(moveRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

            body.addView(rowBtn("앱 정보 열기", 0xFF1A3452.toInt()) {
                dismissPopup()
                runCatching {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    app.startActivity(i)
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

            body.addView(rowBtn("앱 제거 (삭제)", 0xFF4A1D24.toInt()) {
                dismissPopup()
                runCatching {
                    val i = Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:$pkg"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    app.startActivity(i)
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun popupAppCell(pm: PackageManager, pkg: String): View {
        val icon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
        val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        return LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xFF131E30.toInt())
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(4), dp(6), dp(4), dp(4))
            addView(ImageView(app).apply {
                if (icon != null) setImageDrawable(icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(TextView(app).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
            setOnClickListener {
                dismissPopup()
                scheduleAutoCollapse()
                launchPackage(pkg)
            }
        }
    }

    private fun showPopupCard(title: String, widthDp: Int, maxHeightDp: Int, fill: (LinearLayout) -> Unit) {
        dismissPopup()
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val card = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                val popAlpha = ((DockPreferences.popupOpacityPercent(app) / 100f) * 255f).toInt().coerceIn(100, 255)
                setColor((popAlpha shl 24) or 0x0B1220)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(2), 0xFF38D9E6.toInt())
            }
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        val head = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(app).apply {
            text = title
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(app).apply {
            text = "✕"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setOnClickListener { dismissPopup() }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        val body = LinearLayout(app).apply { orientation = LinearLayout.VERTICAL }
        fill(body)
        card.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val backdrop = FrameLayout(app).apply {
            setBackgroundColor(0x33000000)
            setOnClickListener { dismissPopup() }
        }
        card.isClickable = true
        val cardLp = FrameLayout.LayoutParams(dp(widthDp), FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(DockPreferences.heightDp(app) + 14)
        }
        backdrop.addView(card, cardLp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        runCatching {
            wm.addView(backdrop, lp)
            popupOverlay = backdrop
        }.onFailure { CoreLog.w("DOCK", "showPopupCard failed: ${it.message}") }
    }

    private fun dismissPopup() {
        removeWindowView(popupOverlay)
        popupOverlay = null
    }

    private fun performRecents() {
        if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_RECENTS)) return
        Thread { AuthorizedAdbRuntime.writeOnce(app, "input keyevent 187") }.start()
    }

    private fun performHome() {
        if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_HOME)) return
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val ok = runCatching { app.startActivity(homeIntent); true }.getOrDefault(false)
        if (!ok) Thread { AuthorizedAdbRuntime.writeOnce(app, "input keyevent 3") }.start()
    }

    private fun performBack() {
        if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_BACK)) return
        Thread { AuthorizedAdbRuntime.writeOnce(app, "input keyevent 4") }.start()
    }

    private fun coreItemLabel(key: String): String = when (key) {
        "recents" -> "최근앱"
        "home" -> "홈"
        "back" -> "이전"
        "ac" -> "공조"
        "temp" -> "온도"
        "fan" -> "풍량"
        "wind" -> "바람"
        "recirc" -> "외/내기"
        "steer" -> "핸들열선"
        "seat_l" -> "운전열선"
        "seat_r" -> "동승열선"
        "rear_def" -> "미러·후방"
        "drl" -> "주간등"
        "screenshot" -> "스크린샷"
        "settings" -> "설정"
        "drawer" -> "앱서랍"
        else -> key
    }

    /** Hybrid Reorder Popup: supports BOTH 1-tap ◀/▶ arrows AND Drag-and-Drop across all dock items. */
    private fun showReorderPopup(initialKey: String, title: String) {
        showPopupCard("독바 순서 편집 (◀/▶ 또는 드래그 앤 드롭)", widthDp = 620, maxHeightDp = 360) { body ->
            var selectedKey = initialKey
            val order = DockPreferences.dockCoreOrder(app).toMutableList()
            val chipViews = mutableListOf<Pair<String, TextView>>()

            fun btn(txt: String, col: Int, act: () -> Unit): TextView = TextView(app).apply {
                text = txt; textSize = 14f; gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD); setTextColor(Color.WHITE)
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = GradientDrawable().apply { setColor(col); cornerRadius = dp(10).toFloat() }
                setOnClickListener { act() }
            }

            val hintTv = TextView(app).apply {
                text = "선택됨: ${coreItemLabel(selectedKey)}  ·  칩을 꾹 눌러 다른 칸 위로 드래그하거나 ◀/▶ 버튼으로 이동하세요."
                textSize = 12.5f
                setTextColor(0xFF94A3B8.toInt())
                setPadding(0, 0, 0, dp(8))
            }
            body.addView(hintTv)

            val grid = GridLayout(app).apply {
                columnCount = 5
                alignmentMode = GridLayout.ALIGN_BOUNDS
            }

            fun refreshGrid() {
                grid.removeAllViews()
                chipViews.clear()
                hintTv.text = "선택됨: ${coreItemLabel(selectedKey)}  ·  칩을 끌어 다른 위치에 놓거나 ◀/▶ 버튼으로 이동"
                order.forEachIndexed { idx, k ->
                    val isSel = k == selectedKey
                    val chip = TextView(app).apply {
                        text = "${idx + 1}. ${coreItemLabel(k)}"
                        textSize = 12.5f
                        gravity = Gravity.CENTER
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(if (isSel) 0xFF090F1A.toInt() else Color.WHITE)
                        background = GradientDrawable().apply {
                            setColor(if (isSel) 0xFF38D9E6.toInt() else 0xFF1C2C44.toInt())
                            cornerRadius = dp(10).toFloat()
                            setStroke(dp(1), if (isSel) 0xFFFFFFFF.toInt() else 0xFF334155.toInt())
                        }
                        setPadding(dp(6), dp(12), dp(6), dp(12))
                    }
                    chip.setOnTouchListener { v, ev ->
                        when (ev.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                selectedKey = k
                                v.alpha = 0.72f
                                v.scaleX = 1.06f
                                v.scaleY = 1.06f
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                v.translationX = ev.rawX - (v.locationOnScreenCenterX())
                                v.translationY = ev.rawY - (v.locationOnScreenCenterY())
                                true
                            }
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
                                v.translationX = 0f; v.translationY = 0f
                                val rx = ev.rawX; val ry = ev.rawY
                                val target = chipViews.firstOrNull { (tk, tv) ->
                                    tk != k && tv.containsRawPoint(rx, ry)
                                }?.first
                                if (target != null) {
                                    val fromIdx = order.indexOf(k)
                                    val toIdx = order.indexOf(target)
                                    if (fromIdx >= 0 && toIdx >= 0 && fromIdx != toIdx) {
                                        val moved = order.removeAt(fromIdx)
                                        order.add(toIdx, moved)
                                        DockPreferences.setDockCoreOrder(app, order)
                                        showOrRebuild()
                                    }
                                }
                                refreshGrid()
                                true
                            }
                            else -> false
                        }
                    }
                    chipViews.add(k to chip)
                    grid.addView(chip, GridLayout.LayoutParams().apply {
                        width = dp(110); height = dp(46)
                        setMargins(dp(4), dp(4), dp(4), dp(4))
                    })
                }
            }
            refreshGrid()
            body.addView(grid, LinearLayout.LayoutParams(-1, -2))

            val row = LinearLayout(app).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(btn("◀ 왼쪽으로", 0xFF1E3A5F.toInt()) {
                val idx = order.indexOf(selectedKey)
                if (idx > 0) {
                    order.removeAt(idx); order.add(idx - 1, selectedKey)
                    DockPreferences.setDockCoreOrder(app, order)
                    showOrRebuild(); refreshGrid()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            row.addView(btn("오른쪽으로 ▶", 0xFF1E3A5F.toInt()) {
                val idx = order.indexOf(selectedKey)
                if (idx in 0 until order.lastIndex) {
                    order.removeAt(idx); order.add(idx + 1, selectedKey)
                    DockPreferences.setDockCoreOrder(app, order)
                    showOrRebuild(); refreshGrid()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
            row.addView(btn("초기화", 0xFF334155.toInt()) {
                order.clear(); order.addAll(DockPreferences.defaultCoreOrder)
                DockPreferences.setDockCoreOrder(app, order)
                showOrRebuild(); refreshGrid()
            }, LinearLayout.LayoutParams(dp(96), -2))
            body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
    }

    private fun View.locationOnScreenCenterX(): Float {
        val loc = IntArray(2); getLocationOnScreen(loc)
        return loc[0] + width / 2f
    }

    private fun View.locationOnScreenCenterY(): Float {
        val loc = IntArray(2); getLocationOnScreen(loc)
        return loc[1] + height / 2f
    }

    private fun View.containsRawPoint(rx: Float, ry: Float): Boolean {
        val loc = IntArray(2); getLocationOnScreen(loc)
        return rx >= loc[0] && rx <= loc[0] + width && ry >= loc[1] && ry <= loc[1] + height
    }

    private fun launchStockSettings() {
        val candidates = listOf(
            Intent().setComponent(ComponentName("com.byd.carsettings", "com.byd.carsettings.MainActivity")),
            app.packageManager.getLaunchIntentForPackage("com.byd.carsettings"),
            app.packageManager.getLaunchIntentForPackage("com.android.settings"),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in candidates) {
            if (i == null) continue
            val ok = runCatching {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(i)
                true
            }.getOrDefault(false)
            if (ok) return
        }
        Toast.makeText(app, "순정 설정 열기 실패", Toast.LENGTH_SHORT).show()
    }

    private fun launchDriveAlertsApp() {
        val ok = runCatching {
            val i = Intent(app, com.byd.dolphin.drivealerts.ui.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            app.startActivity(i)
            true
        }.getOrDefault(false)
        if (!ok) Toast.makeText(app, "주행 보조 앱 열기 실패", Toast.LENGTH_SHORT).show()
    }

    private fun captureScreenshot() {
        // Priority 1: Android 9+ AccessibilityService GLOBAL_ACTION_TAKE_SCREENSHOT (instant, works without ADB)
        if (Build.VERSION.SDK_INT >= 28) {
            if (ForegroundPolicyAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)) {
                Toast.makeText(app, "스크린샷 캡처 완료", Toast.LENGTH_SHORT).show()
                return
            }
        }
        // Priority 2: Local ADB screencap into /storage/emulated/0/Pictures/Screenshots/
        overscanExecutor.execute {
            val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
            val outPath = "/storage/emulated/0/Pictures/Screenshots/Dolphin_${stamp}.png"
            val cmd = "mkdir -p /storage/emulated/0/Pictures/Screenshots && screencap -p '$outPath' && am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d 'file://$outPath'"
            val res = runCatching { AuthorizedAdbRuntime.writeOnce(app, cmd, 6_000L).result }.getOrNull()
            mainHandler.post {
                if (res?.success == true) {
                    Toast.makeText(app, "스크린샷 저장 완료 (Pictures/Screenshots)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(app, "스크린샷 실패: 접근성 서비스 또는 로컬 ADB 연결을 확인해 주세요.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /**
     * Dynamically discover and launch BYD stock HVAC / Seat-Heat screen (com.byd.hvac has no CATEGORY_LAUNCHER icon
     * on DiLink 5.0, which is why getLaunchIntentForPackage() previously returned null and fell into Settings).
     */
    private fun launchBydHvacInternal(preferSeatTab: Boolean) {
        val pm = app.packageManager
        val hvacPkgs = listOf("com.byd.hvac", "com.byd.aircondition", "com.byd.ac")
        var discoveredComponent: String? = null

        for (pkg in hvacPkgs) {
            val direct = pm.getLaunchIntentForPackage(pkg)
            if (direct != null && !preferSeatTab) {
                val ok = runCatching {
                    direct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    app.startActivity(direct)
                    true
                }.getOrDefault(false)
                if (ok) return
            }
            @Suppress("DEPRECATION")
            val acts = runCatching { pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES).activities }.getOrNull()
                ?.filter { it.enabled } ?: emptyList()
            val ordered = if (preferSeatTab) {
                acts.sortedByDescending { a ->
                    val n = a.name.lowercase()
                    when {
                        "seat" in n || "heat" in n || "comfort" in n -> 3
                        "main" in n || "hvac" in n || "ac" in n -> 2
                        a.exported -> 1
                        else -> 0
                    }
                }
            } else {
                acts.sortedByDescending { a ->
                    val n = a.name.lowercase()
                    when {
                        "main" in n || "hvacactivity" in n || "acactivity" in n -> 3
                        "hvac" in n || "air" in n -> 2
                        a.exported -> 1
                        else -> 0
                    }
                }
            }
            for (act in ordered) {
                if (discoveredComponent == null) discoveredComponent = "${act.packageName}/${act.name}"
                if (!act.exported) continue
                val ok = runCatching {
                    val i = Intent().setComponent(ComponentName(act.packageName, act.name)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (preferSeatTab) {
                            putExtra("tab", "seat")
                            putExtra("page", "seat")
                            putExtra("from", "seat_heat")
                        }
                    }
                    app.startActivity(i)
                    true
                }.getOrDefault(false)
                if (ok) return
            }
        }

        val bcastActions = if (preferSeatTab) {
            listOf("com.byd.hvac.SHOW_SEAT", "com.byd.hvac.SHOW_HVAC", "com.byd.action.SHOW_HVAC")
        } else {
            listOf("com.byd.hvac.SHOW_HVAC", "com.byd.action.SHOW_HVAC")
        }
        for (actName in bcastActions) {
            runCatching { app.sendBroadcast(Intent(actName).setPackage("com.byd.hvac")) }
        }
        val targetComp = discoveredComponent ?: "com.byd.hvac/.MainActivity"
        overscanExecutor.execute {
            val extra = if (preferSeatTab) " --es tab seat --es page seat" else ""
            val res = runCatching {
                AuthorizedAdbRuntime.writeOnce(app, "am start --user 0 -n '$targetComp'$extra", 5_000L).result
            }.getOrNull()
            if (res?.success != true) {
                mainHandler.post {
                    Toast.makeText(
                        app,
                        if (preferSeatTab) "순정 공조·열선 화면(com.byd.hvac) 열기 실패 — 로컬 ADB 연결을 확인해 주세요."
                        else "순정 공조 화면(com.byd.hvac) 열기 실패 — 로컬 ADB 연결을 확인해 주세요.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun launchStockHvac() = launchBydHvacInternal(preferSeatTab = false)

    private fun launchStockSeatHeat() = launchBydHvacInternal(preferSeatTab = true)

    private fun dispatchMediaKey(keyCode: Int) {
        runCatching {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
            val now = android.os.SystemClock.uptimeMillis()
            am.dispatchMediaKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, keyCode, 0))
            am.dispatchMediaKeyEvent(android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_UP, keyCode, 0))
        }
    }

    private fun launchPackage(pkg: String) {
        val intent = app.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent != null) {
            runCatching { app.startActivity(intent) }
        }
    }

    private fun removeWindowView(v: View?) {
        if (v == null) return
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        runCatching { wm.removeViewImmediate(v) }
    }
}
