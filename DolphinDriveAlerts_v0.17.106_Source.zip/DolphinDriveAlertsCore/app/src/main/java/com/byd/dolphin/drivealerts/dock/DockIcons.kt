package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import com.byd.dolphin.drivealerts.R

/**
 * High-Visibility Automotive Cockpit Vector Icon Kit (v0.17.82).
 * Designed so every single function is unmistakable in <0.25s even WITHOUT text labels:
 * - AC (공조 ON/OFF): Bold Power-Ring (⏻) with soft halo — completely distinct from AC_AUTO.
 * - AC_AUTO (AUTO 공조): Rounded badge with bold "AUTO" emblem + circulation arc.
 * - DRL (주간주행등): Iconic headlamp lens + 3 crisp sunburst rays.
 * - WIND_ALL (전체 방향): Seated silhouette + simultaneous Up / Face / Foot arrows.
 * - DOCK_HANDLE (프리미엄 접기 핸들): Layered futuristic dual-chevron cockpit emblem.
 */
object DockIcons {
    enum class Kind {
        COLLAPSE,
        EXPAND,
        DOCK_HANDLE,
        RECENTS,
        HOME,
        BACK,
        AC,
        AC_AUTO,
        FAN,
        WIND_FACE,
        WIND_FACE_FOOT,
        WIND_FOOT,
        WIND_DEFROST_FOOT,
        WIND_DEFROST,
        WIND_ALL,
        RECIRC,
        FRESH_AIR,
        STEERING_HEAT,
        SEAT_HEAT_L,
        SEAT_HEAT_R,
        REAR_MIRROR_DEFROST,
        FRONT_DEFROST,
        DRL,
        SETTINGS,
        APP_DRAWER,
        FOLDER,
        WINDOW_VENT,
        WINDOW_CLOSE,
        SUNSHADE,
        DASHCAM_LOCK,
        SPLIT_QUICK,
        SCREENSHOT,
        MEDIA_PLAY_PAUSE,
        MEDIA_NEXT
    }

    private fun isLuminousActive(color: Int): Boolean {
        val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
        val maxC = maxOf(r, g, b); val minC = minOf(r, g, b)
        // Neutral silver/gray/white has low saturation; cyan/amber/gold active colors have high chroma
        return (maxC - minC) >= 55
    }

    private fun conceptAResId(kind: Kind, active: Boolean): Int = when (kind) {
        Kind.COLLAPSE -> R.drawable.ic_dock_collapse_off
        Kind.BACK -> R.drawable.ic_dock_back_off
        Kind.HOME -> if (active) R.drawable.ic_dock_home_on else R.drawable.ic_dock_home_off
        Kind.RECENTS -> R.drawable.ic_dock_recents_off
        Kind.AC -> if (active) R.drawable.ic_dock_ac_on else R.drawable.ic_dock_ac_off
        Kind.FAN -> if (active) R.drawable.ic_dock_fan_on else R.drawable.ic_dock_fan_off
        Kind.WIND_FACE -> if (active) R.drawable.ic_dock_wind_face_on else R.drawable.ic_dock_wind_face_off
        Kind.WIND_FACE_FOOT -> R.drawable.ic_dock_wind_face_foot_on
        Kind.WIND_FOOT -> R.drawable.ic_dock_wind_foot_on
        Kind.WIND_DEFROST -> R.drawable.ic_dock_wind_defrost_on
        Kind.WIND_DEFROST_FOOT -> R.drawable.ic_dock_wind_def_foot_on
        Kind.WIND_ALL -> R.drawable.ic_dock_wind_all_on
        Kind.RECIRC -> if (active) R.drawable.ic_dock_recirc_on else R.drawable.ic_dock_recirc_off
        Kind.FRESH_AIR -> if (active) R.drawable.ic_dock_fresh_on else R.drawable.ic_dock_fresh_off
        Kind.STEERING_HEAT -> if (active) R.drawable.ic_dock_steer_heat_on else R.drawable.ic_dock_steer_heat_off
        Kind.SEAT_HEAT_L -> if (active) R.drawable.ic_dock_seat_l_on else R.drawable.ic_dock_seat_l_off
        Kind.SEAT_HEAT_R -> if (active) R.drawable.ic_dock_seat_r_on else R.drawable.ic_dock_seat_r_off
        Kind.REAR_MIRROR_DEFROST -> if (active) R.drawable.ic_dock_rear_defrost_on else R.drawable.ic_dock_rear_defrost_off
        Kind.DRL -> if (active) R.drawable.ic_dock_drl_on else R.drawable.ic_dock_drl_off
        Kind.SETTINGS -> R.drawable.ic_dock_settings_off
        Kind.APP_DRAWER -> if (active) R.drawable.ic_dock_drawer_on else R.drawable.ic_dock_drawer_off
        Kind.SCREENSHOT -> if (active) R.drawable.ic_dock_screenshot_on else R.drawable.ic_dock_screenshot_off
        Kind.MEDIA_PLAY_PAUSE -> R.drawable.ic_dock_media_play_off
        Kind.MEDIA_NEXT -> R.drawable.ic_dock_media_next_off
        else -> 0
    }

    fun drawable(context: Context, kind: Kind, color: Int, sizeDp: Int = 28, rotateDeg: Float = 0f): Drawable {
        val d = context.resources.displayMetrics.density
        val sizePx = (d * sizeDp + 0.5f).toInt().coerceAtLeast(22)
        if (rotateDeg == 0f) {
            val resId = conceptAResId(kind, isLuminousActive(color))
            if (resId != 0) {
                val bmpDrw = runCatching {
                    @Suppress("DEPRECATION")
                    val raw = context.resources.getDrawable(resId, null) as? BitmapDrawable
                    raw?.bitmap?.let { b ->
                        val scaled = Bitmap.createScaledBitmap(b, sizePx, sizePx, true)
                        BitmapDrawable(context.resources, scaled)
                    }
                }.getOrNull()
                if (bmpDrw != null) return bmpDrw
            }
        }
        return DockIconDrawable(
            kind = kind,
            color = color,
            sizePx = sizePx,
            strokePx = (d * 2.4f).coerceAtLeast(2.1f),
            rotateDeg = rotateDeg
        )
    }

    private class DockIconDrawable(
        private val kind: Kind,
        private val color: Int,
        private val sizePx: Int,
        private val strokePx: Float,
        private val rotateDeg: Float
    ) : Drawable() {
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = this@DockIconDrawable.color
        }
        private val boldStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx * 1.25f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            color = this@DockIconDrawable.color
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = this@DockIconDrawable.color
        }
        private val softFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(48, Color.red(this@DockIconDrawable.color), Color.green(this@DockIconDrawable.color), Color.blue(this@DockIconDrawable.color))
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = this@DockIconDrawable.color
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        override fun getIntrinsicWidth(): Int = sizePx
        override fun getIntrinsicHeight(): Int = sizePx

        override fun draw(canvas: Canvas) {
            val b = bounds
            val w = b.width().toFloat().coerceAtLeast(1f)
            val h = b.height().toFloat().coerceAtLeast(1f)
            val s = minOf(w, h)
            val cx = b.exactCenterX()
            val cy = b.exactCenterY()
            val r = s * 0.43f

            if (rotateDeg != 0f) {
                canvas.save()
                canvas.rotate(rotateDeg, cx, cy)
            }

            when (kind) {
                Kind.COLLAPSE -> {
                    // Sleek double-chevron down + dock bar base
                    val p1 = Path().apply {
                        moveTo(cx - r * 0.65f, cy - r * 0.45f)
                        lineTo(cx, cy + r * 0.12f)
                        lineTo(cx + r * 0.65f, cy - r * 0.45f)
                    }
                    val p2 = Path().apply {
                        moveTo(cx - r * 0.48f, cy + r * 0.02f)
                        lineTo(cx, cy + r * 0.46f)
                        lineTo(cx + r * 0.48f, cy + r * 0.02f)
                    }
                    canvas.drawPath(p1, stroke)
                    canvas.drawPath(p2, boldStroke)
                    canvas.drawRoundRect(RectF(cx - r * 0.68f, cy + r * 0.68f, cx + r * 0.68f, cy + r * 0.86f), r * 0.1f, r * 0.1f, fill)
                }
                Kind.EXPAND -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.68f, cy + r * 0.36f)
                        lineTo(cx, cy - r * 0.34f)
                        lineTo(cx + r * 0.68f, cy + r * 0.36f)
                    }
                    canvas.drawPath(p, boldStroke)
                    canvas.drawRoundRect(RectF(cx - r * 0.65f, cy - r * 0.78f, cx + r * 0.65f, cy - r * 0.6f), r * 0.1f, r * 0.1f, fill)
                }
                Kind.DOCK_HANDLE -> {
                    // Premium cockpit emblem: translucent halo ring + twin wing chevrons + glowing diamond core
                    canvas.drawCircle(cx, cy, r * 0.88f, softFill)
                    canvas.drawArc(RectF(cx - r * 0.86f, cy - r * 0.86f, cx + r * 0.86f, cy + r * 0.86f), 205f, 130f, false, boldStroke)
                    canvas.drawArc(RectF(cx - r * 0.86f, cy - r * 0.86f, cx + r * 0.86f, cy + r * 0.86f), 25f, 130f, false, stroke)
                    val topWing = Path().apply {
                        moveTo(cx - r * 0.50f, cy + r * 0.05f)
                        lineTo(cx, cy - r * 0.44f)
                        lineTo(cx + r * 0.50f, cy + r * 0.05f)
                    }
                    canvas.drawPath(topWing, boldStroke)
                    val core = Path().apply {
                        moveTo(cx, cy + r * 0.04f)
                        lineTo(cx + r * 0.24f, cy + r * 0.28f)
                        lineTo(cx, cy + r * 0.52f)
                        lineTo(cx - r * 0.24f, cy + r * 0.28f)
                        close()
                    }
                    canvas.drawPath(core, fill)
                }
                Kind.RECENTS -> {
                    // Classic Android/Galaxy 3 vertical bars (|||) — unmistakable without text
                    val span = r * 0.50f
                    val halfH = r * 0.66f
                    canvas.drawLine(cx - span, cy - halfH, cx - span, cy + halfH, boldStroke)
                    canvas.drawLine(cx, cy - halfH, cx, cy + halfH, boldStroke)
                    canvas.drawLine(cx + span, cy - halfH, cx + span, cy + halfH, boldStroke)
                }
                Kind.HOME -> {
                    // Crisp OEM Material rounded house silhouette
                    val house = Path().apply {
                        moveTo(cx, cy - r * 0.78f)
                        lineTo(cx + r * 0.76f, cy - r * 0.10f)
                        lineTo(cx + r * 0.60f, cy - r * 0.10f)
                        lineTo(cx + r * 0.60f, cy + r * 0.72f)
                        lineTo(cx + r * 0.18f, cy + r * 0.72f)
                        lineTo(cx + r * 0.18f, cy + r * 0.24f)
                        lineTo(cx - r * 0.18f, cy + r * 0.24f)
                        lineTo(cx - r * 0.18f, cy + r * 0.72f)
                        lineTo(cx - r * 0.60f, cy + r * 0.72f)
                        lineTo(cx - r * 0.60f, cy - r * 0.10f)
                        lineTo(cx - r * 0.76f, cy - r * 0.10f)
                        close()
                    }
                    canvas.drawPath(house, softFill)
                    canvas.drawPath(house, boldStroke)
                }
                Kind.BACK -> {
                    // Classic curved return arrow (↵) — smooth arc down-left with crisp arrowhead
                    val p = Path().apply {
                        moveTo(cx + r * 0.56f, cy - r * 0.54f)
                        lineTo(cx + r * 0.56f, cy - r * 0.06f)
                        quadTo(cx + r * 0.56f, cy + r * 0.40f, cx + r * 0.06f, cy + r * 0.40f)
                        lineTo(cx - r * 0.58f, cy + r * 0.40f)
                    }
                    canvas.drawPath(p, boldStroke)
                    drawArrowLeftHead(canvas, cx - r * 0.60f, cy + r * 0.40f, r * 0.30f)
                }
                Kind.AC -> {
                    // Unmistakable HVAC Power Symbol (⏻) with soft halo — distinct from AUTO
                    canvas.drawCircle(cx, cy, r * 0.84f, softFill)
                    val arc = RectF(cx - r * 0.72f, cy - r * 0.68f, cx + r * 0.72f, cy + r * 0.76f)
                    canvas.drawArc(arc, -52f, 284f, false, boldStroke)
                    canvas.drawLine(cx, cy - r * 0.88f, cx, cy - r * 0.02f, boldStroke)
                }
                Kind.AC_AUTO -> {
                    // Unmistakable AUTO climate badge: rounded pill + crisp "AUTO" text + curved auto-arc
                    val pill = RectF(cx - r * 0.92f, cy - r * 0.54f, cx + r * 0.92f, cy + r * 0.54f)
                    canvas.drawRoundRect(pill, r * 0.28f, r * 0.28f, softFill)
                    canvas.drawRoundRect(pill, r * 0.28f, r * 0.28f, stroke)
                    textPaint.textSize = s * 0.27f
                    val fm = textPaint.fontMetrics
                    val ty = cy - (fm.ascent + fm.descent) * 0.5f
                    canvas.drawText("AUTO", cx, ty, textPaint)
                }
                Kind.FAN -> {
                    // Classic 4-blade OEM automotive blower fan
                    canvas.drawCircle(cx, cy, r * 0.18f, fill)
                    for (deg in listOf(0f, 90f, 180f, 270f)) {
                        canvas.save()
                        canvas.rotate(deg, cx, cy)
                        val blade = Path().apply {
                            moveTo(cx, cy - r * 0.16f)
                            quadTo(cx - r * 0.36f, cy - r * 0.72f, cx + r * 0.08f, cy - r * 0.88f)
                            quadTo(cx + r * 0.46f, cy - r * 0.74f, cx + r * 0.16f, cy - r * 0.18f)
                            close()
                        }
                        canvas.drawPath(blade, softFill)
                        canvas.drawPath(blade, stroke)
                        canvas.restore()
                    }
                }
                Kind.WIND_FACE, Kind.WIND_FACE_FOOT, Kind.WIND_FOOT, Kind.WIND_DEFROST_FOOT, Kind.WIND_DEFROST, Kind.WIND_ALL -> {
                    // Bold seated passenger silhouette + unmistakable directional arrows
                    canvas.drawCircle(cx + r * 0.42f, cy - r * 0.52f, r * 0.24f, fill)
                    val seat = Path().apply {
                        moveTo(cx + r * 0.48f, cy - r * 0.16f)
                        lineTo(cx + r * 0.20f, cy + r * 0.34f)
                        lineTo(cx - r * 0.26f, cy + r * 0.34f)
                        lineTo(cx - r * 0.40f, cy + r * 0.80f)
                    }
                    canvas.drawPath(seat, boldStroke)
                    if (kind == Kind.WIND_FACE || kind == Kind.WIND_FACE_FOOT || kind == Kind.WIND_ALL) {
                        drawArrowRight(canvas, cx - r * 0.92f, cy - r * 0.14f, cx - r * 0.08f, cy - r * 0.14f, r * 0.22f)
                    }
                    if (kind == Kind.WIND_FOOT || kind == Kind.WIND_FACE_FOOT || kind == Kind.WIND_DEFROST_FOOT || kind == Kind.WIND_ALL) {
                        drawArrowDown(canvas, cx - r * 0.68f, cy + r * 0.18f, cx - r * 0.68f, cy + r * 0.82f, r * 0.22f)
                    }
                    if (kind == Kind.WIND_DEFROST || kind == Kind.WIND_DEFROST_FOOT || kind == Kind.WIND_ALL) {
                        drawArrowUp(canvas, cx - r * 0.68f, cy - r * 0.24f, cx - r * 0.68f, cy - r * 0.86f, r * 0.22f)
                    }
                }
                Kind.RECIRC -> {
                    // Car side silhouette + bold U-turn cabin arrow
                    drawCarSilhouette(canvas, cx, cy, r)
                    val arc = RectF(cx - r * 0.38f, cy - r * 0.18f, cx + r * 0.38f, cy + r * 0.32f)
                    canvas.drawArc(arc, -150f, 270f, false, boldStroke)
                    drawArrowLeftHead(canvas, cx - r * 0.34f, cy - r * 0.04f, r * 0.18f)
                }
                Kind.FRESH_AIR -> {
                    drawCarSilhouette(canvas, cx, cy, r)
                    drawArrowRight(canvas, cx - r * 0.92f, cy - r * 0.78f, cx + r * 0.26f, cy + r * 0.14f, r * 0.22f)
                }
                Kind.STEERING_HEAT -> {
                    // Steering wheel + 3 bold heat waves on top
                    canvas.drawCircle(cx, cy + r * 0.16f, r * 0.66f, softFill)
                    canvas.drawCircle(cx, cy + r * 0.16f, r * 0.66f, boldStroke)
                    canvas.drawCircle(cx, cy + r * 0.16f, r * 0.18f, fill)
                    canvas.drawLine(cx - r * 0.62f, cy + r * 0.16f, cx + r * 0.62f, cy + r * 0.16f, stroke)
                    canvas.drawLine(cx, cy + r * 0.16f, cx, cy + r * 0.78f, stroke)
                    drawHeatWaves(canvas, cx, cy - r * 0.68f, r * 0.44f, r * 0.28f)
                }
                Kind.SEAT_HEAT_L, Kind.SEAT_HEAT_R -> {
                    val dir = if (kind == Kind.SEAT_HEAT_L) 1f else -1f
                    // Headrest + bold L-shaped seat cushion + 3 rising heat waves
                    canvas.drawCircle(cx - dir * r * 0.50f, cy - r * 0.68f, r * 0.16f, fill)
                    val seat = Path().apply {
                        moveTo(cx - dir * r * 0.48f, cy - r * 0.42f)
                        lineTo(cx - dir * r * 0.20f, cy + r * 0.50f)
                        lineTo(cx + dir * r * 0.66f, cy + r * 0.50f)
                    }
                    canvas.drawPath(seat, boldStroke)
                    drawHeatWaves(canvas, cx + dir * r * 0.24f, cy - r * 0.12f, r * 0.46f, r * 0.36f)
                }
                Kind.REAR_MIRROR_DEFROST -> {
                    val glass = RectF(cx - r * 0.86f, cy - r * 0.50f, cx + r * 0.86f, cy + r * 0.52f)
                    canvas.drawRoundRect(glass, r * 0.18f, r * 0.18f, softFill)
                    canvas.drawRoundRect(glass, r * 0.18f, r * 0.18f, boldStroke)
                    drawHeatWaves(canvas, cx, cy + r * 0.02f, r * 0.58f, r * 0.46f)
                }
                Kind.FRONT_DEFROST -> {
                    val ws = Path().apply {
                        moveTo(cx - r * 0.84f, cy + r * 0.38f)
                        lineTo(cx - r * 0.52f, cy - r * 0.54f)
                        quadTo(cx, cy - r * 0.74f, cx + r * 0.52f, cy - r * 0.54f)
                        lineTo(cx + r * 0.84f, cy + r * 0.38f)
                        quadTo(cx, cy + r * 0.18f, cx - r * 0.84f, cy + r * 0.38f)
                        close()
                    }
                    canvas.drawPath(ws, softFill)
                    canvas.drawPath(ws, boldStroke)
                    drawHeatWaves(canvas, cx, cy + r * 0.12f, r * 0.52f, r * 0.44f)
                }
                Kind.DRL -> {
                    // Iconic automotive Daytime Running Light: D-shaped lamp housing + 3 crisp forward rays + sun glow
                    val lamp = Path().apply {
                        moveTo(cx + r * 0.02f, cy - r * 0.56f)
                        arcTo(RectF(cx - r * 0.86f, cy - r * 0.56f, cx + r * 0.22f, cy + r * 0.56f), -90f, -180f, false)
                        close()
                    }
                    canvas.drawPath(lamp, softFill)
                    canvas.drawPath(lamp, boldStroke)
                    // 3 crisp DRL beam rays on right
                    canvas.drawLine(cx + r * 0.30f, cy - r * 0.40f, cx + r * 0.88f, cy - r * 0.52f, boldStroke)
                    canvas.drawLine(cx + r * 0.34f, cy, cx + r * 0.92f, cy, boldStroke)
                    canvas.drawLine(cx + r * 0.30f, cy + r * 0.40f, cx + r * 0.88f, cy + r * 0.52f, boldStroke)
                }
                Kind.SETTINGS -> {
                    canvas.drawCircle(cx, cy, r * 0.56f, softFill)
                    canvas.drawCircle(cx, cy, r * 0.34f, boldStroke)
                    for (deg in 0 until 360 step 45) {
                        canvas.save()
                        canvas.rotate(deg.toFloat(), cx, cy)
                        canvas.drawLine(cx, cy - r * 0.86f, cx, cy - r * 0.56f, boldStroke)
                        canvas.restore()
                    }
                }
                Kind.APP_DRAWER -> {
                    // Crisp OEM 2x2 rounded-square app grid (high visibility at 34dp)
                    val gap = r * 0.14f
                    val box = r * 0.62f
                    val rad = r * 0.18f
                    for (ix in listOf(-1f, 1f)) {
                        for (iy in listOf(-1f, 1f)) {
                            val x0 = if (ix < 0) cx - gap - box else cx + gap
                            val y0 = if (iy < 0) cy - gap - box else cy + gap
                            val rect = RectF(x0, y0, x0 + box, y0 + box)
                            canvas.drawRoundRect(rect, rad, rad, softFill)
                            canvas.drawRoundRect(rect, rad, rad, boldStroke)
                        }
                    }
                }
                Kind.FOLDER -> {
                    val p = Path().apply {
                        moveTo(cx - r * 0.84f, cy - r * 0.60f)
                        lineTo(cx - r * 0.16f, cy - r * 0.60f)
                        lineTo(cx + r * 0.02f, cy - r * 0.36f)
                        lineTo(cx + r * 0.84f, cy - r * 0.36f)
                        lineTo(cx + r * 0.84f, cy + r * 0.64f)
                        lineTo(cx - r * 0.84f, cy + r * 0.64f)
                        close()
                    }
                    canvas.drawPath(p, softFill)
                    canvas.drawPath(p, boldStroke)
                }
                Kind.WINDOW_VENT, Kind.WINDOW_CLOSE -> {
                    val win = Path().apply {
                        moveTo(cx - r * 0.72f, cy + r * 0.64f)
                        lineTo(cx - r * 0.72f, cy - r * 0.08f)
                        lineTo(cx - r * 0.08f, cy - r * 0.66f)
                        lineTo(cx + r * 0.72f, cy - r * 0.66f)
                        lineTo(cx + r * 0.72f, cy + r * 0.64f)
                        close()
                    }
                    canvas.drawPath(win, softFill)
                    canvas.drawPath(win, stroke)
                    if (kind == Kind.WINDOW_VENT) {
                        drawArrowDown(canvas, cx + r * 0.08f, cy - r * 0.32f, cx + r * 0.08f, cy + r * 0.36f, r * 0.22f)
                    } else {
                        drawArrowUp(canvas, cx + r * 0.08f, cy + r * 0.36f, cx + r * 0.08f, cy - r * 0.32f, r * 0.22f)
                    }
                }
                Kind.SUNSHADE -> {
                    val box = RectF(cx - r * 0.82f, cy - r * 0.56f, cx + r * 0.82f, cy + r * 0.56f)
                    canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, softFill)
                    canvas.drawRoundRect(box, r * 0.20f, r * 0.20f, boldStroke)
                    canvas.drawLine(cx - r * 0.82f, cy - r * 0.14f, cx + r * 0.82f, cy - r * 0.14f, stroke)
                    canvas.drawLine(cx - r * 0.82f, cy + r * 0.22f, cx + r * 0.82f, cy + r * 0.22f, stroke)
                }
                Kind.DASHCAM_LOCK -> {
                    val body = RectF(cx - r * 0.84f, cy - r * 0.48f, cx + r * 0.36f, cy + r * 0.48f)
                    canvas.drawRoundRect(body, r * 0.18f, r * 0.18f, softFill)
                    canvas.drawRoundRect(body, r * 0.18f, r * 0.18f, boldStroke)
                    val lens = Path().apply {
                        moveTo(cx + r * 0.38f, cy - r * 0.16f)
                        lineTo(cx + r * 0.86f, cy - r * 0.42f)
                        lineTo(cx + r * 0.86f, cy + r * 0.42f)
                        lineTo(cx + r * 0.38f, cy + r * 0.16f)
                        close()
                    }
                    canvas.drawPath(lens, boldStroke)
                    canvas.drawCircle(cx - r * 0.24f, cy, r * 0.18f, fill)
                }
                Kind.SCREENSHOT, Kind.MEDIA_PLAY_PAUSE, Kind.MEDIA_NEXT -> {
                    canvas.drawCircle(cx, cy, r * 0.42f, stroke)
                }
                Kind.SPLIT_QUICK -> {
                    val outer = RectF(cx - r * 0.84f, cy - r * 0.62f, cx + r * 0.84f, cy + r * 0.62f)
                    canvas.drawRoundRect(outer, r * 0.18f, r * 0.18f, softFill)
                    canvas.drawRoundRect(outer, r * 0.18f, r * 0.18f, boldStroke)
                    canvas.drawLine(cx, cy - r * 0.62f, cx, cy + r * 0.62f, boldStroke)
                }
            }

            if (rotateDeg != 0f) {
                canvas.restore()
            }
        }

        private fun drawCarSilhouette(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            // Sleek OEM side-profile coupe silhouette with wheel arches
            val car = Path().apply {
                moveTo(cx - r * 0.90f, cy + r * 0.44f)
                quadTo(cx - r * 0.92f, cy + r * 0.02f, cx - r * 0.60f, cy - r * 0.06f)
                quadTo(cx - r * 0.34f, cy - r * 0.52f, cx + r * 0.14f, cy - r * 0.50f)
                quadTo(cx + r * 0.56f, cy - r * 0.46f, cx + r * 0.78f, cy - r * 0.02f)
                quadTo(cx + r * 0.94f, cy + r * 0.08f, cx + r * 0.90f, cy + r * 0.44f)
                close()
            }
            canvas.drawPath(car, softFill)
            canvas.drawPath(car, boldStroke)
            canvas.drawCircle(cx - r * 0.52f, cy + r * 0.48f, r * 0.16f, fill)
            canvas.drawCircle(cx + r * 0.52f, cy + r * 0.48f, r * 0.16f, fill)
        }

        private fun drawArrowRight(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, head: Float) {
            canvas.drawLine(x0, y0, x1, y1, boldStroke)
            canvas.drawLine(x1 - head, y1 - head * 0.72f, x1, y1, boldStroke)
            canvas.drawLine(x1 - head, y1 + head * 0.72f, x1, y1, boldStroke)
        }

        private fun drawArrowLeftHead(canvas: Canvas, x: Float, y: Float, head: Float) {
            canvas.drawLine(x + head, y - head * 0.72f, x, y, boldStroke)
            canvas.drawLine(x + head, y + head * 0.72f, x, y, boldStroke)
        }

        private fun drawArrowDown(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, head: Float) {
            canvas.drawLine(x0, y0, x1, y1, boldStroke)
            canvas.drawLine(x1 - head * 0.72f, y1 - head, x1, y1, boldStroke)
            canvas.drawLine(x1 + head * 0.72f, y1 - head, x1, y1, boldStroke)
        }

        private fun drawArrowUp(canvas: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, head: Float) {
            canvas.drawLine(x0, y0, x1, y1, boldStroke)
            canvas.drawLine(x1 - head * 0.72f, y1 + head, x1, y1, boldStroke)
            canvas.drawLine(x1 + head * 0.72f, y1 + head, x1, y1, boldStroke)
        }

        private fun drawHeatWaves(canvas: Canvas, cx: Float, cy: Float, spanX: Float, heightY: Float) {
            for (i in -1..1) {
                val wx = cx + i * (spanX * 0.52f)
                val p = Path().apply {
                    moveTo(wx, cy + heightY * 0.55f)
                    quadTo(wx - spanX * 0.16f, cy + heightY * 0.15f, wx, cy - heightY * 0.05f)
                    quadTo(wx + spanX * 0.16f, cy - heightY * 0.35f, wx, cy - heightY * 0.65f)
                }
                canvas.drawPath(p, stroke)
            }
        }

        override fun setAlpha(alpha: Int) {
            stroke.alpha = alpha
            boldStroke.alpha = alpha
            fill.alpha = alpha
            textPaint.alpha = alpha
        }
        override fun setColorFilter(colorFilter: ColorFilter?) {
            stroke.colorFilter = colorFilter
            boldStroke.colorFilter = colorFilter
            fill.colorFilter = colorFilter
            textPaint.colorFilter = colorFilter
        }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}
