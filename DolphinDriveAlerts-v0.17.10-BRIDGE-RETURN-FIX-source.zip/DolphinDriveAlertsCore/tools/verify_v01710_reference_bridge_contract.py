#!/usr/bin/env python3
"""Fast independent preflight: check non-Unit OEM bridge's explicit return before expensive voice/SDK setup."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
service = (root/'app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt').read_text()
pattern = re.compile(r'private\s+fun\s+createReferenceBridge\([^)]*\):\s*Any\s*\{',re.S)
found = pattern.search(service)
assert found, 'createReferenceBridge function missing or signature altered; review preflight'
# Match the entire body, including nested lambda/if blocks.
opening = service.index('{', found.start())
depth = 0
ending = None
for i in range(opening, len(service)):
    if service[i] == '{': depth += 1
    elif service[i] == '}':
        depth -= 1
        if depth == 0:
            ending = i
            break
assert ending is not None
body = service[opening+1:ending]
assert re.search(r'\breturn\s+ctor\.newInstance\s*\(',body), 'non-Unit createReferenceBridge function missing explicit return (v0.17.9 CI failure)'
assert 'c.getMethod("start").invoke(it)' in body, 'Reference bridge start semantics changed'
gradle = (root/'app/build.gradle.kts').read_text()
assert 'versionCode = 36' in gradle and 'versionName = "0.17.10-oem-bridge-compile-fix"' in gradle
print('PASS v0.17.10 bridge return contract and version')
