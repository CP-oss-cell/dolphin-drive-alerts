package com.mideumhana.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.os.Build;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.view.ViewGroup;
import java.util.HashSet;
import java.util.Set;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONTokener;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * A clean-room implementation: browser + video detection + downloads.
 * No advertising, analytics, bundled player, or third-party dependencies.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com/";
    private static final int FOLDER_PICKER = 6601;
    private String scanScript = "";
    private String pendingUrl;
    private String pendingName;
    // Each tab owns its browser history, candidates and navigation epoch.
    private static final class BrowserTab {
        final WebView web;
        final LinkedHashMap<String, VideoCandidate> candidates = new LinkedHashMap<>();
        volatile long epoch = 0;
        volatile long lastPinchAt = 0;
        String lastScannedPage = "";
        BrowserTab(WebView view) { this.web = view; }
    }
    private final CopyOnWriteArrayList<BrowserTab> webTabs = new CopyOnWriteArrayList<>();
    private final Map<WebView, BrowserTab> tabLookup = new ConcurrentHashMap<>();
    private volatile BrowserTab activeTab;
    private FrameLayout webContainer;
    private LinearLayout webTabStrip;
    private TextView dashboardStatus;
    private Button openTabs;
    private static final int MAX_WEB_TABS = 8;
    private static final String BROWSER_PREFS = "mideumhana_browser_ui";
    private static final String PREF_HOME_URL = "homepage";
    private static final String PREF_TABS = "saved_tabs_v3";
    private static final String PREF_SELECTED_TAB = "saved_tab_index_v3";
    private long automaticZoomUntil = 0;
    private final List<DownloadRow> downloadRows = new ArrayList<>();
    private final Set<String> selectedDownloadIds = new HashSet<>();
    private BaseAdapter downloadsAdapter;
    private boolean selectingDownloads = false;
    private View downloadBulkActions;

    private static final class DownloadRow {
        final String id;
        JSONObject entry;
        String status;
        int progress;
        DownloadRow(JSONObject entry, String status, int progress) {
            this.entry = entry; this.id = entry.optString("id");
            this.status = status; this.progress = progress;
        }
        String label() {
            String pct = progress > 0 || status.startsWith("완료") ? " · " + progress + "%"
                    : status.startsWith("다운로드 중") ? " · 진행률 계산 중" : "";
            long bytes = entry.optLong("bytes", 0);
            long total = entry.optLong("total", -1);
            long speed = entry.optLong("speed", 0);
            long eta = entry.optLong("eta", -1);
            String details = bytes > 0 ? "\n" + readableSize(bytes) +
                    (total > 0 ? " / " + ("true".equals(entry.optString("estimated")) ? "약 " : "")
                            + readableSize(total) : "") : "";
            if (speed > 0 && status.startsWith("다운로드 중"))
                details += " · " + readableSize(speed) + "/초" +
                    (eta >= 0 ? " · 약 " + readableTime(eta) + " 남음" : "");
            return entry.optString("name") + "\n" + status + pct + details;
        }
    }

    private static String readableSize(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return String.format(Locale.KOREA, "%.1fKB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.KOREA, "%.1fMB", bytes / 1048576.0);
        return String.format(Locale.KOREA, "%.2fGB", bytes / 1073741824.0);
    }
    private static String readableTime(long seconds) {
        return seconds >= 3600 ? (seconds / 3600) + "시간 " + (seconds % 3600 / 60) + "분"
                : seconds >= 60 ? (seconds / 60) + "분 " + (seconds % 60) + "초" : seconds + "초";
    }

    private final Runnable scanTick = new Runnable() {
        @Override public void run() {
            if (browser != null && browser.getVisibility() == View.VISIBLE && !isFinishing()) {
                runScan();
                ui.postDelayed(this, 2500);
            }
        }
    };
    private LinearLayout detectedCard;
    private android.widget.TextView detectedSummary;
    private Button quickDownload;
    private Button moreVideos;
    private Button selectFolder;
    private android.widget.TextView folderLabel;
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private View downloadsPanel;
    private View bookmarksPanel;
    private ListView downloadsList;
    private ListView bookmarksList;
    private Button tabWeb;
    private Button tabDetect;
    private Button tabDownloads;
    private Button tabBookmarks;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
                renderDownloads();
                ui.postDelayed(this, 2000);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        DownloadStore.reconcile(this);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets p = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(p.left, p.top, p.right, p.bottom);
                return insets;
            });
        }
        address = findViewById(R.id.address);
        progress = findViewById(R.id.progress);
        browser = findViewById(R.id.browser);
        webContainer = findViewById(R.id.web_container);
        webTabStrip = findViewById(R.id.web_tab_strip);
        dashboardStatus = findViewById(R.id.dashboard_status);
        openTabs = findViewById(R.id.open_tabs);
        openTabs.setOnClickListener(v -> showTabPicker(false));
        openTabs.setOnLongClickListener(v -> { showTabPicker(true); return true; });
        findViewById(R.id.home).setOnClickListener(v -> { showPanel("web"); browser.loadUrl(homeUrl()); });
        findViewById(R.id.home).setOnLongClickListener(v -> {
            showHomeSettings(); return true;
        });
        findViewById(R.id.fit_page).setOnClickListener(v -> {
            if (browser == null || !MediaDetector.validWebUrl(browser.getUrl())) return;
            browser.setInitialScale(0);
            browser.reload(); // Manual fallback, never auto-reload a playing video.
            toast("현재 웹페이지를 화면 너비에 다시 맞춥니다");
        });
        downloadsPanel = findViewById(R.id.downloads_panel);
        bookmarksPanel = findViewById(R.id.bookmarks_panel);
        downloadsList = findViewById(R.id.downloads_list);
        bookmarksList = findViewById(R.id.bookmarks_list);
        downloadBulkActions = findViewById(R.id.download_bulk_actions);
        installDownloadAdapter();
        findViewById(R.id.select_downloads).setOnClickListener(v -> setDownloadSelection(!selectingDownloads));
        findViewById(R.id.select_all_downloads).setOnClickListener(v -> {
            if (selectedDownloadIds.size() == downloadRows.size()) selectedDownloadIds.clear();
            else { selectedDownloadIds.clear(); for (DownloadRow row : downloadRows) selectedDownloadIds.add(row.id); }
            redrawDownloadSelection();
        });
        findViewById(R.id.stop_downloads).setOnClickListener(v -> performBulk("stop"));
        findViewById(R.id.retry_downloads).setOnClickListener(v -> performBulk("retry"));
        findViewById(R.id.delete_downloads).setOnClickListener(v -> confirmDeleteSelected());
        detectedCard = findViewById(R.id.detected_card);
        detectedSummary = findViewById(R.id.detected_summary);
        quickDownload = findViewById(R.id.quick_download);
        moreVideos = findViewById(R.id.more_videos);
        selectFolder = findViewById(R.id.select_folder);
        folderLabel = findViewById(R.id.folder_label);
        try (InputStream in = getAssets().open("video_scan.js")) {
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            byte[] bytes = new byte[4096];
            int n;
            while ((n = in.read(bytes)) != -1) data.write(bytes, 0, n);
            scanScript = new String(data.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { toast("영상 감지 모듈을 불러오지 못했습니다"); }
        quickDownload.setOnClickListener(v -> {
            VideoCandidate top = bestCandidate();
            if (top != null) offerDownload(top.url, friendlyName(top.url));
            else showVideos();
        });
        moreVideos.setOnClickListener(v -> showVideos());
        findViewById(R.id.quick_folder).setOnClickListener(v -> chooseFolder());
        selectFolder.setOnClickListener(v -> chooseFolder());
        findViewById(R.id.reset_folder).setOnClickListener(v -> {
            StorageTarget.reset(this);
            refreshFolderLabel();
            toast("기본 다운로드 폴더를 사용합니다");
        });
        refreshFolderLabel();
        tabWeb = findViewById(R.id.tab_web);
        tabDetect = findViewById(R.id.tab_detect);
        tabDownloads = findViewById(R.id.tab_downloads);
        tabBookmarks = findViewById(R.id.tab_bookmarks);

        BrowserTab firstTab = registerTab(browser);
        configureBrowser(browser);
        findViewById(R.id.new_web_tab).setOnClickListener(v -> {
            if (webTabs.size() >= MAX_WEB_TABS) { toast("탭은 최대 8개까지 열 수 있습니다"); return; }
            BrowserTab newTab = createWebTab();
            activateTab(newTab);
            newTab.web.loadUrl(homeUrl());
        });
        findViewById(R.id.back).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoBack()) browser.goBack();
        });
        findViewById(R.id.forward).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoForward()) browser.goForward();
        });
        findViewById(R.id.go).setOnClickListener(v -> navigate());
        findViewById(R.id.go).setOnLongClickListener(v -> { browser.reload(); return true; });
        findViewById(R.id.star).setOnClickListener(v -> {
            if (MediaDetector.validWebUrl(browser.getUrl())) {
                Bookmarks.add(this, browser.getTitle(), browser.getUrl());
                toast("즐겨찾기에 저장했습니다");
            }
        });
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate();
                return true;
            }
            return false;
        });
        tabWeb.setOnClickListener(v -> showPanel("web"));
        tabWeb.setOnLongClickListener(v -> { showPanel("web"); browser.loadUrl(homeUrl()); return true; });
        tabDetect.setOnClickListener(v -> {
            showPanel("web");
            runScan();
            ui.postDelayed(this::showVideos, 350);
        });
        tabDownloads.setOnClickListener(v -> showPanel("downloads"));
        tabBookmarks.setOnClickListener(v -> showPanel("bookmarks"));
        findViewById(R.id.reload_downloads).setOnClickListener(v -> renderDownloads());
        findViewById(R.id.open_folder).setOnClickListener(v -> {
            String tree = StorageTarget.selected(this);
            if (!tree.isEmpty()) {
                try {
                    Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(tree));
                    open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(open);
                    return;
                } catch (Exception ignored) { }
            }
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { toast("내 파일 앱에서 저장 위치를 확인하세요"); }
        });
        bookmarksList.setOnItemClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                showPanel("web");
                browser.loadUrl(list.get(position).optString("url"));
            }
        });
        downloadsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= downloadRows.size()) return;
            DownloadRow row = downloadRows.get(position);
            if (selectingDownloads) {
                if (!selectedDownloadIds.add(row.id)) selectedDownloadIds.remove(row.id);
                redrawDownloadSelection();
            } else if (row.status.startsWith("완료")) openCompletedDownload(row.entry);
            else showDownloadActions(row);
        });
        downloadsList.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= downloadRows.size()) return true;
            if (selectingDownloads) {
                selectedDownloadIds.add(downloadRows.get(position).id);
                redrawDownloadSelection();
            } else showDownloadActions(downloadRows.get(position));
            return true;
        });
        bookmarksList.setOnItemLongClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                JSONObject target = list.get(position);
                new AlertDialog.Builder(this).setTitle("즐겨찾기 삭제")
                        .setMessage(target.optString("title"))
                        .setPositiveButton("삭제", (d, w) -> {
                            Bookmarks.remove(this, target.optString("url"));
                            renderBookmarks();
                        }).setNegativeButton("취소", null).show();
            }
            return true;
        });
        if (saved != null && saved.getInt("browser_tabs_count", 0) > 0) {
            int count = Math.min(MAX_WEB_TABS, saved.getInt("browser_tabs_count", 1));
            for (int i = 1; i < count; i++) createWebTab();
            for (int i = 0; i < count; i++) {
                Bundle savedTab = saved.getBundle("browser_tab_" + i);
                if (savedTab != null) {
                    if (webTabs.get(i).web.restoreState(savedTab) == null) {
                        webTabs.get(i).web.loadUrl(savedTab.getString("last_url", HOME));
                    }
                }
            }
            activateTab(webTabs.get(Math.max(0,
                    Math.min(count - 1, saved.getInt("browser_tab_selected", 0)))));
        } else if (!restorePersistedTabs(firstTab)) {
            activateTab(firstTab);
            browser.loadUrl(homeUrl());
        }
        applyAdaptiveWindowLayout();
    }

    /** Persist only tab URLs and selection, never session cookies or WebView internal state. */
    private void persistTabs() {
        JSONArray urls = new JSONArray();
        for (BrowserTab tab : webTabs) {
            String url = tab.web.getUrl();
            if (!MediaDetector.validWebUrl(url)) url = homeUrl();
            urls.put(url);
        }
        getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit()
                .putString(PREF_TABS, urls.toString())
                .putInt(PREF_SELECTED_TAB, Math.max(0, webTabs.indexOf(activeTab)))
                .apply();
    }

    private boolean restorePersistedTabs(BrowserTab first) {
        try {
            JSONArray stored = new JSONArray(getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                    .getString(PREF_TABS, "[]"));
            if (stored.length() <= 0) return false;
            int count = Math.min(MAX_WEB_TABS, stored.length());
            for (int i = 1; i < count; i++) createWebTab();
            for (int i = 0; i < count; i++) {
                String url = stored.optString(i, homeUrl());
                webTabs.get(i).web.loadUrl(MediaDetector.validWebUrl(url) ? url : homeUrl());
            }
            int selected = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                    .getInt(PREF_SELECTED_TAB, 0);
            activateTab(webTabs.get(Math.max(0, Math.min(count - 1, selected))));
            return true;
        } catch (Exception ignored) { return false; }
    }

    private String scaleKey(String page) {
        if (!MediaDetector.validWebUrl(page)) return "";
        String host = Uri.parse(page).getHost();
        return host == null ? "" : "site_scale_" +
                (getResources().getConfiguration().screenWidthDp >= 600 ? "wide_" : "compact_")
                + host.toLowerCase(Locale.ROOT);
    }
    private void restoreSiteZoom(WebView view) {
        String key = scaleKey(view.getUrl());
        if (key.isEmpty()) return;
        float target = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getFloat(key, -1);
        if (target < 0.5f || target > 3f) return;
        view.post(() -> {
            if (isDestroyed() || view.getScale() <= 0) return;
            float factor = target / view.getScale();
            if (factor > 0.5f && factor < 2f && Math.abs(factor - 1f) > 0.05f) {
                automaticZoomUntil = android.os.SystemClock.uptimeMillis() + 750;
                view.zoomBy(factor);
            }
        });
    }

    private String homeUrl() {
        String value = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getString(PREF_HOME_URL, HOME);
        return MediaDetector.validWebUrl(value) ? value : HOME;
    }

    private void saveHome(String url) {
        if (!MediaDetector.validWebUrl(url)) { toast("올바른 홈페이지 주소가 아닙니다"); return; }
        getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit().putString(PREF_HOME_URL, url).apply();
        toast("홈 주소가 설정됐습니다");
    }

    private void showHomeSettings() {
        String[] choices = {"현재 페이지를 홈으로 지정", "홈 주소 직접 입력", "즐겨찾기에서 선택", "기본 Google 홈으로 초기화"};
        new AlertDialog.Builder(this).setTitle("홈페이지 설정")
            .setMessage("현재 홈: " + homeUrl())
            .setItems(choices, (dialog, which) -> {
                if (which == 0) {
                    if (browser != null) saveHome(browser.getUrl());
                } else if (which == 1) {
                    EditText editor = new EditText(this);
                    editor.setSingleLine(true);
                    editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
                    editor.setText(homeUrl());
                    new AlertDialog.Builder(this).setTitle("홈 주소 입력")
                        .setView(editor).setPositiveButton("설정", (d,w) -> {
                            String text = editor.getText().toString().trim();
                            if (!text.contains("://")) text = "https://" + text;
                            saveHome(text);
                        }).setNegativeButton("취소", null).show();
                } else if (which == 2) {
                    List<JSONObject> items = Bookmarks.all(this);
                    if (items.isEmpty()) { toast("즐겨찾기가 없습니다"); return; }
                    String[] titles = new String[items.size()];
                    for (int i = 0; i < items.size(); i++)
                        titles[i] = items.get(i).optString("title") + "\n" + items.get(i).optString("url");
                    new AlertDialog.Builder(this).setTitle("홈으로 지정할 즐겨찾기")
                        .setItems(titles, (d,i) -> saveHome(items.get(i).optString("url")))
                        .setNegativeButton("취소", null).show();
                } else saveHome(HOME);
            }).setNegativeButton("닫기", null).show();
    }

    private void showTabPicker(boolean closeMode) {
        List<BrowserTab> snapshot = new ArrayList<>(webTabs);
        String[] titles = new String[snapshot.size()];
        for (int i = 0; i < snapshot.size(); i++) {
            WebView view = snapshot.get(i).web;
            String title = view.getTitle();
            if (title == null || title.trim().isEmpty()) title = view.getUrl();
            if (title == null || title.trim().isEmpty()) title = "새 탭";
            titles[i] = (snapshot.get(i) == activeTab ? "● " : "○ ") + (i + 1) + ". " + title;
        }
        new AlertDialog.Builder(this).setTitle(closeMode ? "닫을 탭 선택" : "열린 탭 선택")
            .setItems(titles, (d,i) -> {
                if (closeMode) closeWebTab(snapshot.get(i));
                else activateTab(snapshot.get(i));
            })
            .setNeutralButton(closeMode ? "탭 전환" : "탭 닫기", (d,w) -> showTabPicker(!closeMode))
            .setNegativeButton("취소", null).show();
    }

    private BrowserTab registerTab(WebView web) {
        BrowserTab tab = new BrowserTab(web);
        webTabs.add(tab);
        tabLookup.put(web, tab);
        return tab;
    }

    private BrowserTab createWebTab() {
        WebView web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        web.setVisibility(View.GONE);
        webContainer.addView(web);
        BrowserTab tab = registerTab(web);
        configureBrowser(web);
        return tab;
    }

    private void activateTab(BrowserTab tab) {
        if (tab == null || !webTabs.contains(tab)) return;
        if (activeTab != null && activeTab != tab) {
            activeTab.web.onPause();
            activeTab.web.setVisibility(View.GONE);
        }
        activeTab = tab;
        browser = tab.web;
        browser.setVisibility(View.VISIBLE);
        browser.onResume();
        address.setText(browser.getUrl() == null ? "" : browser.getUrl());
        progress.setVisibility(View.GONE);
        showPanel("web");
        renderWebTabs();
        persistTabs();
    }

    private void closeWebTab(BrowserTab tab) {
        if (webTabs.size() == 1) {
            tab.candidates.clear();
            tab.web.loadUrl(homeUrl());
            return;
        }
        int oldIndex = webTabs.indexOf(tab);
        if (tab == activeTab) {
            BrowserTab next = webTabs.get(oldIndex > 0 ? oldIndex - 1 : 1);
            // Remove the closed tab before switching its visibility.
            activeTab = null;
            browser = next.web;
            webTabs.remove(tab);
            tabLookup.remove(tab.web);
            tab.web.setVisibility(View.GONE);
            activateTab(next);
        } else {
            webTabs.remove(tab);
            tabLookup.remove(tab.web);
        }
        tab.web.stopLoading();
        tab.web.setWebChromeClient(null);
        tab.web.setWebViewClient(null);
        webContainer.removeView(tab.web);
        tab.web.destroy();
        renderWebTabs();
        persistTabs();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void renderWebTabs() {
        if (webTabStrip == null) return;
        webTabStrip.removeAllViews();
        for (BrowserTab tab : webTabs) {
            boolean selected = tab == activeTab;
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(android.view.Gravity.CENTER_VERTICAL);
            GradientDrawable shape = new GradientDrawable();
            shape.setCornerRadius(dp(12));
            shape.setColor(selected ? 0xffffffff : 0xffE8EEF5);
            shape.setStroke(dp(1), selected ? 0xff91B6ED : 0xffD8E2ED);
            chip.setBackground(shape);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, dp(34));
            cp.setMargins(dp(4), dp(3), dp(4), dp(3));
            webTabStrip.addView(chip, cp);
            TextView label = new TextView(this);
            String raw = tab.web.getTitle();
            if (raw == null || raw.trim().isEmpty()) {
                try { raw = Uri.parse(tab.web.getUrl()).getHost(); }
                catch (Exception ignored) { raw = null; }
            }
            if (raw == null || raw.trim().isEmpty()) raw = "새 탭";
            raw = raw.replace('\n', ' ');
            label.setText(raw.length() > 17 ? raw.substring(0, 16) + "…" : raw);
            label.setTextSize(12);
            label.setSingleLine(true);
            label.setTextColor(selected ? 0xff183B65 : 0xff516477);
            label.setPadding(dp(12), 0, dp(7), 0);
            chip.addView(label, new LinearLayout.LayoutParams(-2, -1));
            label.setGravity(android.view.Gravity.CENTER_VERTICAL);
            label.setOnClickListener(v -> activateTab(tab));
            TextView close = new TextView(this);
            close.setText("×");
            close.setContentDescription("탭 닫기");
            close.setTextSize(20);
            close.setTextColor(0xff657A91);
            close.setGravity(android.view.Gravity.CENTER);
            chip.addView(close, new LinearLayout.LayoutParams(dp(30), -1));
            close.setOnClickListener(v -> closeWebTab(tab));
        }
        if (openTabs != null) openTabs.setText("탭 " + webTabs.size() + " ▾");
        if (dashboardStatus != null) dashboardStatus.setText(webTabs.size() + "개 탭");
    }

    // Window size can change in-place on a foldable or in split-screen.
    private void applyAdaptiveWindowLayout() {
        if (dashboardStatus != null) {
            int widthDp = getResources().getConfiguration().screenWidthDp;
            dashboardStatus.setText(webTabs.size() + "개 탭 · "
                    + (widthDp >= 600 ? "펼친 화면" : "일반 화면"));
        }
        if (webContainer != null) webContainer.requestLayout();
        for (BrowserTab tab : webTabs) {
            tab.web.setInitialScale(0);
            tab.web.requestLayout();
            tab.web.invalidate();
            restoreSiteZoom(tab.web);
        }
        // Give responsive webpages a resize event without reloading media.
        if (browser != null) browser.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed())
                browser.evaluateJavascript("window.dispatchEvent(new Event('resize'));", null);
        }, 250);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applyAdaptiveWindowLayout();
    }

    private void configureBrowser(WebView web) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); // Needed by most modern websites.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Android 8+: enable Google Safe Browsing protection for malicious URLs.
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        // Foldable / wide-window: let CSS viewport reflow to the actual WebView width.
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setInitialScale(0);
        web.setOnTouchListener((v, e) -> {
            BrowserTab tab = tabLookup.get(web);
            if (tab != null && e.getPointerCount() >= 2)
                tab.lastPinchAt = android.os.SystemClock.uptimeMillis();
            return false; // WebView still handles pinch and click itself.
        });
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int percent) {
                if (web != browser) return;
                progress.setProgress(percent);
                progress.setVisibility(percent >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                BrowserTab tab = tabLookup.get(view);
                if (tab == null) return;
                tab.epoch++;
                tab.lastScannedPage = url == null ? "" : url;
                tab.candidates.clear();
                if (tab == activeTab) {
                    refreshCandidates();
                    address.setText(url);
                    renderWebTabs();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (view != browser) return;
                address.setText(url);
                renderWebTabs();
                restoreSiteZoom(view);
                persistTabs();
                runScan();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (AdBlock.blocked(uri)) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                String url = uri.toString();
                BrowserTab tab = tabLookup.get(view);
                if (MediaDetector.looksLikeVideo(url) && tab != null && tab == activeTab) {
                    addVideo(tab, url, 1, 0, 0, 0, false, null, tab.epoch);
                }
                return null;
            }
            @Override public void onScaleChanged(WebView view, float oldScale, float newScale) {
                long now = android.os.SystemClock.uptimeMillis();
                if (now < automaticZoomUntil) return;
                BrowserTab zoomTab = tabLookup.get(view);
                if (zoomTab == null || now - zoomTab.lastPinchAt > 1500) return;
                if (newScale < 0.5f || newScale > 3f || Math.abs(oldScale - newScale) < 0.03f) return;
                String key = scaleKey(view.getUrl());
                if (!key.isEmpty()) getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                        .edit().putFloat(key, newScale).apply();
            }
            @Override public void onReceivedSslError(WebView view,
                                                      SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never let invalid certificates through.
                runOnUiThread(() -> toast("안전하지 않은 연결을 차단했습니다"));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) {
                    runOnUiThread(() -> toast("웹페이지를 열 수 없습니다"));
                }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (web != browser) { toast("먼저 해당 웹페이지 탭을 선택하세요"); return; }
            if (MediaDetector.validWebUrl(url)) {
                offerDownload(url, MediaDetector.guessName(url, contentDisposition, mimeType));
            } else {
                toast("이 다운로드 주소는 지원하지 않습니다");
            }
        });
    }

    /** Top-level, one-shot WebView query. No JavaScript bridge is exposed to iframes. */
    private void runScan() {
        if (scanScript.isEmpty() || browser == null || activeTab == null
                || browser.getVisibility() != View.VISIBLE) return;
        final BrowserTab tab = activeTab;
        final WebView currentWeb = browser;
        final String page = currentWeb.getUrl();
        if (!MediaDetector.validWebUrl(page)) return;
        if (!page.equals(tab.lastScannedPage)) {
            // Also clear stale candidates on single-page application URL changes.
            Uri previous = Uri.parse(tab.lastScannedPage.isEmpty() ? page : tab.lastScannedPage)
                    .buildUpon().fragment(null).build();
            Uri current = Uri.parse(page).buildUpon().fragment(null).build();
            if (!previous.equals(current)) { tab.candidates.clear(); refreshCandidates(); }
            tab.lastScannedPage = page;
        }
        final long epoch = tab.epoch;
        currentWeb.evaluateJavascript(scanScript, json -> {
            if (json == null || "null".equals(json) || isFinishing() || isDestroyed()
                    || tab != activeTab || currentWeb != browser || epoch != tab.epoch) return;
            try {
                // WebView JSON-encodes JavaScript's JSON.stringify return string.
                Object decoded = new JSONTokener(json).nextValue();
                if (!(decoded instanceof String)) return;
                JSONObject result = new JSONObject((String) decoded);
                if (!samePageDocument(result.optString("page"))) return;
                JSONArray videos = result.optJSONArray("videos");
                if (videos == null) return;
                for (int i = 0; i < Math.min(80, videos.length()); i++) {
                    JSONObject v = videos.optJSONObject(i);
                    if (v == null) continue;
                    addVideo(tab, v.optString("url"), v.optInt("source", 1),
                            v.optInt("width", 0), v.optInt("height", 0),
                            v.optInt("duration", 0), v.optBoolean("playing", false),
                            result.optString("page"), epoch);
                }
            } catch (Exception ignored) { /* Malformed/untrusted webpage metadata. */ }
        });
    }

    private void addVideo(BrowserTab tab, String url, int source, int width,
                          int height, int duration, boolean playing, String page, long epoch) {
        if (!MediaDetector.validWebUrl(url) || MediaDetector.adLike(url)
                || (source <= 1 && !MediaDetector.looksLikeVideo(url))) return;
        ui.post(() -> {
            if (isFinishing() || isDestroyed() || tab != activeTab || epoch != tab.epoch) return;
            if (page != null && !samePageDocument(page)) return;
            VideoCandidate candidate = tab.candidates.get(url);
            if (candidate == null) {
                if (tab.candidates.size() >= 90) {
                    // Preserve room for the actual in-page player when many ads/resources exist.
                    if (source < 2) return;
                    String low = null;
                    for (Map.Entry<String, VideoCandidate> item : tab.candidates.entrySet()) {
                        if (item.getValue().source <= 1) { low = item.getKey(); break; }
                    }
                    if (low == null) return;
                    tab.candidates.remove(low);
                }
                candidate = new VideoCandidate(url);
                tab.candidates.put(url, candidate);
            }
            Uri pageUri = Uri.parse(browser.getUrl() == null ? HOME : browser.getUrl());
            candidate.observe(source, width, height, duration, playing, pageUri.getHost());
            refreshCandidates();
        });
    }

    // Exact top-level document match, not merely same host. URL fragments are
    // excluded because they do not identify a different network document.
    // This does NOT authenticate messages from untrusted JavaScript frames.
    private boolean samePageDocument(String page) {
        if (!MediaDetector.validWebUrl(page)) return false;
        String current = browser.getUrl();
        if (!MediaDetector.validWebUrl(current)) return false;
        Uri reported = Uri.parse(page).buildUpon().fragment(null).build();
        Uri visible = Uri.parse(current).buildUpon().fragment(null).build();
        return reported.equals(visible);
    }

    private List<VideoCandidate> rankedCandidates() {
        List<VideoCandidate> list = new ArrayList<>();
        if (activeTab == null) return list;
        for (VideoCandidate c : activeTab.candidates.values()) if (c.allowed()) list.add(c);
        list.sort((a, b) -> Integer.compare(b.score(), a.score()));
        return list;
    }

    private VideoCandidate bestCandidate() {
        List<VideoCandidate> items = rankedCandidates();
        return !items.isEmpty() && items.get(0).recommended() ? items.get(0) : null;
    }

    private void refreshCandidates() {
        List<VideoCandidate> list = rankedCandidates();
        VideoCandidate best = !list.isEmpty() && list.get(0).recommended() ? list.get(0) : null;
        int good = 0;
        for (VideoCandidate item : list) if (item.recommended()) good++;
        tabDetect.setText(good == 0 ? "영상 찾기" : "영상 찾기 (" + good + ")");
        detectedCard.setVisibility(best == null ? View.GONE : View.VISIBLE);
        if (best != null) {
            String title = browser.getTitle();
            if (title == null || title.trim().isEmpty()) title = "현재 페이지";
            if (title.length() > 24) title = title.substring(0, 24) + "…";
            detectedSummary.setText((best.active ? "▶ 재생 영상" : "▶ 영상 후보")
                    + " · " + best.qualityLabel() + " · " + title);
            moreVideos.setVisibility(good > 1 ? View.VISIBLE : View.GONE);
            quickDownload.setText(MediaDetector.isHls(best.url) ? "화질 · 받기" : "다운로드");
        }
    }

    private String friendlyName(String url) {
        String title = browser.getTitle();
        if (title == null || title.trim().isEmpty()) title = "영상";
        String name = DownloadStore.safeFileName(title);
        if (name.length() > 65) name = name.substring(0, 65);
        String path = Uri.parse(url).getPath();
        String ext = ".mp4";
        if (path != null) {
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".webm")) ext = ".webm";
            else if (lower.endsWith(".mov")) ext = ".mov";
            else if (lower.endsWith(".m4v")) ext = ".m4v";
        }
        return name + (MediaDetector.isHls(url) ? ".ts" : ext);
    }

    private void showVideos() {
        List<VideoCandidate> all = rankedCandidates();
        List<VideoCandidate> list = new ArrayList<>();
        for (VideoCandidate c : all) if (c.recommended()) list.add(c);
        if (list.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("현재 영상이 확인되지 않았습니다")
                .setMessage("사이트에서 원하는 영상을 재생한 뒤 '영상 찾기'를 다시 눌러주세요. "
                    + "광고 영상으로 추정되는 주소는 숨겼습니다. 보호된 스트리밍은 감지되지 않을 수 있습니다.")
                .setPositiveButton("다시 찾기", (d,w) -> runScan())
                .setNeutralButton(all.isEmpty() ? "주소 직접 입력" : "기타 영상 후보 (주의)",
                    (d,w) -> {
                        if (all.isEmpty()) enterDownloadUrl();
                        else showLowConfidence(all);
                    })
                .setNegativeButton("닫기", null).show();
            return;
        }
        // Only surface a few high-confidence results; don't dump ad/network resource URLs.
        if (list.size() > 8) list = new ArrayList<>(list.subList(0, 8));
        final List<VideoCandidate> choices = list;
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            VideoCandidate c = choices.get(i);
            Uri uri = Uri.parse(c.url);
            labels[i] = (c.active ? "▶ 재생 중" : "영상 후보") + " · "
                    + c.qualityLabel() + " · " + (MediaDetector.isHls(c.url) ? "HLS" : "파일")
                    + "\n" + uri.getHost();
        }
        new AlertDialog.Builder(this).setTitle("본편으로 추정되는 영상 " + choices.size() + "개")
            .setItems(labels, (d, which) -> {
                String url = choices.get(which).url;
                offerDownload(url, friendlyName(url));
            })
            .setNeutralButton("주소 직접 입력", (d, w) -> enterDownloadUrl())
            .setNegativeButton("닫기", null).show();
    }

    private void showLowConfidence(List<VideoCandidate> all) {
        int max = Math.min(5, all.size());
        String[] labels = new String[max];
        for (int i = 0; i < max; i++) {
            VideoCandidate c = all.get(i);
            labels[i] = "확인되지 않은 영상 · " + c.qualityLabel()
                + "\n" + Uri.parse(c.url).getHost();
        }
        new AlertDialog.Builder(this).setTitle("기타 후보 · 광고 영상 포함 가능")
            .setItems(labels, (d, index) -> {
                String url = all.get(index).url;
                offerDownload(url, friendlyName(url));
            })
            .setNegativeButton("닫기", null).show();
    }

    private void chooseFolder() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, FOLDER_PICKER);
        } catch (Exception e) { toast("폴더 선택기를 실행할 수 없습니다"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FOLDER_PICKER && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                StorageTarget.choose(this, tree);
                refreshFolderLabel();
                toast("저장 폴더를 변경했습니다");
            } catch (SecurityException e) {
                toast("선택한 폴더의 쓰기 권한을 얻지 못했습니다");
            }
        }
        if (requestCode == FOLDER_PICKER && pendingUrl != null) {
            String url = pendingUrl, name = pendingName;
            pendingUrl = null; pendingName = null;
            if (resultCode == RESULT_OK) offerDownload(url, name);
        }
    }

    private void refreshFolderLabel() {
        folderLabel.setText("저장 위치: " + StorageTarget.display(this));
    }

    private void enterDownloadUrl() {
        EditText text = new EditText(this);
        text.setSingleLine(false);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        text.setHint("https://example.com/video.mp4");
        text.setPadding(32, 20, 32, 20);
        new AlertDialog.Builder(this).setTitle("동영상 주소 붙여넣기")
                .setView(text)
                .setPositiveButton("다음", (d, w) -> {
                    String url = text.getText().toString().trim();
                    if (MediaDetector.validWebUrl(url))
                        offerDownload(url, MediaDetector.guessName(url, null, null));
                    else toast("http:// 또는 https:// 주소를 입력하세요");
                })
                .setNegativeButton("취소", null).show();
    }

    private void offerDownload(String url, String suggestedName) {
        if (!MediaDetector.validWebUrl(url)) { toast("다운로드 주소 오류"); return; }
        boolean hls = MediaDetector.isHls(url);
        EditText nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setText(suggestedName);
        nameBox.setSelectAllOnFocus(true);
        nameBox.setPadding(32, 24, 32, 24);
        new AlertDialog.Builder(this).setTitle(hls ? "영상 저장 · 화질 선택" : "영상 다운로드")
            .setMessage("저장 위치: " + StorageTarget.display(this)
                + (hls ? "\n실제 제공되는 화질을 다음 화면에서 선택합니다." :
                    "\nMP4 파일은 사이트에서 제공하는 원본 화질로 저장합니다."))
            .setView(nameBox)
            .setPositiveButton(hls ? "화질 선택" : "다운로드", (d, w) -> {
                String name = DownloadStore.safeFileName(nameBox.getText().toString());
                if (hls) {
                    int dot = name.lastIndexOf('.');
                    name = (dot > 0 ? name.substring(0, dot) : name) + ".ts";
                    chooseHlsQuality(url, name);
                } else downloadDirect(url, name);
            })
            .setNeutralButton("폴더 선택", (d, w) -> {
                pendingUrl = url;
                pendingName = DownloadStore.safeFileName(nameBox.getText().toString());
                chooseFolder();
            })
            .setNegativeButton("취소", null).show();
    }

    private void chooseHlsQuality(String url, String filename) {
        final String referer = browser.getUrl();
        final String ua = browser.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final AlertDialog loading = new AlertDialog.Builder(this)
                .setTitle("화질 확인 중")
                .setMessage("영상 사이트가 제공하는 화질을 확인합니다…")
                .setNegativeButton("취소", null).create();
        loading.show();
        new Thread(() -> {
            List<HlsQualityResolver.Quality> qualities = null;
            String error = null;
            try { qualities = HlsQualityResolver.inspect(url, referer, ua, cookie); }
            catch (Exception e) { error = e.getMessage(); }
            final List<HlsQualityResolver.Quality> options = qualities;
            final String reason = error;
            ui.post(() -> {
                if (isDestroyed() || isFinishing() || !loading.isShowing()) return;
                loading.dismiss();
                if (reason != null) {
                    new AlertDialog.Builder(this).setTitle("화질 정보를 확인하지 못했습니다")
                        .setMessage(reason + "\n원본 영상 주소로 다운로드를 시도할 수 있습니다.")
                        .setPositiveButton("원본으로 시도", (d,w) -> startHlsDownload(url, filename))
                        .setNegativeButton("취소", null).show();
                    return;
                }
                String[] labels = new String[options.size()];
                for (int i=0; i < options.size(); i++) labels[i] = options.get(i).label;
                new AlertDialog.Builder(this).setTitle("영상 화질 선택")
                    .setSingleChoiceItems(labels, 0, (dialog, which) -> {
                        dialog.dismiss();
                        startHlsDownload(options.get(which).url, filename);
                    })
                    .setNegativeButton("취소", null).show();
            });
        }, "HlsQualityInspect").start();
    }

    private void startHlsDownload(String url, String filename) {
        startServiceDownload(url, filename, "hls");
    }

    private void startServiceDownload(String url, String filename, String mode) {
        enqueueService(url, filename, mode, StorageTarget.selected(this),
                browser == null ? "" : browser.getUrl(),
                browser == null ? "" : browser.getSettings().getUserAgentString());
    }

    private boolean enqueueService(String url, String filename, String mode,
                                   String folder, String referer, String ua) {
        if (!MediaDetector.validWebUrl(url)) return false;
        String id = mode + "-" + UUID.randomUUID();
        String kind = "service-" + mode;
        filename = DownloadStore.freshName(this, filename);
        DownloadStore.addSource(this, id, kind, filename, url, referer, folder, ua);
        Intent intent = new Intent(this, HlsDownloadService.class);
        intent.putExtra("id", id);
        intent.putExtra("mode", mode);
        intent.putExtra("url", url);
        intent.putExtra("filename", filename);
        intent.putExtra("folder", folder);
        intent.putExtra("referer", referer);
        intent.putExtra("ua", ua);
        // Resolve the current site's cookie at retry time; never save session secrets in history.
        intent.putExtra("cookie", CookieManager.getInstance().getCookie(url));
        try {
            startForegroundService(intent);
            toast("다운로드를 시작했습니다");
            return true;
        } catch (Exception e) {
            DownloadStore.update(this, id, "실패: 다운로드 서비스 시작 오류", 0);
            toast("다운로드를 시작할 수 없습니다");
            return false;
        }
    }

    private void downloadDirect(String url, String filename) {
        enqueueService(url, filename, "direct", StorageTarget.selected(this),
                browser == null ? "" : browser.getUrl(),
                browser == null ? "" : browser.getSettings().getUserAgentString());
    }

    /** System DownloadManager has automatic network retry, but no app pause/resume API. */
    private boolean enqueueDirect(String url, String filename, String referer, String ua) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription(getString(R.string.app_name));
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, "믿음하나/" + filename);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            if (ua != null && !ua.isEmpty()) request.addRequestHeader("User-Agent", ua);
            if (MediaDetector.validWebUrl(referer)) request.addRequestHeader("Referer", referer);
            if (filename.toLowerCase(Locale.ROOT).endsWith(".mp4"))
                request.setMimeType("video/mp4");
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            DownloadStore.addSource(this, String.valueOf(id), "direct", filename,
                    url, referer, "", ua);
            toast("다운로드를 시작했습니다");
            return true;
        } catch (Exception e) {
            toast("다운로드 실패: " + e.getClass().getSimpleName());
            return false;
        }
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        String url;
        if (MediaDetector.validWebUrl(input)) url = input;
        else if (input.matches("(?i)^[^\\s]+\\.[a-z]{2,}([/:?].*)?$")) url = "https://" + input;
        else url = "https://www.google.com/search?q=" + Uri.encode(input);
        showPanel("web");
        browser.loadUrl(url);
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    private void showPanel(String name) {
        boolean download = "downloads".equals(name);
        boolean bookmark = "bookmarks".equals(name);
        downloadsPanel.setVisibility(download ? View.VISIBLE : View.GONE);
        bookmarksPanel.setVisibility(bookmark ? View.VISIBLE : View.GONE);
        for (BrowserTab tab : webTabs) {
            tab.web.setVisibility(!download && !bookmark && tab == activeTab
                    ? View.VISIBLE : View.GONE);
        }
        if (!download && !bookmark) {
            refreshCandidates();
            ui.removeCallbacks(scanTick);
            ui.post(scanTick);
        } else {
            ui.removeCallbacks(scanTick);
            detectedCard.setVisibility(View.GONE);
        }
        if (download) refreshFolderLabel();
        tabWeb.setTextColor(!download && !bookmark ? 0xff1357b5 : 0xff303030);
        tabDownloads.setTextColor(download ? 0xff1357b5 : 0xff303030);
        tabBookmarks.setTextColor(bookmark ? 0xff1357b5 : 0xff303030);
        tabDetect.setTextColor(0xff303030);
        ui.removeCallbacks(tick);
        if (download) { renderDownloads(); ui.postDelayed(tick, 2000); }
        if (bookmark) renderBookmarks();
    }

    private void renderBookmarks() {
        List<String> labels = new ArrayList<>();
        for (JSONObject item : Bookmarks.all(this)) {
            labels.add(item.optString("title") + "\n" + item.optString("url"));
        }
        if (labels.isEmpty()) labels.add("즐겨찾기가 없습니다. 웹사이트에서 ☆ 버튼을 누르세요.");
        bookmarksList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void installDownloadAdapter() {
        downloadsAdapter = new BaseAdapter() {
            @Override public int getCount() { return downloadRows.isEmpty() ? 1 : downloadRows.size(); }
            @Override public Object getItem(int position) {
                return downloadRows.isEmpty() ? null : downloadRows.get(position);
            }
            @Override public long getItemId(int position) {
                return downloadRows.isEmpty() ? -1 : downloadRows.get(position).id.hashCode();
            }
            @Override public boolean hasStableIds() { return true; }
            @Override public View getView(int position, View recycled, ViewGroup parent) {
                TextView label = recycled instanceof TextView ? (TextView) recycled : new TextView(MainActivity.this);
                label.setTextSize(14);
                label.setTextColor(0xff1B354B);
                label.setPadding(dp(12), dp(9), dp(12), dp(9));
                label.setMinHeight(dp(58));
                if (downloadRows.isEmpty()) {
                    label.setText("다운로드 내역이 없습니다. 웹페이지에서 영상을 선택하세요.");
                    label.setBackgroundColor(0xffffffff);
                } else {
                    DownloadRow row = downloadRows.get(position);
                    label.setText((selectingDownloads ? (selectedDownloadIds.contains(row.id) ? "☑ " : "☐ ") : "")
                            + row.label());
                    label.setBackgroundColor(selectedDownloadIds.contains(row.id) ? 0xffDFEFFF : 0xffffffff);
                }
                return label;
            }
        };
        downloadsList.setAdapter(downloadsAdapter);
    }

    private void setDownloadSelection(boolean on) {
        selectingDownloads = on;
        if (!on) selectedDownloadIds.clear();
        downloadBulkActions.setVisibility(on ? View.VISIBLE : View.GONE);
        ((Button) findViewById(R.id.select_downloads)).setText(on ? "선택 취소" : "선택");
        redrawDownloadSelection();
    }

    private void redrawDownloadSelection() {
        int first = downloadsList.getFirstVisiblePosition();
        View child = downloadsList.getChildAt(0);
        int top = child == null ? 0 : child.getTop();
        downloadsAdapter.notifyDataSetChanged();
        downloadsList.post(() -> downloadsList.setSelectionFromTop(first, top));
    }

    /** Update visible rows without rebuilding the adapter every two seconds. */
    private void renderDownloads() {
        List<DownloadRow> next = new ArrayList<>();
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        for (JSONObject entry : DownloadStore.list(this)) {
            String id = entry.optString("id");
            String status = entry.optString("status", "대기 중");
            int percent = entry.optInt("progress", 0);
            if ("direct".equals(entry.optString("type"))
                    && !status.startsWith("중지")) {
                try {
                    long number = Long.parseLong(id);
                    try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                        if (cursor != null && cursor.moveToFirst()) {
                            int raw = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            long done = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                            percent = total > 0 ? (int) Math.min(100, done * 100 / total) : 0;
                            if (raw == DownloadManager.STATUS_SUCCESSFUL) { status = "완료"; percent = 100; }
                            else if (raw == DownloadManager.STATUS_RUNNING) status = "다운로드 중";
                            else if (raw == DownloadManager.STATUS_PAUSED) status = "일시 대기 (시스템 자동 재시도)";
                            else if (raw == DownloadManager.STATUS_FAILED) status = "실패";
                            else status = "대기 중";
                        } else status = "시스템에 다운로드 기록 없음";
                    }
                } catch (Exception e) { status = "상태 확인 실패"; }
            }
            next.add(new DownloadRow(entry, status, percent));
        }
        int first = downloadsList.getFirstVisiblePosition();
        View topView = downloadsList.getChildAt(0);
        int top = topView == null ? 0 : topView.getTop();
        boolean changedStructure = next.size() != downloadRows.size();
        if (!changedStructure) {
            for (int i = 0; i < next.size(); i++) {
                if (!next.get(i).id.equals(downloadRows.get(i).id)) {
                    changedStructure = true; break;
                }
            }
        }
        if (changedStructure) {
            downloadRows.clear();
            downloadRows.addAll(next);
            downloadsAdapter.notifyDataSetChanged();
            // Restore the exact row and pixel offset after insertion/removal.
            downloadsList.post(() -> downloadsList.setSelectionFromTop(
                    Math.min(first, Math.max(0, downloadsAdapter.getCount() - 1)), top));
        } else {
            for (int i = 0; i < next.size(); i++) {
                DownloadRow previous = downloadRows.get(i), current = next.get(i);
                String oldLabel = previous.label();
                previous.entry = current.entry;
                previous.status = current.status;
                previous.progress = current.progress;
                if (!oldLabel.equals(previous.label())) {
                    int child = i - first;
                    if (child >= 0 && child < downloadsList.getChildCount()) {
                        View visible = downloadsList.getChildAt(child);
                        if (visible instanceof TextView) {
                            ((TextView) visible).setText((selectingDownloads
                                    ? (selectedDownloadIds.contains(previous.id) ? "☑ " : "☐ ") : "")
                                    + previous.label());
                        }
                    }
                }
            }
        }
        selectedDownloadIds.retainAll(downloadIds());
    }

    private Set<String> downloadIds() {
        Set<String> ids = new HashSet<>();
        for (DownloadRow row : downloadRows) ids.add(row.id);
        return ids;
    }

    private boolean isActive(DownloadRow row) {
        String s = row.status;
        return s.startsWith("다운로드 중") || s.startsWith("대기 중")
                || s.startsWith("일시 대기") || s.startsWith("중지 요청")
                || s.startsWith("이어받기 준비");
    }

    private void showDownloadActions(DownloadRow row) {
        List<String> actions = new ArrayList<>();
        if (row.status.startsWith("완료")) actions.add("저장된 영상 열기");
        if (isActive(row)) actions.add("다운로드 중지");
        if (!isActive(row) && row.entry.optString("type").startsWith("service-")
                && !row.status.startsWith("완료")) actions.add("이어받기 (가능한 지점부터)");
        if (!isActive(row)) actions.add("다시 받기 (처음부터)");
        actions.add("삭제 옵션…");
        new AlertDialog.Builder(this).setTitle(row.entry.optString("name"))
            .setItems(actions.toArray(new String[0]), (d, which) -> {
                String action = actions.get(which);
                if (action.startsWith("저장된")) openCompletedDownload(row.entry);
                else if (action.startsWith("다운로드 중지")) stopDownload(row);
                else if (action.startsWith("이어받기")) resumeDownload(row, false);
                else if (action.startsWith("다시 받기")) resumeDownload(row, true);
                else { selectedDownloadIds.clear(); selectedDownloadIds.add(row.id); confirmDeleteSelected(); }
            }).setNegativeButton("닫기", null).show();
    }

    private void stopDownload(DownloadRow row) {
        if (!isActive(row)) return;
        if ("direct".equals(row.entry.optString("type"))) {
            try {
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (manager.remove(Long.parseLong(row.id)) <= 0) { toast("시스템 다운로드를 찾지 못했습니다"); return; }
                DownloadStore.update(this, row.id, "중지됨 · 처음부터 다시 받기", 0);
            } catch (Exception e) { toast("중지 실패"); return; }
        } else {
            if (!HlsDownloadService.isJobActive(row.id)) {
                DownloadStore.patch(this, row.id, "state", "PAUSED", "status", "중지됨 · 이어받기 가능");
                renderDownloads();
                return;
            }
            try {
                Intent stop = new Intent(this, HlsDownloadService.class);
                stop.setAction(HlsDownloadService.ACTION_CANCEL);
                stop.putExtra("id", row.id);
                startService(stop);
                DownloadStore.patch(this, row.id, "status", "중지 요청 중");
            } catch (Exception e) { toast("중지 명령 실패"); return; }
        }
        renderDownloads();
    }

    private void retryDownload(DownloadRow row) { resumeDownload(row, false); }

    /** Same task ID preserves validated private chunks; full restart creates a fresh transfer. */
    private void resumeDownload(DownloadRow row, boolean restart) {
        if (isActive(row)) { toast("먼저 현재 작업을 중지하세요"); return; }
        JSONObject entry = DownloadStore.get(this, row.id);
        if (entry == null) return;
        String url = entry.optString("url");
        if (!MediaDetector.validWebUrl(url)) { toast("이전 기록의 영상 주소가 없습니다"); return; }
        String type = entry.optString("type");
        String filename = entry.optString("name");
        String folder = entry.optString("folder");
        String referer = entry.optString("referer");
        String ua = entry.optString("ua");
        if (!type.startsWith("service-")) {
            boolean ok = "direct".equals(type) ? enqueueService(url, filename, "direct", folder, referer, ua) : false;
            if (ok) toast("과거 시스템 다운로드는 처음부터 새로 받습니다");
            else toast("다시 받기를 시작할 수 없습니다");
            return;
        }
        if (restart || "COMPLETED".equals(entry.optString("state"))) {
            if (enqueueService(url, filename, type.substring("service-".length()), folder, referer, ua))
                toast("처음부터 새 다운로드로 시작합니다");
            return;
        }
        if (HlsDownloadService.isJobActive(row.id)) {
            toast("이전 다운로드 중지 처리 중입니다"); return;
        }
        DownloadStore.patch(this, row.id, "state", "QUEUED", "status", "이어받기 준비 중");
        Intent start = new Intent(this, HlsDownloadService.class).putExtra("id", row.id);
        try {
            startForegroundService(start);
            toast("저장된 지점부터 이어받기를 시도합니다");
        } catch (Exception e) {
            DownloadStore.patch(this, row.id, "state", "RECOVERY", "status", "이어받기 실패 · 다시 선택");
            toast("이어받기를 시작할 수 없습니다");
        }
        renderDownloads();
    }

    private void performBulk(String operation) {
        List<DownloadRow> chosen = new ArrayList<>();
        for (DownloadRow row : downloadRows)
            if (selectedDownloadIds.contains(row.id)) chosen.add(row);
        if (chosen.isEmpty()) { toast("작업할 다운로드를 선택하세요"); return; }
        if ("stop".equals(operation)) for (DownloadRow row : chosen) stopDownload(row);
        if ("retry".equals(operation)) for (DownloadRow row : chosen) retryDownload(row);
        renderDownloads();
    }

    private void confirmDeleteSelected() {
        if (selectedDownloadIds.isEmpty()) { toast("삭제할 다운로드를 선택하세요"); return; }
        final Set<String> ids = new HashSet<>(selectedDownloadIds);
        String[] options = {"목록에서만 삭제 (파일 유지)", "목록과 다운로드 파일 함께 삭제"};
        new AlertDialog.Builder(this).setTitle("선택한 " + ids.size() + "개 다운로드 삭제")
            .setItems(options, (d, which) -> {
                int success = 0, skipped = 0;
                for (DownloadRow row : new ArrayList<>(downloadRows)) {
                    if (!ids.contains(row.id)) continue;
                    if (removeDownload(row, which == 1)) success++; else skipped++;
                }
                selectedDownloadIds.clear();
                renderDownloads();
                toast("삭제 " + success + "개" + (skipped > 0 ? ", 확인 필요 " + skipped + "개" : ""));
            }).setNegativeButton("취소", null).show();
    }

    private boolean removeDownload(DownloadRow row, boolean deleteFile) {
        // Do not hide an active worker: users need to be able to stop it first.
        if (isActive(row) && !deleteFile) return false;
        if ("direct".equals(row.entry.optString("type"))) {
            if (deleteFile && !row.status.startsWith("중지")) {
                try {
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (dm.remove(Long.parseLong(row.id)) <= 0) return false;
                } catch (Exception e) { return false; }
            }
        } else {
            if (isActive(row)) {
                stopDownload(row);
                toast("먼저 중지했습니다. 중지 완료 후 파일 삭제를 다시 선택하세요");
                return false;
            }
            if (deleteFile) {
                String fileUri = row.entry.optString("uri");
                if (!fileUri.isEmpty()) {
                    try {
                        Uri uri = Uri.parse(fileUri);
                        boolean deleted = "content".equals(uri.getScheme())
                                && (uri.getAuthority() != null && uri.getAuthority().contains("documents")
                                    ? DocumentsContract.deleteDocument(getContentResolver(), uri)
                                    : getContentResolver().delete(uri, null, null) > 0);
                        if (!deleted) return false;
                    } catch (Exception e) { return false; }
                }
            }
        }
        DownloadStore.remove(this, row.id);
        HlsDownloadService.discardStaging(this, row.id);
        return true;
    }

    private void openCompletedDownload(JSONObject entry) {
        try {
            String type = entry.optString("type");
            Uri file;
            if ("direct".equals(type)) {
                long number = Long.parseLong(entry.optString("id"));
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                    if (cursor == null || !cursor.moveToFirst() || cursor.getInt(
                            cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            != DownloadManager.STATUS_SUCCESSFUL) {
                        toast("다운로드가 아직 완료되지 않았습니다");
                        return;
                    }
                }
                file = manager.getUriForDownloadedFile(number);
            } else {
                if (!entry.optString("status").startsWith("완료")) {
                    toast("다운로드가 아직 완료되지 않았습니다");
                    return;
                }
                String saved = entry.optString("uri");
                if (saved.isEmpty()) {
                    toast("이전 버전 기록입니다. 저장 폴더에서 확인하세요");
                    return;
                }
                file = Uri.parse(saved);
            }
            if (file == null) { toast("저장된 파일을 찾을 수 없습니다"); return; }
            String name = entry.optString("name").toLowerCase(Locale.ROOT);
            String mime = name.endsWith(".ts") ? "video/mp2t"
                    : name.endsWith(".webm") ? "video/webm"
                    : name.endsWith(".mov") ? "video/quicktime" : "video/mp4";
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(file, mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(view, "동영상 열기"));
        } catch (Exception e) { toast("열 수 있는 동영상 앱이 없거나 저장 파일을 찾을 수 없습니다"); }
    }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() {
        if (selectingDownloads && downloadsPanel.getVisibility() == View.VISIBLE) {
            setDownloadSelection(false);
            return;
        }
        if (downloadsPanel.getVisibility() == View.VISIBLE
                || bookmarksPanel.getVisibility() == View.VISIBLE) showPanel("web");
        else if (browser.canGoBack()) browser.goBack();
        else if (webTabs.size() > 1) closeWebTab(activeTab);
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        persistTabs();
        super.onPause();
        ui.removeCallbacks(tick);
        ui.removeCallbacks(scanTick);
        for (BrowserTab tab : webTabs) tab.web.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (browser != null) browser.onResume();
        ui.removeCallbacks(scanTick);
        if (browser != null && browser.getVisibility() == View.VISIBLE) ui.post(scanTick);
        if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
            ui.removeCallbacks(tick);
            renderDownloads();
            ui.postDelayed(tick, 2000);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("browser_tabs_count", webTabs.size());
        state.putInt("browser_tab_selected", Math.max(0, webTabs.indexOf(activeTab)));
        for (int i = 0; i < webTabs.size(); i++) {
            Bundle tabState = new Bundle();
            WebView web = webTabs.get(i).web;
            web.saveState(tabState);
            tabState.putString("last_url", web.getUrl() == null ? HOME : web.getUrl());
            state.putBundle("browser_tab_" + i, tabState);
        }
        super.onSaveInstanceState(state);
    }

    @Override protected void onDestroy() {
        persistTabs();
        ui.removeCallbacksAndMessages(null);
        for (BrowserTab tab : webTabs) {
            tab.web.stopLoading();
            tab.web.setWebChromeClient(null);
            tab.web.setWebViewClient(null);
            tab.web.destroy();
        }
        webTabs.clear();
        tabLookup.clear();
        super.onDestroy();
    }
}
