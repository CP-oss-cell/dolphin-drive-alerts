"""Structural regression checks for foldable WebView, tabs and compact dashboard.
These checks do NOT replace Android compilation or real foldable testing.
"""
from pathlib import Path
from xml.etree import ElementTree as ET
from subprocess import run
import re
root=Path(__file__).resolve().parents[1]
java=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
layout=root/'app/src/main/res/layout/activity_main.xml'
e=ET.parse(layout).getroot()
ns='{http://schemas.android.com/apk/res/android}'
ids={el.attrib.get(ns+'id','').replace('@+id/',''):el for el in e.iter() if ns+'id' in el.attrib}
for name in ('root','web_container','browser','web_tab_strip','new_web_tab','dashboard_status',
             'fit_page','detected_card','detected_summary','quick_download','quick_folder','more_videos',
             'downloads_panel','downloads_list','bookmarks_panel','bookmarks_list',
             'tab_web','tab_detect','tab_downloads','tab_bookmarks'):
    assert name in ids,name
assert ids['detected_card'].get(ns+'layout_height')=='54dp'
assert ids['detected_card'].get(ns+'orientation')=='horizontal'
assert 'setUseWideViewPort(true)' in java
assert 'setLoadWithOverviewMode(true)' in java
assert 'setTextZoom(100)' in java
assert 'setInitialScale(0)' in java
assert 'onConfigurationChanged(Configuration newConfig)' in java
assert 'screenSize|smallestScreenSize|screenLayout' in manifest
assert 'android:resizeableActivity="true"' in manifest
assert 'MAX_WEB_TABS = 8' in java
assert 'private static final class BrowserTab' in java
assert 'final LinkedHashMap<String, VideoCandidate> candidates' in java
assert 'tab != activeTab' in java
for name in ('registerTab','createWebTab','activateTab','closeWebTab', 'renderWebTabs',
             'onSaveInstanceState','restoreState(savedTab)'):
    assert name in java,name
assert 'tab.web.destroy()' in java
assert 'addJavascriptInterface' not in java
assert not re.search(r'\bpageEpoch\b|\bdetected\.clear\(', java)
assert 'tab.candidatesCard' not in java and 'tab.candidatesSummary' not in java
for name in ('browser','web_container','web_tab_strip','new_web_tab','dashboard_status','fit_page'):
    assert ('R.id.'+name) in java
print('FOLD_TABS_STATIC_REGRESSION_OK')
