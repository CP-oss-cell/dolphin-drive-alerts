from pathlib import Path
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parents[1]
layout = root / 'app/src/main/res/layout/activity_main.xml'
xml = layout.read_text(encoding='utf8')
ET.parse(layout)
# The older v2.0.1 GitHub Actions workflow failed at AAPT resource linking because this is NOT an Android XML attribute.
assert 'android:horizontalScrollBarEnabled' not in xml, 'Unsupported Android XML attribute in tab strip'
ns = '{http://schemas.android.com/apk/res/android}'
tabs = [e for e in ET.parse(layout).iter() if e.tag.endswith('HorizontalScrollView')]
assert len(tabs) == 1, f'Expected a single tab scrolling area, found {len(tabs)}'
assert tabs[0].attrib.get(ns + 'scrollbars') == 'none', 'The tab strip should hide its scrollbar'
assert tabs[0].attrib.get(ns + 'layout_width') == '0dp'
assert tabs[0].attrib.get(ns + 'layout_weight') == '1'
print('AAPT_TAB_SCROLLBAR_RESOURCE_REGRESSION_OK')
