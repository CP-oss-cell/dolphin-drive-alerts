from pathlib import Path
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
layout=(root/'app/src/main/res/layout/activity_main.xml').read_text()
java=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
assert 'quick_folder' in layout and 'quick_folder' in java
assert 'quick_download' in layout and 'quickDownload.setText' in java
assert '▶ 영상 후보' in java
assert 'StorageTarget.display(this)' in java
assert 'web_container' in layout and 'web_tab_strip' in layout and 'new_web_tab' in layout
assert 'detected_card' in layout and 'android:layout_height="54dp"' in layout
assert '"browser_tab_" + i' in java and 'restoreState(savedTab)' in java
assert 'setUseWideViewPort(true)' in java
assert 'setLoadWithOverviewMode(true)' in java
assert 'setInitialScale(0)' in java
assert 'onConfigurationChanged(Configuration newConfig)' in java
print('UI_REGRESSION_OK')
