# v2.1.0 빌드 및 검증 상태

- 버전: `com.mideumhana.browser`, `versionName 2.1.0`, `versionCode 6`.
- 사용자 요구: 바깥 ZIP 한 개를 풀면 `MideumHanaBrowser_v2.1.0_Source.zip`과 `MideumHanaBrowser_v2.1.0_Source.yml` 두 파일만 나오도록 구성.
- 실제 Android SDK APK 컴파일: **실행하지 못함** (이 환경에 SDK 및 Gradle Android 플러그인이 설치되어 있지 않음).
- Java 구문 파서 / XML / JS / 오프라인 회귀 검사 / 이어받기 순수 Java 테스트: 패키지 완성 전 수행.
- 주요 구현: Range 재개·HLS 조각 체크포인트·다운로드 기록 복구·속도/ETA·파일명 중복 회피·탭 URL 저장·사이트별 접힘/펼침 줌.
- 주의: Android 15+는 BOOT_COMPLETED에서 dataSync FGS 실행 불가. 앱에서 '이어받기'를 눌러 재개.
