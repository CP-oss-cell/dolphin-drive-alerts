package com.dolphin.comms.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.dolphin.comms.R;
import com.dolphin.comms.adb.PermissionBootstrapper;
import com.dolphin.comms.data.CommsRepository;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import com.dolphin.comms.phone.BtProfiles;
import com.dolphin.comms.phone.CallStateManager;
import com.dolphin.comms.phone.PhoneController;
import com.dolphin.comms.sms.EmergencyAlertReceiver;
import com.dolphin.comms.sms.SmsController;
import com.dolphin.comms.sms.SmsReceiver;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * T전화 스타일 5탭 초경량 통합 앱 (다이얼 · 최근기록 · 연락처 · 문자 · 설정).
 * 전화=블루투스(HFP), 문자/MMS/재난문자=차량 유심 경로를 구분해 동작합니다.
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK_IMAGE = 301;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final StringBuilder dialBuffer = new StringBuilder();

    private List<CommsRepository.Contact> allContacts = new ArrayList<>();
    private List<CommsRepository.RecentItem> allRecents = new ArrayList<>();
    private List<CommsRepository.SmsThread> allSmsThreads = new ArrayList<>();

    private int recentsFilter = 0; // 0=전체, 1=전화(BT), 2=문자(유심)
    private int smsFilter = 0; // 0=전체, 1=일반/MMS, 2=재난문자
    private boolean favoritesOnly = false;
    private CommsRepository.SmsThread openSmsThread = null;
    private Uri pendingMmsImageUri = null;

    private View[] panels;
    private View[] tabs;
    private TextView tvDialDisplay, tvDialMatch, tvModeBadge, tvSmsHeaderTitle, tvMmsAttachStatus;
    private EditText etSmsInput;
    private View smsThreadBox, smsDetailBox;
    private RecentsAdapter recentsAdapter;
    private ContactsAdapter contactsAdapter;
    private SmsThreadsAdapter smsThreadsAdapter;
    private SmsMessagesAdapter smsMessagesAdapter;

    private final BroadcastReceiver smsReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { reloadAll(); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SmsController.ensureSentReceiver(this);

        panels = new View[]{
            findViewById(R.id.panelDialer),
            findViewById(R.id.panelRecents),
            findViewById(R.id.panelContacts),
            findViewById(R.id.panelSms),
            findViewById(R.id.panelSettings)
        };
        tabs = new View[]{
            findViewById(R.id.tabDialer),
            findViewById(R.id.tabRecents),
            findViewById(R.id.tabContacts),
            findViewById(R.id.tabSms),
            findViewById(R.id.tabSettings)
        };
        tvModeBadge = findViewById(R.id.tvModeBadge);

        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            tabs[i].setOnClickListener(v -> selectTab(idx));
        }

        setupDialer();
        setupLists();
        setupSms();
        setupSettings();

        handleIncomingIntent(getIntent());
        requestAllPerms();

        IntentFilter f = new IntentFilter(SmsReceiver.ACTION_SMS_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(smsReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(smsReceiver, f);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        BtProfiles.init(this);
        reloadAll();
        refreshStatus();
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) { selectTab(0); return; }
        Uri data = intent.getData();
        String scheme = data != null ? data.getScheme() : null;
        if ("tel".equalsIgnoreCase(scheme)) {
            String num = data.getSchemeSpecificPart();
            if (num != null && !num.isEmpty()) {
                dialBuffer.setLength(0);
                dialBuffer.append(num);
                updateDialDisplay();
            }
            selectTab(0);
            return;
        }
        if ("sms".equalsIgnoreCase(scheme) || "smsto".equalsIgnoreCase(scheme)
                || "mms".equalsIgnoreCase(scheme) || "mmsto".equalsIgnoreCase(scheme)) {
            String num = data.getSchemeSpecificPart();
            selectTab(3);
            if (num != null && !num.trim().isEmpty()) {
                CommsRepository.SmsThread t = new CommsRepository.SmsThread();
                t.threadId = -1;
                t.address = num.trim();
                t.name = CommsRepository.pretty(t.address);
                openThread(t);
            }
            return;
        }
        selectTab(intent.getIntExtra("open_tab", 0));
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadAll();
        refreshStatus();
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(smsReceiver); } catch (Throwable ignored) {}
        bg.shutdownNow();
        super.onDestroy();
    }

    private void selectTab(int idx) {
        for (int i = 0; i < panels.length; i++) {
            panels[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            tabs[i].setSelected(i == idx);
        }
    }

    private void requestAllPerms() {
        List<String> req = new ArrayList<>();
        String[] perms = {
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.WRITE_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_MMS,
            Manifest.permission.RECEIVE_WAP_PUSH
        };
        for (String p : perms) {
            if (checkSelfPermission(p) != 0) req.add(p);
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != 0) {
            req.add("android.permission.BLUETOOTH_CONNECT");
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            req.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), 1);
    }

    private void setupDialer() {
        tvDialDisplay = findViewById(R.id.tvDialDisplay);
        tvDialMatch = findViewById(R.id.tvDialMatch);
        int[] ids = {R.id.key1,R.id.key2,R.id.key3,R.id.key4,R.id.key5,R.id.key6,R.id.key7,R.id.key8,R.id.key9,R.id.keyStar,R.id.key0,R.id.keyHash};
        String[] vals = {"1","2","3","4","5","6","7","8","9","*","0","#"};
        for (int i = 0; i < ids.length; i++) {
            final String d = vals[i];
            findViewById(ids[i]).setOnClickListener(v -> {
                if (dialBuffer.length() < 32) { dialBuffer.append(d); updateDialDisplay(); }
            });
        }
        findViewById(R.id.key0).setOnLongClickListener(v -> { dialBuffer.append("+"); updateDialDisplay(); return true; });
        View bs = findViewById(R.id.btnBackspace);
        bs.setOnClickListener(v -> { if (dialBuffer.length() > 0) { dialBuffer.deleteCharAt(dialBuffer.length() - 1); updateDialDisplay(); } });
        bs.setOnLongClickListener(v -> { dialBuffer.setLength(0); updateDialDisplay(); return true; });
        findViewById(R.id.btnDialCall).setOnClickListener(v -> {
            String num = dialBuffer.length() > 0 ? dialBuffer.toString() : firstRecentCallNumber();
            placeCall(num);
        });
    }

    private String firstRecentCallNumber() {
        for (CommsRepository.RecentItem r : allRecents) {
            if (r.kind == CommsRepository.RecentItem.KIND_CALL && !r.number.isEmpty()) return r.number;
        }
        return "";
    }

    private void updateDialDisplay() {
        String raw = dialBuffer.toString();
        tvDialDisplay.setText(raw.isEmpty() ? "번호 입력 (블루투스 발신)" : raw);
        String match = "";
        if (raw.length() >= 2) {
            String d = CommsRepository.digits(raw);
            for (CommsRepository.Contact c : allContacts) {
                if (c.searchKey.contains(d)) { match = c.name + " · " + c.number; break; }
            }
        }
        tvDialMatch.setText(match);
    }

    private void setupLists() {
        recentsAdapter = new RecentsAdapter();
        ListView lvRecents = findViewById(R.id.lvRecents);
        lvRecents.setAdapter(recentsAdapter);
        lvRecents.setOnItemClickListener((p, v, pos, id) -> {
            CommsRepository.RecentItem r = recentsAdapter.items.get(pos);
            if (r.kind == CommsRepository.RecentItem.KIND_CALL) {
                placeCall(r.number);
            } else {
                selectTab(3);
                CommsRepository.SmsThread target = new CommsRepository.SmsThread();
                target.threadId = r.threadId;
                target.address = r.number;
                target.name = r.name;
                target.isEmergency = r.kind == CommsRepository.RecentItem.KIND_EMERGENCY;
                openThread(target);
            }
        });

        View rAll = findViewById(R.id.chipRecentsAll);
        View rCall = findViewById(R.id.chipRecentsCall);
        View rMsg = findViewById(R.id.chipRecentsSms);
        rAll.setSelected(true);
        rAll.setOnClickListener(v -> { recentsFilter = 0; rAll.setSelected(true); rCall.setSelected(false); rMsg.setSelected(false); filterRecents(); });
        rCall.setOnClickListener(v -> { recentsFilter = 1; rAll.setSelected(false); rCall.setSelected(true); rMsg.setSelected(false); filterRecents(); });
        rMsg.setOnClickListener(v -> { recentsFilter = 2; rAll.setSelected(false); rCall.setSelected(false); rMsg.setSelected(true); filterRecents(); });

        contactsAdapter = new ContactsAdapter();
        ListView lvContacts = findViewById(R.id.lvContacts);
        lvContacts.setAdapter(contactsAdapter);
        lvContacts.setOnItemClickListener((p, v, pos, id) -> placeCall(contactsAdapter.items.get(pos).number));

        View chipAll = findViewById(R.id.chipContactsAll);
        View chipFav = findViewById(R.id.chipContactsFav);
        chipAll.setSelected(true);
        chipAll.setOnClickListener(v -> { favoritesOnly = false; chipAll.setSelected(true); chipFav.setSelected(false); filterContacts(); });
        chipFav.setOnClickListener(v -> { favoritesOnly = true; chipAll.setSelected(false); chipFav.setSelected(true); filterContacts(); });

        ((EditText) findViewById(R.id.etContactSearch)).addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { filterContacts(); }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void filterRecents() {
        List<CommsRepository.RecentItem> out = new ArrayList<>();
        for (CommsRepository.RecentItem r : allRecents) {
            if (recentsFilter == 1 && r.kind != CommsRepository.RecentItem.KIND_CALL) continue;
            if (recentsFilter == 2 && r.kind == CommsRepository.RecentItem.KIND_CALL) continue;
            out.add(r);
        }
        recentsAdapter.items = out;
        recentsAdapter.notifyDataSetChanged();
    }

    private void filterContacts() {
        String q = ((EditText) findViewById(R.id.etContactSearch)).getText().toString().trim().toLowerCase(Locale.ROOT);
        List<CommsRepository.Contact> out = new ArrayList<>();
        for (CommsRepository.Contact c : allContacts) {
            if (favoritesOnly && !c.starred) continue;
            if (q.isEmpty() || c.searchKey.contains(q)) out.add(c);
        }
        contactsAdapter.items = out;
        contactsAdapter.notifyDataSetChanged();
    }

    private void setupSms() {
        smsThreadBox = findViewById(R.id.smsThreadBox);
        smsDetailBox = findViewById(R.id.smsDetailBox);
        tvSmsHeaderTitle = findViewById(R.id.tvSmsHeaderTitle);
        etSmsInput = findViewById(R.id.etSmsInput);
        tvMmsAttachStatus = findViewById(R.id.tvMmsAttachStatus);

        smsThreadsAdapter = new SmsThreadsAdapter();
        ListView lvThreads = findViewById(R.id.lvSmsThreads);
        lvThreads.setAdapter(smsThreadsAdapter);
        lvThreads.setOnItemClickListener((p, v, pos, id) -> openThread(smsThreadsAdapter.items.get(pos)));

        View sAll = findViewById(R.id.chipSmsAll);
        View sGen = findViewById(R.id.chipSmsGeneral);
        View sEmg = findViewById(R.id.chipSmsEmergency);
        sAll.setSelected(true);
        sAll.setOnClickListener(v -> { smsFilter = 0; sAll.setSelected(true); sGen.setSelected(false); sEmg.setSelected(false); filterSmsThreads(); });
        sGen.setOnClickListener(v -> { smsFilter = 1; sAll.setSelected(false); sGen.setSelected(true); sEmg.setSelected(false); filterSmsThreads(); });
        sEmg.setOnClickListener(v -> { smsFilter = 2; sAll.setSelected(false); sGen.setSelected(false); sEmg.setSelected(true); filterSmsThreads(); });

        findViewById(R.id.btnNewSms).setOnClickListener(v -> showNewSmsDialog());

        smsMessagesAdapter = new SmsMessagesAdapter();
        ListView lvMsgs = findViewById(R.id.lvSmsMessages);
        lvMsgs.setAdapter(smsMessagesAdapter);
        lvMsgs.setOnItemClickListener((p, v, pos, id) -> {
            String text = smsMessagesAdapter.items.get(pos).body;
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("SMS", text));
            Toast.makeText(this, "문자 내용을 복사했습니다", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnSmsBack).setOnClickListener(v -> {
            openSmsThread = null;
            pendingMmsImageUri = null;
            tvMmsAttachStatus.setVisibility(View.GONE);
            smsDetailBox.setVisibility(View.GONE);
            smsThreadBox.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.btnSmsCallSender).setOnClickListener(v -> {
            if (openSmsThread != null && !openSmsThread.isEmergency) placeCall(openSmsThread.address);
        });
        findViewById(R.id.btnMmsAttach).setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
            startActivityForResult(pick, REQ_PICK_IMAGE);
        });
        findViewById(R.id.btnSmsSend).setOnClickListener(v -> {
            if (openSmsThread == null || openSmsThread.isEmergency) {
                Toast.makeText(this, "재난문자 채널에는 답장을 보낼 수 없습니다", Toast.LENGTH_SHORT).show();
                return;
            }
            String body = etSmsInput.getText().toString().trim();
            String err;
            if (pendingMmsImageUri != null || body.length() > 70) {
                err = SmsController.sendMms(this, openSmsThread.address, body, pendingMmsImageUri);
            } else {
                err = SmsController.sendSms(this, openSmsThread.address, body);
            }
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show();
            } else {
                etSmsInput.setText("");
                pendingMmsImageUri = null;
                tvMmsAttachStatus.setVisibility(View.GONE);
                Toast.makeText(this, "차량 유심으로 발신 요청됨", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showNewSmsDialog() {
        EditText etNum = new EditText(this);
        etNum.setHint("받는 번호 (예: 010-4444-5555)");
        etNum.setTextColor(0xFFF8FAFC);
        etNum.setHintTextColor(0xFF94A3B8);
        new AlertDialog.Builder(this)
            .setTitle("새 문자 / MMS 작성 (차량 유심)")
            .setView(etNum)
            .setPositiveButton("작성", (d, w) -> {
                String num = etNum.getText().toString().trim();
                if (!num.isEmpty()) {
                    CommsRepository.SmsThread t = new CommsRepository.SmsThread();
                    t.threadId = -1;
                    t.address = num;
                    t.name = CommsRepository.pretty(num);
                    openThread(t);
                }
            })
            .setNegativeButton("취소", null)
            .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            pendingMmsImageUri = data.getData();
            tvMmsAttachStatus.setText("📎 MMS 사진 첨부됨 (탭하면 해제)");
            tvMmsAttachStatus.setVisibility(View.VISIBLE);
            tvMmsAttachStatus.setOnClickListener(v -> {
                pendingMmsImageUri = null;
                tvMmsAttachStatus.setVisibility(View.GONE);
            });
        }
    }

    private void filterSmsThreads() {
        List<CommsRepository.SmsThread> out = new ArrayList<>();
        for (CommsRepository.SmsThread t : allSmsThreads) {
            if (smsFilter == 1 && t.isEmergency) continue;
            if (smsFilter == 2 && !t.isEmergency) continue;
            out.add(t);
        }
        smsThreadsAdapter.items = out;
        smsThreadsAdapter.notifyDataSetChanged();
    }

    private void openThread(CommsRepository.SmsThread t) {
        openSmsThread = t;
        tvSmsHeaderTitle.setText(t.name + (t.isEmergency ? "" : " (" + t.address + ")"));
        findViewById(R.id.smsComposeBar).setVisibility(t.isEmergency ? View.GONE : View.VISIBLE);
        findViewById(R.id.btnSmsCallSender).setVisibility(t.isEmergency ? View.GONE : View.VISIBLE);
        smsThreadBox.setVisibility(View.GONE);
        smsDetailBox.setVisibility(View.VISIBLE);
        bg.execute(() -> {
            if (!t.isEmergency) CommsRepository.markThreadRead(this, t.threadId, t.address);
            List<CommsRepository.SmsMessage> msgs = CommsRepository.loadSmsMessages(this, t.threadId, t.address);
            runOnUiThread(() -> {
                smsMessagesAdapter.items = msgs;
                smsMessagesAdapter.notifyDataSetChanged();
            });
        });
    }

    private void setupSettings() {
        SharedPreferences sp = getSharedPreferences("dolphin_comms_prefs", MODE_PRIVATE);
        TextView btnAdb = findViewById(R.id.btnAdbGrantAll);
        btnAdb.setOnClickListener(v -> {
            btnAdb.setEnabled(false);
            btnAdb.setText("⏳ 로컬 ADB 연결 및 권한 부여 중...");
            TextView tvDiag = findViewById(R.id.tvDiagSummary);
            bg.execute(() -> {
                PermissionBootstrapper.Result res = PermissionBootstrapper.applyAll(
                    MainActivity.this,
                    msg -> runOnUiThread(() -> tvDiag.setText("진행 중: " + msg))
                );
                runOnUiThread(() -> {
                    btnAdb.setEnabled(true);
                    btnAdb.setText("⚡ 앱 내 로컬 ADB로 모든 권한 일괄 승인");
                    BtProfiles.init(MainActivity.this);
                    reloadAll();
                    refreshStatus();
                    StringBuilder sb = new StringBuilder();
                    for (String line : res.getLines()) sb.append(line).append("\n");
                    tvDiag.setText(sb.toString().trim());
                    Toast.makeText(MainActivity.this, res.getSummary(), Toast.LENGTH_LONG).show();
                });
            });
        });

        Switch sw = findViewById(R.id.swCompactPopup);
        sw.setChecked(sp.getBoolean("compact_popup", true));
        sw.setOnCheckedChangeListener((b, chk) -> sp.edit().putBoolean("compact_popup", chk).apply());

        Switch swEmg = findViewById(R.id.swEmergencyAlerts);
        swEmg.setChecked(sp.getBoolean("emergency_alerts_enabled", true));
        swEmg.setOnCheckedChangeListener((b, chk) -> {
            sp.edit().putBoolean("emergency_alerts_enabled", chk).apply();
            refreshStatus();
            Toast.makeText(this, chk ? "긴급재난문자 수신이 켜졌습니다" : "긴급재난문자 수신이 꺼졌습니다", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btnSetDefaultDialer).setOnClickListener(v -> requestRole(RoleManager.ROLE_DIALER, TelecomManager.ACTION_CHANGE_DEFAULT_DIALER));
        findViewById(R.id.btnSetDefaultSms).setOnClickListener(v -> requestRole(RoleManager.ROLE_SMS, Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT));
        findViewById(R.id.btnGrantOverlay).setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        findViewById(R.id.btnTestIncoming).setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "먼저 '다른 앱 위에 표시' 권한을 허용하세요", Toast.LENGTH_LONG).show(); return; }
            CallStateManager.simulateIncoming("010-4444-5555");
        });
        findViewById(R.id.btnTestSmsPopup).setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "먼저 '다른 앱 위에 표시' 권한을 허용하세요", Toast.LENGTH_LONG).show(); return; }
            MessagePopupOverlayService.showMessage(this, "이영희", "010-4444-5555", "도착 10분 전에 블루투스로 전화 한번 줘!", false, false);
        });
        findViewById(R.id.btnTestEmergencyPopup).setOnClickListener(v -> {
            if (!sp.getBoolean("emergency_alerts_enabled", true)) {
                Toast.makeText(this, "긴급재난문자 수신이 꺼져 있습니다. 위 스위치를 켜주세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "먼저 '다른 앱 위에 표시' 권한을 허용하세요", Toast.LENGTH_LONG).show(); return; }
            String msg = "[행정안전부] 오늘 14:00 호우주의보 발효. 하천변·지하차도 진입 자제 바랍니다.";
            EmergencyAlertReceiver.saveAlert(this, "긴급재난문자", msg, System.currentTimeMillis());
            MessagePopupOverlayService.showMessage(this, "긴급재난문자", "", msg, true, false);
            reloadAll();
        });
    }

    private void requestRole(String role, String legacyAction) {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm.isRoleAvailable(role) && !rm.isRoleHeld(role)) {
                startActivityForResult(rm.createRequestRoleIntent(role), 100);
            } else {
                Toast.makeText(this, "이미 기본 앱으로 설정되어 있습니다", Toast.LENGTH_SHORT).show();
            }
        } else {
            startActivity(new Intent(legacyAction).putExtra("package", getPackageName()));
        }
    }

    private void refreshStatus() {
        TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
        boolean isDialer = getPackageName().equals(tm.getDefaultDialerPackage());
        boolean isSms = getPackageName().equals(Telephony.Sms.getDefaultSmsPackage(this));
        boolean overlay = Settings.canDrawOverlays(this);
        boolean emgOn = getSharedPreferences("dolphin_comms_prefs", MODE_PRIVATE).getBoolean("emergency_alerts_enabled", true);
        int hfpCnt = BtProfiles.hfpDevices().size();

        tvModeBadge.setText("전화: 블루투스(HFP " + hfpCnt + "대)  ·  문자/MMS: 차량 유심" + (emgOn ? " · 재난ON" : " · 재난OFF"));
        ((TextView) findViewById(R.id.tvDiagSummary)).setText(
            "• 통화 경로: 블루투스 HFP (" + hfpCnt + "대 연결됨 · Hidden API " + BtProfiles.availableHiddenApiCount() + "/6)\n" +
            "• 문자/MMS: 차량 내장 유심 송수신 (데이터 유심은 발신 차단 가능)\n" +
            "• 긴급재난문자(CBS): " + (emgOn ? "켜짐 (수신 및 팝업 알림 활성)" : "꺼짐 (수신 차단)") + "\n" +
            "• 기본 전화 앱: " + (isDialer ? "설정됨" : "미설정") + "  ·  기본 문자 앱: " + (isSms ? "설정됨" : "미설정") + "\n" +
            "• 작은 수신화면 오버레이(전화/문자): " + (overlay ? "허용됨" : "권한 필요")
        );
    }

    private void reloadAll() {
        bg.execute(() -> {
            List<CommsRepository.Contact> contacts = CommsRepository.loadContacts(this);
            Map<String, String> nameMap = CommsRepository.buildNameMap(contacts);
            List<CommsRepository.RecentItem> recents = CommsRepository.loadUnifiedRecents(this, nameMap, 250);
            List<CommsRepository.SmsThread> threads = CommsRepository.loadSmsThreads(this, nameMap);
            runOnUiThread(() -> {
                allContacts = contacts;
                allRecents = recents;
                allSmsThreads = threads;
                filterRecents();
                filterSmsThreads();
                filterContacts();
                if (openSmsThread != null) openThread(openSmsThread);
            });
        });
    }

    private void placeCall(String number) {
        String err = PhoneController.dial(this, number);
        if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show();
        else { dialBuffer.setLength(0); updateDialDisplay(); }
    }

    private class RecentsAdapter extends BaseAdapter {
        List<CommsRepository.RecentItem> items = new ArrayList<>();
        final SimpleDateFormat fmt = new SimpleDateFormat("M/d HH:mm", Locale.KOREA);
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup p) {
            if (cv == null) cv = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_contact_row, p, false);
            CommsRepository.RecentItem r = items.get(i);
            String prefix = r.kind == CommsRepository.RecentItem.KIND_EMERGENCY ? "🚨 "
                : (r.kind == CommsRepository.RecentItem.KIND_MMS ? "🖼 "
                : (r.kind == CommsRepository.RecentItem.KIND_SMS ? "💬 " : "📞 "));
            ((TextView) cv.findViewById(R.id.tvRowTitle)).setText(prefix + r.name + (r.count > 1 ? " (" + r.count + ")" : ""));
            String sub;
            if (r.kind == CommsRepository.RecentItem.KIND_CALL) {
                String t = r.type == 2 ? "발신(BT)" : (r.type == 3 ? "부재중(BT)" : "수신(BT)");
                sub = r.number + " · " + t + " · " + fmt.format(new Date(r.dateMs));
            } else {
                String tag = r.kind == CommsRepository.RecentItem.KIND_EMERGENCY ? "재난문자(유심)"
                    : (r.kind == CommsRepository.RecentItem.KIND_MMS ? "MMS(유심)" : "문자(유심)");
                sub = tag + " · " + r.preview + " · " + fmt.format(new Date(r.dateMs));
            }
            ((TextView) cv.findViewById(R.id.tvRowSub)).setText(sub);
            cv.findViewById(R.id.ivRowStar).setVisibility(View.GONE);
            return cv;
        }
    }

    private class ContactsAdapter extends BaseAdapter {
        List<CommsRepository.Contact> items = new ArrayList<>();
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup p) {
            if (cv == null) cv = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_contact_row, p, false);
            CommsRepository.Contact c = items.get(i);
            ((TextView) cv.findViewById(R.id.tvRowTitle)).setText(c.name);
            ((TextView) cv.findViewById(R.id.tvRowSub)).setText(c.label.isEmpty() ? c.number : c.number + " · " + c.label);
            ImageView star = cv.findViewById(R.id.ivRowStar);
            star.setVisibility(View.VISIBLE);
            star.setImageResource(c.starred ? R.drawable.ic_star_filled : R.drawable.ic_star_outline);
            star.setOnClickListener(v -> {
                boolean added = CommsRepository.toggleFavorite(MainActivity.this, c.number);
                Toast.makeText(MainActivity.this, added ? "즐겨찾기 추가" : "즐겨찾기 해제", Toast.LENGTH_SHORT).show();
                reloadAll();
            });
            return cv;
        }
    }

    private class SmsThreadsAdapter extends BaseAdapter {
        List<CommsRepository.SmsThread> items = new ArrayList<>();
        final SimpleDateFormat fmt = new SimpleDateFormat("M/d HH:mm", Locale.KOREA);
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup p) {
            if (cv == null) cv = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_contact_row, p, false);
            CommsRepository.SmsThread t = items.get(i);
            String badge = t.isEmergency ? "🚨 " : (t.isMms ? "[MMS] " : "");
            ((TextView) cv.findViewById(R.id.tvRowTitle)).setText((t.unread ? "● " : "") + badge + t.name);
            ((TextView) cv.findViewById(R.id.tvRowSub)).setText(t.snippet + " · " + fmt.format(new Date(t.dateMs)));
            cv.findViewById(R.id.ivRowStar).setVisibility(View.GONE);
            return cv;
        }
    }

    private class SmsMessagesAdapter extends BaseAdapter {
        List<CommsRepository.SmsMessage> items = new ArrayList<>();
        final SimpleDateFormat fmt = new SimpleDateFormat("M/d HH:mm", Locale.KOREA);
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup p) {
            if (cv == null) cv = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_sms_message, p, false);
            CommsRepository.SmsMessage m = items.get(i);
            ((TextView) cv.findViewById(R.id.tvMsgBody)).setText(m.body);
            String dir = m.isEmergency ? "재난문자" : (m.type == 2 ? (m.isMms ? "MMS 발신" : "유심 발신") : (m.isMms ? "MMS 수신" : "유심 수신"));
            ((TextView) cv.findViewById(R.id.tvMsgMeta)).setText(dir + " · " + fmt.format(new Date(m.dateMs)) + " (눌러서 복사)");
            ImageView iv = cv.findViewById(R.id.ivMmsThumb);
            if (m.imagePartId > 0) {
                iv.setVisibility(View.VISIBLE);
                iv.setImageBitmap(null);
                bg.execute(() -> {
                    Bitmap bmp = CommsRepository.loadMmsImage(MainActivity.this, m.imagePartId);
                    if (bmp != null) runOnUiThread(() -> iv.setImageBitmap(bmp));
                });
            } else {
                iv.setVisibility(View.GONE);
            }
            return cv;
        }
    }
}
