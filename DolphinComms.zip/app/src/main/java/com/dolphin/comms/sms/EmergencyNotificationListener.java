package com.dolphin.comms.sms;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import com.dolphin.comms.overlay.MessagePopupOverlayService;

/**
 * 시스템 재난문자(CellBroadcastReceiver) 알림 폴백 리스너.
 * ADB(cmd notification allow_listener)로 활성화하면 서드파티 앱에서도 CBS 재난문자를 누락 없이 수신합니다.
 */
public class EmergencyNotificationListener extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        String pkg = sbn.getPackageName() != null ? sbn.getPackageName().toLowerCase() : "";
        if (pkg.equals(getPackageName())) return;

        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence t = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence b = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (b == null) b = extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = t != null ? t.toString() : "";
        String body = b != null ? b.toString() : "";
        if (body.trim().isEmpty()) return;

        boolean fromCbs = pkg.contains("cellbroadcast") || EmergencyAlertReceiver.isEmergencyText(title, body);
        if (!fromCbs) return;

        SharedPreferences sp = getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
        if (!sp.getBoolean("emergency_alerts_enabled", true)) return;

        String sender = title.isEmpty() ? "긴급재난문자" : title;
        EmergencyAlertReceiver.saveAlert(this, sender, body.trim(), System.currentTimeMillis());
        if (sp.getBoolean("compact_popup", true)) {
            MessagePopupOverlayService.showMessage(this, sender, "", body.trim(), true, false);
        }
        sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(getPackageName()));
    }
}
