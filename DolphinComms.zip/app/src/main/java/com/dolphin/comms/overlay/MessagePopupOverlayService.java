package com.dolphin.comms.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.dolphin.comms.R;
import com.dolphin.comms.phone.PhoneController;
import com.dolphin.comms.ui.MainActivity;

/**
 * T전화 작은 수신화면 스타일의 문자 / MMS / 재난문자 팝업 (포그라운드 서비스 + 위로 드래그 닫기).
 */
public class MessagePopupOverlayService extends Service {
    private static final String CH_ID = "dolphin_msg_popup_fg";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_ADDR = "addr";
    private static final String EXTRA_BODY = "body";
    private static final String EXTRA_EMERGENCY = "emergency";
    private static final String EXTRA_MMS = "mms";

    public static void showMessage(Context ctx, String title, String addr, String body, boolean emergency, boolean mms) {
        if (!Settings.canDrawOverlays(ctx)) return;
        Intent i = new Intent(ctx, MessagePopupOverlayService.class)
            .putExtra(EXTRA_TITLE, title)
            .putExtra(EXTRA_ADDR, addr)
            .putExtra(EXTRA_BODY, body)
            .putExtra(EXTRA_EMERGENCY, emergency)
            .putExtra(EXTRA_MMS, mms);
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Throwable ignored) {}
    }

    private WindowManager wm;
    private View popupView;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable autoHide = this::dismissSelf;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH_ID, "문자/재난문자 팝업", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CH_ID)
            : new Notification.Builder(this);
        startForeground(1002, nb.setSmallIcon(R.drawable.ic_phone_call)
            .setContentTitle("Dolphin Comms")
            .setContentText("문자/재난문자 팝업 표시 중")
            .build());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { dismissSelf(); return START_NOT_STICKY; }
        String title = intent.getStringExtra(EXTRA_TITLE);
        String addr = intent.getStringExtra(EXTRA_ADDR);
        String body = intent.getStringExtra(EXTRA_BODY);
        boolean emergency = intent.getBooleanExtra(EXTRA_EMERGENCY, false);
        boolean mms = intent.getBooleanExtra(EXTRA_MMS, false);
        showPopup(title, addr, body, emergency, mms);
        return START_NOT_STICKY;
    }

    private void showPopup(String title, String addr, String body, boolean emergency, boolean mms) {
        ui.removeCallbacks(autoHide);
        if (popupView == null) {
            View v = LayoutInflater.from(this).inflate(R.layout.overlay_compact_message, null);
            int widthPx = Math.min((int) (getResources().getDisplayMetrics().density * 460),
                (int) (getResources().getDisplayMetrics().widthPixels * 0.92f));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                widthPx, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = getStatusBarOffsetPx() + (int) (getResources().getDisplayMetrics().density * 14);
            attachSwipeUp(v);
            wm.addView(v, lp);
            popupView = v;
        }

        TextView tvBadge = popupView.findViewById(R.id.tvMsgPopupBadge);
        TextView tvSender = popupView.findViewById(R.id.tvMsgPopupSender);
        TextView tvBody = popupView.findViewById(R.id.tvMsgPopupBody);
        TextView btnCall = popupView.findViewById(R.id.btnMsgPopupCall);

        if (emergency) {
            tvBadge.setText("🚨 긴급재난문자 (차량 유심)");
            tvBadge.setTextColor(0xFFF87171);
        } else if (mms) {
            tvBadge.setText("차량 유심 · MMS 수신");
            tvBadge.setTextColor(0xFFFBBF24);
        } else {
            tvBadge.setText("차량 유심 · 문자 수신");
            tvBadge.setTextColor(0xFFFBBF24);
        }

        tvSender.setText((title == null || title.isEmpty()) ? "새 문자" : title);
        tvBody.setText(body == null ? "" : body);

        popupView.findViewById(R.id.btnMsgPopupOpen).setOnClickListener(v -> {
            Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("open_tab", 3);
            startActivity(open);
            dismissSelf();
        });

        popupView.findViewById(R.id.btnMsgPopupCopy).setOnClickListener(v -> {
            ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("SMS", body));
            Toast.makeText(this, "문자 내용을 복사했습니다", Toast.LENGTH_SHORT).show();
            dismissSelf();
        });

        boolean canCall = !emergency && addr != null && !addr.trim().isEmpty();
        btnCall.setVisibility(canCall ? View.VISIBLE : View.GONE);
        if (canCall) {
            btnCall.setOnClickListener(v -> {
                PhoneController.dial(this, addr);
                dismissSelf();
            });
        }

        ui.postDelayed(autoHide, emergency ? 15000L : 8500L);
    }

    private void attachSwipeUp(View view) {
        final float threshold = getResources().getDisplayMetrics().density * 68f;
        final float[] downY = {0f};
        final boolean[] dragging = {false};
        view.setOnTouchListener((v, ev) -> {
            int act = ev.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN) {
                downY[0] = ev.getRawY();
                dragging[0] = false;
                return true;
            } else if (act == MotionEvent.ACTION_MOVE) {
                float dy = ev.getRawY() - downY[0];
                if (Math.abs(dy) > 10f) dragging[0] = true;
                if (dy < 0f) {
                    v.setTranslationY(dy);
                    v.setAlpha(Math.max(0.25f, 1f + dy / (threshold * 2.2f)));
                } else {
                    v.setTranslationY(dy * 0.15f);
                    v.setAlpha(1f);
                }
                return true;
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                float dy = ev.getRawY() - downY[0];
                if (dragging[0] && dy < -threshold) {
                    v.animate().translationY(-v.getHeight() - 80f).alpha(0f).setDuration(170L)
                        .withEndAction(this::dismissSelf).start();
                } else {
                    v.animate().translationY(0f).alpha(1f).setDuration(150L).start();
                }
                return dragging[0];
            }
            return false;
        });
    }

    private void dismissSelf() {
        ui.removeCallbacks(autoHide);
        if (popupView != null) {
            try { wm.removeView(popupView); } catch (Throwable ignored) {}
            popupView = null;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { dismissSelf(); super.onDestroy(); }
    private int getStatusBarOffsetPx() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int h = resId > 0 ? getResources().getDimensionPixelSize(resId) : 0;
        int minPx = (int) (getResources().getDisplayMetrics().density * 36);
        return Math.max(h, minPx);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
