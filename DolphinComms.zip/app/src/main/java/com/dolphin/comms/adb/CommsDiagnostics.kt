package com.dolphin.comms.adb

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import com.dolphin.comms.phone.BtProfiles
import com.dolphin.comms.phone.CallDebugLog
import com.dolphin.comms.phone.CallStateManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * BYD 돌핀 실차 종합 진단 수집기:
 * 1) 순정 통화 팝업의 실제 패키지/윈도우 타입
 * 2) HFP 프로필 및 숨김 메서드 시그니처
 * 3) 통화 받기/종료 1~4단계 실행 로그 및 통화 중 윈도우 스냅샷
 * 4) 연락처/BYD ContactProvider 및 ADB 캐시 건수
 * 5) 핸들 리모컨 전화 버튼 최근 이벤트(logcat)
 */
object CommsDiagnostics {
    data class Report(val text: String, val savedPath: String)

    @JvmStatic
    fun collect(context: Context): Report {
        val app = context.applicationContext
        val sb = StringBuilder()
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA).format(Date())
        sb.append("=== DolphinComms v1.3.2 실차 종합 진단 (").append(now).append(") ===\n")
        sb.append("Device: ").append(Build.MANUFACTURER).append(" / ").append(Build.MODEL)
            .append(" / Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")

        // 1. Roles & Permissions
        val tm = app.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        val isDialer = app.packageName == tm.defaultDialerPackage
        val isSms = app.packageName == Telephony.Sms.getDefaultSmsPackage(app)
        val overlay = Settings.canDrawOverlays(app)
        val adbOpen = NativeAdbClient.isPortOpen()
        sb.append("[1. 기본 앱 · 권한 · ADB]\n")
        sb.append("- DefaultDialer: ").append(tm.defaultDialerPackage).append(" (우리앱=").append(isDialer).append(")\n")
        sb.append("- DefaultSms: ").append(Telephony.Sms.getDefaultSmsPackage(app)).append(" (우리앱=").append(isSms).append(")\n")
        sb.append("- Overlay: ").append(overlay).append(" | LocalADB(5555) PortOpen: ").append(adbOpen).append("\n")
        val checkPerms = listOf(
            "android.permission.CALL_PHONE", "android.permission.ANSWER_PHONE_CALLS",
            "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG",
            "android.permission.BLUETOOTH_CONNECT", "android.permission.READ_SMS",
            "com.android.bluetooth.permission.READ_CONTENTPROVIDER"
        )
        sb.append("- Perms: ")
        sb.append(checkPerms.joinToString(", ") { p ->
            val shortName = p.substringAfterLast('.')
            "$shortName=${app.checkSelfPermission(p) == 0}"
        }).append("\n\n")

        // 2. Bluetooth HFP & Methods
        BtProfiles.init(app)
        val devs = BtProfiles.hfpDevices()
        sb.append("[2. 블루투스 HFP 프로필 & 메서드]\n")
        sb.append("- Connected HFP devices: ").append(devs.size).append("\n")
        for (d in devs) {
            sb.append("  * ").append(try { d.name } catch (_: Throwable) { "?" }).append(" / ").append(d.address).append("\n")
            val rawCalls = BtProfiles.rawCurrentCalls(d)
            sb.append("    liveRawCalls=").append(rawCalls.size).append("\n")
        }
        sb.append("- HFP Methods: ").append(BtProfiles.dumpHfpMethodSignatures()).append("\n")
        val cur = CallStateManager.currentCall()
        sb.append("- CurrentCall: ").append(if (cur == null) "none" else "state=${cur.state}, num=${cur.number}, via=${cur.via}").append("\n\n")

        // 3. Contacts & BYD ContactProvider
        sb.append("[3. 연락처 · BYD ContactProvider]\n")
        sb.append("- Android ContactsContract count: ").append(countUri(app, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)).append("\n")
        val bydUri = Uri.parse("content://com.android.bluetooth.contactprovider/contacts")
        sb.append("- BYD contactprovider (Direct): ").append(probeUri(app, bydUri)).append("\n")
        sb.append("- ADB Synced Contact Cache: ").append(BydAdbContactsSync.loadCached(app).size).append("건 (").append(BydAdbContactsSync.lastStatus).append(")\n")
        val bydCallLogUri = Uri.parse("content://com.android.calllogprovider/calls")
        sb.append("- BYD calllogprovider: ").append(probeUri(app, bydCallLogUri)).append("\n\n")

        // 4. ADB Deep Inspection
        sb.append("[4. 로컬 ADB 심층 진단]\n")
        if (adbOpen) {
            val echo = NativeAdbClient.executeShell(app, "echo ok", timeoutMs = 2500L)
            sb.append("- ADB Shell Auth: ").append(echo.success).append(" (").append(echo.message).append(")\n")
            if (echo.success) {
                val pkgs = NativeAdbClient.executeShell(app, "pm list packages | grep -iE 'phone|call|dial|telecom|bt|bluetooth|incall|systemui|launcher|customke'", timeoutMs = 4000L)
                sb.append("- Phone/BT/UI Packages:\n").append(pkgs.output.trim().take(3000)).append("\n")

                val disabled = NativeAdbClient.executeShell(app, "pm list packages -d", timeoutMs = 3000L)
                sb.append("- Disabled Packages:\n").append(disabled.output.trim().take(600)).append("\n")

                val wins = NativeAdbClient.executeShell(app, "dumpsys window windows | grep -iE 'Window #|mCurrentFocus|ty='", timeoutMs = 4500L)
                sb.append("- Active Windows/Overlays:\n").append(wins.output.trim().take(2500)).append("\n")

                val keys = NativeAdbClient.executeShell(app, "logcat -d -t 200 | grep -iE 'KEYCODE_CALL|KEYCODE_ENDCALL|HeadsetClient|bluetoothcall|byd.*call|byd.*phone|AG_CALL|acceptCall|terminateCall|Steering|KeyEvent|customke' | tail -n 35", timeoutMs = 4500L)
                sb.append("- Recent Steering/Call Logcat:\n").append(keys.output.trim().take(2000)).append("\n")
            }
        } else {
            sb.append("- 127.0.0.1:5555 닫힘 (차량 무선/로컬 ADB 미활성)\n")
        }
        sb.append("\n")

        // 5. Call Control Trace Log (includes auto InCall Window Snapshot)
        sb.append("[5. 최근 통화 받기/종료 실행 추적 & 통화 중 윈도우 스냅샷]\n")
        sb.append(CallDebugLog.dump()).append("\n")

        val reportText = sb.toString()
        val savedPath = saveToFile(app, reportText)
        return Report(reportText, savedPath)
    }

    private fun countUri(ctx: Context, uri: Uri): String {
        return try {
            ctx.contentResolver.query(uri, arrayOf("_id"), null, null, null)?.use { c -> "${c.count}" } ?: "null cursor"
        } catch (t: Throwable) {
            "ERR(${t.javaClass.simpleName}: ${t.message})"
        }
    }

    private fun probeUri(ctx: Context, uri: Uri): String {
        return try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c: Cursor ->
                val cols = c.columnNames.joinToString(",")
                "count=${c.count}, cols=[$cols]"
            } ?: "null cursor"
        } catch (t: Throwable) {
            "ERR(${t.javaClass.simpleName}: ${t.message})"
        }
    }

    private fun saveToFile(ctx: Context, text: String): String {
        try {
            val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (dl != null && (dl.exists() || dl.mkdirs())) {
                val f = File(dl, "dolphin_comms_diag.txt")
                f.writeText(text, Charsets.UTF_8)
                return f.absolutePath
            }
        } catch (_: Throwable) {}
        return try {
            val f = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "dolphin_comms_diag.txt")
            f.writeText(text, Charsets.UTF_8)
            f.absolutePath
        } catch (_: Throwable) {
            ""
        }
    }
}
