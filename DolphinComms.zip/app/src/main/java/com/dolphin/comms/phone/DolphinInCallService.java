package com.dolphin.comms.phone;

import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;

public class DolphinInCallService extends InCallService {
    private static volatile DolphinInCallService instance;
    public static DolphinInCallService get() { return instance; }

    private final Call.Callback cb = new Call.Callback() {
        @Override public void onStateChanged(Call call, int state) {
            CallStateManager.onTelecomCallUpdated(call);
        }
        @Override public void onDetailsChanged(Call call, Call.Details details) {
            CallStateManager.onTelecomCallUpdated(call);
        }
    };

    @Override public void onCreate() { super.onCreate(); instance = this; }
    @Override public void onDestroy() { instance = null; super.onDestroy(); }

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        call.registerCallback(cb);
        CallStateManager.onTelecomCallUpdated(call);
    }

    @Override public void onCallRemoved(Call call) {
        super.onCallRemoved(call);
        call.unregisterCallback(cb);
        CallStateManager.onTelecomCallRemoved(call);
    }

    @Override public void onCallAudioStateChanged(CallAudioState state) {
        super.onCallAudioStateChanged(state);
        if (state != null) CallStateManager.onAudioMuted(state.isMuted());
    }
}
