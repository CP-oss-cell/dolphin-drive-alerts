package com.dolphin.comms.phone;

import android.bluetooth.BluetoothDevice;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class HfpCall {
    public static final int ACTIVE = 0;
    public static final int HELD = 1;
    public static final int DIALING = 2;
    public static final int ALERTING = 3;
    public static final int INCOMING = 4;
    public static final int WAITING = 5;
    public static final int HELD_BY_RAH = 6;
    public static final int TERMINATED = 7;

    private static final Pattern P_ID = Pattern.compile("mId:\\s*(\\d+)");
    private static final Pattern P_STATE = Pattern.compile("mState:\\s*([A-Z_]+|\\d+)");
    private static final Pattern P_NUM = Pattern.compile("mNumber:\\s*([^,}]*)");
    private static final Pattern P_OUT = Pattern.compile("mOutgoing:\\s*(true|false)");

    public int id;
    public int state = -1;
    public String number = "";
    public boolean outgoing;
    public String deviceAddress;
    public long activeSinceMs;
    public String via = "unknown";

    public boolean isRinging() { return state == INCOMING || state == WAITING; }
    public boolean isDialing() { return state == DIALING || state == ALERTING; }
    public boolean isActive() { return state == ACTIVE || state == HELD; }

    public static HfpCall from(Parcelable p) {
        if (p == null) return null;
        HfpCall c = fromGetters(p);
        if (c == null) c = fromParcel(p);
        if (c == null) c = fromString(p.toString());
        return c;
    }

    private static HfpCall fromGetters(Object o) {
        try {
            Class<?> cls = o.getClass();
            HfpCall c = new HfpCall();
            c.id = (Integer) cls.getMethod("getId").invoke(o);
            c.state = (Integer) cls.getMethod("getState").invoke(o);
            Object num = cls.getMethod("getNumber").invoke(o);
            c.number = num instanceof String ? (String) num : "";
            c.outgoing = (Boolean) cls.getMethod("isOutgoing").invoke(o);
            Object dev = cls.getMethod("getDevice").invoke(o);
            if (dev instanceof BluetoothDevice) c.deviceAddress = ((BluetoothDevice) dev).getAddress();
            c.via = "getter";
            return c;
        } catch (Throwable t) {
            return null;
        }
    }

    private static HfpCall fromParcel(Parcelable p) {
        Parcel parcel = Parcel.obtain();
        try {
            p.writeToParcel(parcel, 0);
            parcel.setDataPosition(0);
            HfpCall c = new HfpCall();
            BluetoothDevice dev = parcel.readParcelable(BluetoothDevice.class.getClassLoader());
            if (dev != null) c.deviceAddress = dev.getAddress();
            c.id = parcel.readInt();
            String uuid = parcel.readString();
            c.state = parcel.readInt();
            String num = parcel.readString();
            c.number = num != null ? num : "";
            parcel.readInt();
            c.outgoing = parcel.readInt() == 1;
            parcel.readInt();
            UUID.fromString(uuid);
            if (c.state < 0 || c.state > 7 || c.id < 0 || c.id > 10000) return null;
            int avail = parcel.dataAvail();
            c.via = avail == 20 ? "parcel/BYD20" : "parcel/AOSP";
            return c;
        } catch (Throwable t) {
            return null;
        } finally {
            parcel.recycle();
        }
    }

    private static HfpCall fromString(String raw) {
        if (raw == null) return null;
        Matcher sm = P_STATE.matcher(raw);
        if (!sm.find()) return null;
        int st = parseState(sm.group(1));
        if (st < 0) return null;
        HfpCall c = new HfpCall();
        c.state = st;
        Matcher im = P_ID.matcher(raw);
        if (im.find()) c.id = Integer.parseInt(im.group(1));
        Matcher nm = P_NUM.matcher(raw);
        if (nm.find()) c.number = nm.group(1).trim();
        Matcher om = P_OUT.matcher(raw);
        if (om.find()) c.outgoing = Boolean.parseBoolean(om.group(1));
        c.via = "toString";
        return c;
    }

    private static int parseState(String s) {
        if ("ACTIVE".equals(s)) return ACTIVE;
        if ("HELD".equals(s)) return HELD;
        if ("DIALING".equals(s)) return DIALING;
        if ("ALERTING".equals(s)) return ALERTING;
        if ("INCOMING".equals(s)) return INCOMING;
        if ("WAITING".equals(s)) return WAITING;
        if ("HELD_BY_RESPONSE_AND_HOLD".equals(s)) return HELD_BY_RAH;
        if ("TERMINATED".equals(s)) return TERMINATED;
        try { return Integer.parseInt(s); } catch (Throwable t) { return -1; }
    }
}
