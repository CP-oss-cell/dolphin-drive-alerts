package com.dolphin.comms;

import android.app.Application;
import android.os.Build;
import com.dolphin.comms.phone.BtProfiles;
import com.dolphin.comms.phone.CallStateManager;
import java.lang.reflect.Method;

public class DolphinCommsApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        exemptHiddenApis();
        BtProfiles.init(this);
        CallStateManager.start(this);
    }

    private void exemptHiddenApis() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return;
        try {
            Method forName = Class.class.getDeclaredMethod("forName", String.class);
            Method getDeclaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, Class[].class);
            Class<?> vmRuntimeCls = (Class<?>) forName.invoke(null, "dalvik.system.VMRuntime");
            Method getRuntime = (Method) getDeclaredMethod.invoke(vmRuntimeCls, "getRuntime", new Class[0]);
            Method setExemptions = (Method) getDeclaredMethod.invoke(vmRuntimeCls, "setHiddenApiExemptions", new Class[]{String[].class});
            Object runtime = getRuntime.invoke(null);
            setExemptions.invoke(runtime, new Object[]{new String[]{"Landroid/bluetooth/", "Landroid/telecom/"}});
        } catch (Throwable ignored) {}
    }
}
