package com.dolphin.comms.sms;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

/**
 * 차량 유심 SMS 및 MMS 발신 컨트롤러 (결과 콜백 기반 Sent/Failed 기록 + MmsService URI 권한 부여).
 */
public final class SmsController {
    private static final String ACTION_SMS_SENT = "com.dolphin.comms.SMS_SENT";
    private static final String ACTION_MMS_SENT = "com.dolphin.comms.MMS_SENT";
    private static boolean receiverRegistered;

    private SmsController() {}

    public static synchronized void ensureSentReceiver(Context ctx) {
        if (receiverRegistered) return;
        receiverRegistered = true;
        Context app = ctx.getApplicationContext();
        BroadcastReceiver br = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent intent) {
                int code = getResultCode();
                boolean isMms = ACTION_MMS_SENT.equals(intent.getAction());
                String addr = intent.getStringExtra("addr");
                String body = intent.getStringExtra("body");
                if (code == Activity.RESULT_OK) {
                    if (!isMms && addr != null && body != null) {
                        saveSmsBox(c, Telephony.Sms.Sent.CONTENT_URI, addr, body);
                    }
                    Toast.makeText(c, isMms ? "MMS 발송 완료" : "문자 발송 완료", Toast.LENGTH_SHORT).show();
                } else {
                    if (!isMms && addr != null && body != null) {
                        saveSmsBox(c, Telephony.Sms.Outbox.CONTENT_URI, addr, "[발신실패] " + body);
                    }
                    Toast.makeText(c, (isMms ? "MMS" : "문자") + " 발신 실패 (데이터 전용 유심은 통신사가 발신을 차단할 수 있음)", Toast.LENGTH_LONG).show();
                }
                c.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(c.getPackageName()));
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_SMS_SENT);
        f.addAction(ACTION_MMS_SENT);
        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(br, f, Context.RECEIVER_NOT_EXPORTED);
        else app.registerReceiver(br, f);
    }

    private static void saveSmsBox(Context c, Uri boxUri, String addr, String body) {
        try {
            ContentValues cv = new ContentValues();
            cv.put(Telephony.Sms.ADDRESS, addr);
            cv.put(Telephony.Sms.BODY, body);
            cv.put(Telephony.Sms.DATE, System.currentTimeMillis());
            cv.put(Telephony.Sms.READ, 1);
            c.getContentResolver().insert(boxUri, cv);
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings("deprecation")
    private static SmsManager getSmsManager(Context ctx) {
        if (Build.VERSION.SDK_INT >= 31) {
            SmsManager sm = ctx.getSystemService(SmsManager.class);
            if (sm != null) return sm;
        }
        return SmsManager.getDefault();
    }

    public static String sendSms(Context ctx, String address, String body) {
        String addr = address == null ? "" : address.trim();
        String msg = body == null ? "" : body.trim();
        if (addr.isEmpty() || msg.isEmpty()) return "받는 번호와 내용을 입력하세요";
        ensureSentReceiver(ctx);
        try {
            SmsManager sm = getSmsManager(ctx);
            ArrayList<String> parts = sm.divideMessage(msg);
            Intent sentIntent = new Intent(ACTION_SMS_SENT)
                .setPackage(ctx.getPackageName())
                .putExtra("addr", addr)
                .putExtra("body", msg);
            PendingIntent pi = PendingIntent.getBroadcast(
                ctx, (int) (System.currentTimeMillis() & 0xFFFF), sentIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            if (parts.size() > 1) {
                ArrayList<PendingIntent> pis = new ArrayList<>();
                for (int i = 0; i < parts.size(); i++) pis.add(i == 0 ? pi : null);
                sm.sendMultipartTextMessage(addr, null, parts, pis, null);
            } else {
                sm.sendTextMessage(addr, null, msg, pi, null);
            }
            return null;
        } catch (Throwable t) {
            return "문자 발신 오류: " + t.getMessage();
        }
    }

    public static String sendMms(Context ctx, String address, String body, Uri imageUri) {
        String addr = address == null ? "" : address.trim();
        if (addr.isEmpty()) return "받는 번호를 입력하세요";
        ensureSentReceiver(ctx);
        try {
            byte[] pdu = MmsPduHelper.buildSendReqPdu(ctx, addr, body, imageUri);
            String fn = "mms_out_" + System.currentTimeMillis() + ".pdu";
            File pduFile = new File(ctx.getCacheDir(), fn);
            try (FileOutputStream fos = new FileOutputStream(pduFile)) {
                fos.write(pdu);
            }
            Uri contentUri = MmsTempProvider.buildUri(fn);
            try {
                ctx.grantUriPermission("com.android.mms.service", contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Throwable ignored) {}
            PendingIntent pi = PendingIntent.getBroadcast(
                ctx, (int) (System.currentTimeMillis() & 0xFFFF),
                new Intent(ACTION_MMS_SENT).setPackage(ctx.getPackageName()),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            getSmsManager(ctx).sendMultimediaMessage(ctx, contentUri, null, null, pi);
            return null;
        } catch (Throwable t) {
            return "MMS 발신 오류: " + t.getMessage();
        }
    }
}
