package com.dolphin.comms.sms;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public class MmsTempProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dolphin.comms.mms";

    public static Uri buildUri(String fileName) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(fileName).build();
    }

    @Override public boolean onCreate() { return true; }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        if (getContext() == null) return null;
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("..")) return null;
        File file = new File(getContext().getCacheDir(), name);
        String[] cols = (projection != null && projection.length > 0)
            ? projection
            : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor mc = new MatrixCursor(cols, 1);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = name;
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = file.exists() ? file.length() : 0L;
            else row[i] = null;
        }
        mc.addRow(row);
        return mc;
    }

    @Override
    public String getType(Uri uri) {
        String name = uri != null ? uri.getLastPathSegment() : null;
        if (name != null && name.endsWith(".txt")) return "text/plain";
        return "application/vnd.wap.mms-message";
    }

    @Override public Uri insert(Uri u, ContentValues cv) { return null; }
    @Override public int delete(Uri u, String s, String[] sa) { return 0; }
    @Override public int update(Uri u, ContentValues cv, String s, String[] sa) { return 0; }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (getContext() == null) throw new FileNotFoundException("No context");
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("..")) throw new FileNotFoundException("Invalid name");
        File file = new File(getContext().getCacheDir(), name);
        int flags = (mode != null && mode.contains("w"))
            ? (ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_TRUNCATE)
            : ParcelFileDescriptor.MODE_READ_ONLY;
        return ParcelFileDescriptor.open(file, flags);
    }
}
