package com.dolphin.comms.sms;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * 외부 라이브러리 없이 순수 Java로 최소 MMS 1.2 SendReq PDU를 생성합니다.
 */
public final class MmsPduHelper {
    private MmsPduHelper() {}

    public static byte[] buildSendReqPdu(Context ctx, String recipient, String text, Uri imageUri) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            // X-Mms-Message-Type: m-send-req (0x80)
            out.write(0x8C); out.write(0x80);
            // X-Mms-Transaction-ID
            out.write(0x98);
            writeTextString(out, "dc" + System.currentTimeMillis());
            // X-Mms-MMS-Version: 1.2 (0x92)
            out.write(0x8D); out.write(0x92);
            // From: insert-address-token (0x81)
            out.write(0x89); out.write(0x01); out.write(0x81);
            // To: <recipient>/TYPE=PLMN
            out.write(0x97);
            writeEncodedString(out, recipient + "/TYPE=PLMN");
            // Content-Type: application/vnd.wap.multipart.related (0xB3)
            out.write(0x84); out.write(0xB3);

            byte[] jpegBytes = imageUri != null ? compressImage(ctx, imageUri) : null;
            byte[] textBytes = (text != null && !text.isEmpty()) ? text.getBytes(StandardCharsets.UTF_8) : new byte[0];

            int partCount = (textBytes.length > 0 ? 1 : 0) + (jpegBytes != null ? 1 : 0);
            if (partCount == 0) {
                textBytes = " ".getBytes(StandardCharsets.UTF_8);
                partCount = 1;
            }
            writeUintVar(out, partCount);

            if (textBytes.length > 0) {
                // Header: text/plain; charset=utf-8
                ByteArrayOutputStream hdr = new ByteArrayOutputStream();
                hdr.write(0x03); // value len
                hdr.write(0x83); // text/plain (0x03 | 0x80)
                hdr.write(0x81); // charset
                hdr.write(0xEA); // utf-8 (106 | 0x80)
                byte[] hBytes = hdr.toByteArray();
                writeUintVar(out, hBytes.length);
                writeUintVar(out, textBytes.length);
                out.write(hBytes);
                out.write(textBytes);
            }

            if (jpegBytes != null) {
                ByteArrayOutputStream hdr = new ByteArrayOutputStream();
                hdr.write(0x9E); // image/jpeg (0x1E | 0x80)
                byte[] hBytes = hdr.toByteArray();
                writeUintVar(out, hBytes.length);
                writeUintVar(out, jpegBytes.length);
                out.write(hBytes);
                out.write(jpegBytes);
            }
        } catch (Throwable ignored) {}
        return out.toByteArray();
    }

    private static byte[] compressImage(Context ctx, Uri uri) {
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            if (is == null) return null;
            Bitmap raw = BitmapFactory.decodeStream(is);
            if (raw == null) return null;
            int maxDim = 960;
            int w = raw.getWidth(), h = raw.getHeight();
            Bitmap scaled = raw;
            if (w > maxDim || h > maxDim) {
                float r = Math.min((float) maxDim / w, (float) maxDim / h);
                scaled = Bitmap.createScaledBitmap(raw, Math.max(1, (int) (w * r)), Math.max(1, (int) (h * r)), true);
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 78, baos);
            if (scaled != raw) scaled.recycle();
            raw.recycle();
            return baos.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }

    private static void writeTextString(ByteArrayOutputStream out, String s) {
        out.write(s.getBytes(StandardCharsets.US_ASCII), 0, s.length());
        out.write(0x00);
    }

    private static void writeEncodedString(ByteArrayOutputStream out, String s) {
        byte[] data = s.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream inner = new ByteArrayOutputStream();
        inner.write(0xEA); // utf-8
        inner.write(data, 0, data.length);
        inner.write(0x00);
        byte[] b = inner.toByteArray();
        writeUintVar(out, b.length);
        out.write(b, 0, b.length);
    }

    private static void writeUintVar(ByteArrayOutputStream out, int val) {
        byte[] buf = new byte[5];
        int idx = 4;
        buf[idx] = (byte) (val & 0x7F);
        val >>>= 7;
        while (val > 0 && idx > 0) {
            idx--;
            buf[idx] = (byte) ((val & 0x7F) | 0x80);
            val >>>= 7;
        }
        out.write(buf, idx, 5 - idx);
    }
}
