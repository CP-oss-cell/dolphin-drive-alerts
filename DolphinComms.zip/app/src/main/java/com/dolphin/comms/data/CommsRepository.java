package com.dolphin.comms.data;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;
import com.dolphin.comms.adb.BydAdbContactsSync;
import com.dolphin.comms.phone.BtProfiles;
import com.dolphin.comms.sms.EmergencyAlertReceiver;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * [전화: 블루투스 HFP/PBAP] + [문자/MMS/재난문자: 차량 유심] 통합 저장소.
 */
public final class CommsRepository {
    private static final Uri BYD_CONTACTS_URI = Uri.parse("content://com.android.bluetooth.contactprovider/contacts");
    private static final Uri BYD_CALLLOG_URI = Uri.parse("content://com.android.calllogprovider/calls");
    private static final Uri MMS_PART_URI = Uri.parse("content://mms/part");
    private static final char[] CHO = {'ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'};

    public static final class Contact {
        public String name = "";
        public String number = "";
        public String label = "";
        public boolean starred;
        public String searchKey = "";
    }

    public static final class RecentItem {
        public static final int KIND_CALL = 0;
        public static final int KIND_SMS = 1;
        public static final int KIND_MMS = 2;
        public static final int KIND_EMERGENCY = 3;

        public int kind = KIND_CALL;
        public String name = "";
        public String number = "";
        public String preview = "";
        public int type; // CallLog type or 1=수신,2=발신
        public long dateMs;
        public int count = 1;
        public long threadId = -1;
    }

    public static final class SmsThread {
        public long threadId;
        public String address = "";
        public String name = "";
        public String snippet = "";
        public long dateMs;
        public boolean unread;
        public boolean isMms;
        public boolean isEmergency;
    }

    public static final class SmsMessage {
        public long id;
        public String address = "";
        public String body = "";
        public long dateMs;
        public int type; // 1=수신, 2=발신
        public boolean isMms;
        public boolean isEmergency;
        public long imagePartId = -1;
        public String localImagePath = "";
    }

    private CommsRepository() {}

    public static String digits(String raw) {
        if (raw == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if ((c >= '0' && c <= '9') || c == '+' || c == '*' || c == '#') sb.append(c);
        }
        String s = sb.toString();
        return s.startsWith("+82") ? "0" + s.substring(3) : s;
    }

    public static String pretty(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        String f = PhoneNumberUtils.formatNumber(raw, "KR");
        return f != null ? f : raw;
    }

    public static String initials(String text) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= 0xAC00 && c <= 0xD7A3) sb.append(CHO[(c - 0xAC00) / 588]);
            else if (!Character.isWhitespace(c)) sb.append(Character.toLowerCase(c));
        }
        return sb.toString();
    }

    public static Set<String> loadLocalFavorites(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("dolphin_comms_favs", Context.MODE_PRIVATE);
        Set<String> out = new HashSet<>();
        try {
            JSONArray arr = new JSONArray(sp.getString("digits", "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(arr.getString(i));
        } catch (Throwable ignored) {}
        return out;
    }

    public static boolean toggleFavorite(Context ctx, String number) {
        String d = digits(number);
        if (d.isEmpty()) return false;
        Set<String> set = loadLocalFavorites(ctx);
        boolean added = set.contains(d) ? !set.remove(d) : set.add(d);
        JSONArray arr = new JSONArray();
        for (String s : set) arr.put(s);
        ctx.getSharedPreferences("dolphin_comms_favs", Context.MODE_PRIVATE)
            .edit().putString("digits", arr.toString()).apply();
        return added;
    }

    public static List<Contact> loadContacts(Context ctx) {
        Map<String, Contact> byDigits = new LinkedHashMap<>();
        Set<String> localFavs = loadLocalFavorites(ctx);

        try (Cursor c = ctx.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.STARRED
                }, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String num = c.getString(1);
                    String d = digits(num);
                    if (d.isEmpty() || byDigits.containsKey(d)) continue;
                    Contact item = new Contact();
                    item.number = num.trim();
                    String nm = c.getString(0);
                    item.name = (nm != null && !nm.trim().isEmpty()) ? nm.trim() : item.number;
                    item.starred = c.getInt(2) == 1 || localFavs.contains(d);
                    item.searchKey = item.name.toLowerCase(Locale.ROOT) + " " + initials(item.name) + " " + d;
                    byDigits.put(d, item);
                }
            }
        } catch (Throwable ignored) {}

        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        String mac = devs.isEmpty() ? null : devs.get(0).getAddress();
        try (Cursor c = ctx.getContentResolver().query(BYD_CONTACTS_URI, null, null, null, null)) {
            if (c != null) {
                int iName = c.getColumnIndex("pb_name");
                int iNum = c.getColumnIndex("pb_number");
                int iLbl = c.getColumnIndex("pb_lable");
                int iMac = c.getColumnIndex("mac_address");
                if (iName >= 0 && iNum >= 0) {
                    while (c.moveToNext()) {
                        if (mac != null && iMac >= 0) {
                            String rowMac = c.getString(iMac);
                            if (rowMac != null && !mac.equalsIgnoreCase(rowMac)) continue;
                        }
                        String num = c.getString(iNum);
                        String d = digits(num);
                        if (d.isEmpty() || byDigits.containsKey(d)) continue;
                        Contact item = new Contact();
                        item.number = num.trim();
                        String nm = c.getString(iName);
                        item.name = (nm != null && !nm.trim().isEmpty()) ? nm.trim() : item.number;
                        item.label = iLbl >= 0 && c.getString(iLbl) != null ? c.getString(iLbl).trim() : "";
                        item.starred = localFavs.contains(d);
                        item.searchKey = item.name.toLowerCase(Locale.ROOT) + " " + initials(item.name) + " " + d;
                        byDigits.put(d, item);
                    }
                }
            }
        } catch (Throwable ignored) {}

        for (BydAdbContactsSync.CachedContact cc : BydAdbContactsSync.loadCached(ctx)) {
            if (mac != null && !cc.getMac().isEmpty() && !mac.equalsIgnoreCase(cc.getMac())) continue;
            String d = digits(cc.getNumber());
            if (d.isEmpty() || byDigits.containsKey(d)) continue;
            Contact item = new Contact();
            item.number = cc.getNumber().trim();
            item.name = cc.getName().trim().isEmpty() ? item.number : cc.getName().trim();
            item.label = cc.getLabel().trim();
            item.starred = localFavs.contains(d);
            item.searchKey = item.name.toLowerCase(Locale.ROOT) + " " + initials(item.name) + " " + d;
            byDigits.put(d, item);
        }

        for (Contact lc : LocalContactsStore.loadAll(ctx)) {
            String d = digits(lc.number);
            if (d.isEmpty() || byDigits.containsKey(d)) continue;
            lc.starred = localFavs.contains(d);
            lc.searchKey = lc.name.toLowerCase(Locale.ROOT) + " " + initials(lc.name) + " " + d;
            byDigits.put(d, lc);
        }

        List<Contact> list = new ArrayList<>(byDigits.values());
        Collator coll = Collator.getInstance(Locale.KOREAN);
        Collections.sort(list, (a, b) -> coll.compare(a.name, b.name));
        return list;
    }

    public static Map<String, String> buildNameMap(List<Contact> contacts) {
        Map<String, String> map = new HashMap<>();
        for (Contact c : contacts) map.put(digits(c.number), c.name);
        return map;
    }

    /**
     * 통합 최근기록: 블루투스 통화기록 + 유심 SMS/MMS + 재난문자 시간순 병합.
     */
    public static List<RecentItem> loadUnifiedRecents(Context ctx, Map<String, String> nameMap, int limit) {
        List<RecentItem> calls = new ArrayList<>();
        try (Cursor c = ctx.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE},
                null, null, CallLog.Calls.DATE + " DESC")) {
            if (c != null) {
                while (c.moveToNext() && calls.size() < limit) {
                    RecentItem r = new RecentItem();
                    r.kind = RecentItem.KIND_CALL;
                    r.number = c.getString(0) != null ? c.getString(0) : "";
                    String nm = c.getString(1);
                    r.name = (nm != null && !nm.isEmpty()) ? nm : nameMap.getOrDefault(digits(r.number), r.number);
                    r.type = c.getInt(2);
                    r.dateMs = c.getLong(3);
                    appendGroupedCall(calls, r);
                }
            }
        } catch (Throwable ignored) {}

        if (calls.isEmpty()) {
            try (Cursor c = ctx.getContentResolver().query(BYD_CALLLOG_URI, null, null, null, null)) {
                if (c != null) {
                    String[] cols = c.getColumnNames();
                    int iNum = findCol(cols, "number", "phone"), iName = findCol(cols, "name"),
                        iType = findCol(cols, "type"), iDate = findCol(cols, "date", "time");
                    if (iNum >= 0) {
                        while (c.moveToNext() && calls.size() < limit) {
                            RecentItem r = new RecentItem();
                            r.kind = RecentItem.KIND_CALL;
                            r.number = c.getString(iNum) != null ? c.getString(iNum) : "";
                            String nm = iName >= 0 ? c.getString(iName) : null;
                            r.name = (nm != null && !nm.isEmpty()) ? nm : nameMap.getOrDefault(digits(r.number), r.number);
                            r.type = iType >= 0 ? c.getInt(iType) : 1;
                            r.dateMs = iDate >= 0 ? c.getLong(iDate) : System.currentTimeMillis();
                            appendGroupedCall(calls, r);
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }

        List<RecentItem> merged = new ArrayList<>(calls);
        List<SmsThread> threads = loadSmsThreads(ctx, nameMap);
        for (SmsThread t : threads) {
            RecentItem r = new RecentItem();
            r.kind = t.isEmergency ? RecentItem.KIND_EMERGENCY : (t.isMms ? RecentItem.KIND_MMS : RecentItem.KIND_SMS);
            r.name = t.name;
            r.number = t.address;
            r.preview = t.snippet;
            r.dateMs = t.dateMs;
            r.threadId = t.threadId;
            merged.add(r);
        }

        Collections.sort(merged, (a, b) -> Long.compare(b.dateMs, a.dateMs));
        if (merged.size() > limit) return merged.subList(0, limit);
        return merged;
    }

    private static int findCol(String[] cols, String... keys) {
        for (int i = 0; i < cols.length; i++) {
            String lc = cols[i].toLowerCase(Locale.ROOT);
            for (String k : keys) if (lc.contains(k)) return i;
        }
        return -1;
    }

    private static void appendGroupedCall(List<RecentItem> list, RecentItem r) {
        if (!list.isEmpty()) {
            RecentItem last = list.get(list.size() - 1);
            if (last.kind == RecentItem.KIND_CALL && last.type == r.type && digits(last.number).equals(digits(r.number))) {
                last.count++;
                return;
            }
        }
        list.add(r);
    }

    public static List<SmsThread> loadSmsThreads(Context ctx, Map<String, String> nameMap) {
        Map<String, SmsThread> byKey = new LinkedHashMap<>();

        // 1. SMS
        try (Cursor c = ctx.getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                new String[]{Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.READ},
                null, null, Telephony.Sms.DATE + " DESC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    String addr = c.getString(1);
                    if (addr == null || addr.trim().isEmpty()) continue;
                    String key = digits(addr);
                    if (key.isEmpty()) key = addr.trim();
                    if (byKey.containsKey(key)) continue;
                    SmsThread t = new SmsThread();
                    t.threadId = c.getLong(0);
                    t.address = addr.trim();
                    t.name = nameMap.getOrDefault(digits(addr), pretty(t.address));
                    t.snippet = c.getString(2) != null ? c.getString(2) : "";
                    t.dateMs = c.getLong(3);
                    t.unread = c.getInt(4) == 0;
                    t.isEmergency = EmergencyAlertReceiver.isEmergencyText(t.address, t.snippet);
                    byKey.put(key, t);
                }
            }
        } catch (Throwable ignored) {}

        // 2. MMS (차량 유심 멀티미디어 문자)
        try (Cursor c = ctx.getContentResolver().query(
                Telephony.Mms.CONTENT_URI,
                new String[]{Telephony.Mms._ID, Telephony.Mms.THREAD_ID, Telephony.Mms.DATE, Telephony.Mms.READ, Telephony.Mms.SUBJECT},
                null, null, Telephony.Mms.DATE + " DESC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    long mmsId = c.getLong(0);
                    long tid = c.getLong(1);
                    long dateMs = c.getLong(2) * 1000L;
                    boolean unread = c.getInt(3) == 0;
                    String addr = getMmsAddress(ctx, mmsId);
                    if (addr.isEmpty()) addr = "MMS";
                    String key = digits(addr);
                    if (key.isEmpty()) key = addr;
                    MmsPartSummary part = readMmsPartSummary(ctx, mmsId);
                    String snip = !part.text.isEmpty() ? part.text : (part.imagePartId > 0 ? "[사진 첨부 MMS]" : "(MMS)");
                    SmsThread existing = byKey.get(key);
                    if (existing == null || dateMs > existing.dateMs) {
                        SmsThread t = new SmsThread();
                        t.threadId = tid;
                        t.address = addr;
                        t.name = nameMap.getOrDefault(digits(addr), pretty(addr));
                        t.snippet = snip;
                        t.dateMs = dateMs;
                        t.unread = unread;
                        t.isMms = true;
                        byKey.put(key, t);
                    }
                }
            }
        } catch (Throwable ignored) {}

        // 2-b. 로컬 다운로드 MMS (기본 문자 앱 수신 시 MmsDownloadedReceiver 저장분)
        try {
            SharedPreferences spMms = ctx.getSharedPreferences("dolphin_local_mms", Context.MODE_PRIVATE);
            JSONArray arrMms = new JSONArray(spMms.getString("items", "[]"));
            for (int i = 0; i < arrMms.length(); i++) {
                JSONObject o = arrMms.getJSONObject(i);
                String addr = o.optString("sender", "MMS");
                String key = digits(addr);
                if (key.isEmpty()) key = addr;
                long dMs = o.optLong("dateMs", 0L);
                SmsThread ex = byKey.get(key);
                if (ex == null || dMs > ex.dateMs) {
                    SmsThread t = new SmsThread();
                    t.threadId = -500;
                    t.address = addr;
                    t.name = nameMap.getOrDefault(digits(addr), pretty(addr));
                    t.snippet = o.optString("body", "[MMS]");
                    t.dateMs = dMs;
                    t.isMms = true;
                    byKey.put(key, t);
                }
            }
        } catch (Throwable ignored) {}

        // 3. 저장된 긴급재난문자(CBS)
        try {
            SharedPreferences sp = ctx.getSharedPreferences("dolphin_emergency_alerts", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("items", "[]"));
            if (arr.length() > 0) {
                JSONObject top = arr.getJSONObject(0);
                SmsThread t = new SmsThread();
                t.threadId = -999;
                t.address = "긴급재난문자";
                t.name = "🚨 긴급재난문자 (CBS)";
                t.snippet = top.optString("body", "");
                t.dateMs = top.optLong("dateMs", System.currentTimeMillis());
                t.isEmergency = true;
                byKey.put("EMERGENCY_CBS", t);
            }
        } catch (Throwable ignored) {}

        List<SmsThread> list = new ArrayList<>(byKey.values());
        Collections.sort(list, (a, b) -> Long.compare(b.dateMs, a.dateMs));
        return list;
    }

    public static List<SmsMessage> loadSmsMessages(Context ctx, long threadId, String address) {
        List<SmsMessage> list = new ArrayList<>();
        if (threadId == -999) {
            try {
                SharedPreferences sp = ctx.getSharedPreferences("dolphin_emergency_alerts", Context.MODE_PRIVATE);
                JSONArray arr = new JSONArray(sp.getString("items", "[]"));
                for (int i = arr.length() - 1; i >= 0; i--) {
                    JSONObject o = arr.getJSONObject(i);
                    SmsMessage m = new SmsMessage();
                    m.address = o.optString("sender", "긴급재난문자");
                    m.body = o.optString("body", "");
                    m.dateMs = o.optLong("dateMs", 0L);
                    m.type = 1;
                    m.isEmergency = true;
                    list.add(m);
                }
            } catch (Throwable ignored) {}
            return list;
        }

        String sel = threadId > 0 ? Telephony.Sms.THREAD_ID + "=?" : Telephony.Sms.ADDRESS + "=?";
        String arg = threadId > 0 ? String.valueOf(threadId) : address;
        try (Cursor c = ctx.getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                new String[]{Telephony.Sms._ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE},
                sel, new String[]{arg}, Telephony.Sms.DATE + " ASC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    SmsMessage m = new SmsMessage();
                    m.id = c.getLong(0);
                    m.address = c.getString(1);
                    m.body = c.getString(2) != null ? c.getString(2) : "";
                    m.dateMs = c.getLong(3);
                    m.type = c.getInt(4);
                    m.isEmergency = EmergencyAlertReceiver.isEmergencyText(m.address, m.body);
                    list.add(m);
                }
            }
        } catch (Throwable ignored) {}

        if (threadId > 0) {
            try (Cursor c = ctx.getContentResolver().query(
                    Telephony.Mms.CONTENT_URI,
                    new String[]{Telephony.Mms._ID, Telephony.Mms.DATE, Telephony.Mms.MESSAGE_BOX},
                    Telephony.Mms.THREAD_ID + "=?", new String[]{String.valueOf(threadId)},
                    Telephony.Mms.DATE + " ASC")) {
                if (c != null) {
                    while (c.moveToNext()) {
                        long mmsId = c.getLong(0);
                        MmsPartSummary p = readMmsPartSummary(ctx, mmsId);
                        SmsMessage m = new SmsMessage();
                        m.id = mmsId;
                        m.address = address;
                        m.body = !p.text.isEmpty() ? p.text : "[MMS 첨부 이미지]";
                        m.dateMs = c.getLong(1) * 1000L;
                        m.type = c.getInt(2) == Telephony.Mms.MESSAGE_BOX_SENT ? 2 : 1;
                        m.isMms = true;
                        m.imagePartId = p.imagePartId;
                        list.add(m);
                    }
                }
            } catch (Throwable ignored) {}
        }

        try {
            SharedPreferences spMms = ctx.getSharedPreferences("dolphin_local_mms", Context.MODE_PRIVATE);
            JSONArray arrMms = new JSONArray(spMms.getString("items", "[]"));
            String targetDigits = digits(address);
            for (int i = 0; i < arrMms.length(); i++) {
                JSONObject o = arrMms.getJSONObject(i);
                String s = o.optString("sender", "");
                if (s.equals(address) || (!targetDigits.isEmpty() && targetDigits.equals(digits(s)))) {
                    SmsMessage m = new SmsMessage();
                    m.address = s;
                    m.body = o.optString("body", "");
                    m.dateMs = o.optLong("dateMs", 0L);
                    m.type = 1;
                    m.isMms = true;
                    m.localImagePath = o.optString("imgPath", "");
                    list.add(m);
                }
            }
        } catch (Throwable ignored) {}

        Collections.sort(list, (a, b) -> Long.compare(a.dateMs, b.dateMs));
        return list;
    }

    private static String getMmsAddress(Context ctx, long mmsId) {
        Uri uri = Uri.parse("content://mms/" + mmsId + "/addr");
        try (Cursor c = ctx.getContentResolver().query(uri, new String[]{"address", "type"}, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String addr = c.getString(0);
                    if (addr != null && !addr.equals("insert-address-token")) return addr;
                }
            }
        } catch (Throwable ignored) {}
        return "";
    }

    private static final class MmsPartSummary {
        String text = "";
        long imagePartId = -1;
    }

    private static MmsPartSummary readMmsPartSummary(Context ctx, long mmsId) {
        MmsPartSummary sum = new MmsPartSummary();
        try (Cursor c = ctx.getContentResolver().query(
                MMS_PART_URI, new String[]{"_id", "ct", "text"},
                "mid=?", new String[]{String.valueOf(mmsId)}, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    long pid = c.getLong(0);
                    String ct = c.getString(1);
                    if ("text/plain".equals(ct)) {
                        String t = c.getString(2);
                        if (t != null) sum.text = t;
                    } else if (ct != null && ct.startsWith("image/")) {
                        sum.imagePartId = pid;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return sum;
    }

    public static Bitmap loadMmsImage(Context ctx, long partId) {
        if (partId <= 0) return null;
        try (InputStream is = ctx.getContentResolver().openInputStream(Uri.withAppendedPath(MMS_PART_URI, String.valueOf(partId)))) {
            return is != null ? BitmapFactory.decodeStream(is) : null;
        } catch (Throwable t) {
            return null;
        }
    }

    public static String resolveNameQuick(Context ctx, String rawNumber) {
        String d = digits(rawNumber);
        if (d.isEmpty()) return rawNumber == null ? "" : rawNumber;
        try (Cursor c = ctx.getContentResolver().query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(rawNumber)),
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String nm = c.getString(0);
                if (nm != null && !nm.trim().isEmpty()) return nm.trim();
            }
        } catch (Throwable ignored) {}
        try (Cursor c = ctx.getContentResolver().query(BYD_CONTACTS_URI, null, null, null, null)) {
            if (c != null) {
                int iName = c.getColumnIndex("pb_name");
                int iNum = c.getColumnIndex("pb_number");
                if (iName >= 0 && iNum >= 0) {
                    while (c.moveToNext()) {
                        if (d.equals(digits(c.getString(iNum)))) {
                            String nm = c.getString(iName);
                            if (nm != null && !nm.trim().isEmpty()) return nm.trim();
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
        for (BydAdbContactsSync.CachedContact cc : BydAdbContactsSync.loadCached(ctx)) {
            if (d.equals(digits(cc.getNumber())) && !cc.getName().trim().isEmpty()) {
                return cc.getName().trim();
            }
        }
        for (Contact lc : LocalContactsStore.loadAll(ctx)) {
            if (d.equals(digits(lc.number)) && lc.name != null && !lc.name.trim().isEmpty()) {
                return lc.name.trim();
            }
        }
        return pretty(rawNumber);
    }

    public static void markThreadRead(Context ctx, long threadId, String address) {
        try {
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put("read", 1);
            if (threadId > 0) {
                ctx.getContentResolver().update(Telephony.Sms.CONTENT_URI, cv, Telephony.Sms.THREAD_ID + "=? AND read=0", new String[]{String.valueOf(threadId)});
                ctx.getContentResolver().update(Telephony.Mms.CONTENT_URI, cv, Telephony.Mms.THREAD_ID + "=? AND read=0", new String[]{String.valueOf(threadId)});
            } else if (address != null && !address.isEmpty()) {
                ctx.getContentResolver().update(Telephony.Sms.CONTENT_URI, cv, Telephony.Sms.ADDRESS + "=? AND read=0", new String[]{address});
            }
        } catch (Throwable ignored) {}
    }
}
