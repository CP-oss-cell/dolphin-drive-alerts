package com.dolphin.comms.adb

import android.content.Context
import android.os.SystemClock
import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * 주행보조 앱(DolphinDriveAlerts)에서 검증된 BYD 돌핀 로컬 ADB(127.0.0.1:5555) 클라이언트.
 */
object NativeAdbClient {
    private const val CONNECT_TIMEOUT_MS = 2_500L
    private const val SHELL_TIMEOUT_MS = 5_000L

    private val lock = Any()
    private var connection: Dadb? = null
    private var connectedHost: String? = null

    data class ShellResult(
        val success: Boolean,
        val exitCode: Int,
        val output: String,
        val message: String
    )

    @JvmStatic
    fun isPortOpen(host: String = "127.0.0.1", port: Int = 5555): Boolean {
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), 400) }
            true
        } catch (_: Exception) {
            false
        }
    }

    @JvmStatic
    fun executeShell(
        context: Context,
        command: String,
        host: String = "127.0.0.1",
        port: Int = 5555,
        timeoutMs: Long = SHELL_TIMEOUT_MS
    ): ShellResult = synchronized(lock) {
        try {
            val adb = getConnection(context.applicationContext, host, port)
            val result = AtomicReference<ShellResult?>()
            val error = AtomicReference<Throwable?>()
            val thread = Thread({
                try {
                    val response = adb.shell(command)
                    val output = response.allOutput
                    val success = response.exitCode == 0
                    result.set(
                        ShellResult(
                            success = success,
                            exitCode = response.exitCode,
                            output = output,
                            message = if (success) "ok" else output.trim().ifBlank { "exit=${response.exitCode}" }
                        )
                    )
                } catch (t: Throwable) {
                    error.set(t)
                }
            }, "dolphin-comms-adb-shell").apply { isDaemon = true }

            thread.start()
            thread.join(timeoutMs)
            if (thread.isAlive) {
                thread.interrupt()
                closeLocked()
                return@synchronized ShellResult(false, -1, "", "ADB shell ${timeoutMs}ms 시간 초과")
            }

            error.get()?.let { throw if (it is Exception) it else Exception(it) }
            result.get() ?: ShellResult(false, -1, "", "ADB shell 결과 없음")
        } catch (e: Exception) {
            closeLocked()
            ShellResult(false, -1, "", e.message ?: e.javaClass.simpleName)
        }
    }

    @JvmStatic
    fun waitForAuthorization(
        context: Context,
        maxWaitMs: Long = 30_000L,
        host: String = "127.0.0.1",
        port: Int = 5555,
        onProgress: (String) -> Unit = {}
    ): ShellResult {
        val end = SystemClock.elapsedRealtime() + maxWaitMs.coerceIn(2_000L, 60_000L)
        var last = ShellResult(false, -1, "", "ADB 승인 대기")
        while (SystemClock.elapsedRealtime() < end) {
            if (Thread.currentThread().isInterrupted) {
                close()
                return ShellResult(false, -1, "", "ADB 승인 대기 취소됨")
            }
            if (!isPortOpen(host, port)) {
                last = ShellResult(false, -1, "", "$host:$port 포트가 닫혀 있습니다")
                onProgress("차량 로컬 ADB(5555) 포트 대기 중...")
            } else {
                onProgress("로컬 ADB 연결 중 · RSA 승인 팝업이 뜨면 '항상 허용'을 눌러주세요")
                last = executeShell(context, "echo dolphin_comms_adb_ok", host, port, 3_000L)
                if (last.success && last.output.contains("dolphin_comms_adb_ok")) {
                    onProgress("로컬 ADB 인증 완료! 권한을 일괄 부여합니다...")
                    return last
                }
                onProgress("RSA 승인 대기 중: " + last.message.take(100))
            }
            try {
                Thread.sleep(1_500L)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                close()
                return ShellResult(false, -1, "", "ADB 승인 대기 취소됨")
            }
        }
        return last.copy(message = "ADB 승인 시간 초과: ${last.message}")
    }

    @JvmStatic
    fun close() = synchronized(lock) { closeLocked() }

    private fun getConnection(context: Context, host: String, port: Int): Dadb {
        connection?.takeIf { connectedHost == "$host:$port" }?.let { return it }
        closeLocked()
        val privateKey = File(context.filesDir, "adbkey")
        val publicKey = File(context.filesDir, "adbkey.pub")
        if (!privateKey.exists() || !publicKey.exists()) {
            AdbKeyPair.generate(privateKey, publicKey)
        }
        val keyPair = AdbKeyPair.read(privateKey, publicKey)
        return createWithTimeout(host, port, keyPair).also {
            connection = it
            connectedHost = "$host:$port"
        }
    }

    private fun createWithTimeout(host: String, port: Int, keyPair: AdbKeyPair): Dadb {
        val result = AtomicReference<Dadb?>()
        val error = AtomicReference<Throwable?>()
        val cancelled = AtomicBoolean(false)
        val thread = Thread({
            try {
                val candidate = Dadb.create(host, port, keyPair)
                if (cancelled.get()) runCatching { candidate.close() }
                else result.set(candidate)
            } catch (t: Throwable) {
                error.set(t)
            }
        }, "dolphin-comms-adb-connect").apply { isDaemon = true }
        thread.start()
        thread.join(CONNECT_TIMEOUT_MS)
        if (thread.isAlive) {
            cancelled.set(true)
            thread.interrupt()
            runCatching { result.getAndSet(null)?.close() }
            throw IllegalStateException("RSA 승인 대기 또는 연결 시간 초과")
        }
        error.get()?.let { throw if (it is Exception) it else Exception(it) }
        return result.get() ?: throw IllegalStateException("ADB 연결 결과 없음")
    }

    private fun closeLocked() {
        try { connection?.close() } catch (_: Exception) {}
        connection = null
        connectedHost = null
    }
}
