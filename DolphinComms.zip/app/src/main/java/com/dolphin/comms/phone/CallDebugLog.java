package com.dolphin.comms.phone;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

public final class CallDebugLog {
    private static final int MAX = 60;
    private static final ArrayDeque<String> RING = new ArrayDeque<>();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss.SSS", Locale.KOREA);

    private CallDebugLog() {}

    public static synchronized void log(String msg) {
        String line = FMT.format(new Date()) + " " + msg;
        if (RING.size() >= MAX) RING.removeFirst();
        RING.addLast(line);
    }

    public static synchronized String dump() {
        if (RING.isEmpty()) return "(통화 제어 기록 없음 - 수신/종료 버튼을 한 번 누른 뒤 진단하세요)";
        StringBuilder sb = new StringBuilder();
        for (String s : RING) sb.append(s).append("\n");
        return sb.toString().trim();
    }
}
