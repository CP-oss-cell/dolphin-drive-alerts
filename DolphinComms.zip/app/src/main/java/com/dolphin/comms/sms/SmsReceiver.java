package com.dolphin.comms.sms;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import com.dolphin.comms.R;
import com.dolphin.comms.data.CommsRepository;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import com.dolphin.comms.ui.MainActivity;

public class SmsReceiver extends BroadcastReceiver {
    public static final String ACTION_SMS_UPDATED = "com.dolphin.comms.SMS_UPDATED";
    private static final String CH_ID = "dolphin_sms_ch";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String act = intent.getAction();
        boolean isDeliver = Telephony.Sms.Intents.SMS_DELIVER_ACTION.equals(act);
        boolean isReceived = Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(act);
        if (!isDeliver && !isReceived) return;

        // 기본 문자 앱일 때는 SMS_DELIVER만 처리해 중복 알림/팝업 방지
        String defaultSmsPkg = Telephony.Sms.getDefaultSmsPackage(context);
        boolean weAreDefault = context.getPackageName().equals(defaultSmsPkg);
        if (weAreDefault && isReceived) return;

        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (msgs == null || msgs.length == 0) return;

        String sender = msgs[0].getDisplayOriginatingAddress();
        long time = msgs[0].getTimestampMillis();
        StringBuilder body = new StringBuilder();
        for (SmsMessage m : msgs) {
            if (m.getMessageBody() != null) body.append(m.getMessageBody());
        }
        String text = body.toString();

        SharedPreferences sp = context.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
        boolean isEmergency = EmergencyAlertReceiver.isEmergencyText(sender, text);
        if (isEmergency) {
            if (!sp.getBoolean("emergency_alerts_enabled", true)) return;
            EmergencyAlertReceiver.saveAlert(context, sender, text, time);
        }

        if (isDeliver) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(Telephony.Sms.ADDRESS, sender);
                cv.put(Telephony.Sms.BODY, text);
                cv.put(Telephony.Sms.DATE, time);
                cv.put(Telephony.Sms.READ, 0);
                context.getContentResolver().insert(Telephony.Sms.Inbox.CONTENT_URI, cv);
            } catch (Throwable ignored) {}
        }

        String displayName = CommsRepository.resolveNameQuick(context, sender);
        showNotification(context, displayName, text, isEmergency);

        if (sp.getBoolean("compact_popup", true)) {
            MessagePopupOverlayService.showMessage(context, displayName, sender, text, isEmergency, false);
        }

        context.sendBroadcast(new Intent(ACTION_SMS_UPDATED).setPackage(context.getPackageName()));
    }

    private void showNotification(Context ctx, String sender, String text, boolean isEmergency) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH_ID, "유심 문자/재난문자", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent open = new Intent(ctx, MainActivity.class).putExtra("open_tab", 3);
        PendingIntent pi = PendingIntent.getActivity(ctx, 2001, open,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(ctx, CH_ID)
            : new Notification.Builder(ctx);
        nb.setSmallIcon(R.drawable.ic_phone_call)
            .setContentTitle((isEmergency ? "[재난문자] " : "[유심 수신] ") + sender)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi);
        nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), nb.build());
    }
}
