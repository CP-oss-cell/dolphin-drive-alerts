package com.dolphin.comms.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.TextView;
import com.dolphin.comms.R;
import com.dolphin.comms.data.CommsRepository;
import com.dolphin.comms.phone.CallStateManager;
import com.dolphin.comms.phone.HfpCall;
import com.dolphin.comms.phone.PhoneController;
import java.util.Locale;

/**
 * 시안 A 다크 글래스 루미너스 플로팅 수신 팝업:
 * - 위로 드래그해 숨기면 자유 이동 가능한 미니 필 표시(마지막 위치 기억)
 * - 순정 우상단 팝업 덮기 모드 시 우상단(360x287) 위에 Z-order 최상단 배치
 */
public class IncomingCallOverlayService extends Service implements CallStateManager.Listener {
    private static final String ACTION_SHOW = "com.dolphin.comms.overlay.SHOW";
    private static final String ACTION_DISMISS = "com.dolphin.comms.overlay.DISMISS";
    private static final String CH_ID = "dolphin_comms_call";
    private static final String PREFS = "dolphin_comms_prefs";

    public static void showOrUpdate(Context ctx) {
        if (!Settings.canDrawOverlays(ctx)) return;
        Intent i = new Intent(ctx, IncomingCallOverlayService.class).setAction(ACTION_SHOW);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
        else ctx.startService(i);
    }

    public static void dismiss(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, IncomingCallOverlayService.class));
        } catch (Throwable ignored) {}
    }

    private WindowManager wm;
    private View popupView;
    private WindowManager.LayoutParams popupLp;
    private View miniPillView;
    private WindowManager.LayoutParams miniLp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean dtmfVisible;
    private boolean dismissedToMini;
    private String dismissedCallKey = null;
    private int lastRenderedState = -1;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            HfpCall c = CallStateManager.currentCall();
            if (c != null && c.isActive() && c.activeSinceMs > 0) {
                long sec = Math.max(0, (SystemClock.elapsedRealtime() - c.activeSinceMs) / 1000L);
                String t = String.format(Locale.KOREA, "%02d:%02d", sec / 60, sec % 60);
                if (popupView != null) ((TextView) popupView.findViewById(R.id.tvPopupState)).setText("블루투스 통화 중 · " + t);
                if (miniPillView != null) ((TextView) miniPillView.findViewById(R.id.tvMiniStatus)).setText("📞 통화 중 " + t + " · 이동 / 탭 열기");
                ui.postDelayed(this, 1000L);
            }
        }
    };

    private final Runnable raiseZOrder = () -> {
        if (popupView != null && popupLp != null && !dismissedToMini) {
            try {
                wm.removeViewImmediate(popupView);
                wm.addView(popupView, popupLp);
            } catch (Throwable ignored) {}
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH_ID, "블루투스 통화 팝업", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_ID) : new Notification.Builder(this);
        startForeground(1001, nb.setContentTitle("Dolphin Comms").setContentText("작은 수신화면 모드 실행 중")
            .setSmallIcon(R.drawable.ic_phone_call).setOngoing(true).build());
        CallStateManager.addListener(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACTION_DISMISS.equals(act)) {
            removeAllViews();
            stopSelf();
        } else if (ACTION_SHOW.equals(act)) {
            HfpCall c = CallStateManager.currentCall();
            if (c != null) {
                String key = callKey(c);
                if (!key.equals(dismissedCallKey)) {
                    dismissedToMini = false;
                    dismissedCallKey = null;
                }
                if (dismissedToMini) showMiniPill(c);
                else renderCall(c);
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onCallChanged(HfpCall call) {
        if (call == null) {
            removeAllViews();
            stopSelf();
            return;
        }
        String key = callKey(call);
        if (!key.equals(dismissedCallKey)) {
            dismissedToMini = false;
            dismissedCallKey = null;
        }
        if (!dismissedToMini) renderCall(call);
        else showMiniPill(call);
    }

    private void renderCall(HfpCall call) {
        removeMiniPill();
        boolean coverStock = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("cover_stock_popup", true);
        DisplayMetrics dm = getResources().getDisplayMetrics();

        if (popupView == null) {
            View v = LayoutInflater.from(this).inflate(R.layout.overlay_compact_call, null);
            int widthPx = coverStock
                ? Math.max((int) (dm.density * 372), 372)
                : Math.min((int) (dm.density * 460), (int) (dm.widthPixels * 0.92f));
            if (coverStock) {
                v.setMinimumHeight(Math.max((int) (dm.density * 296), 296));
            }
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                widthPx, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSLUCENT);
            if (coverStock) {
                lp.gravity = Gravity.TOP | Gravity.END;
                lp.x = 0;
                lp.y = 0;
            } else {
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.x = 0;
                lp.y = getStatusBarOffsetPx() + (int) (dm.density * 14);
            }
            attachSwipeUp(v);
            bindButtons(v);
            wm.addView(v, lp);
            popupView = v;
            popupLp = lp;
        }

        String rawNum = (call.number == null || call.number.isEmpty()) ? "" : call.number;
        String disp = rawNum.isEmpty() ? "발신번호 표시제한" : CommsRepository.resolveNameQuick(this, rawNum);
        String subNum = rawNum.isEmpty() ? "블루투스(HFP) 통화" : CommsRepository.pretty(rawNum) + " · 블루투스(HFP)";
        ((TextView) popupView.findViewById(R.id.tvPopupName)).setText(disp);
        ((TextView) popupView.findViewById(R.id.tvPopupNumber)).setText(subNum);
        String avatarCh = (!disp.isEmpty() && Character.isDigit(disp.charAt(0))) ? "☎" : disp.substring(0, 1);
        ((TextView) popupView.findViewById(R.id.tvPopupAvatar)).setText(avatarCh);
        ((TextView) popupView.findViewById(R.id.tvPopupState)).setText(
            call.isRinging() ? "블루투스 전화가 걸려왔습니다" : (call.isDialing() ? "블루투스 발신 중…" : "블루투스 통화 중"));

        popupView.findViewById(R.id.rowIncomingActions).setVisibility(call.isRinging() ? View.VISIBLE : View.GONE);
        popupView.findViewById(R.id.rowActiveActions).setVisibility(!call.isRinging() ? View.VISIBLE : View.GONE);
        popupView.findViewById(R.id.gridPopupDtmf).setVisibility(!call.isRinging() && dtmfVisible ? View.VISIBLE : View.GONE);

        // 통화 상태가 바뀔 때(수신 -> 통화중) 순정 우상단 팝업보다 Z-order를 위로 재정렬
        if (coverStock && call.state != lastRenderedState) {
            lastRenderedState = call.state;
            ui.removeCallbacks(raiseZOrder);
            ui.postDelayed(raiseZOrder, 450L);
        }

        ui.removeCallbacks(tick);
        if (call.isActive()) ui.post(tick);
    }

    private void attachSwipeUp(View view) {
        final float threshold = getResources().getDisplayMetrics().density * 72f;
        final float[] downY = {0f};
        final boolean[] dragging = {false};
        view.setOnTouchListener((v, ev) -> {
            int act = ev.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN) {
                downY[0] = ev.getRawY();
                dragging[0] = false;
                return true;
            } else if (act == MotionEvent.ACTION_MOVE) {
                float dy = ev.getRawY() - downY[0];
                if (Math.abs(dy) > 10f) dragging[0] = true;
                if (dy < 0f) {
                    v.setTranslationY(dy);
                    v.setAlpha(Math.max(0.25f, 1f + dy / (threshold * 2.2f)));
                } else {
                    v.setTranslationY(dy * 0.15f);
                    v.setAlpha(1f);
                }
                return true;
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                float dy = ev.getRawY() - downY[0];
                if (dragging[0] && dy < -threshold) {
                    v.animate().translationY(-v.getHeight() - 80f).alpha(0f).setDuration(180L).withEndAction(() -> {
                        dismissedToMini = true;
                        HfpCall c = CallStateManager.currentCall();
                        dismissedCallKey = c != null ? callKey(c) : null;
                        removePopupOnly();
                        if (c != null) showMiniPill(c);
                    }).start();
                } else {
                    v.animate().translationY(0f).alpha(1f).setDuration(160L).start();
                }
                return dragging[0];
            }
            return false;
        });
    }

    private void bindButtons(View v) {
        v.findViewById(R.id.btnPopupAccept).setOnClickListener(x -> PhoneController.accept(this));
        v.findViewById(R.id.btnPopupReject).setOnClickListener(x -> PhoneController.endOrReject(this, true));
        v.findViewById(R.id.btnPopupEnd).setOnClickListener(x -> PhoneController.endOrReject(this, false));
        v.findViewById(R.id.btnPopupMute).setOnClickListener(btn -> {
            boolean next = !CallStateManager.isMuted();
            PhoneController.setMuted(this, next);
            ((TextView) btn).setText(next ? "음소거 중" : "음소거");
        });
        v.findViewById(R.id.btnPopupDtmf).setOnClickListener(x -> {
            dtmfVisible = !dtmfVisible;
            v.findViewById(R.id.gridPopupDtmf).setVisibility(dtmfVisible ? View.VISIBLE : View.GONE);
        });

        GridLayout grid = v.findViewById(R.id.gridPopupDtmf);
        String[] keys = {"1","2","3","4","5","6","7","8","9","*","0","#"};
        for (String k : keys) {
            TextView tv = new TextView(this);
            tv.setText(k);
            tv.setTextSize(18f);
            tv.setTextColor(0xFFF4F8FF);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 14, 0, 14);
            tv.setBackgroundResource(R.drawable.bg_key_button);
            tv.setOnClickListener(x -> PhoneController.sendDtmf(k.charAt(0)));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(5, 5, 5, 5);
            grid.addView(tv, lp);
        }
    }

    private void showMiniPill(HfpCall call) {
        if (miniPillView != null) {
            ((TextView) miniPillView.findViewById(R.id.tvMiniStatus)).setText(
                call.isRinging() ? "📞 수신 중 · 이동 / 탭 열기" : "📞 통화 중 · 이동 / 탭 열기");
            return;
        }
        View pill = LayoutInflater.from(this).inflate(R.layout.overlay_mini_pill, null);
        ((TextView) pill.findViewById(R.id.tvMiniStatus)).setText(
            call.isRinging() ? "📞 수신 중 · 이동 / 탭 열기" : "📞 통화 중 · 이동 / 탭 열기");

        DisplayMetrics dm = getResources().getDisplayMetrics();
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        int defaultX = Math.max(16, (dm.widthPixels - (int) (dm.density * 240)) / 2);
        int defaultY = getStatusBarOffsetPx() + (int) (dm.density * 10);
        int savedX = sp.getInt("mini_pill_x", defaultX);
        int savedY = sp.getInt("mini_pill_y", defaultY);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Math.max(0, Math.min(savedX, dm.widthPixels - 80));
        lp.y = Math.max(0, Math.min(savedY, dm.heightPixels - 60));

        // 자유 드래그 이동 + 마지막 위치 저장 + 짧은 탭으로 팝업 다시 열기
        final int[] startLp = {0, 0};
        final float[] downRaw = {0f, 0f};
        final boolean[] moved = {false};
        pill.setOnTouchListener((v, ev) -> {
            int act = ev.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN) {
                startLp[0] = lp.x;
                startLp[1] = lp.y;
                downRaw[0] = ev.getRawX();
                downRaw[1] = ev.getRawY();
                moved[0] = false;
                return true;
            } else if (act == MotionEvent.ACTION_MOVE) {
                float dx = ev.getRawX() - downRaw[0];
                float dy = ev.getRawY() - downRaw[1];
                if (Math.hypot(dx, dy) > 12f) moved[0] = true;
                if (moved[0]) {
                    int maxX = Math.max(0, dm.widthPixels - v.getWidth());
                    int maxY = Math.max(0, dm.heightPixels - v.getHeight());
                    lp.x = Math.max(0, Math.min(startLp[0] + (int) dx, maxX));
                    lp.y = Math.max(0, Math.min(startLp[1] + (int) dy, maxY));
                    try { wm.updateViewLayout(v, lp); } catch (Throwable ignored) {}
                }
                return true;
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                if (moved[0]) {
                    sp.edit().putInt("mini_pill_x", lp.x).putInt("mini_pill_y", lp.y).apply();
                } else {
                    dismissedToMini = false;
                    dismissedCallKey = null;
                    HfpCall c = CallStateManager.currentCall();
                    if (c != null) renderCall(c);
                }
                return true;
            }
            return false;
        });

        wm.addView(pill, lp);
        miniPillView = pill;
        miniLp = lp;
        ui.removeCallbacks(tick);
        if (call.isActive()) ui.post(tick);
    }

    private void removePopupOnly() {
        ui.removeCallbacks(raiseZOrder);
        if (popupView != null) { try { wm.removeView(popupView); } catch (Throwable ignored) {} popupView = null; popupLp = null; }
    }
    private void removeMiniPill() {
        if (miniPillView != null) { try { wm.removeView(miniPillView); } catch (Throwable ignored) {} miniPillView = null; miniLp = null; }
    }
    private void removeAllViews() {
        ui.removeCallbacks(tick);
        ui.removeCallbacks(raiseZOrder);
        removePopupOnly();
        removeMiniPill();
        dtmfVisible = false;
        dismissedToMini = false;
        dismissedCallKey = null;
        lastRenderedState = -1;
    }

    @Override public void onDestroy() {
        CallStateManager.removeListener(this);
        removeAllViews();
        super.onDestroy();
    }

    private String callKey(HfpCall c) {
        String d = CommsRepository.digits(c.number);
        return !d.isEmpty() ? d : ("id:" + c.id);
    }

    private int getStatusBarOffsetPx() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int h = resId > 0 ? getResources().getDimensionPixelSize(resId) : 0;
        int minPx = (int) (getResources().getDisplayMetrics().density * 36);
        return Math.max(h, minPx);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
