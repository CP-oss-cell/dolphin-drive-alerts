package com.dolphin.comms.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.TextView;
import com.dolphin.comms.R;
import com.dolphin.comms.phone.CallStateManager;
import com.dolphin.comms.phone.HfpCall;
import com.dolphin.comms.phone.PhoneController;
import java.util.Locale;

/**
 * T전화 스타일 작은 수신화면 모드 팝업 (위로 드래그하여 숨기기).
 */
public class IncomingCallOverlayService extends Service implements CallStateManager.Listener {
    private static final String ACTION_SHOW = "com.dolphin.comms.overlay.SHOW";
    private static final String ACTION_DISMISS = "com.dolphin.comms.overlay.DISMISS";
    private static final String CH_ID = "dolphin_comms_call";

    public static void showOrUpdate(Context ctx) {
        if (!Settings.canDrawOverlays(ctx)) return;
        Intent i = new Intent(ctx, IncomingCallOverlayService.class).setAction(ACTION_SHOW);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
        else ctx.startService(i);
    }

    public static void dismiss(Context ctx) {
        try {
            ctx.stopService(new Intent(ctx, IncomingCallOverlayService.class));
        } catch (Throwable ignored) {}
    }

    private WindowManager wm;
    private View popupView;
    private View miniPillView;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean dtmfVisible;
    private boolean dismissedToMini;
    private String dismissedCallKey = null;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            HfpCall c = CallStateManager.currentCall();
            if (c != null && c.isActive() && c.activeSinceMs > 0) {
                long sec = Math.max(0, (SystemClock.elapsedRealtime() - c.activeSinceMs) / 1000L);
                String t = String.format(Locale.KOREA, "%02d:%02d", sec / 60, sec % 60);
                if (popupView != null) ((TextView) popupView.findViewById(R.id.tvPopupState)).setText("블루투스 통화 중 · " + t);
                if (miniPillView != null) ((TextView) miniPillView.findViewById(R.id.tvMiniStatus)).setText("통화 중 " + t + " · 눌러서 열기");
                ui.postDelayed(this, 1000L);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH_ID, "블루투스 통화 팝업", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_ID) : new Notification.Builder(this);
        startForeground(1001, nb.setContentTitle("Dolphin Comms").setContentText("작은 수신화면 모드 실행 중")
            .setSmallIcon(R.drawable.ic_phone_call).setOngoing(true).build());
        CallStateManager.addListener(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent != null ? intent.getAction() : null;
        if (ACTION_DISMISS.equals(act)) {
            removeAllViews();
            stopSelf();
        } else if (ACTION_SHOW.equals(act)) {
            HfpCall c = CallStateManager.currentCall();
            if (c != null) {
                String key = callKey(c);
                if (!key.equals(dismissedCallKey)) {
                    dismissedToMini = false;
                    dismissedCallKey = null;
                }
                if (dismissedToMini) showMiniPill(c);
                else renderCall(c);
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onCallChanged(HfpCall call) {
        if (call == null) {
            removeAllViews();
            stopSelf();
            return;
        }
        String key = callKey(call);
        if (!key.equals(dismissedCallKey)) {
            dismissedToMini = false;
            dismissedCallKey = null;
        }
        if (!dismissedToMini) renderCall(call);
        else showMiniPill(call);
    }

    private void renderCall(HfpCall call) {
        removeMiniPill();
        if (popupView == null) {
            View v = LayoutInflater.from(this).inflate(R.layout.overlay_compact_call, null);
            int widthPx = Math.min((int) (getResources().getDisplayMetrics().density * 460),
                (int) (getResources().getDisplayMetrics().widthPixels * 0.92f));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                widthPx, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = getStatusBarOffsetPx() + (int) (getResources().getDisplayMetrics().density * 14);
            attachSwipeUp(v);
            bindButtons(v);
            wm.addView(v, lp);
            popupView = v;
        }

        String rawNum = (call.number == null || call.number.isEmpty()) ? "" : call.number;
        String disp = rawNum.isEmpty() ? "발신번호 표시제한" : com.dolphin.comms.data.CommsRepository.resolveNameQuick(this, rawNum);
        String subNum = rawNum.isEmpty() ? "블루투스(HFP) 통화" : com.dolphin.comms.data.CommsRepository.pretty(rawNum) + " · 블루투스(HFP)";
        ((TextView) popupView.findViewById(R.id.tvPopupName)).setText(disp);
        ((TextView) popupView.findViewById(R.id.tvPopupNumber)).setText(subNum);
        String avatarCh = (!disp.isEmpty() && Character.isDigit(disp.charAt(0))) ? "☎" : disp.substring(0, 1);
        ((TextView) popupView.findViewById(R.id.tvPopupAvatar)).setText(avatarCh);
        ((TextView) popupView.findViewById(R.id.tvPopupState)).setText(
            call.isRinging() ? "블루투스 전화가 걸려왔습니다" : (call.isDialing() ? "블루투스 발신 중…" : "블루투스 통화 중"));

        popupView.findViewById(R.id.rowIncomingActions).setVisibility(call.isRinging() ? View.VISIBLE : View.GONE);
        popupView.findViewById(R.id.rowActiveActions).setVisibility(!call.isRinging() ? View.VISIBLE : View.GONE);
        popupView.findViewById(R.id.gridPopupDtmf).setVisibility(!call.isRinging() && dtmfVisible ? View.VISIBLE : View.GONE);

        ui.removeCallbacks(tick);
        if (call.isActive()) ui.post(tick);
    }

    private void attachSwipeUp(View view) {
        final float threshold = getResources().getDisplayMetrics().density * 72f;
        final float[] downY = {0f};
        final boolean[] dragging = {false};
        view.setOnTouchListener((v, ev) -> {
            int act = ev.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN) {
                downY[0] = ev.getRawY();
                dragging[0] = false;
                return true;
            } else if (act == MotionEvent.ACTION_MOVE) {
                float dy = ev.getRawY() - downY[0];
                if (Math.abs(dy) > 10f) dragging[0] = true;
                if (dy < 0f) {
                    v.setTranslationY(dy);
                    v.setAlpha(Math.max(0.25f, 1f + dy / (threshold * 2.2f)));
                } else {
                    v.setTranslationY(dy * 0.15f);
                    v.setAlpha(1f);
                }
                return true;
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                float dy = ev.getRawY() - downY[0];
                if (dragging[0] && dy < -threshold) {
                    v.animate().translationY(-v.getHeight() - 80f).alpha(0f).setDuration(180L).withEndAction(() -> {
                        dismissedToMini = true;
                        HfpCall c = CallStateManager.currentCall();
                        dismissedCallKey = c != null ? callKey(c) : null;
                        removePopupOnly();
                        if (c != null) showMiniPill(c);
                    }).start();
                } else {
                    v.animate().translationY(0f).alpha(1f).setDuration(160L).start();
                }
                return dragging[0];
            }
            return false;
        });
    }

    private void bindButtons(View v) {
        v.findViewById(R.id.btnPopupAccept).setOnClickListener(x -> PhoneController.accept(this));
        v.findViewById(R.id.btnPopupReject).setOnClickListener(x -> PhoneController.endOrReject(this, true));
        v.findViewById(R.id.btnPopupEnd).setOnClickListener(x -> PhoneController.endOrReject(this, false));
        v.findViewById(R.id.btnPopupMute).setOnClickListener(btn -> {
            boolean next = !CallStateManager.isMuted();
            PhoneController.setMuted(this, next);
            ((TextView) btn).setText(next ? "음소거 중" : "음소거");
        });
        v.findViewById(R.id.btnPopupDtmf).setOnClickListener(x -> {
            dtmfVisible = !dtmfVisible;
            v.findViewById(R.id.gridPopupDtmf).setVisibility(dtmfVisible ? View.VISIBLE : View.GONE);
        });

        GridLayout grid = v.findViewById(R.id.gridPopupDtmf);
        String[] keys = {"1","2","3","4","5","6","7","8","9","*","0","#"};
        for (String k : keys) {
            TextView tv = new TextView(this);
            tv.setText(k);
            tv.setTextSize(18f);
            tv.setTextColor(0xFFF8FAFC);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(0, 16, 0, 16);
            tv.setBackgroundResource(R.drawable.bg_key_button);
            tv.setOnClickListener(x -> PhoneController.sendDtmf(k.charAt(0)));
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = GridLayout.LayoutParams.WRAP_CONTENT;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(5, 5, 5, 5);
            grid.addView(tv, lp);
        }
    }

    private void showMiniPill(HfpCall call) {
        if (miniPillView != null) return;
        View pill = LayoutInflater.from(this).inflate(R.layout.overlay_mini_pill, null);
        ((TextView) pill.findViewById(R.id.tvMiniStatus)).setText(
            call.isRinging() ? "수신 중 · 눌러서 팝업 열기" : "통화 중 · 눌러서 팝업 열기");
        pill.setOnClickListener(x -> {
            dismissedToMini = false;
            dismissedCallKey = null;
            HfpCall c = CallStateManager.currentCall();
            if (c != null) renderCall(c);
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = getStatusBarOffsetPx() + (int) (getResources().getDisplayMetrics().density * 8);
        wm.addView(pill, lp);
        miniPillView = pill;
    }

    private void removePopupOnly() {
        if (popupView != null) { try { wm.removeView(popupView); } catch (Throwable ignored) {} popupView = null; }
    }
    private void removeMiniPill() {
        if (miniPillView != null) { try { wm.removeView(miniPillView); } catch (Throwable ignored) {} miniPillView = null; }
    }
    private void removeAllViews() {
        ui.removeCallbacks(tick);
        removePopupOnly();
        removeMiniPill();
        dtmfVisible = false;
        dismissedToMini = false;
        dismissedCallKey = null;
    }

    @Override public void onDestroy() {
        CallStateManager.removeListener(this);
        removeAllViews();
        super.onDestroy();
    }

    private String callKey(HfpCall c) {
        String d = com.dolphin.comms.data.CommsRepository.digits(c.number);
        return !d.isEmpty() ? d : ("id:" + c.id);
    }

    private int getStatusBarOffsetPx() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int h = resId > 0 ? getResources().getDimensionPixelSize(resId) : 0;
        int minPx = (int) (getResources().getDisplayMetrics().density * 36);
        return Math.max(h, minPx);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
