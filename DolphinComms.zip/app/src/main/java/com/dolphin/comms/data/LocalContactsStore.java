package com.dolphin.comms.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * BYD 차량에서 com.android.bluetooth.contactprovider가 시스템 서명 권한으로 잠겨 있을 때,
 * 폰에서 내보낸 .vcf(vCard) 파일 가져오기 및 수동 연락처 저장을 지원하는 로컬 연락처 저장소.
 */
public final class LocalContactsStore {
    private static final String PREFS = "dolphin_comms_local_contacts";
    private static final String KEY_JSON = "items";

    private LocalContactsStore() {}

    public static List<CommsRepository.Contact> loadAll(Context ctx) {
        List<CommsRepository.Contact> out = new ArrayList<>();
        try {
            SharedPreferences sp = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY_JSON, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String num = o.optString("number", "").trim();
                String name = o.optString("name", "").trim();
                if (num.isEmpty()) continue;
                CommsRepository.Contact c = new CommsRepository.Contact();
                c.number = num;
                c.name = name.isEmpty() ? num : name;
                c.label = o.optString("label", "로컬");
                out.add(c);
            }
        } catch (Throwable ignored) {}
        return out;
    }

    public static int saveOrMerge(Context ctx, List<CommsRepository.Contact> incoming) {
        Map<String, CommsRepository.Contact> merged = new LinkedHashMap<>();
        for (CommsRepository.Contact c : loadAll(ctx)) {
            String d = CommsRepository.digits(c.number);
            if (!d.isEmpty()) merged.put(d, c);
        }
        int addedOrUpdated = 0;
        for (CommsRepository.Contact c : incoming) {
            String d = CommsRepository.digits(c.number);
            if (d.isEmpty()) continue;
            merged.put(d, c);
            addedOrUpdated++;
        }
        JSONArray arr = new JSONArray();
        try {
            for (CommsRepository.Contact c : merged.values()) {
                JSONObject o = new JSONObject();
                o.put("name", c.name);
                o.put("number", c.number);
                o.put("label", c.label != null ? c.label : "");
                arr.put(o);
            }
            ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_JSON, arr.toString()).apply();
        } catch (Throwable ignored) {}
        return addedOrUpdated;
    }

    public static void addSingle(Context ctx, String name, String number) {
        CommsRepository.Contact c = new CommsRepository.Contact();
        c.name = (name == null || name.trim().isEmpty()) ? number.trim() : name.trim();
        c.number = number.trim();
        c.label = "직접 저장";
        List<CommsRepository.Contact> one = new ArrayList<>();
        one.add(c);
        saveOrMerge(ctx, one);
    }

    /**
     * 삼성 갤럭시 등에서 내보낸 .vcf(vCard 2.1/3.0/4.0, UTF-8 및 QUOTED-PRINTABLE) 파싱.
     */
    public static int importFromVcfUri(Context ctx, Uri uri) throws Exception {
        List<String> unfolded = new ArrayList<>();
        try (InputStream is = ctx.getContentResolver().openInputStream(uri)) {
            if (is == null) return 0;
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("\uFEFF")) line = line.substring(1);
                if (!unfolded.isEmpty()) {
                    String prev = unfolded.get(unfolded.size() - 1);
                    // QUOTED-PRINTABLE soft line break (=) 또는 RFC folding (space/tab)
                    if (prev.endsWith("=") && prev.toUpperCase().contains("QUOTED-PRINTABLE")) {
                        unfolded.set(unfolded.size() - 1, prev.substring(0, prev.length() - 1) + line);
                        continue;
                    }
                    if (line.startsWith(" ") || line.startsWith("\t")) {
                        unfolded.set(unfolded.size() - 1, prev + line.substring(1));
                        continue;
                    }
                }
                unfolded.add(line);
            }
        }

        List<CommsRepository.Contact> parsed = new ArrayList<>();
        String curName = "";
        List<String> curPhones = new ArrayList<>();
        boolean inCard = false;

        for (String line : unfolded) {
            String upper = line.toUpperCase();
            if (upper.startsWith("BEGIN:VCARD")) {
                inCard = true;
                curName = "";
                curPhones.clear();
            } else if (upper.startsWith("END:VCARD")) {
                if (inCard && !curPhones.isEmpty()) {
                    String finalName = curName.trim();
                    for (String p : curPhones) {
                        CommsRepository.Contact c = new CommsRepository.Contact();
                        c.number = p;
                        c.name = finalName.isEmpty() ? p : finalName;
                        c.label = "VCF";
                        parsed.add(c);
                    }
                }
                inCard = false;
            } else if (inCard) {
                int colon = line.indexOf(':');
                if (colon <= 0) continue;
                String meta = line.substring(0, colon).toUpperCase();
                String val = line.substring(colon + 1).trim();
                boolean isQp = meta.contains("QUOTED-PRINTABLE");

                if (meta.equals("FN") || meta.startsWith("FN;")) {
                    String decoded = isQp ? decodeQuotedPrintable(val) : val;
                    if (!decoded.trim().isEmpty()) curName = decoded.trim();
                } else if ((meta.equals("N") || meta.startsWith("N;")) && curName.isEmpty()) {
                    String decoded = isQp ? decodeQuotedPrintable(val) : val;
                    String cleaned = decoded.replace(";", " ").replaceAll("\\s+", " ").trim();
                    if (!cleaned.isEmpty()) curName = cleaned;
                } else if (meta.equals("TEL") || meta.startsWith("TEL;")) {
                    String digits = CommsRepository.digits(val);
                    if (digits.length() >= 3) curPhones.add(val.trim());
                }
            }
        }
        return saveOrMerge(ctx, parsed);
    }

    private static String decodeQuotedPrintable(String input) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int len = input.length();
        for (int i = 0; i < len; i++) {
            char c = input.charAt(i);
            if (c == '=' && i + 2 < len) {
                int hi = Character.digit(input.charAt(i + 1), 16);
                int lo = Character.digit(input.charAt(i + 2), 16);
                if (hi >= 0 && lo >= 0) {
                    baos.write((hi << 4) + lo);
                    i += 2;
                    continue;
                }
            }
            baos.write((byte) c);
        }
        return new String(baos.toByteArray(), StandardCharsets.UTF_8);
    }
}
