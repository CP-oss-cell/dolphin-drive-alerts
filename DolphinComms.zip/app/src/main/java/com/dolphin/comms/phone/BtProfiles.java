package com.dolphin.comms.phone;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Parcelable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BtProfiles {
    public static final int HEADSET_CLIENT = 16;
    public static final int PBAP_CLIENT = 17;

    private static volatile BluetoothProfile hfp;
    private static volatile BluetoothProfile pbap;
    private static volatile boolean initialized;

    private BtProfiles() {}

    public static synchronized void init(Context context) {
        if (initialized) return;
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return;
        initialized = true;
        Context app = context.getApplicationContext();

        try {
            adapter.getProfileProxy(app, new BluetoothProfile.ServiceListener() {
                @Override public void onServiceConnected(int p, BluetoothProfile proxy) { hfp = proxy; }
                @Override public void onServiceDisconnected(int p) { hfp = null; }
            }, HEADSET_CLIENT);
        } catch (Throwable ignored) {}

        try {
            adapter.getProfileProxy(app, new BluetoothProfile.ServiceListener() {
                @Override public void onServiceConnected(int p, BluetoothProfile proxy) { pbap = proxy; }
                @Override public void onServiceDisconnected(int p) { pbap = null; }
            }, PBAP_CLIENT);
        } catch (Throwable ignored) {}
    }

    @SuppressLint("MissingPermission")
    public static List<BluetoothDevice> hfpDevices() {
        BluetoothProfile p = hfp;
        if (p == null) return Collections.emptyList();
        try {
            return new ArrayList<>(p.getConnectedDevices());
        } catch (Throwable t) {
            return Collections.emptyList();
        }
    }

    public static Class<?> callClass() {
        try {
            return Class.forName("android.bluetooth.BluetoothHeadsetClientCall");
        } catch (Throwable t) {
            return null;
        }
    }

    public static Method hiddenMethod(String name, Class<?>... params) {
        BluetoothProfile p = hfp;
        if (p == null) return null;
        try {
            return p.getClass().getMethod(name, params);
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean invokeHfp(String name, Class<?>[] types, Object[] args) {
        BluetoothProfile p = hfp;
        if (p == null) return false;
        try {
            Method m = p.getClass().getMethod(name, types);
            Object res = m.invoke(p, args);
            return !(res instanceof Boolean) || (Boolean) res;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean dialViaHfp(BluetoothDevice dev, String number) {
        BluetoothProfile p = hfp;
        if (p == null) return false;
        try {
            Method m = p.getClass().getMethod("dial", BluetoothDevice.class, String.class);
            return m.invoke(p, dev, number) != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public static List<HfpCall> currentCalls(BluetoothDevice dev) {
        BluetoothProfile p = hfp;
        if (p == null) return Collections.emptyList();
        try {
            Method m = p.getClass().getMethod("getCurrentCalls", BluetoothDevice.class);
            Object raw = m.invoke(p, dev);
            if (!(raw instanceof List<?>)) return Collections.emptyList();
            List<HfpCall> out = new ArrayList<>();
            for (Object item : (List<?>) raw) {
                if (item instanceof Parcelable) {
                    HfpCall c = HfpCall.from((Parcelable) item);
                    if (c != null) out.add(c);
                }
            }
            return out;
        } catch (Throwable t) {
            return Collections.emptyList();
        }
    }

    public static int availableHiddenApiCount() {
        int ok = 0;
        if (hiddenMethod("getCurrentCalls", BluetoothDevice.class) != null) ok++;
        if (hiddenMethod("dial", BluetoothDevice.class, String.class) != null) ok++;
        if (hiddenMethod("acceptCall", BluetoothDevice.class, int.class) != null) ok++;
        if (hiddenMethod("rejectCall", BluetoothDevice.class) != null) ok++;
        Class<?> cls = callClass();
        if (cls != null && hiddenMethod("terminateCall", BluetoothDevice.class, cls) != null) ok++;
        if (hiddenMethod("sendDTMF", BluetoothDevice.class, byte.class) != null) ok++;
        return ok;
    }
}
