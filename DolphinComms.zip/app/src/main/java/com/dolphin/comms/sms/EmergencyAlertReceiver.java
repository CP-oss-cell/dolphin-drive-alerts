package com.dolphin.comms.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.lang.reflect.Method;

/**
 * 재난문자(CBS) 수신 리시버: 셀 브로드캐스트 수신 시 저장 + 긴급 팝업 표시.
 * (@SystemApi SmsCbMessage를 리플렉션으로 읽어 공개 Android SDK에서도 오류 없이 컴파일됩니다.)
 */
public class EmergencyAlertReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        SharedPreferences prefs = context.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("emergency_alerts_enabled", true)) return;

        Bundle extras = intent.getExtras();
        if (extras == null) return;
        Object raw = extras.get("message");
        String body = extractCbBody(raw);
        if (body == null || body.trim().isEmpty()) return;

        String sender = "긴급재난문자";
        if (saveAlert(context, sender, body.trim(), System.currentTimeMillis())) {
            MessagePopupOverlayService.showMessage(context, sender, sender, body.trim(), true, false);
        }
        context.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(context.getPackageName()));
    }

    private static String extractCbBody(Object raw) {
        if (raw == null) return null;
        try {
            Method m = raw.getClass().getMethod("getMessageBody");
            Object res = m.invoke(raw);
            if (res instanceof String) return (String) res;
        } catch (Throwable ignored) {}
        return raw.toString();
    }

    public static boolean saveAlert(Context ctx, String sender, String body, long dateMs) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("dolphin_emergency_alerts", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("items", "[]"));
            if (arr.length() > 0) {
                JSONObject top = arr.getJSONObject(0);
                if (body.equals(top.optString("body", "")) && Math.abs(dateMs - top.optLong("dateMs", 0L)) < 60000L) {
                    return false;
                }
            }
            JSONObject obj = new JSONObject();
            obj.put("sender", sender);
            obj.put("body", body);
            obj.put("dateMs", dateMs);
            JSONArray next = new JSONArray();
            next.put(obj);
            for (int i = 0; i < Math.min(arr.length(), 49); i++) next.put(arr.get(i));
            sp.edit().putString("items", next.toString()).apply();
            return true;
        } catch (Throwable ignored) { return false; }
    }

    public static boolean isEmergencyText(String sender, String body) {
        String s = (sender == null ? "" : sender) + " " + (body == null ? "" : body);
        return s.contains("재난문자") || s.contains("안전안내") || s.contains("위급재난")
            || s.contains("국민재난안전포털") || s.contains("[기상청]");
    }
}
