package com.dolphin.comms.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsCbMessage;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 재난문자(CBS) 수신 리시버: 셀 브로드캐스트 수신 시 저장 + 긴급 팝업 표시.
 */
public class EmergencyAlertReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        SharedPreferences prefs = context.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("emergency_alerts_enabled", true)) return;
        Bundle extras = intent.getExtras();
        if (extras == null) return;
        Object raw = extras.get("message");
        String body = null;
        int priority = 1;
        if (raw instanceof SmsCbMessage) {
            SmsCbMessage cb = (SmsCbMessage) raw;
            body = cb.getMessageBody();
        } else if (raw != null) {
            body = raw.toString();
        }
        if (body == null || body.trim().isEmpty()) return;
        String sender = "긴급재난문자";
        saveAlert(context, sender, body.trim(), System.currentTimeMillis());
        MessagePopupOverlayService.showMessage(context, sender, sender, body.trim(), true, false);
        context.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(context.getPackageName()));
    }

    public static void saveAlert(Context ctx, String sender, String body, long dateMs) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("dolphin_emergency_alerts", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("items", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("sender", sender);
            obj.put("body", body);
            obj.put("dateMs", dateMs);
            JSONArray next = new JSONArray();
            next.put(obj);
            for (int i = 0; i < Math.min(arr.length(), 49); i++) next.put(arr.get(i));
            sp.edit().putString("items", next.toString()).apply();
        } catch (Throwable ignored) {}
    }

    public static boolean isEmergencyText(String sender, String body) {
        String s = (sender == null ? "" : sender) + " " + (body == null ? "" : body);
        return s.contains("재난문자") || s.contains("안전안내") || s.contains("위급재난")
            || s.contains("국민재난안전포털") || s.contains("[기상청]");
    }
}
