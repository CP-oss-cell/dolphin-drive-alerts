package com.dolphin.comms.sms;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsManager;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import java.nio.charset.StandardCharsets;

/**
 * 차량 유심 MMS WAP Push 수신 리시버:
 * 기본 문자 앱일 때 WAP Push PDU에서 Content-Location URL을 파싱해 실제 MMS를 다운로드합니다.
 */
public class MmsReceiver extends BroadcastReceiver {
    public static final String ACTION_MMS_DOWNLOADED = "com.dolphin.comms.MMS_DOWNLOADED";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String act = intent.getAction();
        boolean isDeliver = Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION.equals(act);
        boolean isReceived = Telephony.Sms.Intents.WAP_PUSH_RECEIVED_ACTION.equals(act);
        if (!isDeliver && !isReceived) return;

        boolean weAreDefault = context.getPackageName().equals(Telephony.Sms.getDefaultSmsPackage(context));
        if (weAreDefault && isReceived) return;

        byte[] pdu = intent.getByteArrayExtra("data");
        if (isDeliver && pdu != null && pdu.length > 0) {
            String locationUrl = extractContentLocation(pdu);
            if (locationUrl != null && !locationUrl.isEmpty()) {
                try {
                    String fn = "mms_in_" + System.currentTimeMillis() + ".pdu";
                    Uri outUri = MmsTempProvider.buildUri(fn);
                    context.grantUriPermission("com.android.mms.service", outUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    PendingIntent pi = PendingIntent.getBroadcast(
                        context, (int) (System.currentTimeMillis() & 0xFFFF),
                        new Intent(ACTION_MMS_DOWNLOADED).setPackage(context.getPackageName()).putExtra("file", fn),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    SmsManager sm = Build.VERSION.SDK_INT >= 31
                        ? context.getSystemService(SmsManager.class)
                        : SmsManager.getDefault();
                    if (sm != null) {
                        sm.downloadMultimediaMessage(context, locationUrl, outUri, null, pi);
                    }
                } catch (Throwable ignored) {}
            }
        }

        SharedPreferences sp = context.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
        if (sp.getBoolean("compact_popup", true)) {
            MessagePopupOverlayService.showMessage(
                context, "MMS 멀티미디어 문자", "", "새 MMS(사진/장문)가 차량 유심으로 수신되었습니다.", false, true);
        }
        context.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(context.getPackageName()));
    }

    /**
     * WAP Push M-Notification.ind PDU에서 X-Mms-Content-Location (0x83) URL을 추출합니다.
     */
    private static String extractContentLocation(byte[] pdu) {
        for (int i = 0; i < pdu.length - 6; i++) {
            if ((pdu[i] & 0xFF) == 0x83) {
                int start = i + 1;
                int end = start;
                while (end < pdu.length && pdu[end] != 0x00) end++;
                if (end > start) {
                    String url = new String(pdu, start, end - start, StandardCharsets.US_ASCII).trim();
                    if (url.startsWith("http://") || url.startsWith("https://")) return url;
                }
            }
        }
        return null;
    }
}
