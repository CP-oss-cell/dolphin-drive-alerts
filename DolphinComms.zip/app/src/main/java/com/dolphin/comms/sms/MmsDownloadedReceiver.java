package com.dolphin.comms.sms;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.dolphin.comms.overlay.MessagePopupOverlayService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * SmsManager.downloadMultimediaMessage() 완료 브로드캐스트 수신 리시버.
 * 다운로드된 MMS PDU에서 발신번호·텍스트·JPEG 사진을 추출해 로컬 저장 및 팝업 갱신합니다.
 */
public class MmsDownloadedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String fileName = intent.getStringExtra("file");
        if (fileName == null || fileName.isEmpty()) return;
        File pduFile = new File(context.getCacheDir(), fileName);
        if (!pduFile.exists()) return;

        try {
            if (getResultCode() != Activity.RESULT_OK) return;
            byte[] data = readAll(pduFile);
            if (data.length == 0) return;

            String sender = extractPhone(data);
            if (sender.isEmpty()) sender = "MMS";
            String body = extractReadableText(data);
            String imgPath = extractAndSaveJpeg(context, data);
            if (body.isEmpty() && !imgPath.isEmpty()) body = "[사진 첨부 MMS]";
            if (body.isEmpty()) body = "(MMS 멀티미디어 메시지)";

            saveLocalMms(context, sender, body, imgPath, System.currentTimeMillis());

            SharedPreferences sp = context.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
            if (sp.getBoolean("compact_popup", true)) {
                MessagePopupOverlayService.showMessage(context, sender, sender, body, false, true);
            }
            context.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(context.getPackageName()));
        } catch (Throwable ignored) {
        } finally {
            try { pduFile.delete(); } catch (Throwable ignored) {}
        }
    }

    private static byte[] readAll(File f) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (FileInputStream fis = new FileInputStream(f)) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = fis.read(buf)) > 0) bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    private static String extractPhone(byte[] data) {
        String ascii = new String(data, 0, Math.min(data.length, 512), StandardCharsets.ISO_8859_1);
        int idx = ascii.indexOf("/TYPE=PLMN");
        if (idx > 3) {
            int start = idx - 1;
            while (start > 0) {
                char c = ascii.charAt(start - 1);
                if ((c >= '0' && c <= '9') || c == '+' || c == '-') start--;
                else break;
            }
            String candidate = ascii.substring(start, idx).trim();
            if (candidate.length() >= 3) return candidate;
        }
        return "";
    }

    private static String extractAndSaveJpeg(Context ctx, byte[] data) {
        int start = -1;
        for (int i = 0; i < data.length - 3; i++) {
            if ((data[i] & 0xFF) == 0xFF && (data[i + 1] & 0xFF) == 0xD8 && (data[i + 2] & 0xFF) == 0xFF) {
                start = i;
                break;
            }
        }
        if (start < 0) return "";
        int end = -1;
        for (int i = data.length - 2; i > start + 10; i--) {
            if ((data[i] & 0xFF) == 0xFF && (data[i + 1] & 0xFF) == 0xD9) {
                end = i + 2;
                break;
            }
        }
        if (end <= start) return "";
        try {
            File dir = new File(ctx.getFilesDir(), "mms_images");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, "mms_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                fos.write(data, start, end - start);
            }
            return out.getAbsolutePath();
        } catch (Throwable t) {
            return "";
        }
    }

    private static String extractReadableText(byte[] data) {
        int scanLen = Math.min(data.length, 16384);
        String decoded = new String(data, 0, scanLen, StandardCharsets.UTF_8);
        StringBuilder best = new StringBuilder();
        StringBuilder cur = new StringBuilder();
        for (int i = 0; i < decoded.length(); i++) {
            char c = decoded.charAt(i);
            boolean ok = (c >= 0xAC00 && c <= 0xD7A3) || (c >= 0x20 && c <= 0x7E) || c == '\n' || c == '\r';
            if (ok) {
                cur.append(c);
            } else {
                if (cur.length() > best.length() && containsKoreanOrSpaces(cur)) {
                    best.setLength(0);
                    best.append(cur);
                }
                cur.setLength(0);
            }
        }
        if (cur.length() > best.length() && containsKoreanOrSpaces(cur)) {
            best.setLength(0);
            best.append(cur);
        }
        String res = best.toString().trim();
        if (res.contains("/TYPE=PLMN") || res.startsWith("http://") || res.startsWith("https://")) return "";
        return res;
    }

    private static boolean containsKoreanOrSpaces(CharSequence s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 0xAC00 && c <= 0xD7A3) || c == ' ') return true;
        }
        return false;
    }

    private static void saveLocalMms(Context ctx, String sender, String body, String imgPath, long dateMs) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("dolphin_local_mms", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("items", "[]"));
            JSONObject o = new JSONObject();
            o.put("sender", sender);
            o.put("body", body);
            o.put("imgPath", imgPath);
            o.put("dateMs", dateMs);
            JSONArray next = new JSONArray();
            next.put(o);
            for (int i = 0; i < Math.min(arr.length(), 49); i++) next.put(arr.get(i));
            sp.edit().putString("items", next.toString()).apply();
        } catch (Throwable ignored) {}
    }
}
