package com.dolphin.comms.sms;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;

public class HeadlessSmsSendService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && Intent.ACTION_SENDTO.equals(intent.getAction()) ||
                (intent != null && "android.intent.action.RESPOND_VIA_MESSAGE".equals(intent.getAction()))) {
            Uri uri = intent.getData();
            String addr = uri != null ? uri.getSchemeSpecificPart() : "";
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (addr != null && !addr.isEmpty() && text != null && !text.isEmpty()) {
                SmsController.sendSms(this, addr, text);
            }
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
