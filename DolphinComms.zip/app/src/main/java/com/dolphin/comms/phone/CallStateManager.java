package com.dolphin.comms.phone;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.telecom.Call;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import com.dolphin.comms.adb.BydAdbContactsSync;
import com.dolphin.comms.adb.NativeAdbClient;
import com.dolphin.comms.overlay.IncomingCallOverlayService;
import com.dolphin.comms.sms.SmsReceiver;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CallStateManager {
    public interface Listener {
        void onCallChanged(HfpCall call);
    }

    private static final String ACTION_AG_CALL_CHANGED =
        "android.bluetooth.headsetclient.profile.action.AG_CALL_CHANGED";
    private static final String ACTION_HFP_CONN =
        "android.bluetooth.headsetclient.profile.action.CONNECTION_STATE_CHANGED";

    private static Context appContext;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final List<Listener> LISTENERS = new CopyOnWriteArrayList<>();
    private static final ExecutorService BG_EXEC = Executors.newSingleThreadExecutor();

    private static volatile Call activeTelecomCall;
    private static volatile HfpCall currentCall;
    private static volatile boolean muted;
    private static volatile String pendingDial;
    private static volatile boolean simulating;
    private static volatile long lastWinSnapMs = 0L;
    private static boolean started;

    private CallStateManager() {}

    public static Call activeTelecomCall() { return activeTelecomCall; }
    public static HfpCall currentCall() { return currentCall; }
    public static boolean isMuted() { return muted; }
    public static boolean isSimulating() { return simulating; }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static void start(Context context) {
        if (started) return;
        started = true;
        appContext = context.getApplicationContext();

        // 앱 시작 시 로컬 ADB를 통한 BYD 블루투스 연락처 백그라운드 동기화
        BydAdbContactsSync.syncAsync(appContext);

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_AG_CALL_CHANGED);
        f.addAction(ACTION_HFP_CONN);
        BroadcastReceiver br = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent intent) {
                if (simulating) return;
                String act = intent.getAction();
                if (ACTION_AG_CALL_CHANGED.equals(act)) {
                    Parcelable raw = intent.getParcelableExtra("android.bluetooth.headsetclient.extra.CALL");
                    HfpCall parsed = HfpCall.from(raw);
                    if (parsed == null) return;
                    CallDebugLog.log("AG_CALL_CHANGED state=" + parsed.state + " num=" + parsed.number);
                    if (parsed.state == HfpCall.TERMINATED) {
                        if (activeTelecomCall == null) updateCall(null);
                    } else {
                        if (parsed.state == HfpCall.ACTIVE) {
                            HfpCall prev = currentCall;
                            parsed.activeSinceMs = (prev != null && prev.activeSinceMs > 0)
                                ? prev.activeSinceMs : SystemClock.elapsedRealtime();
                        }
                        updateCall(parsed);
                    }
                } else if (ACTION_HFP_CONN.equals(act)) {
                    int st = intent.getIntExtra("android.bluetooth.profile.extra.STATE", -1);
                    if (st == 2) {
                        BtProfiles.init(ctx);
                        BydAdbContactsSync.syncAsync(ctx);
                        notifyDataChanged();
                    } else if (st == 0 && activeTelecomCall == null) {
                        updateCall(null);
                        notifyDataChanged();
                    }
                }
            }
        };
        if (Build.VERSION.SDK_INT >= 33) {
            appContext.registerReceiver(br, f, Context.RECEIVER_EXPORTED);
        } else {
            appContext.registerReceiver(br, f);
        }

        try {
            TelephonyManager tm = (TelephonyManager) appContext.getSystemService(Context.TELEPHONY_SERVICE);
            tm.listen(new PhoneStateListener() {
                @Override public void onCallStateChanged(int state, String num) {
                    if (simulating || activeTelecomCall != null) return;
                    if (state == TelephonyManager.CALL_STATE_IDLE) {
                        HfpCall cur = currentCall;
                        if (cur != null && "phone-state".equals(cur.via)) {
                            updateCall(null);
                        }
                    } else if (state == TelephonyManager.CALL_STATE_RINGING) {
                        HfpCall c = new HfpCall();
                        c.id = -1; c.state = HfpCall.INCOMING;
                        c.number = num != null ? num : "";
                        c.via = "phone-state";
                        updateCall(c);
                    } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                        HfpCall c = new HfpCall();
                        c.id = -1; c.state = HfpCall.ACTIVE;
                        c.number = (num != null && !num.isEmpty()) ? num : (pendingDial != null ? pendingDial : "");
                        c.outgoing = pendingDial != null;
                        HfpCall prev = currentCall;
                        c.activeSinceMs = (prev != null && prev.activeSinceMs > 0)
                            ? prev.activeSinceMs : SystemClock.elapsedRealtime();
                        c.via = "phone-state";
                        updateCall(c);
                    }
                }
            }, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (Throwable ignored) {}
    }

    public static void onDialRequested(String number) {
        pendingDial = number;
        MAIN.postDelayed(() -> pendingDial = null, 30000L);
    }

    public static void onTelecomCallUpdated(Call call) {
        activeTelecomCall = call;
        int st = call.getState();
        int mapped;
        if (st == Call.STATE_RINGING) mapped = HfpCall.INCOMING;
        else if (st == Call.STATE_DIALING || st == Call.STATE_CONNECTING) mapped = HfpCall.DIALING;
        else if (st == Call.STATE_ACTIVE) mapped = HfpCall.ACTIVE;
        else if (st == Call.STATE_HOLDING) mapped = HfpCall.HELD;
        else if (st == Call.STATE_DISCONNECTED || st == Call.STATE_DISCONNECTING) mapped = HfpCall.TERMINATED;
        else mapped = HfpCall.ACTIVE;

        if (mapped == HfpCall.TERMINATED) {
            activeTelecomCall = null;
            updateCall(null);
            return;
        }
        HfpCall c = new HfpCall();
        c.id = call.hashCode();
        c.state = mapped;
        c.number = call.getDetails().getHandle() != null
            ? call.getDetails().getHandle().getSchemeSpecificPart()
            : (pendingDial != null ? pendingDial : "");
        c.outgoing = mapped == HfpCall.DIALING;
        if (mapped == HfpCall.ACTIVE) {
            HfpCall prev = currentCall;
            c.activeSinceMs = (prev != null && prev.activeSinceMs > 0)
                ? prev.activeSinceMs : SystemClock.elapsedRealtime();
        }
        c.via = "InCallService";
        updateCall(c);
    }

    public static void onTelecomCallRemoved(Call call) {
        if (activeTelecomCall == call) {
            activeTelecomCall = null;
            updateCall(null);
        }
    }

    public static void onAudioMuted(boolean m) {
        muted = m;
        notifyListeners();
    }

    public static void simulateIncoming(String number) {
        simulating = true;
        HfpCall c = new HfpCall();
        c.id = 999; c.state = HfpCall.INCOMING; c.number = number; c.via = "sim";
        updateCall(c);
    }

    public static void simulateAccept() {
        HfpCall prev = currentCall;
        if (prev == null) return;
        HfpCall c = new HfpCall();
        c.id = prev.id; c.state = HfpCall.ACTIVE; c.number = prev.number;
        c.activeSinceMs = SystemClock.elapsedRealtime(); c.via = "sim";
        updateCall(c);
    }

    public static void stopSimulation() {
        simulating = false;
        updateCall(null);
    }

    private static void updateCall(HfpCall call) {
        boolean ended = (currentCall != null && call == null);
        currentCall = call;
        notifyListeners();
        if (appContext != null) {
            SharedPreferences sp = appContext.getSharedPreferences("dolphin_comms_prefs", Context.MODE_PRIVATE);
            boolean popupOn = sp.getBoolean("compact_popup", true);
            if (call != null && popupOn) {
                IncomingCallOverlayService.showOrUpdate(appContext);
            } else {
                IncomingCallOverlayService.dismiss(appContext);
            }
            if (call != null && !simulating) {
                captureInCallWindowSnapshotOnce();
            }
            if (ended) {
                MAIN.postDelayed(CallStateManager::notifyDataChanged, 1200L);
            }
        }
    }

    private static void captureInCallWindowSnapshotOnce() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastWinSnapMs < 15_000L || appContext == null) return;
        lastWinSnapMs = now;
        final Context app = appContext;
        BG_EXEC.execute(() -> {
            try { Thread.sleep(1200L); } catch (InterruptedException ignored) {}
            if (!NativeAdbClient.isPortOpen()) return;
            NativeAdbClient.ShellResult r = NativeAdbClient.executeShell(
                app,
                "dumpsys window windows | grep -iE 'Window #|mCurrentFocus|ty=' | head -n 45",
                "127.0.0.1", 5555, 3500L
            );
            if (r.getSuccess() && !r.getOutput().trim().isEmpty()) {
                CallDebugLog.log("[InCall Window Snapshot]\n" + r.getOutput().trim());
            }
        });
    }

    private static void notifyDataChanged() {
        if (appContext == null) return;
        try {
            appContext.sendBroadcast(new Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(appContext.getPackageName()));
        } catch (Throwable ignored) {}
    }

    public static void addListener(Listener l) {
        if (!LISTENERS.contains(l)) LISTENERS.add(l);
        l.onCallChanged(currentCall);
    }

    public static void removeListener(Listener l) { LISTENERS.remove(l); }

    private static void notifyListeners() {
        HfpCall snap = currentCall;
        MAIN.post(() -> {
            for (Listener l : LISTENERS) l.onCallChanged(snap);
        });
    }
}
