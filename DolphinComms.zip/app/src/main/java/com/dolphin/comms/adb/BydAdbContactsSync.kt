package com.dolphin.comms.adb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.regex.Pattern

/**
 * BYD 차량은 폰 블루투스 연락처를 content://com.android.bluetooth.contactprovider/contacts 에 저장하며
 * READ_CONTENTPROVIDER 권한이 시스템 서명 권한이라 일반 앱에서 SecurityException 이 발생한다.
 * 로컬 ADB(127.0.0.1:5555) shell 권한으로 content query 를 1회 읽어 로컬 캐시에 동기화한다.
 */
object BydAdbContactsSync {
    private const val PREFS = "dolphin_comms_adb_contacts"
    private const val KEY_JSON = "contacts_json"
    private val EXEC = Executors.newSingleThreadExecutor()
    @Volatile
    private var syncing = false

    data class CachedContact(
        val name: String,
        val number: String,
        val label: String,
        val mac: String
    )

    @JvmStatic
    fun syncAsync(context: Context) {
        if (syncing) return
        val app = context.applicationContext
        EXEC.execute {
            syncBlocking(app)
        }
    }

    @JvmStatic
    fun syncBlocking(context: Context): Int {
        if (syncing) return loadCached(context).size
        syncing = true
        try {
            val app = context.applicationContext
            if (!NativeAdbClient.isPortOpen()) return -1
            val res = NativeAdbClient.executeShell(
                app,
                "content query --uri content://com.android.bluetooth.contactprovider/contacts --projection pb_name:pb_number:pb_lable:mac_address",
                timeoutMs = 8000L
            )
            if (!res.success || res.output.isBlank()) return -1

            val arr = JSONArray()
            val rowPattern = Pattern.compile("Row:\\s+\\d+\\s+(.*)")
            for (line in res.output.lines()) {
                val m = rowPattern.matcher(line.trim())
                if (!m.find()) continue
                val body = m.group(1) ?: continue
                val name = extractField(body, "pb_name", listOf("pb_number", "pb_lable", "mac_address"))
                val number = extractField(body, "pb_number", listOf("pb_lable", "mac_address"))
                val label = extractField(body, "pb_lable", listOf("mac_address"))
                val mac = extractField(body, "mac_address", emptyList())
                if (number.isBlank() || number == "NULL") continue
                val obj = JSONObject()
                obj.put("name", if (name == "NULL" || name.isBlank()) number else name)
                obj.put("number", number)
                obj.put("label", if (label == "NULL") "" else label)
                obj.put("mac", if (mac == "NULL") "" else mac)
                arr.put(obj)
            }
            if (arr.length() > 0) {
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_JSON, arr.toString()).apply()
            }
            return arr.length()
        } catch (_: Throwable) {
            return -1
        } finally {
            syncing = false
        }
    }

    private fun extractField(body: String, key: String, nextKeys: List<String>): String {
        val startToken = "$key="
        val idx = body.indexOf(startToken)
        if (idx < 0) return ""
        val valStart = idx + startToken.length
        var endIdx = body.length
        for (nk in nextKeys) {
            val marker = ", $nk="
            val pos = body.indexOf(marker, valStart)
            if (pos in valStart until endIdx) {
                endIdx = pos
            }
        }
        return body.substring(valStart, endIdx).trim()
    }

    @JvmStatic
    fun loadCached(context: Context): List<CachedContact> {
        val out = mutableListOf<CachedContact>()
        try {
            val raw = context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_JSON, "[]") ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val num = o.optString("number", "")
                if (num.isNotBlank()) {
                    out += CachedContact(
                        name = o.optString("name", num),
                        number = num,
                        label = o.optString("label", ""),
                        mac = o.optString("mac", "")
                    )
                }
            }
        } catch (_: Throwable) {}
        return out
    }
}
