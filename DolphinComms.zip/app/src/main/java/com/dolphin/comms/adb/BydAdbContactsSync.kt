package com.dolphin.comms.adb

import android.content.Context
import android.content.Intent
import com.dolphin.comms.sms.SmsReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.regex.Pattern

/**
 * BYD 차량은 폰 블루투스 연락처를 content://com.android.bluetooth.contactprovider/contacts 에 저장하며
 * READ_CONTENTPROVIDER 권한이 시스템 서명 권한이라 일반 앱에서 SecurityException 이 발생한다.
 * 로컬 ADB(127.0.0.1:5555) shell 권한으로 content query 를 1회 읽어 컬럼명을 자동 인식해 로컬 캐시에 동기화한다.
 */
object BydAdbContactsSync {
    private const val PREFS = "dolphin_comms_adb_contacts"
    private const val KEY_JSON = "contacts_json"
    private val EXEC = Executors.newSingleThreadExecutor()
    @Volatile
    private var syncing = false
    @Volatile
    @JvmField
    var lastStatus: String = "미실행"

    data class CachedContact(
        val name: String,
        val number: String,
        val label: String,
        val mac: String
    )

    @JvmStatic
    fun syncAsync(context: Context) {
        if (syncing) return
        val app = context.applicationContext
        EXEC.execute {
            syncBlocking(app)
        }
    }

    @JvmStatic
    fun syncBlocking(context: Context): Int {
        if (syncing) return loadCached(context).size
        syncing = true
        try {
            val app = context.applicationContext
            if (!NativeAdbClient.isPortOpen()) {
                lastStatus = "ADB 5555 포트 닫힘"
                return -1
            }
            val res = NativeAdbClient.executeShell(
                app,
                "content query --uri content://com.android.bluetooth.contactprovider/contacts",
                timeoutMs = 10_000L
            )
            if (!res.success || res.output.isBlank()) {
                lastStatus = "query 실패(${res.message.take(120)})"
                return -1
            }

            val arr = JSONArray()
            val rowPattern = Pattern.compile("^Row:\\s+\\d+\\s+(.*)$")
            val keyPattern = Pattern.compile("(?:^|,\\s+)([A-Za-z0-9_]+)=")
            var sampleKeys = ""

            for (rawLine in res.output.lines()) {
                val m = rowPattern.matcher(rawLine.trim())
                if (!m.find()) continue
                val body = m.group(1) ?: continue
                val fields = parseRowFields(body, keyPattern)
                if (sampleKeys.isEmpty() && fields.isNotEmpty()) {
                    sampleKeys = fields.keys.joinToString(",")
                }

                val name = firstNonBlank(fields, "pb_name", "display_name", "name", "contact_name")
                val number = firstNonBlank(fields, "pb_number", "number", "phone", "phone_number", "tel")
                val label = firstNonBlank(fields, "pb_lable", "pb_label", "label", "type")
                val mac = firstNonBlank(fields, "mac_address", "bt_mac", "device_mac", "address")

                if (number.isBlank() || number.equals("NULL", ignoreCase = true)) continue
                val cleanName = if (name.isBlank() || name.equals("NULL", ignoreCase = true)) number else name
                val obj = JSONObject()
                obj.put("name", cleanName)
                obj.put("number", number)
                obj.put("label", if (label.equals("NULL", ignoreCase = true)) "" else label)
                obj.put("mac", if (mac.equals("NULL", ignoreCase = true)) "" else mac)
                arr.put(obj)
            }

            if (arr.length() > 0) {
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY_JSON, arr.toString()).apply()
                lastStatus = "성공(${arr.length()}건, cols=[$sampleKeys])"
                try {
                    app.sendBroadcast(Intent(SmsReceiver.ACTION_SMS_UPDATED).setPackage(app.packageName))
                } catch (_: Throwable) {}
            } else {
                lastStatus = "0건(cols=[$sampleKeys], sample=${res.output.trim().take(120)})"
            }
            return arr.length()
        } catch (t: Throwable) {
            lastStatus = "ERR(${t.javaClass.simpleName}: ${t.message})"
            return -1
        } finally {
            syncing = false
        }
    }

    private fun parseRowFields(body: String, keyPattern: Pattern): LinkedHashMap<String, String> {
        val map = LinkedHashMap<String, String>()
        val matcher = keyPattern.matcher(body)
        val keys = mutableListOf<Triple<String, Int, Int>>() // key, matchStart, valStart
        while (matcher.find()) {
            val k = matcher.group(1) ?: continue
            keys += Triple(k.lowercase(), matcher.start(), matcher.end())
        }
        for (i in keys.indices) {
            val (k, _, valStart) = keys[i]
            val valEnd = if (i + 1 < keys.size) keys[i + 1].second else body.length
            if (valStart <= valEnd) {
                map[k] = body.substring(valStart, valEnd).trim()
            }
        }
        return map
    }

    private fun firstNonBlank(map: Map<String, String>, vararg keys: String): String {
        for (k in keys) {
            val v = map[k]
            if (!v.isNullOrBlank() && !v.equals("NULL", ignoreCase = true)) return v
        }
        return ""
    }

    @JvmStatic
    fun loadCached(context: Context): List<CachedContact> {
        val out = mutableListOf<CachedContact>()
        try {
            val raw = context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_JSON, "[]") ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val num = o.optString("number", "")
                if (num.isNotBlank()) {
                    out += CachedContact(
                        name = o.optString("name", num),
                        number = num,
                        label = o.optString("label", ""),
                        mac = o.optString("mac", "")
                    )
                }
            }
        } catch (_: Throwable) {}
        return out
    }
}
