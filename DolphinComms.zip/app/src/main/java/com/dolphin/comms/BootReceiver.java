package com.dolphin.comms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.dolphin.comms.phone.BtProfiles;
import com.dolphin.comms.phone.CallStateManager;

/**
 * 시동 ON(BOOT_COMPLETED) 또는 앱 업데이트 직후 블루투스 HFP 감시를 자동 기동합니다.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        BtProfiles.init(context);
        CallStateManager.start(context);
    }
}
