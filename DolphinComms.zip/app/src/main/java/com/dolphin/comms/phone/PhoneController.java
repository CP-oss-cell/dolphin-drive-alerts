package com.dolphin.comms.phone;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import com.dolphin.comms.adb.NativeAdbClient;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PhoneController {
    private static final ExecutorService ADB_EXEC = Executors.newSingleThreadExecutor();

    private PhoneController() {}

    @SuppressLint("MissingPermission")
    public static String dial(Context context, String rawNumber) {
        String number = rawNumber == null ? "" : rawNumber.trim();
        if (number.isEmpty()) return "번호를 입력하세요";
        BtProfiles.init(context);

        TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
        Uri uri = Uri.fromParts("tel", number, null);

        try {
            List<PhoneAccountHandle> accounts = tm.getCallCapablePhoneAccounts();
            PhoneAccountHandle chosen = null;
            if (accounts != null) {
                for (PhoneAccountHandle h : accounts) {
                    String pkg = h.getComponentName().getPackageName().toLowerCase();
                    String cls = h.getComponentName().getClassName().toLowerCase();
                    if (pkg.contains("bluetooth") || cls.contains("hfp")) { chosen = h; break; }
                }
                if (chosen == null && !accounts.isEmpty()) chosen = accounts.get(0);
            }
            if (chosen != null) {
                Bundle b = new Bundle();
                b.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, chosen);
                tm.placeCall(uri, b);
                CallStateManager.onDialRequested(number);
                return null;
            }
        } catch (Throwable ignored) {}

        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty() && BtProfiles.dialViaHfp(devs.get(0), number)) {
            CallStateManager.onDialRequested(number);
            return null;
        }

        try {
            Intent i = new Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            CallStateManager.onDialRequested(number);
            return null;
        } catch (Throwable ignored) {}

        return "블루투스 핸즈프리 연결 또는 전화 권한을 확인하세요";
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean accept(Context context) {
        if (CallStateManager.isSimulating()) {
            CallStateManager.simulateAccept();
            return true;
        }
        BtProfiles.init(context);

        // 1단계: Telecom InCallService
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                tc.answer(VideoProfile.STATE_AUDIO_ONLY);
                return true;
            } catch (Throwable ignored) {}
        }

        // 2단계: BluetoothHeadsetClient.acceptCall(dev, CALL_ACCEPT_NONE=0)
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty()) {
            BluetoothDevice dev = devs.get(0);
            if (BtProfiles.invokeHfp("acceptCall",
                    new Class[]{BluetoothDevice.class, int.class}, new Object[]{dev, 0})) {
                return true;
            }
        }

        // 3단계: TelecomManager.acceptRingingCall()
        boolean telecomAccepted = false;
        try {
            ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).acceptRingingCall();
            telecomAccepted = true;
        } catch (Throwable ignored) {}

        // 4단계: 상태 확인형(Readback) 로컬 ADB 폴백 — 700ms 후에도 여전히 수신 중이면 KEYCODE_CALL(5)/HEADSETHOOK(79) 발사
        final Context app = context.getApplicationContext();
        final boolean alreadyTried = telecomAccepted;
        ADB_EXEC.execute(() -> {
            if (alreadyTried) {
                try { Thread.sleep(700L); } catch (InterruptedException ignored) {}
                HfpCall cur = CallStateManager.currentCall();
                if (cur == null || !cur.isRinging()) return;
            }
            NativeAdbClient.ShellResult r = NativeAdbClient.executeShell(app, "input keyevent 5", "127.0.0.1", 5555, 2500L);
            try { Thread.sleep(600L); } catch (InterruptedException ignored) {}
            HfpCall cur2 = CallStateManager.currentCall();
            if (!r.getSuccess() || (cur2 != null && cur2.isRinging())) {
                NativeAdbClient.executeShell(app, "input keyevent 79", "127.0.0.1", 5555, 2500L);
            }
        });
        return true;
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean endOrReject(Context context, boolean isRinging) {
        if (CallStateManager.isSimulating()) {
            CallStateManager.stopSimulation();
            return true;
        }
        BtProfiles.init(context);

        // 1단계: Telecom InCallService
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                if (isRinging) tc.reject(false, null);
                else tc.disconnect();
                return true;
            } catch (Throwable ignored) {}
        }

        // 2단계: BluetoothHeadsetClient (실제 BluetoothHeadsetClientCall 객체 우선 전달)
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty()) {
            BluetoothDevice dev = devs.get(0);
            boolean ok = false;
            if (isRinging) {
                ok = BtProfiles.invokeHfp("rejectCall",
                    new Class[]{BluetoothDevice.class}, new Object[]{dev});
            }
            if (!ok) {
                Class<?> cls = BtProfiles.callClass();
                if (cls != null) {
                    List<Object> liveCalls = BtProfiles.rawCurrentCalls(dev);
                    for (Object liveCall : liveCalls) {
                        if (BtProfiles.invokeHfp("terminateCall",
                                new Class[]{BluetoothDevice.class, cls}, new Object[]{dev, liveCall})) {
                            ok = true;
                        }
                    }
                    if (!ok) {
                        ok = BtProfiles.invokeHfp("terminateCall",
                            new Class[]{BluetoothDevice.class, cls}, new Object[]{dev, null});
                    }
                }
                if (!ok) {
                    ok = BtProfiles.invokeHfp("terminateCall",
                        new Class[]{BluetoothDevice.class, int.class}, new Object[]{dev, 0});
                }
            }
            if (ok) return true;
        }

        // 3단계: TelecomManager.endCall()
        boolean telecomEnded = false;
        try {
            telecomEnded = ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).endCall();
            if (telecomEnded) return true;
        } catch (Throwable ignored) {}

        // 4단계: 상태 확인형(Readback) 로컬 ADB 종료 폴백 — 여전히 통화 중이면 KEYCODE_ENDCALL(6) 발사
        final Context app = context.getApplicationContext();
        final boolean alreadyTried = telecomEnded;
        ADB_EXEC.execute(() -> {
            if (alreadyTried) {
                try { Thread.sleep(700L); } catch (InterruptedException ignored) {}
                if (CallStateManager.currentCall() == null) return;
            }
            NativeAdbClient.executeShell(app, "input keyevent 6", "127.0.0.1", 5555, 2500L);
        });
        return true;
    }

    public static boolean sendDtmf(char digit) {
        if (CallStateManager.isSimulating()) return true;
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                tc.playDtmfTone(digit);
                tc.stopDtmfTone();
                return true;
            } catch (Throwable ignored) {}
        }
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        return !devs.isEmpty() && BtProfiles.invokeHfp(
            "sendDTMF", new Class[]{BluetoothDevice.class, byte.class}, new Object[]{devs.get(0), (byte) digit});
    }

    public static boolean setMuted(Context context, boolean mute) {
        DolphinInCallService svc = DolphinInCallService.get();
        if (svc != null) svc.setMuted(mute);
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        try { am.setMicrophoneMute(mute); } catch (Throwable ignored) {}
        return am.isMicrophoneMute();
    }
}
