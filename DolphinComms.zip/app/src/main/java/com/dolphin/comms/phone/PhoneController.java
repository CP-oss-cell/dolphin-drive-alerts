package com.dolphin.comms.phone;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import java.util.List;

public final class PhoneController {
    private PhoneController() {}

    @SuppressLint("MissingPermission")
    public static String dial(Context context, String rawNumber) {
        String number = rawNumber == null ? "" : rawNumber.trim();
        if (number.isEmpty()) return "번호를 입력하세요";

        TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
        Uri uri = Uri.fromParts("tel", number, null);

        try {
            List<PhoneAccountHandle> accounts = tm.getCallCapablePhoneAccounts();
            PhoneAccountHandle chosen = null;
            if (accounts != null) {
                for (PhoneAccountHandle h : accounts) {
                    String pkg = h.getComponentName().getPackageName().toLowerCase();
                    String cls = h.getComponentName().getClassName().toLowerCase();
                    if (pkg.contains("bluetooth") || cls.contains("hfp")) { chosen = h; break; }
                }
                if (chosen == null && !accounts.isEmpty()) chosen = accounts.get(0);
            }
            if (chosen != null) {
                Bundle b = new Bundle();
                b.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, chosen);
                tm.placeCall(uri, b);
                CallStateManager.onDialRequested(number);
                return null;
            }
        } catch (Throwable ignored) {}

        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty() && BtProfiles.dialViaHfp(devs.get(0), number)) {
            CallStateManager.onDialRequested(number);
            return null;
        }

        try {
            Intent i = new Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            CallStateManager.onDialRequested(number);
            return null;
        } catch (Throwable ignored) {}

        return "블루투스 핸즈프리 연결 또는 전화 권한을 확인하세요";
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean accept(Context context) {
        if (CallStateManager.isSimulating()) {
            CallStateManager.simulateAccept();
            return true;
        }
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            tc.answer(VideoProfile.STATE_AUDIO_ONLY);
            return true;
        }
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty() && BtProfiles.invokeHfp(
                "acceptCall", new Class[]{BluetoothDevice.class, int.class}, new Object[]{devs.get(0), 0})) {
            return true;
        }
        try {
            ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).acceptRingingCall();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean endOrReject(Context context, boolean isRinging) {
        if (CallStateManager.isSimulating()) {
            CallStateManager.stopSimulation();
            return true;
        }
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            if (isRinging) tc.reject(false, null);
            else tc.disconnect();
            return true;
        }
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty()) {
            boolean ok;
            if (isRinging) {
                ok = BtProfiles.invokeHfp("rejectCall", new Class[]{BluetoothDevice.class}, new Object[]{devs.get(0)});
            } else {
                Class<?> cls = BtProfiles.callClass();
                ok = cls != null && BtProfiles.invokeHfp("terminateCall",
                    new Class[]{BluetoothDevice.class, cls}, new Object[]{devs.get(0), null});
            }
            if (ok) return true;
        }
        try {
            return ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).endCall();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean sendDtmf(char digit) {
        if (CallStateManager.isSimulating()) return true;
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            tc.playDtmfTone(digit);
            tc.stopDtmfTone();
            return true;
        }
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        return !devs.isEmpty() && BtProfiles.invokeHfp(
            "sendDTMF", new Class[]{BluetoothDevice.class, byte.class}, new Object[]{devs.get(0), (byte) digit});
    }

    public static boolean setMuted(Context context, boolean mute) {
        DolphinInCallService svc = DolphinInCallService.get();
        if (svc != null) svc.setMuted(mute);
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        try { am.setMicrophoneMute(mute); } catch (Throwable ignored) {}
        return am.isMicrophoneMute();
    }
}
