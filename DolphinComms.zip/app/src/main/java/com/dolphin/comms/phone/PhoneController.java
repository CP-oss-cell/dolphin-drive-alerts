package com.dolphin.comms.phone;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import com.dolphin.comms.adb.NativeAdbClient;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PhoneController {
    private static final ExecutorService ADB_EXEC = Executors.newSingleThreadExecutor();

    private PhoneController() {}

    @SuppressLint("MissingPermission")
    public static String dial(Context context, String rawNumber) {
        String number = rawNumber == null ? "" : rawNumber.trim();
        if (number.isEmpty()) return "번호를 입력하세요";
        BtProfiles.init(context);

        TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
        Uri uri = Uri.fromParts("tel", number, null);

        try {
            List<PhoneAccountHandle> accounts = tm.getCallCapablePhoneAccounts();
            PhoneAccountHandle chosen = null;
            if (accounts != null) {
                for (PhoneAccountHandle h : accounts) {
                    String pkg = h.getComponentName().getPackageName().toLowerCase();
                    String cls = h.getComponentName().getClassName().toLowerCase();
                    if (pkg.contains("bluetooth") || cls.contains("hfp")) { chosen = h; break; }
                }
                if (chosen == null && !accounts.isEmpty()) chosen = accounts.get(0);
            }
            if (chosen != null) {
                Bundle b = new Bundle();
                b.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, chosen);
                tm.placeCall(uri, b);
                CallStateManager.onDialRequested(number);
                return null;
            }
        } catch (Throwable ignored) {}

        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        if (!devs.isEmpty() && BtProfiles.dialViaHfp(devs.get(0), number)) {
            CallStateManager.onDialRequested(number);
            return null;
        }

        try {
            Intent i = new Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            CallStateManager.onDialRequested(number);
            return null;
        } catch (Throwable ignored) {}

        return "블루투스 핸즈프리 연결 또는 전화 권한을 확인하세요";
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean accept(Context context) {
        CallDebugLog.log("=== accept() clicked ===");
        if (CallStateManager.isSimulating()) {
            CallStateManager.simulateAccept();
            return true;
        }
        BtProfiles.init(context);

        // 1단계: Telecom InCallService (조기 리턴하지 않고 로그만 남긴 뒤 HFP/ADB 폴백까지 상태 확인)
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                tc.answer(VideoProfile.STATE_AUDIO_ONLY);
                CallDebugLog.log("1.Telecom.answer() invoked (state=" + tc.getState() + ")");
            } catch (Throwable t) {
                CallDebugLog.log("1.Telecom.answer() ERR: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            }
        } else {
            CallDebugLog.log("1.Telecom.answer() skipped (tc=null)");
        }

        // 2단계: BluetoothHeadsetClient.acceptCall(dev, 0)
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        CallDebugLog.log("2.HFP devices=" + devs.size());
        boolean hfpAccepted = false;
        if (!devs.isEmpty()) {
            BluetoothDevice dev = devs.get(0);
            hfpAccepted = BtProfiles.invokeHfp("acceptCall",
                new Class[]{BluetoothDevice.class, int.class}, new Object[]{dev, 0});
            if (!hfpAccepted) {
                hfpAccepted = BtProfiles.invokeHfp("acceptCall",
                    new Class[]{BluetoothDevice.class, int.class}, new Object[]{dev, 1});
            }
        }

        // 3단계: TelecomManager.acceptRingingCall()
        if (!hfpAccepted) {
            try {
                ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).acceptRingingCall();
                CallDebugLog.log("3.TelecomManager.acceptRingingCall() invoked");
            } catch (Throwable t) {
                CallDebugLog.log("3.TelecomManager.acceptRingingCall() ERR: " + t.getClass().getSimpleName());
            }
        }

        // 4단계: 상태 확인형(Readback) 로컬 ADB 폴백 — 550ms 후에도 여전히 수신 중이면 KEYCODE_CALL(5)/HEADSETHOOK(79) 발사
        final Context app = context.getApplicationContext();
        ADB_EXEC.execute(() -> {
            try { Thread.sleep(550L); } catch (InterruptedException ignored) {}
            HfpCall cur = CallStateManager.currentCall();
            if (cur == null || !cur.isRinging()) {
                CallDebugLog.log("4.ADB accept skipped (already not ringing: " + (cur == null ? "null" : cur.state) + ")");
                return;
            }
            NativeAdbClient.ShellResult r = NativeAdbClient.executeShell(app, "input keyevent 5", "127.0.0.1", 5555, 2500L);
            CallDebugLog.log("4.ADB keyevent 5 -> ok=" + r.getSuccess() + " msg=" + r.getMessage());
            try { Thread.sleep(550L); } catch (InterruptedException ignored) {}
            HfpCall cur2 = CallStateManager.currentCall();
            if (!r.getSuccess() || (cur2 != null && cur2.isRinging())) {
                NativeAdbClient.ShellResult r2 = NativeAdbClient.executeShell(app, "input keyevent 79", "127.0.0.1", 5555, 2500L);
                CallDebugLog.log("4.ADB keyevent 79 -> ok=" + r2.getSuccess() + " msg=" + r2.getMessage());
            }
        });
        return true;
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    public static boolean endOrReject(Context context, boolean isRinging) {
        CallDebugLog.log("=== endOrReject(ringing=" + isRinging + ") clicked ===");
        if (CallStateManager.isSimulating()) {
            CallStateManager.stopSimulation();
            return true;
        }
        BtProfiles.init(context);

        // 1단계: Telecom InCallService (조기 리턴하지 않고 HFP까지 병행 시도)
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                if (isRinging) tc.reject(false, null);
                else tc.disconnect();
                CallDebugLog.log("1.Telecom." + (isRinging ? "reject" : "disconnect") + "() invoked (state=" + tc.getState() + ")");
            } catch (Throwable t) {
                CallDebugLog.log("1.Telecom end ERR: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            }
        } else {
            CallDebugLog.log("1.Telecom end skipped (tc=null)");
        }

        // 2단계: BluetoothHeadsetClient (실제 BluetoothHeadsetClientCall 객체 우선 전달)
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        CallDebugLog.log("2.HFP devices=" + devs.size());
        boolean hfpEnded = false;
        if (!devs.isEmpty()) {
            BluetoothDevice dev = devs.get(0);
            if (isRinging) {
                hfpEnded = BtProfiles.invokeHfp("rejectCall",
                    new Class[]{BluetoothDevice.class}, new Object[]{dev});
            }
            if (!hfpEnded) {
                Class<?> cls = BtProfiles.callClass();
                if (cls != null) {
                    List<Object> liveCalls = BtProfiles.rawCurrentCalls(dev);
                    CallDebugLog.log("2.HFP liveRawCalls=" + liveCalls.size());
                    for (Object liveCall : liveCalls) {
                        if (BtProfiles.invokeHfp("terminateCall",
                                new Class[]{BluetoothDevice.class, cls}, new Object[]{dev, liveCall})) {
                            hfpEnded = true;
                        }
                    }
                    if (!hfpEnded) {
                        hfpEnded = BtProfiles.invokeHfp("terminateCall",
                            new Class[]{BluetoothDevice.class, cls}, new Object[]{dev, null});
                    }
                }
                if (!hfpEnded) {
                    hfpEnded = BtProfiles.invokeHfp("terminateCall",
                        new Class[]{BluetoothDevice.class, int.class}, new Object[]{dev, 0});
                }
            }
        }

        // 3단계: TelecomManager.endCall()
        if (!hfpEnded) {
            try {
                boolean telecomEnded = ((TelecomManager) context.getSystemService(Context.TELECOM_SERVICE)).endCall();
                CallDebugLog.log("3.TelecomManager.endCall() -> " + telecomEnded);
            } catch (Throwable t) {
                CallDebugLog.log("3.TelecomManager.endCall() ERR: " + t.getClass().getSimpleName());
            }
        }

        // 4단계: 상태 확인형(Readback) 로컬 ADB 종료 폴백 — 550ms 후에도 통화 중이면 KEYCODE_ENDCALL(6) 발사
        final Context app = context.getApplicationContext();
        ADB_EXEC.execute(() -> {
            try { Thread.sleep(550L); } catch (InterruptedException ignored) {}
            HfpCall cur = CallStateManager.currentCall();
            if (cur == null) {
                CallDebugLog.log("4.ADB end skipped (call already ended)");
                return;
            }
            NativeAdbClient.ShellResult r = NativeAdbClient.executeShell(app, "input keyevent 6", "127.0.0.1", 5555, 2500L);
            CallDebugLog.log("4.ADB keyevent 6 -> ok=" + r.getSuccess() + " msg=" + r.getMessage());
        });
        return true;
    }

    public static boolean sendDtmf(char digit) {
        if (CallStateManager.isSimulating()) return true;
        Call tc = CallStateManager.activeTelecomCall();
        if (tc != null) {
            try {
                tc.playDtmfTone(digit);
                tc.stopDtmfTone();
                return true;
            } catch (Throwable ignored) {}
        }
        List<BluetoothDevice> devs = BtProfiles.hfpDevices();
        return !devs.isEmpty() && BtProfiles.invokeHfp(
            "sendDTMF", new Class[]{BluetoothDevice.class, byte.class}, new Object[]{devs.get(0), (byte) digit});
    }

    public static boolean setMuted(Context context, boolean mute) {
        DolphinInCallService svc = DolphinInCallService.get();
        if (svc != null) svc.setMuted(mute);
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        try { am.setMicrophoneMute(mute); } catch (Throwable ignored) {}
        return am.isMicrophoneMute();
    }
}
