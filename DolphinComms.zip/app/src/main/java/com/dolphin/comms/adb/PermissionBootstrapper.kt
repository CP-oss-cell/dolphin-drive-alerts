package com.dolphin.comms.adb

import android.content.ComponentName
import android.content.Context
import android.os.Build
import com.dolphin.comms.sms.EmergencyNotificationListener

/**
 * 주행보조 앱(DolphinDriveAlerts)과 동일한 방식의 앱 내 로컬 ADB 일괄 권한 부여 및 Readback 검증기.
 */
object PermissionBootstrapper {
    data class Result(val success: Boolean, val summary: String, val lines: List<String>)

    interface ProgressCallback {
        fun onProgress(message: String)
    }

    @JvmStatic
    fun applyAll(context: Context, callback: ProgressCallback?): Result {
        val app = context.applicationContext
        val pkg = app.packageName
        val lines = mutableListOf<String>()

        val auth = NativeAdbClient.waitForAuthorization(app, maxWaitMs = 30_000L) { msg ->
            callback?.onProgress(msg)
        }
        lines += "• 로컬 ADB(127.0.0.1:5555): ${if (auth.success) "연결 및 인증 완료" else "실패 (${auth.message})"}"
        if (!auth.success) {
            lines += "• 차량 개발자 옵션에서 무선/로컬 ADB(5555)가 켜져 있는지 확인하세요."
            return Result(false, "로컬 ADB 연결 실패", lines)
        }

        fun shell(cmd: String) = NativeAdbClient.executeShell(app, cmd, timeoutMs = 6_000L)

        // 1. 런타임 + Android 10+ 제한 권한 (통화기록/문자/MMS/블루투스)
        callback?.onProgress("전화·통화기록·문자·MMS 제한 권한 부여 중...")
        val perms = mutableListOf(
            "android.permission.CALL_PHONE",
            "android.permission.READ_PHONE_STATE",
            "android.permission.ANSWER_PHONE_CALLS",
            "android.permission.READ_CONTACTS",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_MMS",
            "android.permission.RECEIVE_WAP_PUSH",
            "com.android.bluetooth.permission.READ_CONTENTPROVIDER"
        )
        if (Build.VERSION.SDK_INT >= 31) perms += "android.permission.BLUETOOTH_CONNECT"
        if (Build.VERSION.SDK_INT >= 33) perms += "android.permission.POST_NOTIFICATIONS"

        var grantedCount = 0
        for (p in perms) {
            val r = shell("pm grant $pkg $p")
            if (r.success) grantedCount++
        }
        lines += "• pm grant 권한 부여: $grantedCount/${perms.size}건 처리"

        // 2. 오버레이 & SMS/통화기록 AppOps + 백그라운드 유지
        callback?.onProgress("작은 수신화면 오버레이 및 백그라운드 권한 부여 중...")
        shell("appops set $pkg SYSTEM_ALERT_WINDOW allow")
        shell("appops set $pkg WRITE_SMS allow")
        shell("appops set $pkg READ_SMS allow")
        shell("appops set $pkg READ_CALL_LOG allow")
        shell("appops set $pkg RUN_IN_BACKGROUND allow")
        shell("appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        shell("appops set $pkg WAKE_LOCK allow")
        shell("dumpsys deviceidle whitelist +$pkg")

        val overlayOk = shell("appops get $pkg SYSTEM_ALERT_WINDOW").output.contains("allow", ignoreCase = true)
        val batteryOk = shell("dumpsys deviceidle whitelist").output.contains(pkg)
        lines += "• 작은 수신화면 오버레이: ${if (overlayOk) "허용 확인" else "미확인"} · 배터리 제외: ${if (batteryOk) "확인" else "미확인"}"

        // 3. 기본 전화 앱(ROLE_DIALER) & 기본 문자 앱(ROLE_SMS)
        callback?.onProgress("기본 전화 앱 및 기본 문자 앱 지정 중...")
        val dialerRes = shell("cmd role add-role-holder android.app.role.DIALER $pkg")
        val smsRes = shell("cmd role add-role-holder android.app.role.SMS $pkg")
        lines += "• 기본 전화(DIALER): ${if (dialerRes.success) "지정 완료" else "수동 확인 필요"} · 기본 문자(SMS): ${if (smsRes.success) "지정 완료" else "수동 확인 필요"}"

        // 4. 시스템 재난문자(CBS) 알림 폴백 리스너 활성화 (기존 리스너 보존 병합)
        callback?.onProgress("긴급재난문자 알림 리스너 활성화 중...")
        val listenerComp = ComponentName(app, EmergencyNotificationListener::class.java).flattenToString()
        val allowRes = shell("cmd notification allow_listener $listenerComp")
        if (!allowRes.success) {
            val prev = shell("settings get secure enabled_notification_listeners")
            if (prev.success) {
                val merged = prev.output.trim().takeUnless { it.isBlank() || it == "null" }.orEmpty()
                    .split(':').filter { it.isNotBlank() }.toMutableList()
                    .apply { if (listenerComp !in this) add(listenerComp) }
                    .distinct().joinToString(":")
                val quoted = merged.replace("'", "'\''")
                shell("settings put secure enabled_notification_listeners '$quoted'")
            }
        }
        val listenerOk = shell("settings get secure enabled_notification_listeners").output
            .split(':').map(String::trim).contains(listenerComp)
        lines += "• 재난문자 알림 리스너: ${if (listenerOk) "활성화 확인" else "미확인"}"

        callback?.onProgress("BYD 블루투스 연락처 동기화 중...")
        val syncedContacts = BydAdbContactsSync.syncBlocking(app)
        lines += "• 블루투스 연락처 동기화: ${if (syncedContacts >= 0) "${syncedContacts}건 캐시 완료" else "연결 대기 중"}"

        val overallOk = overlayOk && batteryOk
        val summary = if (overallOk) "앱 내 ADB 권한 일괄 부여 완료!" else "일부 권한 부여 완료 (로그 확인)"
        return Result(overallOk, summary, lines)
    }

    @JvmStatic
    fun setBydStockPopupBlocked(context: Context, block: Boolean, callback: ProgressCallback?): Result {
        val app = context.applicationContext
        val lines = mutableListOf<String>()
        val auth = NativeAdbClient.waitForAuthorization(app, maxWaitMs = 20_000L) { msg ->
            callback?.onProgress(msg)
        }
        if (!auth.success) {
            lines += "• 로컬 ADB 연결 실패: ${auth.message}"
            return Result(false, "로컬 ADB 연결 실패", lines)
        }

        fun shell(cmd: String) = NativeAdbClient.executeShell(app, cmd, timeoutMs = 6_000L)

        callback?.onProgress("BYD 순정 전화 UI 패키지 탐색 중...")
        val listRes = shell("pm list packages")
        val allPkgs = listRes.output.lines()
            .map { it.removePrefix("package:").trim() }
            .filter { it.isNotEmpty() }

        // com.android.bluetooth (HFP 엔진)는 절대 건드리지 않고, BYD 순정 전화 UI 패키지만 선별
        val knownCandidates = setOf(
            "com.byd.bluetoothcall",
            "com.byd.btphone",
            "com.byd.phone",
            "com.byd.dialer",
            "com.byd.app.bluetoothcall"
        )
        val targets = allPkgs.filter { pkg ->
            pkg != app.packageName &&
            pkg != "com.android.bluetooth" &&
            !pkg.startsWith("com.android.bluetooth.") &&
            (pkg in knownCandidates ||
                (pkg.startsWith("com.byd.") &&
                    (pkg.contains("call") || pkg.contains("phone") || pkg.contains("dialer"))))
        }.distinct()

        if (targets.isEmpty()) {
            lines += "• BYD 순정 전화 UI 패키지를 찾지 못했습니다."
            return Result(false, "순정 전화 UI 패키지 미발견", lines)
        }

        var okCount = 0
        for (pkg in targets) {
            if (block) {
                callback?.onProgress("$pkg 팝업 차단 적용 중...")
                shell("appops set $pkg SYSTEM_ALERT_WINDOW ignore")
                val dis = shell("pm disable-user --user 0 $pkg")
                if (!dis.success) shell("pm hide $pkg")
                shell("am force-stop $pkg")
                val disabledCheck = shell("pm list packages -d").output.contains(pkg)
                if (disabledCheck || dis.success) okCount++
                lines += "• $pkg: ${if (disabledCheck || dis.success) "순정 팝업 차단 완료" else "오버레이 무시 적용됨"}"
            } else {
                callback?.onProgress("$pkg 순정 팝업 복구 중...")
                shell("pm unhide $pkg")
                val en = shell("pm enable $pkg")
                shell("appops set $pkg SYSTEM_ALERT_WINDOW allow")
                if (en.success) okCount++
                lines += "• $pkg: ${if (en.success) "순정 복구 완료" else "복구 시도됨"}"
            }
        }

        val summary = if (block) {
            "BYD 순정 전화 팝업 차단 완료 (${okCount}/${targets.size})"
        } else {
            "BYD 순정 전화 팝업 복구 완료 (${okCount}/${targets.size})"
        }
        lines += "• 블루투스 엔진(com.android.bluetooth)은 유지되어 HFP 통화는 정상 동작합니다."
        return Result(okCount > 0, summary, lines)
    }
}
