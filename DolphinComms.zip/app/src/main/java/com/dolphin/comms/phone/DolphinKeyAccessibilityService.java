package com.dolphin.comms.phone;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import com.dolphin.comms.ui.MainActivity;

/**
 * 핸들 리모컨 전화 버튼(KEYCODE_CALL / ENDCALL / HEADSETHOOK 등)을
 * 티맵·홈 등 어떤 화면 위에서도 실시간으로 가로채 DolphinComms로 연결합니다.
 */
public class DolphinKeyAccessibilityService extends AccessibilityService {
    private static volatile boolean connected = false;

    public static boolean isConnected() {
        return connected;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        connected = true;
        CallDebugLog.log("KeyAccessibilityService connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 키 이벤트 전용 경량 서비스 — UI 트리 조회 없음
    }

    @Override
    public void onInterrupt() {
        connected = false;
    }

    @Override
    public void onDestroy() {
        connected = false;
        super.onDestroy();
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event == null) return false;
        int code = event.getKeyCode();
        int action = event.getAction();

        // 볼륨/뒤로가기/홈 외의 하드웨어 키(핸들 리모컨 등)는 진단을 위해 기록
        if (action == KeyEvent.ACTION_DOWN
                && code != KeyEvent.KEYCODE_VOLUME_UP
                && code != KeyEvent.KEYCODE_VOLUME_DOWN
                && code != KeyEvent.KEYCODE_BACK
                && code != KeyEvent.KEYCODE_HOME) {
            CallDebugLog.log("HWKey DOWN code=" + code
                + " (" + KeyEvent.keyCodeToString(code) + ") scan=" + event.getScanCode());
        }

        boolean isCallKey = (code == KeyEvent.KEYCODE_CALL || code == KeyEvent.KEYCODE_HEADSETHOOK);
        boolean isEndKey = (code == KeyEvent.KEYCODE_ENDCALL);
        if (!isCallKey && !isEndKey) return false;

        if (action == KeyEvent.ACTION_DOWN) {
            HfpCall cur = CallStateManager.currentCall();
            if (isEndKey) {
                if (cur != null) {
                    PhoneController.endOrReject(this, cur.isRinging());
                    return true;
                }
                return false;
            }
            // 단일 전화 버튼(KEYCODE_CALL / HEADSETHOOK):
            // 수신 중 -> 받기, 통화 중 -> 종료, 대기 중 -> DolphinComms 최근기록 열기
            if (cur != null && cur.isRinging()) {
                PhoneController.accept(this);
                return true;
            } else if (cur != null) {
                PhoneController.endOrReject(this, false);
                return true;
            } else {
                try {
                    Intent open = new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("open_tab", 1);
                    startActivity(open);
                } catch (Throwable ignored) {}
                return true;
            }
        }
        // ACTION_UP 도 소비해 순정 앱으로 중복 전달 방지
        return true;
    }
}
