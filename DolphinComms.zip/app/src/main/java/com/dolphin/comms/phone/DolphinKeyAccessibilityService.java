package com.dolphin.comms.phone;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import com.dolphin.comms.ui.MainActivity;

/**
 * BYD 돌핀 핸들 리모컨 전화 버튼(code=313 / KEYCODE_DIAL_ANSWER_CALL / scan=266 및 표준 CALL/ENDCALL)을
 * 티맵·홈 등 어떤 화면 위에서도 실시간으로 가로채 DolphinComms로 연결합니다.
 */
public class DolphinKeyAccessibilityService extends AccessibilityService {
    private static final int BYD_KEYCODE_DIAL_ANSWER_CALL = 313;
    private static final int BYD_SCANCODE_PHONE = 266;
    private static final long DEBOUNCE_MS = 600L;

    private static volatile boolean connected = false;
    private long lastHandledMs = 0L;

    public static boolean isConnected() {
        return connected;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        connected = true;
        CallDebugLog.log("KeyAccessibilityService connected (BYD 313/266 ready)");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 키 이벤트 전용 경량 서비스 — UI 트리 조회 없음
    }

    @Override
    public void onInterrupt() {
        connected = false;
    }

    @Override
    public void onDestroy() {
        connected = false;
        super.onDestroy();
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (event == null) return false;
        int code = event.getKeyCode();
        int scan = event.getScanCode();
        int action = event.getAction();
        String name = KeyEvent.keyCodeToString(code);

        boolean isEndKey = (code == KeyEvent.KEYCODE_ENDCALL);
        boolean isCallKey = (code == BYD_KEYCODE_DIAL_ANSWER_CALL
            || scan == BYD_SCANCODE_PHONE
            || code == KeyEvent.KEYCODE_CALL
            || code == KeyEvent.KEYCODE_HEADSETHOOK
            || (name != null && (name.contains("ANSWER_CALL") || name.contains("DIAL_CALL"))));

        if (!isCallKey && !isEndKey) {
            if (action == KeyEvent.ACTION_DOWN
                    && code != KeyEvent.KEYCODE_VOLUME_UP
                    && code != KeyEvent.KEYCODE_VOLUME_DOWN
                    && code != KeyEvent.KEYCODE_BACK
                    && code != KeyEvent.KEYCODE_HOME) {
                CallDebugLog.log("HWKey DOWN code=" + code + " (" + name + ") scan=" + scan);
            }
            return false;
        }

        // ACTION_UP 은 소비만 해서 순정 앱으로 중복 전달 차단
        if (action != KeyEvent.ACTION_DOWN) return true;

        // 길게 누름/연타로 인한 200ms 반복 입력 디바운스
        long now = SystemClock.elapsedRealtime();
        if (now - lastHandledMs < DEBOUNCE_MS || event.getRepeatCount() > 0) {
            return true;
        }
        lastHandledMs = now;

        HfpCall cur = CallStateManager.currentCall();
        CallDebugLog.log("SteeringPhoneKey HANDLED code=" + code + " scan=" + scan
            + " callState=" + (cur == null ? "idle" : cur.state));

        if (isEndKey) {
            if (cur != null) PhoneController.endOrReject(this, cur.isRinging());
            return true;
        }

        // 단일 전화 버튼(BYD 313/266, CALL, HEADSETHOOK):
        // 수신 중 -> 받기 / 통화 중 -> 종료 / 대기 중 -> DolphinComms 최근기록 열기
        if (cur != null && cur.isRinging()) {
            PhoneController.accept(this);
        } else if (cur != null) {
            PhoneController.endOrReject(this, false);
        } else {
            try {
                Intent open = new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("open_tab", 1);
                startActivity(open);
            } catch (Throwable ignored) {}
        }
        return true;
    }
}
