# Dolphin Drive Alerts v0.17.29 — DA-010 기존 순정 TMAP 검사 원본 ZIP 누락 보수

## 이 변경이 해결하는 문제
10월 10~11일 실차 자료에는 `2602_OEM_NAV_GUIDANCE` 와 `2602_THIRD_PARTY_NAV_GUIDANCE` 실행 마커가 있었지만, 당시 일반 `DolphinDriveLogs_*.zip`은 START·STOP 진단 폴더만 내보냈습니다. 내비 실험실은 `nav_audio_lab`에 별도 보관되어 수동으로 다른 ZIP을 저장해야 했습니다. 이 설계 결함을 사용자 조작 단계 추가 없이 수정했습니다.

## 실제 소스 수정
- `log/UnifiedLogCapture.kt`: 세션 기간에 요청된 `external_speaker_diag`의 모든 캡처 폴더와 `nav_audio_lab`의 3·8·15초 검사 폴더를 일반 ZIP에 포함. 기존 START/STOP, 로그 JSONL, 수집 연속성 저장 유지.
- `log/SessionDiagnosticSelector.kt`: 요청 시각 우선, 옛 진단은 폴더 시각 보조로 세션 선택. 다른 날짜·다른 세션의 캡처는 선택하지 않음. `observations.tsv`, `uid_relay_status.log`도 세션 시각 행만 포함.
- `log/SystemDiagnosticsCollector.kt`: 비동기 처리로 실행이 밀려도 정확한 캡처 **요청 시각** `requestedAtMs`를 저장. 차량/오디오 write 없음.
- `audio/NavRouteCaptureService.kt`: 백그라운드 큐에 등록하기 전에 시작 마커를 저장해 '종료' 직후 발생하는 누락 경쟁 상태 차단.
- 내비 스캔이 아직 진행 중이면 최대 20초 대기. 미완료면 **성공으로 표시하지 않고** 다음 '수집 종료'에서 동일 세션 저장 재시도. 이미 완료된 수집은 유실하지 않음.
- `evidence_manifest.json`: 파일별 bytes + SHA256, 포함 파일 수, 내비 부분실패 수 기록. ZIP CRC 및 해시/파일 수 검증 통과 후에만 Downloads에 공개. `session.json`에 포함 진단 폴더·내비 완료 상태 명시.

## 안전 및 보존
기존 9개 메인 메뉴, NORMAL/BSD/2분할/외부스피커 기능 코드, 오디오 출력, Edge 남녀 음성 60개 생성 흐름은 손대지 않았습니다. 이번 버전은 DA-010 증거 누락 수정이며, 타사 내비 운전석 **단독 출력 성공을 뜻하지 않습니다**. 차량의 오디오 믹서나 AVAS/ECU에는 쓰기 명령이 없습니다.

## 검증 경계
- 신규 정적 검사 20/20 PASS
- 순수 Kotlin 실제 JVM 실행 검사: 빠른 순정 캡처/종료, 세션 구분, 내비 COMPLETE/PARTIAL/IN_PROGRESS, 관찰 로그 시간 필터 PASS
- 기존 9메뉴 16/16, 내비 21/21, 주행 통합 25/25 검사 PASS
- Gradle 전체 Android 컴파일: **GitHub Actions 확인 전**
- 새로운 실차 ZIP 내에서 순정 내비의 activeOutput·driver only: **사용자 실차 재확인 전**

## 한 번만 하는 실차 확인(정차 P)
앱 메인 > 로그 수집 시작 > 기존 순정 TMAP 검사 (또는 순정 내비 15초 스캔) > 원하는 타사 내비 검사 > 로그 수집 종료 > 최신 ZIP 공유. 더는 내비 실험실에서 ZIP을 별도로 저장할 필요가 없도록 설계했습니다. 긴 스캔 중에 수집 종료를 누르면 '아직 진행 중' 안내에 따라 완료 후 '수집 종료'를 한 번 더 누릅니다. 실제 수집 내용은 `session.json`과 `evidence_manifest.json`에 적힙니다.
