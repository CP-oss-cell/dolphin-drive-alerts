# v0.17.29 GitHub 빌드·설치

1. `DolphinDriveAlerts-v0.17.29-TMAP-LOG-EXPORT-REPAIR-source.zip`을 GitHub 저장소 최상위에 올립니다.
2. `build-v01729-tmap-log-export.yml`을 `.github/workflows/build-v01729-tmap-log-export.yml`로 올립니다.
3. Actions에서 `Build Dolphin Drive Alerts v0.17.29 TMAP Evidence ZIP` 실행 → 최종 APK 산출물 다운로드.
4. 기존 앱을 삭제하지 마세요. 이 APK는 패키지 `com.byd.dolphin.drivealerts`, versionCode 55입니다. 설치 중인 APK와 서명 인증서가 같아야 설정과 로그를 유지한 채 업데이트됩니다. `DOLPHIN_DEBUG_KEYSTORE_B64` 고정 키 사용을 권장합니다. 달라진 키라면 사용 기록을 잃는 재설치를 먼저 제안하지 않습니다.
5. APK 안의 Edge 남녀 WAV 60개, 버전 55, 서명 인증서 지문을 CI에서 점검합니다.

이번은 **기존 TMAP/타사 내비 테스트 결과가 ZIP에서 누락되는 문제의 소스 수정본**입니다. 주행모드나 앱별 오디오 원본 라우팅이 해결됐다는 의미가 아닙니다. Android 전체 컴파일과 신규 실차 검증은 별도 필요합니다.
