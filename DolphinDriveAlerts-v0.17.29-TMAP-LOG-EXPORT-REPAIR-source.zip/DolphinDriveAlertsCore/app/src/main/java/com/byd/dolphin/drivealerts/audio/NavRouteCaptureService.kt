package com.byd.dolphin.drivealerts.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Background A/B dumpsys snapshots while the stock or third-party navigation app is in front. */
class NavRouteCaptureService : Service() {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "nav-audio-capture") }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val label = intent?.getStringExtra(EXTRA_LABEL)?.replace(Regex("[^A-Za-z0-9_.-]"), "_")?.take(48) ?: "UNNAMED"
        val target = intent?.getStringExtra(EXTRA_PACKAGE) ?: ""
        val channel = "nav_route_lab_v01720"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(channel,"오디오 경로 실험실 수집",NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("오디오 라우팅 실험실")
            .setContentText("$label 안내음 오디오 경로 수집 중 · 읽기 전용")
            .setOngoing(true).build()
        startForeground(1720, notification)
        // Create the capture session marker before scheduling work. This closes the
        // race where a user presses "수집 종료" before the worker creates its folder.
        val requestedAt = System.currentTimeMillis()
        val dir = File(filesDir, "nav_audio_lab/${stamp()}_$label").apply { mkdirs() }
        val marked = runCatching {
            File(dir, "metadata.json").writeText(JSONObject().apply {
                put("label", label); put("targetPackage",target)
                put("startMs",requestedAt); put("captures","3,8,15 seconds")
                put("note","Only read-only dumpsys and pm list commands. Audio output has not been modified.")
            }.toString(2))
        }.isSuccess
        if (!marked) {
            CoreLog.w("NAV_AUDIO_LAB", "Could not persist scan marker: ${dir.name}")
            stopSelfResult(startId)
            return START_NOT_STICKY
        }
        worker.execute {
            try {
                var failures = 0
                val start = android.os.SystemClock.elapsedRealtime()
                for ((idx, elapsed) in listOf(3_000L,8_000L,15_000L).withIndex()) {
                    val wait = start + elapsed - android.os.SystemClock.elapsedRealtime()
                    if (wait > 0) Thread.sleep(wait)
                    val out = File(dir,"snapshot_${idx+1}").apply { mkdirs() }
                    val commands = linkedMapOf(
                        "audio.txt" to "dumpsys audio",
                        "policy.txt" to "dumpsys media.audio_policy",
                        "flinger.txt" to "dumpsys media.audio_flinger",
                        "packages_uid.txt" to "pm list packages -U"
                    )
                    for ((name, command) in commands) {
                        val result = NativeAdbClient.executeShell(applicationContext,command,timeoutMs=8_000L)
                        if (!result.success) failures++
                        File(out,name).writeText("# captureMs=${System.currentTimeMillis()} success=${result.success} exit=${result.exitCode} message=${result.message.take(240)}\n" + result.output.take(600_000))
                    }
                }
                File(dir,if(failures==0) "COMPLETE.txt" else "PARTIAL_FAILED_COMMANDS.txt").writeText("수집 종료: ${System.currentTimeMillis()}; commandFailures=$failures\nUID/stream/output은 기록만 했습니다. 실제 운전석 출력은 귀로 검증해야 합니다.\n")
                CoreLog.i("NAV_AUDIO_LAB","Capture $label complete directory=${dir.name}")
            } catch (e: Exception) {
                File(dir,"FAILED.txt").writeText("${e.javaClass.simpleName}: ${e.message}")
                CoreLog.w("NAV_AUDIO_LAB","Capture $label failed: ${e.message}")
            } finally { stopSelfResult(startId) }
        }
        return START_NOT_STICKY
    }
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(Date())
    companion object {
        const val EXTRA_LABEL="label"
        const val EXTRA_PACKAGE="target_package"
    }
}
