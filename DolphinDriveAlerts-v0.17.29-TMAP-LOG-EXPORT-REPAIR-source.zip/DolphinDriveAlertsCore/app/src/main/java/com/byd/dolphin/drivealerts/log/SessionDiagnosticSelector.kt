package com.byd.dolphin.drivealerts.log

import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/** Pure JVM selector: never leak another recording session into an exported ZIP. */
internal object SessionDiagnosticSelector {
    private val epochPattern = Regex("\\\"([A-Za-z]+Ms)\\\"\\s*:\\s*(\\d{10,17})")
    private val filenamePattern = Regex("^(\\d{8}_\\d{6}_\\d{3})(?:_.*)?$")

    fun inSession(time: Long?, begin: Long, end: Long): Boolean =
        time != null && begin > 0 && end >= begin && time in begin..end

    fun captureTime(dir: File, metadataName: String, vararg preferredFields: String): Long? {
        val meta = File(dir, metadataName)
        if (meta.isFile) {
            // Own JSON metadata holds numeric timestamps; parsing these never executes a command.
            val values = runCatching { epochPattern.findAll(meta.readText(Charsets.UTF_8).take(12_000))
                .associate { it.groupValues[1] to it.groupValues[2].toLong() } }.getOrNull().orEmpty()
            preferredFields.firstNotNullOfOrNull { values[it] }?.let { return it }
        }
        val prefix = filenamePattern.matchEntire(dir.name)?.groupValues?.get(1) ?: return null
        return runCatching {
            SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).apply { isLenient = false }
                .parse(prefix)?.time
        }.getOrNull()
    }

    fun diagnosticFolders(root: File?, begin: Long, end: Long, sessionId: String): List<File> =
        root?.listFiles().orEmpty().filter { it.isDirectory &&
            (it.name.endsWith("UNIFIED_START_$sessionId") ||
                it.name.endsWith("UNIFIED_STOP_$sessionId") ||
                inSession(captureTime(it, "00_meta.json", "requestedAtMs", "timestampMs"), begin, end))
        }.sortedBy { it.name }

    fun navigationFolders(root: File, begin: Long, end: Long): List<File> =
        root.listFiles().orEmpty().filter { it.isDirectory &&
            inSession(captureTime(it, "metadata.json", "startMs"), begin, end)
        }.sortedBy { it.name }

    fun navigationStatus(folder: File): String = when {
        File(folder, "COMPLETE.txt").isFile -> "COMPLETE"
        File(folder, "PARTIAL_FAILED_COMMANDS.txt").isFile -> "PARTIAL_COMMAND_FAILURE"
        File(folder, "FAILED.txt").isFile -> "FAILED"
        else -> "IN_PROGRESS"
    }

    /** TSV / status lines begin with an epoch timestamp; never export history from other sessions. */
    fun filterTimedLines(file: File, begin: Long, end: Long): ByteArray = buildString {
        file.forEachLine(Charsets.UTF_8) { line ->
            val time = line.takeWhile { it.isDigit() }.toLongOrNull()
            if (inSession(time, begin, end)) append(line).append('\n')
        }
    }.toByteArray(Charsets.UTF_8)
}
