#!/usr/bin/env python3
"""Static UI guard: home 9+logging and old behavior retained; not a real-car pass."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt').read_text()
base=(root/'app/build.gradle.kts').read_text()
checks={
  'version-code-at-least-54':(lambda m: bool(m) and int(m.group(1)) >= 54)(re.search(r'versionCode\s*=\s*(\d+)',base)),
  'version-nine-menu-or-later': bool(re.search(r'versionName\s*=\s*\"0\.17\.(28|29)[^\"]*\"',base)),
  'exactly-nine-feature-entries': all(q in main for q in [
      '자동차 주행 보조 알림','부팅 시 앱 자동 실행','화면 분할','화면 회전 · DPI',
      '이퀄라이저 · 음장 효과','BSD 감지 알림','내비 5종 운전석 알림',
      '외부 스피커(차량 밖) 알림','ADB 권한 부여']),
  'log-is-last': '"ADB 권한 부여",\n            "로그 수집 · 자동 점검 · ZIP 공유"' in main,
  'collapsed-at-start':'visibility = View.GONE' in main and 'cards.forEach { it.visibility = View.GONE }' in main,
  'group-all-old-sections':main.count('to 1,') >= 4 and main.count('to 9,') >= 2,
  'keep-capture-start-stop':main.count('text = "수집 시작"')==1 and main.count('text = "수집 종료"')==1,
  'keep-capture-wiring':'DrivingAlertService.beginUnifiedCapture(this@MainActivity)' in main and 'DrivingAlertService.endUnifiedCapture(this@MainActivity)' in main,
  'share-downloaded-zip':'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in main and 'Intent.ACTION_SEND' in main and 'FLAG_GRANT_READ_URI_PERMISSION' in main,
  'auto-check-read-only':'private fun runReadOnlyAutoCheck()' in main and 'USER_AUTOMATED_READONLY_CHECK' in main,
  'clear-unsupported-audio':'체크는 대상 저장이며 실제 출력 성공을 뜻하지 않습니다' in main,
  'bdc-option-preserved':all(x in main for x in ['bsdBlinkerEnabled','bsdTurnSoundExperimentalEnabled','bsdInstantEnabled']),
  'nav-five-targets':'ExternalAppAudioRouter.NAVIGATION_APPS.forEachIndexed' in main,
  'user-preferences-not-reset':'clear()' not in main and 'deleteSharedPreferences' not in main,
  'no-unsafe-oem-write':'setAVAS' not in main and 'setVehicleMode' not in main,
  'core-activities-retained':all(x in main for x in ['AutoLaunchSettingsActivity','SplitProfilesActivity','AudioTuningActivity','DriveModeCalibrationActivity','NavAudioLabActivity','AdbSetupActivity','AppPermissionManagerActivity']),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' '+k)
print(f'REDESIGN_SOURCE_CHECKS={sum(checks.values())}/{len(checks)}')
raise SystemExit(0 if all(checks.values()) else 1)
