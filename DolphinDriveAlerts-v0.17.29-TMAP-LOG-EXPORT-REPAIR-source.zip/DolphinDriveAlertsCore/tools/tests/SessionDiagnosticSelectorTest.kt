package com.byd.dolphin.drivealerts.log

import java.io.File
import java.nio.file.Files
import java.text.SimpleDateFormat
import java.util.Locale

fun main() {
    val root = Files.createTempDirectory("dolphin-nav-test").toFile()
    try {
        fun stamp(time: Long): String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(time)
        val begin = 1792570000000L
        val end = begin + 110000L
        val diag = File(root, "external_speaker_diag").apply { mkdir() }
        val nav = File(root, "nav_audio_lab").apply { mkdir() }
        val forced = File(diag, "${stamp(end+100000)}_UNIFIED_STOP_XYZ").apply { mkdir() }
        val within = File(diag, "${stamp(begin+20000)}_2602_OEM_NAV_GUIDANCE").apply { mkdir() }
        File(within, "00_meta.json").writeText("""{"timestampMs":${end+60000},"requestedAtMs":${begin+20000}}""")
        val old = File(diag, "${stamp(begin-100000)}_2602_OLD").apply { mkdir() }
        File(old, "00_meta.json").writeText("""{"timestampMs":${begin-100000}}""")
        val stock = File(nav, "${stamp(begin+21000)}_STOCK_TMAP").apply { mkdir() }
        File(stock, "metadata.json").writeText("""{"startMs":${begin+21000},"label":"STOCK_TMAP"}""")
        File(stock,"COMPLETE.txt").writeText("pass")
        val third = File(nav, "${stamp(begin+50000)}_THIRD_MCON_K").apply { mkdir() }
        File(third, "metadata.json").writeText("""{"startMs":${begin+50000},"label":"THIRD"}""")
        val past = File(nav, "${stamp(begin-150000)}_STOCK_TMAP").apply { mkdir() }
        File(past, "metadata.json").writeText("""{"startMs":${begin-150000}}""")
        val sys = SessionDiagnosticSelector.diagnosticFolders(diag, begin, end, "XYZ")
        check(sys.toSet()==setOf(forced,within)) { "Quick/final folder selection $sys" }
        val scans = SessionDiagnosticSelector.navigationFolders(nav, begin, end)
        check(scans.toSet()==setOf(stock,third)) { "Nav folder session selection $scans" }
        check(SessionDiagnosticSelector.navigationStatus(stock)=="COMPLETE")
        check(SessionDiagnosticSelector.navigationStatus(third)=="IN_PROGRESS")
        File(third,"PARTIAL_FAILED_COMMANDS.txt").writeText("failed=1")
        check(SessionDiagnosticSelector.navigationStatus(third)=="PARTIAL_COMMAND_FAILURE")
        val log = File(nav,"observations.tsv")
        log.writeText("${begin-1000}\tBEFORE\\n${begin+2000}\tIN_SESSION\\n${end+1000}\tAFTER\\n".replace("\\n","\n"))
        val filtered=String(SessionDiagnosticSelector.filterTimedLines(log,begin,end))
        check("IN_SESSION" in filtered && "BEFORE" !in filtered && "AFTER" !in filtered) {filtered}
        check(!SessionDiagnosticSelector.inSession(null, begin,end))
        println("SESSION_SELECTOR_TEST_PASS: forced START/STOP; queued quick request; session isolation; nav COMPLETE/PARTIAL/IN_PROGRESS; filtered observations")
    } finally { root.deleteRecursively() }
}
