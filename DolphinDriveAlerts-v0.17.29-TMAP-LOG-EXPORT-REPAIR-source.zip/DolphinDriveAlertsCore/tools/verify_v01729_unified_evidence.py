#!/usr/bin/env python3
"""Session-scoped TMAP/AVAS evidence ZIP regression checks; Android compilation separate."""
from pathlib import Path
import subprocess, shutil, tempfile
root=Path(__file__).resolve().parents[1]
base=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda x:x.read_text(encoding='utf-8')
cap=read(base/'log/UnifiedLogCapture.kt')
sel=read(base/'log/SessionDiagnosticSelector.kt')
col=read(base/'log/SystemDiagnosticsCollector.kt')
nav=read(base/'audio/NavRouteCaptureService.kt')
ui=read(base/'ui/MainActivity.kt')
service=read(base/'service/DrivingAlertService.kt')
results={
    'entrypoint-preserved': 'ACTION_CAPTURE_END ->' in service and 'UnifiedLogCapture.finish(this, rawLogger, diagnostics)' in service,
    'capture-start-end-preserved': 'UNIFIED_CAPTURE_START' in cap and 'UNIFIED_CAPTURE_END' in cap,
    'download-atomic': 'IS_PENDING' in cap and 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in cap,
    'session-captured-jsonl': 'timestamp in state.startMs..state.endMs' in cap,
    'quick-oem-diag-included': 'diagnosticFolders' in cap and 'diagnostics/${folder.name}' in cap,
    'nav-route-lab-included': 'navigationFolders' in cap and 'nav_audio_lab/${folder.name}' in cap,
    'old-observation-filter': 'filterTimedLines' in cap and 'inSession(time, begin, end)' in sel,
    'force-start-stop': 'UNIFIED_START_$sessionId' in sel and 'UNIFIED_STOP_$sessionId' in sel,
    'request-time-metadata': 'put("requestedAtMs", requestedAtMs)' in col and 'requestedAtMs' in sel,
    'nav-metadata-before-worker': nav.index('File(dir, "metadata.json").writeText') < nav.index('worker.execute {'),
    'nav-completion-gate': 'awaitNavSessions' in cap and 'IN_PROGRESS' in cap and 'FAILED' in cap,
    'nav-status-differentiated': all(x in sel for x in ('COMPLETE','PARTIAL_COMMAND_FAILURE','FAILED','IN_PROGRESS')),
    'sha256-manifest-in-zip': 'evidence_manifest.json' in cap and 'MessageDigest.getInstance("SHA-256")' in cap,
    'zip-verify-crc': 'ZipInputStream' in cap and 'verifyCompleteZip(staged)' in cap,
    'zip-verify-file-hashes': 'item.getString("sha256")' in cap and 'item.getLong("bytes")' in cap,
    'nav-output-success-not-claimed': 'navAudioScanFullySuccessful' in cap,
    'no-shared-prefs-export': 'shared_prefs' not in cap,
    'no-oem-write-introduced': all(x not in cap+sel for x in ('setChannel(', 'setOperationMode(', 'setStreamVolume(', 'am stack resize', 'writeOnce(')),
    '9-menus-unchanged': 'section("통합 로그 수집")' in ui,
    'retains-existing-nav-service': 'snapshot_${idx+1}' in nav and 'dumpsys media.audio_policy' in nav,
}
for name,good in results.items(): print(('PASS ' if good else 'FAIL ')+name)
if not all(results.values()): raise SystemExit(1)
if shutil.which('kotlinc') and shutil.which('java'):
    with tempfile.TemporaryDirectory() as folder:
        jar=Path(folder)/'selector.jar'
        cmd=['kotlinc',str(base/'log/SessionDiagnosticSelector.kt'),str(root/'tools/tests/SessionDiagnosticSelectorTest.kt'),'-include-runtime','-d',str(jar)]
        r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if r.returncode: print(r.stdout); raise SystemExit(r.returncode)
        r=subprocess.run(['java','-jar',str(jar)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        print(r.stdout.strip());
        if r.returncode: raise SystemExit(r.returncode)
else: print('KOTLINC_NOT_ON_CI: Android Gradle compile provides compiler verification; local pure Kotlin test run separately')
print(f'DA010_UNIFIED_EVIDENCE_SOURCE_CHECKS={sum(results.values())}/{len(results)}')
