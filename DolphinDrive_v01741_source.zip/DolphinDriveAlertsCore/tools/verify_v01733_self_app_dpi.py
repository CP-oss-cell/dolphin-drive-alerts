#!/usr/bin/env python3
"""v0.17.33: app-local DPI works in Activity contexts; never mutates global DPI for setting target."""
from pathlib import Path
import re, shutil, subprocess, tempfile
p=Path(__file__).resolve().parents[1]
src=p/'app/src/main/java/com/byd/dolphin/drivealerts'
self_dpi=(src/'dpi/SelfAppDensity.kt').read_text()
controller=(src/'dpi/DisplaySettingsController.kt').read_text()
ui=(src/'ui/AppPolicyActivity.kt').read_text()
main=(src/'ui/MainActivity.kt').read_text()
gradle=(p/'app/build.gradle.kts').read_text()
checks={
 'self-context-local-override': 'context.createConfigurationContext(config)' in self_dpi and 'config.densityDpi = target' in self_dpi,
 'durable-setting': 'putInt(KEY, dpi).commit()' in self_dpi,
 'valid-app-range': 'value in 120..320' in self_dpi and 'value == STOCK' in self_dpi,
 'all-owned-activities': all('DensityAwareActivity()' in f.read_text() for f in [
  src/'ui'/n for n in ['MainActivity.kt','AppPolicyActivity.kt','AdbSetupActivity.kt',
  'AppPermissionManagerActivity.kt','AudioTuningActivity.kt','DriveModeCalibrationActivity.kt','NavAudioLabActivity.kt']
 ]),
 'rotation-unchanged': 'RotationPolicy.applyCurrent' in ui,
 'external-nav-unchanged': 'ExternalAppAudioRouter.NAVIGATION_APPS' in ui,
 'global-is-explicit-and-separate': 'wm density $requested' in controller and 'TemporaryAppDpiController.applyExplicitGlobal' in ui,
 'explicit-recovery': 'wm density reset' in controller and 'AlertDialog.Builder(this).setTitle("차량 전체 DPI 강제설정 해제")' in ui,
 'user-facing-scope-honest': '주행보조 앱 전용 DPI' in ui and '타사 앱 DPI는 일시적으로 전역 변경' in main,
 'ui-can-save': 'SelfAppDensity.save(this, selectedDpi)' in ui and 'recreate()' in ui,
 'preserved-pcm-onset-priority': 'navOnsetExecutor' in (src/'log/SystemDiagnosticsCollector.kt').read_text(),
 'versionCode-at-least-59': (lambda m: bool(m) and int(m.group(1)) >= 59)(re.search(r'versionCode\s*=\s*(\d+)', gradle)),
}
for name,value in checks.items():print(('PASS' if value else 'FAIL'),name)
assert all(checks.values()),'static gate failure'
# compile and run actual production Kotlin source with lightweight Android API stubs.
if shutil.which('kotlinc'):
 with tempfile.TemporaryDirectory(prefix='selfdpi-') as t:
  d=Path(t)
  (d/'Configuration.kt').write_text('''package android.content.res
open class Configuration() { var densityDpi: Int = 160; constructor(other:Configuration):this() { densityDpi=other.densityDpi } }
class Resources(val configuration:Configuration)
''')
  (d/'Context.kt').write_text('''package android.content
import android.content.res.Configuration
import android.content.res.Resources
open class Context {
  companion object { const val MODE_PRIVATE=0 }
  open val applicationContext: Context get()=this
  open val resources: Resources get()=Resources(Configuration())
  open fun getSharedPreferences(name:String,mode:Int):Prefs=PrefsHolder.p
  open fun createConfigurationContext(c: Configuration):Context=object:Context() { override val resources=Resources(c); override val applicationContext:Context get()=this@Context.applicationContext }
}
class Prefs(var stored:Int=0) {
 fun getInt(k:String, def:Int)=stored
 fun edit()=this
 fun putInt(k:String, v:Int):Prefs {stored=v;return this}
 fun commit()=true
}
object PrefsHolder { val p=Prefs() }
''')
  (d/'Activity.kt').write_text('''package android.app
import android.content.Context
open class Activity: Context(){
 protected open fun attachBaseContext(newBase:Context){}
 protected open fun onResume() {}
 val window=Window()
}
class Window { val decorView=Decor() }
class Decor { fun post(action:()->Unit) { action() } }
''')
  (d/'Theme.kt').write_text('''package com.byd.dolphin.drivealerts.ui
object DashboardTheme { fun decorate(a:android.app.Activity) {} }
''')
  (d/'Main.kt').write_text('''import android.content.Context
import com.byd.dolphin.drivealerts.dpi.SelfAppDensity
fun main(){
 val c=Context()
 check(SelfAppDensity.selected(c)==0)
 check(SelfAppDensity.wrap(c)===c)
 check(SelfAppDensity.save(c,140))
 check(SelfAppDensity.selected(c)==140)
 check(SelfAppDensity.wrap(c).resources.configuration.densityDpi==140)
 check(c.resources.configuration.densityDpi==160)
 check(!SelfAppDensity.save(c,80)); check(SelfAppDensity.selected(c)==140)
 check(SelfAppDensity.save(c,120))
 check(SelfAppDensity.wrap(c).resources.configuration.densityDpi==120)
 check(SelfAppDensity.save(c,0));check(SelfAppDensity.wrap(c)===c)
 println("PASS native Kotlin rules/context ownership/save-restore")
}
''')
  jar=d/'app.jar'
  r=subprocess.run(['kotlinc',str(src/'dpi/SelfAppDensity.kt'),*[str(x) for x in d.glob('*.kt')],'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=65)
  if r.returncode:raise RuntimeError('Kotlin compile: '+r.stderr[-2500:])
  k=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=10)
  if k.returncode:raise RuntimeError(k.stderr[-2000:])
  print(k.stdout.strip())
print('V01733_SELF_APP_DPI: PASS',len(checks),'static rules')
