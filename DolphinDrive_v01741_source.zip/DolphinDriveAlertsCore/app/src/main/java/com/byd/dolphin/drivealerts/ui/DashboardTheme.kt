package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Unified low-noise dashboard look for ALL detailed screens; preserves all existing listeners. */
object DashboardTheme {
    private val navy=Color.rgb(11,17,29)
    private val tile=Color.rgb(28,46,70)
    private val fg=Color.rgb(237,244,250)
    private val muted=Color.rgb(176,193,213)
    private val accent=Color.rgb(84,212,220)
    private fun round(color:Int, radius:Float):GradientDrawable = GradientDrawable().apply {
        setColor(color);cornerRadius=radius
    }
    private fun dp(activity:Activity,n:Int)=(n*activity.resources.displayMetrics.density).toInt()
    fun decorate(activity:Activity) {
        val decor=activity.window?.decorView as? ViewGroup ?: return
        activity.window.statusBarColor=navy
        activity.window.navigationBarColor=navy
        walk(activity,decor,0)
    }
    private fun walk(activity:Activity, view:View, depth:Int) {
        when(view) {
            is ScrollView -> { view.setBackgroundColor(navy);view.isFillViewport=true }
            is EditText -> {
                view.setTextColor(fg); view.setHintTextColor(muted)
                view.background=round(tile,dp(activity,10).toFloat());view.setPadding(dp(activity,12),dp(activity,8),dp(activity,12),dp(activity,8))
            }
            is Button -> {
                view.isAllCaps=false;view.setTextColor(fg)
                view.background=round(tile,dp(activity,12).toFloat())
                view.setPadding(dp(activity,14),dp(activity,10),dp(activity,14),dp(activity,10))
                view.minHeight=dp(activity,44)
            }
            is CheckBox -> { view.setTextColor(fg);view.buttonTintList=ColorStateList.valueOf(accent);view.setPadding(dp(activity,5),dp(activity,9),dp(activity,5),dp(activity,9)) }
            is RadioButton -> { view.setTextColor(fg);view.buttonTintList=ColorStateList.valueOf(accent) }
            is Spinner -> { view.setBackgroundColor(tile) }
            is TextView -> {
                view.setTextColor(if(view.textSize/activity.resources.displayMetrics.scaledDensity >= 18f) accent else muted)
                if(view.textSize/activity.resources.displayMetrics.scaledDensity >= 18f) view.setTypeface(view.typeface,Typeface.BOLD)
            }
            is LinearLayout -> { if(depth<=3) view.setBackgroundColor(navy) }
        }
        if (view is ViewGroup) for(i in 0 until view.childCount) walk(activity,view.getChildAt(i),depth+1)
    }
}
