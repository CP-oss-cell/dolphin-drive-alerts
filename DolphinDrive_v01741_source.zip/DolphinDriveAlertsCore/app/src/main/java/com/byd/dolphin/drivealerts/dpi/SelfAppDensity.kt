package com.byd.dolphin.drivealerts.dpi

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

/**
 * Per-app density for activities owned by Dolphin Drive Alerts.
 * No adb, no wm density, no system-wide settings, no modification to other packages.
 * For third-party apps, a separately authorized embedding display would be required.
 */
object SelfAppDensity {
    private const val PREFS = "self_app_density_v01733"
    private const val KEY = "density_dpi"
    const val STOCK = 0
    val PRESETS = listOf(0, 200, 180, 160, 140, 120)

    fun normalize(value: Int): Int = if (value == STOCK || value in 120..320) value else -1

    fun selected(context: Context): Int {
        val saved = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY, STOCK)
        return normalize(saved).takeIf { it >= 0 } ?: STOCK
    }

    fun save(context: Context, dpi: Int): Boolean {
        if (normalize(dpi) < 0) return false
        return context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY, dpi).commit()
    }

    fun wrap(context: Context): Context {
        val target = selected(context)
        if (target == STOCK) return context
        val existing = context.resources.configuration
        if (existing.densityDpi == target) return context
        val config = Configuration(existing)
        config.densityDpi = target
        // A Context-specific override; displayId 0 and OEM UI remain untouched.
        return context.createConfigurationContext(config)
    }
}

/** Base for all app UI activities; settings persist across navigation and reboot. */
open class DensityAwareActivity : Activity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(SelfAppDensity.wrap(newBase))
    }
    override fun onResume() {
        super.onResume()
        // Use one visual theme across detailed screens, without replacing their settings listeners.
        if (javaClass.simpleName != "MainActivity" && javaClass.simpleName != "SplitGhostActivity") {
            window.decorView.post { com.byd.dolphin.drivealerts.ui.DashboardTheme.decorate(this) }
        }
    }
}
