package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.ApplicationInfo

/** No true per-task density: temporarily changes whole display while user target app is foreground. */
object ThirdPartyDpiRules {
    private const val PREF = "third_party_dpi_v01739"
    private const val ENABLED = "auto_enabled"
    private const val PREFIX = "pkg_"
    private val safePkg = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    fun enabled(context: Context) = context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(ENABLED,false)
    fun setEnabled(context: Context, value: Boolean): Boolean = context.getSharedPreferences(PREF,Context.MODE_PRIVATE)
        .edit().putBoolean(ENABLED,value).commit()
    fun allowed(context: Context, pkg: String): Boolean {
        if (!safePkg.matches(pkg) || pkg == context.packageName || pkg.startsWith("com.byd.") || pkg.startsWith("android.")) return false
        val info = runCatching { context.packageManager.getApplicationInfo(pkg,0) }.getOrNull() ?: return false
        return info.flags and ApplicationInfo.FLAG_SYSTEM == 0
    }
    fun rule(context: Context, pkg: String): Int {
        if (!allowed(context,pkg)) return 0
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getInt(PREFIX+pkg,0).takeIf { it in 120..320 } ?: 0
    }
    fun save(context: Context,pkg: String, dpi: Int): Boolean {
        if (!allowed(context,pkg) || dpi != 0 && dpi !in 120..320) return false
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putInt(PREFIX+pkg,dpi).commit()
    }
    fun summary(context: Context): String = context.getSharedPreferences(PREF,Context.MODE_PRIVATE).all
        .filter { it.key.startsWith(PREFIX) && it.value is Int && (it.value as Int) in 120..320 }
        .map { "${it.key.removePrefix(PREFIX)}=${it.value}" }.sorted().joinToString(";")
}
