package com.byd.dolphin.drivealerts.ui

import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.*
import com.byd.dolphin.drivealerts.util.CoreLog

/** Per-app native UI density, explicit legacy system recovery, rotation and nav controls. */
class AppPolicyActivity : DensityAwareActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,20,28,28) }
        scroll.addView(box); setContentView(scroll)
        fun label(t: String, size: Float=15f) = TextView(this).apply { text=t; textSize=size; setPadding(0,7,0,9) }
        fun btn(t: String, fn: ()->Unit) = Button(this).apply { text=t; isAllCaps=false; setOnClickListener { fn() } }
        box.addView(label("디스플레이 · 회전 · 내비 운전석 출력",22f))
        box.addView(label("주행보조 앱 전용 DPI (차량 전체 DPI 변경 없음)",18f))
        box.addView(label("이 항목만 주행보조 앱 내부 화면에 독립 적용됩니다. 타사 앱 임시 규칙과 전역 DPI 설정은 아래 별도 항목입니다.",13f))
        val modes = listOf("순정(앱 기본)", "200", "180", "160", "140", "120", "수동")
        val values = listOf(0,200,180,160,140,120)
        val savedDpi = SelfAppDensity.selected(this)
        val dpi = Spinner(this).apply {
            adapter = ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,modes)
            setSelection(values.indexOf(savedDpi).takeIf { it>=0 } ?: 6)
        }
        box.addView(dpi)
        val manual = EditText(this).apply {
            hint="수동 DPI 120~320"; inputType=InputType.TYPE_CLASS_NUMBER
            if (savedDpi !in values) setText(savedDpi.toString())
        }
        box.addView(manual)
        val measuredDpi = resources.configuration.densityDpi
        val densityStatus = label(if (savedDpi == 0) {
            "주행보조 앱 DPI: 순정 (현재 UI=${measuredDpi})"
        } else if (savedDpi == measuredDpi) {
            "주행보조 앱 DPI: ${savedDpi} (UI 적용 확인)"
        } else {
            "주행보조 앱 DPI: 설정 ${savedDpi}, 현재 UI ${measuredDpi} (미적용 확인 필요)"
        },13f)
        box.addView(densityStatus)
        box.addView(btn("주행보조 앱 DPI 적용") {
            val selectedDpi = if (dpi.selectedItemPosition == 6) manual.text.toString().toIntOrNull()
                else values[dpi.selectedItemPosition]
            if (selectedDpi == null || !SelfAppDensity.save(this, selectedDpi)) {
                densityStatus.text = "저장 실패: DPI 120~320 또는 순정만 사용할 수 있습니다"
            } else {
                // Recreate with a configuration-specific activity context, not wm density.
                recreate()
            }
        })
        box.addView(label("타사 앱 선택 DPI · 앱 실행 동안만 임시 전역 적용",18f))
        box.addView(label("Android 10의 wm density는 타사 앱 하나에만 적용되지 않습니다. 지정 앱으로 전환하면 화면 전체 DPI를 잠시 변경하고 나올 때 직전 값으로 복구합니다. 순정 런처·360도 그동안 잘릴 수 있습니다. 사용 전 접근성 권한과 ADB 승인이 필요합니다. 기본 OFF.",13f))
        val thirdApps = packageManager.getInstalledApplications(0)
            .filter { ThirdPartyDpiRules.allowed(this,it.packageName) }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        val thirdList=thirdApps.map { "${packageManager.getApplicationLabel(it)} (${it.packageName})" }
        if (thirdApps.isNotEmpty()) {
            val appChooser=Spinner(this).apply { adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,thirdList) }
            box.addView(appChooser)
            val targetValues=listOf(0,200,180,160,140,120)
            val targetChooser=Spinner(this).apply { adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,listOf("순정(규칙 해제)","200","180","160","140","120")) }
            box.addView(targetChooser)
            val tempStatus=label("선택한 앱의 임시 DPI 규칙을 저장하세요. 다른 앱의 독립 DPI가 아닙니다.",13f)
            box.addView(tempStatus)
            fun selectedPackage(): String = thirdApps[appChooser.selectedItemPosition.coerceIn(0,thirdApps.lastIndex)].packageName
            appChooser.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position:Int, id:Long) {
                    val saved=ThirdPartyDpiRules.rule(this@AppPolicyActivity,selectedPackage())
                    targetChooser.setSelection(targetValues.indexOf(saved).coerceAtLeast(0))
                    tempStatus.text="${selectedPackage()} · 저장된 DPI: ${if(saved==0) "순정" else saved}"
                }
            }
            box.addView(btn("선택 앱 DPI 규칙 저장") {
                val pkg=selectedPackage();val dpi=targetValues[targetChooser.selectedItemPosition.coerceAtLeast(0)]
                tempStatus.text=if(ThirdPartyDpiRules.save(this,pkg,dpi)) "규칙 저장: $pkg → ${if(dpi==0) "순정" else dpi}; 자동 적용은 아래 스위치 ON 필요" else "앱별 DPI 규칙 저장 실패"
            })
            box.addView(CheckBox(this).apply {
                text="지정 앱 전환 시 임시 DPI 자동 변경 (전체 화면에 영향)"
                isChecked=ThirdPartyDpiRules.enabled(this@AppPolicyActivity)
                setOnCheckedChangeListener { button,on ->
                    if(on) AlertDialog.Builder(this@AppPolicyActivity)
                        .setTitle("전체 화면 임시 DPI 변경 주의")
                        .setMessage("타사 앱을 보는 동안 순정 화면, 공조, 카메라까지 같이 바뀔 수 있습니다. 복원 실패 시 아래 '순정 복구' 버튼을 이용하세요. 정차 중에만 설정하세요.")
                        .setPositiveButton("동의하고 사용") { _,_ -> ThirdPartyDpiRules.setEnabled(this@AppPolicyActivity,true) }
                        .setNegativeButton("취소") { _,_ -> button.isChecked=false }.show()
                    else { ThirdPartyDpiRules.setEnabled(this@AppPolicyActivity,false);TemporaryAppDpiController.disableAndRestore(this@AppPolicyActivity) }
                }
            })
            box.addView(btn("임시 DPI 종료 및 직전 화면 복원") {
                ThirdPartyDpiRules.setEnabled(this,false)
                TemporaryAppDpiController.disableAndRestore(this)
                tempStatus.text="임시 변경 해제 요청. 아래 차량 현재 DPI 확인으로 복원을 확인하세요."
            })
        } else box.addView(label("타사 앱 목록 조회 불가. 앱 설치/패키지 조회 권한을 확인하세요.",13f))
        box.addView(label("차량 전체 DPI 직접 변경 (고급·순정 화면 잘림 주의)",18f))
        val globalPresets=listOf(160,180,200,140,120)
        val globalSpinner=Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,globalPresets.map { "$it DPI" })
        }
        box.addView(globalSpinner)
        val globalManual=EditText(this).apply { hint="전체 DPI 수동 입력 120~320 (비우면 위 선택값)";inputType=InputType.TYPE_CLASS_NUMBER }
        box.addView(globalManual)
        box.addView(btn("선택 DPI 차량 전체 적용") {
            val selected=globalManual.text.toString().trim().takeIf { it.isNotEmpty() }?.toIntOrNull()
                ?: globalPresets[globalSpinner.selectedItemPosition.coerceIn(0,globalPresets.lastIndex)]
            if (selected !in 120..320) { Toast.makeText(this,"DPI는 120~320만 허용",Toast.LENGTH_SHORT).show();return@btn }
            AlertDialog.Builder(this).setTitle("차량 전체 DPI $selected 적용")
                .setMessage("순정 런처/공조/360 카메라 화면이 잘릴 수 있습니다. 정차한 경우에만 사용하고, 문제가 있으면 '순정 복구'를 누르세요. 정말 적용합니까?")
                .setPositiveButton("적용") { _, _ ->
                    ThirdPartyDpiRules.setEnabled(this,false)
                    TemporaryAppDpiController.applyExplicitGlobal(this,selected) { result ->
                        runOnUiThread { Toast.makeText(this@AppPolicyActivity,result.message,Toast.LENGTH_LONG).show() }
                    }
                }.setNegativeButton("취소",null).show()
        })
        box.addView(label("기존 전역 DPI 설정 복구 (선택사항)",18f))
        box.addView(label("과거 버전에서 화면 전체 DPI가 바뀐 경우에만 사용하세요. '순정 복구'는 wm density의 강제 override만 해제하며, 순정 제조사 UI 배치를 보장하지 않습니다.",13f))
        val globalStatus = label("차량 시스템 DPI: 조회 전",13f)
        box.addView(globalStatus)
        box.addView(btn("차량 현재 DPI 확인 (읽기 전용)") {
            Thread {
                val state = DisplaySettingsController.readDensity(applicationContext)
                val size = DisplaySettingsController.readSize(applicationContext)
                runOnUiThread { globalStatus.text = "차량 전체: ${state ?: "ADB 조회 불가"}, 화면: $size" }
            }.start()
        })
        box.addView(btn("기존 전역 DPI 강제설정 해제 · 순정 복구") {
            AlertDialog.Builder(this).setTitle("차량 전체 DPI 강제설정 해제")
                .setMessage("이전 앱이 지정한 시스템 전체 DPI override만 지웁니다. 실제 차량 전체 화면 크기가 바뀔 수 있습니다. 정차한 경우에만 사용하세요. 복구하겠습니까?")
                .setPositiveButton("복구") { _, _ ->
                    Thread {
                        ThirdPartyDpiRules.setEnabled(applicationContext,false)
                        TemporaryAppDpiController.applyExplicitGlobal(applicationContext,null) { res ->
                            runOnUiThread { globalStatus.text = res.message
                                Toast.makeText(this@AppPolicyActivity, if(res.ok) "시스템 DPI 강제설정 해제 완료" else "강제설정 해제 실패",Toast.LENGTH_LONG).show()
                            }
                        }
                    }.start()
                }.setNegativeButton("취소",null).show()
        })
        box.addView(label("디스플레이 프로필/해상도",18f))
        box.addView(label("wm size 1920x1080은 논리적 화면 크기 변경일 뿐 실제 패널 12인치/1920x1080 하드웨어로 속이지 않습니다. BYD 차량 설정의 12인치 프로필과 동일한 효과는 미확인입니다. 안전상 프로필 위장은 자동 실행하지 않습니다.",13f))
        box.addView(btn("패널 / 논리 해상도 정보 조회 (읽기 전용)") {
            Thread {
                val info = DisplaySettingsController.readDisplayHardware(applicationContext)
                runOnUiThread { AlertDialog.Builder(this@AppPolicyActivity)
                    .setTitle("물리 패널 및 논리 해상도")
                    .setMessage(info).setPositiveButton("닫기",null).show() }
            }.start()
        })
        box.addView(label("화면 회전 · Orientation Control 방식 (앱 선택 없음)",18f))
        val toggle = CheckBox(this).apply { text="전역 회전 사용"; isChecked=RotationPolicy.enabled(this@AppPolicyActivity) }
        box.addView(toggle)
        val all = listOf(OrientationMode.STOCK,OrientationMode.LANDSCAPE,OrientationMode.REVERSE_LANDSCAPE,OrientationMode.PORTRAIT,OrientationMode.REVERSE_PORTRAIT,OrientationMode.SENSOR_LANDSCAPE,OrientationMode.SENSOR_PORTRAIT,OrientationMode.USER_LANDSCAPE,OrientationMode.USER_PORTRAIT,OrientationMode.FULL_USER,OrientationMode.LOCKED,OrientationMode.FULL_SENSOR)
        val rotation = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity,android.R.layout.simple_spinner_dropdown_item,listOf("순정","가로 고정","가로 반전","세로 고정","세로 반전","센서 가로","센서 세로","사용자 가로","사용자 세로","전체 사용자 회전","현재 방향 잠금","센서 전체"))
            setSelection(all.indexOf(RotationPolicy.selected(this@AppPolicyActivity)).coerceAtLeast(0))
        }
        box.addView(rotation)
        val rotStatus=label("0×0 오버레이 이용. 차량의 오버레이 권한 필요. 시스템/앱별 패키지 권한 불필요.",13f)
        box.addView(rotStatus)
        box.addView(btn("회전 적용") {
            RotationPolicy.setSelected(this, all[rotation.selectedItemPosition]); RotationPolicy.setEnabled(this,toggle.isChecked)
            val ok=RotationPolicy.applyCurrent(this)
            rotStatus.text=if(ok) "회전 요청 적용: ${RotationPolicy.selected(this)} (실제 차량 화면 확인 필요)" else "회전 요청 실패: 화면 위 표시 권한 및 순정 화면 정책 확인"
        })
        box.addView(btn("화면 위 표시 권한 열기") { SafeSettingsLauncher.open(this,Settings.ACTION_MANAGE_OVERLAY_PERMISSION,true) })
        box.addView(label("내비게이션 운전석 스피커 · 대상 5종 고정",18f))
        box.addView(label("현재 BYD 타 앱 UID→운전석 물리 라우팅은 아직 미구현입니다. 아래 선택은 향후 전용 라우팅 대상 저장용이며, 선택만으로 운전석에서 출력되지 않습니다.",13f))
        for (entry in ExternalAppAudioRouter.NAVIGATION_APPS) {
            val current=ExternalAppAudioRouter.enabled(this,entry.pkg)
            val cb=CheckBox(this).apply { text="${entry.title} (${entry.pkg})"; isChecked=current
                setOnCheckedChangeListener { _,checked -> ExternalAppAudioRouter.setEnabled(this@AppPolicyActivity,entry.pkg,checked)
                    ExternalAppAudioRouter.diagnose(this@AppPolicyActivity,entry.pkg) }
            }
            box.addView(cb)
        }
    }
}
