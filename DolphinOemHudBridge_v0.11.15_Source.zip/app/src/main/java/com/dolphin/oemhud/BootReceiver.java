package com.dolphin.oemhud;

import android.content.*;
import android.os.Build;
public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        SharedPreferences p=c.getSharedPreferences(BridgeLog.STORE,0);
        if(!p.getBoolean("enabled_initialized",false)){
            p.edit().putBoolean("enabled_initialized",true).putBoolean("enabled",true)
                .putString("nav_package",OemTmapStateSignal.PACKAGE).apply();
        }
        if(!p.getBoolean("enabled",false))return;
        Intent s=new Intent(c,BridgeService.class);
        try{
            if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);
        }catch(RuntimeException e){
            BridgeLog.event(c,"자동 실행 실패: "+e.getClass().getSimpleName());
        }
    }
}
