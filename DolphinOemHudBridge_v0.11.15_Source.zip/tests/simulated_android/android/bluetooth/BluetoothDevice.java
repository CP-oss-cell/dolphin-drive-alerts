package android.bluetooth;public class BluetoothDevice{public String getName(){return "";}public String getAddress(){return "";}}
