package com.dolphin.oemhud;public class NavAccessibilityService{public static boolean isReceiverAttached(){return false;}}
