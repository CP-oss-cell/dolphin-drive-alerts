# BYD 돌핀 순정 런처 자동 연구 v0.5.0 (BETA)

## 목표
BYD Dolphin 글로벌 2602, Android 10 / API29, 1280×720, 순정 HOME `com.android.launcher3` 유지.
별도 순정 런처를 덮어씌우거나 차량 명령을 보내지 않는 **진단 도구**. 삼성 Good Lock 방식 순정 런처 커스터마이징의 가능성을 검증하기 위한 자료 수집용이며, 순정 독바 자체를 수정하는 기능은 아직 없음.

## 이전 v0.4 실차 결과를 반영한 변경
1. 자동 검사에서 `NameNotFoundException`을 실제 실행 오류로 오해하지 않도록, `PACKAGE_NOT_INSTALLED_OR_NOT_VISIBLE`로 분류. 요약에는 **오류 / 미설치·조회불가 / 미확인 / 접근 차단**을 별도로 출력.
2. 우리 앱의 진단 바로가기 추가를 사용자가 승인하면, 이후 앱으로 복귀할 때 **ShortcutManager의 pinned 목록**을 자동으로 다시 검사하고 타임스탬프/원본 상태를 기록. 자동 pinned 확인은 순정 홈 화면에 실제 아이콘이 보이는 증명이 아니며, 별도로 사용자가 육안 확인.
3. 독바 질문 1개로 묶던 것을 **앱 추가·아이콘 이동·편집 메뉴·가로 스크롤** 4개로 분리. 수동 검사 화면은 계속 3개. 독바는 한 화면에서 4개의 3지선다(모름/보임/없음)를 기록하므로 수동 조작 부담 최소화.
4. Downloads ZIP에 `shortcut-followup.json`, `dock-features.json` 추가. JSON, 요약, SHA256 원본과 함께 공유.
5. 기존 v0.4 개발을 유지하면서 동일 앱 식별자 `com.dolphin.goodlock.probe.v04`, `versionCode=5`로 업그레이드 경로 제공. v0.4 데이터 키도 보존. **동일한 서명키인 경우에만 덮어쓰기 업데이트 가능**.

## 차량에서 해야 할 일 — 안전하게 P 정차 후 진행
① 앱 설치 후 **로그 수집 시작**
② **자동 검색 · 테스트 · 결과** (모든 조회 가능 항목은 한 번에 자동 실행)
③ 앱 안의 **수동 확인 3개만 보기**: 순정 HOME 바로가기, 홈 위젯 메뉴, 독바 기능별 4가지. 확인하기 어려우면 '모름' 선택. 차량 설정, 아이콘 배치, 순정 파일은 바꾸지 않아도 됨.
④ **수집 종료 · 다운로드 ZIP · 공유** 를 누르면 `Download/DolphinOEMResearch_*.zip`으로 저장하고 Android 공유 화면이 열림.

## 중요한 설치·서명 주의
- 먼저 v0.4 앱이 있으면 **v0.4 수집 ZIP부터 저장**하고 설치 진행.
- GitHub Actions가 자동으로 생성한 debug APK는 실행마다 서명키가 달라질 수 있음. **앱 ID와 버전코드가 같거나 높더라도 서명이 다르면 설치 업데이트는 실패함.**
- 업데이트 불가 메시지가 뜨면 기존 v0.4의 ZIP 저장을 확인하고 구 앱을 제거한 뒤 v0.5 설치. 제거하면 앱 내부 미내보낸 기록은 삭제됨.
- 향후 반복 업데이트를 위해서는 **일관된 서명키를 안전하게 보관해 서명하는 릴리스 절차**가 별도로 필요함. 기존 debug signing key가 알려지지 않은 상태에서 업데이트 성공을 약속하지 않음.

## GitHub Actions 빌드
- 이 BUILD-PACK ZIP을 풀고 **동봉된 `DolphinOEMResearch-v0.5.0-source.zip`** 및 **`.github/workflows/build-dolphin-oemresearch-v05.yml`** 을 저장소 루트와 워크플로 경로에 올림.
- Actions → `Dolphin OEM Launcher Research v0.5` → Run workflow.
- 성공하면 Artifacts `DolphinOEMResearch-v0.5.0-APK` 다운로드 후 그 안의 `DolphinOEMResearch-v0.5.0-debug.apk`를 설치.
- 실제 APK 컴파일 및 차량 동작 확인은 GitHub Actions/실차에서 별도로 검증. 로컬에서 수행한 검사는 42/42 정적 게이트와 Java parser만 PASS.

## 결과판정 원칙
- `READ_HOME` 권한 허용 ≠ `HomeProvider` API 호출 성공 ≠ 순정 HOME 수정 권한.
- `CardProvider` READ/WRITE는 차량의 OEM signature/privileged 보호. 일반 APK에서 임의 우회 시도하지 않음.
- 기존 오프라인 `HomeProvider.query()` 정적 NULL 복귀 / `call(get_home_info)` 분기 후보만 관찰. 이 v0.5에서는 해당 IPC 호출 **하지 않음**.
- RRO/차량 SOC·TPMS/독바 쓰기/순정 상태바 제어는 `NOT_VERIFIED`. 가짜 기능 표시 금지.
- Android HOME 교체, 루팅, ADB, 사용자 권한 상승, OEM IPC/Provider query, 차량 CAN/ECU write, 네트워크 업로드 없음.

## ZIP 확인
`python3 tools/verify_export_zip.py <Download ZIP 경로>`
