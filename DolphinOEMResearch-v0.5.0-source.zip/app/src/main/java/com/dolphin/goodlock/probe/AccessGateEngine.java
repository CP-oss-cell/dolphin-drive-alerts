package com.dolphin.goodlock.probe;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/** Permission and declaration checks only; no ContentResolver.query(), OEM IPC or shell. */
public final class AccessGateEngine {
    private final Context app;
    private final PackageManager pm;
    private static final String LAUNCHER="com.android.launcher3";
    public AccessGateEngine(Context context){ app=context; pm=context.getPackageManager(); }
    private static void put(JSONObject o,String key,Object value) {try{o.put(key,value);}catch(Exception ignored){}}
    private static JSONObject node(String type,String target){
        JSONObject o=new JSONObject();put(o,"type",type);put(o,"target",target);
        put(o,"status","UNKNOWN");return o;
    }
    private JSONObject permissionDetail(String perm){
        JSONObject o=node("DECLARED_PERMISSION",perm);
        if(perm==null||perm.isEmpty()){
            put(o,"status","NO_PERMISSION_DECLARED");return o;
        }
        try {
            int mine=pm.checkPermission(perm,app.getPackageName());
            put(o,"our_app_granted",mine==PackageManager.PERMISSION_GRANTED);
            put(o,"our_app_package",app.getPackageName());
            put(o,"oem_launcher_granted",pm.checkPermission(perm,LAUNCHER)==PackageManager.PERMISSION_GRANTED);
            try {
                PermissionInfo info=pm.getPermissionInfo(perm,0);
                int base=info.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE;
                String p=base==PermissionInfo.PROTECTION_NORMAL?"normal":base==PermissionInfo.PROTECTION_DANGEROUS?"dangerous":base==PermissionInfo.PROTECTION_SIGNATURE?"signature":"other_"+base;
                put(o,"protection_base",p);
                put(o,"protection_level_raw",info.protectionLevel);
                put(o,"declaring_package",info.packageName);
            } catch(PackageManager.NameNotFoundException e){ put(o,"declaration_status","UNKNOWN_PERMISSION_INFO_NOT_VISIBLE"); }
            put(o,"status",mine==PackageManager.PERMISSION_GRANTED?"OUR_APP_PERMISSION_GRANTED_NO_IPC_TEST":"OUR_APP_PERMISSION_DENIED_NO_IPC_TEST");
        } catch(Exception e){put(o,"status","UNKNOWN_ERROR");put(o,"error",e.getClass().getSimpleName());}
        return o;
    }
    private JSONObject provider(String className){
        JSONObject out=node("PROVIDER",className);
        try {
            PackageInfo pkg=pm.getPackageInfo(LAUNCHER,PackageManager.GET_PROVIDERS);
            ProviderInfo target=null;
            if(pkg.providers!=null)for(ProviderInfo pr:pkg.providers)if(className.equals(pr.name)){target=pr;break;}
            if(target==null){put(out,"status","UNKNOWN_NOT_VISIBLE");return out;}
            put(out,"authority",target.authority);put(out,"exported",target.exported);
            put(out,"read_permission",target.readPermission);put(out,"write_permission",target.writePermission);
            put(out,"grant_uri_permissions",target.grantUriPermissions);
            put(out,"read_gate",permissionDetail(target.readPermission));
            put(out,"write_gate_metadata_only",permissionDetail(target.writePermission));
            // NEVER query the OEM provider, even if permission is reported granted.
            JSONObject read=out.optJSONObject("read_gate");
            boolean granted=read!=null && read.optBoolean("our_app_granted",false);
            put(out,"status",!target.exported?"BLOCKED_NOT_EXPORTED":
                    target.readPermission!=null&&!granted?"BLOCKED_READ_PERMISSION_NOT_GRANTED":
                    "READ_GATE_UNBLOCKED_BUT_PROVIDER_NOT_QUERIED");
            put(out,"meaning","Manifest/PackageManager gate only. Actual IPC/schema/launcher edit are NOT verified.");
        } catch(Exception e){put(out,"status","UNKNOWN_ERROR");put(out,"error",e.getClass().getSimpleName());}
        return out;
    }
    private JSONObject service(){
        String name="com.android.launcher3.cardwindow.CardWindowService";
        JSONObject out=node("SERVICE",name);
        try {
            PackageInfo pkg=pm.getPackageInfo(LAUNCHER,PackageManager.GET_SERVICES);
            ServiceInfo target=null;
            if(pkg.services!=null)for(ServiceInfo si:pkg.services)if(name.equals(si.name)){target=si;break;}
            if(target==null){put(out,"status","UNKNOWN_NOT_VISIBLE");return out;}
            put(out,"exported",target.exported);put(out,"service_permission",target.permission);
            put(out,"permission_gate",permissionDetail(target.permission));
            put(out,"status",target.exported?"DECLARED_EXPORTED_SERVICE_NOT_INVOKED":"BLOCKED_SERVICE_NOT_EXPORTED");
            put(out,"meaning","Exported != supported public API. No bind/start/send attempted.");
        }catch(Exception e){put(out,"status","UNKNOWN_ERROR");put(out,"error",e.getClass().getSimpleName());}
        return out;
    }
    private JSONObject shortcut(){
        JSONObject out=node("OWN_SHORTCUT","goodlock_probe_diagnostic");
        try {
            ShortcutManager sm=(ShortcutManager)app.getSystemService(Context.SHORTCUT_SERVICE);
            if(sm==null){put(out,"status","UNKNOWN_NO_SHORTCUT_SERVICE");return out;}
            put(out,"request_pin_supported",sm.isRequestPinShortcutSupported());
            boolean pinned=false; int total=0;
            List<ShortcutInfo> list=sm.getPinnedShortcuts();
            if(list!=null)for(ShortcutInfo info:list){total++;if("goodlock_probe_diagnostic".equals(info.getId())&&info.isPinned())pinned=true;}
            put(out,"pinned_shortcut_count_for_our_app",total);
            put(out,"target_id_reported_pinned",pinned);
            put(out,"status",pinned?"OWN_SHORTCUT_PINNED_METADATA_ONLY":"OWN_SHORTCUT_NOT_PINNED_OR_NOT_VISIBLE");
            put(out,"meaning","Pinned metadata does not prove icon is visibly placed in OEM home/CardBar.");
        }catch(Exception e){put(out,"status","UNKNOWN_ERROR");put(out,"error",e.getClass().getSimpleName());}
        return out;
    }
    private JSONObject widget(){
        JSONObject out=node("OWN_WIDGET",DiagnosticWidget.class.getName());
        try {
            AppWidgetManager wm=AppWidgetManager.getInstance(app);
            boolean supports=wm.isRequestPinAppWidgetSupported();
            int[] ids=wm.getAppWidgetIds(new ComponentName(app,DiagnosticWidget.class));
            put(out,"pin_api_supported",supports);put(out,"our_provider_bound_ids_count",ids==null?-1:ids.length);
            put(out,"status",!supports?"PIN_WIDGET_API_UNSUPPORTED_MANUAL_PATH_UNKNOWN":"PIN_WIDGET_API_SUPPORTED_NOT_PLACEMENT_PROOF");
            put(out,"meaning","Manual launcher widget-picker support not inferred.");
        }catch(Exception e){put(out,"status","UNKNOWN_ERROR");put(out,"error",e.getClass().getSimpleName());}
        return out;
    }
    public JSONObject runPlan(JSONArray steps){
        JSONObject o=new JSONObject();put(o,"schema","DolphinGoodLockGate/0.4");
        put(o,"safety","NO_ADB_NO_ROOT_NO_OEM_IPC_NO_PROVIDER_QUERY_NO_OEM_WRITE_NO_VEHICLE_SIGNAL");
        JSONArray ordered=new JSONArray();
        for(int i=0;i<steps.length();i++){
            String key=steps.optString(i,"");
            JSONObject part;
            switch(key){
                case "home_provider": part=provider("com.android.launcher3.data.HomeProvider"); break;
                case "card_provider": part=provider("com.android.launcher3.cardwindow.data.provider.CardProvider"); break;
                case "card_window_service": part=service(); break;
                case "own_shortcut": part=shortcut(); break;
                case "own_widget": part=widget(); break;
                default: throw new IllegalArgumentException("Unsupported plan step: "+key);
            }
            put(o,key,part);ordered.put(key);
        }
        put(o,"steps_executed_in_order",ordered);
        put(o,"oem_launcher_signature_matches_our_app",pm.checkSignatures(app.getPackageName(),LAUNCHER)==PackageManager.SIGNATURE_MATCH);
        put(o,"next_decision","Provider blocked => offline OEM permission/provider contract audit. Unblocked => explicit consent and schema verification, NOT an automatic query.");
        return o;
    }
    public JSONObject run(){
        JSONArray plan=new JSONArray();
        for(String key:new String[]{"home_provider","card_provider","card_window_service","own_shortcut","own_widget"})plan.put(key);
        return runPlan(plan);
    }
}
