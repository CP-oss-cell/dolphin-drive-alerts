package com.dolphin.goodlock.probe;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ShortcutManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.Display;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

/** Only normal public Android API queries. No BYD SDK invocation, broadcasts, shell or permission changes. */
public final class ProbeEngine {
    private final Context app;
    private final PackageManager pm;
    private JSONObject root;

    public ProbeEngine(Context app) {
        this.app = app;
        this.pm = app.getPackageManager();
    }

    private static void put(JSONObject o, String key, Object value) {
        try { o.put(key, value); } catch (Exception ignored) { }
    }
    private static void fail(JSONObject o, Exception e) {
        put(o, "status", "UNKNOWN_ERROR");
        put(o, "error_type", e.getClass().getSimpleName());
        put(o, "message", e.getMessage() == null ? "" : e.getMessage());
    }
    private static String component(ComponentName c) {
        return c == null ? "NULL" : c.flattenToShortString();
    }
    private static JSONObject section(String state, String note) {
        JSONObject o = new JSONObject();
        put(o, "status", state);
        put(o, "note", note);
        return o;
    }
    public JSONObject runAll() {
        JSONObject out = section("COMPLETE_WITH_UNKNOWN_ALLOWED", "조회 API 응답만 기록, 장치 실제 지원/수정 가능 확인 아님");
        put(out, "schema", "DolphinGoodLockProbe/0.1");
        put(out, "captured_local", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.KOREA).format(new Date()));
        put(out, "safety", "READ_ONLY_NO_VEHICLE_IO_NO_ADB_NO_ROOT_NO_OVERLAY_NO_INTERNET");
        put(out, "display", inspectDisplay());
        put(out, "home", inspectHome());
        put(out, "widgets", inspectWidgets());
        put(out, "shortcuts", inspectShortcuts());
        put(out, "settings_intents", inspectSettings());
        put(out, "packages", inspectPackages());
        put(out, "signature", inspectSignature());
        put(out, "privilege", inspectPrivilege());
        put(out, "rro", section("NOT_PROBED", "타겟 overlayable 정책은 OEM APK 또는 승인된 shell에서 별도 정적/런타임 검사 필요"));
        put(out, "cardbar_runtime", section("NOT_PROBED", "순정 홈 하단 독바와 CardBar의 런타임 동일성은 본 일반 앱만으로 검증할 수 없음"));
        put(out, "vehicle_data", section("NOT_PROBED", "고전압 구동 배터리/TPMS/전비 SDK 읽기는 검증된 권한·API 확보 전 차단. Android 기기 배터리와 차량 SOC 혼동 방지"));
        root = out;
        return out;
    }
    public JSONObject current() { return root == null ? runAll() : root; }

    private JSONObject inspectDisplay() {
        JSONObject o = section("API_QUERY", "현재 화면 정보. Launcher3 리소스 qualifier 및 실제 CardBar 폭 확정은 아님");
        try {
            DisplayMetrics real = new DisplayMetrics();
            WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            Display disp = wm.getDefaultDisplay();
            disp.getRealMetrics(real);
            put(o, "real_width_px", real.widthPixels);
            put(o, "real_height_px", real.heightPixels);
            put(o, "density_dpi", real.densityDpi);
            put(o, "density", real.density);
            put(o, "display_id", disp.getDisplayId());
            put(o, "rotation", disp.getRotation());
            put(o, "sdk", Build.VERSION.SDK_INT);
            put(o, "android_release", Build.VERSION.RELEASE);
            put(o, "manufacturer", Build.MANUFACTURER);
            put(o, "model", Build.MODEL);
            put(o, "build_fingerprint", Build.FINGERPRINT);
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectHome() {
        JSONObject o = section("API_QUERY", "현재 기본 HOME 인텐트 결과, OEM CardBar 제어권 의미 아님");
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo info = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            put(o, "resolved", info == null || info.activityInfo == null ? "NULL" : info.activityInfo.packageName + "/" + info.activityInfo.name);
            put(o, "home_category_self_registered", false);
            put(o, "test_app_replaces_home", false);
            if (info == null || info.activityInfo == null) put(o, "status", "UNKNOWN_NO_RESOLVER");
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectWidgets() {
        JSONObject o = section("API_QUERY", "요청 가능 여부는 위젯 실제 배치 성공이 아님; 앱 서랍에서 수동 추가도 별도 시험");
        try {
            AppWidgetManager awm = AppWidgetManager.getInstance(app);
            put(o, "pin_widget_supported", awm.isRequestPinAppWidgetSupported());
            put(o, "diagnostic_provider", component(new ComponentName(app, DiagnosticWidget.class)));
            put(o, "provider_declared", true);
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectShortcuts() {
        JSONObject o = section("API_QUERY", "Pin Shortcut 지원 여부만 확인, 직접 홈에 설치하지 않음");
        try {
            ShortcutManager manager = (ShortcutManager) app.getSystemService(Context.SHORTCUT_SERVICE);
            put(o, "pin_shortcut_supported", manager != null && manager.isRequestPinShortcutSupported());
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectSettings() {
        JSONObject o = section("API_QUERY", "설정 Intent를 처리할 수 있는 Activity만 조회; 상태바 토글 실제 작동 여부와 무관");
        String[] actions = {Settings.ACTION_SETTINGS, Settings.ACTION_WIFI_SETTINGS,
                Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_APPLICATION_SETTINGS,
                Settings.ACTION_SOUND_SETTINGS};
        try {
            for (String action: actions) {
                Intent i = new Intent(action);
                ResolveInfo v = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
                put(o, action, v == null || v.activityInfo == null ? "NO_PUBLIC_HANDLER" :
                        v.activityInfo.packageName + "/" + v.activityInfo.name);
            }
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectPackages() {
        JSONObject o = section("API_QUERY", "설치여부/내보낸 구성요소 존재와 접근권한이 실제로 허용된 것은 별개");
        String[] names = {"com.android.launcher3", "com.android.systemui",
                "com.byd.mycar", "com.byd.widget.mediacenter", "com.byd.automap.provider",
                "com.dolphin.launcher.v1", "com.byd.dolphin.drivealerts"};
        for (String name : names) {
            JSONObject item = new JSONObject();
            try {
                PackageInfo pkg = pm.getPackageInfo(name, PackageManager.GET_ACTIVITIES |
                        PackageManager.GET_SERVICES | PackageManager.GET_PROVIDERS);
                put(item, "installed", true);
                put(item, "version", pkg.versionName == null ? "UNKNOWN" : pkg.versionName);
                put(item, "is_system_app", pkg.applicationInfo != null &&
                        (pkg.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                JSONArray exported = new JSONArray();
                int total = 0;
                if (pkg.activities != null) for (ActivityInfo a: pkg.activities) {
                    if (a.exported) { total++; if (exported.length() < 30) exported.put("Activity " + a.name + " permission=" + a.permission); }
                }
                if (pkg.services != null) for (ServiceInfo s: pkg.services) {
                    if (s.exported) { total++; if (exported.length() < 30) exported.put("Service " + s.name + " permission=" + s.permission); }
                }
                if (pkg.providers != null) for (ProviderInfo p: pkg.providers) {
                    if (p.exported) { total++; if (exported.length() < 30) exported.put("Provider " + p.name + " read=" + p.readPermission + " write=" + p.writePermission); }
                }
                put(item, "exported_total", total);
                put(item, "exported_sample_max30", exported);
                put(item, "capability_unverified", "exported API alone does not grant permission or support calling it");
            } catch (PackageManager.NameNotFoundException e) {
                put(item, "installed", false);
                put(item, "note", "not visible / not installed / different OEM package ID");
            } catch (Exception e) { fail(item,e); }
            put(o,name,item);
        }
        return o;
    }
    private JSONObject inspectSignature() {
        JSONObject o = section("API_QUERY", "서명 일치 여부는 업데이트/보호 권한의 유일한 조건이 아님");
        try {
            int value = pm.checkSignatures(app.getPackageName(),"com.android.launcher3");
            put(o,"signature_compare_result", value);
            put(o,"matches_oem_launcher", value == PackageManager.SIGNATURE_MATCH);
        } catch (Exception e) { fail(o,e); }
        return o;
    }
    private JSONObject inspectPrivilege() {
        JSONObject o = section("API_QUERY", "권한 요청·부여 명령 없음. 권한 보유 여부만 확인");
        String[] list = {"android.permission.WRITE_SECURE_SETTINGS",
                "android.permission.MODIFY_AUDIO_ROUTING", "android.permission.MANAGE_ACTIVITY_STACKS",
                "android.permission.INTERACT_ACROSS_USERS_FULL", "android.permission.BIND_APPWIDGET"};
        for (String name: list) {
            try { put(o,name, app.checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED ? "GRANTED" : "NOT_GRANTED"); }
            catch (Exception e) { put(o,name,"UNKNOWN_ERROR"); }
        }
        return o;
    }
}
