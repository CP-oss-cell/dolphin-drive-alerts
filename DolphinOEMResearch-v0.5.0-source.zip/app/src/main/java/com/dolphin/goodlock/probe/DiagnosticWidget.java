package com.dolphin.goodlock.probe;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

public final class DiagnosticWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.diagnostic_widget);
            views.setTextViewText(R.id.diag_label, "돌핀 Good Lock 진단 위젯");
            manager.updateAppWidget(id, views);
        }
    }
}
