import java.io.File;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;
/** Parse-only check. Does not resolve Android symbols or replace Gradle build. */
public class ParseJava {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
    try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,Locale.ROOT,null)) {
      Iterable<? extends JavaFileObject> input=manager.getJavaFileObjectsFromStrings(Arrays.asList(args));
      JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,Arrays.asList("-proc:none"),null,input);
      task.parse();
      int errs=0;
      for(Diagnostic<? extends JavaFileObject> d:diagnostics.getDiagnostics()){
        if(d.getKind()==Diagnostic.Kind.ERROR){errs++;System.err.println(d);}
      }
      if(errs>0){System.err.println("Java parse errors: "+errs);System.exit(1);}
      System.out.println("Java source syntax parsed successfully: "+args.length+" files (NOT Android type-check/compile)");
    }
  }
}
