#!/usr/bin/env python3
"""Verify session ZIP hash manifest and v0.5 schema (offline, never sends data)."""
import hashlib, json, sys, zipfile
from pathlib import Path

if len(sys.argv) != 2:
    print('Usage: python3 tools/verify_export_zip.py DolphinOEMResearch_YYYYMMDD_HHMMSS.zip')
    raise SystemExit(2)
p=Path(sys.argv[1]); required={'session.json','summary.txt','manual-results.json','shortcut-followup.json','dock-features.json','SHA256SUMS.txt'}
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None, 'ZIP CRC FAIL'
    assert set(z.namelist()) == required, f'Unexpected ZIP files: {set(z.namelist()) ^ required}'
    sha={}
    for line in z.read('SHA256SUMS.txt').decode('utf-8').splitlines():
        digest, name=line.split('  ',1); sha[name]=digest
    for name in required-{'SHA256SUMS.txt'}:
        assert sha.get(name)==hashlib.sha256(z.read(name)).hexdigest(),f'SHA256 FAIL {name}'
    session=json.loads(z.read('session.json')); summary=session.get('automatic_summary') or {}
    manual=json.loads(z.read('manual-results.json'))
    follow=json.loads(z.read('shortcut-followup.json'))
    dock=json.loads(z.read('dock-features.json'))
    assert session['schema']=='DolphinOEMResearch/0.5', 'Unexpected schema'
    assert session.get('safety','').startswith('READ_ONLY'), 'Safety marker missing'
    assert all(k in summary for k in ('errors','unavailable','unknown','blocked')), 'Missing verdict split'
    assert all(k in dock for k in ('add_app','move_icon','edit_menu','horizontal_scroll')) if 'M3' in manual else dock=={}, 'Incomplete M3 dock evidence'
    assert (not follow or 'status' in follow), 'Missing shortcut follow-up status'
print('PASS: ZIP CRC + every SHA256 + v0.5 verdict separation + dock fields')
print('Measured, not inferred:',summary)
