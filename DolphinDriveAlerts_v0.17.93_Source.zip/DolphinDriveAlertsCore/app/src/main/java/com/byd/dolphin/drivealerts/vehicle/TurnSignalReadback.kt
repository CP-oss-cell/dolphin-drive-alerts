package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/**
 * BYD DiLink 3/5 Turn Signal Readback (v0.17.93):
 * Real-car verified BYDAutoLightDevice APIs (matching LinkLock & DolphinControl):
 * 1. BYDAutoLightDevice.getLightStatus(1) = LEFT turn signal, getLightStatus(2) = RIGHT turn signal
 *    (with getDoubleFlashLightState() hazard guard so emergency flashers never trigger BVM).
 * 2. BYDAutoLightDevice.getTurnLightState() / getTurnLightFlashState() (1=LEFT, 2=RIGHT, 3=HAZARD, 0=OFF).
 * 3. Legacy zero-arg getter fallback.
 */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    data class Result(val side: Side, val detail: String, val anyBlinkerActive: Boolean = false)

    internal fun classify(left: Int?, right: Int?): Boolean =
        (left == 1 && right == 0) || (right == 1 && left == 0)

    private data class Sample(val method: String, val value: Int?)
    private val classes = listOf(
        "android.hardware.bydauto.light.BYDAutoLightDevice",
        "android.hardware.bydauto.BYDAutoLightDevice",
        "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
        "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice"
    )
    private val leftMethods = listOf(
        "getLeftTurnLightState", "getLeftTurnSignalState",
        "getLeftTurnLampState", "getLeftTurnState", "getLeftTurnSignalLightState"
    )
    private val rightMethods = listOf(
        "getRightTurnLightState", "getRightTurnSignalState",
        "getRightTurnLampState", "getRightTurnState", "getRightTurnSignalLightState"
    )

    fun read(): Result {
        val notes = mutableListOf<String>()
        var left: Sample? = null
        var right: Sample? = null

        for (className in classes) {
            val cls = try { Class.forName(className) } catch (t: Throwable) {
                notes += "class:${className.substringAfterLast('.')}=${t.javaClass.simpleName}"
                continue
            }
            val device = try {
                val factory = cls.methods.firstOrNull {
                    it.name == "getInstance" && it.parameterCount == 1 &&
                        it.parameterTypes[0].isAssignableFrom(Context::class.java)
                } ?: cls.methods.firstOrNull { it.name == "getInstance" && it.parameterCount == 0 }
                if (factory == null) { notes += "factory:${cls.simpleName}=MISSING"; continue }
                if (factory.parameterCount == 1) factory.invoke(null, app) else factory.invoke(null)
            } catch (t: Throwable) {
                notes += "instance:${cls.simpleName}=${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                continue
            }
            if (device == null) { notes += "instance:${cls.simpleName}=NULL"; continue }

            // Check hazard / double-flash state first so hazard lights do not trigger Left/Right BVM
            val hazard = runCatching {
                val hm = cls.methods.firstOrNull { it.name == "getDoubleFlashLightState" && it.parameterCount == 0 }
                (hm?.invoke(device) as? Number)?.toInt() == 1
            }.getOrDefault(false)
            if (hazard) {
                return Result(Side.UNKNOWN, "hazardActive=true", anyBlinkerActive = false)
            }

            // 1. Primary BYD DiLink 5.0 API: getLightStatus(1) = LEFT, getLightStatus(2) = RIGHT
            val mLightStatus = cls.methods.firstOrNull {
                it.name == "getLightStatus" && it.parameterCount == 1 &&
                    (it.parameterTypes[0] == Int::class.javaPrimitiveType || it.parameterTypes[0] == Integer::class.java)
            }
            if (mLightStatus != null) {
                val lVal = runCatching { (mLightStatus.invoke(device, 1) as? Number)?.toInt() }.getOrNull()
                val rVal = runCatching { (mLightStatus.invoke(device, 2) as? Number)?.toInt() }.getOrNull()
                val lBin = when (lVal) { 1 -> 1; 0, 2 -> 0; else -> null }
                val rBin = when (rVal) { 1 -> 1; 0, 2 -> 0; else -> null }
                if (lBin != null && rBin != null) {
                    left = Sample("${cls.simpleName}.getLightStatus(1)", lBin)
                    right = Sample("${cls.simpleName}.getLightStatus(2)", rBin)
                    if (lBin == 1 || rBin == 1) break
                } else {
                    notes += "getLightStatus(1/2):raw=$lVal/$rVal"
                }
            }

            // 2. BYD DiLink 5.0 combined turn state: getTurnLightState() / getTurnLightFlashState()
            for (mName in listOf("getTurnLightState", "getTurnLightFlashState")) {
                val m = cls.methods.firstOrNull { it.name == mName && it.parameterCount == 0 } ?: continue
                val raw = runCatching { (m.invoke(device) as? Number)?.toInt() }.getOrNull() ?: continue
                when (raw) {
                    1 -> {
                        left = Sample("${cls.simpleName}.$mName", 1)
                        right = Sample("${cls.simpleName}.$mName", 0)
                    }
                    2 -> {
                        left = Sample("${cls.simpleName}.$mName", 0)
                        right = Sample("${cls.simpleName}.$mName", 1)
                    }
                    0 -> {
                        if (left == null) left = Sample("${cls.simpleName}.$mName", 0)
                        if (right == null) right = Sample("${cls.simpleName}.$mName", 0)
                    }
                    else -> notes += "$mName=$raw"
                }
                if (raw == 1 || raw == 2) break
            }
            if (left?.value == 1 || right?.value == 1) break

            // 3. Legacy individual getters fallback
            fun readSide(names: List<String>, tag: String): Sample? {
                for (name in names) {
                    val method = cls.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
                    val raw = try { method.invoke(device) } catch (t: Throwable) {
                        notes += "$tag.$name:${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                        continue
                    }
                    if (raw is Number) return Sample("${cls.simpleName}.$name", raw.toInt())
                }
                return null
            }
            val candidateLeft = readSide(leftMethods, "LEFT")
            val candidateRight = readSide(rightMethods, "RIGHT")
            if (candidateLeft != null && candidateRight != null &&
                candidateLeft.value in 0..1 && candidateRight.value in 0..1
            ) {
                left = candidateLeft
                right = candidateRight
                if (candidateLeft.value == 1 || candidateRight.value == 1) break
            }
        }

        val l = left?.value
        val r = right?.value
        val side = when {
            l == 1 && r == 0 -> Side.LEFT
            r == 1 && l == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        val detail = "left=$l right=$r;leftMethod=${left?.method ?: "MISSING"};" +
            "rightMethod=${right?.method ?: "MISSING"};reason=${notes.take(10).joinToString("|")}"
        return Result(side, detail, anyBlinkerActive = classify(l, r))
    }
}
