# 빌드 상태

버전: 0.2.0-realcar-rawlog / versionCode 2

소스 변경은 완료되었으나 현재 실행 환경에는 Android SDK/Build Tools가 없고,
외부 DNS가 차단되어 Gradle 및 Android SDK를 내려받을 수 없어 APK 컴파일 단계에 진입하지 못했다.
따라서 존재하지 않는 APK를 정상 설치 APK라고 표시하지 않는다.

필요 빌드 환경:
- JDK 17 이상
- Android SDK 34
- Gradle 8.7 wrapper
- 인터넷 가능한 Gradle dependency resolution

빌드 명령:
`./gradlew :app:assembleDebug --stacktrace`
