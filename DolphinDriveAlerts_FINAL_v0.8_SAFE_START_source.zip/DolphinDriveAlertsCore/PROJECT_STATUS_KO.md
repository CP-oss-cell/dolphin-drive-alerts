# Dolphin Drive Alerts · 프로젝트 상태 규칙

## 상태
- TODO: 아직 구현 전
- IMPLEMENTED: 코드 반영 완료, 실차 검증 전
- REALCAR_VERIFY_REQUIRED: 실차 로그/동작 검증 필요
- VERIFIED: 실차 증거로 확인 완료

## 기능 묶음
1. 음성팩/출력: 남/여 사전생성 음성, 효과음, 운전석 stream 14, 미디어
2. 차량 RAW 신호: 기어/EPB/회생/AutoHold/ICC/BSD/차선/앞차출발/도어 후측방
3. AVAS/외부 스피커: 순정 주행 전자음 ON/OFF 및 외부 출력 경로 진단
4. 핸들 리모컨: MENU/BACK/학습키 3연타, 사용자 단발 음성
5. 자동실행: BOOT_COMPLETED/Quick Boot/MY_PACKAGE_REPLACED, START_STICKY
6. 앱별 정책: DPI 및 오디오 라우팅 정책
7. GitHub Actions: TTS 60개 생성, APK, SHA-256, 생성된 소스 artifact

## 절대 원칙
- 실차 의미가 확인되지 않은 RAW 값은 자동 음성/차량 제어에 연결하지 않는다.
- setter/차량 제어 API는 검증 증거 없이 추가하지 않는다.
- 외부 AVAS 스피커 주입은 진단 로그로 경로 확인 전 비활성 상태를 유지한다.
- IMPLEMENTED와 VERIFIED를 혼동하지 않는다.
