package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.util.CoreLog
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap

class BydVehicleReader(context: Context) {
    private val app = context.applicationContext
    private val devices = ConcurrentHashMap<String, Any>()
    private val methods = ConcurrentHashMap<String, Method>()
    private val failed = HashSet<String>()

    fun readFrame(): RawVehicleFrame {
        return RawVehicleFrame(
            speedKmH = readNumber(SPEED, "getCurrentSpeed")?.toFloat(),
            gearRaw = readInt(GEARBOX, "getCurrentGear"),
            epbRaw = readInt(GEARBOX, "getEPBState"),
            avhRaw = readInt(ADAS, "getAVHState"),
            bsdRaw = readInt(ADAS, "getBSDState"),
            laneOffsetRaw = readInt(ADAS, "getLaneOffsetState"),
            tjaRaw = readInt(ADAS, "getTJAState"),
            driveInterfaceRaw = readInt(INSTRUMENT, "getCurrentDriveInterFace"),
            energyFeedbackRaw = readInt(INSTRUMENT, "getEnergyFeedback") ?: readInt(SETTING, "getEnergyFeedback"),
            driveConfigRaw = readInt(SETTING, "getDriveConfig"),
            deviationRaw = readInt(INSTRUMENT, "getDeviationState"),
            pcwAlarmRaw = readInt(INSTRUMENT, "getPCWAlarmInstruction"),
            laneLineStateRaw = readInt(INSTRUMENT, "getLaneLineState"),
            radarDistances = readIntArray(RADAR, "getAllRadarObstacleDistances")
        )
    }

    fun readReferenceEnergySignals(): Map<String, Int> {
        val out = linkedMapOf<String, Int>()
        val candidates = mapOf(
            "energy.recycle" to listOf("getEnergyRecycle", "getEnergyRecycleState"),
            "energy.roadSurface" to listOf("getEnergyRoadSurface", "getRoadSurface", "getRoadSurfaceState"),
            "energy.operationMode" to listOf("getOperationMode", "getOperationModeState"),
            "energy.accMode" to listOf("getAccMode", "getACCMode")
        )
        for ((key, names) in candidates) {
            names.firstNotNullOfOrNull { name -> readInt(ENERGY, name) }?.let { out[key] = it }
        }
        return out
    }

    private fun readInt(className: String, methodName: String): Int? = readNumber(className, methodName)?.toInt()
    private fun readNumber(className: String, methodName: String): Number? = invoke(className, methodName) as? Number
    private fun readIntArray(className: String, methodName: String): IntArray? = invoke(className, methodName) as? IntArray

    private fun invoke(className: String, methodName: String): Any? {
        val key = "$className#$methodName"
        return try {
            val instance = devices.getOrPut(className) {
                val c = Class.forName(className)
                c.getMethod("getInstance", Context::class.java).invoke(null, BydPermissionContext.wrap(app))
                    ?: error("getInstance null")
            }
            val method = methods.getOrPut(key) { instance.javaClass.getMethod(methodName) }
            method.invoke(instance)
        } catch (t: Throwable) {
            synchronized(failed) {
                if (failed.add("$key:${t.javaClass.simpleName}")) CoreLog.w("BYD", "$key unavailable: ${t.cause?.message ?: t.message}")
            }
            null
        }
    }

    companion object {
        private const val SPEED = "android.hardware.bydauto.speed.BYDAutoSpeedDevice"
        private const val GEARBOX = "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice"
        private const val ADAS = "android.hardware.bydauto.adas.BYDAutoADASDevice"
        private const val INSTRUMENT = "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice"
        private const val SETTING = "android.hardware.bydauto.setting.BYDAutoSettingDevice"
        private const val RADAR = "android.hardware.bydauto.radar.BYDAutoRadarDevice"
        private const val ENERGY = "android.hardware.bydauto.energy.BYDAutoEnergyDevice"
    }
}
