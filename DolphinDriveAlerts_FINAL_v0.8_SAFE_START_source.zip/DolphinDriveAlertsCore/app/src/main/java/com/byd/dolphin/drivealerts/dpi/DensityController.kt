package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

object DensityController {
    @Volatile private var applied: Int? = null

    fun apply(context: Context, dpi: Int?): Boolean {
        if (dpi == applied) return true
        val command = if (dpi == null) "wm density reset" else "wm density ${dpi.coerceIn(120, 640)}"
        val result = NativeAdbClient.executeShell(context.applicationContext, command)
        CoreLog.i("DPI", "$command success=${result.success} exit=${result.exitCode}")
        if (result.success) applied = dpi
        return result.success
    }
}
