package com.byd.dolphin.drivealerts.log

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

/**
 * Read-only Android audio-route snapshot.  It cannot prove that the BYD AVAS/external
 * speaker is an Android AudioDevice, but changes here are useful evidence when the
 * stock "주행 전자음" toggle is operated.
 */
class AudioRouteProbe(context: Context) {
    private val audio = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun snapshot(): Map<String, String> = linkedMapOf<String, String>().apply {
        put("mode", audio.mode.toString())
        put("isMusicActive", audio.isMusicActive.toString())
        @Suppress("DEPRECATION")
        put("isSpeakerphoneOn", audio.isSpeakerphoneOn.toString())
        put("stream.music.volume", safeVolume(AudioManager.STREAM_MUSIC))
        put("stream.alarm.volume", safeVolume(AudioManager.STREAM_ALARM))
        put("stream.notification.volume", safeVolume(AudioManager.STREAM_NOTIFICATION))
        put("stream.14.volume", safeVolume(14))
        put("property.outputSampleRate", audio.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE) ?: "null")
        put("property.framesPerBuffer", audio.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER) ?: "null")

        val outputs = runCatching { audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS) }.getOrDefault(emptyArray())
            .sortedBy { it.id }
        put("output.count", outputs.size.toString())
        outputs.forEachIndexed { i, d -> put("output.$i", describe(d)) }
    }

    private fun safeVolume(stream: Int): String = runCatching {
        "${audio.getStreamVolume(stream)}/${audio.getStreamMaxVolume(stream)}"
    }.getOrElse { "unavailable:${it.javaClass.simpleName}" }

    private fun describe(d: AudioDeviceInfo): String = buildString {
        append("id=").append(d.id)
        append(",type=").append(typeName(d.type)).append('(').append(d.type).append(')')
        append(",product=").append(d.productName ?: "")
        append(",rates=").append(d.sampleRates.joinToString(prefix = "[", postfix = "]"))
        append(",channels=").append(d.channelCounts.joinToString(prefix = "[", postfix = "]"))
        append(",encodings=").append(d.encodings.joinToString(prefix = "[", postfix = "]"))
    }

    private fun typeName(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "BUILTIN_EARPIECE"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "BUILTIN_SPEAKER"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "WIRED_HEADSET"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "WIRED_HEADPHONES"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "BLUETOOTH_SCO"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "BLUETOOTH_A2DP"
        AudioDeviceInfo.TYPE_HDMI -> "HDMI"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB_DEVICE"
        AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB_ACCESSORY"
        AudioDeviceInfo.TYPE_DOCK -> "DOCK"
        AudioDeviceInfo.TYPE_FM -> "FM"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER_SAFE -> "BUILTIN_SPEAKER_SAFE"
        AudioDeviceInfo.TYPE_BUS -> "BUS"
        AudioDeviceInfo.TYPE_IP -> "IP"
        AudioDeviceInfo.TYPE_AUX_LINE -> "AUX_LINE"
        else -> "TYPE_$type"
    }
}
