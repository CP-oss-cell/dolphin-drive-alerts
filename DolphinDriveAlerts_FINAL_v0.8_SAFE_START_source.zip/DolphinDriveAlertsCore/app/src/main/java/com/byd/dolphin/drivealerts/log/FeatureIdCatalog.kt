package com.byd.dolphin.drivealerts.log

import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Modifier

/** Read-only reflection dump of BYDAutoFeatureIds. Useful for mapping raw event IDs to names. */
class FeatureIdCatalog {
    private val byId: Map<Int, List<String>> by lazy { load() }

    fun namesFor(id: Int): List<String> = byId[id].orEmpty()

    fun asJson(): JSONObject = JSONObject().apply {
        put("count", byId.values.sumOf { it.size })
        val items = JSONArray()
        byId.toSortedMap().forEach { (id, names) ->
            items.put(JSONObject().apply {
                put("id", id)
                put("hex", "0x${id.toUInt().toString(16)}")
                put("names", JSONArray(names))
            })
        }
        put("items", items)
    }

    private fun load(): Map<Int, List<String>> {
        val grouped = linkedMapOf<Int, MutableList<String>>()
        for (name in CLASSES) {
            val c = runCatching { Class.forName(name) }.getOrNull() ?: continue
            c.declaredFields.filter { Modifier.isStatic(it.modifiers) && it.type == Int::class.javaPrimitiveType }.forEach { f ->
                runCatching {
                    f.isAccessible = true
                    val id = f.getInt(null)
                    grouped.getOrPut(id) { mutableListOf() }.add("${c.simpleName}.${f.name}")
                }
            }
        }
        return grouped.mapValues { it.value.distinct().sorted() }
    }

    companion object {
        private val CLASSES = listOf(
            "android.hardware.bydauto.BYDAutoFeatureIds",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Adas",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Instrument",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Setting",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Energy",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Radar",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Gearbox",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Bodywork",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Audio"
        )
    }
}
