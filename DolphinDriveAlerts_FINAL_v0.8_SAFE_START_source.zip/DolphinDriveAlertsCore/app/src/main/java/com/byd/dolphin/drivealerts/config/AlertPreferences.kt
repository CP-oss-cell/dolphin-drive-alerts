package com.byd.dolphin.drivealerts.config

import android.content.Context
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.OutputRoute

object AlertPreferences {
    private const val PREF = "drive_alert_core"
    private const val KEY_ROUTE = "route"
    private const val KEY_STYLE = "style"
    private const val KEY_ENABLED = "enabled"

    fun route(context: Context): OutputRoute = runCatching {
        OutputRoute.valueOf(prefs(context).getString(KEY_ROUTE, OutputRoute.DRIVER_STREAM14.name)!!)
    }.getOrDefault(OutputRoute.DRIVER_STREAM14)

    fun setRoute(context: Context, route: OutputRoute) =
        prefs(context).edit().putString(KEY_ROUTE, route.name).apply()

    fun style(context: Context): AlertStyle = runCatching {
        AlertStyle.valueOf(prefs(context).getString(KEY_STYLE, AlertStyle.EFFECT.name)!!)
    }.getOrDefault(AlertStyle.EFFECT)

    fun setStyle(context: Context, style: AlertStyle) =
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
