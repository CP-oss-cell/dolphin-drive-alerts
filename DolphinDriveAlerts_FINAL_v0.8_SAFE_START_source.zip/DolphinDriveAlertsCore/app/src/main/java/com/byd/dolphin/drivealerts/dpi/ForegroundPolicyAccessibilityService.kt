package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.util.CoreLog

class ForegroundPolicyAccessibilityService : AccessibilityService() {
    private var activePackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
            CoreLog.i("ACCESSIBILITY", "key-event filter enabled")
        }.onFailure { CoreLog.w("ACCESSIBILITY", "failed to request key-event filtering: ${it.message}") }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (pkg == activePackage) return
        activePackage = pkg
        val policy = AppPolicyStore.all(this)[pkg]
        if (policy == null) {
            DensityController.apply(this, null)
            return
        }
        CoreLog.i("APP_POLICY", "foreground=$pkg dpi=${policy.dpiMode} audio=${policy.audioRoute}")
        DensityController.apply(this, policy.requestedDpi())
        ExternalAppAudioRouter.apply(this, pkg, policy.audioRoute)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        SteeringTripleTapDetector.onKeyEvent(this, event)
        return false // Observe only. OEM single/double behavior remains untouched.
    }

    override fun onInterrupt() = Unit
    override fun onDestroy() { DensityController.apply(this, null); super.onDestroy() }
}
