package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap

/** Read-only reflection probe for unknown BYD raw values. Never invokes setters or methods with parameters. */
class ReadOnlySignalProbe(context: Context) {
    private val app = context.applicationContext
    private val devices = ConcurrentHashMap<String, Any>()
    private val getterCache = ConcurrentHashMap<String, List<Method>>()
    private val unavailable = HashSet<String>()

    fun snapshot(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        for (className in CLASSES) {
            val instance = instance(className) ?: continue
            val short = className.substringAfterLast('.')
            val getters = getterCache.getOrPut(className) {
                instance.javaClass.methods.filter { m ->
                    m.parameterTypes.isEmpty() &&
                        (m.name.startsWith("get") || m.name.startsWith("is")) &&
                        m.name !in BLOCKED_NAMES && isSafeReturn(m.returnType)
                }.sortedBy { it.name }
            }
            for (m in getters) {
                val v = runCatching { m.invoke(instance) }.getOrNull() ?: continue
                serialize(v)?.let { out["$short.${m.name}"] = it }
            }
        }
        return out
    }

    private fun instance(className: String): Any? {
        devices[className]?.let { return it }
        synchronized(unavailable) { if (className in unavailable) return null }
        return runCatching {
            val c = Class.forName(className)
            val o = c.getMethod("getInstance", Context::class.java).invoke(null, BydPermissionContext.wrap(app)) ?: return null
            devices[className] = o; o
        }.getOrElse { synchronized(unavailable) { unavailable.add(className) }; null }
    }

    private fun isSafeReturn(c: Class<*>): Boolean = c.isPrimitive || Number::class.java.isAssignableFrom(c) ||
        c == java.lang.Boolean::class.java || c == String::class.java || c.isEnum || c.isArray

    private fun serialize(v: Any): String? = when (v) {
        is IntArray -> v.joinToString(prefix="[", postfix="]")
        is FloatArray -> v.joinToString(prefix="[", postfix="]")
        is DoubleArray -> v.joinToString(prefix="[", postfix="]")
        is LongArray -> v.joinToString(prefix="[", postfix="]")
        is BooleanArray -> v.joinToString(prefix="[", postfix="]")
        is Array<*> -> v.joinToString(prefix="[", postfix="]") { it?.toString() ?: "null" }
        is Number, is Boolean, is String, is Enum<*> -> v.toString()
        else -> null
    }

    companion object {
        private val BLOCKED_NAMES = setOf("getClass", "getInstance")
        private val CLASSES = listOf(
            "android.hardware.bydauto.speed.BYDAutoSpeedDevice",
            "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
            "android.hardware.bydauto.adas.BYDAutoADASDevice",
            "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
            "android.hardware.bydauto.setting.BYDAutoSettingDevice",
            "android.hardware.bydauto.radar.BYDAutoRadarDevice",
            "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
            "android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice"
        )
    }
}
