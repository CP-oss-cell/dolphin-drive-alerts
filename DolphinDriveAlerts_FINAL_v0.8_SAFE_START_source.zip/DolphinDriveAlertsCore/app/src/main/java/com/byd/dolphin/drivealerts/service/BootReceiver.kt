package com.byd.dolphin.drivealerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Starts the always-on foreground monitor after a normal Android boot, BYD/Android quick boot,
 * or package replacement. The app only needs to be opened once after installation so Android
 * clears the package "stopped" state; subsequent normal vehicle restarts are automatic.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "<null>"
        CoreLog.i("BOOT", "received $action enabled=${AlertPreferences.isEnabled(context)}")
        if (!AlertPreferences.isEnabled(context)) return
        runCatching { DrivingAlertService.start(context.applicationContext) }
            .onSuccess { CoreLog.i("BOOT", "foreground service start requested: $action") }
            .onFailure { CoreLog.w("BOOT", "start failed for $action: ${it.message}", it) }
    }
}
