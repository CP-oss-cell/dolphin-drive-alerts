package com.byd.dolphin.drivealerts.steering

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File

enum class SteeringTriggerMode { MENU, BACK, EITHER, LEARNED }

object SteeringTriggerPreferences {
    private const val PREF = "steering_one_shot"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_MODE = "mode"
    private const val KEY_LEARNED_CODE = "learned_key_code"
    private const val KEY_LEARNED_SCAN = "learned_scan_code"
    private const val KEY_LEARN_UNTIL = "learn_until_ms"
    private const val KEY_SOUND_PATH = "sound_path"
    private const val KEY_SOUND_NAME = "sound_name"

    fun enabled(context: Context) = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, value).apply()

    fun mode(context: Context): SteeringTriggerMode = runCatching {
        SteeringTriggerMode.valueOf(prefs(context).getString(KEY_MODE, SteeringTriggerMode.EITHER.name)!!)
    }.getOrDefault(SteeringTriggerMode.EITHER)
    fun setMode(context: Context, value: SteeringTriggerMode) = prefs(context).edit().putString(KEY_MODE, value.name).apply()

    fun learnedKeyCode(context: Context) = prefs(context).getInt(KEY_LEARNED_CODE, -1)
    fun learnedScanCode(context: Context) = prefs(context).getInt(KEY_LEARNED_SCAN, -1)
    fun saveLearnedKey(context: Context, keyCode: Int, scanCode: Int) {
        prefs(context).edit()
            .putInt(KEY_LEARNED_CODE, keyCode)
            .putInt(KEY_LEARNED_SCAN, scanCode)
            .putLong(KEY_LEARN_UNTIL, 0L)
            .apply()
    }

    fun armLearning(context: Context, durationMs: Long = 15_000L) {
        prefs(context).edit().putLong(KEY_LEARN_UNTIL, System.currentTimeMillis() + durationMs).apply()
    }
    fun cancelLearning(context: Context) = prefs(context).edit().putLong(KEY_LEARN_UNTIL, 0L).apply()
    fun isLearning(context: Context): Boolean = prefs(context).getLong(KEY_LEARN_UNTIL, 0L) >= System.currentTimeMillis()

    fun soundFile(context: Context): File? = prefs(context).getString(KEY_SOUND_PATH, null)
        ?.let(::File)?.takeIf { it.isFile && it.canRead() }
    fun soundName(context: Context): String = prefs(context).getString(KEY_SOUND_NAME, null) ?: "기본 음성: 빵빵, 차 좀 지나갈게요"

    fun importSound(context: Context, uri: Uri): Result<String> = runCatching {
        val app = context.applicationContext
        val name = displayName(app, uri) ?: "custom_one_shot_audio"
        val dir = File(app.filesDir, "one_shot").apply { mkdirs() }
        dir.listFiles()?.forEach { runCatching { it.delete() } }
        val target = File(dir, "custom_audio.bin")
        app.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(32 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= 25L * 1024L * 1024L) { "음성파일은 25MB 이하만 지원합니다." }
                    output.write(buffer, 0, n)
                }
                require(total > 0L) { "빈 파일입니다." }
            }
        } ?: error("선택한 파일을 읽을 수 없습니다.")
        prefs(app).edit().putString(KEY_SOUND_PATH, target.absolutePath).putString(KEY_SOUND_NAME, name).apply()
        CoreLog.i("STEERING", "custom one-shot imported name=$name bytes=${target.length()}")
        name
    }

    fun clearSound(context: Context) {
        soundFile(context)?.let { runCatching { it.delete() } }
        prefs(context).edit().remove(KEY_SOUND_PATH).remove(KEY_SOUND_NAME).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun displayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
}
