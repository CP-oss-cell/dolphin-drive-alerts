package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Passive AVAS/external-speaker diagnostics.
 * All shell commands are read-only: dumpsys/getprop/settings/service/logcat/cat/ls/tinymix.
 * No mixer value, system setting, vehicle ECU or BYD setter is changed.
 */
class SystemDiagnosticsCollector(
    context: Context,
    private val logger: RawSignalLogger,
    private val featureIds: FeatureIdCatalog
) {
    private val app = context.applicationContext
    private val root = File(app.filesDir, "external_speaker_diag").apply { mkdirs() }
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "external-speaker-diag").apply { isDaemon = true }
    }

    init {
        writeText(File(root, "byd_feature_ids.json"), featureIds.asJson().toString(2))
    }

    fun directory(): File = root

    fun captureDeep(label: String) {
        executor.execute { captureInternal(label, COMMANDS_DEEP) }
    }

    /** Faster capture for an exact ON/OFF state. */
    fun captureQuick(label: String) {
        executor.execute { captureInternal(label, COMMANDS_QUICK) }
    }

    /** Raw Linux input capture for steering-wheel button mapping. Read-only except for a temporary file under /data/local/tmp. */
    fun captureSteeringKeyWindow(seconds: Int = 10) {
        val duration = seconds.coerceIn(5, 20)
        logger.marker("STEERING_RAW_WINDOW_START", "${duration}s")
        executor.execute {
            val dir = File(root, "${stamp()}_STEERING_KEYS").apply { mkdirs() }
            val tmp = "/data/local/tmp/drivealerts_keys.txt"
            val command = "sh -c 'rm -f $tmp; getevent -lt > $tmp 2>&1 & pid=${'$'}!; sleep $duration; kill ${'$'}pid 2>/dev/null || true; wait ${'$'}pid 2>/dev/null || true; cat $tmp; rm -f $tmp'"
            val events = NativeAdbClient.executeShell(app, command, timeoutMs = (duration + 8L) * 1000L)
            val input = NativeAdbClient.executeShell(app, "dumpsys input", timeoutMs = 8_000L)
            val caps = NativeAdbClient.executeShell(app, "getevent -lp 2>&1", timeoutMs = 8_000L)
            writeText(File(dir, "steering_getevent.txt"), "# $command\n# success=${events.success} exit=${events.exitCode} ${events.message}\n\n${limit(events.output)}")
            writeText(File(dir, "dumpsys_input.txt"), limit(input.output))
            writeText(File(dir, "getevent_capabilities.txt"), limit(caps.output))
            logger.marker("STEERING_RAW_WINDOW_END", "${duration}s success=${events.success}")
        }
    }

    /** Capture start/end around a short real driving-sound window. */
    fun captureWindow(label: String, seconds: Int = 12) {
        logger.marker("${label}_WINDOW_START", "${seconds}s")
        executor.execute { captureInternal("${label}_START", COMMANDS_QUICK) }
        executor.schedule({
            logger.marker("${label}_WINDOW_END", "${seconds}s")
            captureInternal("${label}_END", COMMANDS_QUICK)
        }, seconds.toLong(), TimeUnit.SECONDS)
    }

    /** Queues behind earlier captures so export includes all requested snapshots. */
    fun captureDeepAndWait(label: String, timeoutSeconds: Long = 180): Boolean = runCatching {
        executor.submit<Boolean> { captureInternal(label, COMMANDS_DEEP); true }.get(timeoutSeconds, TimeUnit.SECONDS)
    }.getOrElse {
        CoreLog.w("EXT_SPK_DIAG", "final capture timeout/failure: ${it.message}")
        false
    }

    fun close() {
        executor.shutdown()
        runCatching { executor.awaitTermination(2, TimeUnit.SECONDS) }
        executor.shutdownNow()
    }

    private fun captureInternal(label: String, commands: Map<String, String>) {
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(64)
        val dir = File(root, "${stamp()}_$safe").apply { mkdirs() }
        logger.marker("DIAG_CAPTURE_START", safe)

        writeText(File(dir, "00_meta.json"), JSONObject().apply {
            put("label", label)
            put("timestampMs", System.currentTimeMillis())
            put("adbPortOpen", NativeAdbClient.isPortOpen())
            put("note", "read-only external speaker/AVAS diagnostics")
        }.toString(2))

        for ((filename, command) in commands) {
            val r = NativeAdbClient.executeShell(app, command)
            val header = "# command: $command\n# success=${r.success} exit=${r.exitCode} message=${r.message}\n\n"
            writeText(File(dir, filename), header + limit(r.output))
        }
        logger.marker("DIAG_CAPTURE_END", safe)
    }

    private fun writeText(file: File, text: String) = runCatching {
        file.parentFile?.mkdirs()
        file.writeText(text, Charsets.UTF_8)
    }.onFailure { CoreLog.w("EXT_SPK_DIAG", "write failed ${file.name}: ${it.message}") }

    private fun limit(s: String): String = if (s.length <= MAX_CHARS) s else {
        "# output truncated to last $MAX_CHARS chars\n" + s.takeLast(MAX_CHARS)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    companion object {
        private const val MAX_CHARS = 2_000_000
        private val COMMANDS_QUICK = linkedMapOf(
            "02_audio.txt" to "dumpsys audio",
            "03_audio_policy.txt" to "dumpsys media.audio_policy",
            "05_properties.txt" to "getprop | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|acoustic' || true",
            "06_settings.txt" to "(settings list system; settings list global; settings list secure) | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "10_tinymix.txt" to "command -v tinymix >/dev/null 2>&1 && tinymix || echo 'tinymix unavailable'",
            "12_logcat_filtered.txt" to "logcat -d -v threadtime -t 2000 | grep -Ei 'byd|bydauto|audio|sound|avas|vsp|pedestrian|speaker|acoustic|warning|vehicle|low.?speed' || true"
        )

        private val COMMANDS_DEEP = linkedMapOf(
            "01_service_list.txt" to "service list | grep -Ei 'audio|sound|vehicle|car|byd|avas|vsp|pedestrian' || true",
            "02_audio.txt" to "dumpsys audio",
            "03_audio_policy.txt" to "dumpsys media.audio_policy",
            "04_audio_flinger.txt" to "dumpsys media.audio_flinger",
            "05_properties.txt" to "getprop | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|acoustic' || true",
            "06_settings_system.txt" to "settings list system | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "07_settings_global.txt" to "settings list global | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "08_settings_secure.txt" to "settings list secure | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "09_asound_cards.txt" to "cat /proc/asound/cards 2>&1; echo; cat /proc/asound/pcm 2>&1; echo; ls -l /dev/snd 2>&1",
            "10_tinymix.txt" to "command -v tinymix >/dev/null 2>&1 && tinymix || echo 'tinymix unavailable'",
            "11_hal_audio_vehicle.txt" to "command -v lshal >/dev/null 2>&1 && lshal | grep -Ei 'audio|vehicle|byd|sound' || true",
            "12_logcat_filtered.txt" to "logcat -d -v threadtime -t 2000 | grep -Ei 'byd|bydauto|audio|sound|avas|vsp|pedestrian|speaker|acoustic|warning|vehicle|low.?speed' || true"
        )
    }
}
