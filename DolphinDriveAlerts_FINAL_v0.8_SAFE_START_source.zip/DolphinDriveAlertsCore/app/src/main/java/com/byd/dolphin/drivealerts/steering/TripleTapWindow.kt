package com.byd.dolphin.drivealerts.steering

/** Pure timing/state helper so triple-tap behavior can be validated without Android. */
class TripleTapWindow(
    private val windowMs: Long = 1_200L,
    private val minGapMs: Long = 80L
) {
    private val taps = ArrayDeque<Long>()
    private var lastIdentity: String? = null
    private var lastDownMs = Long.MIN_VALUE

    @Synchronized
    fun register(nowMs: Long, identity: String): Boolean {
        if (lastDownMs != Long.MIN_VALUE && nowMs - lastDownMs < minGapMs) return false
        if (lastIdentity != identity) taps.clear()
        lastIdentity = identity
        lastDownMs = nowMs
        while (taps.isNotEmpty() && nowMs - taps.first() > windowMs) taps.removeFirst()
        taps.add(nowMs)
        if (taps.size >= 3) {
            taps.clear()
            return true
        }
        return false
    }

    @Synchronized
    fun reset() {
        taps.clear()
        lastIdentity = null
        lastDownMs = Long.MIN_VALUE
    }
}
