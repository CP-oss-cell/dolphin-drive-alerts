# Core 0.8 SAFE START 수정

실차에서 FINAL 0.7 APK가 설치되지만 실행 직후 종료되는 현상 대응 빌드입니다.

주요 변경:
- foreground service가 BYD/vendor 클래스보다 먼저 startForeground()를 호출.
- 차량/진단 컴포넌트별 초기화를 전부 독립 try/catch로 격리.
- 가장 위험한 BYD listener tap은 앱 시작 시 등록하지 않고 AVAS 진단 버튼을 눌렀을 때만 lazy-start.
- UI build 실패 시에도 SAFE START 오류 화면을 표시.
- 서비스 명령 실패가 전체 앱 프로세스를 종료하지 않도록 방어.
- 기존 60개 음성, RAW 로그, AVAS 진단, 핸들 3연타 기능 유지.

실차에서 먼저 확인:
1. 아이콘 터치 시 UI가 열리는지
2. 상단에 '주행 보조 알림 작동 중' 알림이 뜨는지
3. 알림 테스트가 재생되는지
4. RAW/AVAS 로그 생성 버튼이 동작하는지
