#!/usr/bin/env python3
import json, pathlib, sys, wave
root=pathlib.Path(__file__).resolve().parents[1]
prompts=json.loads((root/'tools/voice_prompts.json').read_text(encoding='utf-8'))
errors=[]; count=0
for style in ('male','female'):
    for p in prompts:
        f=root/'app/src/main/assets/voice'/style/p['file']
        count+=1
        if not f.exists(): errors.append(f'missing {f.relative_to(root)}'); continue
        try:
            with wave.open(str(f),'rb') as w:
                if w.getnchannels()!=1 or w.getsampwidth()!=2 or w.getframerate()!=44100:
                    errors.append(f'bad format {f.relative_to(root)} ch={w.getnchannels()} width={w.getsampwidth()} sr={w.getframerate()}')
                if w.getnframes()<2205: errors.append(f'too short {f.relative_to(root)}')
        except Exception as e: errors.append(f'unreadable {f.relative_to(root)}: {e}')
print(f'voice files checked: {count}; errors: {len(errors)}')
for e in errors: print(e)
if errors: sys.exit(1)
