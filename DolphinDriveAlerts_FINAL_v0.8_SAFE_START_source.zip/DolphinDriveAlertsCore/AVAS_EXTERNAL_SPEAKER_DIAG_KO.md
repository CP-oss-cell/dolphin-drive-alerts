# 순정 주행 전자음 / 외부 스피커 실차 진단 (Core 0.5)

목적: BYD 순정 UI의 `주행 전자음` ON/OFF와 실제 외부 스피커 출력이 어느 계층에서 제어되는지 확인한다.

## 안전 원칙
- 이 진단 기능은 BYD setter, 차량 제어 명령, mixer 변경, Settings 변경을 호출하지 않는다.
- `registerListener` 및 getter/reflection, Android AudioManager 조회, 로컬 ADB의 읽기 명령만 사용한다.
- 순정 보행자 경고 기능을 비활성화하거나 커스텀 음원으로 대체하지 않는다.
- 실제 외부 전자음 구간은 안전한 장소에서 저속으로만 수집한다.

## 자동 수집
서비스가 실행되는 동안 다음을 기록한다.
- 기존 150ms 차량 RAW polling
- 1초 전체 snapshot + 값 변경 즉시 기록
- BYD read-only `get*/is*` getter 탐색
- BYD Setting/Instrument/ADAS/Energy/Radar/Gearbox listener의 이벤트 ID/값 변화
- `BYDAutoFeatureIds` ID↔이름 매핑
- Android 출력 AudioDevice/route/volume 변화

## 심층 캡처
각 AVAS 버튼에서 다음 읽기 전용 자료를 별도 폴더에 저장한다.
- `service list` 관련 서비스
- `dumpsys audio`
- `dumpsys media.audio_policy`
- `dumpsys media.audio_flinger`
- audio/sound/AVAS/VSP/pedestrian/BYD 관련 `getprop`
- 관련 `settings list system/global/secure`
- `/proc/asound/cards`, `/proc/asound/pcm`, `/dev/snd`
- `tinymix` 현재 상태(명령이 존재할 때만, 값 변경 없음)
- `lshal` audio/vehicle 관련 항목
- 최근 관련 `logcat`

## 실차 순서
1. 앱 실행 후 `1. 기준 상태 캡처`
2. 순정 UI에서 `주행 전자음 OFF`
3. 5초 기다린 뒤 `2. ... OFF 후 기록`
4. 순정 UI에서 `주행 전자음 ON`
5. 5초 기다린 뒤 `3. ... ON 후 기록`
6. 안전한 장소에서 `4. 실제 외부 전자음 12초 구간 캡처`를 누르고 저속으로 실제 전자음이 나게 한 뒤 정차
7. `수집된 파일 생성 · Download 폴더에 저장`
8. 생성된 `DolphinDriveAlerts_RAW_AVAS_*.zip` 파일을 분석용으로 전달

## 분석 목표
- 특정 BYD event ID/getter가 ON/OFF와 같이 변하는지
- Settings/property 값이 바뀌는지
- Android audio route/device가 바뀌는지
- audio policy/AudioFlinger에서 별도 BUS/외부 device가 나타나는지
- ALSA/tinymix에서 외부 경고 스피커 경로가 노출되는지
- 아무 Android 경로 변화가 없고 BYD/MCU 이벤트만 보이는지

이 결과로 Android audio route인지, BYD vendor service인지, MCU/AVAS 전용 경로인지 분류한다.
