# Dolphin OEM HUD Bridge v0.10.3 — 순정 TMAP TBT 우선

**최종 목적:** 한국 BYD 돌핀(글로벌 2602)의 **순정 `com.tmap.auto.byd` TBT 회전 방향/거리 → TPLAY HUD Q 실제 표시**. 일반 TMAP, 네이버지도, 아틀란, 카카오맵은 부가 내비.

## 현재까지 입증된 사실

- 사용자 실차: TPLAY HUD Q FFEA/FFF2 연결·수동 밝기·우회전 300m 시험 출력 성공. 관련 BLE/설정 프로토콜 파일은 v0.10.1과 바이트 동일(무변경 SHA 기록).
- 순정 TMAP은 내부에 TBT 값을 갖고 있으나 **일반 APK에서 TBT 방향·거리를 실시간으로 직접 구독하는 공개 IPC 미확정**. 지금도 순정 내비 자동 HUD 출력은 미해결.
- RE-001~011 원본 연구의 최종 대조: Binder는 경로 정보 중심; 순정 상태 방송은 TBT 아님; 화면의 방향 아이콘은 이미지이고 접근성 View ID에서 읽을 수 없음; DiCar Binder 제공자는 TBT API 입증되지 않음.

## v0.10.3 빌드 오류 수정

- `byd2.zip`의 실제 GitHub Actions 빌드 오류 수정: Android SDK `ProviderInfo.permission` 없는 필드 참조 제거.
- 오프라인 가짜 SDK ProviderInfo 클래스에서 잘못 추가된 permission 필드를 제거.
- CI에서 실제 Android 34 `android.jar`로 해당 프로브를 컴파일하는 신규 차단 검사 추가.
- 새 릴리스 `versionCode=23`. 기존 v0.10.2 HUD 프로토콜, BLE, 내비 판단 로직 변경 없음.

## v0.10.2 변경 (유지)

1. **확인된 순정 상태 방송 두 개**(`NAVIGATION_STATE_CHANGED`, `MAP_ACTIVITY_STATE_CHANGED`)를 등록해 상태값만 기록. 발신자 인증/현재 방향/거리 확인으로 표시하지 않음.
2. 자동 선택/순정 TMAP 선택 때 근거 없는 AutoNavi 방송이 TBT HUD 명령으로 전환되는 것을 차단. 다른 내비의 기존 호환 후보는 별도로 보존.
3. 순정 TMAP의 그래픽 화살표에 대해 `AccessibilityNodeInfo.getViewIdResourceName()`으로 방향을 추정하던 잘못된 코드를 제거. 거리 전용 위젯·설명 없는 이미지 수만 기록. 임의 방향 출력 금지.
4. DiCarServer의 Provider·순정 ClusterActivity 설치 **Manifest 메타데이터**만 읽기 전용 자동 조회. Provider query/차량 Binder 트랜잭션/ECU 명령 실행 없음.
5. 기존 다크모드·자동밝기·내비 목록 선택·ADB 권한·부팅 시작·실차 성공 BLE 보존.

### 독립 연구 자료

- `research/HUD-RE-012/TECHNICAL_REPORT_KO.md` : 마지막 심화 조사와 RE-001~011의 근거·결론·한계.
- `research/HUD-RE-012/evidence/` : 12차수 판단 매트릭스, 성공 BLE 원본 해시 보존 증거.
- `tools/validate_re012_evidence.py` : 소스·근거 일관성 점검 (실차 테스트 아님).

## GitHub 빌드 (통합 ZIP 1개만 다운로드)

1. 받은 `DolphinOemHudBridge_v0.10.3_Complete_Build_Package.zip`을 한 번만 압축 해제합니다.
2. 나온 `DolphinOemHudBridge_v0.10.3_Source.zip`은 **그대로 GitHub 저장소 최상위에 업로드**합니다.
3. `DolphinOemHudBridge_v0.10.3_Source.yml`을 이름을 바꿔 `build-oem-hud-bridge.yml`로 만든 뒤 `.github/workflows/build-oem-hud-bridge.yml` 경로에 올려 기존 파일을 교체합니다.
4. GitHub Actions에서 `Build Dolphin OEM HUD Bridge v0.10.3 (ZIP + YML)` 실행. 성공한 APK `DolphinOemHudBridge_v0.10.3_vc23.apk` 업데이트 설치.

**검증 한계:** 현 환경에는 실제 Android SDK/Gradle 및 차량이 없어 APK 컴파일 성공과 순정 TBT 자동 안내를 입증하지 못했습니다. 빌드 프로세스는 GitHub Actions에서 확인해야 합니다. 원본 OEM/MCON APK는 재배포하지 않습니다.

**중요:** 기존 저장소에 남아 있는 이전 버전 소스 ZIP과 구형 GitHub Actions 파일이 중복 실행되지 않도록, v0.10.3 소스와 워크플로를 같은 브랜치에 업로드해야 합니다. 실차 TBT 자동 출력은 아직 미입증입니다.
