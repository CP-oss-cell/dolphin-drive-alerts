package com.dolphin.oemhud;

import android.content.*;
import java.text.*;
import android.content.pm.ApplicationInfo;
import java.util.*;

public final class BridgeLog {
    static final String STORE="nav_bridge";
    private BridgeLog() {}
    public static boolean isNavPackage(Context context, String name){
        if(name==null)return false;
        String chosen=context.getSharedPreferences(STORE,0).getString("nav_package","").trim();
        if(!chosen.isEmpty())return chosen.equals(name);
        // Some BYD / DiLink OEM navigation package names have no "nav" substring.
        // Only inspect the visible app's public label; do not read unrelated apps.
        String label="";
        try {
            ApplicationInfo app=context.getPackageManager().getApplicationInfo(name,0);
            CharSequence visible=context.getPackageManager().getApplicationLabel(app);
            if(visible!=null)label=visible.toString();
        } catch (Exception ignored) {}
        return NavPackageMatcher.likely(name,label);
    }
    public static synchronized void event(Context ctx,String line){
        String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.KOREA).format(new Date());
        android.content.SharedPreferences p=ctx.getSharedPreferences(STORE,0);
        String old=p.getString("history","");
        String item=stamp+" "+line.replace('\n',' ').replace('\r',' ');
        if(item.length()>300)item=item.substring(0,300);
        String combined=old+item+"\n";
        if(combined.length()>15000)combined=combined.substring(combined.length()-15000);
        p.edit().putString("history",combined).apply();
        android.util.Log.i("DolphinHud",item);
    }
    public static void cue(Context ctx,NavCue cue){
        if(cue==null || !ctx.getSharedPreferences(STORE,0).getBoolean("enabled",false))return;
        ctx.getSharedPreferences(STORE,0).edit().putString("last_cue",cue.display()).apply();
        event(ctx,"TBT "+cue.display());
        if(cue.isUsable()){
            if(!BridgeService.onCue(cue)){
                // Notification/accessibility can start before the foreground bridge service.
                // Store only a short-lived maneuver; don't replay stale turns after relaunch.
                ctx.getSharedPreferences(STORE,0).edit()
                    .putString("pending_direction",cue.direction)
                    .putInt("pending_distance",cue.distanceMeters)
                    .putString("pending_source",cue.source)
                    .putLong("pending_at",System.currentTimeMillis()).apply();
                try{
                    android.content.Intent service=new android.content.Intent(ctx,BridgeService.class);
                    if(android.os.Build.VERSION.SDK_INT>=26)ctx.startForegroundService(service);
                    else ctx.startService(service);
                    event(ctx,"순정 안내 수신 · 브리지 서비스 재시작 요청");
                }catch(Exception e){event(ctx,"브리지 자동 시작 실패: "+e.getClass().getSimpleName());}
            }
        }
        else event(ctx,"TBT 방향·거리 불확실 → HUD 명령 생성 생략 (원본 확인 필요)");
    }
}
