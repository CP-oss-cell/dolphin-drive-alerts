package com.dolphin.oemhud;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

/** TMAP/selected navigator: read-only visible guidance, only with user-enabled accessibility.
 * Never taps the OEM UI, sends a vehicle signal, or reads unrelated windows' text. */
public final class NavAccessibilityService extends AccessibilityService {
    private String lastCueKey="";
    private long lastCueAt, lastObservationAt, lastTreeAt;
    private int lastEventCount;
    private final Handler pollHandler=new Handler(Looper.getMainLooper());
    private final Runnable periodicGuideScan=new Runnable(){
        @Override public void run(){
            try{
                android.content.SharedPreferences p=getSharedPreferences(BridgeLog.STORE,0);
                if(p.getBoolean("enabled",false)){
                    String nav=p.getString("nav_package","").trim();
                    if(nav.isEmpty())nav="com.tmap.auto.byd";
                    String text=readNavigatorWindows(nav);
                    if(!text.isEmpty()){
                        p.edit().putInt("nav_poll_scans_count",p.getInt("nav_poll_scans_count",0)+1)
                            .putString("last_nav_package",nav)
                            .putInt("nav_visible_text_chars",text.length())
                            .putBoolean("nav_distance_token_seen",NavCue.hasDistanceToken(text))
                            .putBoolean("nav_direction_token_seen",NavCue.hasDirectionToken(text)).apply();
                        publish(NavCue.fromText("TMAP 자동화면:"+nav,text),p);
                    }
                }
            }catch(Exception e){BridgeLog.event(NavAccessibilityService.this,"화면 자동 조회 오류: "+e.getClass().getSimpleName());}
            finally{pollHandler.postDelayed(this,1800);}
        }
    };

    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        AccessibilityServiceInfo info=getServiceInfo();
        if(info!=null){
            info.flags|=AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            setServiceInfo(info);
        }
        getSharedPreferences(BridgeLog.STORE,0).edit()
            .putBoolean("a11y_runtime_connected",true)
            .putString("a11y_runtime_state","CONNECTED")
            .putLong("a11y_runtime_at",System.currentTimeMillis()).apply();
        BridgeLog.event(this,"순정 TMAP 화면 수신기 실제 연결");
        pollHandler.removeCallbacks(periodicGuideScan);
        pollHandler.postDelayed(periodicGuideScan,700);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null || event.getPackageName()==null)return;
        if(!getSharedPreferences(BridgeLog.STORE,0).getBoolean("enabled",false))return;
        final String pkg=String.valueOf(event.getPackageName());
        if(!BridgeLog.isNavPackage(this,pkg))return;
        android.content.SharedPreferences prefs=getSharedPreferences(BridgeLog.STORE,0);
        lastEventCount=prefs.getInt("nav_accessibility_count",0)+1;
        prefs.edit().putInt("nav_accessibility_count",lastEventCount)
            .putString("last_nav_package",pkg)
            .putString("last_nav_input_source","TMAP 접근성 이벤트")
            .putLong("last_nav_event_at",System.currentTimeMillis()).apply();

        StringBuilder eventText=new StringBuilder();
        List<CharSequence> lines=event.getText();
        if(lines!=null)for(CharSequence s:lines){
            if(s!=null && eventText.length()<1000)eventText.append(s).append(' ');
        }
        if(event.getContentDescription()!=null)eventText.append(event.getContentDescription()).append(' ');
        NavCue cue=NavCue.fromText("TMAP 화면:"+pkg,eventText.toString());
        if(cue==null || !cue.isUsable()){
            // An OEM TBT may consist of separate TextViews: distance, direction, lane.
            // Gather only nodes that belong to the selected navigator window.
            long now=SystemClock.elapsedRealtime();
            if(now-lastTreeAt>=450){
                lastTreeAt=now;
                String visible=readNavigatorWindows(pkg);
                if(!visible.isEmpty()){
                    prefs.edit().putInt("nav_tree_scan_count",prefs.getInt("nav_tree_scan_count",0)+1)
                        .putInt("nav_visible_text_chars",visible.length())
                        .putBoolean("nav_distance_token_seen",NavCue.hasDistanceToken(visible))
                        .putBoolean("nav_direction_token_seen",NavCue.hasDirectionToken(visible)).apply();
                    cue=NavCue.fromText("TMAP 화면트리:"+pkg,visible);
                }
            }
        }
        if(cue==null || !cue.isUsable()){
            if(lastEventCount%15==1) prefs.edit()
                .putInt("nav_parse_missing_count",prefs.getInt("nav_parse_missing_count",0)+1).apply();
            long now=SystemClock.elapsedRealtime();
            if(now-lastObservationAt>15000){
                lastObservationAt=now;
                BridgeLog.event(this,"순정 내비 화면 이벤트 감지, 회전/거리 짝 미확인 · pkg="+pkg+
                    " / event="+lastEventCount+" / tree="+prefs.getInt("nav_tree_scan_count",0));
            }
            return;
        }
        publish(cue,prefs);
    }
    private void publish(NavCue cue,android.content.SharedPreferences prefs){
        if(cue==null||!cue.isUsable())return;
        String key=cue.direction+"/"+cue.distanceMeters;
        long now=SystemClock.elapsedRealtime();
        // A stationary turn label must not flood the BLE queue every polling cycle.
        if(key.equals(lastCueKey)&&now-lastCueAt<15000)return;
        lastCueKey=key;lastCueAt=now;
        prefs.edit().putInt("nav_parsed_count",prefs.getInt("nav_parsed_count",0)+1)
            .putString("last_nav_input_source",cue.source).apply();
        BridgeLog.cue(this,cue);
    }

    /** Restrict content collection to nodes labelled with the exact emitting navigation package. */
    private String readNavigatorWindows(String pkg){
        StringBuilder all=new StringBuilder();
        int[] screenEvidence=new int[]{0,0}; // OEM distance widgets, unlabeled images (not actual TBT direction)
        AccessibilityNodeInfo root=null;
        try{
            root=getRootInActiveWindow();
            if(root!=null)collect(root,pkg,all,0,new int[]{0},screenEvidence);
        }catch(Exception ignored){}
        finally{if(root!=null)root.recycle();}
        if(all.length()<1500){
            try{
                List<AccessibilityWindowInfo> windows=getWindows();
                if(windows!=null)for(AccessibilityWindowInfo window:windows){
                    if(all.length()>=1500)break;
                    AccessibilityNodeInfo r=window.getRoot();
                    if(r!=null)try{collect(r,pkg,all,0,new int[]{0},screenEvidence);}finally{r.recycle();}
                }
            }catch(Exception ignored){}
        }
        if(OemTmapStateSignal.PACKAGE.equals(pkg)){
            getSharedPreferences(BridgeLog.STORE,0).edit()
                .putInt("oem_tbt_distance_widgets_last",screenEvidence[0])
                .putInt("oem_unlabeled_images_last",screenEvidence[1])
                .putString("oem_direction_access","NOT_EXPOSED_BY_TEXT_OR_VIEW_ID")
                .apply();
        }
        return all.length()>1600?all.substring(0,1600):all.toString();
    }
    private static void collect(AccessibilityNodeInfo n,String pkg,StringBuilder out,int depth,int[] seen,int[] screenEvidence){
        if(n==null||depth>12||seen[0]++>300||out.length()>1500)return;
        CharSequence owner=n.getPackageName();
        if(owner!=null && pkg.contentEquals(owner)){
            append(out,n.getText());append(out,n.getContentDescription());
            // HUD-RE-008/010: getViewIdResourceName() is a VIEW ID, NEVER the
            // current ImageView.setImageResource() drawable. OEM TBT arrows
            // have neither view IDs nor contentDescription. Do not create
            // fake turns from this value. Only record non-sensitive counts.
            if(OemTmapStateSignal.PACKAGE.equals(pkg)){
                CharSequence klass=n.getClassName();
                if(klass!=null){
                    String type=String.valueOf(klass);
                    if(type.endsWith("TbtDistanceTextView"))screenEvidence[0]++;
                    if(type.endsWith("ImageView")&&n.getContentDescription()==null)screenEvidence[1]++;
                }
            }
        }
        for(int i=0;i<n.getChildCount()&&i<60&&out.length()<1500;i++){
            AccessibilityNodeInfo child=n.getChild(i);
            if(child!=null)try{collect(child,pkg,out,depth+1,seen,screenEvidence);}finally{child.recycle();}
        }
    }
    private static void append(StringBuilder out,CharSequence s){
        if(s!=null&&s.length()>0&&out.length()<1500)out.append(s).append(' ');
    }
    @Override public void onInterrupt(){BridgeLog.event(this,"순정 TMAP 화면 수신 일시 중단");}
    @Override public void onDestroy(){
        pollHandler.removeCallbacks(periodicGuideScan);
        getSharedPreferences(BridgeLog.STORE,0).edit()
            .putBoolean("a11y_runtime_connected",false)
            .putString("a11y_runtime_state","DISCONNECTED").apply();
        super.onDestroy();
    }
}
