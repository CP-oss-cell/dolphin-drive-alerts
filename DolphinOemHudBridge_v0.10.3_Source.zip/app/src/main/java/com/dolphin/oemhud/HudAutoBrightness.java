package com.dolphin.oemhud;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.Calendar;
import java.util.Locale;

/** App-side HUD illumination adaptation. Does not access vehicle lights, CAN or OEM controls.
 * Light sensor wins when provided by Android; clock is an explicit fallback.
 * Hysteresis keeps alternating tunnel/shadow samples from flooding the BLE queue. */
public final class HudAutoBrightness implements SensorEventListener {
    private static final float NIGHT_BELOW_LUX=20f;
    private static final float DAY_ABOVE_LUX=85f;
    private static final long SENSOR_STALE_MS=120000L;
    private final Context context;
    private final HudConnector connector;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private SensorManager sensors;
    private boolean started;
    private boolean haveLux;
    private boolean night;
    private long lastLuxElapsed;
    private float lastLux=-1f;
    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(!started)return;
            if(!haveLux || SystemClock.elapsedRealtime()-lastLuxElapsed>SENSOR_STALE_MS)
                updateForNight(clockIsNight(),"시간대 대체",false);
            handler.postDelayed(this,60000L);
        }
    };
    public HudAutoBrightness(Context app,HudConnector connector){
        this.context=app.getApplicationContext();this.connector=connector;
    }
    private SharedPreferences prefs(){return context.getSharedPreferences(BridgeLog.STORE,0);}
    static boolean clockIsNight(){
        int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h<7 || h>=19;
    }
    static boolean sensorNight(float lux,boolean previousNight){
        if(Float.isNaN(lux)||lux<0) return previousNight;
        return previousNight?lux<DAY_ABOVE_LUX:lux<NIGHT_BELOW_LUX;
    }
    public void refresh(){
        boolean enabled=prefs().getBoolean("hud_brightness_saved",false) && prefs().getBoolean("hud_brightness_auto",false);
        if(!enabled){stop();return;}
        if(!started){
            started=true;
            try{
                sensors=(SensorManager)context.getSystemService(Context.SENSOR_SERVICE);
                Sensor light=sensors==null?null:sensors.getDefaultSensor(Sensor.TYPE_LIGHT);
                if(light!=null){
                    if(sensors.registerListener(this,light,SensorManager.SENSOR_DELAY_NORMAL))
                        prefs().edit().putString("hud_auto_sensor","조도 센서 대기").apply();
                    else prefs().edit().putString("hud_auto_sensor","센서 등록 실패 · 시간대 전환").apply();
                }else prefs().edit().putString("hud_auto_sensor","센서 없음 · 시간대 전환").apply();
            }catch(Exception e){
                prefs().edit().putString("hud_auto_sensor","센서 접근 불가 · 시간대 전환").apply();
            }
            handler.removeCallbacks(tick);handler.postDelayed(tick,60000L);
        }
        boolean initial=haveLux && SystemClock.elapsedRealtime()-lastLuxElapsed<=SENSOR_STALE_MS
            ?sensorNight(lastLux,night):clockIsNight();
        updateForNight(initial,haveLux?"조도 센서":"시간대 대체",true);
    }
    public void stop(){
        if(sensors!=null)try{sensors.unregisterListener(this);}catch(Exception ignored){}
        sensors=null;started=false;haveLux=false;handler.removeCallbacks(tick);
        prefs().edit().putString("hud_auto_sensor","자동 조절 중지").apply();
    }
    private void updateForNight(boolean nextNight,String reason,boolean force){
        if(!started || !prefs().getBoolean("hud_brightness_auto",false))return;
        if(!force && prefs().getBoolean("hud_auto_state_known",false) && night==nextNight)return;
        night=nextNight;
        SharedPreferences p=prefs();
        int day=p.getInt("hud_brightness_day",2), evening=p.getInt("hud_brightness_night",0);
        int level=nextNight?evening:day;
        p.edit().putBoolean("hud_auto_state_known",true)
            .putBoolean("hud_auto_night_active",nextNight)
            .putString("hud_auto_sensor",reason+(haveLux?String.format(Locale.ROOT," · %.1f lux",lastLux):""))
            .putString("hud_auto_status",(nextNight?"야간":"주간")+" · "+(level+1)+"단계 · "+reason)
            .putLong("hud_auto_changed_at",System.currentTimeMillis()).apply();
        // Two identical levels force the current actual HUD level. The previous
        // mode merely sent day/night preferences and relied on HUD firmware switching.
        connector.sendSetting(HudSettingsProtocol.brightness(level,level));
        BridgeLog.event(context,"HUD 앱 자동 밝기: "+(nextNight?"야간":"주간")+
            " / 레벨="+(level+1)+" / "+reason);
    }
    @Override public void onSensorChanged(SensorEvent event){
        if(!started || event==null || event.sensor.getType()!=Sensor.TYPE_LIGHT ||
            event.values==null || event.values.length==0)return;
        float lux=event.values[0];
        if(Float.isNaN(lux)||lux<0||Float.isInfinite(lux))return;
        lastLux=lux;lastLuxElapsed=SystemClock.elapsedRealtime();haveLux=true;
        boolean nextNight=sensorNight(lux,night);
        if(nextNight!=night || !prefs().getBoolean("hud_auto_state_known",false))
            updateForNight(nextNight,"조도 센서",false);
        else prefs().edit().putString("hud_auto_sensor",String.format(Locale.ROOT,"조도 센서 · %.1f lux",lux)).apply();
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
}
