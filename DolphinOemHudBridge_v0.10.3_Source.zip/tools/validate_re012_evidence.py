#!/usr/bin/env python3
"""Checks source claims and retained verified BLE byte hashes (static only)."""
from pathlib import Path
import hashlib,csv,json
root=Path(__file__).resolve().parents[1]
r=root/'research/HUD-RE-012'
base=root/'app/src/main/java/com/dolphin/oemhud'
assert (r/'TECHNICAL_REPORT_KO.md').exists()
rows=list(csv.DictReader((r/'evidence/RESEARCH_001_012_DECISION_MATRIX.csv').open(encoding='utf-8-sig')))
assert len(rows)==12, len(rows)
checks=json.loads((r/'evidence/VERIFIED_BASE_COMPONENT_SHA256.json').read_text())
assert len(checks)==7
for item in checks:
 assert item['unchanged'],item
 assert hashlib.sha256((base/item['component']).read_bytes()).hexdigest()==item['v0101_sha256'],item
s=(base/'BridgeService.java').read_text()
assert 'OemTmapStateSignal.NAVIGATION_STATE' in s and 'OemTmapStateSignal.MAP_ACTIVITY_STATE' in s
assert 'autonavi_ignored_for_oem' in s
assert 'signal.diagnostic()' in s and 'NavCue' not in (base/'OemTmapStateSignal.java').read_text()
acc=(base/'NavAccessibilityService.java').read_text()
assert 'append(out,NavCue.maneuverFromResourceId' not in acc
assert 'oem_direction_access' in acc and 'oem_tbt_distance_widgets_last' in acc
vehicle=(base/'OemVehicleIpcProbe.java').read_text()
assert 'getPackageInfo(' in vehicle and 'getActivityInfo(' in vehicle
assert 'getContentResolver().query(' not in vehicle and 'Binder.transact(' not in vehicle and 'Spi.getService(' not in vehicle
for x in ('HUD-RE-010/evidence/2602_LAYOUT_SUMMARY.json','HUD-RE-011/evidence/RE011_INTERFACE_SUMMARY.json'):
 assert (r/x).exists(),x
iface=json.loads((r/'HUD-RE-011/evidence/RE011_INTERFACE_SUMMARY.json').read_text())
assert iface['registered_service_instances']==23 and iface['unique_interface_methods']==91
print('PASS HUD-RE-012: 12-stage traceability, actual OEM state-only, no View ID direction, DiCar metadata-only')
print('PASS retained real-car verified BLE/brightness/protocol sources identical: 7/7')
print('PASS upstream research evidence consistency: SPI services=23 unique methods=91')
print('NOTE: no real-car OEM TBT receiving or Android APK compilation is claimed')
