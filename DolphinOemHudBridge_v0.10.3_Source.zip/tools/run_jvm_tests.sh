#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"; trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -d "$out" \
  tests/java/android/os/Bundle.java \
  app/src/main/java/com/dolphin/oemhud/NavCue.java \
  app/src/main/java/com/dolphin/oemhud/MconHudQProtocol.java app/src/main/java/com/dolphin/oemhud/HudSettingsProtocol.java \
  tests/java/com/dolphin/oemhud/NavCueSelfTest.java \
  tests/java/com/dolphin/oemhud/MconHudQProtocolTest.java \
  tests/java/com/dolphin/oemhud/HudSettingsProtocolTest.java
java -cp "$out" com.dolphin.oemhud.NavCueSelfTest
java -cp "$out" com.dolphin.oemhud.MconHudQProtocolTest
java -cp "$out" com.dolphin.oemhud.HudSettingsProtocolTest

# New navigation package recognition regression tests (actual production Java helper).
javac -encoding UTF-8 -d "$out" app/src/main/java/com/dolphin/oemhud/NavPackageMatcher.java tests/java/com/dolphin/oemhud/NavPackageMatcherTest.java
java -cp "$out" com.dolphin.oemhud.NavPackageMatcherTest

# User-selected installed app catalog: sorting/search/hidden OEM visibility.
javac -encoding UTF-8 -d "$out" app/src/main/java/com/dolphin/oemhud/NavPackageMatcher.java app/src/main/java/com/dolphin/oemhud/NavAppCatalog.java tests/java/com/dolphin/oemhud/NavAppCatalogTest.java
java -cp "$out" com.dolphin.oemhud.NavAppCatalogTest

# OEM broadcasts are status-only: exact-package and missing-data guard.
javac -encoding UTF-8 -d "$out" app/src/main/java/com/dolphin/oemhud/OemTmapStateSignal.java tests/java/com/dolphin/oemhud/OemTmapStateSignalTest.java
java -cp "$out" com.dolphin.oemhud.OemTmapStateSignalTest
