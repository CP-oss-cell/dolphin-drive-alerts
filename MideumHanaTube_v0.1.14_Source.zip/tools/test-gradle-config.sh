#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY_TEST'
from pathlib import Path
import re
props = Path('gradle.properties').read_text(encoding='utf-8')
config = {}
for line in props.splitlines():
    line = line.strip()
    if not line or line.startswith(('#','!')): continue
    match = re.fullmatch(r'([^:=\s]+)\s*[=:]\s*(.*?)\s*', line)
    if match:
        k,v = match.groups()
        if k in config: raise SystemExit(f'Duplicate Gradle property: {k}')
        config[k]=v
assert config.get('android.useAndroidX') == 'true', 'Media3 requires android.useAndroidX=true in gradle.properties'
build = Path('app/build.gradle').read_text(encoding='utf-8')
assert 'androidx.media3:media3-exoplayer:' in build, 'Native playback dependency unexpectedly missing'
assert "versionName '0.1.14'" in build
assert 'versionCode 15' in build
print('AndroidX + Media3 + version Gradle configuration PASS')
PY_TEST
