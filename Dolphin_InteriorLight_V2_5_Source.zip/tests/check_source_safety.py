"""V2.5 source invariants. Static checks only: NOT a real APK or real-car validation."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re
import sys
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/dolphin/insidelightprobe/MainActivity.java').read_text()
p=(root/'app/src/main/java/com/dolphin/insidelightprobe/LogShareProvider.java').read_text()
g=(root/'app/build.gradle').read_text()
w=(root/'.github/workflows/build-apk.yml').read_text()
m=(root/'app/src/main/AndroidManifest.xml').read_text()
a=ET.fromstring(m)
ns='{http://schemas.android.com/apk/res/android}'
providers=a.findall('.//provider')
checks={
 'XML parses':a.tag=='manifest',
 'one screen flow': 'showSimpleDashboard()' in s and 'private void render()' in s,
 'capture start': 'confirmStartCapture' in s and 'SESSION_START' in s,
 'auto tests independent of menu': 'runAutomaticDiagnostic()' in s and 'AUTO_END' in s,
 'auto scanning': 'scan();' in s and 'AUTO_DISCOVERY' in s,
 'auto permission details': 'AUTO_PERMISSION' in s and 'getPermissionInfo(p,0)' in s,
 'auto car settings read only': 'AUTO_CAR_SETTING' in s and 'insight_light_online' in s and 'setInt' not in s,
 'auto known zero arg OEM read': 'getInsideLightDoorState' in s and 'getAirLightPanelState' in s and 'getInsBacklightCtl' in s and 'getSmartWelcomeLightState' in s,
 'getter attempts count honest': 'Getter 시도' in s and 'Getter 0/4' in s and 'lastGetterAttempts=attempted' in s,
 'auto test no setter': not re.search(r'(?:runAutomaticDiagnostic|private void runAutomaticDiagnostic)[\s\S]{0,5000}setInsideLight',s),
 'no auto OEM write': 'turnOffInsideLight' not in s[s.index('private void runAutomaticDiagnostic()'):s.index('private void showManualObservation()')],
 'slow read can cancel without success': 'INCOMPLETE_TIMEOUT' in s and 'AUTO_CANCEL' in s,
 'prevent overlapping OEM reads': 'autoUnderlyingOutstanding' in s,
 'manual result explicit': 'showManualObservation()' in s and 'USER_REPORTED_ONLY' in s,
 'COMMON runtime consent only': 'requestPermissions(new String[]{PERM_COMMON},COMMON_PERMISSION_REQUEST)' in s,
 'GET SET no runtime request': all(t not in s for t in ('requestPermissions(new String[]{PERM_GET}','requestPermissions(new String[]{PERM_SET}')),
 'write method only OEM candidate': 'getMethod("turnOffInsideLight",int.class)' in s,
 'guard write both permissions': 'permission(PERM_COMMON) || !permission(PERM_SET)' in s,
 'confirm physical only': 'P단 정차 + 주차 브레이크' in s and 'PHYSICAL_CHANGED' in s,
 'session persisted': 'v25_capture_active' in s and 'SESSION_END' in s,
 'ZIP includes json': 'zipEntry(zip,"report.json",json)' in s,
 'ZIP includes summary': 'zipEntry(zip,"summary_ko.txt",summaryBytes)' in s,
 'ZIP includes manual guide': 'zipEntry(zip,"manual_steps_ko.txt",manualBytes)' in s,
 'ZIP hash manifest': 'report_sha256' in s and 'summary_sha256' in s,
 'private ZIP backup before download': s.index('writePrivateZip(bytes);')<s.index('saveZipDownloads(bytes,latestZipName)'),
 'Android 10 Downloads ZIP': 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in s and 'application/zip' in s and 'DolphinLightLogs' in s,
 'ZIP share button': 'ZIP 파일 공유' in s and 'Intent.EXTRA_STREAM,uri' in s,
 'ZIP provider path': 'latest-zip' in p and 'latest-report.zip' in p,
 'ZIP provider MIME': 'application/zip' in p and 'OpenableColumns.SIZE' in p,
 'private read-only non exported':len(providers)==1 and providers[0].get(ns+'exported')=='false' and 'MODE_READ_ONLY' in p,
 'No root shell/internet/CAN': all(t not in s for t in ('CAN_RAW','sendBroadcast(', 'Runtime.getRuntime(', 'ProcessBuilder(', 'Socket(', 'su -c')),
 'No internet/admin storage':all(t not in m for t in ('android.permission.INTERNET','MANAGE_EXTERNAL_STORAGE','WRITE_EXTERNAL_STORAGE')),
 'No HOME replacement': 'android.intent.category.HOME' not in m,
 'version increment': 'versionCode 7' in g and '2.5.0-one-screen-zip' in g,
 'new report schema': 'DOLPHIN_INTERIOR_LIGHT_WIZARD_V2_5' in s,
 'new ZIP schema': 'DOLPHIN_INTERIOR_LIGHT_ZIP_V2_5' in s,
 'GitHub actions workflow': 'Dolphin_InteriorLight_V2_5_Source.zip' in w,
 'Android SDK 35+': 'android-actions/setup-android@v4' in w,
 'APK build': ':app:assembleDebug' in w,
 'APK checksum': 'apk_sha256.txt' in w,
 'APK upload': 'Dolphin-InteriorLight-V2-5-Diagnostic-APK' in w,
}
for k,v in checks.items():print(('PASS ' if v else 'FAIL ')+k)
print(f'STATIC_PASS={sum(checks.values())}/{len(checks)} / APK_COMPILE_NOT_TESTED / REALCAR_NOT_TESTED')
sys.exit(0 if all(checks.values()) else 1)
