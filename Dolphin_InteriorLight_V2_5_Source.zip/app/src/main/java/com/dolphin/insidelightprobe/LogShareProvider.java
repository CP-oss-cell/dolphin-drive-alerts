package com.dolphin.insidelightprobe;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** One-purpose, non-exported provider for a single app-owned diagnostic JSON. */
public final class LogShareProvider extends ContentProvider {
    private static final String AUTHORITY = "com.dolphin.insidelightprobe.logs";
    private static final UriMatcher MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
    static { MATCHER.addURI(AUTHORITY, "latest", 1); MATCHER.addURI(AUTHORITY, "latest-zip", 2); }
    private File verify(Uri uri) throws FileNotFoundException {
        if ((MATCHER.match(uri) != 1 && MATCHER.match(uri) != 2) || getContext() == null)
            throw new FileNotFoundException("Unknown diagnostic file");
        File file = new File(getContext().getFilesDir(), MATCHER.match(uri) == 2 ? "latest-report.zip" : "latest-report.json");
        if (!file.isFile()) throw new FileNotFoundException("Diagnostic file is not ready");
        return file;
    }
    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) {
        return MATCHER.match(uri) == 1 ? "application/json" : MATCHER.match(uri) == 2 ? "application/zip" : null;
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        try {
            File f = verify(uri);
            String[] fields = projection == null
                    ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
            MatrixCursor c = new MatrixCursor(fields);
            Object[] values = new Object[fields.length];
            for (int i = 0; i < fields.length; i++) {
                if (OpenableColumns.DISPLAY_NAME.equals(fields[i])) values[i] = MATCHER.match(uri) == 2 ? "Dolphin_InteriorLight_latest.zip" : "Dolphin_InteriorLight_latest.json";
                else if (OpenableColumns.SIZE.equals(fields[i])) values[i] = f.length();
                else values[i] = null;
            }
            c.addRow(values);
            return c;
        } catch (FileNotFoundException e) { return null; }
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode)
            throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read-only diagnostic attachment");
        return ParcelFileDescriptor.open(verify(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Read-only provider");
    }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }
    @Override public int update(Uri uri, ContentValues values, String selection,
                                String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }
}
