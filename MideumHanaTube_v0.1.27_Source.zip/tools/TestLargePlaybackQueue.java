package app.mideumhanatube.android;
import java.util.ArrayList;
public final class TestLargePlaybackQueue {
    public static void main(String[] args) {
        PlaybackQueue q = new PlaybackQueue();
        ArrayList<PlaybackQueue.Track> tracks = new ArrayList<>();
        for (int i=1; i<=503; i++)
            tracks.add(new PlaybackQueue.Track("https://www.youtube.com/watch?v="+String.format("%011d",i),"영상"+i));
        q.setTracks(tracks,300);
        if(q.size()!=503 || q.currentIndex()!=300 || !q.current().title.equals("영상301"))
            throw new AssertionError("503-item ordered queue selected item");
        if (!q.next(false).title.equals("영상302") || !q.previous().title.equals("영상301"))
            throw new AssertionError("previous/next queue in large list");
        q.setTracks(tracks,502);
        if(q.next(true)!=null)throw new AssertionError("end must not auto substitute recommendation");
        System.out.println("503-item native playback queue and edge preservation: PASS");
    }
}
