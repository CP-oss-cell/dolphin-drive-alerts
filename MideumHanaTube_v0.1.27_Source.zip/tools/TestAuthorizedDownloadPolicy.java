package app.mideumhanatube.android;
public final class TestAuthorizedDownloadPolicy {
    private static void check(boolean value,String message) { if(!value)throw new AssertionError(message); }
    public static void main(String[] args) {
        check(".mp4".equals(AuthorizedDownloadPolicy.extension("https://example.com/video.MP4?sig=ignored")),"MP4 file");
        check(".mp3".equals(AuthorizedDownloadPolicy.extension("https://cdn.example.org/audio.mp3")),"MP3 file");
        check(".m4a".equals(AuthorizedDownloadPolicy.extension("https://example.com/sound.m4a")),"M4A file");
        check("".equals(AuthorizedDownloadPolicy.extension("https://youtube.com/watch?v=AAAAAAAAAAA")),"youtube watch prohibited");
        check("".equals(AuthorizedDownloadPolicy.extension("https://rr1.googlevideo.com/file.mp4")),"youtube stream prohibited");
        check("".equals(AuthorizedDownloadPolicy.extension("http://example.com/file.mp4")),"non-https prohibited");
        check("".equals(AuthorizedDownloadPolicy.extension("https://user:pass@example.com/file.mp3")),"embedded credentials prohibited");
        check("".equals(AuthorizedDownloadPolicy.extension("https://example.com/playlist.m3u8")),"no HLS extraction");
        check("".equals(AuthorizedDownloadPolicy.extension("https://example.com/file.mp4.exe")),"not a direct supported file");
        String safe=AuthorizedDownloadPolicy.makeFileName("../못된/경로.mp4", ".mp4", 103L);
        check(safe.endsWith(".mp4") && !safe.contains("/") && !safe.contains(".."),"safe name");
        check("audio/mp4".equals(AuthorizedDownloadPolicy.mime(".m4a")),"M4A MIME");
        System.out.println("Authorized download direct URL, path and MIME tests: PASS");
    }
}
