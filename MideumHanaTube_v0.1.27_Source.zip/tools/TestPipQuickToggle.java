package app.mideumhanatube.android;
/** Android-free regression checks for the two three-action PiP button presets. */
public final class TestPipQuickToggle {
    private static void require(boolean value, String name) {
        if (!value) throw new AssertionError(name);
    }
    public static void main(String[] args) {
        require(PlaybackHandoff.normalizedPipActionMode(1)==1, "default seek");
        require(PlaybackHandoff.toggledPipActionMode(1)==0, "seek to previous/next");
        require(PlaybackHandoff.toggledPipActionMode(0)==1, "previous/next to seek");
        require(PlaybackHandoff.toggledPipActionMode(-1)==1, "unrecognized mode normalized");
        require(PlaybackHandoff.toggledPipActionMode(99)==1, "future mode normalized");
        require("10초 이동".equals(PlaybackHandoff.pipActionModeName(1)), "Korean seek label");
        require("이전·다음 영상".equals(PlaybackHandoff.pipActionModeName(0)), "Korean queue label");
        require(PlaybackHandoff.toggledPipActionMode(PlaybackHandoff.toggledPipActionMode(1))==1,
                "two toggles round trip");
        System.out.println("v0.1.25 PiP quick toggle logic: PASS");
    }
}
