package app.mideumhanatube.android;
import java.util.List;
public final class TestYouTubePlaylistWindow {
    private static void check(boolean value,String message){ if(!value) throw new AssertionError(message); }
    private static String video(int i){ return "https://www.youtube.com/watch?v="+String.format("%011d",i); }
    public static void main(String[] args) {
        YouTubePlaylistWindow window = new YouTubePlaylistWindow();
        for(int i=1;i<=100;i++)window.add(i,video(i),"영상"+i);
        for(int i=81;i<=220;i++)window.add(i,video(i),"영상"+i);
        List<YouTubePlaylistWindow.Track> result=window.snapshot();
        check(result.size()==220,"merged 2 windows without doubles");
        check(result.get(0).index==1 && result.get(99).index==100 && result.get(219).index==220,"true order");
        check(!window.hasGaps(),"no gap");
        window.add(240,video(240),"추가");
        check(window.hasGaps(),"missing list section is explicit");
        for(int i=241;i<=503;i++)window.add(i,video(i),"영상"+i);
        check(window.snapshot().size()==484,"503-list accessible windows with gaps");
        check(window.snapshot().get(window.snapshot().size()-1).index==503,"last seen index preserved");
        window.clear();
        check(window.snapshot().isEmpty(),"reset on list change");
        window.add(0,video(1),"첫곡");
        window.add(0,video(2),"둘째곡");
        window.add(0,video(2),"중복");
        check(window.snapshot().size()==2,"nonindexed order without duplication");
        System.out.println("503-track bounded playlist window merge and order: PASS");
    }
}
