#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY_CHECK'
from pathlib import Path
import xml.etree.ElementTree as ET
pkg=Path('app/src/main/java/app/mideumhanatube/android')
main=(pkg/'MainActivity.java').read_text()
video=(pkg/'VideoPlayerActivity.java').read_text()
service=(pkg/'BackgroundAudioService.java').read_text()
manifest=ET.parse('app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
activities={a.get(ns+'name'):a for a in manifest.findall('application/activity')}
assert activities['.VideoPlayerActivity'].get(ns+'supportsPictureInPicture')=='true'
assert activities['.MainActivity'].get(ns+'supportsPictureInPicture')!='true'
assert '"웹 PIP"' not in main and 'enterPip()' not in main
for old in ['configureWebAutoPip', 'enterNativePip()', 'pipEnterJavaScript', 'pipExitJavaScript', 'setPipChromeHidden', 'ACTION_WEB_PLAY', 'ACTION_WEB_PAUSE']:
 assert old not in main,old
assert 'ACTION_WEB_PLAY' not in service and 'ACTION_WEB_PAUSE' not in service
assert not Path('app/src/main/assets/pip-video-enter.js').exists()
assert not Path('app/src/main/assets/pip-video-exit.js').exists()
assert '"작은 화면"' in main
home=main.split('@Override protected void onUserLeaveHint()')[1].split('@Override protected void onResume()')[0]
assert 'autoPip && lastKnownVideoPlaying' in home
assert 'YouTubeStreamResolver.isSupportedVideoUrl(webView.getUrl())' in home
assert 'HOME_NATIVE_PIP_REQUESTED' in home
assert 'openNativeVideo(true);' in home
assert 'beginNativeHandoff();' in home
assert 'if (exiting || launchingNativeVideo) return;' in home
native=main.split('private void openNativeVideo(boolean enterPipImmediately)')[1].split('private void updateStatus()')[0]
assert 'EXTRA_START_IN_PIP, enterPipImmediately' in native
assert 'startActivity(video)' in native
assert 'webView.evaluateJavascript' in native
assert 'new PlayerView(this)' in video and 'playerView.setPlayer(player)' in video
assert 'setAutoEnterEnabled(true)' in video
assert 'banner.post(this::enterPipNow)' in video
assert 'controls.setVisibility(inPip ? View.GONE : View.VISIBLE)' in video
assert "versionCode 28" in Path('app/build.gradle').read_text()
assert "versionName '0.1.27'" in Path('app/build.gradle').read_text()
print('PASS: Web PiP removed, native video PiP is sole Home + menu path; audio route preserved')
PY_CHECK
