# v0.1.26 검증 보고서

검증 범위: **정적 소스 및 로컬 회귀 검사** (실제 APK 컴파일/스마트폰 테스트 아님)

- Java 17 순수 정책 검사: 다운로드 URL 확장자/HTTPS/호스트 제한, 파일명 정제/MIME, 재생목록 창 합치기·중복 방지, 503곡 큐 이동/끝 경계
- JavaScript DOM 모의 검사: 503곡 visible renderer 인덱스 순서 유지
- 기존 Android 소스/미디어/PIP/웹 복귀/블루투스/로그/안전 정책에 대한 셸 검사 28개
- XML 파싱, GitHub Actions YAML 파싱, 전체 ZIP 파일 CRC와 이름/버전 일치 확인

**한계**: Android SDK와 에뮬레이터가 없어 실제 `assembleDebug` 및 Android 시스템 다운로드 서비스, 단말 PiP, 유튜브 사이트 실동작은 검증하지 못했습니다. APK 빌드 오류 또는 기기별 동작 차이는 가능성이 남습니다.
