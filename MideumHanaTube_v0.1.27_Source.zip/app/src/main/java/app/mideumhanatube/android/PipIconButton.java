package app.mideumhanatube.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Native drawn picture-in-picture pictogram (no emoji font dependency). */
public final class PipIconButton extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int actionMode = 1;
    /** Small '10' or track badge makes the active PiP control preset visible. */
    public void setActionMode(int mode) {
        actionMode = PlaybackHandoff.normalizedPipActionMode(mode);
        setContentDescription("작은 화면(PIP), " + PlaybackHandoff.pipActionModeName(actionMode)
                + ". 길게 눌러 버튼 전환");
        invalidate();
    }
    public PipIconButton(Context context) {
        super(context);
        setActionMode(1);
        setClickable(true);
        setFocusable(true);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density=getResources().getDisplayMetrics().density;
        float cx=getWidth()/2f, cy=getHeight()/2f;
        paint.setColor(Color.rgb(237,242,249));
        paint.setStrokeWidth(Math.max(1.5f,1.8f*density));
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRoundRect(new RectF(cx-13*density,cy-9*density,cx+13*density,cy+9*density),
            2*density,2*density,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(25,36,52));
        canvas.drawRect(cx-1*density,cy+1*density,cx+16*density,cy+12*density,paint);
        paint.setColor(Color.rgb(96,165,250));
        canvas.drawRoundRect(new RectF(cx,cy+2*density,cx+14*density,cy+11*density),
            1.5f*density,1.5f*density,paint);
        // Overlay a simple, high-contrast preset badge without additional toolbar width.
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create(
                android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD));
        paint.setTextSize((actionMode == 1 ? 8f : 7f) * density);
        canvas.drawText(actionMode == 1 ? "10" : ">>",
                cx + 7f*density, cy + 9.2f*density, paint);
    }
}
