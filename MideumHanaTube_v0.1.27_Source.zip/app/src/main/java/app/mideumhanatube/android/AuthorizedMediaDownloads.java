package app.mideumhanatube.android;

import android.app.DownloadManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Android DownloadManager wrapper for a direct HTTPS file the user has permission to save.
 * Public Downloads on Android 10+; private app Downloads on Android 8/9 so no
 * broad external storage permission is required. Persists IDs/names, never URLs. */
public final class AuthorizedMediaDownloads {
    private static final String STORE = "mht_authorized_downloads";
    private static final String KEY = "entries";
    private static final int MAX_ENTRIES = 30;
    private AuthorizedMediaDownloads() { }

    public static long enqueue(Context context, String url, String label) {
        String ext = AuthorizedDownloadPolicy.extension(url);
        if (ext.isEmpty()) throw new IllegalArgumentException("직접 내려받을 수 있는 HTTPS 미디어 파일 주소만 지원합니다.");
        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) throw new IllegalStateException("기기의 다운로드 서비스가 없습니다.");
        String name = AuthorizedDownloadPolicy.makeFileName(label, ext, System.currentTimeMillis());
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url.trim()))
                .setTitle(name)
                .setDescription("저장 권한이 있는 미디어 파일 다운로드")
                .setMimeType(AuthorizedDownloadPolicy.mime(ext))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true);
        if (Build.VERSION.SDK_INT >= 29)
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "믿음하나튜브/"+name);
        else
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, name);
        long id = dm.enqueue(request);
        remember(context, id, name);
        return id;
    }

    private static synchronized void remember(Context context, long id, String name) {
        JSONArray before = stored(context);
        JSONArray after = new JSONArray();
        JSONObject entry = new JSONObject();
        try { entry.put("id", id); entry.put("name", name); after.put(entry); } catch (Exception ignored) { }
        for (int i = 0; i < before.length() && after.length() < MAX_ENTRIES; i++) {
            JSONObject item = before.optJSONObject(i);
            if (item != null && item.optLong("id", -1) != id) after.put(item);
        }
        context.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit().putString(KEY, after.toString()).apply();
    }

    private static JSONArray stored(Context c) {
        String raw = c.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString(KEY, "[]");
        try { return new JSONArray(raw); } catch (Exception ignored) { return new JSONArray(); }
    }

    public static final class Status {
        public final long id;
        public final String name;
        public final String status;
        public final int progress;
        Status(long id, String name, String status, int progress) {
            this.id = id; this.name = name; this.status = status; this.progress = progress;
        }
        public String label() { return name + " · " + status + (progress >= 0 ? " " + progress + "%" : ""); }
    }

    public static List<Status> statuses(Context c) {
        List<Status> result = new ArrayList<>();
        DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) return result;
        JSONArray items = stored(c);
        for (int i = 0; i < items.length(); i++) {
            JSONObject entry = items.optJSONObject(i);
            if (entry == null) continue;
            long id = entry.optLong("id", -1);
            if (id < 0) continue;
            String state = "기록만 있음";
            int percent = -1;
            try (Cursor cursor = dm.query(new DownloadManager.Query().setFilterById(id))) {
                if (cursor != null && cursor.moveToFirst()) {
                    int code = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    if (code == DownloadManager.STATUS_SUCCESSFUL) { state = "완료"; percent = 100; }
                    else if (code == DownloadManager.STATUS_FAILED) state = "실패";
                    else if (code == DownloadManager.STATUS_PAUSED) state = "대기·일시정지";
                    else if (code == DownloadManager.STATUS_RUNNING) state = "다운로드 중";
                    else if (code == DownloadManager.STATUS_PENDING) state = "시작 대기";
                    if (total > 0 && percent != 100) percent = (int) Math.min(100, downloaded * 100 / total);
                }
            } catch (RuntimeException ignored) { state = "상태 확인 불가"; }
            result.add(new Status(id, entry.optString("name", "미디어 파일"), state, percent));
        }
        return result;
    }

    public static Uri completedUri(Context c, long id) {
        DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
        return dm == null ? null : dm.getUriForDownloadedFile(id);
    }
    public static void cancel(Context c, long id) {
        DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm != null) dm.remove(id);
    }
}
