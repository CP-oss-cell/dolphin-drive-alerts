package app.mideumhanatube.android;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;

/** Retain the order of visible, lazily loaded YouTube playlist windows.
 * No remote API, cookies or speculative/recommended media are inserted. */
public final class YouTubePlaylistWindow {
    public static final int LIMIT = 600;
    public static final class Track {
        public final int index;
        public final String url;
        public final String title;
        public Track(int index, String url, String title) {
            this.index = index;
            this.url = url;
            this.title = title;
        }
    }
    private final TreeMap<Integer, Track> numbered = new TreeMap<>();
    private final LinkedHashMap<String, Track> unnumbered = new LinkedHashMap<>();
    public void clear() { numbered.clear(); unnumbered.clear(); }
    public void add(int index, String url, String title) {
        String videoId = YouTubePlaylistContext.videoId(url);
        if (videoId.isEmpty() || index > LIMIT || index < 0) return;
        Track track = new Track(index, url, title == null ? "영상" : title);
        if (index > 0) {
            numbered.put(index, track);
            unnumbered.remove(videoId);
        } else {
            boolean present = false;
            for (Track prior : numbered.values()) if (videoId.equals(YouTubePlaylistContext.videoId(prior.url))) {
                present = true; break;
            }
            if (!present) unnumbered.putIfAbsent(videoId, track);
        }
    }
    public List<Track> snapshot() {
        ArrayList<Track> result = new ArrayList<>();
        HashSet<String> visited = new HashSet<>();
        for (Track track : numbered.values()) {
            String id = YouTubePlaylistContext.videoId(track.url);
            if (visited.add(id)) result.add(track);
            if (result.size() >= LIMIT) return result;
        }
        for (Track track : unnumbered.values()) {
            String id = YouTubePlaylistContext.videoId(track.url);
            if (visited.add(id)) result.add(track);
            if (result.size() >= LIMIT) return result;
        }
        return result;
    }
    public int size() { return snapshot().size(); }
    public boolean hasGaps() {
        if (numbered.isEmpty()) return false;
        int previous = 0;
        for (int number : numbered.keySet()) {
            if (previous != 0 && number != previous + 1) return true;
            previous = number;
        }
        return numbered.firstKey() > 1;
    }
}
