package app.mideumhanatube.android;

import java.net.URI;
import java.util.Locale;

/** Validates a user-supplied, directly downloadable, authorized media file.
 * Never extracts YouTube media URLs, media fragments, cookies, or access tokens. */
public final class AuthorizedDownloadPolicy {
    private AuthorizedDownloadPolicy() { }

    public static String extension(String rawUrl) {
        if (rawUrl == null || rawUrl.length() > 2048) return "";
        try {
            URI u = new URI(rawUrl.trim());
            if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost() == null ||
                    u.getUserInfo() != null || u.getHost().length() > 250) return "";
            String host = u.getHost().toLowerCase(Locale.ROOT);
            if (host.equals("youtu.be") || host.endsWith(".youtu.be") ||
                    host.equals("youtube.com") || host.endsWith(".youtube.com") ||
                    host.equals("googlevideo.com") || host.endsWith(".googlevideo.com") ||
                    host.equals("youtube-nocookie.com") || host.endsWith(".youtube-nocookie.com")) return "";
            String path = u.getPath();
            if (path == null) return "";
            String lower = path.toLowerCase(Locale.ROOT);
            for (String suffix : new String[]{".mp4", ".mp3", ".m4a", ".webm"})
                if (lower.endsWith(suffix)) return suffix;
        } catch (Exception ignored) { }
        return "";
    }

    public static String makeFileName(String displayName, String extension, long suffix) {
        if (extension == null || !extension.matches("\\.(mp4|mp3|m4a|webm)"))
            throw new IllegalArgumentException("unsupported media extension");
        String base = displayName == null ? "" : displayName.trim()
                .replaceAll("(?i)\\.(mp4|mp3|m4a|webm)$", "")
                .replaceAll("[^\\p{L}\\p{N} ._()\\-]", "_")
                .replaceAll("\\.{2,}", "_").trim();
        if (base.isEmpty()) base = "믿음하나튜브";
        if (base.length() > 56) base = base.substring(0, 56).trim();
        return base + "_" + Long.toString(Math.abs(suffix), 36) + extension;
    }

    public static String mime(String extension) {
        if (".mp4".equals(extension)) return "video/mp4";
        if (".webm".equals(extension)) return "video/webm";
        if (".m4a".equals(extension)) return "audio/mp4";
        if (".mp3".equals(extension)) return "audio/mpeg";
        return "application/octet-stream";
    }
}
