package app.mideumhanatube.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import org.json.JSONTokener;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.JsPromptResult;
import android.speech.RecognizerIntent;
import java.util.ArrayList;
import java.util.HashSet;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.window.OnBackAnimationCallback;
import android.window.BackEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.OutputStream;
import java.io.IOException;

/**
 * MideumHanaTube v0.1: standalone Android web-video viewer with a best-effort ad filter.
 * The application is NOT affiliated with YouTube and does not guarantee zero ads.
 * No privileged permissions, VPN, root, Google credentials or external account servers.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://m.youtube.com/";
    public static final String EXTRA_NATIVE_VIDEO_RETURN_URL = "native_video_return_url";
    public static final String EXTRA_NATIVE_VIDEO_RETURN_MS = "native_video_return_ms";
    public static final String EXTRA_NATIVE_VIDEO_RETURN_PLAYING = "native_video_return_playing";
    public static final String EXTRA_OPEN_DIAGNOSTICS = "open_diagnostics";
    private static final String PREF = "mideumhanatube_settings";
    private static final String KEY_FILTER = "filter_hosts";
    private static final String KEY_HIDE = "hide_promotions";
    private static final String KEY_SKIP = "auto_skip";
    private static final String KEY_BACKGROUND = "background_audio";
    private static final String KEY_AUTO_PIP = "auto_pip_on_home";
    private static final String KEY_MICROPHONE = "youtube_voice_microphone_enabled";
    private static final int REQUEST_MICROPHONE = 131;
    private static final int REQUEST_SPEECH = 132;
    private static final int REQUEST_DIAGNOSTIC_SAVE = 145;
    private static final String KEY_NOTIFICATION_ASKED = "notification_permission_asked";
    private static final String KEY_FIRST_RUN_PERMISSIONS = "initial_permission_setup_v2";
    private static final int REQUEST_FIRST_NOTIFICATION = 162;
    private static final int REQUEST_FIRST_MICROPHONE = 163;
    private static final int REQUEST_LIBRARY_EXPORT = 164;
    private static final int REQUEST_LIBRARY_IMPORT = 165;
    private static final int COLOR_BG = Color.rgb(15, 23, 35);
    private static final int COLOR_PANEL = Color.rgb(25, 36, 52);
    private static final int COLOR_ACCENT = Color.rgb(96, 165, 250);
    private static final int COLOR_WHITE = Color.rgb(237, 242, 249);

    private SharedPreferences settings;
    private LibraryStore library;
    private FrameLayout root;
    private LinearLayout page;
    private LinearLayout statusStrip;
    private HorizontalScrollView toolsScroll;
    // The full row also contains the fixed voice button, so hiding only toolsScroll is insufficient.
    private LinearLayout toolbarRow;
    private TextView status;
    private WebView webView;
    private FrameLayout browserContainer;
    private FrameLayout fullscreenContainer;
    private ProgressBar loading;
    private Button bookmarkButton;
    private PipIconButton pipActionButton;
    private String pendingBookmarkCollection = "";
    private String pendingBookmarkPlaylist = LibraryStore.DEFAULT_MUSIC;
    private boolean firstRunPermissionsPending;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private int priorOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
    private boolean filterOn;
    private boolean hidePromotions;
    private boolean autoSkip;
    private boolean backgroundAudio;
    private boolean autoPip;
    private boolean microphoneEnabled;
    private boolean speechAfterPermission;
    private boolean exiting;
    private AlertDialog exitConfirmationDialog;
    private boolean backLongPressHandled;
    private PermissionRequest pendingWebMicrophoneRequest;
    private boolean activityBackgrounded;
    private boolean lastKnownPlaying;
    private long lastConfirmedPlaybackAt;
    private long lastForegroundPauseAt;
    private boolean serviceWasStarted;
    private boolean playWasActiveOnLeave;
    private boolean attemptedResumeOnLeave;
    private boolean launchingNativeVideo;
    private boolean lastKnownVideoPlaying;
    private String currentNativePageUrl;
    private boolean nativeHandoffRequested;
    private boolean nativeAudioActive;
    private long latestForegroundResumeMs;
    private boolean nativeToWebSwitchPending;
    private boolean nativeSnapshotOnResumePending;
    private boolean nativeVideoReturnExplicit;
    // Retain play/pause across handoff, instead of unconditionally calling HTMLVideoElement.play().
    private boolean nativeReturnShouldPlay = true;
    private boolean nativeBrowserSync;
    private String nativePendingReturnUrl;
    private long nativePendingReturnPositionMs;
    private int nativeReturnRetries;
    private boolean returnQueryPending;
    private boolean nativeVideoReattachStarted;
    private long lastKnownPositionMs;
    private long lastRecommendationsAt;
    private final ArrayList<LibraryStore.Entry> visibleRelatedTracks = new ArrayList<>();
    // Keep the user's original YouTube playlist order separate from recommendations.
    private final ArrayList<LibraryStore.Entry> youtubePlaylistTracks = new ArrayList<>();
    private final YouTubePlaylistWindow youtubePlaylistWindow = new YouTubePlaylistWindow();
    private String youtubePlaylistId = "";
    private String youtubePlaylistJavaScript = "";
    private Button returnToVideoButton;
    private long lastPlayerCommandMs;
    private static final long PLAYER_COMMAND_VERIFY_MS = 900L;
    private String lastMediaTitle = "믿음하나튜브";
    private boolean audioReceiverRegistered;
    private OnBackInvokedCallback systemBackCallback;
    private long systemBackGestureStartedAt;
    private long lastVoiceBridgeRequestAt;
    private String youtubeMicBridgeJavaScript = "";
    private String lastNativeError = "";
    private long playbackTraceSession;
    private long lastBackAtRoot;
    private static final long BACK_EXIT_WINDOW_MS = 2000L;
    private final Runnable refreshSavedTitle = () -> {
        if (webView != null && LibraryStore.isYoutubeUrl(webView.getUrl())) {
            requestPageTitle(webView.getUrl(), 0, null);
        }
    };
    private final Handler audioHandler = new Handler(Looper.getMainLooper());
    private final BroadcastReceiver audioControlReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BackgroundAudioService.ACTION_NATIVE_READY.equals(action)) {
                PlaybackDiagnostics.event(MainActivity.this, playbackTraceSession, "HANDOFF_ACTUALLY_PLAYING", "PLAYER_VERIFIED", null);
                nativeHandoffRequested = false;
                nativeAudioActive = true;
                currentNativePageUrl = intent.getStringExtra(BackgroundAudioService.EXTRA_ACTIVE_PAGE);
                lastNativeError = "";
                if (webView != null) webView.evaluateJavascript(
                        "(function(){var v=document.querySelector('video');if(v)v.pause();})()", null);
                updateReturnToVideoButton();
                updateStatus();
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_STOPPED.equals(action)) {
                nativeAudioActive = false;
                nativeHandoffRequested = false;
                currentNativePageUrl = null;
                updateReturnToVideoButton();
                updateStatus();
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_FAILURE.equals(action)) {
                PlaybackDiagnostics.event(MainActivity.this, playbackTraceSession, "HANDOFF_FAILED_IN_UI", "PLAYER_OR_STREAM_FAILURE", null);
                nativeHandoffRequested = false;
                nativeAudioActive = false;
                currentNativePageUrl = null;
                String why = intent.getStringExtra(BackgroundAudioService.EXTRA_ERROR);
                lastNativeError = why == null ? "오디오 전환 실패" : why;
                if (!activityBackgrounded) toast(lastNativeError);
                updateReturnToVideoButton();
                updateStatus();
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_POSITION.equals(action)) {
                long position = intent.getLongExtra(BackgroundAudioService.EXTRA_POSITION_MS, 0L);
                String url = intent.getStringExtra(BackgroundAudioService.EXTRA_ACTIVE_PAGE);
                if (YouTubeStreamResolver.isSupportedVideoUrl(url)) currentNativePageUrl = url;
                nativeReturnShouldPlay = intent.getBooleanExtra(BackgroundAudioService.EXTRA_PLAYING, true);
                resumeVideoFromNative(position);
                return;
            }
            if (BackgroundAudioService.ACTION_NATIVE_SNAPSHOT.equals(action)) {
                applyNativeSnapshot(intent);
                return;
            }
            if (!BackgroundAudioService.ACTION_CONTROL.equals(action)) return;
            String control = intent.getStringExtra(BackgroundAudioService.EXTRA_CONTROL);
            if (BackgroundAudioService.ACTION_PLAY.equals(control)) {
                playWasActiveOnLeave = true;
                controlWebPlayer(true);
            } else if (BackgroundAudioService.ACTION_PAUSE.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
            } else if (BackgroundAudioService.ACTION_STOP.equals(control)) {
                playWasActiveOnLeave = false;
                controlWebPlayer(false);
                stopBackgroundService();
            }
        }
    };
    private final Runnable playbackPoll = new Runnable() {
        @Override public void run() {
            if (webView != null) {
                String url = webView.getUrl();
                if (LibraryStore.isYoutubeUrl(url)) {
                    webView.evaluateJavascript(PLAYBACK_PROBE_JS, MainActivity.this::readWebPlayerState);
                } else if (lastKnownPlaying) {
                    reportPlayerState(false, lastMediaTitle);
                }
            }
            // Native session broadcasts its own state; avoid a 250ms WebView poll.
            audioHandler.postDelayed(this, 1200L);
        }
    };
    // Poll the HTML5 media element without exposing a JavascriptInterface to untrusted frames.
    private static final String PLAYBACK_PROBE_JS = "(function(){var a=document.querySelectorAll('video'),v=null;" +
            "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
            "if(!v&&a.length)v=a[0];" +
            "return JSON.stringify({playing:!!(v&&!v.paused&&!v.ended&&v.readyState>0&&!v.muted&&v.volume>0)," +
            "videoPlaying:!!(v&&!v.paused&&!v.ended&&v.readyState>0)," +
            "hasVideo:!!v,ended:!!(v&&v.ended),positionMs:v?Math.floor(v.currentTime*1000):0,title:document.title||'믿음하나튜브'});})()";
    private final AtomicInteger blockedCount = new AtomicInteger();
    private final AtomicInteger detectedAds = new AtomicInteger();
    private final AtomicInteger skippedAds = new AtomicInteger();
    private String cleanerJavaScript = "";
    private String bookmarkTitleJavaScript = "";
    // A bookmark is committed only when a meaningful title is available.
    private int bookmarkLookupGeneration;
    private String pendingBookmarkUrl;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        settings = getSharedPreferences(PREF, MODE_PRIVATE);
        library = new LibraryStore(this);
        filterOn = settings.getBoolean(KEY_FILTER, true);
        hidePromotions = settings.getBoolean(KEY_HIDE, true);
        autoSkip = settings.getBoolean(KEY_SKIP, true);
        backgroundAudio = settings.getBoolean(KEY_BACKGROUND, true);
        autoPip = settings.getBoolean(KEY_AUTO_PIP, false);
        microphoneEnabled = settings.getBoolean(KEY_MICROPHONE, true);
        registerAudioReceiver();
        try { cleanerJavaScript = loadAsset("cleaner.js"); }
        catch (Exception e) { cleanerJavaScript = ""; }
        try { bookmarkTitleJavaScript = loadAsset("bookmark-title.js"); }
        catch (Exception e) { bookmarkTitleJavaScript = ""; }
        try { youtubeMicBridgeJavaScript = loadAsset("youtube-mic-bridge.js"); }
        catch (Exception e) { youtubeMicBridgeJavaScript = ""; }
        try { youtubePlaylistJavaScript = loadAsset("youtube-playlist-context.js"); }
        catch (Exception e) { youtubePlaylistJavaScript = ""; }
        setWindowColors();
        buildUi();
        nativeAudioActive = BackgroundAudioService.hasNativeAudioSession();
        updateReturnToVideoButton();
        buildBrowser();
        registerSystemBack();
        if (state != null && state.getBundle("web_state") != null) {
            webView.restoreState(state.getBundle("web_state"));
        } else {
            navigateInitial(getIntent());
        }
        if (getIntent()!=null && getIntent().getBooleanExtra(EXTRA_OPEN_DIAGNOSTICS,false))
            audioHandler.post(this::quickShareDiagnostics);
        if (getIntent()!=null && YouTubeStreamResolver.isSupportedVideoUrl(
                getIntent().getStringExtra(EXTRA_NATIVE_VIDEO_RETURN_URL)))
            handleExplicitVideoReturn(getIntent());
        audioHandler.postDelayed(playbackPoll, 500);
        if (!settings.getBoolean("intro_seen", false)) showIntro();
        else if (!settings.getBoolean(KEY_FIRST_RUN_PERMISSIONS, false))
            audioHandler.postDelayed(this::showPermissionSetup, 600);
    }

    private void setWindowColors() {
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        // The YouTube page already contains its own search.  The former 56dp
        // native search row was duplicate UI and is intentionally removed.

        toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        toolsScroll.setBackgroundColor(COLOR_PANEL);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(6), 0, dp(6), 0);
        toolsScroll.addView(actions, new HorizontalScrollView.LayoutParams(-2, dp(45)));
        // Keep the extra voice button on the far-right edge of the real screen,
        // independent from the horizontally scrolling navigation/action buttons.
        toolbarRow = new LinearLayout(this);
        toolbarRow.setOrientation(LinearLayout.HORIZONTAL);
        toolbarRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbarRow.setBackgroundColor(COLOR_PANEL);
        toolbarRow.addView(toolsScroll, new LinearLayout.LayoutParams(0, dp(45), 1f));
        Button quickDiagnostics = toolbarButton("⚠", "한 번 눌러 진단 ZIP 저장·공유",
                v -> quickShareDiagnostics());
        toolbarRow.addView(quickDiagnostics, new LinearLayout.LayoutParams(dp(43), dp(45)));
        pipActionButton = new PipIconButton(this);
        pipActionButton.setActionMode(settings.getInt("pip_action_mode", 1));
        // Tap: enter PiP exactly as before; long press: switch seek/track controls
        // without visiting the settings screen. No changes to actual playback.
        pipActionButton.setOnClickListener(v -> openNativeVideo(true));
        pipActionButton.setOnLongClickListener(v -> {
            togglePipControlMode();
            return true;
        });
        toolbarRow.addView(pipActionButton, new LinearLayout.LayoutParams(dp(44), dp(45)));
        Button separateVoiceButton = toolbarButton("🎙", "유튜브 음성 검색",
                v -> startVoiceSearch());
        toolbarRow.addView(separateVoiceButton, new LinearLayout.LayoutParams(-2, dp(45)));
        page.addView(toolbarRow, new LinearLayout.LayoutParams(-1, dp(45)));

        Button backButton = addAction(actions, "◀", "뒤로 (길게 누르면 앱 종료)", v -> back());
        backButton.setOnLongClickListener(v -> { showExitConfirmation(); return true; });
        addAction(actions, "▶", "앞으로", v -> { if (webView.canGoForward()) webView.goForward(); });
        addAction(actions, "⌂", "홈", v -> webView.loadUrl(HOME));
        addAction(actions, "↻", "새로고침", v -> webView.reload());
        bookmarkButton = addAction(actions, "☆", "즐겨찾기 추가 또는 제거", v -> toggleBookmark());
        addAction(actions, "라이브러리", "나중에 보기와 내 음악 플레이리스트", v -> showLibrary());
        addAction(actions, "기록", "시청 기록", v -> showEntries(true));
        returnToVideoButton = addAction(actions, "영상 복귀", "독립 오디오에서 영상 재생으로 복귀", v -> returnToVideo());
        updateReturnToVideoButton();
        addAction(actions, "다운로드", "권한 있는 미디어 파일 다운로드 및 관리", v -> showDownloadCenter());
        addAction(actions, "설정", "음악·PIP·권한·캐시·백업 등 통합 설정", v -> showSettings());
        addAction(actions, "앱 종료", "확인 후 음악과 영상을 중단하고 앱 종료", v -> showExitConfirmation());

        statusStrip = new LinearLayout(this);
        statusStrip.setGravity(Gravity.CENTER_VERTICAL);
        statusStrip.setPadding(dp(12), 0, dp(10), 0);
        statusStrip.setBackgroundColor(COLOR_BG);
        page.addView(statusStrip, new LinearLayout.LayoutParams(-1, dp(26)));
        status = new TextView(this);
        status.setTextColor(Color.rgb(160, 178, 195));
        status.setTextSize(11);
        status.setSingleLine(true);
        statusStrip.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        loading = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loading.setMax(100);
        loading.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_ACCENT));
        statusStrip.addView(loading, new LinearLayout.LayoutParams(dp(65), dp(4)));

        browserContainer = new FrameLayout(this);
        page.addView(browserContainer, new LinearLayout.LayoutParams(-1, 0, 1f));
        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets area = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(area.left, area.top, area.right, area.bottom);
                return insets;
            });
            root.requestApplyInsets();
        }
        updateStatus();
    }

    private Button addAction(LinearLayout container, String label, String description, View.OnClickListener action) {
        Button btn = toolbarButton(label, description, action);
        container.addView(btn, new LinearLayout.LayoutParams(-2, dp(44)));
        return btn;
    }

    private Button toolbarButton(String label, String description, View.OnClickListener action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setTextColor(COLOR_WHITE);
        btn.setTextSize(13);
        btn.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        btn.setPadding(dp(8), 0, dp(8), 0);
        btn.setMinWidth(0);
        btn.setMinimumWidth(0);
        btn.setMinHeight(0);
        btn.setMinimumHeight(0);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(COLOR_PANEL));
        btn.setContentDescription(description);
        btn.setOnClickListener(action);
        return btn;
    }

    private void buildBrowser() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browserContainer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Notification Play and one-shot background recovery are not DOM user gestures.
        // The app only attempts recovery after an already-playing video was user-started.
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (filterOn && AdBlockEngine.shouldBlock(request.getUrl().toString(), request.isForMainFrame())) {
                    int count = blockedCount.incrementAndGet();
                    if (count <= 10 || count % 10 == 0) runOnUiThread(MainActivity.this::updateStatus);
                    WebResourceResponse empty = new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                    empty.setStatusCodeAndReasonPhrase(204, "No Content");
                    return empty;
                }
                return null;
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if (isInternal(url)) return false;
                if ("https".equalsIgnoreCase(url.getScheme()) || "http".equalsIgnoreCase(url.getScheme())) {
                    openExternal(url);
                } else {
                    toast("외부 앱으로 연결되는 링크는 지원하지 않습니다.");
                }
                return true;
            }

            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (lastKnownPlaying) reportPlayerState(false, lastMediaTitle);
                loading.setVisibility(View.VISIBLE);
                loading.setProgress(5);
                updateStatus();
            }

            @Override public void onPageFinished(WebView view, String url) {
                loading.setVisibility(View.GONE);
                if (nativeBrowserSync && nativeAudioActive) {
                    view.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()",null);
                    // Allow intentional foreground playback after page synchronization.
                    if (nativePendingReturnUrl == null) audioHandler.postDelayed(() -> nativeBrowserSync=false, 2000L);
                }
                if (nativePendingReturnUrl != null &&
                        YouTubeStreamResolver.canonicalMediaKey(nativePendingReturnUrl).equals(
                        YouTubeStreamResolver.canonicalMediaKey(url))) {
                    nativePendingReturnUrl = null;
                    nativeBrowserSync = false;
                    audioHandler.postDelayed(MainActivity.this::requestNativeReturnPosition,750L);
                }
                if (LibraryStore.isYoutubeUrl(url)) {
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                    injectCleaner();
                    injectYouTubeMicBridge();
                    view.postDelayed(MainActivity.this::collectYoutubePlaylistTracks, 700L);
                    view.postDelayed(MainActivity.this::collectYoutubePlaylistTracks, 2200L);
                }
                updateBookmark();
                scheduleSavedTitleRefresh();
                updateStatus();
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                super.doUpdateVisitedHistory(view, url, isReload);
                if (!isReload && LibraryStore.isYoutubeUrl(url))
                    library.addHistory(BookmarkTitleResolver.resolve(null, null, url), url);
                // YouTube is an SPA: navigating to another video may not call onPageFinished.
                if (LibraryStore.isYoutubeUrl(url) && webView != null)
                    webView.postDelayed(() -> {
                        if (webView != null && LibraryStore.isYoutubeUrl(webView.getUrl())) {
                            injectCleaner();
                            collectYoutubePlaylistTracks();
                        }
                    }, 250L);
                updateBookmark();
                scheduleSavedTitleRefresh();
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    loading.setVisibility(View.GONE);
                    toast("페이지 연결 실패: 인터넷 상태와 Android WebView를 확인하세요.");
                }
            }

            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (view == webView) {
                    browserContainer.removeView(view);
                    view.destroy();
                    webView = null;
                    toast("웹 엔진이 종료되어 화면을 다시 엽니다.");
                    recreate();
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                loading.setProgress(progress);
                loading.setVisibility(progress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (LibraryStore.isYoutubeUrl(view.getUrl())) {
                    library.addHistory(BookmarkTitleResolver.resolve(title, null, view.getUrl()), view.getUrl());
                    scheduleSavedTitleRefresh();
                }
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            // Some YouTube pages show "브라우저 설정에서 마이크를 허용" instead
            // of requesting getUserMedia in Android WebView. An injected listener
            // on the PAGE'S voice-search control bridges that user click to the
            // Android speech recognizer; never allow untrusted origins to use it.
            @Override public boolean onJsPrompt(WebView view, String url, String message,
                                                String defaultValue, JsPromptResult result) {
                if (VoicePermissionPolicy.isTrustedOrigin(url) &&
                        "MHT_AD_DETECTED_0120".equals(message)) {
                    result.confirm("");
                    detectedAds.incrementAndGet();
                    PlaybackDiagnostics.event(MainActivity.this,playbackTraceSession,
                            "VIDEO_AD_DETECTED", "DOM_BEST_EFFORT",null);
                    updateStatus();
                    return true;
                }
                if (VoicePermissionPolicy.isTrustedOrigin(url) &&
                        "MHT_AD_NO_LONGER_VISIBLE_0121".equals(message)) {
                    result.confirm("");
                    PlaybackDiagnostics.event(MainActivity.this,playbackTraceSession,
                            "VIDEO_AD_NO_LONGER_VISIBLE", "NOT_VERIFIED_AS_SKIP",null);
                    return true;
                }
                if (VoicePermissionPolicy.isTrustedOrigin(url) &&
                        "MHT_AD_SKIP_CLICKED_0120".equals(message)) {
                    result.confirm("");
                    skippedAds.incrementAndGet();
                    PlaybackDiagnostics.event(MainActivity.this,playbackTraceSession,
                            "AD_SKIP_ATTEMPT", "CLICK_NOT_VERIFIED",null);
                    updateStatus();return true;
                }
                if ("MHT_YOUTUBE_VOICE_SEARCH_0111".equals(message) &&
                        microphoneEnabled && VoicePermissionPolicy.isTrustedOrigin(url)) {
                    result.confirm("");
                    audioHandler.post(MainActivity.this::startVoiceSearch);
                    return true;
                }
                return super.onJsPrompt(view, url, message, defaultValue, result);
            }

            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (pendingWebMicrophoneRequest == request) pendingWebMicrophoneRequest = null;
                });
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view;
                customCallback = callback;
                priorOrientation = getRequestedOrientation();
                page.setVisibility(View.GONE);
                fullscreenContainer.removeAllViews();
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenContainer.setVisibility(View.VISIBLE);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        View.SYSTEM_UI_FLAG_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() { hideCustomView(); }
        });
    }

    private void hideCustomView() {
        if (customView == null) return;
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(priorOrientation);
        page.setVisibility(View.VISIBLE);
        if (root != null) root.requestApplyInsets();
    }

    private static boolean isInternal(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return AdBlockEngine.isHostOrSubdomain(host, "youtube.com")
                || AdBlockEngine.isHostOrSubdomain(host, "youtu.be")
                || AdBlockEngine.isHostOrSubdomain(host, "youtube-nocookie.com");
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException ex) { toast("연결할 브라우저가 없습니다."); }
    }

    private void navigateInitial(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        webView.loadUrl(uri != null && isInternal(uri) ? uri.toString() : HOME);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // A media notification opens this Activity with NO URL. Do not navigate to HOME:
        // doing so destroys the current video position and makes PiP restoration restart.
        if (intent != null && intent.getBooleanExtra(EXTRA_OPEN_DIAGNOSTICS,false)) {
            quickShareDiagnostics();return;
        }
        if (intent != null && YouTubeStreamResolver.isSupportedVideoUrl(
                intent.getStringExtra(EXTRA_NATIVE_VIDEO_RETURN_URL))) {
            handleExplicitVideoReturn(intent);
            return;
        }
        Uri link = intent == null ? null : intent.getData();
        if (webView != null && link != null && isInternal(link) &&
                !link.toString().equals(webView.getUrl())) webView.loadUrl(link.toString());
    }

    /** Request microphone access only for HTTPS YouTube origins and audio only.
     * NEVER grant all requested WebView resources; camera and other resources stay denied.
     */
    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) return;
        if (!microphoneEnabled ||
                !VoicePermissionPolicy.isTrustedOrigin(String.valueOf(request.getOrigin())) ||
                !VoicePermissionPolicy.isAudioOnly(request.getResources(),
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
            request.deny();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            return;
        }
        // The Android permission prompt is shown only after the web page asks for audio.
        if (pendingWebMicrophoneRequest != null && pendingWebMicrophoneRequest != request)
            pendingWebMicrophoneRequest.deny();
        pendingWebMicrophoneRequest = request;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
    }

    private void requestMicForSettings() {
        if (!microphoneEnabled) {
            toast("먼저 설정에서 유튜브 음성 검색 마이크 사용을 켜 주세요.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            toast("마이크 권한이 허용되어 있습니다.");
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
        }
    }

    /** Replaces only the YouTube *page's own* voice-icon click when WebView
     * rejects web microphone access. A separate toolbar mic also remains.
     * The injected script uses a trusted-origin prompt, not JavascriptInterface.
     */
    private void injectYouTubeMicBridge() {
        if (!microphoneEnabled || webView == null || youtubeMicBridgeJavaScript.isEmpty()) return;
        if (!VoicePermissionPolicy.isTrustedOrigin(webView.getUrl())) return;
        webView.evaluateJavascript(youtubeMicBridgeJavaScript, null);
    }

    // Native recognizer: invoked from either the page mic icon or separate toolbar mic.
    private void startVoiceSearch() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastVoiceBridgeRequestAt < 850L) return;
        lastVoiceBridgeRequestAt = now;
        if (!microphoneEnabled) {
            toast("설정에서 '유튜브 음성 검색 마이크 사용'을 켜 주세요.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            speechAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
            return;
        }
        launchVoiceRecognizer();
    }

    private void launchVoiceRecognizer() {
        Intent voice = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        voice.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        voice.putExtra(RecognizerIntent.EXTRA_PROMPT, "유튜브에서 무엇을 검색할까요?");
        try {
            startActivityForResult(voice, REQUEST_SPEECH);
        } catch (ActivityNotFoundException error) {
            toast("음성 인식 앱이 없습니다. 유튜브 화면의 검색을 이용해 주세요.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LIBRARY_EXPORT && resultCode == RESULT_OK && data!=null && data.getData()!=null) {
            try (OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if (out==null) throw new IOException("출력 파일 없음");
                JSONObject backup=new JSONObject();
                backup.put("app","MideumHanaTube");backup.put("version",1);
                backup.put("library",library.exportLibrary());
                JSONObject prefs=new JSONObject();
                for(String key : new String[]{KEY_FILTER,KEY_HIDE,KEY_SKIP,KEY_BACKGROUND,KEY_AUTO_PIP,KEY_MICROPHONE})
                    prefs.put(key,settings.getBoolean(key,true));
                backup.put("settings",prefs);
                String last=getSharedPreferences("mht_last_music_resume",MODE_PRIVATE).getString("last","");
                if (last!=null && !last.isEmpty()) backup.put("lastPlayback",new JSONObject(last));
                JSONObject queueOptions=new JSONObject();
                SharedPreferences qp=getSharedPreferences("mht_queue_controls",MODE_PRIVATE);
                queueOptions.put("repeat",qp.getInt("repeat",PlaybackQueue.OFF));
                queueOptions.put("shuffle",qp.getBoolean("shuffle",false));
                backup.put("queueOptions",queueOptions);
                out.write(backup.toString(2).getBytes(StandardCharsets.UTF_8));
                toast("백업 저장 완료 · 계정·쿠키는 포함하지 않았습니다.");
            } catch(Exception e){toast("백업 저장 실패");}return;
        }
        if (requestCode == REQUEST_LIBRARY_IMPORT && resultCode == RESULT_OK && data!=null && data.getData()!=null) {
            try(java.io.InputStream in=getContentResolver().openInputStream(data.getData())) {
                if(in==null)throw new IOException("입력 파일 없음");
                ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] chunk=new byte[4096];int n;
                while((n=in.read(chunk))!=-1){buf.write(chunk,0,n);if(buf.size()>1024*1024)throw new IOException("용량 초과");}
                JSONObject backup=new JSONObject(buf.toString(StandardCharsets.UTF_8.name()));
                if(!"MideumHanaTube".equals(backup.optString("app")) ||
                        !library.importLibrary(backup.optJSONObject("library"))) throw new IOException("형식 오류");
                JSONObject prefs=backup.optJSONObject("settings");
                if(prefs!=null){SharedPreferences.Editor ed=settings.edit();
                    for(String key:new String[]{KEY_FILTER,KEY_HIDE,KEY_SKIP,KEY_BACKGROUND,KEY_AUTO_PIP,KEY_MICROPHONE})
                        if(prefs.has(key))ed.putBoolean(key,prefs.optBoolean(key,true));ed.apply();}
                JSONObject last=backup.optJSONObject("lastPlayback");
                if(last!=null && YouTubeStreamResolver.isSupportedVideoUrl(last.optString("url",""))) {
                    // User explicitly chose this backup; never restore stream tokens.
                    getSharedPreferences("mht_last_music_resume",MODE_PRIVATE).edit()
                            .putString("last",last.toString()).apply();
                }
                JSONObject qp=backup.optJSONObject("queueOptions");
                if(qp!=null)getSharedPreferences("mht_queue_controls",MODE_PRIVATE).edit()
                        .putInt("repeat",Math.max(0,Math.min(2,qp.optInt("repeat",0))))
                        .putBoolean("shuffle",qp.optBoolean("shuffle",false)).apply();
                toast("백업 복원 완료 · 설정 변경은 앱을 다시 열면 적용됩니다.");updateBookmark();
            } catch(Exception e){toast("백업 복원 실패: 파일 형식을 확인해 주세요.");}return;
        }
        if (requestCode == REQUEST_DIAGNOSTIC_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("진단 파일을 열 수 없음");
                    PlaybackDiagnostics.writeZip(this, out);
                    toast("재생 진단 ZIP 저장 완료");
                } catch (IOException error) { toast("진단 저장 실패: 저장 위치를 확인해 주세요."); }
            }
            return;
        }
        if (requestCode != REQUEST_SPEECH || resultCode != RESULT_OK || data == null) return;
        ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (results == null || results.isEmpty()) return;
        String words = results.get(0) == null ? "" : results.get(0).trim();
        if (!words.isEmpty() && webView != null) {
            webView.loadUrl("https://m.youtube.com/results?search_query=" + Uri.encode(words));
            toast("음성 검색: " + words);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_FIRST_NOTIFICATION) {requestFirstMicPermission();return;}
        if (requestCode == REQUEST_FIRST_MICROPHONE) {firstRunPermissionsPending=false;return;}
        if (requestCode != REQUEST_MICROPHONE) return;
        boolean granted = grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;
        PermissionRequest webRequest = pendingWebMicrophoneRequest;
        pendingWebMicrophoneRequest = null;
        if (webRequest != null) {
            if (granted && microphoneEnabled &&
                    VoicePermissionPolicy.isTrustedOrigin(String.valueOf(webRequest.getOrigin())))
                webRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            else webRequest.deny();
        }
        boolean search = speechAfterPermission;
        speechAfterPermission = false;
        if (search && granted && microphoneEnabled) launchVoiceRecognizer();
        else if (!granted) toast("마이크 권한이 거부되었습니다. Android 앱 설정에서 허용할 수 있습니다.");
    }

    /**
     * Save the real current title, never a synthetic video ID.
     * SPA pages may publish their title well after the navigation callbacks fire.
     * DOM and YouTube oEmbed lookup race; the first verified title wins.
     */
    private void toggleBookmark() {
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) {
            toast("유튜브 페이지를 열어 주세요."); return;
        }
        final String url = webView.getUrl();
        List<String> folders = library.musicPlaylistNames();
        ArrayList<String> options = new ArrayList<>();
        options.add("☆ 나중에 보기 / 구독처럼 보관");
        for (String folder : folders) options.add("♫ " + folder);
        options.add("＋ 새 음악 플레이리스트 만들기");
        if (library.isSavedAnywhere(url)) options.add("저장 위치별 삭제 / 관리");
        new AlertDialog.Builder(this).setTitle("어디에 저장할까요?")
                .setItems(options.toArray(new String[0]), (dialog, selected) -> {
                    if (selected == 0) { pendingBookmarkCollection = "watch"; saveBookmarkWithTitle(url); }
                    else if (selected <= folders.size()) {
                        pendingBookmarkCollection = "music";
                        pendingBookmarkPlaylist = folders.get(selected-1);
                        saveBookmarkWithTitle(url);
                    } else if (selected == folders.size()+1) {
                        promptCreatePlaylist(name -> {
                            pendingBookmarkCollection = "music";
                            pendingBookmarkPlaylist = name;
                            saveBookmarkWithTitle(url);
                        });
                    } else showSavedLocations(url);
                }).setNegativeButton("취소",null).show();
    }
    private void commitBookmark(String title, String url) {
        if ("music".equals(pendingBookmarkCollection)) {
            library.saveMusicTrack(pendingBookmarkPlaylist, title, url);
            toast("음악 저장: " + pendingBookmarkPlaylist);
        } else {
            library.addBookmark(title, url);
            toast("나중에 보기 저장: " + title);
        }
        updateBookmark();
    }
    private void saveBookmarkWithTitle(String url) {
        if (url.equals(pendingBookmarkUrl)) {
            toast("영상 제목을 확인하는 중입니다.");
            return;
        }
        // A previously visited entry may already have the correct title.
        for (LibraryStore.Entry entry : library.history()) {
            if (url.equals(entry.url) && BookmarkSavePolicy.isActualTitle(entry.title, url)) {
                commitBookmark(entry.title, url);
                return;
            }
        }
        // Home and search have stable, meaningful names without waiting for video metadata.
        String simpleName = BookmarkSavePolicy.simplePageName(url);
        if (simpleName != null) {
            commitBookmark(simpleName, url);
            return;
        }
        final int requestId = ++bookmarkLookupGeneration;
        pendingBookmarkUrl = url;
        toast("즐겨찾기 제목을 확인하고 있습니다.");
        requestTitleForBookmark(url, requestId, 0);

        // oEmbed is a complementary, public YouTube title endpoint; it is never
        // trusted as HTML and never receives unrelated query parameters.
        if (YouTubeOEmbedUrl.forSource(url) != null) {
            new Thread(() -> {
                String title = YouTubeOEmbedTitle.fetch(url);
                runOnUiThread(() -> completeBookmarkWithTitle(url, requestId, title));
            }, "bookmark-metadata").start();
        }
        audioHandler.postDelayed(() -> {
            if (!isActiveBookmarkRequest(url, requestId)) return;
            pendingBookmarkUrl = null;
            showBookmarkTitleInput(url);
        }, 8500L);
    }

    private boolean isActiveBookmarkRequest(String url, int requestId) {
        return requestId == bookmarkLookupGeneration && url.equals(pendingBookmarkUrl)
                && webView != null && url.equals(webView.getUrl());
    }

    private void completeBookmarkWithTitle(String url, int requestId, String title) {
        if (!isActiveBookmarkRequest(url, requestId)) return;
        String resolved = BookmarkTitleResolver.resolve(title, null, url);
        if (!BookmarkSavePolicy.isActualTitle(resolved, url)) return;
        pendingBookmarkUrl = null;
        commitBookmark(resolved, url);
        library.repairGenericTitles(url, resolved);
    }

    private void requestTitleForBookmark(String url, int requestId, int attempt) {
        if (!isActiveBookmarkRequest(url, requestId)) return;
        extractLiveTitle(url, title -> {
            if (!isActiveBookmarkRequest(url, requestId)) return;
            if (BookmarkSavePolicy.isActualTitle(title, url)) {
                completeBookmarkWithTitle(url, requestId, title);
            } else if (attempt < 12) {
                audioHandler.postDelayed(() -> requestTitleForBookmark(url, requestId, attempt + 1), 550L);
            }
        });
    }

    /** On source pages with unavailable metadata, never silently save an ID. */
    private void showBookmarkTitleInput(String url) {
        if (webView == null || !url.equals(webView.getUrl())) return;
        // Search and home URLs have meaningful names even without a video title.
        String meaningfulFallback = BookmarkSavePolicy.simplePageName(url);
        if (meaningfulFallback != null) {
            commitBookmark(meaningfulFallback, url);
            return;
        }
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("영상 또는 채널 이름을 입력하세요");
        FrameLayout wrapper = new FrameLayout(this);
        wrapper.setPadding(dp(18), dp(10), dp(18), dp(10));
        wrapper.addView(input, new FrameLayout.LayoutParams(-1, -2));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 이름 확인")
                .setMessage("유튜브에서 제목을 가져오지 못했습니다. 영상 ID 대신 이름을 직접 입력해 저장할 수 있어요.")
                .setView(wrapper)
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(clicked -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) { input.setError("이름을 입력해 주세요."); return; }
                    if (webView == null || !url.equals(webView.getUrl())) {
                        toast("페이지가 변경되어 저장하지 않았습니다.");
                        dialog.dismiss();
                        return;
                    }
                    commitBookmark(name, url);
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private interface TitleResult { void resolved(String title); }

    private void extractLiveTitle(String expectedUrl, TitleResult callback) {
        if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
        if (bookmarkTitleJavaScript.isEmpty()) {
            callback.resolved(BookmarkTitleResolver.fallbackForUrl(expectedUrl));
            return;
        }
        webView.evaluateJavascript(bookmarkTitleJavaScript, json -> {
            if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
            String metadata = null;
            // Do not trust WebView.getTitle(): it can still refer to the previous SPA video.
            String pageTitle = "YouTube";
            try {
                Object unwrapped = new JSONTokener(json).nextValue();
                if (unwrapped instanceof String) {
                    JSONObject parsed = new JSONObject((String) unwrapped);
                    if (!expectedUrl.equals(parsed.optString("url", ""))) return;
                    metadata = parsed.optString("title", "");
                    pageTitle = parsed.optString("pageTitle", "YouTube");
                }
            } catch (Exception ignored) { }
            callback.resolved(BookmarkTitleResolver.resolve(metadata, pageTitle, expectedUrl));
        });
    }

    private void requestPageTitle(String expectedUrl, int retry, TitleResult callback) {
        extractLiveTitle(expectedUrl, resolved -> {
            if (BookmarkTitleResolver.isFallback(resolved) && retry < 2) {
                audioHandler.postDelayed(() -> requestPageTitle(expectedUrl, retry + 1, callback),
                        retry == 0 ? 450L : 900L);
                return;
            }
            library.repairGenericTitles(expectedUrl, resolved);
            if (callback != null) callback.resolved(resolved);
        });
    }

    private void scheduleSavedTitleRefresh() {
        audioHandler.removeCallbacks(refreshSavedTitle);
        audioHandler.postDelayed(refreshSavedTitle, 650);
    }

    private void updateBookmark() {
        if (bookmarkButton != null && webView != null)
            bookmarkButton.setText(library.isSavedAnywhere(webView.getUrl()) ? "★" : "☆");
    }

    /** The single library contains watch-later and user-managed music playlists. */
    private void showLibrary() {
        List<String> names=library.musicPlaylistNames();
        ArrayList<String> actions=new ArrayList<>();
        actions.add("☆ 나중에 보기 / 구독 대신 보관");
        for(String name:names)actions.add("♫ "+name+" ("+library.musicTracks(name).size()+"곡)");
        actions.add("＋ 새 음악 플레이리스트");
        actions.add("↻ 현재 화면 영상으로 대기열 만들기");
        new AlertDialog.Builder(this).setTitle("내 라이브러리")
                .setItems(actions.toArray(new String[0]),(d,i)->{
                    if(i==0)showEntries(false);
                    else if(i<=names.size())showMusicPlaylist(names.get(i-1));
                    else if(i==names.size()+1)promptCreatePlaylist(this::showMusicPlaylist);
                    else startVisiblePagePlaylist();
                }).setNegativeButton("닫기",null).show();
    }
    private void showMusicPlaylist(String name) {
        final String[] actions={"모든 곡 순서대로 재생", "여러 곡 선택해서 재생",
                "곡 순서 관리 / 삭제", "플레이리스트 이름 변경", "플레이리스트 삭제"};
        new AlertDialog.Builder(this).setTitle("♫ "+name)
                .setItems(actions,(d,i)->{
                    if(i==0){List<LibraryStore.Entry> entries=library.musicTracks(name);
                        if(entries.isEmpty()){toast("저장된 음악이 없습니다.");return;}
                        startQueue(entries,0);
                    }else if(i==1)selectTracksToPlay(name);
                    else if(i==2)manageMusicTracks(name);
                    else if(i==3)renameMusicPlaylist(name);
                    else if(i==4) {
                        if(LibraryStore.DEFAULT_MUSIC.equals(name)){toast("기본 내 음악 목록은 삭제할 수 없습니다.");return;}
                        new AlertDialog.Builder(this).setTitle("플레이리스트 삭제")
                            .setMessage(""+name+"와 이 목록의 음악을 삭제할까요? 나중에 보기에는 영향을 주지 않습니다.")
                            .setNegativeButton("취소",null).setPositiveButton("삭제",(dd,w)->{
                                library.removeMusicPlaylist(name);toast("플레이리스트 삭제됨");
                            }).show();
                    }
                }).setNegativeButton("닫기",null).show();
    }
    private void selectTracksToPlay(String name) {
        List<LibraryStore.Entry> all=library.musicTracks(name);
        if(all.isEmpty()){toast("저장된 음악이 없습니다.");return;}
        String[] labels=new String[all.size()];boolean[] picks=new boolean[all.size()];
        for(int i=0;i<all.size();i++)labels[i]=all.get(i).title;
        new AlertDialog.Builder(this).setTitle("재생할 곡 선택 (순서대로 재생)")
                .setMultiChoiceItems(labels,picks,(d,i,checked)->picks[i]=checked)
                .setPositiveButton("선택한 곡 재생",(d,i)->{
                    List<LibraryStore.Entry> selected=new ArrayList<>();
                    for(int j=0;j<all.size();j++)if(picks[j])selected.add(all.get(j));
                    if(selected.isEmpty()){toast("재생할 곡을 선택해 주세요.");return;}
                    startQueue(selected,0);
                }).setNegativeButton("취소",null).show();
    }
    private void manageMusicTracks(String name) {
        List<LibraryStore.Entry> all=library.musicTracks(name);
        if(all.isEmpty()){toast("저장된 음악이 없습니다.");return;}
        String[] names=new String[all.size()];
        for(int i=0;i<all.size();i++)names[i]=(i+1)+". "+all.get(i).title;
        new AlertDialog.Builder(this).setTitle("♫ "+name+" · 곡 관리")
                .setItems(names,(d,index)->showTrackActions(name,index))
                .setNegativeButton("닫기",null).show();
    }
    private void showTrackActions(String list,int index) {
        List<LibraryStore.Entry> items=library.musicTracks(list);
        if(index>=items.size())return;
        new AlertDialog.Builder(this).setTitle(items.get(index).title)
                .setItems(new String[]{"이 곡 먼저 재생","맨 위로 이동","한 칸 위로","한 칸 아래로","목록에서 제거"},(d,which)->{
                    if(which==0){startQueue(items,index);return;}
                    if(which==4)items.remove(index);
                    else {int target=which==1?0:which==2?Math.max(0,index-1):Math.min(items.size()-1,index+1);
                        java.util.Collections.swap(items,index,target);}
                    library.saveMusicTracks(list,items);showMusicPlaylist(list);
                }).setNegativeButton("취소",null).show();
    }
    private void renameMusicPlaylist(String oldName) {
        if(LibraryStore.DEFAULT_MUSIC.equals(oldName)){toast("기본 내 음악 이름은 변경할 수 없습니다.");return;}
        EditText edit=new EditText(this);edit.setSingleLine(true);edit.setText(oldName);
        FrameLayout content=new FrameLayout(this);content.setPadding(dp(18),dp(8),dp(18),dp(8));content.addView(edit);
        new AlertDialog.Builder(this).setTitle("플레이리스트 이름 변경")
                .setView(content).setNegativeButton("취소",null)
                .setPositiveButton("변경",(d,w)->{
                    if(library.renameMusicPlaylist(oldName,edit.getText().toString().trim()))toast("이름 변경 완료");
                    else toast("이름 변경 실패 · 중복 여부 확인");
                }).show();
    }

    private void showEntries(boolean history) {
        List<LibraryStore.Entry> entries = history ? library.history() : library.bookmarks();
        String title = history ? "최근 방문 기록" : "즐겨찾기";
        if (entries.isEmpty()) { toast(title + "이 없습니다."); return; }
        String[] titles = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) titles[i] = entries.get(i).title;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(history ? title : "즐겨찾기 · 길게 눌러 이름 변경")
                .setItems(titles, (d, index) -> webView.loadUrl(entries.get(index).url))
                .setNegativeButton("닫기", null)
                .setNeutralButton("전체 삭제", (d, which) -> new AlertDialog.Builder(this)
                        .setTitle(title + " 전체 삭제")
                        .setMessage("기기에 저장된 항목을 모두 삭제할까요?")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제", (confirmation, w) -> {
                            if (history) library.clearHistory(); else library.clearBookmarks();
                            updateBookmark();
                            toast("삭제했습니다.");
                        }).show())
                .create();
        dialog.setOnShowListener(ignored -> {
            if (history) return;
            dialog.getListView().setOnItemLongClickListener((parent, view, position, id) -> {
                dialog.dismiss();
                renameBookmark(entries.get(position));
                return true;
            });
        });
        dialog.show();
    }

    private void renameBookmark(LibraryStore.Entry entry) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(entry.title);
        input.selectAll();
        int pad = dp(18);
        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(pad, dp(8), pad, dp(8));
        frame.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 이름 변경")
                .setView(frame)
                .setNegativeButton("취소", null)
                .setNeutralButton("삭제", (d, which) -> {
                    library.removeBookmark(entry.url);
                    updateBookmark();
                    toast("즐겨찾기를 삭제했습니다.");
                })
                .setPositiveButton("저장", (d, which) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) { toast("이름을 입력해 주세요."); return; }
                    library.renameBookmark(entry.url, name);
                    toast("이름을 변경했습니다.");
                })
                .show();
    }

    /** One top-level settings menu; no duplicated 'music settings' surface. */
    private void showSettings() {
        final String[] items = {"재생 · PIP · 광고 · 마이크 설정", "권한 상태 / 다시 요청",
                "백그라운드 재생 진단", "웹 캐시 삭제", "즐겨찾기·음악·설정 백업",
                "백업 가져오기", "취침 타이머 (15/30/60분)", "기기·WebView 호환성 정보",
                "시스템 작은 화면(PIP) 허용 설정", "PIP 버튼 선택 (곡 이동 / 10초 탐색)",
                "독립 영상 화질 선택", "다운로드 관리 (권한 있는 파일)"};
        new AlertDialog.Builder(this).setTitle("믿음하나튜브 설정")
                .setItems(items, (d,index) -> {
                    switch(index) {
                        case 0: showPlaybackSettings(); break;
                        case 1: showPermissionSetup(); break;
                        case 2: showAudioDiagnostics(); break;
                        case 3: showCacheClearConfirmation(); break;
                        case 4: exportLibraryBackup(); break;
                        case 5: importLibraryBackup(); break;
                        case 6: showSleepTimer(); break;
                        case 7: showDeviceDetails(); break;
                        case 8: openPipSettings(); break;
                        case 9: showPipControlSettings(); break;
                        case 10: showNativeQualitySettings(); break;
                        case 11: showDownloadCenter(); break;
                        default: break;
                    }
                }).setNegativeButton("닫기",null).show();
    }
    /** Only changes the resolution cap used by the independent native player.
     * YouTube WebView-selected quality is not accessible from this app. */
    private void showNativeQualitySettings() {
        final int[] caps = {480, 720, 1080};
        final String[] names = {"데이터 절약 · 최대 480p", "균형 · 최대 720p (기본)",
                "고화질 · 최대 1080p (데이터 사용 증가)"};
        int current = settings.getInt("native_video_max_height",720);
        int selected = current == 480 ? 0 : current == 1080 ? 2 : 1;
        new AlertDialog.Builder(this).setTitle("독립 영상 · PIP 화질")
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    settings.edit().putInt("native_video_max_height",caps[which]).apply();
                    PlaybackDiagnostics.event(this,playbackTraceSession,"NATIVE_QUALITY_CAP",
                            "MAX_"+caps[which]+"P",null);
                    toast("다음 독립 영상부터 최대 " + caps[which] + "p 적용 · 웹 화질과는 별도입니다.");
                    dialog.dismiss();
                }).setNegativeButton("취소",null).show();
    }

    /** Android system downloader. We only accept direct HTTPS media files the
     * user is permitted to save; YouTube pages and extracted streams are excluded. */
    private void showDownloadCenter() {
        new AlertDialog.Builder(this).setTitle("믿음하나튜브 다운로드")
                .setItems(new String[]{"허용된 MP4·MP3·M4A·WebM 링크 저장",
                        "다운로드 상태 및 저장 파일", "시스템 다운로드 폴더 열기"},
                        (dialog, which) -> {
                            if (which == 0) showDirectMediaDownload();
                            else if (which == 1) showDownloadStatus();
                            else openSystemDownloads();
                        }).setNegativeButton("닫기",null).show();
    }

    private void showDirectMediaDownload() {
        LinearLayout fields = new LinearLayout(this);
        fields.setPadding(dp(18), dp(6), dp(18), dp(6));
        fields.setOrientation(LinearLayout.VERTICAL);
        TextView info = new TextView(this);
        info.setText("본인이 저장 권한을 가진 HTTPS 미디어 파일 링크만 지원합니다.\n"
                + "유튜브 영상 페이지의 MP4/MP3 추출·변환 기능은 아닙니다.");
        fields.addView(info);
        EditText link = new EditText(this);
        link.setSingleLine(true);
        link.setHint("https://example.com/my-video.mp4");
        link.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        fields.addView(link);
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("파일 이름 (선택)");
        fields.addView(name);
        new AlertDialog.Builder(this).setTitle("허용된 미디어 다운로드")
                .setView(fields)
                .setPositiveButton("저장 시작", (dialog, which) -> {
                    try {
                        long id = AuthorizedMediaDownloads.enqueue(this,
                                link.getText().toString(),name.getText().toString());
                        PlaybackDiagnostics.event(this,playbackTraceSession,
                                "AUTHORIZED_DOWNLOAD_ENQUEUED","DIRECT_HTTPS_MEDIA",null);
                        toast("다운로드 등록 완료 · 다운로드 메뉴에서 상태 확인");
                    } catch (Exception error) {
                        PlaybackDiagnostics.event(this,playbackTraceSession,
                                "AUTHORIZED_DOWNLOAD_REJECTED",error instanceof IllegalArgumentException
                                ? "UNSUPPORTED_LINK":"SYSTEM_DOWNLOAD_ERROR",null);
                        new AlertDialog.Builder(this).setTitle("다운로드 시작 실패")
                                .setMessage(error.getMessage() == null ? "지원되지 않는 파일 주소입니다." : error.getMessage())
                                .setPositiveButton("확인",null).show();
                    }
                }).setNegativeButton("취소",null).show();
    }

    private void showDownloadStatus() {
        List<AuthorizedMediaDownloads.Status> list = AuthorizedMediaDownloads.statuses(this);
        if (list.isEmpty()) { toast("등록된 다운로드가 없습니다."); return; }
        String[] labels = new String[list.size()];
        for (int i=0;i<list.size();i++) labels[i] = list.get(i).label();
        new AlertDialog.Builder(this).setTitle("다운로드 상태 · 최근 30개")
                .setItems(labels,(d,which) -> {
                    AuthorizedMediaDownloads.Status selected = list.get(which);
                    new AlertDialog.Builder(this).setTitle(selected.name)
                            .setItems(new String[]{"완료된 파일 열기", "다운로드 취소/삭제", "새로고침"},
                                    (dd,action) -> {
                                        if (action == 0) openDownloadedMedia(selected.id, selected.name);
                                        else if (action == 1) {
                                            new AlertDialog.Builder(this).setTitle("다운로드 삭제")
                                                .setMessage("진행 중인 다운로드는 중단되고 저장된 파일도 삭제될 수 있습니다.")
                                                .setPositiveButton("삭제",(x,y)->{
                                                    AuthorizedMediaDownloads.cancel(this,selected.id);
                                                    showDownloadStatus();
                                                }).setNegativeButton("취소",null).show();
                                        } else showDownloadStatus();
                                    }).setNegativeButton("닫기",null).show();
                }).setNegativeButton("닫기",null).show();
    }

    private void openDownloadedMedia(long id, String name) {
        Uri item = AuthorizedMediaDownloads.completedUri(this,id);
        if (item == null) { toast("아직 다운로드가 완료되지 않았습니다."); return; }
        String ext = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        String mime = ext.endsWith(".mp3") ? "audio/mpeg" : ext.endsWith(".m4a")
                ? "audio/mp4" : ext.endsWith(".webm") ? "video/webm" : "video/mp4";
        try {
            Intent view = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(item,mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(view,"저장한 미디어 열기"));
        } catch (RuntimeException ignored) { toast("이 파일을 열 앱이 없습니다."); }
    }
    private void openSystemDownloads() {
        try { startActivity(new Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS)); }
        catch (RuntimeException ignored) { toast("다운로드 앱을 열지 못했습니다. 다운로드 상태 메뉴를 이용해 주세요."); }
    }

    /** A one-gesture shortcut on the existing PiP icon. It intentionally does not
     * switch the live player's video, playlist or playback position. */
    private void togglePipControlMode() {
        int current = settings.getInt("pip_action_mode", 1);
        int next = PlaybackHandoff.toggledPipActionMode(current);
        applyPipControlMode(next, "TOOLBAR_LONG_PRESS");
    }
    private void applyPipControlMode(int choice, String origin) {
        int mode = PlaybackHandoff.normalizedPipActionMode(choice);
        settings.edit().putInt("pip_action_mode", mode).apply();
        if (pipActionButton != null) pipActionButton.setActionMode(mode);
        PlaybackDiagnostics.event(this, playbackTraceSession,
                "PIP_CONTROL_MODE_CHANGED", origin + "/" + (mode == 1 ? "SEEK_10S" : "QUEUE_PREV_NEXT"), null);
        toast("PIP 버튼: " + PlaybackHandoff.pipActionModeName(mode)
                + " · 아이콘 길게 누르면 다시 전환");
    }
    /** System PiP has no draggable seek bar. Offer genuinely working seek actions
     * without extra overlay permissions or replacing Android's PiP window. */
    private void showPipControlSettings() {
        final String[] choices = {"이전 영상 / 재생·정지 / 다음 영상", "10초 뒤로 / 재생·정지 / 10초 앞으로"};
        int current = PlaybackHandoff.normalizedPipActionMode(settings.getInt("pip_action_mode", 1));
        new AlertDialog.Builder(this).setTitle("PIP 작은 화면 버튼")
                .setSingleChoiceItems(choices, current, (dialog, index) -> {
                    dialog.dismiss();
                    applyPipControlMode(index, "SETTINGS");
                }).setNegativeButton("취소", null).show();
    }

    private void showPlaybackSettings() {
        String[] labels = {
                "외부 광고 요청 필터", "광고 화면 요소 숨기기", "건너뛰기 버튼 자동 클릭",
                "백그라운드 음악 사용", "홈 버튼 시 영상 PIP 우선 (실험)",
                "유튜브 음성 검색 마이크 사용"
        };
        boolean[] checks = {filterOn, hidePromotions, autoSkip, backgroundAudio, autoPip, microphoneEnabled};
        new AlertDialog.Builder(this).setTitle("재생 · PIP · 광고 · 마이크")
                .setMultiChoiceItems(labels, checks, (d,i,checked) -> checks[i]=checked)
                .setPositiveButton("저장", (d,i) -> {
                    boolean reload = filterOn != checks[0] || hidePromotions != checks[1] || autoSkip != checks[2];
                    boolean previousBackground = backgroundAudio;
                    filterOn=checks[0]; hidePromotions=checks[1]; autoSkip=checks[2];
                    backgroundAudio=checks[3]; autoPip=checks[4]; microphoneEnabled=checks[5];
                    settings.edit().putBoolean(KEY_FILTER,filterOn).putBoolean(KEY_HIDE,hidePromotions)
                            .putBoolean(KEY_SKIP,autoSkip).putBoolean(KEY_BACKGROUND,backgroundAudio)
                            .putBoolean(KEY_AUTO_PIP,autoPip).putBoolean(KEY_MICROPHONE,microphoneEnabled).apply();
                    if (!backgroundAudio && previousBackground) stopBackgroundService();
                    if (backgroundAudio && !previousBackground) requestNotificationPermission();
                    if (microphoneEnabled) injectYouTubeMicBridge();
                    if (!microphoneEnabled && pendingWebMicrophoneRequest!=null) {
                        pendingWebMicrophoneRequest.deny(); pendingWebMicrophoneRequest=null;
                    }
                    injectCleaner();
                    if (reload && webView!=null) webView.reload();
                    updateStatus();
                }).setNegativeButton("취소",null).show();
    }
    private void showPermissionSetup() {
        if (isFinishing() || isDestroyed()) return;
        String notification = Build.VERSION.SDK_INT<33 ? "시스템 별도 승인 불필요" :
                (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED ? "허용" : "권한 필요");
        String microphone = checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED ? "허용" : "권한 필요";
        String pip = getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) ?
                "기기 지원 (시스템 설정에서 차단 가능)" : "기기 미지원";
        new AlertDialog.Builder(this).setTitle("최초 실행 권한 안내")
                .setMessage("필요한 Android 권한을 순서대로 확인할게요. 이미 허용된 권한은 다시 묻지 않습니다.\n\n"+
                        "알림: "+notification+"\n마이크: "+microphone+"\n작은 화면: "+pip+
                        "\n\n권한을 거부해도 일반 영상 시청은 계속 가능합니다. Root와 ADB는 필요하지 않습니다.")
                .setPositiveButton("권한 확인", (d,i)->beginPermissionSequence())
                .setNegativeButton("나중에", (d,i)->settings.edit().putBoolean(KEY_FIRST_RUN_PERMISSIONS,true).apply())
                .show();
    }
    private void beginPermissionSequence() {
        settings.edit().putBoolean(KEY_FIRST_RUN_PERMISSIONS,true).apply();
        firstRunPermissionsPending = true;
        settings.edit().putBoolean(KEY_NOTIFICATION_ASKED,true).apply();
        if (Build.VERSION.SDK_INT>=33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_FIRST_NOTIFICATION);
        } else requestFirstMicPermission();
    }
    private void requestFirstMicPermission() {
        if (microphoneEnabled && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_FIRST_MICROPHONE);
        else firstRunPermissionsPending=false;
    }
    private void openPipSettings() {
        if (Build.VERSION.SDK_INT < 26) {toast("Android 8 이상에서 PIP가 지원됩니다.");return;}
        try {
            Intent intent=new Intent("android.settings.PICTURE_IN_PICTURE_SETTINGS",
                    Uri.parse("package:"+getPackageName()));
            startActivity(intent);
        } catch(Exception e) {toast("기기에서 PIP 설정 화면을 열 수 없습니다.");}
    }
    private void showDeviceDetails() {
        String provider = "확인 불가";
        try { android.content.pm.PackageInfo pkg = WebView.getCurrentWebViewPackage();
            if(pkg!=null) provider=pkg.packageName+" · "+pkg.versionName;
        } catch(Exception ignored) { }
        new AlertDialog.Builder(this).setTitle("호환성 정보")
                .setMessage("Android "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")"+
                        "\n모델: "+Build.MANUFACTURER+" "+Build.MODEL+
                        "\nWebView: "+provider+"\n\n광고 필터 카운터는 외부 요청만 집계하며, 영상 광고 차단 성공 수치가 아닙니다.")
                .setPositiveButton("닫기",null).show();
    }
    private void showSleepTimer() {
        new AlertDialog.Builder(this).setTitle("취침 타이머")
                .setItems(new String[]{"사용 안 함","15분 뒤 종료","30분 뒤 종료","60분 뒤 종료"},(d,i)->{
                    int minutes=i==0?0:i==1?15:i==2?30:60;
                    try { startService(new Intent(this, BackgroundAudioService.class)
                        .setAction(BackgroundAudioService.ACTION_SLEEP_TIMER)
                        .putExtra(BackgroundAudioService.EXTRA_SLEEP_MINUTES,minutes));
                        toast(minutes==0?"취침 타이머 해제":minutes+"분 뒤 음악 정지");
                    } catch(RuntimeException e) {toast("재생 서비스가 실행 중이지 않습니다.");}
                }).setNegativeButton("취소",null).show();
    }
    private void exportLibraryBackup() {
        Intent file = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        file.addCategory(Intent.CATEGORY_OPENABLE);file.setType("application/json");
        file.putExtra(Intent.EXTRA_TITLE,"믿음하나튜브_백업.json");
        try {startActivityForResult(file,REQUEST_LIBRARY_EXPORT);} catch(ActivityNotFoundException e) {toast("파일 저장 앱이 없습니다.");}
    }
    private void importLibraryBackup() {
        Intent file = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        file.addCategory(Intent.CATEGORY_OPENABLE);file.setType("application/json");
        try {startActivityForResult(file,REQUEST_LIBRARY_IMPORT);} catch(ActivityNotFoundException e) {toast("파일 선택 앱이 없습니다.");}
    }
    private void showSavedLocations(String url) {
        List<String> locations=new ArrayList<>();
        if(library.isBookmarked(url)) locations.add("나중에 보기");
        for(String playlist:library.musicPlaylistNames())
            for(LibraryStore.Entry e:library.musicTracks(playlist)) if(url.equals(e.url)) {locations.add(playlist);break;}
        if(locations.isEmpty()){toast("저장된 곳이 없습니다.");return;}
        new AlertDialog.Builder(this).setTitle("저장 위치별 삭제")
                .setItems(locations.toArray(new String[0]),(d,i)->{
                    String location=locations.get(i);
                    if(location.equals("나중에 보기")) library.removeBookmark(url);
                    else {List<LibraryStore.Entry> list=library.musicTracks(location);
                        list.removeIf(e->e.url.equals(url));library.saveMusicTracks(location,list);}
                    updateBookmark();toast("선택한 저장 위치에서 제거했습니다.");
                }).setNegativeButton("취소",null).show();
    }
    private interface PlaylistNameCallback { void onCreated(String name); }
    private void promptCreatePlaylist(PlaylistNameCallback callback) {
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint("새 플레이리스트 이름");
        FrameLayout frame=new FrameLayout(this);frame.setPadding(dp(20),dp(8),dp(20),dp(8));frame.addView(name);
        new AlertDialog.Builder(this).setTitle("음악 플레이리스트 만들기")
                .setView(frame).setNegativeButton("취소",null)
                .setPositiveButton("만들기",(d,i)->{
                    String value=name.getText().toString().trim();
                    if(library.createMusicPlaylist(value))callback.onCreated(value);
                    else toast("이름이 중복되거나 사용할 수 없습니다.");
                }).show();
    }

    private void showCacheClearConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("웹 캐시 삭제")
                .setMessage("웹페이지 이미지·스크립트 등 임시 캐시를 삭제합니다.\n\n" +
                        "즐겨찾기, 방문 기록, 앱 설정, 쿠키·로그인은 유지됩니다. " +
                        "현재 영상은 새로고침하거나 재생 위치를 변경하지 않습니다.\n\n" +
                        "네이티브 오디오에는 별도의 디스크 캐시가 없습니다.")
                .setPositiveButton("캐시 삭제", (dialog, which) -> {
                    if (webView == null) {
                        toast("웹페이지가 준비되지 않았습니다.");
                        return;
                    }
                    // WebView.clearCache(true) removes memory/disk resource cache only.
                    // Do NOT delete app storage, Cookies, WebStorage, LibraryStore, or traces.
                    webView.clearCache(true);
                    PlaybackDiagnostics.event(this, playbackTraceSession, "WEB_CACHE_CLEARED", "KEEP_USER_DATA", null);
                    toast("캐시 삭제 완료 · 즐겨찾기와 설정은 유지됩니다.");
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void injectCleaner() {
        if (webView == null || cleanerJavaScript.isEmpty()) return;
        if (!LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        String script = "window.__CS_HIDE=" + (hidePromotions ? "true" : "false") + ";" +
                "window.__CS_SKIP=" + (autoSkip ? "true" : "false") + ";\n" + cleanerJavaScript;
        webView.evaluateJavascript(script, null);
    }

    private static final class QueuePayload {
        final ArrayList<String> urls = new ArrayList<>();
        final ArrayList<String> names = new ArrayList<>();
        int selected;
    }
    /** Shared queue for both PiP video and background audio (no separate dummy queue). */
    private QueuePayload collectPlaybackQueue(String currentUrl) {
        QueuePayload payload = new QueuePayload();
        String originalList = YouTubePlaylistContext.playlistId(currentUrl);
        if (originalList.isEmpty() && !youtubePlaylistId.isEmpty()) {
            // YouTube SPA transitions sometimes drop list= from the watch URL.
            ArrayList<String> savedUrls = new ArrayList<>();
            for (LibraryStore.Entry entry : youtubePlaylistTracks) savedUrls.add(entry.url);
            if (YouTubePlaylistContext.containsVideo(savedUrls, currentUrl))
                originalList = youtubePlaylistId;
        }
        if (!originalList.isEmpty()) {
            // Never silently replace a user-selected playlist with recommendations.
            boolean captured = originalList.equals(youtubePlaylistId) && !youtubePlaylistTracks.isEmpty();
            if (captured) for (LibraryStore.Entry entry : youtubePlaylistTracks)
                appendQueueItem(payload,entry.url,entry.title);
            appendQueueItem(payload,currentUrl,lastMediaTitle);
            PlaybackDiagnostics.event(this, playbackTraceSession, "YOUTUBE_PLAYLIST_QUEUE",
                    captured ? "ORIGINAL_ORDER_VISIBLE_"+youtubePlaylistTracks.size() : "LIST_ITEMS_NOT_LOADED", null);
        } else {
            List<LibraryStore.Entry> history = library.history();
            for (int i=Math.min(history.size(),25)-1; i>=0; i--) {
                LibraryStore.Entry e=history.get(i);
                if (YouTubeStreamResolver.isSupportedVideoUrl(e.url)) appendQueueItem(payload,e.url,e.title);
            }
            appendQueueItem(payload,currentUrl,lastMediaTitle);
            for (LibraryStore.Entry suggestion: visibleRelatedTracks)
                appendQueueItem(payload,suggestion.url,suggestion.title);
        }
        String id = YouTubeStreamResolver.canonicalMediaKey(currentUrl);
        payload.selected = 0;
        for (int i=0;i<payload.urls.size();i++) {
            if (id.equals(YouTubeStreamResolver.canonicalMediaKey(payload.urls.get(i)))) {
                payload.selected=i; break;
            }
        }
        return payload;
    }
    private void appendQueueItem(QueuePayload payload,String url,String displayTitle) {
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url) || payload.urls.size()>=PlaybackQueue.LIMIT) return;
        String id=YouTubeStreamResolver.canonicalMediaKey(url);
        for (String entry:payload.urls)
            if (id.equals(YouTubeStreamResolver.canonicalMediaKey(entry))) return;
        payload.urls.add(url);
        payload.names.add(displayTitle == null || displayTitle.isEmpty() ? "영상" : displayTitle);
    }

    /** Real PlayerView video surface. Unlike a browser PiP, toolbars cannot appear in it. */
    private void openNativeVideo(boolean enterPipImmediately) {
        if (webView == null || !YouTubeStreamResolver.isSupportedVideoUrl(webView.getUrl())) {
            toast("먼저 유튜브 영상을 열어 주세요.");
            return;
        }
        String url = webView.getUrl();
        launchingNativeVideo = true;
        nativeHandoffRequested = true;
        // Stop the web audio before the independent ExoPlayer starts.
        webView.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
        QueuePayload candidates = collectPlaybackQueue(url);
        Intent video = new Intent(this, VideoPlayerActivity.class)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS,candidates.urls)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_TITLES,candidates.names)
                .putExtra(BackgroundAudioService.EXTRA_QUEUE_START,candidates.selected)
                .putExtra(VideoPlayerActivity.EXTRA_PAGE_URL, url)
                .putExtra(VideoPlayerActivity.EXTRA_START_MS, lastKnownPositionMs)
                .putExtra(VideoPlayerActivity.EXTRA_START_IN_PIP, enterPipImmediately)
                .putExtra(VideoPlayerActivity.EXTRA_PAGE_TITLE, lastMediaTitle);
        try { startActivity(video); }
        catch (RuntimeException error) {
            launchingNativeVideo = false;
            nativeHandoffRequested = false;
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "NATIVE_PIP_LAUNCH_FAILED", "ACTIVITY_START_FAILED", null);
            toast("영상 전용 작은 화면을 열지 못했습니다.");
            if (backgroundAudio && activityBackgrounded && wasPlayingImmediatelyBeforeLeaving()) beginNativeHandoff();
        }
    }
    private void updateStatus() {
        if (status == null) return;
        status.setText((!lastNativeError.isEmpty() ? "오디오 오류 · 설정→재생 진단" :
                (backgroundAudio ? "음악 백그라운드 ON" : "음악 백그라운드 OFF")) +
                " · " + (nativeAudioActive ? "독립 오디오 중" : (nativeHandoffRequested ? "오디오 전환 중" :
                (lastKnownPlaying ? "재생 중" : "대기"))) +
                " · 광고·필터 기록은 ⚠ 진단에서 확인");
    }

    private void showIntro() {
        settings.edit().putBoolean("intro_seen", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 0.1.24")
                .setMessage("유튜브 시청과 음악 재생을 위한 앱입니다. 라이브러리에서 나중에 보기와 음악목록을 분리해 관리하고, 설정에서 권한·백업·캐시·재생 진단을 관리할 수 있습니다. 사용 전 필요한 권한을 확인합니다. 광고 필터와 자동 PIP는 일부 기기에서 제한될 수 있습니다. 차량에서는 정차 상태에서만 영상을 시청하세요.")
                .setPositiveButton("시작", (d,i)->audioHandler.postDelayed(this::showPermissionSetup,250))
                .show();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }

    private String loadAsset(String name) throws Exception {
        try (java.io.InputStream stream = getAssets().open(name);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int n;
            while ((n = stream.read(chunk)) != -1) buffer.write(chunk, 0, n);
            return buffer.toString(StandardCharsets.UTF_8.name());
        }
    }

    /** One handler for toolbar, Android Back button and Android 13+ back gestures. */
    private void back() {
        if (customView != null) { hideCustomView(); return; }
        if (webView != null && webView.canGoBack()) {
            lastBackAtRoot = 0L;
            webView.goBack();
            return;
        }
        if (webView != null) {
            String current = webView.getUrl();
            if (current != null && !HOME.equals(current) &&
                    !"https://www.youtube.com/".equals(current)) {
                lastBackAtRoot = 0L;
                webView.loadUrl(HOME);
                return;
            }
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackAtRoot <= BACK_EXIT_WINDOW_MS) {
            showExitConfirmation();
        } else {
            lastBackAtRoot = now;
            toast("한 번 더 뒤로 누르면 앱을 종료합니다.");
        }
    }

    /**
     * All user-facing exit paths ask first. Merely opening/cancelling this dialog
     * never pauses WebView, changes playback position or stops native audio.
     */
    private void showExitConfirmation() {
        if (exiting || isFinishing() || isDestroyed()) return;
        if (exitConfirmationDialog != null && exitConfirmationDialog.isShowing()) return;
        lastBackAtRoot = 0L;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("믿음하나튜브 종료")
                .setMessage("앱을 종료하시겠습니까?\n\n재생 중인 음악과 영상도 함께 종료됩니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("종료", (d, which) -> exitApp())
                .create();
        exitConfirmationDialog = dialog;
        dialog.setOnDismissListener(d -> {
            if (exitConfirmationDialog == dialog) exitConfirmationDialog = null;
        });
        dialog.show();
    }

    /** Called ONLY after the user confirms exit. Stops all playing media. */
    private void exitApp() {
        if (exiting) return;
        exiting = true;
        nativeHandoffRequested = false;
        nativeAudioActive = false;
        playWasActiveOnLeave = false;
        audioHandler.removeCallbacksAndMessages(null);
        try {
            if (webView != null) {
                webView.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
                webView.onPause();
            }
        } catch (RuntimeException ignored) { }
        stopBackgroundService();
        finishAndRemoveTask();
    }

    /** Physical BACK keys can report a long press; system gestures cannot. */
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.getRepeatCount() == 0) {
                backLongPressHandled = false;
                event.startTracking();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            backLongPressHandled = true;
            showExitConfirmation();
            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!backLongPressHandled && !event.isCanceled()) back();
            backLongPressHandled = false;
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void registerSystemBack() {
        // Android 14+ can report Back *started* and *committed* events.
        // On some system navigation modes a long press can thus be measured.
        // On Android 13 and gesture modes that provide commit only, duration
        // is not available; we preserve ordinary back and explicit App Exit.
        if (Build.VERSION.SDK_INT >= 34) {
            systemBackCallback = new OnBackAnimationCallback() {
                @Override public void onBackStarted(BackEvent event) {
                    systemBackGestureStartedAt = SystemClock.elapsedRealtime();
                }
                @Override public void onBackProgressed(BackEvent event) { }
                @Override public void onBackCancelled() { systemBackGestureStartedAt = 0L; }
                @Override public void onBackInvoked() {
                    long elapsed = systemBackGestureStartedAt == 0L ? 0L :
                            SystemClock.elapsedRealtime() - systemBackGestureStartedAt;
                    systemBackGestureStartedAt = 0L;
                    if (elapsed >= 850L) showExitConfirmation();
                    else back();
                }
            };
        } else if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback = this::back;
        }
        if (systemBackCallback != null) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, systemBackCallback);
        }
    }

    @Override public void onBackPressed() { back(); }
    @Override public void onConfigurationChanged(Configuration config) { super.onConfigurationChanged(config); }
    @Override protected void onSaveInstanceState(Bundle output) {
        if (webView != null) {
            Bundle webState = new Bundle();
            webView.saveState(webState);
            output.putBundle("web_state", webState);
        }
        super.onSaveInstanceState(output);
    }
    private void registerAudioReceiver() {
        android.content.IntentFilter filter = new android.content.IntentFilter(BackgroundAudioService.ACTION_CONTROL);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_READY);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_STOPPED);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_FAILURE);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_POSITION);
        filter.addAction(BackgroundAudioService.ACTION_NATIVE_SNAPSHOT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(audioControlReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(audioControlReceiver, filter);
        }
        audioReceiverRegistered = true;
    }

    private void readWebPlayerState(String response) {
        try {
            Object unwrapped = new JSONTokener(response).nextValue();
            if (!(unwrapped instanceof String)) return;
            JSONObject state = new JSONObject((String) unwrapped);
            if (!nativeAudioActive && !nativeHandoffRequested)
                lastKnownPositionMs = Math.max(0L, state.optLong("positionMs", lastKnownPositionMs));
            boolean playing = state.optBoolean("playing", false);
            lastKnownVideoPlaying = state.optBoolean("videoPlaying", playing);
            if (!state.optBoolean("hasVideo", false)) playing = false;
            String title = state.optString("title", "믿음하나튜브");
            if (title.isEmpty()) title = "믿음하나튜브";
            if (playing) lastConfirmedPlaybackAt = SystemClock.elapsedRealtime();
            if (playing && !activityBackgrounded &&
                    SystemClock.elapsedRealtime()-lastRecommendationsAt>12000L) {
                lastRecommendationsAt=SystemClock.elapsedRealtime();
                collectRelatedTracks();
                collectYoutubePlaylistTracks();
            }
            else if (!activityBackgrounded) lastForegroundPauseAt = SystemClock.elapsedRealtime();
            // WebView and ExoPlayer must NEVER both be allowed to play for long.
            // The user may tap YouTube's own play button rather than our "영상 복귀".
            if (playing && nativeAudioActive && (nativeBrowserSync || nativeToWebSwitchPending)) {
                // The browser may autoplay while showing the CURRENT native song.
                // Do not destroy the user's background player during UI synchronization.
                if (nativeBrowserSync) webView.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
            } else if (playing && nativeAudioActive && !activityBackgrounded &&
                    SystemClock.elapsedRealtime() - latestForegroundResumeMs > 500L) {
                PlaybackDiagnostics.event(this, playbackTraceSession,
                        "DUAL_AUDIO_PREVENTED", "WEB_PLAY_TOOK_OVER", null);
                nativeAudioActive = false;
                nativeHandoffRequested = false;
                nativeToWebSwitchPending = false;
                try { startService(new Intent(this, BackgroundAudioService.class)
                        .setAction(BackgroundAudioService.ACTION_NATIVE_STOP)); }
                catch (RuntimeException ignored) { }
                updateReturnToVideoButton();
            }
            reportPlayerState(playing, title);
        } catch (Exception ignored) {
            // A navigation may invalidate the JS callback; the next poll will retry.
        }
    }

    private void reportPlayerState(boolean playing, String title) {
        if (nativeHandoffRequested || nativeAudioActive) {
            // WebView is no longer the audio source: never overwrite the native session.
            lastKnownPlaying = playing;
            // The browser may still display the OLD video. Native title/URL
            // are authoritative until an explicit return is confirmed.
            updateStatus();
            return;
        }
        if (playing == lastKnownPlaying && title.equals(lastMediaTitle)) return;
        boolean changed = playing != lastKnownPlaying;
        if (changed) PlaybackDiagnostics.event(this, playbackTraceSession,
                playing ? "WEB_PLAYING" : "WEB_NOT_PLAYING", "HTML_VIDEO", null);
        lastKnownPlaying = playing;
        lastMediaTitle = title;
        if (!backgroundAudio) { updateStatus(); return; }
        if (playing) {
            if (!activityBackgrounded && Build.VERSION.SDK_INT >= 33 &&
                    !settings.getBoolean(KEY_NOTIFICATION_ASKED, false)) {
                settings.edit().putBoolean(KEY_NOTIFICATION_ASKED, true).apply();
                requestNotificationPermission();
            }
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, true)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title)
                    .putExtra(BackgroundAudioService.EXTRA_POSITION_MS, lastKnownPositionMs)
                    .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL,
                            webView == null ? "" : webView.getUrl());
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);
                serviceWasStarted = true;
            } catch (RuntimeException ignored) {
                // Foreground service restrictions may prevent a late background start.
                serviceWasStarted = false;
            }
        } else if (serviceWasStarted) {
            Intent intent = new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_UPDATE)
                    .putExtra(BackgroundAudioService.EXTRA_PLAYING, false)
                    .putExtra(BackgroundAudioService.EXTRA_TITLE, title);
            try { startService(intent); } catch (RuntimeException ignored) { }
        }
        if (changed) updateStatus();
    }

    private void stopBackgroundService() {
        serviceWasStarted = false;
        stopService(new Intent(this, BackgroundAudioService.class));
    }

    /** Request play/pause, then check the REAL video state before changing the notification. */
    private void controlWebPlayer(boolean play) {
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) {
            reportControlFailure("앱에서 먼저 영상을 열어 재생해 주세요.");
            return;
        }
        final String expectedUrl = webView.getUrl();
        lastPlayerCommandMs = SystemClock.elapsedRealtime();
        final long commandId = lastPlayerCommandMs;
        String script = "(function(){try{var a=document.querySelectorAll('video'),v=null;" +
                "for(var i=0;i<a.length;i++){if(!a[i].paused&&!a[i].ended){v=a[i];break}}" +
                "if(!v&&a.length)v=a[0];if(!v)return 'NO_VIDEO';" +
                (play ? "var p=v.play();if(p&&p.catch)p.catch(function(e){window.__MHT_PLAY_ERROR=String(e&&e.name||e);});" : "v.pause();") +
                "return 'SENT';}catch(e){return String(e&&e.name||e);}})()";
        webView.evaluateJavascript(script, response -> {
            if (webView == null || !expectedUrl.equals(webView.getUrl())) return;
            if (response == null || !response.contains("SENT")) {
                reportControlFailure("웹 플레이어 명령을 실행할 수 없습니다.");
                return;
            }
            audioHandler.postDelayed(() -> verifyPlayerCommand(expectedUrl, commandId, play),
                    PLAYER_COMMAND_VERIFY_MS);
        });
    }

    private void verifyPlayerCommand(String expectedUrl, long commandId, boolean requestedPlay) {
        if (webView == null || commandId != lastPlayerCommandMs ||
                !expectedUrl.equals(webView.getUrl())) return;
        webView.evaluateJavascript(PLAYBACK_PROBE_JS, response -> {
            if (webView == null || commandId != lastPlayerCommandMs ||
                    !expectedUrl.equals(webView.getUrl())) return;
            readWebPlayerState(response);
            if (requestedPlay && !lastKnownPlaying) {
                reportControlFailure("웹 플레이어가 재생을 시작하지 못했습니다. 앱 화면에서 재생해 주세요.");
            }
        });
    }

    private void reportControlFailure(String reason) {
        if (!activityBackgrounded) toast(reason);
        Intent intent = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_FEEDBACK)
                .putExtra(BackgroundAudioService.EXTRA_ERROR, reason);
        try { startService(intent); } catch (RuntimeException ignored) { }
    }

    private void attemptBackgroundResumptionOnce() {
        if (!activityBackgrounded || !backgroundAudio || !playWasActiveOnLeave || attemptedResumeOnLeave)
            return;
        attemptedResumeOnLeave = true;
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) return;
        // A single retry is allowed only for media the user had actively started.
        // We intentionally do not create a repeating autoplay loop.
        webView.evaluateJavascript("(function(){var v=document.querySelector('video');" +
                "if(v&&v.paused&&!v.ended&&v.currentTime>0){" +
                "var p=v.play();if(p&&p.catch)p.catch(function(){});return true;}return false;})()", null);
    }

    private boolean wasPlayingImmediatelyBeforeLeaving() {
        if (lastKnownPlaying) return true;
        long now = SystemClock.elapsedRealtime();
        // Some WebView builds pause the video between the Home gesture and
        // onPause(). Accept a previously confirmed playback for 3 seconds,
        // but never resume if the user paused it explicitly in foreground.
        return lastConfirmedPlaybackAt > lastForegroundPauseAt &&
                now >= lastConfirmedPlaybackAt && now - lastConfirmedPlaybackAt <= 3000L &&
                lastKnownPositionMs > 0L && webView != null &&
                YouTubeStreamResolver.isSupportedVideoUrl(webView.getUrl());
    }

    /** Best-effort links already visible on a YouTube page, not a private API.
     * Availability is determined by YouTube's current web layout.
     */
    private void collectRelatedTracks() {
        if(webView==null || !YouTubeStreamResolver.isSupportedVideoUrl(webView.getUrl()))return;
        final String page=webView.getUrl();
        String script="(function(){var seen={},items=[];var a=document.querySelectorAll('a[href*=\"watch?v=\"]');"+
            "for(var i=0;i<a.length&&items.length<18;i++){try{var u=new URL(a[i].href,location.origin);"+
            "var id=u.searchParams.get('v');if(!id||!/^[a-zA-Z0-9_-]{11}$/.test(id)||seen[id])continue;"+
            "seen[id]=1;items.push({url:'https://www.youtube.com/watch?v='+id,"+
            "title:String(a[i].getAttribute('aria-label')||a[i].getAttribute('title')||a[i].textContent||'관련 영상').trim().slice(0,100)});"+
            "}catch(e){}}return JSON.stringify(items)})()";
        webView.evaluateJavascript(script,json->{
            if(webView==null || !page.equals(webView.getUrl()))return;
            try {
                Object parsed=new JSONTokener(json).nextValue();
                if(!(parsed instanceof String))return;
                org.json.JSONArray arr=new org.json.JSONArray((String)parsed);
                visibleRelatedTracks.clear();
                for(int i=0;i<arr.length();i++){
                    JSONObject obj=arr.optJSONObject(i);if(obj==null)continue;
                    String u=obj.optString("url","");
                    if(YouTubeStreamResolver.isSupportedVideoUrl(u) &&
                       !YouTubeStreamResolver.canonicalMediaKey(u).equals(YouTubeStreamResolver.canonicalMediaKey(page)))
                        visibleRelatedTracks.add(new LibraryStore.Entry(obj.optString("title","관련 영상"),u));
                }
            } catch(Exception ignored){}
        });
    }
    /** Capture ONLY the video rows of the user's selected YouTube playlist.
     * Keep previously loaded playlist rows across SPA transitions to watch pages.
     * Large playlists may expose only the first/nearby rows through lazy loading.
     */
    private void collectYoutubePlaylistTracks() {
        if (webView == null || youtubePlaylistJavaScript.isEmpty()) return;
        final String page = webView.getUrl();
        final String requestedList = YouTubePlaylistContext.playlistId(page);
        if (requestedList.isEmpty()) return;
        webView.evaluateJavascript(youtubePlaylistJavaScript, raw -> {
            if (webView == null || !page.equals(webView.getUrl())) return;
            try {
                Object value = new JSONTokener(raw).nextValue();
                if (!(value instanceof String)) return;
                JSONObject data = new JSONObject((String) value);
                if (!requestedList.equals(data.optString("id"))) return;
                org.json.JSONArray rows = data.optJSONArray("tracks");
                if (rows == null || rows.length() == 0) return;
                ArrayList<LibraryStore.Entry> results = new ArrayList<>();
                // Keep first-seen order and title exactly as before, but avoid
                // repeatedly canonicalizing and scanning all previously seen URLs.
                HashSet<String> seenMediaKeys = new HashSet<>();
                for (int i = 0; i < rows.length() && results.size() < PlaybackQueue.LIMIT; i++) {
                    JSONObject row = rows.optJSONObject(i);
                    if (row == null) continue;
                    String url = row.optString("url", "");
                    if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) continue;
                    String title = row.optString("title", "영상");
                    String key = YouTubeStreamResolver.canonicalMediaKey(url);
                    if (seenMediaKeys.add(key)) results.add(new LibraryStore.Entry(title, url));
                }
                if (!results.isEmpty()) {
                    if (!requestedList.equals(youtubePlaylistId)) {
                        youtubePlaylistId = requestedList;
                        youtubePlaylistWindow.clear();
                    }
                    for (int i=0; i<rows.length(); i++) {
                        JSONObject row = rows.optJSONObject(i);
                        if (row == null) continue;
                        String url = row.optString("url", "");
                        if (YouTubeStreamResolver.isSupportedVideoUrl(url))
                            youtubePlaylistWindow.add(row.optInt("index",0),url,row.optString("title","영상"));
                    }
                    youtubePlaylistTracks.clear();
                    for (YouTubePlaylistWindow.Track track : youtubePlaylistWindow.snapshot())
                        youtubePlaylistTracks.add(new LibraryStore.Entry(track.title, track.url));
                    PlaybackDiagnostics.event(this, playbackTraceSession, "YOUTUBE_PLAYLIST_CAPTURED",
                            "VISIBLE_"+results.size()+"_MERGED_"+youtubePlaylistTracks.size()
                            +(youtubePlaylistWindow.hasGaps()?"_PARTIAL_INDEX":""), null);
                }
            } catch (Exception ignored) { }
        });
    }

    private void beginNativeHandoff() {
        if (webView == null || nativeHandoffRequested || nativeAudioActive) return;
        String url = webView.getUrl();
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) {
            lastNativeError = "현재 주소에서 독립 오디오를 시작할 수 없습니다. 영상 페이지를 열어 주세요.";
            updateStatus();
            return;
        }
        playbackTraceSession = PlaybackDiagnostics.nextSession(this);
        PlaybackDiagnostics.event(this, playbackTraceSession, "HANDOFF_REQUESTED", "HOME_EXIT", null);
        nativeHandoffRequested = true;
        QueuePayload queue = collectPlaybackQueue(url);
        Intent intent = new Intent(this, BackgroundAudioService.class)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS,queue.urls)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_TITLES,queue.names)
                .putExtra(BackgroundAudioService.EXTRA_QUEUE_START,queue.selected)
                .putExtra("trace_session", playbackTraceSession)
                .setAction(BackgroundAudioService.ACTION_NATIVE_START)
                .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL, url)
                .putExtra(BackgroundAudioService.EXTRA_POSITION_MS, lastKnownPositionMs)
                .putExtra(BackgroundAudioService.EXTRA_TITLE, lastMediaTitle);
        try {
            // Foreground-service transition is user-initiated via the Home gesture.
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
        } catch (RuntimeException error) {
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "START_FOREGROUND_SERVICE_FAILED", "ANDROID_RESTRICTION", null);
            nativeHandoffRequested = false;
            lastNativeError = "백그라운드 서비스 시작 차단: " + error.getClass().getSimpleName();
        }
        updateStatus();
    }

    private void updateReturnToVideoButton() {
        if (returnToVideoButton != null)
            returnToVideoButton.setVisibility(nativeAudioActive ? View.VISIBLE : View.GONE);
    }

    private void returnToVideo() {
        if (!nativeAudioActive || webView == null) return;
        // Always query current native track/position; cached WebView URL is not authoritative.
        returnQueryPending = true;
        nativeVideoReturnExplicit = false;
        startService(new Intent(this,BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_NATIVE_QUERY));
    }

    private void handleExplicitVideoReturn(Intent intent) {
        String url = intent.getStringExtra(EXTRA_NATIVE_VIDEO_RETURN_URL);
        if (webView == null || !YouTubeStreamResolver.isSupportedVideoUrl(url)) return;
        nativeVideoReturnExplicit = true;
        nativeVideoReattachStarted = false;
        nativeSnapshotOnResumePending = false;
        nativeAudioActive = true;
        currentNativePageUrl = url;
        lastKnownPositionMs = Math.max(0L,intent.getLongExtra(EXTRA_NATIVE_VIDEO_RETURN_MS,0L));
        nativeReturnShouldPlay = intent.getBooleanExtra(EXTRA_NATIVE_VIDEO_RETURN_PLAYING, true);
        nativePendingReturnPositionMs = lastKnownPositionMs;
        PlaybackDiagnostics.event(this,playbackTraceSession,"VIDEO_TO_WEB_RETURN","CURRENT_NATIVE_TRACK",null);
        nativeToWebSwitchPending = true;
        nativeBrowserSync = false;
        if (!sameVideoUrl(url,webView.getUrl())) {
            nativePendingReturnUrl = url;
            webView.loadUrl(url);
        } else {
            nativePendingReturnUrl = null;
            seekWebAndConfirm(lastKnownPositionMs,0);
        }
        updateReturnToVideoButton();
    }

    private boolean sameVideoUrl(String first,String second) {
        return YouTubeStreamResolver.isSupportedVideoUrl(first) &&
                YouTubeStreamResolver.isSupportedVideoUrl(second) &&
                YouTubeStreamResolver.canonicalMediaKey(first).equals(
                        YouTubeStreamResolver.canonicalMediaKey(second));
    }
    private void requestNativeReturnPosition() {
        if (!nativeAudioActive || !nativeToWebSwitchPending) return;
        startService(new Intent(this,BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_NATIVE_RETURN));
    }
    private void resumeVideoFromNative(long positionMs) {
        if (!nativeAudioActive || webView == null || !nativeToWebSwitchPending) return;
        nativePendingReturnPositionMs = positionMs;
        String url=currentNativePageUrl;
        if (!sameVideoUrl(url,webView.getUrl())) {
            if (YouTubeStreamResolver.isSupportedVideoUrl(url)) {
                nativePendingReturnUrl=url;
                webView.loadUrl(url);
            }
            return;
        }
        seekWebAndConfirm(positionMs,0);
    }
    private void seekWebAndConfirm(long positionMs,int attempts) {
        if (webView==null || !nativeToWebSwitchPending) return;
        if (attempts >= 18) {
            PlaybackDiagnostics.event(this,playbackTraceSession,"WEB_RETURN_TIMEOUT","NATIVE_RETAINED",null);
            restartNativeAfterFailedReturn("웹 영상 준비 실패 · 독립 재생을 유지합니다.");
            return;
        }
        final String expected=currentNativePageUrl;
        if (!sameVideoUrl(expected,webView.getUrl())) return;
        final boolean expectPlaying = nativeReturnShouldPlay;
        // A paused native video must remain paused on return; playback state is
        // part of the same handoff as the media ID and timeline.
        String js="(function(){var v=document.querySelector('video');"+
                "if(!v||v.readyState<1)return 'WAIT';"+
                "v.currentTime="+(Math.max(0L,positionMs)/1000.0)+";"+
                (expectPlaying ? "var p=v.play();if(p&&p.catch)p.catch(function(){});" : "v.pause();")+
                "return 'OK';})()";
        webView.evaluateJavascript(js, response -> {
            if (webView==null || !nativeToWebSwitchPending) return;
            if (response == null || !response.contains("OK")) {
                audioHandler.postDelayed(()->seekWebAndConfirm(positionMs,attempts+1),450L);
                return;
            }
            audioHandler.postDelayed(()->webView.evaluateJavascript(PLAYBACK_PROBE_JS, probe -> {
                if (!nativeToWebSwitchPending) return;
                try {
                    Object parsed = new JSONTokener(probe).nextValue();
                    JSONObject state = parsed instanceof String ? new JSONObject((String)parsed) : new JSONObject();
                    boolean videoPlaying=state.optBoolean("videoPlaying",false);
                    long actualPosition=Math.max(0L,state.optLong("positionMs",-1L));
                    // Avoid declaring a stale/old WebView video restored simply
                    // because playback began. Verify both play state and seek.
                    boolean correctState=expectPlaying ? videoPlaying : !videoPlaying;
                    boolean correctPosition=actualPosition>=0L &&
                            PlaybackHandoff.withinSeekTolerance(positionMs,actualPosition);
                    if (!correctState || !correctPosition) {
                        audioHandler.postDelayed(()->seekWebAndConfirm(positionMs,attempts+1),450L);
                        return;
                    }
                    PlaybackDiagnostics.event(this,playbackTraceSession,"WEB_RETURN_CONFIRMED",
                            expectPlaying ? "PLAYING_AT_CURRENT_POSITION" : "PAUSED_AT_CURRENT_POSITION",null);
                    nativeAudioActive=false;
                    nativeHandoffRequested=false;
                    nativeToWebSwitchPending=false;
                    nativeVideoReturnExplicit=false;
                    nativeBrowserSync=false;
                    nativePendingReturnUrl=null;
                    lastKnownPositionMs=Math.max(0L,state.optLong("positionMs",positionMs));
                    lastKnownPlaying=expectPlaying;
                    lastKnownVideoPlaying=expectPlaying;
                    updateReturnToVideoButton();
                    startService(new Intent(this,BackgroundAudioService.class)
                            .setAction(BackgroundAudioService.ACTION_NATIVE_STOP));
                    updateStatus();
                } catch(Exception error) {
                    audioHandler.postDelayed(()->seekWebAndConfirm(positionMs,attempts+1),450L);
                }
            }),350L);
        });
    }

    private void applyNativeSnapshot(Intent snapshot) {
        boolean active = snapshot.getBooleanExtra(BackgroundAudioService.EXTRA_NATIVE_ACTIVE,false);
        if (!active) {nativeSnapshotOnResumePending=false; return;}
        String url=snapshot.getStringExtra(BackgroundAudioService.EXTRA_ACTIVE_PAGE);
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) return;
        currentNativePageUrl=url;
        lastKnownPositionMs=Math.max(0L,snapshot.getLongExtra(BackgroundAudioService.EXTRA_POSITION_MS,0L));
        String currentTitle=snapshot.getStringExtra(BackgroundAudioService.EXTRA_TITLE);
        if (currentTitle!=null && !currentTitle.trim().isEmpty())lastMediaTitle=currentTitle;
        boolean verified = snapshot.getBooleanExtra(BackgroundAudioService.EXTRA_NATIVE_VERIFIED,false);
        nativeAudioActive = nativeAudioActive || verified;
        nativeHandoffRequested = !verified && !nativeAudioActive;
        updateReturnToVideoButton();
        boolean video = snapshot.getBooleanExtra(BackgroundAudioService.EXTRA_NATIVE_VIDEO_MODE,false);
        if (returnQueryPending) {
            returnQueryPending=false;
            nativeToWebSwitchPending=true;
            if (!sameVideoUrl(url,webView.getUrl())) {
                nativeBrowserSync=true;
                nativePendingReturnUrl=url;
                webView.loadUrl(url);
            } else {
                nativeBrowserSync=false;
                requestNativeReturnPosition();
            }
            return;
        }
        if (nativeSnapshotOnResumePending && !nativeVideoReturnExplicit) {
            nativeSnapshotOnResumePending=false;
            if (video) {
                // Never force the user into the unwanted native full-screen Activity.
                // VideoPlayerActivity expands from PiP directly to the web by an
                // explicit handoff carrying the current video and exact position.
                PlaybackDiagnostics.event(this,playbackTraceSession,
                        "NATIVE_VIDEO_SURFACE_RETAINED","WAIT_FOR_PIP_EXPAND",null);
            } else {
                // Opening the app while background music plays means Return to
                // video. The user must not press a second restore button.
                nativeAudioActive=true;
                nativeToWebSwitchPending=true;
                PlaybackDiagnostics.event(this,playbackTraceSession,
                        "BACKGROUND_AUTO_WEB_RETURN","CURRENT_TRACK_AND_POSITION",null);
                if (!sameVideoUrl(url,webView.getUrl())) {
                    nativeBrowserSync=true;
                    nativePendingReturnUrl=url;
                    webView.loadUrl(url);
                } else {
                    nativeBrowserSync=false;
                    requestNativeReturnPosition();
                }
            }
        }
        updateStatus();
    }

    private void restartNativeAfterFailedReturn(String message) {
        nativeToWebSwitchPending = false;
        nativeBrowserSync = true;
        nativeVideoReturnExplicit = false;
        if (webView != null) webView.evaluateJavascript(
                "(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
        // A paused movie must not begin playing merely because browser restore
        // failed. Return to the same native playback intention as before.
        try { startService(new Intent(this, BackgroundAudioService.class)
                .setAction(nativeReturnShouldPlay ? BackgroundAudioService.ACTION_PLAY
                        : BackgroundAudioService.ACTION_PAUSE)); }
        catch (RuntimeException ignored) { }
        PlaybackDiagnostics.event(this,playbackTraceSession,"WEB_RETURN_FALLBACK",
                nativeReturnShouldPlay ? "NATIVE_RESUME" : "NATIVE_KEEP_PAUSED",null);
        toast(message);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 122);
        }
    }

    private void showPlaybackQueueMenu() {
        final String[] items = {
                "즐겨찾기를 연속 음악으로 재생",
                "현재 화면 영상으로 대기목록 만들기 (최대 50곡)",
                "이전 곡", "다음 곡", "반복 모드 전환 (없음 → 한 곡 → 전체)",
                "전체 랜덤 ON/OFF", "독립 음악 재생 중지"
        };
        new AlertDialog.Builder(this).setTitle("음악 재생목록 · 이전/다음 · 반복/랜덤")
                .setItems(items, (dialog, selected) -> {
                    switch (selected) {
                        case 0: startBookmarkPlaylist(); break;
                        case 1: startVisiblePagePlaylist(); break;
                        case 2: sendQueueControl(BackgroundAudioService.ACTION_QUEUE_PREVIOUS); break;
                        case 3: sendQueueControl(BackgroundAudioService.ACTION_QUEUE_NEXT); break;
                        case 4: sendQueueControl(BackgroundAudioService.ACTION_QUEUE_REPEAT); break;
                        case 5: sendQueueControl(BackgroundAudioService.ACTION_QUEUE_SHUFFLE); break;
                        case 6: sendQueueControl(BackgroundAudioService.ACTION_NATIVE_STOP); break;
                        default: break;
                    }
                }).setNegativeButton("닫기", null).show();
    }
    private void sendQueueControl(String action) {
        try {
            startService(new Intent(this, BackgroundAudioService.class).setAction(action));
            toast("음악 제어 명령 전달됨");
        } catch (RuntimeException error) { toast("음악 서비스가 실행 중이지 않습니다."); }
    }
    private void startBookmarkPlaylist() {
        java.util.ArrayList<LibraryStore.Entry> entries = new java.util.ArrayList<>();
        for (LibraryStore.Entry entry : library.musicTracks(LibraryStore.DEFAULT_MUSIC)) {
            if (YouTubeStreamResolver.isSupportedVideoUrl(entry.url)) entries.add(entry);
            if (entries.size() >= PlaybackQueue.LIMIT) break;
        }
        if (entries.isEmpty()) { toast("즐겨찾기에 저장된 영상이 없습니다."); return; }
        String[] names = new String[entries.size()];
        for (int i=0; i<entries.size(); i++) names[i] = entries.get(i).title;
        new AlertDialog.Builder(this)
                .setTitle("즐겨찾기 음악 연속재생")
                .setItems(names, (d, i) -> startQueue(entries, i))
                .setNegativeButton("취소", null).show();
    }
    private void startVisiblePagePlaylist() {
        if (webView == null || !LibraryStore.isYoutubeUrl(webView.getUrl())) {
            toast("유튜브 영상 목록을 먼저 열어 주세요."); return;
        }
        webView.evaluateJavascript("(function(){var found={},list=[];" +
                "var links=document.querySelectorAll('a[href*=\"watch?v=\"]');" +
                "for(var i=0;i<links.length&&list.length<50;i++){try{" +
                "var a=links[i],u=new URL(a.href,location.origin),id=u.searchParams.get('v');" +
                "if(!id||!/^[a-zA-Z0-9_-]{11}$/.test(id)||found[id])continue;found[id]=1;" +
                "list.push({url:'https://www.youtube.com/watch?v='+id," +
                "title:(a.getAttribute('aria-label')||a.getAttribute('title')||a.textContent||'음악').trim().slice(0,100)});" +
                "}catch(e){}}return JSON.stringify(list)})()", result -> {
            try {
                Object outer = new JSONTokener(result).nextValue();
                if (!(outer instanceof String)) { toast("대기목록을 읽지 못했습니다."); return; }
                org.json.JSONArray arr = new org.json.JSONArray((String) outer);
                java.util.ArrayList<LibraryStore.Entry> entries = new java.util.ArrayList<>();
                for (int i=0;i<arr.length();i++) {
                    JSONObject obj=arr.optJSONObject(i); if (obj==null) continue;
                    String url=obj.optString("url", "");
                    if (YouTubeStreamResolver.isSupportedVideoUrl(url))
                        entries.add(new LibraryStore.Entry(obj.optString("title", "음악"),url));
                }
                if (entries.isEmpty()) { toast("현재 화면에서 영상 목록을 찾지 못했습니다."); return; }
                startQueue(entries, 0);
            } catch (Exception error) { toast("이 화면의 목록은 가져올 수 없습니다."); }
        });
    }
    private void startQueue(java.util.List<LibraryStore.Entry> entries, int index) {
        java.util.ArrayList<String> urls = new java.util.ArrayList<>();
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        for (LibraryStore.Entry entry : entries) {
            if (!YouTubeStreamResolver.isSupportedVideoUrl(entry.url)) continue;
            urls.add(entry.url); names.add(entry.title);
            if (urls.size() >= PlaybackQueue.LIMIT) break;
        }
        if (urls.isEmpty()) { toast("재생할 음악이 없습니다."); return; }
        nativeHandoffRequested = true;
        lastKnownVideoPlaying = false;
        if (webView != null) webView.evaluateJavascript(
                "(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
        Intent play = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_QUEUE_PLAY)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_URLS, urls)
                .putStringArrayListExtra(BackgroundAudioService.EXTRA_QUEUE_TITLES, names)
                .putExtra(BackgroundAudioService.EXTRA_QUEUE_START, index);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(play);
            else startService(play);
            toast("음악 " + urls.size() + "곡 재생 준비 중…");
        } catch (RuntimeException error) {
            nativeHandoffRequested = false;
            toast("음악 재생을 시작할 수 없습니다.");
        }
    }

    private void quickShareDiagnostics() {
        PlaybackDiagnostics.event(this, playbackTraceSession, "QUICK_DIAGNOSTICS_REQUESTED", "ONE_TAP", null);
        if (Build.VERSION.SDK_INT < 29) {
            exportPlaybackDiagnostics(); // Android 8/9 uses the permission-free document picker.
            return;
        }
        try {
            Uri saved=PlaybackDiagnostics.saveToDownloads(this);
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("application/zip");
            share.putExtra(Intent.EXTRA_STREAM,saved);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"진단 ZIP 공유 · Downloads에도 저장됨"));
        } catch (IOException | RuntimeException error) {
            PlaybackDiagnostics.event(this,playbackTraceSession,"DIAGNOSTICS_SHARE_FAILED","STORAGE_OR_CHOOSER",null);
            toast("진단 저장·공유를 시작할 수 없습니다. 저장 공간을 확인해 주세요.");
        }
    }

    private void showAudioDiagnostics() {
        SharedPreferences d = getSharedPreferences("mht_audio_diagnostics", MODE_PRIVATE);
        String stage = d.getString("stage", "기록 없음");
        String reason = d.getString("reason", "아직 네이티브 재생 결과 없음");
        String last = lastNativeError.isEmpty() ? reason : lastNativeError;
        int eventCount = PlaybackDiagnostics.count(this);
        String automaticDiagnosis = PlaybackDiagnostics.diagnose(this);
        new AlertDialog.Builder(this)
                .setTitle("백그라운드 오디오 진단")
                .setMessage("자동 원인 판별: " + automaticDiagnosis +
                        "\n\n마지막 단계: " + stage + "\n상세: " + last +
                        "\n자동 기록: " + eventCount + "건 (최대 최근 300건)" +
                        "\n\n오류 전후의 추출·버퍼링·서비스·재생 상태가 자동 저장됩니다. " +
                        "진단 ZIP에는 검색어·영상 제목·URL·쿠키·토큰을 넣지 않습니다. " +
                        "실제 오디오가 재생되지 않았는데 재생 중이라고 표시될 수 있는 기존 오판을 개선했습니다.")
                .setPositiveButton("닫기", null)
                .setNeutralButton("진단 ZIP 저장", (d0, w) -> exportPlaybackDiagnostics())
                .show();
    }

    private void exportPlaybackDiagnostics() {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                PlaybackDiagnostics.saveToDownloads(this);
                toast("Downloads에 재생 진단 ZIP을 저장했습니다.");
            } catch (IOException | RuntimeException error) {
                toast("진단 ZIP 저장에 실패했습니다. 저장 공간을 확인해 주세요.");
            }
        } else {
            // Android 8/9: use SAF to avoid requesting legacy storage permissions.
            Intent picker = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("application/zip");
            picker.putExtra(Intent.EXTRA_TITLE, PlaybackDiagnostics.suggestedFilename());
            try { startActivityForResult(picker, REQUEST_DIAGNOSTIC_SAVE); }
            catch (ActivityNotFoundException error) { toast("기기에 문서 저장 앱이 없습니다."); }
        }
    }

    /**
     * The only small-screen implementation is the independently verified
     * VideoPlayerActivity / PlayerView route. Never enter PiP from MainActivity
     * (which contains the WebView and native toolbar).
     *
     * Home gesture callbacks are OS-controlled; on some devices the system may
     * deny a new Activity launch once Home navigation has begun. In that case
     * an explicit press of the existing "작은 화면" toolbar action is the fallback.
     */
    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (exiting || launchingNativeVideo) return;
        PlaybackDiagnostics.event(this, playbackTraceSession, "USER_LEAVE_HINT",
                autoPip ? "AUTO_NATIVE_PIP_ON" : "AUTO_PIP_OFF", null);
        boolean canAutoPip = autoPip && lastKnownVideoPlaying && !nativeAudioActive
                && !nativeHandoffRequested && webView != null
                && YouTubeStreamResolver.isSupportedVideoUrl(webView.getUrl())
                && Build.VERSION.SDK_INT >= 26
                && getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE);
        if (canAutoPip) {
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "HOME_NATIVE_PIP_REQUESTED", "VIDEO_PLAYER_ACTIVITY", null);
            // This is intentionally the SAME playback surface as the working
            // "작은 화면" toolbar action. It will enter PiP when ExoPlayer is ready.
            openNativeVideo(true);
            return;
        }
        // No video ready for PiP: keep the previously working audio handoff
        // when the background music option is enabled.
        boolean startAudio = backgroundAudio && (!autoPip || !canAutoPip) && wasPlayingImmediatelyBeforeLeaving()
                && !nativeAudioActive && !nativeHandoffRequested;
        if (startAudio) {
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "HOME_NATIVE_PRIORITY", "AUTO_PIP_OFF", null);
            beginNativeHandoff();
        } else if (autoPip && lastKnownVideoPlaying) {
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "HOME_NATIVE_PIP_NOT_STARTED", "VIDEO_OR_PIP_UNAVAILABLE", null);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        activityBackgrounded = false;
        launchingNativeVideo = false;
        latestForegroundResumeMs = SystemClock.elapsedRealtime();
        PlaybackDiagnostics.event(this, playbackTraceSession, "ACTIVITY_RESUME", "LIFECYCLE", null);
        if (BackgroundAudioService.hasNativeAudioSession() && !nativeVideoReturnExplicit) {
            nativeSnapshotOnResumePending=true;
            try { startService(new Intent(this,BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_NATIVE_QUERY)); }
            catch(RuntimeException ignored) {nativeSnapshotOnResumePending=false;}
        }
        playWasActiveOnLeave = false;
        if (webView != null) {
            webView.onResume();
            if (nativeAudioActive) webView.evaluateJavascript(
                    "(function(){document.querySelectorAll('video,audio').forEach(function(v){v.pause()})})()", null);
        }
        if (!lastNativeError.isEmpty()) {
            status.setText("오디오 전환 실패 · 설정 → 재생 진단");
        }
    }

    @Override protected void onPause() {
        activityBackgrounded = true;
        nativeVideoReattachStarted = false;
        PlaybackDiagnostics.event(this, playbackTraceSession, "ACTIVITY_PAUSE", "LIFECYCLE", null);
        // Some Android navigation paths omit onUserLeaveHint; retain the existing
        // audio-only fallback without attempting a forbidden background Activity launch.
        if (!exiting && !launchingNativeVideo && backgroundAudio && wasPlayingImmediatelyBeforeLeaving() &&
                !nativeHandoffRequested && !nativeAudioActive) {
            PlaybackDiagnostics.event(this, playbackTraceSession,
                    "PAUSE_NATIVE_FALLBACK", "HOME_RACE_RECOVERED", null);
            beginNativeHandoff();
        }
        playWasActiveOnLeave = !exiting && backgroundAudio && wasPlayingImmediatelyBeforeLeaving();
        attemptedResumeOnLeave = false;
        // The previous v0.1.1 onPause() stopped WebView media as soon as Home was used.
        // Keep the media WebView active while background audio is enabled.
        if (webView != null && (exiting || !backgroundAudio)) webView.onPause();
        super.onPause();
        if (playWasActiveOnLeave && !launchingNativeVideo && !nativeHandoffRequested && !nativeAudioActive)
            audioHandler.postDelayed(this::attemptBackgroundResumptionOnce, 800);
    }

    @Override protected void onDestroy() {
        if (exitConfirmationDialog != null) {
            exitConfirmationDialog.dismiss();
            exitConfirmationDialog = null;
        }
        audioHandler.removeCallbacksAndMessages(null);
        if (pendingWebMicrophoneRequest != null) {
            pendingWebMicrophoneRequest.deny();
            pendingWebMicrophoneRequest = null;
        }
        if (Build.VERSION.SDK_INT >= 33 && systemBackCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(systemBackCallback);
            systemBackCallback = null;
        }
        if (!nativeAudioActive && !nativeHandoffRequested) stopBackgroundService();
        if (audioReceiverRegistered) {
            unregisterReceiver(audioControlReceiver);
            audioReceiverRegistered = false;
        }
        if (webView != null) {
            browserContainer.removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
