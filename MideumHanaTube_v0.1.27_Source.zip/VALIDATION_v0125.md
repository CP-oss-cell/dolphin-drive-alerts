# v0.1.25 정적/오프라인 검증 보고

- 기준본: v0.1.24 실사용 성공 버전
- 변경 범위: PIP 상단 아이콘 길게 누르기 -> 제어 프리셋 전환 + 모드 표시/로그
- 테스트: `tools/test-*.sh` 총 27개 전부 PASS (출력은 `VALIDATION_v0125_testlog.txt`에 저장)
- Java17 순수 로직 직접 컴파일/실행 PASS
- Java17 소스 구문 20개, XML/YAML 파싱 PASS
- PIP 10초 탐색 / 이전·다음 Android 동작은 기존 동작 경로 그대로 유지
- APK 전체 Gradle 컴파일: 미실행 (로컬 Android SDK 없음)
- 실제 폰에서 이전·다음 모드 전환: 미검증
- 광고 완전 차단, PiP 구간바, 다운로드 기능: 미구현
- GitHub Actions 빌드에서는 Java17 / Android36 SDK로 assembleDebug 후 결과 APK 서명·버전 검증
