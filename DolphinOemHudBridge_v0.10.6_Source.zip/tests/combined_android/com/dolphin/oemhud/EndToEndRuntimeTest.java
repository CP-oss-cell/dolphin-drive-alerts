package com.dolphin.oemhud;
import android.bluetooth.*;
import android.content.*;
import android.os.*;
public final class EndToEndRuntimeTest {
  private static int passed;
  private static void ok(boolean b,String label){if(!b)throw new AssertionError(label);passed++;System.out.println("PASS INTEGRATION "+label);}
  private static Intent tbt(int icon,String distance){return new Intent().setAction("AUTONAVI_STANDARD_BROADCAST_SEND").putExtra("KEY_TYPE",10001).putExtra("NEW_ICON",icon).putExtra("SEG_REMAIN_DIS_AUTO",distance);}
  public static void main(String[] args){
    Handler.reset();BluetoothGatt.automaticConnection=true;BluetoothGatt.discoverReply=true;BluetoothGatt.writeReply=true;BluetoothGatt.hasWriter=true;
    BridgeService b=new BridgeService();b.getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("enabled",true).putString("hud_mac","AA:BB:CC:11:22:33").putString("nav_package","com.example.autonavi").apply();
    b.onCreate();b.onStartCommand(null,0,1);Handler.advance(0);
    int start=BluetoothGatt.writes;
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_setting_write_completed",0)==0,"no setting write counted before nav");
    b.registered.onReceive(b,tbt(3,"1,200m"));
    ok(BluetoothGatt.writes==start+1,"OEM broadcast reaches REAL FFF2 GATT writer");
    ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D010500050004B02F"),"OEM grouped distance + turn code encoded exactly");
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_tx_completed",0)==1,"onCharacteristicWrite completed frame");
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_nav_callback_confirmed",0)==1,"actual navigation GATT callback counted separately");
    b.registered.onReceive(b,tbt(3,"1,200m"));
    ok(BluetoothGatt.writes==start+1,"same TBT deduplicated");
    b.registered.onReceive(b,tbt(11,"100m"));
    ok(BluetoothGatt.writes==start+1,"unverified turn icon fails closed");
    b.getSharedPreferences(BridgeLog.STORE,0).edit().putString("nav_package","com.tmap.auto.byd").apply();
    b.registered.onReceive(b,tbt(2,"70m"));
    ok(BluetoothGatt.writes==start+1,"OEM selected: fake AutoNavi broadcast cannot trigger turn");
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt("autonavi_ignored_for_oem",0)>=1,"OEM AutoNavi assumption counted as ignored");
    b.getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("enabled",false).apply();
    b.registered.onReceive(b,tbt(2,"50m"));
    ok(BluetoothGatt.writes==start+1,"user stop blocks OEM broadcasts");
    // Brightness schedule settings remain purely app-owned; no OEM signal writes.
    Intent schedule=new Intent().setAction(BridgeService.ACTION_BRIGHTNESS)
      .putExtra("auto",true).putExtra("source_mode",1)
      .putExtra("day",2).putExtra("night",0)
      .putExtra("day_start",6*60+30).putExtra("night_start",21*60+15);
    b.onStartCommand(schedule,0,3);
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt(HudBrightnessSchedule.KEY_DAY_START,-1)==390,
      "user day time saved");
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt(HudBrightnessSchedule.KEY_NIGHT_START,-1)==1275,
      "user night time saved");
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt(HudBrightnessSchedule.KEY_SOURCE,-1)==1,
      "manual clock-only mode saved");
    b.onStartCommand(new Intent().setAction(BridgeService.ACTION_BRIGHTNESS)
      .putExtra("auto",true).putExtra("source_mode",1).putExtra("day",2).putExtra("night",0)
      .putExtra("day_start",390).putExtra("night_start",390),0,4);
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getInt(HudBrightnessSchedule.KEY_NIGHT_START,-1)==1275,
      "equal start time rejected without overwriting saved schedule");
    b.onStartCommand(new Intent().setAction(BridgeService.ACTION_DISCONNECT),0,2);
    ok(b.getSharedPreferences(BridgeLog.STORE,0).getString("hud_mac",null)==null,"disconnect clears auto-connect MAC");
    b.onDestroy();
    System.out.println("REAL SERVICE + REAL CONNECTOR "+passed+" PASS");
  }
}
