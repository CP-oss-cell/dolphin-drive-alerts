#!/usr/bin/env python3
"""Checks source claims and retained verified BLE byte hashes (static only)."""
from pathlib import Path
import hashlib,csv,json
root=Path(__file__).resolve().parents[1]
r=root/'research/HUD-RE-012'
base=root/'app/src/main/java/com/dolphin/oemhud'
assert (r/'TECHNICAL_REPORT_KO.md').exists()
rows=list(csv.DictReader((r/'evidence/RESEARCH_001_012_DECISION_MATRIX.csv').open(encoding='utf-8-sig')))
assert len(rows)==12, len(rows)
checks=json.loads((r/'evidence/VERIFIED_BASE_COMPONENT_SHA256.json').read_text())
assert len(checks)==7
# Original RE-012 certificate describes v0.10.1/v0.10.2, not all future revisions.
# v0.10.4 intentionally changes the controller and its reconnection preference reader,
# while preserving the actual BLE/GATT packet encoder, profile and NavCue exactly.
intentional={'HudConnector.java','HudAutoBrightness.java','NavCue.java'}
assert {x['component'] for x in checks}&intentional==intentional
for item in checks:
 assert item['unchanged'] and item['v0102_sha256']==item['v0101_sha256'],item
 current=hashlib.sha256((base/item['component']).read_bytes()).hexdigest()
 if item['component'] in intentional:
  assert current!=item['v0101_sha256'], 'Expected reviewed update: '+item['component']
 else:
  assert current==item['v0101_sha256'], 'Unexpected modification: '+item['component']
s=(base/'BridgeService.java').read_text()
assert 'OemTmapStateSignal.NAVIGATION_STATE' in s and 'OemTmapStateSignal.MAP_ACTIVITY_STATE' in s
assert 'autonavi_ignored_for_oem' in s
assert 'signal.diagnostic()' in s and 'NavCue' not in (base/'OemTmapStateSignal.java').read_text()
acc=(base/'NavAccessibilityService.java').read_text()
assert 'append(out,NavCue.maneuverFromResourceId' not in acc
assert 'oem_direction_access' in acc and 'oem_tbt_distance_widgets_last' in acc
vehicle=(base/'OemVehicleIpcProbe.java').read_text()
assert 'getPackageInfo(' in vehicle and 'getActivityInfo(' in vehicle
assert 'getContentResolver().query(' not in vehicle and 'Binder.transact(' not in vehicle and 'Spi.getService(' not in vehicle
for x in ('HUD-RE-010/evidence/2602_LAYOUT_SUMMARY.json','HUD-RE-011/evidence/RE011_INTERFACE_SUMMARY.json'):
 assert (r/x).exists(),x
iface=json.loads((r/'HUD-RE-011/evidence/RE011_INTERFACE_SUMMARY.json').read_text())
assert iface['registered_service_instances']==23 and iface['unique_interface_methods']==91
print('PASS HUD-RE-012: 12-stage traceability, actual OEM state-only, no View ID direction, DiCar metadata-only')
print('PASS v0.10.2 historical 7/7 hashes valid; historical v0.10.5 evidence audit retained (current v0.10.6 changes audited separately)')
print('PASS upstream research evidence consistency: SPI services=23 unique methods=91')
print('NOTE: no real-car OEM TBT receiving or Android APK compilation is claimed')
