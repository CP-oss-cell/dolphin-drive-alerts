# v2.0.0 새 버전 통합 주의사항

- 이 버전은 v1.1.8 업데이트가 아닌 **독립 새 설치**. 기존 앱과 기존 다운로드 폴더는 삭제·이동하지 않음.
- 후속 업데이트는 com.mideumhana.browser 고정 + versionCode 증가 + 처음부터 같은 signing key 유지.
- 액티비티/서비스 자바 패키지와 namespace도 com.mideumhana.browser로 통일.
- `DownloadManager`의 직접 MP4 다운로드와 `StorageTarget`의 MediaStore 다운로드 경로 둘 다 `Download/믿음하나`.
- GitHub Actions 릴리즈 서명은 시크릿 2개가 없으면 실패하며, 임시 디버그키로 바꿔 빌드하지 않음.
- 사용자 선택 폴더가 있다면 그 값이 우선하고 기본값은 다운로드/믿음하나.

- Android 10 이상 DownloadManager API 수정: dirType은 DIRECTORY_DOWNLOADS 하나만 전달, subPath는 믿음하나/파일명으로 별도 전달.
