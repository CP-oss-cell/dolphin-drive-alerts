# 믿음하나 브라우저 — 첫 설치용 서명키 1회 설정

이 절차를 **v2.0.0 최초 설치 전**에 한 번만 진행하면, 이후 버전도 같은 서명키로 빌드할 수 있습니다.
GitHub Actions를 실행할 때마다 신규 키를 생성하지 않습니다.

### 1. 개인 키스토어 생성 (컴퓨터의 Java/JDK 17 필요)

터미널 또는 PowerShell에서 다음 명령 실행:

```bash
keytool -genkeypair -v -keystore MideumHanaBrowser-release.jks -storetype PKCS12 -alias mideumhana -keyalg RSA -keysize 3072 -validity 10000
```

비밀번호를 설정하고 기억하세요. PKCS12 키 암호는 저장소 암호와 동일하게 둡니다.
생성된 파일 `MideumHanaBrowser-release.jks`는 안전한 곳에 개인적으로 백업하고 **GitHub 파일 업로드/소스 ZIP에 넣지 마세요**.

### 2. 키스토어를 base64 한 줄로 변환

Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path '.\MideumHanaBrowser-release.jks')))
```

macOS / Linux:

```bash
base64 < MideumHanaBrowser-release.jks | tr -d '\n'
```

### 3. GitHub 저장소 Secrets 등록

GitHub 저장소 → **Settings → Secrets and variables → Actions → New repository secret**에서 아래 두 값을 만드세요:

- `MHB_KEYSTORE_BASE64` → 2단계에서 나온 base64 한 줄
- `MHB_KEYSTORE_PASSWORD` → 1단계 키스토어 비밀번호

암호·base64 내용을 채팅이나 소스 코드에 보내지 마세요.

### 4. APK 빌드

저장소 Actions → **믿음하나 브라우저 v2.0.0 Release APK** → Run workflow.
성공 후 Artifacts의 `MideumHanaBrowser_v2.0.0_Release_APK`를 내려받으세요.

다음 버전도 반드시 동일 GitHub Secrets/동일 키스토어를 사용하세요. 다음 버전에서는 `versionCode` 증가 및 두 빌드 ZIP/YML 이름도 새 버전으로 변경합니다.
