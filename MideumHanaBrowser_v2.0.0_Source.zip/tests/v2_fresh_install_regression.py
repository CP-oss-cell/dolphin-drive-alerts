from pathlib import Path
root = Path(__file__).resolve().parents[1]
java = root / 'app/src/main/java/com/mideumhana/browser'
build = (root / 'app/build.gradle').read_text()
assert "namespace 'com.mideumhana.browser'" in build
assert "applicationId 'com.mideumhana.browser'" in build
assert 'versionCode 1' in build and "versionName '2.0.0'" in build
assert "signingConfig signingConfigs.mhbRelease" in build
assert "MHB_SIGNING_KEYSTORE_PATH" in build and "MHB_SIGNING_PASSWORD" in build
assert "keyAlias 'mideumhana'" in build
storage = (java / 'StorageTarget.java').read_text()
activity = (java / 'MainActivity.java').read_text()
service = (java / 'HlsDownloadService.java').read_text()
layout = (root/'app/src/main/res/layout/activity_main.xml').read_text()
assert 'Environment.DIRECTORY_DOWNLOADS + "/믿음하나"' in storage
assert 'Environment.DIRECTORY_DOWNLOADS, "믿음하나/" + filename' in activity
assert '다운로드/믿음하나' in storage and '다운로드/믿음하나' in service
assert '다운로드/믿음하나' in layout
for f in java.glob('*.java'):
    assert f.read_text().startswith('package com.mideumhana.browser;'), f
assert 'CleanVideo' not in (storage+activity+service+layout)
print('V2_FRESH_INSTALL_AND_NEW_FOLDER_OK')
