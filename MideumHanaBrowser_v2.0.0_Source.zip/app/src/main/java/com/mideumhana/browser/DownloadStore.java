package com.mideumhana.browser;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Records downloads only on this device; never sends URLs or usage information out. */
final class DownloadStore {
    private static final String PREFS = "mideumhana_local_v2";
    private static final String KEY = "downloads";

    private DownloadStore() {}

    static synchronized void add(Context c, String id, String type, String name) {
        JSONArray all = loadArray(c);
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("type", type);
            o.put("name", name);
            o.put("status", "대기 중");
            o.put("progress", 0);
            o.put("created", System.currentTimeMillis());
            JSONArray result = new JSONArray();
            result.put(o);
            for (int i = 0; i < all.length() && i < 299; i++) result.put(all.optJSONObject(i));
            save(c, result);
        } catch (Exception ignored) { }
    }

    static synchronized void update(Context c, String id, String status, int progress) {
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) {
                try {
                    o.put("status", status);
                    o.put("progress", Math.max(0, Math.min(100, progress)));
                    save(c, all);
                } catch (Exception ignored) { }
                break;
            }
        }
    }

    static synchronized void setUri(Context c, String id, String uri) {
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) {
                try { o.put("uri", uri); save(c, all); }
                catch (Exception ignored) { }
                break;
            }
        }
    }

    static synchronized List<JSONObject> list(Context c) {
        List<JSONObject> result = new ArrayList<>();
        JSONArray all = loadArray(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o != null) result.add(o);
        }
        return result;
    }

    private static JSONArray loadArray(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try { return new JSONArray(p.getString(KEY, "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray arr) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, arr.toString()).commit();
    }

    static String safeFileName(String candidate) {
        if (candidate == null) candidate = "video.mp4";
        String s = candidate.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        s = s.replaceAll("^\\.+", "");
        if (s.length() > 110) {
            int dot = s.lastIndexOf('.');
            String ext = dot > 0 ? s.substring(dot) : "";
            s = s.substring(0, Math.min(100, s.length())) + ext;
        }
        return s.isEmpty() ? "video.mp4" : s;
    }
}
