# v2.0.0 빌드/회귀 검증

- 소스: 새 Android applicationId 및 Java namespace, versionCode 1, versionName 2.0.0
- 저장 위치: Download/믿음하나 (DownloadManager/MediaStore/UI/서비스 문구 모두 변경)
- 릴리즈 서명: GitHub Actions 시크릿 2개 필수, 소스에 키스토어 포함 금지
- Gradle/Android APK 빌드: **이 환경에 SDK 미설치, 수행하지 못함**
- 실제 기기 설치·다운로드: **미검증**
- Android 공식 DownloadManager API 요구에 맞게 dirType과 하위 경로를 분리하는 회귀 테스트 추가
