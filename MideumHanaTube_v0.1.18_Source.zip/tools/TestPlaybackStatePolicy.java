package app.mideumhanatube.android;
public final class TestPlaybackStatePolicy {
    private static int count;
    static void eq(PlaybackStatePolicy.Phase expected, PlaybackStatePolicy.Phase actual) {
        if (actual != expected) throw new AssertionError("expected " + expected + " got " + actual);
        count++;
    }
    static void check(boolean value) { if (!value) throw new AssertionError(); count++; }
    public static void main(String[] args) {
        eq(PlaybackStatePolicy.Phase.RESOLVING, PlaybackStatePolicy.classify(true,true,1,false,0));
        eq(PlaybackStatePolicy.Phase.BUFFERING, PlaybackStatePolicy.classify(false,true,2,false,0));
        eq(PlaybackStatePolicy.Phase.PAUSED, PlaybackStatePolicy.classify(false,false,2,false,0));
        eq(PlaybackStatePolicy.Phase.READY_WAIT, PlaybackStatePolicy.classify(false,true,3,false,0));
        eq(PlaybackStatePolicy.Phase.PLAYING, PlaybackStatePolicy.classify(false,true,3,true,0));
        eq(PlaybackStatePolicy.Phase.SUPPRESSED, PlaybackStatePolicy.classify(false,true,3,false,1));
        eq(PlaybackStatePolicy.Phase.SUPPRESSED, PlaybackStatePolicy.classify(false,true,3,true,2));
        eq(PlaybackStatePolicy.Phase.ENDED, PlaybackStatePolicy.classify(false,true,4,false,0));
        eq(PlaybackStatePolicy.Phase.IDLE, PlaybackStatePolicy.classify(false,true,1,false,0));
        eq(PlaybackStatePolicy.Phase.PAUSED, PlaybackStatePolicy.classify(true,false,2,false,0));
        check(PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.RESOLVING));
        check(PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.BUFFERING));
        check(PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.PLAYING));
        check(PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.READY_WAIT));
        check(PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.SUPPRESSED));
        check(!PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.PAUSED));
        check(!PlaybackStatePolicy.keepForeground(PlaybackStatePolicy.Phase.ENDED));
        check(PlaybackStatePolicy.isTerminal(PlaybackStatePolicy.Phase.IDLE));
        check(!PlaybackStatePolicy.isTerminal(PlaybackStatePolicy.Phase.BUFFERING));
        System.out.println("PlaybackStatePolicy " + count + " tests PASS");
    }
}
