#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" \
 "$ROOT/app/src/main/java/app/mideumhanatube/android/PlaybackStatePolicy.java" \
 "$ROOT/tools/TestPlaybackStatePolicy.java"
java -cp "$TMP" app.mideumhanatube.android.TestPlaybackStatePolicy
