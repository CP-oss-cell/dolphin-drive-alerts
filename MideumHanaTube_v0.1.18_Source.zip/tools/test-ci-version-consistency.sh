#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY_CI'
from pathlib import Path
import re
archive = 'MideumHanaTube_v0.1.18_Source.zip'
expected = re.fullmatch(r'MideumHanaTube_v(\d+\.\d+\.\d+)_Source\.zip',archive).group(1)
gradle = Path('app/build.gradle').read_text()
workflow = Path('.github/workflows/MideumHanaTube_v0.1.18_Source.yml').read_text()
version = re.search(r"\bversionName\s+'([^']+)'",gradle).group(1)
code = int(re.search(r'\bversionCode\s+(\d+)',gradle).group(1))
assert version == expected, (version, expected)
assert code > 0
assert 'Version mismatch: source archive' in workflow
assert 'MHT_VERSION_CODE' in workflow and 'MHT_VERSION_NAME' in workflow
assert "grep -q \"versionName '0.1.17'\"" not in workflow
assert 'Find MideumHanaTube project' in workflow
print('CI/source version consistency PASS:',version,code)
PY_CI
