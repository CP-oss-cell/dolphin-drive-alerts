import app.mideumhanatube.android.BookmarkSavePolicy;
import app.mideumhanatube.android.BookmarkTitleResolver;
import app.mideumhanatube.android.YouTubeOEmbedUrl;

public final class TestBookmarkSavePolicy {
  private static int tests;
  private static void yes(boolean b,String message) {tests++;if(!b)throw new AssertionError(message);}
  private static void equal(String a,String b,String message) {tests++;if(!a.equals(b))throw new AssertionError(message+" "+a+" != "+b);}
  public static void main(String[] args) {
    String watch="https://m.youtube.com/watch?v=po7TeGgcXSM";
    yes(!BookmarkSavePolicy.isActualTitle("영상 · po7TeGgcXSM",watch),"no id fallback");
    yes(!BookmarkSavePolicy.isActualTitle("YouTube",watch),"no generic title");
    yes(!BookmarkSavePolicy.isActualTitle("라이브 · po7TeGgcXSM",watch),"no live id");
    yes(!BookmarkSavePolicy.isActualTitle("유튜브 · foo",watch),"no fake page name");
    yes(!BookmarkSavePolicy.isActualTitle("재생목록 · PLabc123",watch),"no playlist id");
    yes(BookmarkSavePolicy.isActualTitle("정상 영상 제목",watch),"good name accepted");
    equal(BookmarkSavePolicy.simplePageName("https://m.youtube.com/"),"유튜브 홈","home");
    equal(BookmarkSavePolicy.simplePageName("https://m.youtube.com/results?search_query=Kpop"),"검색 · Kpop","search");
    yes(BookmarkSavePolicy.simplePageName(watch)==null,"no video default");
    String endpoint=YouTubeOEmbedUrl.forSource(watch);
    yes(endpoint.startsWith("https://www.youtube.com/oembed?format=json&url="),"oembed endpoint");
    yes(endpoint.contains("po7TeGgcXSM"),"proper ID passed");
    yes(YouTubeOEmbedUrl.forSource("https://evil.com/watch?v=po7TeGgcXSM")==null,"no external host");
    yes(YouTubeOEmbedUrl.forSource("https://youtube.com.evil.com/watch?v=po7TeGgcXSM")==null,"no fake subdomain");
    yes(YouTubeOEmbedUrl.forSource("http://youtube.com/watch?v=po7TeGgcXSM")==null,"HTTPS only");
    yes(YouTubeOEmbedUrl.forSource("https://m.youtube.com/watch?v=bad")==null,"invalid ID");
    yes(YouTubeOEmbedUrl.forSource("https://m.youtube.com/watch?v=po7TeGgcXSM&token=myprivatekey").contains("myprivatekey")==false,"strip query extras");
    yes(YouTubeOEmbedUrl.forSource("https://www.youtube.com/shorts/po7TeGgcXSM")!=null,"shorts metadata");
    yes(YouTubeOEmbedUrl.forSource("https://www.youtube.com/playlist?list=PL1234567")!=null,"playlist metadata");
    yes(BookmarkTitleResolver.resolve("영상 제목",null,watch).equals("영상 제목"),"metadata resolution");
    System.out.println("Bookmark save policy tests PASS "+tests);
  }
}
