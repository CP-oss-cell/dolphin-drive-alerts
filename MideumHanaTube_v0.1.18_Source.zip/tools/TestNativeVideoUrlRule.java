package app.mideumhanatube.android;
public class TestNativeVideoUrlRule {
  public static void main(String[] args) {
    String[] ok={
      "https://m.youtube.com/watch?v=po7TeGgcXSM",
      "https://www.youtube.com/watch?v=po7TeGgcXSM&t=50s",
      "https://youtube.com/shorts/po7TeGgcXSM",
      "https://youtu.be/po7TeGgcXSM",
      "https://www.youtube.com/live/po7TeGgcXSM"
    };
    String[] not={
      "http://m.youtube.com/watch?v=po7TeGgcXSM",
      "https://youtube.com.evil.com/watch?v=po7TeGgcXSM",
      "https://www.youtube.com@evil.com/watch?v=po7TeGgcXSM",
      "https://evil.com/?v=po7TeGgcXSM",
      "https://m.youtube.com/",
      "https://m.youtube.com/watch?foo=bar",
      "https://m.youtube.com/watch?v=short",
      "https://m.youtube.com:8443/watch?v=po7TeGgcXSM",
      "javascript:alert(1)",null
    };
    for(String s:ok)if(!NativeVideoUrlRule.isVideoPage(s))throw new AssertionError("expected accept: "+s);
    for(String s:not)if(NativeVideoUrlRule.isVideoPage(s))throw new AssertionError("expected reject: "+s);
    System.out.println("Native video URL policy: "+(ok.length+not.length)+" tests PASS");
  }
}
