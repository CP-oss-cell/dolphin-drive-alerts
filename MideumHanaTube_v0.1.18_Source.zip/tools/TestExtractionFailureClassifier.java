package app.mideumhanatube.android;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

public final class TestExtractionFailureClassifier {
    static void eq(String want, String got) {
        if (!want.equals(got)) throw new AssertionError(want + " != " + got);
    }
    static final class Denied extends IOException implements ExtractionFailureClassifier.HttpStatusHint {
        @Override public int statusCode() { return 403; }
    }
    static final class Throttled extends IOException implements ExtractionFailureClassifier.HttpStatusHint {
        @Override public int statusCode() { return 429; }
    }
    static final class ParseException extends Exception { }
    public static void main(String[] args) {
        eq("HTTP_403", ExtractionFailureClassifier.classify(new IOException("unsafe-private-url", new Denied())));
        eq("HTTP_429", ExtractionFailureClassifier.classify(new Throttled()));
        eq("NETWORK_TIMEOUT", ExtractionFailureClassifier.classify(new IOException(new SocketTimeoutException())));
        eq("NETWORK_DNS", ExtractionFailureClassifier.classify(new UnknownHostException()));
        eq("EXTRACTOR_PARSE", ExtractionFailureClassifier.classify(new ParseException()));
        eq("INVALID_INPUT", ExtractionFailureClassifier.classify(new IllegalArgumentException("token-secret")));
        eq("Denied", ExtractionFailureClassifier.safeClassName(new Denied()));
        eq("Unknown", ExtractionFailureClassifier.safeClassName(null));
        System.out.println("8 privacy-safe extractor categorization tests PASS");
    }
}
