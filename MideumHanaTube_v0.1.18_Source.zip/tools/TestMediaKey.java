package app.mideumhanatube.android;
public final class TestMediaKey {
  private static void assertSame(String a, String b) {
    String x = YouTubeStreamResolver.canonicalMediaKey(a), y = YouTubeStreamResolver.canonicalMediaKey(b);
    if (!x.equals(y)) throw new AssertionError(x + " != " + y);
  }
  public static void main(String[] args) {
    assertSame("https://www.youtube.com/watch?v=po7TeGgcXSM", "https://m.youtube.com/watch?v=po7TeGgcXSM&t=12&list=abc");
    assertSame("https://www.youtube.com/shorts/po7TeGgcXSM", "https://youtu.be/po7TeGgcXSM");
    assertSame("https://www.youtube.com/live/po7TeGgcXSM", "https://www.youtube.com/watch?v=po7TeGgcXSM");
    System.out.println("MediaKey test passed");
  }
}
