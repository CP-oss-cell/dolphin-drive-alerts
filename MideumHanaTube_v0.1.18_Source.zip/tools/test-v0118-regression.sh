#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY2'
from pathlib import Path
s=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
r=Path('app/src/main/java/app/mideumhanatube/android/YouTubeStreamResolver.java').read_text()
m=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
c=Path('app/src/main/assets/cleaner.js').read_text()
for v in ('EXTRACT_CACHE_HIT','isValidPrefetchedStream(url)','mediaKey.equals(failedPrefetchUrl)','prefetchRunning && mediaKey.equals(prefetchedUrl)'):
 assert v in s,v
assert 'StreamInfo.getInfo(canonicalMediaKey(youtubeUrl))' in r
assert 'PARSE_AFTER_NETWORK_OBSERVED' in r
assert 'yt-navigate-finish' in c
assert 'SPA: navigating' in m
print('v0.1.18 static regressions passed')
PY2
node --check app/src/main/assets/cleaner.js
