import app.mideumhanatube.android.VoicePermissionPolicy;

public final class TestVoicePermissionPolicy {
    private static int assertions;
    private static void check(boolean condition, String description) {
        ++assertions;
        if (!condition) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        String[] allow = {
            "https://m.youtube.com", "https://www.youtube.com", "https://youtube.com",
            "https://music.youtube.com", "HTTPS://M.YOUTUBE.COM", "https://m.youtube.com:443"
        };
        for (String value : allow) check(VoicePermissionPolicy.isTrustedOrigin(value), "should allow " + value);
        String[] deny = {
            "http://m.youtube.com", "https://m.youtube.com.evil.net", "https://youtube.com.attacker.org",
            "https://evil.youtube.com", "https://m.youtube.com:444", "https://user@m.youtube.com",
            "https://m.youtube.com@evil.net", "file:///android_asset/test.html", "https://google.com",
            "not-a-url", "https://youtube-music.com", "https://youtu.be"
        };
        for (String value : deny) check(!VoicePermissionPolicy.isTrustedOrigin(value), "should deny " + value);
        check(!VoicePermissionPolicy.isTrustedOrigin(null), "null rejected");
        String audio = "android.webkit.resource.AUDIO_CAPTURE";
        String camera = "android.webkit.resource.VIDEO_CAPTURE";
        check(VoicePermissionPolicy.isAudioOnly(new String[]{audio}, audio), "audio only accepted");
        check(!VoicePermissionPolicy.isAudioOnly(new String[]{camera}, audio), "camera denied");
        check(!VoicePermissionPolicy.isAudioOnly(new String[]{audio, camera}, audio), "audio+camera denied");
        check(!VoicePermissionPolicy.isAudioOnly(new String[]{}, audio), "empty denied");
        check(!VoicePermissionPolicy.isAudioOnly(null, audio), "null denied");
        System.out.println("Voice origin/resource policy: " + assertions + " assertions PASS");
    }
}
