package app.mideumhanatube.android;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class TestPlaybackQueue {
    private static void eq(Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError("expected="+expected+" actual="+actual);
    }
    public static void main(String[] args) {
        PlaybackQueue q = new PlaybackQueue(new Random(44));
        List<PlaybackQueue.Track> a = new ArrayList<>();
        for (int i=0; i<5; i++) a.add(new PlaybackQueue.Track("https://www.youtube.com/watch?v=abcdefghij"+i,"곡"+i));
        q.setTracks(a,0); eq(5,q.size()); eq("곡0",q.current().title);
        if(q.previous()!=null) throw new AssertionError("no previous in OFF");
        eq("곡1",q.next(false).title);
        q.setRepeatMode(PlaybackQueue.ONE); eq("곡1",q.next(true).title);
        eq("곡2",q.next(false).title);
        q.setRepeatMode(PlaybackQueue.ALL);
        q.next(false); q.next(false); eq("곡4",q.current().title);
        eq("곡0",q.next(true).title); eq("곡4",q.previous().title);
        q.setShuffle(true); eq("곡4",q.current().title);
        q.setRepeatMode(PlaybackQueue.OFF);
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        PlaybackQueue.Track t=q.current();
        while(t!=null) { if(!seen.add(t.url)) throw new AssertionError("duplicate shuffle");t=q.next(false); }
        eq(5,seen.size()); eq(true,q.shuffle());
        q.setShuffle(false);eq(false,q.shuffle());
        q.clear();eq(0,q.size());if(q.next(false)!=null)throw new AssertionError("empty next");
        q.setTracks(a, 0);eq(PlaybackQueue.ONE,q.cycleRepeat());eq(PlaybackQueue.ALL,q.cycleRepeat());
        eq(PlaybackQueue.OFF,q.cycleRepeat());
        System.out.println("PlaybackQueue cases PASS");
    }
}
