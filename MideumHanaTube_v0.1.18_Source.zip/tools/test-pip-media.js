'use strict';
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const root = path.resolve(__dirname, '..');
const enter = fs.readFileSync(path.join(root, 'app/src/main/assets/pip-video-enter.js'), 'utf8');
const exit = fs.readFileSync(path.join(root, 'app/src/main/assets/pip-video-exit.js'), 'utf8');
let checks = 0;
const check = (ok, msg) => { if (!ok) throw new Error(msg); checks++; };
function dom(playing) {
  const styles = [];
  const mk = (name) => ({
    name, style: {},
    classList: { classes: new Set(), add(v) { this.classes.add(v); }, remove(v) { this.classes.delete(v); }, contains(v) { return this.classes.has(v); } },
    parentElement: null
  });
  const html = mk('html'), body = mk('body'), parent = mk('parent'), video = mk('video');
  parent.parentElement = body;
  video.parentElement = parent;
  Object.assign(video, { paused: !playing, ended: false, readyState: 4, currentTime: 158.75 });
  let playCalls = 0, pauseCalls = 0;
  video.play = () => { playCalls++; };
  video.pause = () => { pauseCalls++; };
  const document = {
    body, documentElement: html,
    head: { appendChild(node) { styles.push(node); node.parentNode = { removeChild(n) { styles.splice(styles.indexOf(n), 1); } }; } },
    createElement(type) { return { tagName: type, textContent: '', id: null }; },
    getElementById(id) { return styles.find(x => x.id === id) || null; },
    querySelectorAll(selector) {
      if (selector === 'video') return [video];
      if (selector === '.mht-pip-ancestor') return [parent, video].filter(v => v.classList.contains('mht-pip-ancestor'));
      if (selector === 'video.mht-pip-selected') return video.classList.contains('mht-pip-selected') ? [video] : [];
      return [];
    }
  };
  const context = vm.createContext({ document, window: {}, JSON });
  return { context, video, html, body, parent, styles, calls: () => [playCalls, pauseCalls] };
}
let x = dom(true);
let result = JSON.parse(vm.runInContext(enter, x.context));
check(result.ready === true, 'Active video must enter PiP mode');
check(x.video.classList.contains('mht-pip-selected'), 'Active video must be selected');
check(x.parent.classList.contains('mht-pip-ancestor'), 'Video ancestry must be isolated');
check(x.body.classList.contains('mht-pip-isolation'), 'Page must enter isolated mode');
check(x.styles.length === 1, 'PiP style must be installed');
check(x.styles[0].textContent.includes('visibility:hidden'), 'Non-video page content must be hidden');
check(x.styles[0].textContent.includes('object-fit:contain'), 'Video must fit PiP bounds');
check(x.video.currentTime === 158.75, 'Video time must not reset on PiP entry');
check(JSON.parse(vm.runInContext(enter, x.context)).already === true, 'Entering twice must be idempotent');
check(x.styles.length === 1, 'Repeated enter must not duplicate styles');
vm.runInContext(exit, x.context);
check(x.styles.length === 0, 'PiP style must be removed on exit');
check(!x.video.classList.contains('mht-pip-selected'), 'Video selection must be cleared on exit');
check(!x.body.classList.contains('mht-pip-isolation'), 'Body must return to normal on exit');
check(x.video.currentTime === 158.75, 'Video time must not reset on exit');
check(x.calls()[0] === 0 && x.calls()[1] === 0, 'PiP must not force play/pause');
x = dom(false);
result = JSON.parse(vm.runInContext(enter, x.context));
check(result.ready === false && result.reason === 'NO_PLAYING_VIDEO', 'PiP must reject missing playing video');
check(x.styles.length === 0, 'Failed enter must not modify document');
console.log('PiP DOM lifecycle:', checks, 'checks passed');
