const fs = require('fs');
const vm = require('vm');
const script = fs.readFileSync('app/src/main/assets/bookmark-title.js','utf8');
new Function('return ' + script + ';');
let cases = 0;
function test(name, url, selectors, pageTitle, metaTitle, playerData, expected) {
  const u = new URL(url);
  const dom = {title:pageTitle,querySelector:(selector)=> {
    if ((selector==='meta[property="og:title"]'||selector==='meta[name="title"]') && metaTitle)
      return {content:metaTitle};
    const str = selectors[selector];
    return str ? {textContent:str,getAttribute:()=>null} : null;
  }};
  const data = vm.runInNewContext(script, {
    document:dom,
    location:{href:url, pathname:u.pathname,search:u.search},
    URL, window:{ytInitialPlayerResponse: playerData || null}
  });
  const parsed=JSON.parse(data);
  if(parsed.title !== expected || parsed.url !== url)
    throw Error(name+': expected '+expected+' got '+JSON.stringify(parsed));
  cases++;
}
const watch='https://m.youtube.com/watch?v=po7TeGgcXSM';
test('mobile title available at bookmark tap',watch,{'ytm-watch-metadata h1':'아저씨 차 빼세요 예능 명장면'},'YouTube','',null,'아저씨 차 빼세요 예능 명장면');
test('player response currently loaded title',watch,{},'YouTube','',{videoDetails:{videoId:'po7TeGgcXSM',title:'정확한 제목 - 저장 즉시'}},'정확한 제목 - 저장 즉시');
test('desktop watch',watch,{'ytd-watch-metadata h1 yt-formatted-string':'실제 데스크톱 제목'},'YouTube','',null,'실제 데스크톱 제목');
test('short', 'https://m.youtube.com/shorts/po7TeGgcXSM',{'h1.slim-video-metadata-title':'쇼츠 원래 제목'},'YouTube','',null,'쇼츠 원래 제목');
test('playlist', 'https://m.youtube.com/playlist?list=PLgood',{'ytd-playlist-header-renderer h1':'플레이리스트 실제 제목'},'YouTube','',null,'플레이리스트 실제 제목');
test('channel', 'https://m.youtube.com/@test',{'ytm-channel-header-renderer h1':'예제 채널명'},'YouTube','',null,'예제 채널명');
test('meta',watch,{},'YouTube','오픈그래프 실제 제목',null,'오픈그래프 실제 제목');
test('fallback generic',watch,{},'YouTube','',null,'YouTube');
test('stale player is ignored',watch,{},'다른 영상 제목 - YouTube','오래된 메타 제목',{videoDetails:{videoId:'AAAAAAAAAAA',title:'오래된 영상 제목'}},'');
console.log('Embedded metadata JS tests PASS',cases);
