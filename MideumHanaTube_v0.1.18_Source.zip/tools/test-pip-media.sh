#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
node --check "$ROOT/app/src/main/assets/pip-video-enter.js"
node --check "$ROOT/app/src/main/assets/pip-video-exit.js"
node "$ROOT/tools/test-pip-media.js"
python3 - "$ROOT" <<'PY'
import pathlib, sys, xml.etree.ElementTree as ET
p=pathlib.Path(sys.argv[1]); main=(p/'app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
svc=(p/'app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
ns='{http://schemas.android.com/apk/res/android}'
xml=ET.parse(p/'app/src/main/AndroidManifest.xml').getroot();activity=next(a for a in xml.findall('application/activity') if a.get(ns+'name')=='.MainActivity')
conf=set(activity.get(ns+'configChanges','').split('|'))
assert {'screenSize','smallestScreenSize','orientation','screenLayout'}<=conf,conf
assert activity.get(ns+'supportsPictureInPicture')=='true'
segment=main.split('private void enterPip()')[1].split('private void updateStatus()')[0]
for disallowed in ['webView.reload()', 'webView.loadUrl(', 'webView.destroy()', 'webView = new WebView(', 'recreate()']:
 assert disallowed not in segment, 'PiP must preserve active web player: '+disallowed
assert 'setPipChromeHidden(true)' in segment and 'statusStrip.setVisibility' in segment
assert 'exitPipVideoIsolation()' in segment
assert 'setSourceRectHint' in segment
assert 'Uri link = intent == null ? null : intent.getData();' in main
assert 'navigateInitial(intent);' not in main.split('onNewIntent(Intent intent)')[1].split('private void search()')[0]
assert 'ACTION_FEEDBACK' in svc and 'awaitingPlaybackConfirmation' in svc
assert 'playing = ACTION_PLAY.equals(action)' not in svc
assert 'verifyPlayerCommand(' in main
print('PiP/Media source regression: 12 checks passed')
PY
