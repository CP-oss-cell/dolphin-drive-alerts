'use strict';
const assert = require('assert');
const vm = require('vm');
const fs = require('fs');
const source = fs.readFileSync('app/src/main/assets/youtube-mic-bridge.js','utf8');
let handler = null, prompts = [], count = 0;
const doc = { addEventListener(type, cb, capture){ assert.strictEqual(type,'click'); assert.strictEqual(capture,true); handler = cb; count++; } };
const win = { prompt(a,b){ prompts.push(a); return ''; } };
const context = {window:win, document:doc};
vm.runInNewContext(source,context);
vm.runInNewContext(source,context);
assert.strictEqual(count,1, 'bridge listener must register exactly once');
function node(label, id = '') {return { nodeType:1, getAttribute(k){return k==='aria-label'?label:null;}, id, className:'' };}
function emit(path, trusted=true){let prevent=0,stop=0,immediate=0;handler({isTrusted:trusted,target:path[0],composedPath:()=>path,preventDefault(){prevent++;}, stopPropagation(){stop++;}, stopImmediatePropagation(){immediate++;}});return [prevent,stop,immediate];}
assert.deepStrictEqual(emit([node('Search with your voice')]),[1,1,1]);
assert.strictEqual(prompts.length,1);
assert.deepStrictEqual(emit([node('음성으로 검색')]),[1,1,1]);
assert.deepStrictEqual(emit([node(''),node('', 'voice-search-button')]),[1,1,1]);
assert.deepStrictEqual(emit([node('Search')]),[0,0,0]);
assert.deepStrictEqual(emit([node('Microphone')], false),[0,0,0]);
assert.strictEqual(prompts.length,3);
assert.ok(prompts.every(v=>v==='MHT_YOUTUBE_VOICE_SEARCH_0111'));
console.log('PASS: YouTube page microphone bridge cases (captured mic, Korean/English, shadow nodes, dedup, nonvoice, synthetic events)');
