#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/mht-syntax
javac -encoding UTF-8 -d /tmp/mht-syntax tools/JavaSyntaxCheck.java
mapfile -t sources < <(find app/src/main/java -type f -name '*.java' | sort)
java -cp /tmp/mht-syntax JavaSyntaxCheck "${sources[@]}"
python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path
import yaml
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
for p in Path('.github/workflows').glob('*.yml'):
    assert yaml.safe_load(p.read_text())
print('XML and GitHub YAML syntax PASS')
PY
