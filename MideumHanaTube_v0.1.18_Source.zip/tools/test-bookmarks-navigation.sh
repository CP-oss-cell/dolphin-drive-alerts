#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf /tmp/mht-bookmark-test
mkdir -p /tmp/mht-bookmark-test
javac -encoding UTF-8 -d /tmp/mht-bookmark-test \
  app/src/main/java/app/mideumhanatube/android/BookmarkTitleResolver.java \
  app/src/main/java/app/mideumhanatube/android/BookmarkSavePolicy.java \
  app/src/main/java/app/mideumhanatube/android/YouTubeOEmbedUrl.java \
  tools/TestBookmarkTitle.java tools/TestBookmarkSavePolicy.java
java -cp /tmp/mht-bookmark-test TestBookmarkTitle
java -cp /tmp/mht-bookmark-test TestBookmarkSavePolicy
node tools/test-page-title.js
MAIN=app/src/main/java/app/mideumhanatube/android/MainActivity.java
MANIFEST=app/src/main/AndroidManifest.xml
grep -q 'registerOnBackInvokedCallback' "$MAIN"
grep -q 'unregisterOnBackInvokedCallback' "$MAIN"
grep -q 'webView.canGoBack()' "$MAIN"
grep -q 'webView.goBack()' "$MAIN"
grep -q 'android:enableOnBackInvokedCallback="true"' "$MANIFEST"
grep -q 'requestTitleForBookmark(url, requestId, 0)' "$MAIN"
grep -q 'showBookmarkTitleInput(url)' "$MAIN"
grep -q 'YouTubeOEmbedTitle.fetch(url)' "$MAIN"
! grep -q 'EXTRACT_PAGE_TITLE_JS' "$MAIN"
grep -q 'repairGenericTitles' "$MAIN"
grep -q 'renameBookmark' "$MAIN"
echo 'Navigation / bookmark structural checks PASS'
