import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import com.sun.source.util.JavacTask;

/** Parse source-only Java syntax without needing an Android SDK classpath. */
public class JavaSyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diag = new DiagnosticCollector<>();
        try (StandardJavaFileManager fm = compiler.getStandardFileManager(diag, null, null)) {
            List<File> files = new ArrayList<>();
            for (String path : args) files.add(new File(path));
            Iterable<? extends JavaFileObject> units = fm.getJavaFileObjectsFromFiles(files);
            JavacTask task = (JavacTask) compiler.getTask(null, fm, diag,
                    Arrays.asList("-proc:none", "-source", "17"), null, units);
            int parsed = 0;
            for (Object tree : task.parse()) parsed++;
            for (Diagnostic<? extends JavaFileObject> d : diag.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.ERROR) {
                    System.err.println(d);
                    System.exit(2);
                }
            }
            if (parsed != files.size()) throw new AssertionError("Parsed " + parsed + " files but expected " + files.size());
            System.out.println("Java 17 source syntax parsed: " + parsed + " files PASS");
        }
    }
}
