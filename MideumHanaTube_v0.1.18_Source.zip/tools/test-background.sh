#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT" <<'PY'
import pathlib, sys, xml.etree.ElementTree as ET
p=pathlib.Path(sys.argv[1]); a=p/'app/src/main/java/app/mideumhanatube/android'
activity=(a/'MainActivity.java').read_text(); svc=(a/'BackgroundAudioService.java').read_text()
manifest=ET.parse(p/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
perms={x.get(ns+'name') for x in manifest.findall('uses-permission')}
for permission in ['android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.WAKE_LOCK','android.permission.POST_NOTIFICATIONS']:
 assert permission in perms,permission
service=manifest.find('application/service')
assert service is not None and service.get(ns+'foregroundServiceType')=='mediaPlayback'
assert 'if (webView != null && (exiting || !backgroundAudio) && !isInPictureInPictureMode()) webView.onPause();' in activity
assert 'startForegroundService(intent)' in activity
assert 'attemptBackgroundResumptionOnce' in activity
assert 'PLAYBACK_PROBE_JS' in activity
assert 'Notification.MediaStyle' in svc and 'MediaSession' in svc
assert 'ACTION_STOP' in svc and 'ACTION_PAUSE' in svc and 'ACTION_PLAY' in svc
assert 'startForeground(NOTIFICATION_ID, notification)' in svc
assert 'wakeLock.acquire()' in svc and 'releaseWakeLock()' in svc
assert 'newWakeLock(PowerManager.PARTIAL_WAKE_LOCK' in svc
print('Background-audio structural tests: 16 checks passed')
PY
