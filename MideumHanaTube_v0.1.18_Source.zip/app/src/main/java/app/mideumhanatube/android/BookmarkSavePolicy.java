package app.mideumhanatube.android;

import java.net.URI;

/** Only meaningful user-facing titles should enter the bookmark list. */
public final class BookmarkSavePolicy {
    private BookmarkSavePolicy() {}

    public static boolean isActualTitle(String title, String url) {
        if (title == null || title.trim().isEmpty()) return false;
        if (BookmarkTitleResolver.isFallback(title)) return false;
        // On a watch page, an old YouTube document.title may belong to another video.
        return !title.matches("(?i)(video|shorts|live)\\s*[·:]\\s*[A-Za-z0-9_-]{6,}");
    }

    public static String simplePageName(String url) {
        if (url == null) return null;
        try {
            URI uri = URI.create(url);
            String path = uri.getPath();
            if (path == null || path.equals("/") || path.isEmpty()) return "유튜브 홈";
            if (path.equals("/results")) return BookmarkTitleResolver.fallbackForUrl(url);
        } catch (RuntimeException ignored) { }
        return null;
    }
}
