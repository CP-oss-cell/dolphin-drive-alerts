package app.mideumhanatube.android;

import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Strictly validated, parameter-reduced public YouTube oEmbed link. */
public final class YouTubeOEmbedUrl {
    private YouTubeOEmbedUrl() { }
    public static String forSource(String source) {
        if (source == null) return null;
        try {
            URI uri = URI.create(source);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return null;
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (!(host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be"))) return null;
            String path = uri.getPath() == null ? "" : uri.getPath();
            String canonical = null;
            if (host.equals("youtu.be") && path.length() > 1) {
                String id = path.substring(1).split("/")[0];
                if (validVideoId(id)) canonical = "https://www.youtube.com/watch?v=" + id;
            } else if (path.equals("/watch")) {
                String id = queryParameter(uri.getRawQuery(), "v");
                if (validVideoId(id)) canonical = "https://www.youtube.com/watch?v=" + id;
            } else if (path.startsWith("/shorts/") || path.startsWith("/live/")) {
                String id = path.substring(path.indexOf('/', 1) + 1).split("/")[0];
                if (validVideoId(id)) canonical = "https://www.youtube.com/watch?v=" + id;
            } else if (path.equals("/playlist")) {
                String list = queryParameter(uri.getRawQuery(), "list");
                if (list.matches("[A-Za-z0-9_-]{3,100}")) canonical = "https://www.youtube.com/playlist?list=" + list;
            }
            return canonical == null ? null : "https://www.youtube.com/oembed?format=json&url="
                    + URLEncoder.encode(canonical, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) { return null; }
    }

    private static boolean validVideoId(String id) {
        return id != null && id.matches("[A-Za-z0-9_-]{11}");
    }

    private static String queryParameter(String query, String key) throws Exception {
        if (query == null) return "";
        for (String component : query.split("&")) {
            int index = component.indexOf('=');
            if (index > 0 && component.substring(0, index).equals(key))
                return URLDecoder.decode(component.substring(index + 1), StandardCharsets.UTF_8.name());
        }
        return "";
    }
}
