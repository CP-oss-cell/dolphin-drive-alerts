package app.mideumhanatube.android;

import java.net.URL;
import java.util.Locale;

/** Only web URLs representing a YouTube video may be passed to the native resolver. */
final class NativeVideoUrlRule {
    private NativeVideoUrlRule() { }
    static boolean isVideoPage(String value) {
        if (value == null) return false;
        try {
            URL url = new URL(value);
            if (!"https".equalsIgnoreCase(url.getProtocol())) return false;
            if (url.getUserInfo() != null || url.getPort() != -1) return false;
            String host = url.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("www.youtube.com") || host.equals("m.youtube.com") ||
                  host.equals("youtube.com") || host.equals("youtu.be"))) return false;
            String path = url.getPath();
            if (host.equals("youtu.be")) return path.matches("/[A-Za-z0-9_-]{11}/?");
            if (path.equals("/watch")) {
                String query = url.getQuery();
                return query != null && query.matches("(?:^|.*&)v=[A-Za-z0-9_-]{11}(?:&.*|$)");
            }
            return path.matches("/(shorts|live)/[A-Za-z0-9_-]{11}/?");
        } catch (Exception ignored) { return false; }
    }
}
