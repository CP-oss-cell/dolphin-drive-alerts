package app.mideumhanatube.android;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

/** A video-only PiP surface, independent of WebView and its toolbars. */
public final class VideoPlayerActivity extends Activity {
    public static final String EXTRA_PAGE_URL = "page_url";
    public static final String EXTRA_START_MS = "start_ms";
    public static final String EXTRA_START_IN_PIP = "enter_pip_on_ready";
    public static final String EXTRA_PAGE_TITLE = "page_title";
    private PlayerView playerView;
    private LinearLayout controls;
    private TextView banner;
    private boolean bound;
    private boolean receiverRegistered;
    private final BroadcastReceiver mediaEvents = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BackgroundAudioService.ACTION_NATIVE_FAILURE.equals(intent.getAction())) {
                String why = intent.getStringExtra(BackgroundAudioService.EXTRA_ERROR);
                banner.setText(why == null ? "독립 영상 연결 실패 · 웹으로 돌아가 주세요." : why);
                startInPip = false;
            } else if (BackgroundAudioService.ACTION_NATIVE_READY.equals(intent.getAction())) {
                updateState();
            }
        }
    };
    private ExoPlayer player;
    private boolean startInPip;
    private boolean enteredInitialPip;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            if (!(binder instanceof BackgroundAudioService.LocalBinder)) return;
            player = ((BackgroundAudioService.LocalBinder) binder).player();
            playerView.setPlayer(player);
            if (player != null) {
                player.addListener(listener);
                updateState();
            }
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            if (player != null) player.removeListener(listener);
            playerView.setPlayer(null);
            player = null;
        }
    };
    private final Player.Listener listener = new Player.Listener() {
        @Override public void onPlaybackStateChanged(int state) { updateState(); }
        @Override public void onIsPlayingChanged(boolean playing) { updateState(); }
        @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
            banner.setText("영상 연결에 실패했습니다. 웹 영상으로 돌아갈 수 있습니다.");
        }
    };
    private void updateState() {
        if (banner == null || player == null) return;
        if (startInPip && !enteredInitialPip && player.isPlaying()) {
            enteredInitialPip = true;
            banner.post(this::enterPipNow);
        }
        switch (player.getPlaybackState()) {
            case Player.STATE_READY:
                banner.setText(player.isPlaying() ? "독립 영상 재생 중" : "일시정지");
                break;
            case Player.STATE_BUFFERING: banner.setText("영상 준비 중…"); break;
            case Player.STATE_ENDED: banner.setText("재생 완료"); break;
            default: banner.setText("영상 연결 대기 중…");
        }
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String url = getIntent().getStringExtra(EXTRA_PAGE_URL);
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) {
            Toast.makeText(this, "먼저 유튜브 영상을 선택해 주세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        startInPip = getIntent().getBooleanExtra(EXTRA_START_IN_PIP, false);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(12, 6, 12, 6);
        controls.setBackgroundColor(0xCC0F1723);
        banner = new TextView(this);
        banner.setTextColor(Color.WHITE);
        banner.setText("영상 연결 대기 중…");
        controls.addView(banner, new LinearLayout.LayoutParams(0, -2, 1f));
        Button pip = new Button(this);
        pip.setText("작은 화면");
        pip.setOnClickListener(v -> enterPipNow());
        controls.addView(pip);
        Button web = new Button(this);
        web.setText("웹으로");
        web.setOnClickListener(v -> {
            startService(new Intent(this, BackgroundAudioService.class)
                    .setAction(BackgroundAudioService.ACTION_NATIVE_STOP));
            finish();
        });
        controls.addView(web);
        root.addView(controls, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        setContentView(root);
        IntentFilter mediaFilter = new IntentFilter(BackgroundAudioService.ACTION_NATIVE_FAILURE);
        mediaFilter.addAction(BackgroundAudioService.ACTION_NATIVE_READY);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(mediaEvents, mediaFilter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(mediaEvents, mediaFilter);
        receiverRegistered = true;
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                setPictureInPictureParams(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(16, 9)).setAutoEnterEnabled(true).build());
            } catch (RuntimeException ignored) { }
        }
        Intent start = new Intent(this, BackgroundAudioService.class)
                .setAction(BackgroundAudioService.ACTION_NATIVE_VIDEO_START)
                .putExtra(BackgroundAudioService.EXTRA_MEDIA_URL, url)
                .putExtra(BackgroundAudioService.EXTRA_POSITION_MS,
                        Math.max(0L, getIntent().getLongExtra(EXTRA_START_MS, 0L)))
                .putExtra(BackgroundAudioService.EXTRA_TITLE,
                        getIntent().getStringExtra(EXTRA_PAGE_TITLE));
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
            else startService(start);
            bound = bindService(new Intent(this, BackgroundAudioService.class), connection,
                    Context.BIND_AUTO_CREATE);
        } catch (RuntimeException error) {
            banner.setText("영상 서비스 실행 실패. 웹 영상으로 돌아가 주세요.");
        }
    }
    private void enterPipNow() {
        if (Build.VERSION.SDK_INT < 26 ||
                !getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            Toast.makeText(this, "이 기기는 작은 화면을 지원하지 않습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            PictureInPictureParams.Builder b = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(true);
            boolean entered = enterPictureInPictureMode(b.build());
            if (!entered) Toast.makeText(this, "작은 화면 진입이 허용되지 않았습니다.", Toast.LENGTH_LONG).show();
        } catch (RuntimeException error) {
            Toast.makeText(this, "Android 설정에서 PIP 허용을 확인해 주세요.", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT < 31 && player != null && player.isPlaying()) enterPipNow();
    }
    @Override public void onPictureInPictureModeChanged(boolean inPip, Configuration config) {
        super.onPictureInPictureModeChanged(inPip, config);
        if (controls != null) controls.setVisibility(inPip ? View.GONE : View.VISIBLE);
        if (playerView != null) playerView.setUseController(!inPip);
    }
    @Override protected void onDestroy() {
        if (player != null) player.removeListener(listener);
        if (playerView != null) playerView.setPlayer(null);
        if (bound) { unbindService(connection); bound = false; }
        if (receiverRegistered) { unregisterReceiver(mediaEvents); receiverRegistered = false; }
        super.onDestroy();
    }
}
