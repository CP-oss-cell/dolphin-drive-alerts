package app.mideumhanatube.android;

import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Optional best-effort fallback when the embedded browser has not published a video title. */
public final class YouTubeOEmbedTitle {
    private YouTubeOEmbedTitle() { }

    public static String fetch(String sourceUrl) {
        String endpoint = YouTubeOEmbedUrl.forSource(sourceUrl);
        if (endpoint == null) return null;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(endpoint).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(3500);
            c.setReadTimeout(3500);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            try (InputStream stream = c.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = stream.read(buffer)) != -1) {
                    if (bytes.size() + count > 65536) return null;
                    bytes.write(buffer, 0, count);
                }
                String title = new JSONObject(bytes.toString(StandardCharsets.UTF_8.name())).optString("title", "").trim();
                return BookmarkSavePolicy.isActualTitle(title, sourceUrl) ? title : null;
            }
        } catch (Exception ignored) { return null; }
        finally { if (c != null) c.disconnect(); }
    }
}
