package app.mideumhanatube.android;

import java.net.URI;

/** Minimal, testable policy for YouTube microphone access, not camera or screen capture. */
public final class VoicePermissionPolicy {
    private VoicePermissionPolicy() { }

    public static boolean isTrustedOrigin(String candidate) {
        if (candidate == null) return false;
        try {
            URI uri = new URI(candidate);
            if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
            if (uri.getRawUserInfo() != null || (uri.getPort() != -1 && uri.getPort() != 443))
                return false;
            String host = uri.getHost();
            if (host == null) return false;
            host = host.toLowerCase(java.util.Locale.ROOT);
            return "youtube.com".equals(host) || "www.youtube.com".equals(host)
                    || "m.youtube.com".equals(host) || "music.youtube.com".equals(host);
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isAudioOnly(String[] resources, String audioCaptureKey) {
        return resources != null && resources.length == 1 &&
                audioCaptureKey != null && audioCaptureKey.equals(resources[0]);
    }
}
