package app.mideumhanatube.android;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Local playback order, independent of network resolution and Android lifecycle. */
public final class PlaybackQueue {
    public static final int OFF = 0, ONE = 1, ALL = 2;
    public static final int LIMIT = 80;
    public static final class Track {
        public final String url;
        public final String title;
        public Track(String url, String title) {
            this.url = url;
            this.title = title == null || title.trim().isEmpty() ? "음악" : title.trim();
        }
    }
    private final ArrayList<Track> tracks = new ArrayList<>();
    private final ArrayList<Integer> order = new ArrayList<>();
    private final Random random;
    private int position = -1;
    private int repeatMode = OFF;
    private boolean shuffle;

    public PlaybackQueue() { this(new Random()); }
    PlaybackQueue(Random random) { this.random = random; }
    public int size() { return tracks.size(); }
    public int repeatMode() { return repeatMode; }
    public boolean shuffle() { return shuffle; }
    public Track current() {
        return position < 0 || position >= order.size() ? null : tracks.get(order.get(position));
    }
    public int currentIndex() {
        return position < 0 || position >= order.size() ? -1 : order.get(position);
    }
    public List<Track> snapshot() { return new ArrayList<>(tracks); }
    public void setTracks(List<Track> items, int selected) {
        tracks.clear();
        if (items != null) {
            for (Track t : items) {
                if (t == null || t.url == null || t.url.isEmpty()) continue;
                boolean duplicate = false;
                for (Track saved : tracks) if (saved.url.equals(t.url)) { duplicate = true; break; }
                if (!duplicate) tracks.add(t);
                if (tracks.size() >= LIMIT) break;
            }
        }
        if (tracks.isEmpty()) { order.clear(); position = -1; return; }
        int index = Math.max(0, Math.min(selected, tracks.size()-1));
        rebuild(index);
    }
    public void clear() { tracks.clear(); order.clear(); position = -1; }
    public void setRepeatMode(int mode) {
        repeatMode = (mode >= OFF && mode <= ALL) ? mode : OFF;
    }
    public int cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3;
        return repeatMode;
    }
    public void setShuffle(boolean enabled) {
        if (shuffle == enabled) return;
        int keep = currentIndex();
        shuffle = enabled;
        rebuild(keep < 0 ? 0 : keep);
    }
    private void rebuild(int currentTrackIndex) {
        order.clear();
        if (tracks.isEmpty()) { position = -1; return; }
        for (int i = 0; i < tracks.size(); i++) order.add(i);
        if (shuffle) {
            order.remove(Integer.valueOf(currentTrackIndex));
            Collections.shuffle(order, random);
            order.add(0, currentTrackIndex);
            position = 0;
        } else {
            position = Math.max(0, Math.min(currentTrackIndex, order.size()-1));
        }
    }
    /** endOfTrack=true respects repeat ONE. Manual next always advances. */
    public Track next(boolean endOfTrack) {
        if (tracks.isEmpty()) return null;
        if (endOfTrack && repeatMode == ONE) return current();
        if (position + 1 < order.size()) position++;
        else if (repeatMode == ALL) position = 0;
        else return null;
        return current();
    }
    public Track previous() {
        if (tracks.isEmpty()) return null;
        if (position > 0) position--;
        else if (repeatMode == ALL) position = order.size()-1;
        else return null;
        return current();
    }
    public String summary() {
        String r = repeatMode == ONE ? "한 곡 반복" : repeatMode == ALL ? "전체 반복" : "반복 없음";
        return r + (shuffle ? " · 랜덤" : " · 순서대로");
    }
}
