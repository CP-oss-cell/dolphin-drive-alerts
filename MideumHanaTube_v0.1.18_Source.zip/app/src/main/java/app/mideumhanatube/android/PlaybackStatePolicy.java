package app.mideumhanatube.android;

/** Pure-Java, testable native playback phase classification.
 * Media3 Player.STATE_IDLE/BUFFERING/READY/ENDED map to 1/2/3/4.
 * isPlaying=false must NEVER be interpreted as a user pause by itself.
 */
public final class PlaybackStatePolicy {
    public enum Phase { IDLE, RESOLVING, BUFFERING, READY_WAIT, PLAYING, PAUSED, SUPPRESSED, ENDED }
    private PlaybackStatePolicy() { }

    public static Phase classify(boolean resolving, boolean playRequested,
                                 int state, boolean actuallyPlaying, int suppressionReason) {
        if (!playRequested) return Phase.PAUSED;
        if (resolving) return Phase.RESOLVING;
        if (state == 4) return Phase.ENDED;
        if (state == 2) return Phase.BUFFERING;
        if (suppressionReason != 0) return Phase.SUPPRESSED;
        if (actuallyPlaying && state == 3) return Phase.PLAYING;
        if (state == 3) return Phase.READY_WAIT;
        return Phase.IDLE;
    }

    public static boolean keepForeground(Phase phase) {
        return phase == Phase.RESOLVING || phase == Phase.BUFFERING ||
                phase == Phase.PLAYING || phase == Phase.READY_WAIT || phase == Phase.SUPPRESSED;
    }

    public static boolean isTerminal(Phase phase) {
        return phase == Phase.ENDED || phase == Phase.IDLE;
    }
}
