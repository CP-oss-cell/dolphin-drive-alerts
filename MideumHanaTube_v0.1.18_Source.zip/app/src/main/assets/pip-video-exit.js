/* Restore DOM styling only; preserve the playback element and position. */
(function () {
  'use strict';
  var style = document.getElementById('mht-pip-video-isolation-css');
  if (style && style.parentNode) style.parentNode.removeChild(style);
  if (document.documentElement) document.documentElement.classList.remove('mht-pip-isolation');
  if (document.body) document.body.classList.remove('mht-pip-isolation');
  var ancestors = document.querySelectorAll('.mht-pip-ancestor');
  for (var i = 0; i < ancestors.length; i++) ancestors[i].classList.remove('mht-pip-ancestor');
  var videos = document.querySelectorAll('video.mht-pip-selected');
  for (var j = 0; j < videos.length; j++) videos[j].classList.remove('mht-pip-selected');
  window.__MHT_PIP_ACTIVE = false;
  return true;
})()
