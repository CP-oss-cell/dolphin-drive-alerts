(function () {
  'use strict';
  var href = location.href;
  var path = location.pathname || '';
  var watch = /^\/(watch|shorts\/|live\/)/.test(path);
  var playlist = /^\/playlist/.test(path);
  var channel = /^\/(@|channel\/|c\/|user\/)/.test(path);
  var videoId = '';
  try {
    if (path === '/watch') videoId = new URL(location.href).searchParams.get('v') || '';
    else if (/^\/(shorts|live)\//.test(path)) videoId = path.split('/')[2] || '';
  } catch (e) { }
  var title = '';
  var details = null;
  try {
    var player = window.ytInitialPlayerResponse || null;
    details = player && player.videoDetails;
    if (watch && details && details.videoId === videoId) title = details.title || '';
  } catch (e) { }

  function read(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var element = document.querySelector(selectors[i]);
      if (!element) continue;
      var value = (element.getAttribute && (element.getAttribute('title') || element.getAttribute('aria-label'))) || element.textContent || '';
      if (value && value.trim()) return value.trim();
    }
    return '';
  }

  if (!title && watch) title = read([
    'ytm-watch-metadata h1', 'ytm-watch-metadata .title',
    'ytm-slim-video-metadata-renderer h1',
    'ytm-slim-video-metadata-renderer .slim-video-metadata-title',
    'h1.slim-video-metadata-title',
    'ytd-watch-metadata h1 yt-formatted-string',
    'ytd-watch-metadata h1',
    'h1.ytd-watch-metadata', '#title h1',
    '.watch-title', '.ytp-title-link'
  ]);
  if (!title && playlist) title = read([
    'ytd-playlist-header-renderer h1',
    'ytm-playlist-header h1', 'ytm-playlist-header-renderer h1',
    'ytm-playlist-header-renderer .title',
    'h1.ytd-playlist-header-renderer'
  ]);
  if (!title && channel) title = read([
    'ytm-channel-header-renderer h1',
    'ytd-channel-name yt-formatted-string',
    'ytm-channel-header-renderer .channel-title',
    'ytd-c4-tabbed-header-renderer #channel-name'
  ]);
  // For video pages, stale metadata may belong to the previously opened SPA video.
  var metadataLooksStale = !!(watch && details && details.videoId && videoId && details.videoId !== videoId);
  if (!title && !metadataLooksStale) {
    var meta = document.querySelector('meta[property="og:title"]') ||
      document.querySelector('meta[name="title"]');
    if (meta) title = meta.content || (meta.getAttribute && meta.getAttribute('content')) || '';
  }
  var pageTitle = metadataLooksStale ? 'YouTube' : (document.title || '');
  if (!title && !metadataLooksStale) title = pageTitle;
  return JSON.stringify({url: href, title: title, pageTitle: pageTitle});
})()