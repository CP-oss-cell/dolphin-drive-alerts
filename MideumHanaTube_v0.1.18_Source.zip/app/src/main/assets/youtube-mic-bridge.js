(function () {
  'use strict';
  if (window.__MHT_YT_MIC_BRIDGE_V0111) return;
  window.__MHT_YT_MIC_BRIDGE_V0111 = true;
  // Do not globally intercept other controls, text fields, or the search button.
  const TOKEN = 'MHT_YOUTUBE_VOICE_SEARCH_0111';
  function isVoiceTarget(node) {
    if (!node || node.nodeType !== 1) return false;
    const text = [node.getAttribute('aria-label'), node.getAttribute('title'),
      node.getAttribute('data-tooltip-text'), node.id,
      typeof node.className === 'string' ? node.className : ''].filter(Boolean)
      .join(' ').toLowerCase();
    return /voice[-_ ]?search|search[-_ ]?(?:with[-_ ]?your[-_ ]?|by[-_ ]?)?voice|음성\s*(검색|으로)|마이크|microphone|\bmic\b/i.test(text);
  }
  document.addEventListener('click', function (event) {
    if (!event.isTrusted || !event.target) return;
    let candidates = typeof event.composedPath === 'function' ? event.composedPath() : [];
    if (!candidates.length) {
      let el = event.target;
      for (let i = 0; el && i < 5; i++, el = el.parentElement) candidates.push(el);
    }
    // YouTube uses custom elements; a voice-search button may be nested inside
    // shadow DOM. Event.composedPath allows matching the actual icon container.
    if (!candidates.some(isVoiceTarget)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    event.stopPropagation();
    try { window.prompt(TOKEN, ''); } catch (ignored) { }
  }, true);
})();
