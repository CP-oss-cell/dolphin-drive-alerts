/*
 * PiP video focus. This operates on the existing <video> without moving,
 * replacing, pausing, or reloading the DOM. CSS is removed upon PiP exit.
 * This is best-effort for the YouTube mobile website's current page structure.
 */
(function () {
  'use strict';
  if (!document.body || !document.head) return JSON.stringify({ ready: false, reason: 'NO_DOCUMENT' });
  if (window.__MHT_PIP_ACTIVE) return JSON.stringify({ ready: true, already: true });
  var videos = Array.prototype.slice.call(document.querySelectorAll('video'));
  var video = null;
  for (var i = 0; i < videos.length; i++) {
    if (!videos[i].paused && !videos[i].ended && videos[i].readyState > 0) {
      video = videos[i];
      break;
    }
  }
  if (!video) return JSON.stringify({ ready: false, reason: 'NO_PLAYING_VIDEO' });

  var css = '' +
    'html.mht-pip-isolation,body.mht-pip-isolation{' +
      'background:#000!important;overflow:hidden!important;overscroll-behavior:none!important;}' +
    'body.mht-pip-isolation *{visibility:hidden!important;}' +
    'body.mht-pip-isolation .mht-pip-ancestor,' +
    'body.mht-pip-isolation video.mht-pip-selected{visibility:visible!important;}' +
    'body.mht-pip-isolation .mht-pip-ancestor{' +
      'overflow:visible!important;clip-path:none!important;transform:none!important;' +
      'filter:none!important;contain:none!important;}' +
    'body.mht-pip-isolation video.mht-pip-selected{' +
      'display:block!important;visibility:visible!important;position:fixed!important;' +
      'top:0!important;left:0!important;right:0!important;bottom:0!important;' +
      'width:100vw!important;height:100vh!important;max-width:none!important;' +
      'max-height:none!important;min-width:0!important;min-height:0!important;' +
      'margin:0!important;padding:0!important;border:0!important;' +
      'transform:none!important;object-fit:contain!important;' +
      'z-index:2147483600!important;background:black!important;opacity:1!important;}' ;
  var style = document.createElement('style');
  style.id = 'mht-pip-video-isolation-css';
  style.textContent = css;
  document.head.appendChild(style);
  video.classList.add('mht-pip-selected');
  var node = video.parentElement;
  while (node && node !== document.body && node !== document.documentElement) {
    node.classList.add('mht-pip-ancestor');
    node = node.parentElement;
  }
  document.documentElement.classList.add('mht-pip-isolation');
  document.body.classList.add('mht-pip-isolation');
  window.__MHT_PIP_ACTIVE = true;
  // The media state and currentTime are deliberately NOT modified.
  return JSON.stringify({ ready: true, time: video.currentTime || 0 });
})()
