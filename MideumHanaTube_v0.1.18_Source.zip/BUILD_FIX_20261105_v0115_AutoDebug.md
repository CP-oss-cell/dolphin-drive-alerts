# 믿음하나튜브 v0.1.15 자동 서명 Debug 재발행

- 이전 v0.1.15 패키지의 GitHub Actions Workflow는 Release APK 생성 및 키 5개 Secrets 등록을 요구했습니다.
- 사용자 요청에 따라 해당 단계를 전부 제거하고, `assembleDebug` → Debug APK 서명 검증 → GitHub Artifact 업로드 방식으로 바꿨습니다.
- 수정 대상: 루트 외부 YML과 소스 ZIP 내부 `.github/workflows/` YML, `app/build.gradle`, 테스트, README.
- 새 사용자 기능 개발이나 버전 변경은 없습니다. 기존 v0.1.15의 모든 재생/광고 관련 불확실성은 동일합니다.
- Debug key는 GitHub Actions 러너마다 달라질 수 있어 인플레이스 업데이트가 보장되지 않습니다. 기존 APK 삭제 후 설치할 수 있습니다.
- 사용자의 개인정보와 데이터는 앱 제거 시 삭제될 수 있습니다.
- 해당 패키지는 APK 자체가 아니라 GitHub Actions 자동 빌드용 소스입니다.
