# v0.1.17 검증 요약

- 검증 일자: 2026-11-05
- 빌드 대상: Android 8.0+ / Android 10 / Android 17 대응 후보
- 순수 Java 대기열 정책과 18개 회귀 테스트 스크립트 실행 PASS
- Java 소스 구문 16개 파일, Android XML, GitHub Actions YAML 파싱 PASS
- Media3 / NewPipeExtractor 공개 API 문서 대조 및 static source checks PASS
- 소스/워크플로 ZIP CRC PASS (패키징 시 검증)
- **미검증:** Android SDK 기반 Gradle APK 컴파일; 실기기 영상 렌더링; 실제 PIP 진입; YouTube 스트림 서비스의 재생 성공 여부; 영상 광고의 차단률.
- `.github/workflows`가 생성하는 Debug APK의 서명 인증서는 GitHub 러너마다 바뀔 수 있음. 기존 앱 삭제 후 설치가 필요할 수 있음.
