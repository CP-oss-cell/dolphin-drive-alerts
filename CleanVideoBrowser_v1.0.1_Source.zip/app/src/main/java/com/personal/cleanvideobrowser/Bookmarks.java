package com.personal.cleanvideobrowser;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class Bookmarks {
    private static final String KEY = "bookmarks";
    private static final String PREFS = "clean_video_local";

    private Bookmarks() {}

    static List<JSONObject> all(Context c) {
        List<JSONObject> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(c.getSharedPreferences(PREFS, 0).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) list.add(obj);
            }
        } catch (Exception ignored) { }
        return list;
    }

    static void add(Context c, String title, String url) {
        if (!MediaDetector.validWebUrl(url)) return;
        List<JSONObject> old = all(c);
        JSONArray newer = new JSONArray();
        try {
            JSONObject first = new JSONObject();
            first.put("title", title == null || title.isEmpty() ? url : title);
            first.put("url", url);
            newer.put(first);
            for (JSONObject b : old) {
                if (!url.equals(b.optString("url"))) newer.put(b);
                if (newer.length() >= 200) break;
            }
            c.getSharedPreferences(PREFS, 0).edit().putString(KEY, newer.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void remove(Context c, String url) {
        JSONArray arr = new JSONArray();
        for (JSONObject b : all(c)) {
            if (!url.equals(b.optString("url"))) arr.put(b);
        }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply();
    }
}
