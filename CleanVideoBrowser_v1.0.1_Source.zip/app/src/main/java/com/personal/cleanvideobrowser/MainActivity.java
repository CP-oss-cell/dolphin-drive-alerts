package com.personal.cleanvideobrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.WindowInsets;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * A clean-room implementation: browser + video detection + downloads.
 * No advertising, analytics, bundled player, or third-party dependencies.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com/";
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private View downloadsPanel;
    private View bookmarksPanel;
    private ListView downloadsList;
    private ListView bookmarksList;
    private Button tabWeb;
    private Button tabDetect;
    private Button tabDownloads;
    private Button tabBookmarks;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String, String> detected = new LinkedHashMap<>();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
                renderDownloads();
                ui.postDelayed(this, 2000);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets p = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(p.left, p.top, p.right, p.bottom);
                return insets;
            });
        }
        address = findViewById(R.id.address);
        progress = findViewById(R.id.progress);
        browser = findViewById(R.id.browser);
        downloadsPanel = findViewById(R.id.downloads_panel);
        bookmarksPanel = findViewById(R.id.bookmarks_panel);
        downloadsList = findViewById(R.id.downloads_list);
        bookmarksList = findViewById(R.id.bookmarks_list);
        tabWeb = findViewById(R.id.tab_web);
        tabDetect = findViewById(R.id.tab_detect);
        tabDownloads = findViewById(R.id.tab_downloads);
        tabBookmarks = findViewById(R.id.tab_bookmarks);

        configureBrowser();
        findViewById(R.id.back).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoBack()) browser.goBack();
        });
        findViewById(R.id.forward).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoForward()) browser.goForward();
        });
        findViewById(R.id.go).setOnClickListener(v -> navigate());
        findViewById(R.id.go).setOnLongClickListener(v -> { browser.reload(); return true; });
        findViewById(R.id.star).setOnClickListener(v -> {
            if (MediaDetector.validWebUrl(browser.getUrl())) {
                Bookmarks.add(this, browser.getTitle(), browser.getUrl());
                toast("즐겨찾기에 저장했습니다");
            }
        });
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate();
                return true;
            }
            return false;
        });
        tabWeb.setOnClickListener(v -> showPanel("web"));
        tabWeb.setOnLongClickListener(v -> { showPanel("web"); browser.loadUrl(HOME); return true; });
        tabDetect.setOnClickListener(v -> {
            showPanel("web");
            browser.evaluateJavascript(SCAN_JS, null);
            ui.postDelayed(this::showVideos, 350);
        });
        tabDownloads.setOnClickListener(v -> showPanel("downloads"));
        tabBookmarks.setOnClickListener(v -> showPanel("bookmarks"));
        findViewById(R.id.reload_downloads).setOnClickListener(v -> renderDownloads());
        findViewById(R.id.open_folder).setOnClickListener(v -> {
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { toast("시스템 다운로드 화면을 열 수 없습니다"); }
        });
        bookmarksList.setOnItemClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                showPanel("web");
                browser.loadUrl(list.get(position).optString("url"));
            }
        });
        bookmarksList.setOnItemLongClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                JSONObject target = list.get(position);
                new AlertDialog.Builder(this).setTitle("즐겨찾기 삭제")
                        .setMessage(target.optString("title"))
                        .setPositiveButton("삭제", (d, w) -> {
                            Bookmarks.remove(this, target.optString("url"));
                            renderBookmarks();
                        }).setNegativeButton("취소", null).show();
            }
            return true;
        });
        showPanel("web");
        if (saved == null) browser.loadUrl(HOME);
        else browser.restoreState(saved);
    }

    private void configureBrowser() {
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true); // Needed by most modern websites.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);
        browser.addJavascriptInterface(new MediaBridge(), "CleanVideoMedia");
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int percent) {
                progress.setProgress(percent);
                progress.setVisibility(percent >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                detected.clear();
                address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                address.setText(url);
                browser.evaluateJavascript(SCAN_JS, null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (AdBlock.blocked(uri)) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                String url = uri.toString();
                if (MediaDetector.looksLikeVideo(url)) {
                    addVideo(url, "영상 주소 감지");
                }
                return null;
            }
            @Override public void onReceivedSslError(WebView view,
                                                      SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never let invalid certificates through.
                runOnUiThread(() -> toast("안전하지 않은 연결을 차단했습니다"));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) {
                    runOnUiThread(() -> toast("웹페이지를 열 수 없습니다"));
                }
            }
        });
        browser.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (MediaDetector.validWebUrl(url)) {
                offerDownload(url, MediaDetector.guessName(url, contentDisposition, mimeType));
            } else {
                toast("이 다운로드 주소는 지원하지 않습니다");
            }
        });
    }

    /** JavaScript only reports URLs; it cannot start downloads or access device files. */
    private final class MediaBridge {
        @JavascriptInterface public void found(String url) {
            addVideo(url, "웹페이지 영상");
        }
    }

    private static final String SCAN_JS =
        "(function(){" +
        "if(window.__cleanVideoScan){if(window.__cleanVideoScanNow)window.__cleanVideoScanNow();return;}" +
        "window.__cleanVideoScan=true;" +
        "function emit(u){try{if(!u)return;var a=new URL(u,document.baseURI);" +
        "if(/^https?:$/.test(a.protocol))CleanVideoMedia.found(a.href)}catch(e){}}" +
        "function video(u){return /\\.(mp4|m4v|mov|webm|avi|wmv|flv|3gp|m3u8)(?:[?#]|$)/i.test(u||'')}" +
        "function scan(){try{" +
        "document.querySelectorAll('video,source').forEach(function(v){emit(v.currentSrc);emit(v.src);" +
        "if(v.getAttribute('src'))emit(v.getAttribute('src'))});" +
        "document.querySelectorAll('a[href]').forEach(function(a){if(video(a.href))emit(a.href)});" +
        "performance.getEntriesByType('resource').forEach(function(r){if(video(r.name))emit(r.name)});" +
        "}catch(e){}}" +
        "window.__cleanVideoScanNow=scan;scan();" +
        "try{new MutationObserver(function(){scan()}).observe(document.documentElement," +
        "{childList:true,subtree:true,attributes:true,attributeFilter:['src','href']})}catch(e){}" +
        "try{new PerformanceObserver(function(list){list.getEntries().forEach(function(r){" +
        "if(video(r.name))emit(r.name)})}).observe({entryTypes:['resource']})}catch(e){}" +
        "setInterval(scan,4000);" +
        "})();";

    private void addVideo(String url, String description) {
        if (!MediaDetector.validWebUrl(url) || AdBlock.blocked(Uri.parse(url))) return;
        ui.post(() -> {
            if (isFinishing() || isDestroyed() || detected.containsKey(url)) return;
            if (detected.size() >= 120) return;
            detected.put(url, description);
            tabDetect.setText("영상 찾기 (" + detected.size() + ")");
        });
    }

    private void showVideos() {
        List<Map.Entry<String, String>> entries = new ArrayList<>(detected.entrySet());
        if (entries.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("발견된 영상이 없습니다")
                    .setMessage("웹페이지에서 동영상 재생 버튼을 누르면 영상 주소가 감지될 수 있습니다. " +
                            "직접 다운로드 주소를 붙여넣을 수도 있습니다.")
                    .setPositiveButton("주소 직접 입력", (d, w) -> enterDownloadUrl())
                    .setNegativeButton("닫기", null).show();
            return;
        }
        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            String url = entries.get(i).getKey();
            Uri uri = Uri.parse(url);
            String path = uri.getLastPathSegment();
            if (path == null || path.isEmpty()) path = "영상 " + (i + 1);
            if (path.length() > 46) path = path.substring(0, 46) + "…";
            labels[i] = (MediaDetector.isHls(url) ? "HLS · " : "영상 · ")
                    + path + "\n" + uri.getHost();
        }
        new AlertDialog.Builder(this).setTitle("감지된 영상 " + entries.size() + "개")
                .setItems(labels, (d, which) -> {
                    String url = entries.get(which).getKey();
                    offerDownload(url, MediaDetector.guessName(url, null, null));
                })
                .setNeutralButton("주소 직접 입력", (d, w) -> enterDownloadUrl())
                .setNegativeButton("닫기", null).show();
    }

    private void enterDownloadUrl() {
        EditText text = new EditText(this);
        text.setSingleLine(false);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        text.setHint("https://example.com/video.mp4");
        text.setPadding(32, 20, 32, 20);
        new AlertDialog.Builder(this).setTitle("동영상 주소 붙여넣기")
                .setView(text)
                .setPositiveButton("다음", (d, w) -> {
                    String url = text.getText().toString().trim();
                    if (MediaDetector.validWebUrl(url))
                        offerDownload(url, MediaDetector.guessName(url, null, null));
                    else toast("http:// 또는 https:// 주소를 입력하세요");
                })
                .setNegativeButton("취소", null).show();
    }

    private void offerDownload(String url, String suggestedName) {
        if (!MediaDetector.validWebUrl(url)) { toast("다운로드 주소 오류"); return; }
        boolean hls = MediaDetector.isHls(url);
        EditText nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setText(suggestedName);
        nameBox.setSelectAllOnFocus(true);
        nameBox.setPadding(32, 24, 32, 24);
        new AlertDialog.Builder(this).setTitle(hls ? "HLS 동영상 저장" : "동영상 다운로드")
                .setMessage(hls ? "일반 비암호화 HLS(VOD)만 다운로드합니다. " +
                        "파일은 .ts 형식으로 저장됩니다." : "저장 위치: 다운로드/CleanVideo")
                .setView(nameBox)
                .setPositiveButton("다운로드", (d, w) -> {
                    String fileName = DownloadStore.safeFileName(nameBox.getText().toString());
                    if (hls) {
                        int dot = fileName.lastIndexOf('.');
                        fileName = (dot > 0 ? fileName.substring(0, dot) : fileName) + ".ts";
                    }
                    if (hls) chooseHlsQuality(url, fileName);
                    else downloadDirect(url, fileName);
                }).setNegativeButton("취소", null).show();
    }

    private void chooseHlsQuality(String url, String filename) {
        new AlertDialog.Builder(this).setTitle("화질 선택")
                .setItems(new String[] { "최고 화질 (가능한 경우)", "데이터 절약 (가능한 경우)" },
                        (d, which) -> startHlsDownload(url, filename, which == 0 ? "best" : "small"))
                .setNegativeButton("취소", null).show();
    }

    private void startHlsDownload(String url, String filename, String quality) {
        String id = "hls-" + UUID.randomUUID();
        DownloadStore.add(this, id, "hls", filename);
        Intent intent = new Intent(this, HlsDownloadService.class);
        intent.putExtra("id", id);
        intent.putExtra("url", url);
        intent.putExtra("filename", filename);
        intent.putExtra("quality", quality);
        intent.putExtra("referer", browser.getUrl());
        intent.putExtra("ua", browser.getSettings().getUserAgentString());
        intent.putExtra("cookie", CookieManager.getInstance().getCookie(url));
        try {
            startForegroundService(intent);
            toast("HLS 다운로드를 시작했습니다");
        } catch (Exception e) {
            DownloadStore.update(this, id, "실패: 다운로드 서비스를 시작할 수 없음", 0);
            toast("다운로드를 시작할 수 없습니다");
        }
    }

    private void downloadDirect(String url, String filename) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription("CleanVideo Browser");
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS + "/CleanVideo", filename);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            request.addRequestHeader("User-Agent", browser.getSettings().getUserAgentString());
            if (MediaDetector.validWebUrl(browser.getUrl()))
                request.addRequestHeader("Referer", browser.getUrl());
            if (filename.toLowerCase(Locale.ROOT).endsWith(".mp4"))
                request.setMimeType("video/mp4");
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            DownloadStore.add(this, String.valueOf(id), "direct", filename);
            toast("다운로드를 시작했습니다");
        } catch (Exception e) {
            toast("다운로드 실패: " + e.getClass().getSimpleName());
        }
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        String url;
        if (MediaDetector.validWebUrl(input)) url = input;
        else if (input.matches("(?i)^[^\\s]+\\.[a-z]{2,}([/:?].*)?$")) url = "https://" + input;
        else url = "https://www.google.com/search?q=" + Uri.encode(input);
        showPanel("web");
        browser.loadUrl(url);
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    private void showPanel(String name) {
        boolean download = "downloads".equals(name);
        boolean bookmark = "bookmarks".equals(name);
        downloadsPanel.setVisibility(download ? View.VISIBLE : View.GONE);
        bookmarksPanel.setVisibility(bookmark ? View.VISIBLE : View.GONE);
        browser.setVisibility(!download && !bookmark ? View.VISIBLE : View.GONE);
        tabWeb.setTextColor(!download && !bookmark ? 0xff1357b5 : 0xff303030);
        tabDownloads.setTextColor(download ? 0xff1357b5 : 0xff303030);
        tabBookmarks.setTextColor(bookmark ? 0xff1357b5 : 0xff303030);
        tabDetect.setTextColor(0xff303030);
        ui.removeCallbacks(tick);
        if (download) { renderDownloads(); ui.postDelayed(tick, 2000); }
        if (bookmark) renderBookmarks();
    }

    private void renderBookmarks() {
        List<String> labels = new ArrayList<>();
        for (JSONObject item : Bookmarks.all(this)) {
            labels.add(item.optString("title") + "\n" + item.optString("url"));
        }
        if (labels.isEmpty()) labels.add("즐겨찾기가 없습니다. 웹사이트에서 ☆ 버튼을 누르세요.");
        bookmarksList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void renderDownloads() {
        List<String> labels = new ArrayList<>();
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        for (JSONObject entry : DownloadStore.list(this)) {
            String id = entry.optString("id");
            String status = entry.optString("status", "대기 중");
            int percent = entry.optInt("progress", 0);
            if ("direct".equals(entry.optString("type"))) {
                try {
                    long number = Long.parseLong(id);
                    try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                        if (cursor != null && cursor.moveToFirst()) {
                            int raw = cursor.getInt(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_STATUS));
                            long total = cursor.getLong(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            long done = cursor.getLong(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                            percent = total > 0 ? (int) (done * 100 / total) : 0;
                            if (raw == DownloadManager.STATUS_SUCCESSFUL) { status = "완료"; percent = 100; }
                            else if (raw == DownloadManager.STATUS_RUNNING) status = "다운로드 중";
                            else if (raw == DownloadManager.STATUS_PAUSED) status = "일시 대기 (네트워크 등)";
                            else if (raw == DownloadManager.STATUS_FAILED) status = "실패";
                            else status = "대기 중";
                        } else status = "시스템에서 다운로드 내역을 찾을 수 없음";
                    }
                } catch (Exception ignored) { status = "상태 확인 실패"; }
            }
            labels.add(entry.optString("name") + "\n" + status + " · " + percent + "%");
        }
        if (labels.isEmpty()) labels.add("다운로드 기록이 없습니다. '영상 찾기'를 눌러 시작하세요.");
        downloadsList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() {
        if (downloadsPanel.getVisibility() == View.VISIBLE
                || bookmarksPanel.getVisibility() == View.VISIBLE) showPanel("web");
        else if (browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        browser.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (browser != null) browser.onResume();
        if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
            ui.removeCallbacks(tick);
            renderDownloads();
            ui.postDelayed(tick, 2000);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        browser.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (browser != null) {
            browser.stopLoading();
            browser.setWebChromeClient(null);
            browser.setWebViewClient(null);
            browser.destroy();
        }
        super.onDestroy();
    }
}
