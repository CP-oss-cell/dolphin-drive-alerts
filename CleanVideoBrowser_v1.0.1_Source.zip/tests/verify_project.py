from pathlib import Path
from xml.etree import ElementTree
import json
import re
import subprocess

root = Path(__file__).resolve().parents[1]
for file in root.rglob('*.xml'):
    ElementTree.parse(file)
    print('XML_OK', file.relative_to(root))

source = '\n'.join(f.read_text() for f in root.rglob('*.java'))
for forbidden in ('com.google.android.gms.ads', 'com.applovin.sdk', 'com.facebook.ads.',
                  'VideoView(', 'new MediaPlayer(', 'ExoPlayer.Builder(',
                  'setAllowFileAccess(true)', 'handler.proceed()'):
    assert forbidden not in source, f'Unsupported/insecure feature: {forbidden}'

manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' in manifest
assert 'FOREGROUND_SERVICE_DATA_SYNC' in manifest
assert 'android:exported="false"' in manifest
assert 'usesCleartextTraffic' in manifest

main = (root / 'app/src/main/java/com/personal/cleanvideobrowser/MainActivity.java').read_text()
code = main.split('private static final String SCAN_JS =', 1)[1].split('private void addVideo(', 1)[0]
fragments = [json.loads(m.group()) for m in re.finditer(r'"(?:\\.|[^"\\])*"', code)]
js = ''.join(fragments)
assert 'MutationObserver' in js and 'PerformanceObserver' in js
script = root / 'tests/.scan_checked.js'
script.write_text(js)
try:
    subprocess.run(['node', '--check', str(script)], check=True)
finally:
    script.unlink(missing_ok=True)
print('JS_SYNTAX_OK, SECURITY_CHECKS_OK')
