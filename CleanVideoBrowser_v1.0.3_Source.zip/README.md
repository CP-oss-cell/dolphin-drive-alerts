# CleanVideoBrowser 1.0.3

개인용 광고 SDK 없는 인터넷 브라우저 + 동영상 다운로더. 기존 Video Downloader의 코드를 수정한 앱이 아니라 독립 작성한 프로젝트입니다. 앱 자체 동영상 플레이어는 없습니다.

## 통합 패키지 사용 방법 (중요)

통합 ZIP을 한 번 해제하면 다음 **두 파일만** 나옵니다.

- `CleanVideoBrowser_v1.0.3_Source.zip` — Android 전체 프로젝트 (다시 압축 해제할 필요 없음)
- `CleanVideoBrowser_v1.0.3_Source.yml` — GitHub Actions 빌드 자동화

GitHub 저장소가 다른 앱 프로젝트와 같더라도 다음처럼 올리세요.

1. `CleanVideoBrowser_v1.0.3_Source.zip` 파일은 **압축을 풀지 말고** GitHub 저장소 최상위(root)에 업로드합니다.
2. `CleanVideoBrowser_v1.0.3_Source.yml` 파일을 GitHub 저장소의 **`.github/workflows/CleanVideoBrowser_v1.0.3_Source.yml`** 경로에 업로드합니다. GitHub Actions YML은 이 경로에 있어야 인식됩니다.
3. Actions 메뉴의 **CleanVideoBrowser v1.0.3 APK** → **Run workflow**를 누르거나 해당 소스 ZIP/YML을 push하면 자동 실행됩니다.
4. 성공 후 빌드 실행의 **Artifacts → CleanVideoBrowser_v1.0.3_APK**에서 앱 APK가 들어 있는 아티팩트를 다운로드합니다.

별도의 기존 소스 파일을 GitHub 루트에 펼치지 않아도 됩니다. 워크플로가 ZIP을 전용 임시 폴더에 풀어 그 안에서만 Gradle을 실행합니다. 바깥쪽 `Complete_Build_Package.zip`만 루트에 올려도 자동 처리하게 지원하지만, 권장 업로드는 위 두 파일입니다.

**과거 워크플로 `.github/workflows/build-apk.yml` 및 구버전 `CleanVideoBrowser_*.yml`은 제거하세요.** 남겨 두면 서로 독립적으로 빌드되어 혼란을 줄 수 있습니다.

## 기능

- WebView 인터넷 브라우저 / 주소 입력과 검색
- 재생 페이지 내 MP4, WebM 등 영상 URL 감지와 직접 링크 다운로드
- DownloadManager 기반 백그라운드 파일 다운로드
- 비암호화 MPEG-TS VOD HLS `.m3u8` 지원 (라이브/DRM/fMP4 제외)
- 다운로드 상태/진행률, 즐겨찾기
- 자체 광고 SDK / 분석 SDK / 로컬 영상 플레이어 없음
- 저장 위치: `Downloads/CleanVideo`
- Android 10(API 29) 이상

## 제한 사항

사이트가 제공하는 광고는 일부 남을 수 있으며, 모든 웹사이트의 동영상 저장을 보장하지 않습니다. DRM 및 유료 서비스 보호를 우회하지 않습니다. 다운로드 시 콘텐츠 이용권한과 각 웹사이트 약관을 준수하세요.

## 검증 상태

첨부된 `creanlog.zip`에서 Android SDK와 Gradle 설치는 성공했지만 `test -f settings.gradle`에서 실패한 것을 확인했습니다. GitHub 루트에 ZIP만 있을 때 원본 파일을 찾지 못하는 워크플로 문제를 수정했습니다. 새 워크플로의 자동 압축 해제 및 프로젝트 구조 검사 경로는 별도의 임시 저장소로 시뮬레이션 검증했습니다. 실제 GitHub Actions APK 컴파일 및 실기기 테스트는 아직 진행되지 않았습니다.
