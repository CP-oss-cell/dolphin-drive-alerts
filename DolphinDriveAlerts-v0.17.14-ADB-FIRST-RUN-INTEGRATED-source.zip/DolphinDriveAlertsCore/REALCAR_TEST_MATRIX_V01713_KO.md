# v0.17.13 실차 검수표

| 기능 | 통과 조건 | 실패 시 수집 |
|---|---|---|
| BSD 깜빡이 | BSD 원시 위험 후보+좌/우 어느 깜빡이든 일반 후측방 1회, 위험 재진입 전 무중복 | `LINKLOCK_BSD_STATE`, `BSD_GATE_*`, `BSD_ALERT_EMITTED`, 당시 순정 계기판 |
| BSD 즉시 ON | 깜빡이 없이 경고 진입시 일반 음성 최대 1회 | `BSD_ALERT_EMITTED`, `BSD_GATE_*`; 기능 상태 ON/OFF와 구별 |
| BSD 둘 OFF | 우리 앱 BSD 음성 없음, 순정 경고 유지 | BSD 설정값, AlertGate 출력 |
| NORMAL | ECO→NORMAL→SPORT→ECO 매 사이클 올바른 음성 | `REFERENCE_OPERATION_MODE`, Energy/raw, 순정 UI 시각 |
| ICC LDW/앞차 | 경고 원시 이벤트↔실제 계기판 경고 대응 증거 먼저 | `DIPILOT_HAZARD_CALLBACK_CANDIDATE`, `ADAS_CANDIDATE_RAW_NO_SPEECH`, ACC 상태 |
| 분할 2앱 | task mode 3/4 및 bounds 요청 비율 일치 | `SPLIT`, `am stack list`, `dumpsys activity activities`, 카메라 종료 후 readback |
| EQ | 기존 음색 유지, 강화 OFF↔ON 변경, 모드별 유효 effect session 확인 | EQ 상태 및 음악앱/오디오 세션 로그 |
| 시동·미디어 | 경고 서비스 지연 감소 / 앱 화면 없이 미디어 재생 | BOOT→INIT timestamps, MediaSession/MediaBrowser |
| 순정 DPI | 순정 UI 짤림 없음 | `wm density`, 순정 복구 스냅샷 |
| 내비5/외부 AVAS | 미구현 상태를 동작으로 위장하지 않음 | OEM NAV/3RD NAV, AVAS read-only markers |

경고: 안전 운전 기능을 새 알림에 의존하지 말고, 주행 중 인위적 위험 유도 시험 금지.
