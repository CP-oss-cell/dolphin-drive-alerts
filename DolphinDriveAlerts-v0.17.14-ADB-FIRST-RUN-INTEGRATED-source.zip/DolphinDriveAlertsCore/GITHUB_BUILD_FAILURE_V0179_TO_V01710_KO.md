# Dolphin Drive Alerts v0.17.9 -> v0.17.10 Kotlin 빌드 오류 수정 보고서

## 실제 GitHub Actions 실패 증거
- 실행: https://github.com/CP-oss-cell/dolphin-drive-alerts/actions/runs/38002316774
- checkout commit: `3adb548027dc17a2b42ac351de1c84c065ebc169`
- 입력 ZIP: `DolphinDriveAlerts-v0.17.9-OEM-SIGNAL-RECOVERY-source.zip`
- 입력 ZIP SHA-256: `4ad343050621f0b8f5cd8cf5302e8cc7ee14f5a0426629b826348f8d0d76a3c1` (로그/라이브러리 bytes 일치)
- 경과: 문서 사전 검증 PASS, 음성 자산 생성 및 Android 리소스 처리까지 진행.
- 실패: `:app:compileDebugKotlin`, `DrivingAlertService.kt:232:5`
  `A 'return' expression required in a function with a block body ('{...}')`.
- `BUILD FAILED in 1m 11s`. v0.17.9 설치 APK 없음. GitHub failure artifact ID `11649713896`는 오류 로그임.

## 원인 (확인됨)
`DrivingAlertService.createReferenceBridge(normalLogger, normalGate): Any`는 `Any` 반환형의 블록 함수인데 끝부분이 `ctor.newInstance(...).also { start() }`로만 끝남. Kotlin의 블록 본문 함수는 표현식만으로 반환하지 않아 명시적 `return` 필요.

## 최소 소스 수정
- `DrivingAlertService.kt`: `return ctor.newInstance(this, normalLogger, normalGate, tripleTap).also { c.getMethod("start").invoke(it) }`. reflection 생성/시작·핸들 3연타 게이트 의미 변경 없음.
- `app/build.gradle.kts`: versionCode 35→36, versionName `0.17.10-oem-bridge-compile-fix`.
- 전용 신규 검증: `verify_v01710_reference_bridge_contract.py` (음성 생성/SDK 설정 이전 실행), `verify_v01710_reference_bridge_kotlin.py` (실제 함수 원문 Kotlin 컴파일 및 start/핸들 3연타 런타임 스텁 검사).
- 과거 57·48개 검사에서 버전Code가 35에 고정돼 있던 두 문항만 35 이상 호환으로 변경. 이외 기존 생산 코드 변경 없음.
- 워크플로에서는 기존 음성/EQ/미디어/BYD/ADAS/AVAS/분할/자동실행 기능 빌드를 유지하고 아티팩트 사전 검사 강화. APK cryptographic signature verify 명령 추가.

## 실제 로컬 검증
- v0.17.8 기존 회귀: 57/57 PASS
- v0.17.9 기존 회귀: 48/48 PASS
- v0.17.10 별도 반환문 계약: PASS
- 실제 함수 추출 Kotlin 컴파일+실행: PASS (`ReferenceVehicleEventBridge.start`, triple tap 허용/차단)
- 실제 EQ/Media/BYD Reader/ADAS Callback Kotlin 일부 소스 typed-stub 컴파일: 각각 PASS
- ZIP CRC/SHA 및 YML YAML 파싱: 아래 통합 검사 결과 참조.

## 확실히 구분해야 하는 상태
- **v0.17.9 Android GitHub APK 빌드: FAILED**.
- **v0.17.10 소스/테스트 수정 및 로컬 Kotlin fixture 컴파일: PASS**.
- **v0.17.10 Android SDK Gradle 전체 컴파일/아티팩트 업로드/실차 기능: NOT VERIFIED**. GitHub Actions를 새 워크플로로 돌린 뒤 판단.
- 기존 DA-010(운전석 내비) 및 DA-012(외부 AVAS) 미구현/미검증 유지. NORMAL/BSD 좌우/전방·차선·도어/ICC와 분할/DPI/EQ는 기존 v0.17.9 상태에서 승격하지 않음.
