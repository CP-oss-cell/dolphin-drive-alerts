# Dolphin Drive Alerts v0.17.12 — EQ 소폭 강화 / 음장 차이 보완

기준 소스: v0.17.11 BSD Any Blinker Generic (원본 ZIP 유지)  
기존 DA-015 확대, 새 기능 이슈 번호 발급 없음.

## 사용자 실차 관찰
- EQ는 만족하나 저·중·고음 체감이 약간 약함.
- Reference/Surround/Cinema 음장 3종의 차이가 잘 느껴지지 않음.
- 실제 멀티채널·OEM 음장 DSP가 작동하는지 미확인.

## 실제 코드 수정
1. **기존 EQ 기본값 보존**: 사용자 3밴드 기본 0.6dB/step, 선명 0.8, 강력 1.0. 신규 옵션 `EQ 미세 강화 (+12%)`는 OFF 기본. 옵션 사용 시 선택한 3밴드 조절량만 12% 증가하되 ±10dB 클램프/부스트 헤드룸 보호 동일. 구버전 설정값 자동 호환.
2. **표시 수정**: 종전 UI는 강도를 선명·강력으로 변경해도 dB를 항상 0.6 기준으로 보여줬음. 이제 실제 EqToneCurve.userBandDb 값(impactLevel·미세강화 포함)을 표시하고 실시간 갱신.
3. **음장 구별 강화**: Reference 프리셋 보정 0 그대로. Surround 0.95/-0.65/+1.1dB, Cinema +1.65/-0.55/+0.5dB의 완만한 교차곡선 적용. 종전 하드 분기(250/4000Hz) 경계 제거. 헤드룸 계산에 포함.
4. **공간 확장 ON 상태 중복 개선**: 종전 50% 강도에서 세 모드가 동일한 Virtualizer 500으로 수렴. 수정 후 Reference 500(원래대로), Surround 575, Cinema 650으로 구분. Virtualizer를 지원하지 않는 차량 출력 경로라면 공간효과는 미지원 상태 그대로 표시.
5. 전체 OEM 360/Bose DSP 구현 주장은 금지. 타 앱 음악의 실제 소리 변화는 별도 실차 A/B 확인 필요.

## 안전·회귀 기준
- 기존 BSD 경고 3종, 기어·오토홀드·회생제동·노멀 연구 상태, 분할·DPI·부팅·미디어 앱·AVAS 소스 로직 수정 없음.
- 기존 57/57, 48/48 통합 검사 및 v0.17.11 BSD 실제 Kotlin 재현 검사 유지.
- v0.17.12 신규 **실제 EqToneCurve Kotlin 실행 검사**: 기본 EQ 보존, 미세 강화 증가, 클램프/헤드룸, Reference/Surround/Cinema 공간감 구분, 프리셋 부드러운 경계, UI 설정/원복.
- 실제 Android API 스텁 EQ Kotlin 컴파일을 CI에 유지. 전체 Android compile/assemble는 GitHub Actions 재검증 전.
- 실차에서 EQ 변화 청취 / Virtualizer 지원 여부 / 오디오 라우팅 / 왜곡은 미검증.

## A/B 실차 시험
1. 음악 재생 중 기존 값 그대로 청취 → `EQ 미세 강화` ON/OFF 비교(동일 볼륨).
2. `공간 확장 ON`, 공간감 강도 50에서 Reference → Surround → Cinema를 비교.
3. `EQ=APPLIED` / `SPATIAL=API_ON` 등 상태 기록. API_ON은 실제 스피커 공간효과 성공을 보장하지 않음.
4. 왜곡·음량 펌핑·소리 안 들림 발생 시 미세 강화 OFF 또는 EQ OFF로 즉시 복귀.
