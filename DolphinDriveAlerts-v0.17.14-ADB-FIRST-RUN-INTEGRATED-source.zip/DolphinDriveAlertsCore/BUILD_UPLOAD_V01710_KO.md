# Dolphin Drive Alerts v0.17.10 GitHub 업로드 및 빌드 방법

1. GitHub 저장소 `CP-oss-cell/dolphin-drive-alerts`의 최상위 폴더에 `DolphinDriveAlerts-v0.17.10-BRIDGE-RETURN-FIX-source.zip`을 업로드합니다. **v0.17.9 소스를 덮어쓰지 마세요.**
2. `.github/workflows/build-v01710-from-source-zip.yml` 경로에 동봉 YML을 올립니다.
3. Actions → `Build Dolphin Drive Alerts v0.17.10 Bridge Return Fix APK` → Run workflow.
4. 초반 `Preflight explicit return in OEM ReferenceBridge`가 통과하는지 확인합니다. 그런 뒤 `:app:compileDebugKotlin`, `:app:assembleDebug`, Artifact 업로드의 순서로 검증합니다.
5. Actions의 `DolphinDriveAlerts-v0.17.10-BRIDGE-RETURN-FIX` Artifact에서 실제 APK를 받습니다. CI가 실패하면 최신 빌드 로그를 제공해 주세요.

**주의:** 이 ZIP은 APK가 아니라 소스/빌드 안내입니다. Android Gradle 전체 빌드 성공 또는 실차 검증 완료를 주장하지 않습니다. 기존 앱 업데이트 시 서명키가 기존 설치 APK와 같아야 합니다. `DOLPHIN_DEBUG_KEYSTORE_B64`는 선택 설정이며, 없다면 CI 실행별 debug 서명이 달라질 수 있습니다. 근거 없이 기존 앱 삭제를 권하지 않습니다.
