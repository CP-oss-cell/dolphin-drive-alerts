# v0.17.14 GitHub 빌드/차량 설치 안내 (PC 연결 불필요)

대상 저장소: https://github.com/CP-oss-cell/dolphin-drive-alerts

1. GitHub 저장소 **루트**에 `DolphinDriveAlerts-v0.17.14-ADB-FIRST-RUN-INTEGRATED-source.zip` 업로드.
2. `.github/workflows/build-v01714-from-source-zip.yml` 경로로 제공 YML 업로드.
3. GitHub Actions → **Build Dolphin Drive Alerts v0.17.14 ADB First Run Integrated APK** → Run workflow.
4. Compile Kotlin + assemble APK가 성공하면 Artifacts `DolphinDriveAlerts-v0.17.14-ADB-FIRST-RUN-INTEGRATED`에서 APK를 받아 차량에 설치. GitHub에만 업로드하면 차량이 자동 업데이트되지는 않음.
5. 현재 설치 앱에서 업데이트 설치하려면 기존 APK와 **동일한 서명 인증서**가 필요. 기존 `DOLPHIN_DEBUG_KEYSTORE_B64` GitHub Secret이 있을 경우 동일한 키로 서명하도록 YML 유지. 서명 다르면 데이터 보존 업데이트 불가.
6. **PC 연결 없이** Dolphin Drive 실행 → 첫 실행 안내 '연결 화면 열기' → '연결 및 승인 요청' → 차량이 실제로 표시하는 RSA 신뢰 대화상자를 직접 확인하여 승인 → `READY` 확인 → 2분할 프로필로 복귀하여 두 앱 실행.
7. 포트가 닫혔을 땐 앱으로 adbd를 켜거나 RSA 팝업을 강제로 생성할 수 없음. 해당 상황을 상태와 스크린샷으로 알려줘야 원인을 확인할 수 있음.
8. `ADB=READY`는 연결 성공이지 분할 성공이 아님. 실제 2개 앱의 화면 배치와 비율, 카메라 사용 후 복원 결과를 각각 기록.

**주의**: 이번에는 GitHub 빌드용 소스와 워크플로를 제공하는 것이며 APK 생성, 실차 설치, RSA 승인 성공은 아직 확인하지 않았습니다.
