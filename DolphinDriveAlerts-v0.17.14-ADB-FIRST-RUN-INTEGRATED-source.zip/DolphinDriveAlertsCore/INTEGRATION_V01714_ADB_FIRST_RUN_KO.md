# Dolphin Drive Alerts v0.17.14 — 로컬 ADB 최초 승인·2분할 진입 통합
기준: 2026-10-10 / 기준 소스 v0.17.13 versionCode39 → v0.17.14 versionCode40 / 패키지 com.byd.dolphin.drivealerts / 기존 DA-027 확장.

## 사용자의 실차 문제
- AutoSplit은 처음 설치·실행 시 ADB 승인을 요청하고 실제 2분할·비율 변경이 정상.
- 우리 Dolphin Drive는 첫 실행 RSA 승인 안내가 없고, 승인 요청 UI 없는 상태로 분할을 시도하여 ADB 미승인이 원인일 수 있음.
- PC 연결 없이 **차량 앱 내부의 로컬 ADB만** 사용. 차량 adbd 서비스가 열려 있지 않으면 앱만으로 강제 켤 수는 없음.

## 변경된 실제 앱 코드
1. `ui/AdbSetupActivity.kt` 신규: 로컬 127.0.0.1:5555 포트 상태, 앱 전용 ADB RSA 인증 시도(90초), 진행 메시지, 취소, 재시도, 상태 재확인, 분할 프로필 복귀. 허가 받기 전 임의 pm grant/차량 MCU 쓰기 없음.
2. `ui/MainActivity.kt`: 최초 실행에서 한 번만 '연결 화면 열기' 또는 '나중에' 안내. 상단에 상시 '차량 ADB 연결 · RSA 승인 요청 · 상태 확인' 버튼. 기존 서비스·BSD·EQ·음성 그대로 보존.
3. `dpi/NativeAdbClient.kt`: 기존 `waitForAuthorization`을 실제 버튼과 연결, `cancelled()` 및 `onProgress()` 추가, 250ms 구간에 취소 감지, 앱 고유 `adbkey`/`adbkey.pub` 영구 사용, 무해한 `echo drivealerts_adb_ok` 응답으로 READY 확인.
4. `automation/SplitProfilesActivity.kt`: 분할 실행 전에 인증 상태 선검사. 인증 실패 시 설정 화면으로 이동하는 선택지 제공; 승인 뒤 자동으로 분할 실행하지 않고 사용자가 재실행하도록 함. 바로가기에서도 미인증 시 ADB 안내 화면을 표시.
5. `AndroidManifest.xml`: 비공개 `.ui.AdbSetupActivity` 등록.
6. `app/build.gradle.kts`: versionCode40/versionName 0.17.14-first-run-adb-auth. 기존 앱 패키지 ID와 설치 데이터 보존.

## 읽기 / 쓰기 경계
- 인증/진단 단계: 앱 자체 저장소 키, TCP ADB handshake, 무해한 `echo` 및 `id`, `am help`. ADB 연결 성공은 shell 인증에만 해당하고 분할 화면 성공이나 개별 Android 권한 획득을 뜻하지 않음.
- 분할 화면 프로필 실행 때만 기존 `am start --windowingMode 3/4`, `am stack resize-docked-stack` 사용. 기존 app1+app2 task와 bounds readback 검사 유지.
- 차량의 로컬 adbd가 닫혔거나 자동차 펌웨어가 ADB를 막으면 RSA popup을 강제로 표시할 수 없음. AutoSplit의 인증키 복사·서명 우회·root 강제·PC 필수 연결을 구현하지 않음.

## 검증
- `tools/verify_v01714_adb_onboarding.py`: 17/17 정적 계약 검사 PASS.
- 실제 `NativeAdbClient.kt` + `AuthorizedAdbRuntime.kt` Kotlin 최소 스텁 컴파일 및 실행 테스트 PASS: 로컬 TCP, wait success, cancel, 앱 키 보존, reconnect.
- 선행 v0.17.8 57/57, v0.17.9 48/48, v0.17.13 25/25 PASS.
- v0.17.11 BSD, v0.17.12 EQ, v0.17.13 정책, v0.17.10 OEM 참조 브리지 Kotlin 검사 PASS.
- YML 정적 파싱/배포 필수 파일 대조/압축 CRC 수행.
- **전체 Android :app:compileDebugKotlin/:app:assembleDebug 미실행**(로컬 Android SDK 없음). GitHub Actions 필수.
- **한국형 돌핀 실차 RSA popup·ADB_READY·2분할 실제 성공 미검증**. 완료/VERIFIED로 표시하지 않음.

## 실차 수용 시험 (PC 불필요)
1. 설치 첫 실행 → '연결 화면 열기' 클릭. 이미 이전 버전에서 사용했어도 v0.17.14 최초 설치 후 업데이트 시 새 안내 1회.
2. '연결 및 승인 요청' → OEM RSA 인증 팝업이 실제 뜨는지 확인하고 사용자가 허용. 90초 내 READY 결과, id 성공 확인.
3. '분할 프로필로 돌아가기'에서 앱1/앱2 지정 → 분할 실행 → 화면에 실제 2개 앱이 표시되는지, 요청 비율인지 확인.
4. 카메라/360 실행 후 분할 복구 시험 및 로그 수집.
5. 시동 껐다 켜고 ADB 상태 재확인; 키 재사용/포트 닫힘/재인증/권한 거부 구분. 오류 화면과 로그 업로드.

## 상태
`DA-027 P0 / FIRST_RUN_ADB_UI_CODE_IMPLEMENTED / LOCAL_KOTLIN_PASS / FULL_ANDROID_BUILD_REQUIRED / REALCAR_RSA_AND_SPLIT_UNVERIFIED`.
