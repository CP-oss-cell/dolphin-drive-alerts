# v0.17.12 GitHub Actions 빌드 업로드

1. GitHub `CP-oss-cell/dolphin-drive-alerts` 저장소 **루트**에 `DolphinDriveAlerts-v0.17.12-EQ-GENTLE-TUNE-source.zip` 업로드.
2. `.github/workflows/` 아래 `build-v01712-from-source-zip.yml` 업로드.
3. Actions → `Build Dolphin Drive Alerts v0.17.12 EQ Gentle Tune APK` → Run workflow.
4. 성공 시 `DolphinDriveAlerts-v0.17.12-EQ-GENTLE-TUNE` Artifact에서 APK 설치.
5. 기존 앱 위에 설치하려면 디버그 keystore가 일치해야 하므로 기존 `DOLPHIN_DEBUG_KEYSTORE_B64` Secret 복원/서명 지문 대조.

변경: 저중고 EQ 미세 강화 +12% 옵션(기본 OFF), 음장 모드 구분, 실제 강도 dB 표시. v0.17.11 BSD 로직 그대로. APK는 GitHub Actions 실행 전 없음.
