#!/usr/bin/env python3
"""Actual EQ arithmetic Kotlin smoke + persisted settings/UI contract; not real-car sound verification."""
from pathlib import Path
import subprocess, tempfile, shutil, sys, re
p=Path(__file__).resolve().parents[1]
a=p/'app/src/main/java/com/byd/dolphin/drivealerts/audio'
u=p/'app/src/main/java/com/byd/dolphin/drivealerts/ui/AudioTuningActivity.kt'
prefs=(a/'EqPreferences.kt').read_text()
ui=u.read_text()
assert 'val subtleBoost: Boolean = false' in prefs
assert 'p.getBoolean(K_SUBTLE_BOOST, false)' in prefs
assert 'fun setSubtleBoost' in prefs
assert 'EqPreferences.setSubtleBoost(this@AudioTuningActivity, false)' in ui
assert 'EqToneCurve.userBandDb(EqPreferences.read(this), value)' in ui
assert 'EQ 미세 강화' in ui
print('PASS EQ settings persist OFF-by-default / reset / accurate band readout')
kt=shutil.which('kotlinc')
java=shutil.which('java')
if not kt or not java:
    print('SKIP local Kotlin runtime - GitHub Gradle Android compile is required')
    sys.exit(0)
fixture='''package com.byd.dolphin.drivealerts.audio
 enum class SoundFocusMode { REFERENCE, SURROUND, CINEMA }
 data class EqSettings(val bass:Int=0,val mid:Int=0,val treble:Int=0,val impactLevel:Int=0,
   val subtleBoost:Boolean=false,val centerpoint360:Boolean=false,val spatialStrength:Int=50,
   val soundFocus:SoundFocusMode=SoundFocusMode.REFERENCE)
'''
smoke='''package com.byd.dolphin.drivealerts.audio
import kotlin.math.abs
fun eqCheck(ok:Boolean, msg:String) { check(ok) { msg } }
fun main() {
  val normal=EqSettings(bass=4,mid=-3,treble=2)
  eqCheck(abs(EqToneCurve.userBandDb(normal,4)-2.4f)<.001f,"unchanged default")
  eqCheck(abs(EqToneCurve.gainDb(normal,63)-2.4f)<.001f,"reference bass unchanged")
  val fine=normal.copy(subtleBoost=true)
  eqCheck(abs(EqToneCurve.userBandDb(fine,4)-2.688f)<.001f,"12 percent fine boost")
  eqCheck(EqToneCurve.gainDb(fine,63)>EqToneCurve.gainDb(normal,63),"opt-in improvement")
  eqCheck(EqToneCurve.userBandDb(fine.copy(impactLevel=2),10)<=10f,"gain clamp")
  eqCheck(EqToneCurve.userBandDb(fine.copy(impactLevel=2),-10)>=-10f,"negative clamp")
  val freqs=intArrayOf(63,125,250,500,1000,2000,4000,8000,16000)
  for (focus in SoundFocusMode.values()) {
    for (i in -10..10) {
      val x=normal.copy(bass=i,mid=i/2,treble=-i,impactLevel=2,subtleBoost=true,soundFocus=focus)
      for (hz in freqs) eqCheck(EqToneCurve.gainDb(x,hz) in -10f..10f,"safe band range")
      val hr=EqToneCurve.headroomDb(x,freqs)
      eqCheck(hr<=0f && freqs.all{EqToneCurve.gainDb(x,it)+hr<=.01f},"headroom")
    }
  }
  val s=EqSettings(centerpoint360=true,spatialStrength=50)
  eqCheck(EqToneCurve.virtualizerStrength(s)==500.toShort(),"Reference unchanged")
  eqCheck(EqToneCurve.virtualizerStrength(s.copy(soundFocus=SoundFocusMode.SURROUND))==575.toShort(),"Surround distinct")
  eqCheck(EqToneCurve.virtualizerStrength(s.copy(soundFocus=SoundFocusMode.CINEMA))==650.toShort(),"Cinema distinct")
  eqCheck(EqToneCurve.virtualizerStrength(s.copy(spatialStrength=0))==0.toShort(),"spatial OFF")
  eqCheck(EqToneCurve.virtualizerStrength(s.copy(spatialStrength=100,soundFocus=SoundFocusMode.CINEMA))<=1000,"strength cap")
  eqCheck(EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.CINEMA),63)>EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.SURROUND),63),"cinema bass")
  eqCheck(EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.SURROUND),12000)>EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.CINEMA),12000),"surround treble")
  // The preset transitions must not have hard stair-step edges.
  eqCheck(abs(EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.SURROUND),179)-EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.SURROUND),181))<.1f,"low crossover smooth")
  eqCheck(abs(EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.CINEMA),5599)-EqToneCurve.gainDb(s.copy(soundFocus=SoundFocusMode.CINEMA),5601))<.1f,"high crossover smooth")
  println("PASS Kotlin actual EqToneCurve default, fine strength, focus modes, clamp, headroom, transitions")
}
'''
with tempfile.TemporaryDirectory(prefix='eq_gentle_') as d:
    d=Path(d); (d/'Fixture.kt').write_text(fixture); (d/'Smoke.kt').write_text(smoke)
    out=d/'eq-smoke.jar'
    c=subprocess.run([kt,str(d/'Fixture.kt'),str(d/'Smoke.kt'),str(a/'EqToneCurve.kt'),'-include-runtime','-d',str(out)],text=True,capture_output=True,timeout=90)
    if c.returncode!=0: print('FAIL compile',c.stderr[-5000:]);sys.exit(2)
    c=subprocess.run([java,'-jar',str(out)],text=True,capture_output=True,timeout=20)
    if c.returncode!=0: print('FAIL run',(c.stdout+c.stderr)[-5000:]);sys.exit(2)
    print(c.stdout.strip())
