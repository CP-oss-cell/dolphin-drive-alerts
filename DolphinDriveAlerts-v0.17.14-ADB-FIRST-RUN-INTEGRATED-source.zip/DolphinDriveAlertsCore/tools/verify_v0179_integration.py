#!/usr/bin/env python3
"""Guard actual v0.17.9 research changes and v0.17.8 compatibility. Not real-car VERIFIED."""
from pathlib import Path
from xml.etree import ElementTree as ET
import subprocess, sys
p=Path(__file__).resolve().parents[1]
src=p/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda x:(src/x).read_text(encoding='utf-8')
code={x:read(x) for x in ['service/DrivingAlertService.kt','service/BootReceiver.kt','vehicle/ReferenceVehicleEventBridge.kt',
'vehicle/BydVehicleReader.kt','vehicle/DriveModeDecoder.kt','vehicle/TurnSignalReadback.kt','vehicle/LinkLockBsdDecoder.kt',
'log/BydEventTap.kt','log/ReadOnlySignalProbe.kt','log/TargetedSignalProbe.kt','log/SystemDiagnosticsCollector.kt',
'ui/MainActivity.kt','automation/MediaPlaybackObserver.kt','automation/AutoLaunchSequenceService.kt',
'automation/VehicleSplitEngine.kt','dpi/DisplaySettingsController.kt','audio/EqToneCurve.kt','dpi/ExternalAppAudioRouter.kt']}
has=lambda path,value:value in code[path]
checks={
 'version-is-35': any(f'versionCode = {v}' in (p/'app/build.gradle.kts').read_text() for v in range(35, 60)), # v0.17.9+ compatible
 'app-id-same': 'applicationId = "com.byd.dolphin.drivealerts"' in (p/'app/build.gradle.kts').read_text(),
 'read-probe-expiring-miss':has('log/ReadOnlySignalProbe.kt','unavailableUntil[className] = now + vendorUnavailableRetryMs'),
 'read-probe-clears-stale-extended':has('log/ReadOnlySignalProbe.kt','extendedCache.clear()'),
 'read-probe-stale-binder':has('log/ReadOnlySignalProbe.kt','devices.remove(className)'),
 'targeted-getter-expiring-miss':has('log/TargetedSignalProbe.kt','missesUntil[key] = now + retryAfterMs'),
 'targeted-getter-mode':has('log/TargetedSignalProbe.kt','Target("energy.operationMode", ENERGY, "getOperationMode")'),
 'targeted-getter-left':has('log/TargetedSignalProbe.kt','Target("light.leftTurn", LIGHT, "getLeftTurnLightState")'),
 'targeted-getter-right':has('log/TargetedSignalProbe.kt','Target("light.rightTurn", LIGHT, "getRightTurnLightState")'),
 'vehicle-reader-reacquire':has('vehicle/BydVehicleReader.kt','stale OEM binder cleared'),
 'passive-tap-health':has('log/BydEventTap.kt','fun healthSnapshot()'),
 'passive-tap-count-duplicates':has('log/BydEventTap.kt','suppressed(source)'),
 'passive-tap-domain-counters':has('log/BydEventTap.kt','domainCounts'),
 'normal-bridge-health':has('vehicle/ReferenceVehicleEventBridge.kt','fun callbackHealth()'),
 'normal-bridge-candidate':has('vehicle/ReferenceVehicleEventBridge.kt','DIPILOT_HAZARD_CALLBACK_CANDIDATE'),
 'normal-bridge-event':has('vehicle/ReferenceVehicleEventBridge.kt','heard(source)'),
 'normal-bridge-pilot':has('vehicle/ReferenceVehicleEventBridge.kt','heard("dipilot.special")'),
 'wake-bridge-rebind':has('service/DrivingAlertService.kt','REFERENCE_WAKE_REBIND_ATTEMPTED'),
 'wake-bridge-recreate':has('service/DrivingAlertService.kt','REFERENCE_WAKE_RECREATE'),
 'wake-worker-not-main':has('service/DrivingAlertService.kt','referenceExecutor.execute'),
 'wake-mitigation-cooldown':has('service/DrivingAlertService.kt','now - lastReferenceRebindMs < 8_000L'),
 'wake-capture-rebind':has('service/DrivingAlertService.kt','rebindCaptureTap("ignition:$source", force = hardWake)'),
 'service-reference-health':has('service/DrivingAlertService.kt','REFERENCE_CALLBACK_HEALTH'),
 'service-tap-health':has('service/DrivingAlertService.kt','BYD_CALLBACK_HEALTH'),
 'nav-compare-quick':has('log/SystemDiagnosticsCollector.kt','"04_audio_flinger.txt" to "dumpsys media.audio_flinger"'),
 'nav-compare-oem-button':has('ui/MainActivity.kt','2602_OEM_NAV_GUIDANCE'),
 'nav-compare-third-party-button':has('ui/MainActivity.kt','2602_THIRD_PARTY_NAV_GUIDANCE'),
 'stock-avas-readonly-window':has('ui/MainActivity.kt','2602_AVAS_STOCK_SETTING'),
 'no-avas-write': 'setBuffer(' not in code['log/SystemDiagnosticsCollector.kt'] and 'setAVAS' not in code['ui/MainActivity.kt'],
 'normal-eco-preserved':has('vehicle/DriveModeDecoder.kt','1 -> AlertEvent.DRIVE_ECO'),
 'normal-sport-preserved':has('vehicle/DriveModeDecoder.kt','2 -> AlertEvent.DRIVE_SPORT'),
 'normal-no-guess':has('vehicle/ReferenceVehicleEventBridge.kt','noFallbackFromOtherModes=true'),
 'bsd-active-2':has('vehicle/LinkLockBsdDecoder.kt','raw == 2'),
 'bsd-no-hazard-side-inference':has('vehicle/ReferenceVehicleEventBridge.kt','blinkerSideNotHazardSide=true'),
 'bsd-no-force-left':not has('vehicle/TurnSignalReadback.kt','== 5 -> Side.LEFT'),
 'pilot-no-speculative-speech':not has('vehicle/ReferenceVehicleEventBridge.kt','emit(AlertEvent.LEAD_CAR_DEPARTURE'),
 'pilot-door-no-speculative-speech':not has('vehicle/ReferenceVehicleEventBridge.kt','emit(AlertEvent.EXIT_REAR_WARNING'),
 'media-no-ui-existing':has('automation/AutoLaunchSequenceService.kt','MediaPlaybackObserver.playWithoutUi'),
 'media-browser-retained':has('automation/MediaPlaybackObserver.kt','MediaBrowser('),
 'split-support-read-only':has('automation/VehicleSplitEngine.kt','fun capabilities('),
 'global-dpi-guard':has('dpi/DisplaySettingsController.kt','requested <= 120'),
 'eq-impact-preserved':has('audio/EqToneCurve.kt','1 -> 0.8f; 2 -> 1.0f'),
 'nav-cross-uid-honest':has('dpi/ExternalAppAudioRouter.kt','OEM cross-UID hook not implemented'),
 'manifest-parse':ET.parse(p/'app/src/main/AndroidManifest.xml') is not None,
 'boot-receiver-preserved':has('service/BootReceiver.kt','DrivingAlertService.start('),
 'apk-build-workflow':(p/'.github/workflows/build-v0179-from-source-zip.yml').exists(),
 'new-oem-kotlin-compile-test':(p/'tools/verify_v0179_oem_kotlin_compile.py').is_file(),
 'new-callback-kotlin-compile-test':(p/'tools/verify_v0179_callback_kotlin_compile.py').is_file(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'), k)
print(f'V0179 INTEGRATION {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):sys.exit(2)
