#!/usr/bin/env python3
"""Compile and execute EXACT source method DrivingAlertService.createReferenceBridge.

Uses stubbed interfaces for dependencies and an actual mock reflection target. This is
NOT the Android Gradle SDK compile; the CI :app:compileDebugKotlin remains authoritative.
"""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
source_file = ROOT / 'app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt'
source = source_file.read_text(encoding='utf-8')
needle = 'private fun createReferenceBridge(normalLogger: RawSignalLogger, normalGate: AlertGate): Any {'
assert source.count(needle) == 1, 'source function moved or duplicated'
start = source.index(needle)
brace = source.index('{', start)
level = 0
end = None
for i in range(brace, len(source)):
    if source[i] == '{':
        level += 1
    elif source[i] == '}':
        level -= 1
        if level == 0:
            end = i + 1
            break
assert end is not None
method = source[start:end]
assert 'return ctor.newInstance(this, normalLogger, normalGate, tripleTap).also' in method
assert method.count('SteeringPlaybackGuard.allow()') == 1
assert shutil.which('kotlinc') and shutil.which('java'), 'kotlinc + java required'
files = {
    'android.kt': '''package android.content
open class Context''',
    'logging.kt': '''package com.byd.dolphin.drivealerts.log
class RawSignalLogger {
  var markerCount = 0
  var suppressedCount = 0
  fun marker(key: String, data: String) { markerCount += 1 }
  fun diagnostic(key: String, data: String) { suppressedCount += 1 }
}''',
    'steering.kt': '''package com.byd.dolphin.drivealerts.steering
import android.content.Context
object SteeringTriggerPreferences {
 var enabledForTest = true
 fun enabled(context: Context): Boolean = enabledForTest
 fun soundFile(context: Context): String = "triple-tap.wav"
}
object SteeringPlaybackGuard { var allowed = true; fun allow(): Boolean = allowed }''',
    'vehicle.kt': '''package com.byd.dolphin.drivealerts.vehicle
import android.content.Context
import com.byd.dolphin.drivealerts.log.RawSignalLogger
class AlertGate
class ReferenceVehicleEventBridge(
  val context: Context, val logger: RawSignalLogger,
  val gate: AlertGate, val tripleTap: Runnable
) {
 var started = false
 fun start() { started = true }
}''',
    'service.kt': '''package com.byd.dolphin.drivealerts.service
import android.content.Context
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.vehicle.AlertGate
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences
class AudioStub { var playCount=0; fun playOneShot(file: String, reason: String) { playCount += 1 } }
class DrivingAlertService : Context() {
 var audio: AudioStub? = AudioStub()
 FUN_TEXT
 fun runBridge(logger: RawSignalLogger, gate: AlertGate): Any = createReferenceBridge(logger, gate)
}'''.replace('FUN_TEXT', method),
    'main.kt': '''package com.byd.dolphin.drivealerts.service
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.vehicle.AlertGate
import com.byd.dolphin.drivealerts.vehicle.ReferenceVehicleEventBridge
import com.byd.dolphin.drivealerts.steering.SteeringPlaybackGuard
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences
fun main() {
 val service = DrivingAlertService()
 val logger = RawSignalLogger()
 val bridge = service.runBridge(logger, AlertGate()) as ReferenceVehicleEventBridge
 check(bridge.started) { "ReferenceVehicleEventBridge.start was not called" }
 bridge.tripleTap.run()
 check(service.audio!!.playCount == 1)
 SteeringPlaybackGuard.allowed = false
 bridge.tripleTap.run()
 check(service.audio!!.playCount == 1)
 check(logger.suppressedCount == 1)
 SteeringPlaybackGuard.allowed = true
 SteeringTriggerPreferences.enabledForTest = false
 bridge.tripleTap.run()
 check(service.audio!!.playCount == 1)
 check(logger.suppressedCount == 2)
 println("PASS v0.17.10 actual source Kotlin bridge reflection+start+triple-tap gating")
}'''
}
with tempfile.TemporaryDirectory(prefix='byd-bridge-compile-') as folder:
    temp = Path(folder)
    for name, content in files.items():
        (temp/name).write_text(content, encoding='utf-8')
    cmd = ['kotlinc'] + [str(temp/name) for name in files] + ['-include-runtime','-d',str(temp/'test.jar')]
    p = subprocess.run(cmd,capture_output=True,text=True,timeout=130)
    if p.returncode != 0:
        raise SystemExit('Actual extracted source Kotlin compile FAILED\n'+p.stdout+'\n'+p.stderr)
    p = subprocess.run(['java','-jar',str(temp/'test.jar')],capture_output=True,text=True,timeout=30)
    if p.returncode != 0:
        raise SystemExit('Actual extracted source runtime FAILED\n'+p.stdout+'\n'+p.stderr)
    print(p.stdout.strip())
