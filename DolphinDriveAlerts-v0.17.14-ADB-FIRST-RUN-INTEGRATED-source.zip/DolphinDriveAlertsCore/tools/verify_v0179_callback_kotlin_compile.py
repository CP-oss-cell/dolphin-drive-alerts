#!/usr/bin/env python3
"""Compile actual BYD listener & safety gate Kotlin sources against bundled Java BYD interfaces.
Also run heartbeat/side safety smoke without registering vehicle hardware; NOT full Gradle.
"""
from pathlib import Path
import tempfile, subprocess, shutil
p=Path(__file__).resolve().parents[1];j=p/'app/src/main/java';app=j/'com/byd/dolphin/drivealerts'
relative=['log/BydEventTap.kt','vehicle/ReferenceVehicleEventBridge.kt','vehicle/TurnSignalReadback.kt','vehicle/LinkLockBsdDecoder.kt','vehicle/BsdAlertDecision.kt','vehicle/DriveModeDecoder.kt','vehicle/AlertGate.kt','vehicle/AutoHoldSwitchDecoder.kt','vehicle/AutoHoldEngagementDecoder.kt','model/AlertModels.kt']
real=[str(app/x) for x in relative]
java=list((j/'android/hardware').rglob('*.java'))
assert len(java)>=6
stubs={
'Context.kt':'''package android.content
open class Context { val applicationContext: Context get()=this }
''',
'AlertPreferences.kt':'''package com.byd.dolphin.drivealerts.config
import android.content.Context
object AlertPreferences {
 fun bsdBlinkerEnabled(c:Context)=true
 fun bsdInstantEnabled(c:Context)=false
}
''',
'CoreLog.kt':'''package com.byd.dolphin.drivealerts.util
object CoreLog {
 fun w(tag:String,message:String,t:Throwable?=null){}
 fun i(tag:String,message:String){}
}
''',
'BydPermissionContext.kt':'''package com.byd.dolphin.drivealerts.vehicle
import android.content.Context
object BydPermissionContext { fun wrap(c: Context): Context = c }
''',
'RawSignalLogger.kt':'''package com.byd.dolphin.drivealerts.log
class RawSignalLogger {
 fun bydEvent(source:String,eventType:Int,value:String?,featureNames:List<String> = emptyList(),detail:String?=null){}
 fun marker(label:String,detail:String?=null){}
 fun diagnostic(message:String,detail:String?=null){}
}
''',
'FeatureIdCatalog.kt':'''package com.byd.dolphin.drivealerts.log
class FeatureIdCatalog { fun namesFor(type:Int):List<String> = emptyList() }
''',
'Runner.kt':'''package com.byd.dolphin.drivealerts.log
import android.content.Context
import com.byd.dolphin.drivealerts.vehicle.TurnSignalReadback
import com.byd.dolphin.drivealerts.model.Side
fun main() {
 val tap=BydEventTap(Context(),RawSignalLogger(),FeatureIdCatalog())
 check(tap.healthSnapshot()=="NO_CALLBACKS_RECEIVED")
 tap.close()
 check(TurnSignalReadback(Context()).read().side==Side.UNKNOWN)
 println("PASS CALLBACK_HEARTBEAT_AND_SAFE_UNKNOWN_SIDE")
}
'''}
with tempfile.TemporaryDirectory(prefix='v0179_callbacks_') as td:
 d=Path(td);cls=d/'classes';cls.mkdir()
 cp=subprocess.run(['javac','-d',str(cls),*map(str,java)],capture_output=True,text=True,timeout=40)
 print(cp.stderr[-1500:]);assert cp.returncode==0,'BYD Java event compat stub failure'
 paths=[]
 for n,v in stubs.items():
  f=d/n;f.write_text(v);paths.append(str(f))
 jar=d/'test.jar'
 cmd=['kotlinc','-classpath',str(cls),*real,*paths,'-include-runtime','-d',str(jar)]
 build=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
 print(build.stdout[-400:]);print(build.stderr[-2500:]);assert build.returncode==0,'Real BYD callback Kotlin compilation failed'
 run=subprocess.run(['java','-cp',str(jar)+':'+str(cls),'com.byd.dolphin.drivealerts.log.RunnerKt'],capture_output=True,text=True,timeout=12)
 print(run.stdout,run.stderr[-1200:]);assert run.returncode==0,'BYD listener heartbeat smoke failed'
 print('PASS 9_REAL_OEM_CALLBACK_KOTLIN_SOURCE_COMPILE')
