#!/usr/bin/env python3
"""v0.17.8 source regression and safety gates. No claim of vehicle or full Android compile."""
from pathlib import Path
from xml.etree import ElementTree as ET
import json
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda rel:(j/rel).read_text(encoding='utf-8')
src={rel:read(rel) for rel in [
    'vehicle/ReferenceVehicleEventBridge.kt','vehicle/DriveModeDecoder.kt','vehicle/TurnSignalReadback.kt',
    'automation/AutoLaunchSequenceService.kt','automation/MediaPlaybackObserver.kt',
    'automation/VehicleSplitEngine.kt','automation/SplitProfilesActivity.kt','automation/AutoLaunchSettingsActivity.kt',
    'dpi/DisplaySettingsController.kt','audio/EqToneCurve.kt','audio/EqPreferences.kt',
    'audio/GlobalEqualizerEngine.kt','service/BootReceiver.kt','service/DrivingAlertService.kt',
    'model/AlertModels.kt','ui/AudioTuningActivity.kt','ui/AppPolicyActivity.kt',
    'dpi/ExternalAppAudioRouter.kt','log/UnifiedLogCapture.kt']}
c=lambda p,x:x in src[p]
checks={
'version-current': any(f'versionCode = {v}' in (p/'app/build.gradle.kts').read_text() for v in range(35, 60)), # v0.17.9+ compatible
'package-unchanged':'applicationId = "com.byd.dolphin.drivealerts"' in (p/'app/build.gradle.kts').read_text(),
'eco-unchanged': c('vehicle/DriveModeDecoder.kt','1 -> AlertEvent.DRIVE_ECO'),
'sport-unchanged': c('vehicle/DriveModeDecoder.kt','2 -> AlertEvent.DRIVE_SPORT'),
'normal-no-guess': c('vehicle/ReferenceVehicleEventBridge.kt','normalRaw0Unverified=true;noFallbackFromOtherModes=true'),
'normal-value-0-candidate':c('vehicle/DriveModeDecoder.kt','0 -> AlertEvent.DRIVE_NORMAL'),
'bsd-unknown-side-voice-until-hazard-side-verified':c('vehicle/ReferenceVehicleEventBridge.kt','AlertRequest(AlertEvent.BSD_WARNING, Side.UNKNOWN)'),
'bsd-no-raw-only-bypass':'emit(AlertEvent.BSD_WARNING,' not in src['vehicle/ReferenceVehicleEventBridge.kt'],
'bsd-unknown-suppressed':c('vehicle/ReferenceVehicleEventBridge.kt','BSD_GATE_SUPPRESSED'),
'bsd-accepted-trace':c('vehicle/ReferenceVehicleEventBridge.kt','BSD_GATE_ACCEPTED'),
'bsd-read-only':c('vehicle/TurnSignalReadback.kt','getLeftTurnLightState'),
'bsd-no-made-up-raw5-mapping':'== 5 -> Side.LEFT' not in src['vehicle/TurnSignalReadback.kt'],
'pilot-candidate-trace':c('vehicle/ReferenceVehicleEventBridge.kt','DIPILOT_HAZARD_CALLBACK_CANDIDATE'),
'pilot-safe-not-assumed': c('vehicle/ReferenceVehicleEventBridge.kt','eventMeaningUnverified=true'),
'no-false-door-voice':'emit(AlertEvent.EXIT_REAR_WARNING,' not in src['vehicle/ReferenceVehicleEventBridge.kt'],
'front-car-callback-present':c('vehicle/ReferenceVehicleEventBridge.kt','onFrontCarStartStateChange'),
'lane-callback-present':c('vehicle/ReferenceVehicleEventBridge.kt','onDriveDepartureStateChanged'),
'icc-preserved':c('vehicle/ReferenceVehicleEventBridge.kt','emit(AlertEvent.ICC_ON'),
'regen-2-preserved':c('vehicle/ReferenceVehicleEventBridge.kt','emit(AlertEvent.REGEN_STANDARD'),
'regen-3-preserved':c('vehicle/ReferenceVehicleEventBridge.kt','emit(AlertEvent.REGEN_HIGH'),
'autohold-preserved':c('vehicle/ReferenceVehicleEventBridge.kt','pollAutoHoldEngagement'),
'boot-enabled':c('service/BootReceiver.kt','DrivingAlertService.start('),
'boot-timestamp':c('service/BootReceiver.kt','BOOT_RX_TIME'),
'service-initialization-duration':c('service/DrivingAlertService.kt','SERVICE_INIT_DURATION'),
'reference-init-worker':c('service/DrivingAlertService.kt','referenceExecutor.execute'),
'service-initial-fg':src['service/DrivingAlertService.kt'].index('startForeground(')<src['service/DrivingAlertService.kt'].index('referenceExecutor.execute'),
'early-media-not-blocked-by-adb':src['automation/AutoLaunchSequenceService.kt'].index('MediaPlaybackObserver.playWithoutUi')<src['automation/AutoLaunchSequenceService.kt'].index('AuthorizedAdbRuntime.awaitReady'),
'media-browser':c('automation/MediaPlaybackObserver.kt','MediaBrowser('),
'media-browser-exported-check':c('automation/MediaPlaybackObserver.kt','it.exported'),
'media-browser-connection-timeout':c('automation/MediaPlaybackObserver.kt','finished.await(5, TimeUnit.SECONDS)'),
'media-background-only-no-ui':c('automation/AutoLaunchSequenceService.kt','noActivityLaunched=true'),
'media-background-new-label':c('automation/AutoLaunchSettingsActivity.kt','화면 열지 않고 백그라운드 재생만'),
'no-blind-global-media-key': 'input keyevent 85' not in src['automation/AutoLaunchSequenceService.kt'],
'split-two-app-still':c('automation/VehicleSplitEngine.kt','firstSeen') and c('automation/VehicleSplitEngine.kt','secondSeen'),
'split-readonly-probe':c('automation/VehicleSplitEngine.kt','fun capabilities('),
'split-no-fake-34-way':c('automation/VehicleSplitEngine.kt','3분할/4분할/멀티팝업=지원 확인 불가'),
'split-capability-visible':c('automation/SplitProfilesActivity.kt','분할/멀티팝업 지원 상태 진단'),
'split-bounds':c('automation/VehicleSplitEngine.kt','SplitBoundsReadback.primaryPercent'),
'global-density-120-guard':c('dpi/DisplaySettingsController.kt','requested <= 120'),
'global-density-stock-reset':c('dpi/DisplaySettingsController.kt','val target = requested'),
'global-density-readback':c('dpi/DisplaySettingsController.kt','val after = readDensity(app)'),
'dpi-no-fake-emulation':c('dpi/DisplaySettingsController.kt','앱별 DPI나 가짜 해상도는 현재 미구현'),
'eq-default-preserved':c('audio/EqToneCurve.kt','else -> 0.6f'),
'eq-extra-2-modes':c('audio/EqToneCurve.kt','1 -> 0.8f; 2 -> 1.0f'),
'eq-settings-persist':c('audio/EqPreferences.kt','K_IMPACT'),
'eq-ui-select':c('ui/AudioTuningActivity.kt','음색 변화 강도'),
'eq-no-fake-oem':c('audio/GlobalEqualizerEngine.kt','OEM_360=UNSUPPORTED_OEM_DSP'),
'eq-headroom':c('audio/EqToneCurve.kt','fun headroomDb'),
'eq-backwards-compat':c('audio/EqToneCurve.kt','val dbPerStep'),
'nav-5-specified':c('dpi/ExternalAppAudioRouter.kt','NavigationApp("MCon K"'),
'nav-route-honest':c('dpi/ExternalAppAudioRouter.kt','OEM cross-UID hook not implemented'),
'adas-no-write': 'setAVHState(' not in src['vehicle/ReferenceVehicleEventBridge.kt'],
'avas-not-faked': 'AVAS_EXTERNAL_PLAY_SUCCEEDED' not in src['service/DrivingAlertService.kt'],
'capture-resume-preserved':c('service/DrivingAlertService.kt','rebindCaptureTap('),
'log-zip-preserved':c('service/DrivingAlertService.kt','UnifiedLogCapture.finish'),
'voice-preserved':(p/'tools/voice_prompts.json').exists(),
'manifest-parse':ET.parse(p/'app/src/main/AndroidManifest.xml') is not None,
}
assert len(checks)>=50
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
print(f'SOURCE_GATES {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):raise SystemExit(2)
