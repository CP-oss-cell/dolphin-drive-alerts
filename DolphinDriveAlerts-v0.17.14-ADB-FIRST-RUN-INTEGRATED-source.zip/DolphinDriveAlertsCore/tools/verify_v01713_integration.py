#!/usr/bin/env python3
"""Source contracts for merged v0.17.13, not equivalent to Android build or real-car test."""
from pathlib import Path
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/byd/dolphin/drivealerts'
s=lambda name:(p/name).read_text()
a=s('config/AlertPreferences.kt'); b=s('vehicle/ReferenceVehicleEventBridge.kt'); ui=s('ui/MainActivity.kt'); split=s('automation/VehicleSplitEngine.kt');eq=s('audio/EqToneCurve.kt')
checks={
 'v0.17.13-or-later-version-code': any(f'versionCode = {v}' in (root/'app/build.gradle.kts').read_text() for v in range(39, 50)),
 'same-application-id': 'applicationId = "com.byd.dolphin.drivealerts"' in (root/'app/build.gradle.kts').read_text(),
 'BSD-blinker-on-default':'getBoolean(KEY_BSD_INDICATOR, true)' in a,
 'BSD-instant-off-default':'getBoolean(KEY_BSD_INSTANT, false)' in a,
 'BSD-persistent-toggle':'setBsdBlinkerEnabled' in a and 'setBsdInstantEnabled' in a,
 'BSD-2-buttons-visible':'BSD 감지 즉시 일반 후측방 음성' in ui and '어느 한쪽 깜빡이' in ui,
 'BSD-no-guessed-side':'AlertRequest(AlertEvent.BSD_WARNING, Side.UNKNOWN)' in b,
 'BSD-arbiter-used':'bsdDecision.onRaw' in b and 'bsdDecision.onIndicator' in b,
 'BSD-no-left-fabrication':'AlertRequest(AlertEvent.BSD_WARNING, Side.LEFT)' not in b,
 'ADAS-no-fake-speech': 'eventMeaningUnverified=true;noSpeech=true' in b,
 'ADAS-icc-correlation':'iccConfirmed=$accActive' in b,
 'NORMAL-cycle-correct':'ECO_NORMAL_SPORT_ECO' in b,
 'NORMAL-raw-meaning-unverified':'normalRaw0Unverified=true' in b,
 'NORMAL-eco-preserved':'1 -> AlertEvent.DRIVE_ECO' in s('vehicle/DriveModeDecoder.kt'),
 'NORMAL-sport-preserved':'2 -> AlertEvent.DRIVE_SPORT' in s('vehicle/DriveModeDecoder.kt'),
 'SPLIT-no-ADB-privilege-claim':'설치 앱 권한 부여 성공과 분할 셸 권한은 서로 다릅니다' in split,
 'SPLIT-ownership-readback':'SplitTaskReadback.inspect(' in split,
 'SPLIT-real-bounds-check':'SplitBoundsReadback.primaryPercent' in split,
 'SPLIT-no-fake-34-popup':'3분할/4분할/멀티팝업=지원 확인 불가' in split,
 'EQ-gentle-default-preserved':'K_SUBTLE_BOOST' in s('audio/EqPreferences.kt') and 'getBoolean(K_SUBTLE_BOOST, false)' in s('audio/EqPreferences.kt'),
 'EQ-custom-switch':'EQ 미세 강화' in s('ui/AudioTuningActivity.kt'),
 'MEDIA-background':'MediaBrowser(' in s('automation/MediaPlaybackObserver.kt'),
 'AVAS-no-ECU-write':'AVAS_EXTERNAL_PLAY_SUCCEEDED' not in s('service/DrivingAlertService.kt'),
 'Boot-still-on':'DrivingAlertService.start(' in s('service/BootReceiver.kt'),
 'App-manifest-parse':ElementTree.parse(root/'app/src/main/AndroidManifest.xml') is not None,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
print(f'INTEGRATED_SOURCE_CHECKS={sum(checks.values())}/{len(checks)}')
assert all(checks.values())
