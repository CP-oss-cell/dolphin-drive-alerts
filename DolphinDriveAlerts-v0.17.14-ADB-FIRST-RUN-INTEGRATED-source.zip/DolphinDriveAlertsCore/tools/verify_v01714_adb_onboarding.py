#!/usr/bin/env python3
"""Source/contract validation and Kotlin JVM exercise of NativeAdbClient ADB handshake.
NOT a substitute for Android Gradle build or actual BYD RSA dialog.
"""
from pathlib import Path
import tempfile, subprocess, textwrap, shutil, os, sys
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/byd/dolphin/drivealerts'
a=(p/'dpi/NativeAdbClient.kt').read_text()
u=(p/'ui/AdbSetupActivity.kt').read_text()
m=(p/'ui/MainActivity.kt').read_text()
s=(p/'automation/SplitProfilesActivity.kt').read_text()
manifest=ElementTree.parse(root/'app/src/main/AndroidManifest.xml')
checks={
    'version40': 'versionCode = 40' in (root/'app/build.gradle.kts').read_text(),
    'packagePreserved': 'applicationId = "com.byd.dolphin.drivealerts"' in (root/'app/build.gradle.kts').read_text(),
    'firstRunExplicitConsent': 'setPositiveButton("연결 화면 열기")' in m and 'setNegativeButton("나중에"' in m,
    'oneTimePrompt': 'markFirstRunShown' in m and 'getBoolean(SEEN, false)' in u,
    'noAutomaticGrant': 'PermissionBootstrapper.apply' not in u and 'pm grant' not in u,
    'adbWaitUsed': 'NativeAdbClient.waitForAuthorization(' in u,
    'wait90sec': 'maxWaitMs = 90_000L' in u,
    'cancelWired': 'cancelled = { cancelled.get() }' in u and 'cancelled.set(true)' in u,
    'progressUpdates': 'onProgress = { msg -> showStatus(msg) }' in u,
    'readOnlyHealth': 'AuthorizedAdbRuntime.health' in u and '"id"' in u,
    'persistedKeys': 'adbkey.pub' in a and 'AdbKeyPair.read' in a,
    'manifestActivity': any(x.attrib.get('{http://schemas.android.com/apk/res/android}name')=='.ui.AdbSetupActivity' and x.attrib.get('{http://schemas.android.com/apk/res/android}exported')=='false' for x in manifest.findall('.//activity')),
    'splitPreflight': 'split-adb-preflight' in s and 'auth.state != AuthorizedAdbRuntime.State.READY' in s,
    'shortcutAuth': 'split-shortcut-adb-preflight' in s and 'ADB 인증 필요' in s,
    'existingSplitTaskBounds': 'SplitBoundsReadback.primaryPercent' in (p/'automation/VehicleSplitEngine.kt').read_text(),
    'originalAlertPreserved': 'BSD 감지 즉시 일반 후측방 음성' in m,
    'eqPreserved': 'EQ 미세 강화' in (p/'ui/AudioTuningActivity.kt').read_text(),
}
for n,pass_ in checks.items(): print(('PASS' if pass_ else 'FAIL'),n)
assert all(checks.values()), 'new ADB onboarding contract violated'

if '--static-only' in sys.argv:
 print(f'ADB_FIRST_RUN_STATIC={sum(checks.values())}/{len(checks)}; Kotlin phase deferred')
 sys.exit(0)

if shutil.which('kotlinc') and shutil.which('java'):
 with tempfile.TemporaryDirectory(prefix='adb-v01714-kotlin-') as td:
  t=Path(td)
  def save(name,content):
   dest=t/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(textwrap.dedent(content));return str(dest)
  sources=[str(p/'dpi/NativeAdbClient.kt'), str(p/'dpi/AuthorizedAdbRuntime.kt')]
  sources.append(save('android/content/Context.kt', '''
    package android.content
    import java.io.File
    class Context(val filesDir:File) {
      val applicationContext:Context get()=this
    }
  '''))
  sources.append(save('android/os/SystemClock.kt', '''
    package android.os
    object SystemClock { fun elapsedRealtime():Long = System.nanoTime()/1000000L }
  '''))
  sources.append(save('com/byd/dolphin/drivealerts/util/CoreLog.kt', '''
    package com.byd.dolphin.drivealerts.util
    object CoreLog {
      fun i(a:String,b:String){};fun w(a:String,b:String){}
    }
  '''))
  sources.append(save('dadb/Dadb.kt', '''
    package dadb
    import java.io.File
    class AdbKeyPair {
      companion object {
        fun generate(a: File, b: File) { a.writeText("local-secret"); b.writeText("local-public") }
        fun read(a: File,b: File): AdbKeyPair { check(a.exists()&&b.exists()); return AdbKeyPair() }
      }
    }
    class Response(val exitCode:Int,val allOutput:String)
    class Dadb {
      fun close() {}
      fun shell(cmd:String):Response=Response(0,if(cmd.startsWith("echo")) cmd.removePrefix("echo ")+"\\n" else "uid=2000(shell)")
      companion object { fun create(host:String,port:Int,key:AdbKeyPair)=Dadb() }
    }
  '''))
  sources.append(save('Test.kt', '''
    import android.content.Context
    import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
    import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
    import java.io.File
    import java.net.ServerSocket
    import java.util.concurrent.atomic.AtomicBoolean
    fun main(args:Array<String>) {
      val c=Context(File(args[0],"adb-home").apply{mkdirs()})
      val stop=AtomicBoolean(false)
      val a=NativeAdbClient.waitForAuthorization(c,1_000L,"127.0.0.1",45601,cancelled={true})
      check(a.message.contains("취소"))
      val port=ServerSocket(0)
      val serving=Thread {
        while(!stop.get()) try { port.accept().close() } catch (ex:Exception) { break }
      }.apply { isDaemon=true;start() }
      try {
        val messages=mutableListOf<String>()
        val success=NativeAdbClient.waitForAuthorization(c,1_000L,"127.0.0.1",port.localPort,onProgress={ messages.add(it) })
        check(success.success && success.output.contains("drivealerts_adb_ok"))
        check(c.filesDir.resolve("adbkey").readText()=="local-secret")
        check(c.filesDir.resolve("adbkey.pub").exists())
        check(messages.any{it.contains("READY")})
        check(AuthorizedAdbRuntime.classify(success)==AuthorizedAdbRuntime.State.READY)
        // Reconnect must re-use the existing key, not erase/re-generate it.
        NativeAdbClient.close()
        val second=NativeAdbClient.waitForAuthorization(c,1_000L,"127.0.0.1",port.localPort)
        check(second.success)
        check(c.filesDir.resolve("adbkey").readText()=="local-secret")
        println("PASS NativeAdbClient actual Kotlin compile/runtime: RSA-wait success/cancel/persisted-key/reconnect")
      } finally {stop.set(true);port.close();serving.join(1000);NativeAdbClient.close()}
    }
  '''))
  jar=t/'test.jar';arg=['kotlinc',*sources,'-include-runtime','-jvm-target','17','-d',str(jar)]
  q=subprocess.run(arg,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=100)
  if q.returncode:raise AssertionError('Actual NativeAdbClient Kotlin type compile FAILED:\n'+q.stdout[-6500:])
  q=subprocess.run(['java','-jar',str(jar),str(t)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
  print(q.stdout[-2000:]);assert q.returncode==0
else:print('SKIP Kotlin JVM verification: kotlin compiler unavailable; Android Gradle compile required')
print(f'ADB_FIRST_RUN_STATIC={sum(checks.values())}/{len(checks)}')
