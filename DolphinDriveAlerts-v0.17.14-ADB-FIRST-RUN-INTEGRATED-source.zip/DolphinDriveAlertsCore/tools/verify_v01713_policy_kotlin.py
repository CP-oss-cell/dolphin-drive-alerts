#!/usr/bin/env python3
"""Compile/run ACTUAL isolated v0.17.13 Kotlin decision classes against deterministic fixtures."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
app=root/'app/src/main/java/com/byd/dolphin/drivealerts'
sources=[app/'vehicle/BsdAlertDecision.kt',app/'automation/SplitTaskReadback.kt',app/'vehicle/DriveModeDecoder.kt',app/'model/AlertModels.kt']
runner='''package com.byd.dolphin.drivealerts.vehicle
import com.byd.dolphin.drivealerts.automation.SplitTaskReadback
import com.byd.dolphin.drivealerts.model.AlertEvent
fun main() {
    val b=BsdAlertDecision()
    check(!b.onRaw(1,true))
    check(!b.onRaw(2,false))
    check(!b.onIndicator(false,true))
    check(b.onIndicator(true,true))
    check(!b.onIndicator(true,true))
    check(!b.onRaw(2,true))
    b.onRaw(1,false)
    check(b.onRaw(2,true))
    check(!b.onIndicator(true,true))
    b.onRaw(1,false)
    check(!b.onRaw(2,false))
    check(!b.onIndicator(true,false))
    check(b.onIndicator(true,true))
    check(DriveModeDecoder.fromEnergyOperationMode(1)==AlertEvent.DRIVE_ECO)
    check(DriveModeDecoder.fromEnergyOperationMode(0)==AlertEvent.DRIVE_NORMAL)
    check(DriveModeDecoder.fromEnergyOperationMode(2)==AlertEvent.DRIVE_SPORT)
    val good="""Task{101 mode=3 A=com.example.one} ActivityRecord{com.example.one/A}
Task{102 mode=4 A=com.example.two} ActivityRecord{com.example.two/B}"""
    val valid=SplitTaskReadback.inspect(good,"com.example.one","com.example.two")
    check(!valid.hasDefinitiveMismatch && "SPLIT_TASKS_SEEN" in valid.detail) {valid.detail}
    val bad="""Task{101 mode=1 A=com.example.one} ActivityRecord{com.example.one/A}
Task{102 mode=1 A=com.example.two} ActivityRecord{com.example.two/B}"""
    val invalid=SplitTaskReadback.inspect(bad,"com.example.one","com.example.two")
    check(invalid.hasDefinitiveMismatch) {invalid.detail}
    val unknown=SplitTaskReadback.inspect("dumpsys partial", "com.example.one", "com.example.two")
    check(!unknown.hasDefinitiveMismatch && "UNRESOLVED" in unknown.detail)
    println("PASS BSD_DUAL_MODE_ONCE_PER_HAZARD; SPLIT_MODE_READBACK; DRIVE_ECO_NORMAL_SPORT_SEQUENCE_MAPPING_ONLY")
}
'''
with tempfile.TemporaryDirectory(prefix='v01713_kotlin_') as temp:
    d=Path(temp);f=d/'Runner.kt';f.write_text(runner)
    jar=d/'test.jar'
    cmd=['kotlinc',*[str(s) for s in sources],str(f),'-include-runtime','-d',str(jar)]
    build=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=75)
    assert build.returncode==0,build.stderr[-4500:]
    r=subprocess.run(['java','-jar',str(jar)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=25)
    assert r.returncode==0,r.stdout+'\n'+r.stderr
    print(r.stdout.strip())
