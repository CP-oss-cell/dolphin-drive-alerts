#!/usr/bin/env python3
"""Compile and exercise actual BSD bridge and BYD light readback with inert fake OEM listeners.
Tests observed raw2 -> either blinker -> generic (side unknown), no repeat until clear.
Not an Android APK or real car validation.
"""
from pathlib import Path
import tempfile, subprocess
p=Path(__file__).resolve().parents[1]
j=p/'app/src/main/java';app=j/'com/byd/dolphin/drivealerts'
relative=['vehicle/ReferenceVehicleEventBridge.kt','vehicle/TurnSignalReadback.kt', 'vehicle/LinkLockBsdDecoder.kt', 'vehicle/BsdAlertDecision.kt','vehicle/DriveModeDecoder.kt','vehicle/AlertGate.kt','vehicle/AutoHoldSwitchDecoder.kt','vehicle/AutoHoldEngagementDecoder.kt','model/AlertModels.kt']
java=list((j/'android/hardware').rglob('*.java'))
stubs={
'Context.kt': '''package android.content
open class Context { val applicationContext: Context get()=this }
''',
'AlertPreferences.kt': '''package com.byd.dolphin.drivealerts.config
import android.content.Context
object AlertPreferences {
 var blinker = true
 var instant = false
 fun bsdBlinkerEnabled(c:Context) = blinker
 fun bsdInstantEnabled(c:Context) = instant
}
''',
'CoreLog.kt': '''package com.byd.dolphin.drivealerts.util
object CoreLog { fun w(tag:String,message:String,t:Throwable?=null){}; fun i(tag:String,message:String){} }
''',
'BydPermissionContext.kt': '''package com.byd.dolphin.drivealerts.vehicle
import android.content.Context
object BydPermissionContext { fun wrap(c: Context): Context = c }
''',
'RawSignalLogger.kt': '''package com.byd.dolphin.drivealerts.log
class RawSignalLogger {
 fun bydEvent(source:String,eventType:Int,value:String?,featureNames:List<String> = emptyList(),detail:String?=null){}
 fun marker(label:String,detail:String?=null){}
 fun diagnostic(message:String,detail:String?=null){}
}
''',
'Runner.kt': '''package com.byd.dolphin.drivealerts.vehicle
import android.content.Context
import android.hardware.bydauto.BYDAutoEventValue
import android.hardware.bydauto.light.BYDAutoLightDevice
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.model.*
class RawEvent(@JvmField val intValue:Int): BYDAutoEventValue()
fun main() {
  val light=BYDAutoLightDevice.getInstance(Context())
  val events=mutableListOf<AlertRequest>()
  val bridge=ReferenceVehicleEventBridge(Context(),RawSignalLogger(),AlertGate { events.add(it) }, Runnable {})
  val m=ReferenceVehicleEventBridge::class.java.getDeclaredMethod("processEvent",String::class.java,Int::class.javaPrimitiveType,BYDAutoEventValue::class.java)
  m.isAccessible=true
  fun bsd(v:Int) = m.invoke(bridge,"adas",0x41800008,RawEvent(v))
  fun assertCount(n:Int,tag:String) { check(events.size==n) { "$tag expected=$n got=${events.size} $events" } }
  // no blinker: never warn
  light.left=0; light.right=0; bsd(2); bridge.pollBsdWithIndicator();assertCount(0,"none")
  // blinker activated only AFTER BSD: exactly one GENERAL warning, not left voice
  light.left=1; bridge.pollBsdWithIndicator();assertCount(1,"left")
  check(events.last().side==Side.UNKNOWN && events.last().event==AlertEvent.BSD_WARNING)
  // despite BSD still active and changing blinker side, prevent duplicate
  light.left=0;light.right=1;repeat(4){ bridge.pollBsdWithIndicator() };assertCount(1,"no_retrigger_same_hazard")
  // new hazard with left/right unknown: right blinker should warn generic again
  bsd(1);Thread.sleep(1850);bsd(2);assertCount(2,"new_hazard_right")
  check(events.last().side==Side.UNKNOWN)
  // hazard lights (both indicators ON) do not trigger
  bsd(1); Thread.sleep(1850);light.left=1;light.right=1;bsd(2);bridge.pollBsdWithIndicator();assertCount(2,"hazards_blocked")
  // after hazard off, transition one active side emits once
  light.left=0;bridge.pollBsdWithIndicator();assertCount(3,"single_after_hazards")
  // SDK unknown/missing raw (eg -1) must not be assumed to mean ON
  bsd(1);Thread.sleep(1850);light.left=-1;light.right=-1;bsd(2);bridge.pollBsdWithIndicator();assertCount(3,"unknown_raw")
  // on blink phase off then on, emits once for same hazard
  light.left=0;light.right=0;bridge.pollBsdWithIndicator();assertCount(3,"blink_off")
  light.left=1;bridge.pollBsdWithIndicator();assertCount(4,"blink_on")
  light.left=0;bridge.pollBsdWithIndicator();light.left=1;bridge.pollBsdWithIndicator();assertCount(4,"blink_no_repeat")
  check(events.all { it.side==Side.UNKNOWN })
  // Additional selectable mode: raw2 without blinker, one generic voice ONLY.
  val prefs=com.byd.dolphin.drivealerts.config.AlertPreferences
  prefs.blinker=false; prefs.instant=true
  Thread.sleep(1850);bsd(1); light.left=0;light.right=0;bsd(2);assertCount(5,"instant_without_blinker")
  light.left=1; repeat(4){bridge.pollBsdWithIndicator()};assertCount(5,"instant_no_double")
  // Both OFF => no new voice, even on hazard+indicator.
  prefs.instant=false; prefs.blinker=false
  Thread.sleep(1850);bsd(1);bsd(2);light.left=1;bridge.pollBsdWithIndicator();assertCount(5,"both_off")
  // Blinker mode enabled alone => generic once, delayed as before.
  prefs.blinker=true
  bridge.pollBsdWithIndicator();assertCount(6,"enable_blinker")
  check(events.all { it.side==Side.UNKNOWN })
  // Three voice paths remain defined and independently addressable for future verified L/R signals.
  check(AlertEvent.BSD_WARNING.phraseFor(Side.UNKNOWN)=="후측방 조심")
  check(AlertEvent.BSD_WARNING.phraseFor(Side.LEFT)=="왼쪽 후측방 조심")
  check(AlertEvent.BSD_WARNING.phraseFor(Side.RIGHT)=="오른쪽 후측방 조심")
  println("PASS v0.17.11 BSD_GENERIC_ON_EITHER_BLINKER; no-both; delayed blinker; no-repeat; reset; voice3")
}
'''
}
lightjava='''package android.hardware.bydauto.light;
import android.content.Context;
public final class BYDAutoLightDevice {
  public int left=0, right=0;
  private static final BYDAutoLightDevice INSTANCE=new BYDAutoLightDevice();
  public static BYDAutoLightDevice getInstance(Context c) { return INSTANCE; }
  public int getLeftTurnLightState() {return left;}
  public int getRightTurnLightState() {return right;}
}
'''
with tempfile.TemporaryDirectory(prefix='bsd1711_real_source_') as t:
 d=Path(t);classes=d/'classes';classes.mkdir();light=d/'BYDAutoLightDevice.java';light.write_text(lightjava)
 ctx=d/'Context.java';ctx.write_text('package android.content; public class Context { public Context getApplicationContext(){return this;} }')
 javac=subprocess.run(['javac','-d',str(classes),*map(str,java),str(light),str(ctx)],capture_output=True,text=True,timeout=30)
 assert javac.returncode==0,javac.stderr
 paths=[]
 for k,v in stubs.items():
  f=d/k;f.write_text(v);paths.append(str(f))
 jar=d/'test.jar'
 cmd=['kotlinc','-classpath',str(classes),*[str(app/x) for x in relative],*paths,'-include-runtime','-d',str(jar)]
 build=subprocess.run(cmd,capture_output=True,text=True,timeout=110)
 assert build.returncode==0,build.stderr[-5000:]
 run=subprocess.run(['java','-cp',f'{jar}:{classes}','com.byd.dolphin.drivealerts.vehicle.RunnerKt'],capture_output=True,text=True,timeout=20)
 assert run.returncode==0,run.stdout+'\n'+run.stderr[-5000:]
 print(run.stdout.strip())
