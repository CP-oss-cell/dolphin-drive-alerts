# v0.17.13 통합 GitHub Actions 수동 빌드

1. GitHub 저장소 `CP-oss-cell/dolphin-drive-alerts` 루트에 **`DolphinDriveAlerts-v0.17.13-ALL-ISSUES-INTEGRATED-source.zip`** 업로드.
2. `.github/workflows/build-v01713-from-source-zip.yml`에 제공 YML 업로드. 다른 v0.17.12 파일을 덮어쓰지 마세요.
3. Actions → **Build Dolphin Drive Alerts v0.17.13 All Issues Integrated APK** → Run workflow.
4. Actions 성공 시 Artifacts → `DolphinDriveAlerts-v0.17.13-ALL-ISSUES-INTEGRATED` → APK/빌드 로그 다운로드.
5. 기존 앱에 업데이트 설치는 APK **서명 인증서 일치** 필요. 다르면 GitHub secret `DOLPHIN_DEBUG_KEYSTORE_B64`를 이전 서명키로 설정하거나 이전 앱/데이터 백업 후 별도 설치 검토.

빌드 완료 후 우선 앱 설정의 **BSD 두 개 독립 ON/OFF**를 확인하세요. 두 옵션 모두 순정 차량 제어를 변경하지 않습니다.

**주의:** ICC 차선이탈/앞차출발, NORMAL 음성, AutoSplit 완전 동일 2분할, 외부 AVAS, 내비5 운전석 전용 출력은 Android 컴파일만으로 정상작동이 확인되지 않습니다. 통합 상세 문서와 실차 검수표를 참고하세요.
