# v0.17.11 GitHub APK 빌드 안내

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 루트에 `DolphinDriveAlerts-v0.17.11-BSD-ANY-BLINKER-GENERIC-source.zip` 업로드.
2. `.github/workflows/` 아래 `build-v01711-from-source-zip.yml` 업로드.
3. Actions에서 `Build Dolphin Drive Alerts v0.17.11 BSD Any Blinker Generic APK` 실행.
4. 성공한 Artifact `DolphinDriveAlerts-v0.17.11-BSD-ANY-BLINKER-GENERIC`에서 APK 다운로드.

기존 APK의 앱 패키지명은 그대로고 versionCode=37. 기존 설치 APK와 서명키가 일치하지 않으면 업데이트 설치 불가. GitHub Secrets `DOLPHIN_DEBUG_KEYSTORE_B64` 옵션 유지. 제작 ZIP에는 APK 미포함; 전체 Android 컴파일은 Actions에서 검증.
