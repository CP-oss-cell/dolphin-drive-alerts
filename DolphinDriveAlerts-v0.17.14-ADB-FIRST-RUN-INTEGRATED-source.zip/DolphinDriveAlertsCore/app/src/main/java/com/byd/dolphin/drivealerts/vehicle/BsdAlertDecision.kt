package com.byd.dolphin.drivealerts.vehicle

/**
 * Pure generic BSD voice arbitration, intentionally ignorant of left/right hazard side.
 * Only an already authenticated ADAS warning candidate (raw 2) may enter active state;
 * never translate a blinker side into a sensor side. One voice per hazard entry.
 */
internal class BsdAlertDecision {
    private var active = false
    private var announced = false

    /** Returns true only for the optional generic immediate announcement on a new entry. */
    @Synchronized fun onRaw(raw: Int, instantEnabled: Boolean): Boolean {
        if (raw != 2) {
            active = false
            announced = false
            return false
        }
        val entered = !active
        active = true
        if (entered && instantEnabled && !announced) {
            announced = true
            return true
        }
        return false
    }

    /** One side blinking (not both) is an audio gate only, NEVER sensor-side evidence. */
    @Synchronized fun onIndicator(anySingleBlinkerActive: Boolean, enabled: Boolean): Boolean {
        if (!active || announced || !enabled || !anySingleBlinkerActive) return false
        announced = true
        return true
    }

    @Synchronized fun isActive(): Boolean = active
    @Synchronized fun isAnnounced(): Boolean = announced
    @Synchronized fun reset() { active = false; announced = false }
}
