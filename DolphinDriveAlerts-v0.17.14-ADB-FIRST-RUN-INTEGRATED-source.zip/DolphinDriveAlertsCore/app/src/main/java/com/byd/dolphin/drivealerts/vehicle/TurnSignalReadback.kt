package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/**
 * Read-only indicator state for BSD audio GATING, never controls vehicle lights.
 * The left/right indicator is a GATE only, not evidence of which BSD sensor fired.
 * Missing SDK or both indicators ON (hazard flashers) => do not speak.
 * Raw ON=1 is a testable SDK candidate; other raw values remain unknown.
 */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    private val lightClass = "android.hardware.bydauto.light.BYDAutoLightDevice"
    data class Result(val side: Side, val detail: String, val anyBlinkerActive: Boolean = false)

    /** Independent indicators: when one is ON, the other may be missing from this SDK. */
    internal fun classify(left: Int?, right: Int?): Boolean =
        (left == 1 || right == 1) && !(left == 1 && right == 1)

    private fun state(names: List<String>): Pair<String, Int>? = runCatching {
        val clazz = Class.forName(lightClass)
        val device = clazz.getMethod("getInstance", Context::class.java).invoke(null, app)
            ?: return@runCatching null
        names.firstNotNullOfOrNull { method ->
            runCatching { (clazz.getMethod(method).invoke(device) as? Number)?.toInt()?.let { method to it } }.getOrNull()
        }
    }.getOrNull()

    fun read(): Result {
        val l = state(listOf("getLeftTurnLightState", "getLeftTurnSignalState", "getLeftTurnLampState"))
        val r = state(listOf("getRightTurnLightState", "getRightTurnSignalState", "getRightTurnLampState"))
        val side = when {
            l?.second == 1 && r?.second == 0 -> Side.LEFT
            r?.second == 1 && l?.second == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        // Only use indicator presence for generic speech. Do NOT send `side` to BSD audio.
        return Result(side, "left=$l right=$r;SDK_ON_1_CANDIDATE;hazardSide=UNKNOWN",
            anyBlinkerActive = classify(l?.second, r?.second))
    }
}
