package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import java.util.concurrent.atomic.AtomicBoolean

/** Local-adbd authorization guide. Never grants permissions without a separate user action. */
class AdbSetupActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private lateinit var cancelButton: Button
    private val cancelled = AtomicBoolean(false)
    @Volatile private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 22, 26, 28)
        }
        fun text(value: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = value; textSize = size; setPadding(0, 7, 0, 7)
        }
        panel.addView(text("차량 ADB 연결 및 RSA 승인", 22f).apply { setTypeface(typeface, Typeface.BOLD) })
        panel.addView(text("① 차량에서 실행되는 Dolphin Drive만으로 127.0.0.1:5555 연결을 시도합니다. PC를 요구하지 않습니다.\n" +
            "② '연결 및 승인 요청'을 누르면 앱 전용 ADB 키로 접속하며 차량의 실제 RSA 승인창이 나타나면 직접 허용하세요.\n" +
            "③ 키는 앱 전용 저장소에 보존됩니다. 재시동·앱 업데이트 후에도 인증 상태를 다시 확인합니다.\n" +
            "※ RSA 팝업은 차량 adbd가 생성합니다. 포트가 닫혀 있거나 OEM이 차단하면 강제로 띄울 수 없습니다. " +
            "다른 앱의 키를 빌리거나 차량 보안을 우회하지 않습니다.",14f))
        status = text("차량 ADB 포트 확인 중…", 15f)
        panel.addView(status)
        connectButton = Button(this).apply {
            text = "연결 및 승인 요청 (최대 90초)"
            setOnClickListener { connect() }
        }
        cancelButton = Button(this).apply {
            text = "연결 대기 취소"
            isEnabled = false
            setOnClickListener { cancelled.set(true); status.text = "취소 요청 중…" }
        }
        panel.addView(connectButton)
        panel.addView(cancelButton)
        panel.addView(Button(this).apply {
            text = "로컬 ADB 상태 다시 확인 (읽기 전용)"
            setOnClickListener { checkStatus() }
        })
        panel.addView(Button(this).apply {
            text = "분할 프로필로 돌아가기"
            setOnClickListener {
                startActivity(Intent(this@AdbSetupActivity,
                    com.byd.dolphin.drivealerts.automation.SplitProfilesActivity::class.java))
                finish()
            }
        })
        setContentView(ScrollView(this).apply { addView(panel) })
        // No background authorization or permission grant on first entry.
        status.text = if (NativeAdbClient.isPortOpen())
            "PORT_OPEN: ADB 포트가 열려 있습니다. 아래 연결 버튼으로 인증 상태를 확인하세요."
        else "PORT_CLOSED: ADB 포트가 닫혀 있습니다. 차량 내부 ADB 서비스 설정을 확인하세요."
    }

    private fun checkStatus() {
        if (running) return
        running = true; connectButton.isEnabled = false
        status.text = "연결 상태 확인 중 (읽기 전용)…"
        Thread({
            try {
                val report = AuthorizedAdbRuntime.health(applicationContext)
                showStatus("${report.state}: ${report.result.message}\n" +
                    if (report.state == AuthorizedAdbRuntime.State.READY)
                        "ADB 인증 완료. 이제 분할 실행을 따로 시험할 수 있습니다."
                    else "ADB 인증 또는 연결에 실패했습니다. '연결 및 승인 요청'을 이용하세요.", done = true)
            } catch (t: Throwable) {
                showStatus("TRANSPORT_ERROR: ${t.javaClass.simpleName}: ${t.message}", done = true)
            }
        }, "adb-status-check").start()
    }

    private fun connect() {
        if (running) return
        running = true
        cancelled.set(false)
        connectButton.isEnabled = false
        cancelButton.isEnabled = true
        status.text = "차량 ADB 연결 시작. 차량 RSA 승인창을 확인하세요."
        Thread({
            try {
                val result = NativeAdbClient.waitForAuthorization(
                    applicationContext,
                    maxWaitMs = 90_000L,
                    cancelled = { cancelled.get() },
                    onProgress = { msg -> showStatus(msg) }
                )
                if (cancelled.get()) {
                    showStatus("ADB 연결 요청 취소됨. 차량 설정은 변경하지 않았습니다.", done = true)
                    return@Thread
                }
                val state = AuthorizedAdbRuntime.classify(result)
                if (state != AuthorizedAdbRuntime.State.READY) {
                    showStatus("$state: ${result.message}\n" +
                        "PORT_CLOSED면 차량 로컬 adbd 활성화가 필요합니다. AUTH_REQUIRED면 RSA 승인 여부를 확인하세요.", done = true)
                    return@Thread
                }
                val identity = AuthorizedAdbRuntime.read(applicationContext, "id", timeoutMs = 4_000L)
                val activityHelp = AuthorizedAdbRuntime.read(applicationContext, "am help", timeoutMs = 4_000L)
                showStatus("READY: 자체 ADB 키로 셸 인증 완료.\n" +
                    "id 명령: ${identity.state} ${identity.result.output.take(200)}\n" +
                    "활동 관리자 확인: ${activityHelp.state}\n" +
                    "이 상태는 ADB 인증 확인이며, 2분할 동작 성공을 보증하지 않습니다. " +
                    "분할 프로필 화면에서 실제 두 앱과 비율을 검증하세요.", done = true)
            } catch (t: Throwable) {
                showStatus("TRANSPORT_ERROR: ${t.javaClass.simpleName}: ${t.message}", done = true)
            }
        }, "adb-rsa-onboarding").start()
    }

    private fun showStatus(message: String, done: Boolean = false) {
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            status.text = message
            if (done) {
                running = false
                connectButton.isEnabled = true
                cancelButton.isEnabled = false
            }
        }
    }

    override fun onDestroy() {
        cancelled.set(true)
        super.onDestroy()
    }

    companion object {
        private const val PREFS = "adb_first_run_ui"
        private const val SEEN = "prompt_shown"
        fun shouldShowFirstRun(context: Context): Boolean =
            !context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(SEEN, false)
        fun markFirstRunShown(context: Context) =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(SEEN, true).apply()
    }
}
