package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/** Independent best-effort system split implementation. OEM stack commands require local ADB. */
object VehicleSplitEngine {
    data class Result(val success: Boolean, val message: String)
    private fun shell(c: Context, command: String): NativeAdbClient.ShellResult =
        if (command.startsWith("wm size") || command.startsWith("am stack list") || command.startsWith("am help") || command.startsWith("cmd activity help") || command.startsWith("dumpsys "))
            AuthorizedAdbRuntime.read(c,command,timeoutMs=4_000).result
        else AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=4_000).result

    /** Read-only platform diagnostics. No unverified 3/4-way or popup commands are sent. */
    fun capabilities(c: Context): String {
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY)
            return "로컬 ADB 상태=${adb.state}; 분할 실행 권한과 별개로 확인 필요"
        val help = shell(c, "am help")
        val current = shell(c, "dumpsys activity activities")
        val activity = shell(c, "cmd activity help")
        val legacy = shell(c, "am stack list")
        val windowing = help.output.contains("windowingMode", ignoreCase = true) ||
            help.output.contains("windowing-mode", ignoreCase = true)
        val splitVisible = current.output.contains("split-screen", ignoreCase = true) ||
            Regex("(?i)windowingMode[=:]\\s*[34]").containsMatchIn(current.output)
        val resizeLegacy = activity.output.contains("resize-docked-stack", ignoreCase = true) ||
            legacy.output.contains("docked", ignoreCase = true)
        return "adb=READY;amStartWindowingOption=$windowing;activeSplitState=$splitVisible;" +
            "legacyResizeHint=$resizeLegacy;activityRead=${current.success};" +
            "3분할/4분할/멀티팝업=지원 확인 불가(OEM 태스크 관리자 기능 별도 검증 필요)"
    }

    fun launch(c: Context, profile: SplitProfile): Result {
        val one = AppSelection.safeComponent(c,profile.firstPackage) ?: return Result(false,"첫 번째 앱을 찾을 수 없음")
        val two = AppSelection.safeComponent(c,profile.secondPackage) ?: return Result(false,"두 번째 앱을 찾을 수 없음")
        if (one == two) return Result(false,"서로 다른 앱 2개를 선택해야 합니다")
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY)
            return Result(false, "로컬 ADB 미준비(${adb.state}): 차량 ADB 포트/RSA 최초 승인을 확인하세요. " +
                "설치 앱 권한 부여 성공과 분할 셸 권한은 서로 다릅니다.")
        CoreLog.i("SPLIT", "adbReady=true first=${profile.firstPackage} second=${profile.secondPackage} pct=${profile.primaryPercent}")
        // Matches the basic Android/DiLink windowing modes found in the reference investigation.
        // Fail rather than claim that an ordinary pair of fullscreen launches was a split.
        val first = shell(c,"am start --windowingMode 3 -n $one")
        if (!first.success) return Result(false,"PRIMARY: ${first.message}")
        val second = shell(c,"am start --windowingMode 4 -n $two")
        if (!second.success) return Result(false,"SECONDARY: ${second.message}")
        // OEM may place our own task into secondary instead of the requested YouTube task.
        // Do not register recovery or report success unless BOTH selected packages are visible.
        Thread.sleep(500L)
        val ownership = shell(c, "dumpsys activity activities")
        val firstSeen = ownership.output.lineSequence().any { it.contains(profile.firstPackage) &&
            (it.contains("Task",true) || it.contains("ActivityRecord",true) || it.contains("Hist",true)) }
        val secondSeen = ownership.output.lineSequence().any { it.contains(profile.secondPackage) &&
            (it.contains("Task",true) || it.contains("ActivityRecord",true) || it.contains("Hist",true)) }
        val taskEvidence = SplitTaskReadback.inspect(ownership.output, profile.firstPackage, profile.secondPackage)
        CoreLog.i("SPLIT", "target task evidence=${taskEvidence.detail}")
        if (!ownership.success || !firstSeen || !secondSeen) {
            CoreLog.w("SPLIT", "SPLIT_TARGET_MISMATCH first=${profile.firstPackage} second=${profile.secondPackage} " +
                "readable=${ownership.success} firstSeen=$firstSeen secondSeen=$secondSeen output=${ownership.output.take(600)}")
            return Result(false, "분할 대상 오류: ${profile.firstPackage} / ${profile.secondPackage} 양쪽 실행 확인 실패. 분할 스택을 점검하세요")
        }
        val state = splitState(c)
        CoreLog.i("SPLIT", "initial split state=${state.output.take(1800)}")
        if (!state.success) return Result(false,"분할 상태 조회 불가: ${state.message}")
        // Do not resize if shell reports no docked stack (could resize unrelated foreground UI).
        if (!state.output.contains("docked",true) && !state.output.contains("split-screen",true)
            && !Regex("(?i)windowingMode[=:]\\s*3").containsMatchIn(state.output))
            return Result(false,"분할 스택 확인 실패 (am stack list 결과 필요)")
        // ADB success can still leave both apps fullscreen or in the same task.
        // Require independent split task evidence when OEM dumpsys exposes it.
        if (taskEvidence.hasDefinitiveMismatch)
            return Result(false,"두 앱 분할 모드 불일치: ${taskEvidence.detail}")
        val ratio = applyRatio(c,profile.primaryPercent)
        if (!ratio.success) return ratio
        FeatureProfiles.markSplit(c,profile.id)
        CoreLog.i("SPLIT", "profile=${profile.id} ratio=${profile.primaryPercent} state=launched")
        return Result(true,"비율 bounds 확인; 앱별 창 분할 상태=${taskEvidence.detail}. 실차 표시 최종 확인 필요")
    }

    fun applyRatio(c: Context, pct: Int): Result {
        val size = shell(c,"wm size")
        if (!size.success) return Result(false,"화면 크기 조회 실패: ${size.message}")
        val match = Regex("(\\d+)x(\\d+)").findAll(size.output).lastOrNull()
            ?: return Result(false,"디스플레이 크기를 해석하지 못함")
        val w = match.groupValues[1].toIntOrNull() ?: return Result(false,"폭 파싱 실패")
        val h = match.groupValues[2].toIntOrNull() ?: return Result(false,"높이 파싱 실패")
        val split = pct.coerceIn(10,90)
        // Automotive head unit normally horizontal, but support portrait split too.
        val boundary = if (w >= h) (w*split/100) else (h*split/100)
        val rectangle = if (w >= h) "0 0 $boundary $h" else "0 0 $w $boundary"
        val command = "am stack resize-docked-stack $rectangle"
        val result = shell(c, command)
        if (!result.success) return Result(false,"비율 명령 거부: ${result.message}")
        val post = splitState(c)
        CoreLog.i("SPLIT", "ratio post state=${post.output.take(2200)}")
        if (!post.success) return Result(false,"비율 적용 후 상태 확인 실패")
        // AutoSplit reference: verify actual windowing mode after resize before reporting success.
        val splitPresent = post.output.contains("docked", true) || post.output.contains("split-screen", true) ||
            Regex("""(?i)windowingMode[=:]\s*[34]""").containsMatchIn(post.output)
        CoreLog.i("SPLIT", "requested=$split screen=${w}x$h boundary=$boundary " +
            "splitPresent=$splitPresent stack=${post.output.take(200)}")
        if (!splitPresent) return Result(false,"비율 적용 후 분할 스택 유실; 다시 분할 실행 필요")
        // Compare the *actual* window/task bounds to the requested primary share.
        // A successful shell command alone is not evidence of 20:80 application.
        val measured = SplitBoundsReadback.primaryPercent(post.output, w, h, split)
        if (measured == null)
            return Result(false, "${split}:${100-split} 요청 전송됨, 분할 스택 bounds 확인 불가; 50:50으로 남았을 수 있음")
        if (kotlin.math.abs(measured - split) > 4)
            return Result(false, "비율 불일치: 요청 ${split}:${100-split}, 실제 ${measured}:${100-measured}")
        return Result(true, "비율 bounds 확인: ${measured}:${100-measured}")
    }

    /** Older DiLink exposes `am stack list`; newer Android may require dumpsys. */
    private fun splitState(c: Context): NativeAdbClient.ShellResult {
        val legacy = shell(c, "am stack list")
        if (legacy.success && (legacy.output.contains("docked",true) ||
            legacy.output.contains("split-screen",true) || legacy.output.contains("windowingMode",true))) return legacy
        val fallback = shell(c, "dumpsys activity activities")
        if (fallback.success) CoreLog.i("SPLIT", "using dumpsys activity split state fallback")
        return if (fallback.success) fallback else legacy
    }

    fun screenToken(c: Context): String? {
        val s = shell(c,"dumpsys activity activities")
        if (!s.success) return null
        val top = s.output.lineSequence().filter {
            it.contains("topResumedActivity",true) || it.contains("mResumedActivity",true) || it.contains("ResumedActivity",true)
        }.lastOrNull() ?: return null
        return top.take(350)
    }
}
