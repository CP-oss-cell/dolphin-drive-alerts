package com.byd.dolphin.drivealerts.automation

/** Read-only consistency check; OEM dumpsys formats differ. No false task ownership. */
internal object SplitTaskReadback {
    data class Inspection(val hasDefinitiveMismatch: Boolean, val detail: String)

    fun inspect(raw: String, first: String, second: String): Inspection {
        // Legacy Android dumpsys splits tasks into Task{} / Task # sections.
        // Missing metadata is UNKNOWN, not a fabricated split success.
        val blocks = raw.split(Regex("(?=Task\\{|Task #\\d+)", RegexOption.IGNORE_CASE))
        fun modesFor(pkg: String): Set<Int> = blocks.filter { pkg in it }.flatMap { block ->
            Regex("(?i)(?:windowingMode|mode)\\s*[=:]\\s*(\\d+)").findAll(block)
                .mapNotNull { it.groupValues[1].toIntOrNull() }.toList()
        }.toSet()
        val a = modesFor(first)
        val b = modesFor(second)
        val knownA = a.filter { it in 1..5 }.toSet()
        val knownB = b.filter { it in 1..5 }.toSet()
        val mismatch = knownA.isNotEmpty() && knownB.isNotEmpty() &&
            !(3 in knownA && 4 in knownB || 4 in knownA && 3 in knownB)
        val verdict = when {
            mismatch -> "MISMATCH"
            3 in knownA && 4 in knownB || 4 in knownA && 3 in knownB -> "SPLIT_TASKS_SEEN"
            else -> "TASK_MODES_UNRESOLVED"
        }
        return Inspection(mismatch, "result=$verdict firstModes=$knownA secondModes=$knownB")
    }
}
