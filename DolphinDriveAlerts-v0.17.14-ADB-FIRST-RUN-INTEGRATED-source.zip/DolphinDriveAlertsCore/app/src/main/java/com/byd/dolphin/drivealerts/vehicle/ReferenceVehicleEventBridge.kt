package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import android.hardware.bydauto.BYDAutoEventValue
import android.hardware.bydauto.adas.AbsBYDAutoADASListener
import android.hardware.bydauto.dipilot.AbsBYDAutoDiPilotListener
import android.hardware.bydauto.energy.AbsBYDAutoEnergyListener
import android.hardware.bydauto.instrument.AbsBYDAutoInstrumentListener
import android.hardware.bydauto.setting.AbsBYDAutoSettingListener
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog
import java.lang.reflect.Modifier
import java.util.ArrayDeque
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Normal-runtime event bridge reconstructed from Byd_SubAI_Beta_v13, which the user reports
 * working on the same Dolphin. BSD warning transition is recovered from verified
 * LinkLock Relay 805's handleBsd() bytecode (raw 2 sets bsdDetected=true).
 * Lane-keeping status and leading-car switch remain distinguished from actual hazards.
 */
class ReferenceVehicleEventBridge(
    context: Context,
    private val logger: RawSignalLogger,
    private val gate: AlertGate,
    private val onSteeringTripleTap: Runnable
) {
    private val app = context.applicationContext
    private data class Binding(val device: Any, val listener: Any)
    private data class StateTime(val value: Int, val timestamp: Long)
    private val bindings = mutableListOf<Binding>()
    private val featureIds = linkedMapOf<String, Int>()
    private val menuHistory = ArrayDeque<StateTime>()
    private var lastAccValue = Int.MIN_VALUE
    private var accActive = false
    private var lastRecycle = Int.MIN_VALUE
    private var lastRoadSurface = Int.MIN_VALUE
    private var lastOperationMode = Int.MIN_VALUE
    private val autoHoldButtonDecoder = AutoHoldSwitchDecoder()
    private val autoHoldEngagementDecoder = AutoHoldEngagementDecoder()
    private val linkLockBsdDecoder = LinkLockBsdDecoder()
    private val turnSignal = TurnSignalReadback(app)
    private val bsdDecision = BsdAlertDecision()
    private val hazardCallbackStates = linkedMapOf<String, Int>()
    private val callbackCounts = ConcurrentHashMap<String, AtomicLong>()
    private val callbackLastMs = ConcurrentHashMap<String, Long>()

    /** Read-only heartbeat; listener registration is not proof of actual event reception. */
    fun callbackHealth(): String {
        val now = System.currentTimeMillis()
        return listOf("instrument", "adas", "energy", "setting", "dipilot", "dipilot.special").joinToString(";") { source ->
            val count = callbackCounts[source]?.get() ?: 0
            val age = callbackLastMs[source]?.let { (now - it).coerceAtLeast(0) } ?: -1L
            "$source=$count,ageMs=$age"
        }
    }

    private fun heard(source: String) {
        callbackCounts.getOrPut(source) { AtomicLong() }.incrementAndGet()
        callbackLastMs[source] = System.currentTimeMillis()
    }
    private var lastBsdSuppressedReason = ""
    private var lastBsdSuppressedAt = 0L

    fun start() {
        if (bindings.isNotEmpty()) return
        loadFeatureIds()
        val wrapped = BydPermissionContext.wrap(app)

        setup(
            "instrument",
            "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
            wrapped,
            object : AbsBYDAutoInstrumentListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("instrument", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("instrument", errCode, errMessage)
            }
        )
        setup(
            "adas",
            "android.hardware.bydauto.adas.BYDAutoADASDevice",
            wrapped,
            object : AbsBYDAutoADASListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("adas", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("adas", errCode, errMessage)
            }
        )
        setup(
            "energy",
            "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
            wrapped,
            object : AbsBYDAutoEnergyListener() {
                override fun onOperationModeChanged(type: Int) = handleOperationMode(type, "callback")
                override fun onEnergyRecycleChanged(state: Int) = handleRecycle(state, "callback")
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("energy", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("energy", errCode, errMessage)
            }
        )

        // SubAI v13 registers the Setting listener as well as Energy.
        // Real Dolphin log: SET_DR_ENERGY_FB (0x34100022) changed 2 -> 3
        // on the *setting* device. Without this listener the alert never fires.
        setup(
            "setting",
            "android.hardware.bydauto.setting.BYDAutoSettingDevice",
            wrapped,
            object : AbsBYDAutoSettingListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("setting", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("setting", errCode, errMessage)
            }
        )

        // LinkLock Relay 805 calls Class.forName("android.hardware.bydauto.dipilot.BYDAutoDipilotDevice")
        // (lowercase p in "pilot"), whereas earlier Dolphin code used a non-existent
        // BYDAutoDiPilotDevice spelling. Try both vendor spellings; never require LinkLock APK.
        val pilotListener = object : AbsBYDAutoDiPilotListener() {
            override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) =
                processEvent("dipilot", eventType, eventValue)
            override fun onFrontCarStartStateChange(state: Int) =
                logPilotCandidate("frontCarStart", state)
            override fun onDriveDepartureStateChanged(state: Int) =
                logPilotCandidate("driveDeparture", state)
            override fun onDrivieDepartureStateChanged(state: Int) =
                logPilotCandidate("drivieDeparture", state)
            override fun onOpenDoorAlertStateChanged(state: Int) =
                logPilotCandidate("openDoorAlert", state)
            override fun onBlindMonitorStateChanged(state: Int) =
                logPilotCandidate("blindMonitor", state)
            override fun onBlindMonitorStateChanged1(state: Int) =
                logPilotCandidate("blindMonitor1", state)
            override fun onBlindMonitorStateChanged2(state: Int) =
                logPilotCandidate("blindMonitor2", state)
            override fun onError(errCode: Int, errMessage: String?) =
                listenerError("dipilot", errCode, errMessage)
        }
        val pilotRegistered = setup(
            "dipilot", "android.hardware.bydauto.dipilot.BYDAutoDipilotDevice", wrapped, pilotListener)
        if (!pilotRegistered) {
            setup("dipilot.alt", "android.hardware.bydauto.dipilot.BYDAutoDiPilotDevice", wrapped, pilotListener)
        }

        logger.diagnostic(
            "REFERENCE_EVENT_BRIDGE_STARTED",
            "subai-v13;bindings=${bindings.size};menu=${featureIds["INSTRUMENT_2IN1_MENU_STATE"]};acc=${featureIds["ADAS_ACC_MODE"]}"
        )
    }

    fun close() {
        bindings.forEach { b ->
            runCatching {
                val method = b.device.javaClass.methods.firstOrNull {
                    it.name == "unregisterListener" && it.parameterCount == 1 && it.parameterTypes[0].isAssignableFrom(b.listener.javaClass)
                } ?: b.device.javaClass.methods.firstOrNull { it.name == "unregisterListener" && it.parameterCount == 1 }
                method?.invoke(b.device, b.listener)
            }
        }
        bindings.clear()
        menuHistory.clear()
        autoHoldButtonDecoder.reset()
        autoHoldEngagementDecoder.reset()
        linkLockBsdDecoder.reset()
        bsdDecision.reset()
        hazardCallbackStates.clear()
        callbackCounts.clear()
        callbackLastMs.clear()
        lastBsdSuppressedReason = ""
    }

    private fun loadFeatureIds() {
        val classes = listOf(
            "android.hardware.bydauto.BYDAutoFeatureIds",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Instrument",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Adas",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Dipilot",
            "android.hardware.bydauto.BYDAutoFeatureIds\$DiPilot",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Energy",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Radar",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Setting"
        )
        for (className in classes) {
            runCatching {
                val c = Class.forName(className)
                for (field in c.declaredFields) {
                    if (Modifier.isStatic(field.modifiers) && field.type == Int::class.javaPrimitiveType) {
                        runCatching { featureIds[field.name] = field.getInt(null) }
                    }
                }
            }
        }
        logger.diagnostic("REFERENCE_FEATURE_IDS_LOADED", "count=${featureIds.size}")
    }

    private fun setup(source: String, className: String, wrapped: Context, listener: Any): Boolean {
        return runCatching {
            val c = Class.forName(className)
            val device = c.getMethod("getInstance", Context::class.java).invoke(null, wrapped) ?: error("getInstance returned null")
            val register = c.methods.firstOrNull {
                it.name == "registerListener" && it.parameterCount == 1 && it.parameterTypes[0].isAssignableFrom(listener.javaClass)
            } ?: c.methods.firstOrNull { it.name == "registerListener" && it.parameterCount == 1 }
            ?: error("registerListener missing")
            register.invoke(device, listener)
            bindings += Binding(device, listener)
            logger.diagnostic("REFERENCE_LISTENER_REGISTERED", source)
            true
        }.onFailure {
            logger.diagnostic("REFERENCE_LISTENER_FAILED", "$source:${it.javaClass.simpleName}:${it.cause?.message ?: it.message}")
            CoreLog.w("REF_BRIDGE", "$source listener failed: ${it.cause?.message ?: it.message}", it)
        }.getOrDefault(false)
    }

    private fun processEvent(source: String, eventType: Int, eventValue: BYDAutoEventValue?) {
        heard(source)
        val value = intValue(eventValue) ?: return
        val names = featureIds.filterValues { it == eventType }.keys.toList()
        logger.bydEvent("reference.$source", eventType, value.toString(), names, "SubAI-v13 compatible listener")

        featureIds["INSTRUMENT_2IN1_MENU_STATE"]?.takeIf { it == eventType }?.let { handleMenuState(value) }
        featureIds["ADAS_ACC_MODE"]?.takeIf { it == eventType }?.let { handleAccMode(value) }

        // Exact constants used in SubAI v13.
        if (eventType == ENERGY_ROAD_SURFACE) handleRoadSurface(value)
        // Independently recover the ENERGY_OPERATION_MODE event if the dedicated
        // onOperationModeChanged callback is unavailable on this firmware.
        // Never infer drive mode from getCurrentDriveInterFace or an ADAS flag.
        if (source == "energy" && (eventType == featureIds["ENERGY_OPERATION_MODE"] ||
                eventType == ENERGY_OPERATION_MODE_OBSERVED)) {
            handleOperationMode(value, "energy:eventType=0x${eventType.toString(16)}")
        }

        val recycleId = featureIds["ENERGY_RECYCLE"]
        val energyFbId = featureIds["SET_DR_ENERGY_FB"]
        // The confirmed 0x34100022 fallback survives missing/renamed SDK feature fields.
        if (eventType == recycleId || eventType == energyFbId || eventType == SET_DR_ENERGY_FB_CONFIRMED) {
            handleRecycle(value, "$source:eventType=0x${eventType.toString(16)}")
        }

        // Vehicle observation: ADAS_AVH_STATE=0/1 transitions occurred repeatedly in
        // user-supplied logs. The user's current request is the AutoHold BUTTON
        // enabled/disabled phrase, not actual wheel-brake engagement/release.
        // Map ONLY the ADAS listener event, and never infer button state from
        // a generic getAVHState polling snapshot or from an ambiguous raw=2.
        if (source == "adas" && eventType == ADAS_AVH_STATE_CONFIRMED) {
            autoHoldButtonDecoder.accept(value)?.let { event ->
                emit(event, "ADAS_AVH_STATE=0x${eventType.toString(16)} raw=$value candidate=BUTTON_STATE")
            }
            autoHoldEngagementDecoder.accept(value, System.currentTimeMillis())?.let { event ->
                emit(event, "AVH raw=$value;engagement=2->1 candidate;realcar_reverify_required")
            }
            logger.diagnostic("AUTOHOLD_BUTTON_ENGAGEMENT_SEPARATE", "raw=$value;2_engaged_candidate_dwell500")
        }

        // Confirmed LinkLock 805 path: SnifferService.onVehicleEvent -> handleBsd(raw)
        // -> bsdDetected=(raw==2) -> beep(). The same event ID 0x41800008
        // is named ADAS_BSD_STATE in the user's 19:59 Dolphin real-car JSONL.
        // Do not mistake the old SubAI "BLIND_SPOT_ASSIST" name for this verified
        // LinkLock alarm path. Only an *ADAS event* can trigger this alert (never a getter).
        val bsdEventId = featureIds["ADAS_BSD_STATE"] ?: ADAS_BSD_STATE_OBSERVED
        if (source == "adas" && (eventType == bsdEventId || eventType == ADAS_BSD_STATE_OBSERVED)) {
            val activation = linkLockBsdDecoder.accept(value)
            val instantEnabled = AlertPreferences.bsdInstantEnabled(app)
            val immediate = bsdDecision.onRaw(value, instantEnabled)
            logger.diagnostic("LINKLOCK_BSD_STATE",
                "raw=$value newActivation=$activation;blinkerMode=${AlertPreferences.bsdBlinkerEnabled(app)};" +
                "instantMode=$instantEnabled;bsdHazardSide=UNKNOWN;raw2RealcarReverifyRequired=true")
            if (immediate) announceGenericBsd("INSTANT_OPTIONAL_RAW2_NEW_HAZARD")
            // The driver may turn on either blinker AFTER hazard detection.
            if (value == 2) pollBsdWithIndicator()
        }
        // Other LinkLock/Beetle candidates need an actual warning-active value,
        // distinct from feature enabled/getter state. Preserve all raw transitions.
        val candidateNames = listOf(
            "ADAS_AVH_STATE", "ADAS_FL_BLIND_SPOT_ALARM", "ADAS_FR_BLIND_SPOT_ALARM",
            "ADAS_LCA_WARNING_LEFT", "ADAS_LCA_WARNING_RIGHT",
            "ADAS_RCTA_WARNING_LEFT", "ADAS_RCTA_WARNING_RIGHT",
            "ADAS_DOW_WARN_LEFT", "ADAS_DOW_WARN_RIGHT",
            "ADAS_RIGHT_RADAR_LCA_WARNINGLEFT", "ADAS_RIGHT_RADAR_LCA_WARNINGRIGHT",
            "ADAS_LANE_DEPARTURE", "ADAS_FRONT_CAR_START"
        ).filter { featureIds[it] == eventType }
        if (eventType == 0x12200046 || candidateNames.isNotEmpty()) {
            logger.diagnostic("ADAS_CANDIDATE_RAW_NO_SPEECH",
                "type=0x${eventType.toString(16)} names=$candidateNames value=$value iccConfirmed=$accActive;eventMeaningUnverified=true;noSpeech=true")
        }
    }

    /** Independent from the ON/OFF button signal; delayed engagement candidate. */
    @Synchronized fun pollAutoHoldEngagement() {
        autoHoldEngagementDecoder.poll(System.currentTimeMillis())?.let { event ->
            emit(event, "AVH raw=2 sustained500ms;realcar_reverify_required")
        }
    }

    /**
     * Temporary global-2602 policy until the *hazard side* is VERIFIED:
     * BSD active (LinkLock raw=2) + EITHER real blinker (left OR right) ->
     * ONE generic BSD_WARNING/UNKNOWN voice. The blinker is not the hazard side.
     * A new BSD activation resets the per-hazard latch; flashing OFF phases do not.
     * Raw left/right indicator getters are read only; no ECU output or CAN write.
     */
    @Synchronized fun pollBsdWithIndicator() {
        if (!linkLockBsdDecoder.isActive() || bsdDecision.isAnnounced() ||
            !AlertPreferences.bsdBlinkerEnabled(app)) return
        val reading = turnSignal.read()
        val now = System.currentTimeMillis()
        if (!reading.anyBlinkerActive) {
            val why = reading.detail
            if (why != lastBsdSuppressedReason || now - lastBsdSuppressedAt > 5_000L) {
                logger.diagnostic("BSD_GATE_SUPPRESSED",
                    "bsdRaw=2 anyBlinkerActive=false reason=$why;leftRightHazardSideUnverified=true")
                lastBsdSuppressedReason = why
                lastBsdSuppressedAt = now
            }
            return
        }
        if (!bsdDecision.onIndicator(reading.anyBlinkerActive, enabled = true)) return
        logger.diagnostic("BSD_GATE_ACCEPTED",
            "bsdRaw=2 ${reading.detail};hazardSide=UNKNOWN;blinkerSideNotHazardSide=true")
        logger.diagnostic("BSD_INDICATOR_GATED", "raw=2 genericOnly=true ${reading.detail}")
        announceGenericBsd("BLINKER_ANY_SIDE;${reading.detail}")
    }

    private fun announceGenericBsd(reason: String) {
        logger.diagnostic("BSD_ALERT_EMITTED", "generic=true;hazardSide=UNKNOWN;reason=$reason")
        gate.submit(AlertRequest(AlertEvent.BSD_WARNING, Side.UNKNOWN))
    }

    private fun logPilotCandidate(callback: String, state: Int) {
        heard("dipilot.special")
        // The callback proves *which* SDK method fired, not whether its integer
        // is a feature switch or a single safety event; avoid phantom alerts.
        val old = hazardCallbackStates.put(callback, state)
        if (old == state) return
        logger.bydEvent("reference.dipilot.$callback", Int.MIN_VALUE, state.toString(),
            detail = "LinkLock/Beetle callback; warning-active semantics UNVERIFIED")
        logger.diagnostic("DIPILOT_HAZARD_CALLBACK_CANDIDATE",
            "callback=$callback transition=$old->$state;eventMeaningUnverified=true;iccConfirmed=$accActive;noSpeech=true")
    }

    private fun intValue(eventValue: Any?): Int? {
        if (eventValue == null) return null
        return runCatching { eventValue.javaClass.getField("intValue").getInt(eventValue) }
            .recoverCatching {
                eventValue.javaClass.getDeclaredField("intValue").apply { isAccessible = true }.getInt(eventValue)
            }.getOrNull()
    }

    private fun handleAccMode(value: Int) {
        if (value == lastAccValue) return
        lastAccValue = value
        when (value) {
            3 -> if (!accActive) {
                accActive = true
                emit(AlertEvent.ICC_ON, "ADAS_ACC_MODE=3")
            }
            0, 1, 2, 4 -> if (accActive) {
                accActive = false
                emit(AlertEvent.ICC_OFF, "ADAS_ACC_MODE=$value")
            }
        }
    }

    private fun handleOperationMode(type: Int, source: String) {
        if (source == "callback") heard("energy.callback")
        if (type == lastOperationMode) return
        val previousMode = lastOperationMode
        lastOperationMode = type
        logger.diagnostic("REFERENCE_OPERATION_MODE", "$source:$type;previous=$previousMode;" +
            "userCycle=ECO_NORMAL_SPORT_ECO;normalRaw0Unverified=true;noFallbackFromOtherModes=true;" +
            "noBlindCycleInference=true;2602_readback_compare_required=true")
        // The drive selector is ECO -> NORMAL -> SPORT; it has no OFF state.
        // User observed ECO incorrectly announced as NORMAL at raw=1.
        // raw=0 is a NORMAL candidate but NOT observed in either supplied car log.
        DriveModeDecoder.fromEnergyOperationMode(type)?.let {
            emit(it, "energy.operationMode=$type source=$source")
        }
    }

    private fun handleRecycle(state: Int, source: String) {
        if (state == lastRecycle) return
        lastRecycle = state
        logger.diagnostic("REFERENCE_RECYCLE", "$source:$state")
        when (state) {
            2 -> emit(AlertEvent.REGEN_STANDARD, "energyRecycle=2")
            3 -> emit(AlertEvent.REGEN_HIGH, "energyRecycle=3")
        }
    }

    private fun handleRoadSurface(value: Int) {
        if (value == lastRoadSurface) return
        lastRoadSurface = value
        when (value) {
            1 -> emit(AlertEvent.SNOW_OFF, "roadSurface=1")
            2 -> emit(AlertEvent.SNOW_ON, "roadSurface=2")
        }
    }

    /** SubAI v13's proven three-press signal appears as six alternating 1/2 state transitions. */
    private fun handleMenuState(value: Int) {
        val now = System.currentTimeMillis()
        while (menuHistory.isNotEmpty() && now - menuHistory.first().timestamp > MENU_WINDOW_MS) menuHistory.removeFirst()
        if (menuHistory.isEmpty() || menuHistory.last().value != value) menuHistory.addLast(StateTime(value, now))
        if (menuHistory.size < 6) return
        val last6 = menuHistory.toList().takeLast(6)
        val completePressReleaseTriplet = listOf(1, 2, 1, 2, 1, 2)
        if (last6.map { it.value } != completePressReleaseTriplet) return
        // Do not count an initial release followed by only two genuine presses.
        val duration = last6.last().timestamp - last6.first().timestamp
        if (duration <= MENU_WINDOW_MS) {
            menuHistory.clear()
            logger.marker("STEERING_TRIPLE_TAP_REFERENCE", "INSTRUMENT_2IN1_MENU_STATE duration=${duration}ms")
            runCatching { onSteeringTripleTap.run() }
                .onFailure { logger.diagnostic("STEERING_TRIPLE_TAP_PLAY_FAILED", it.message) }
        }
    }

    private fun emit(event: AlertEvent, detail: String) {
        logger.diagnostic("REFERENCE_ALERT_EMIT", "${event.name}:$detail")
        gate.submit(AlertRequest(event))
    }

    private fun listenerError(source: String, code: Int, message: String?) {
        logger.diagnostic("REFERENCE_LISTENER_ERROR", "$source:$code:${message ?: ""}")
    }

    companion object {
        private const val ENERGY_OPERATION_MODE_OBSERVED = 0x2120000e // real-car BYD energy event, observed 2 -> 1
        private const val ADAS_AVH_STATE_CONFIRMED = 0x12200046
        private const val SET_DR_ENERGY_FB_CONFIRMED = 0x34100022 // 2026-10-08 real-car ZIP, values 2 and 3
        private const val ENERGY_ROAD_SURFACE = 0x24000033
        private const val ADAS_BSD_STATE_OBSERVED = 0x41800008 // 28 actual user log events, LinkLock active raw=2
        private const val MENU_WINDOW_MS = 1000L
    }
}
