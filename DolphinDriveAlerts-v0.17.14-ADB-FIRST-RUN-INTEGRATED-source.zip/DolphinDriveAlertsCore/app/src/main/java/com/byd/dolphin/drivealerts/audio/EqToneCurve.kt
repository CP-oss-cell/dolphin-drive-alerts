package com.byd.dolphin.drivealerts.audio

import kotlin.math.max
import kotlin.math.ln
import kotlin.math.roundToInt

/** Equalizer presets, not licensed OEM/Bose DSP. Pure arithmetic for deterministic tests. */
object EqToneCurve {
    // The UI and DSP must report/use the same gain, including selected impact strength.
    // Default=false is bit-for-bit compatible with prior 3-band user settings.
    fun userBandDb(s: EqSettings, steps: Int): Float {
        val dbPerStep = when (s.impactLevel.coerceIn(0, 2)) { 1 -> 0.8f; 2 -> 1.0f; else -> 0.6f }
        val multiplier = if (s.subtleBoost) 1.12f else 1f
        return (steps.coerceIn(-10, 10) * dbPerStep * multiplier).coerceIn(-10f, 10f)
    }

    fun gainDb(s: EqSettings, hz: Int): Float {
        val bass = userBandDb(s, s.bass)
        val mid = userBandDb(s, s.mid)
        val treble = userBandDb(s, s.treble)
        // Smooth logarithmic crossovers avoid abrupt 250/4000 Hz cliffs on 10-band DP.
        // 5-band fallback uses the same curve at its own center frequencies.
        val basic = when {
            hz <= 125 -> bass
            hz < 500 -> crossfade(bass, mid, hz, 125, 500)
            hz <= 2000 -> mid
            hz < 8000 -> crossfade(mid, treble, hz, 2000, 8000)
            else -> treble
        }
        val preset = when (s.soundFocus) {
            SoundFocusMode.REFERENCE -> 0f
            // A modestly larger, smoothed contour makes mode A/B audible even
            // when the car does not support Android's Virtualizer on its output.
            SoundFocusMode.SURROUND -> presetCurve(hz, 0.95f, -0.65f, 1.1f)
            SoundFocusMode.CINEMA -> presetCurve(hz, 1.65f, -0.55f, 0.5f)
        }
        return (basic + preset).coerceIn(-10.0f, 10.0f)
    }

    private fun presetCurve(hz: Int, low: Float, mid: Float, high: Float): Float = when {
        hz <= 180 -> low
        hz < 430 -> crossfade(low, mid, hz, 180, 430)
        hz <= 2600 -> mid
        hz < 5600 -> crossfade(mid, high, hz, 2600, 5600)
        else -> high
    }

    private fun crossfade(a: Float, b: Float, hz: Int, lo: Int, hi: Int): Float {
        val x = ((ln(hz.toDouble()) - ln(lo.toDouble())) /
            (ln(hi.toDouble()) - ln(lo.toDouble()))).toFloat().coerceIn(0f, 1f)
        val smooth = x * x * (3f - 2f * x)
        return a + (b - a) * smooth
    }

    // Attenuating before the boost protects headroom. No additional LoudnessEnhancer stacking.
    fun headroomDb(s: EqSettings, frequencies: IntArray): Float =
        -(frequencies.maxOfOrNull { gainDb(s, it) } ?: 0f).coerceAtLeast(0f)

    fun virtualizerStrength(s: EqSettings): Short {
        val multiplier = when {
            // With spatial expansion ON, preserve the original Reference level but
            // stop collapsing Surround/Cinema to exactly the same Virtualizer setting.
            s.centerpoint360 && s.soundFocus == SoundFocusMode.CINEMA -> 1.3f
            s.centerpoint360 && s.soundFocus == SoundFocusMode.SURROUND -> 1.15f
            s.centerpoint360 -> 1.0f
            s.soundFocus == SoundFocusMode.CINEMA -> 0.9f
            s.soundFocus == SoundFocusMode.SURROUND -> 0.7f
            else -> 0f
        }
        return (s.spatialStrength.coerceIn(0, 100) * 10f * multiplier)
            .roundToInt().coerceIn(0, 1000).toShort()
    }
}
