# Dolphin Drive Alerts v0.17.13 — 여러 채팅 이슈 통합 빌드 보고

**기준:** `DolphinDriveAlerts-v0.17.13-ALL-ISSUES-INTEGRATED-source.zip` / v0.17.12(EQ gentle) 계승 / applicationId `com.byd.dolphin.drivealerts`, versionCode 39.

## 원칙
- 사용자 2026-10-10 요청: DA-008 ICC, DA-027 AutoSplit, DA-007 BSD, DA-003/005 NORMAL, DA-015 EQ, 그리고 최신 master issue에서 미완료 항목을 **기존 v0.17.12 소스 하나에 합쳐 빌드 준비**.
- 연구자료, 마스터 이슈 v52, 별도 `DA-008_ICC_ADAS_NEXT_BUILD_20261010.md`, `DA-027_AUTOSPLIT_NEXT_INTEGRATED_BUILD_20261010.md`, `DA015_EQ_SOUNDFIELD_RESEARCH_20261010_KO.md`, `NEXT_RELEASE_BSD_NORMAL_SPEC_20261010_KO.md`, 공통 정책 문서 대조. GitHub main 최근 commit `7758333ed7a7d0fda55ec51276848b26c2c4954a`, GitHub connector push=false. 파일 업로드/Actions 실행은 사용자 수동.
- 차량 ECU/보행자 AVAS/순정 클러스터에 쓰기 명령 또는 알 수 없는 ADAS 경고값으로 음성 강제 발화 없음. **코드 작성/정적 검사/전체 Android 컴파일/실차 청감** 구분.

## 코드로 통합 반영한 부분

| ID | 코드 상태 | 변경·유지 내용 | 미완료 판단 |
|---|---|---|---|
| DA-007 | **CODE_CHANGED + LOCAL_KOTLIN_PASS** | 기본 ON인 `BSD 감지 + 어느 한쪽 깜빡이 → 일반 후측방 음성` 보존. 선택 `BSD 위험 후보 감지 즉시 일반 경고` 기본 OFF 독립 토글 저장. 두 모드 동시 사용 시 한 위험 진입에서 **음성 1회**, BSD 해제 후 재진입 시 재허용. 좌/우 음성 2개는 보존·자동 연결 금지. | 0x41800008 raw2 실제 위험 활성 의미/글로벌 2602 장치 신호 재확인 필요. 좌/우 BSD 원시 상태 미확정 |
| DA-003/005 | **CODE_DIAGNOSTIC** | `ENERGY_OPERATION_MODE`의 이전값/현재값/콜백 출처, 사용자가 확인한 ECO→NORMAL→SPORT→ECO 순서 기록. 기존 ECO·SPORT·회생제동과 0=NORMAL 후보 음성 경로 보존. | 타 앱의 실제 NORMAL 조건과 자동차 0/1/2 값 실증 미완성; **NORMAL 발화 복구 완료 아님** |
| DA-008 | **CODE_DIAGNOSTIC** | ICC 확인 상태와 DiPilot 앞차출발·차선·하차·BSD 콜백 원시값 연결 로그. 기존 음성 자산과 콜백 등록 유지, 무근거 위험값 발화 없음. | ICC ON에서 LDW/앞차출발 활성 이벤트 검증 및 앱 음성 아직 미구현; ICC OFF/좌우 분류 연구 계속 |
| DA-027 | **CODE_CHANGED + LOCAL_KOTLIN_PASS** | ADB 미연결 원인 안내 개선, 승인과 앱 권한 분리. 기존 2앱 분할/비율 bounds 확인/카메라 복원/프로필 기능 보존, 태스크별 분할 모드 확인 데이터 추가. | 실제 2분할·비율 재적용 실차 미확인; 3/4분할 및 멀티팝업은 읽기전용 탐색만 |
| DA-015 | **PRESERVED_FROM_V01712** | 이전 EQ 기본 음색, 소폭 +12% 선택 강화(기본 OFF), Surround/Cinema 소폭 개선 및 헤드룸 유지 | 순정 DSP/센터포인트 360 효과 실증 불가; 실제 음악앱·세션 적용 청감 필요 |
| DA-016 | **PRESERVED** | 시동 비동기 초기화, BYD 리스너 복구 및 무화면 미디어 MediaBrowser 경로 유지 | 시동 지연·특정 미디어앱 무화면 재생 실제 검증 필요 |
| DA-009/010 | **PRESERVED_DIAGNOSTIC** | 내비 5종 지정·운전석 오디오 경로 비교 로그·DPI 120 순정 UI 잘림 보호 유지 | 타 앱 UID 운전석 전용 라우팅 구현 없음. 순정 런처 per-app DPI 속임 미구현 |
| DA-012 | **PRESERVED_DIAGNOSTIC** | 외부 AVAS 순정 설정 전후 읽기 전용 시험 마커 | 사용자 WAV 외부 재생 미구현, 순정 보행자 경고 미변경 |
| DA-025 | **EXCLUDED_SEPARATE_APP** | 5인치 계기판 프로젝트 `DolphinCluster_V1_1...`은 독립 앱이므로 Dolphin Drive Alerts 패키지에 APK 혼합 안 함 | 별도 계기판 앱·권한/안전 범위 유지 |

## 테스트 근거
- v0.17.8 기존 소스 회귀 57/57, v0.17.9 48/48 통과.
- v0.17.10 bridge 반환문 계약 검사 통과.
- 실제 BSD `ReferenceVehicleEventBridge.kt` Kotlin 스텁 컴파일 및 시뮬레이션, 2모드 조합 pass.
- v0.17.12 EQ Kotlin 동작 검사 pass.
- 이번 통합 정적 25/25, 순수 Kotlin BSD arbitration / split task readback / ECO-NORMAL-SPORT decoder pass.
- 이전 버전 전체 OEM/미디어 Kotlin 컴파일 묶음은 시간 초과로 중단된 실행 기록이 있으며 **모두 통과했다고 주장하지 않음**. GitHub :app:compileDebugKotlin/:app:assembleDebug가 최종 빌드 관문.
- GitHub 전체 APK 빌드/서명/설치/실차 안전 경고 청감 **아직 미실행**.

## 설치 및 시험
1. 원본 APK/설정/프로필/실차 로그 백업 및 기존 설치 서명 확인. 기존 versionCode 38 → 39.
2. GitHub에 ZIP/YML 업로드 후 Actions APK 빌드 성공/인증서 fingerprint 확인.
3. 운행 전 정차 상태에서 실행, BSD 두 토글 ON/OFF 저장 및 즉시 음성 1회 로직 확인. 실차 BSD는 실제 교통위험을 만드는 방식으로 인위적 시험 금지.
4. NORMAL은 ECO→NORMAL→SPORT→ECO 조작 시 수집 로그의 raw와 UI를 시간 대조. 잘못된 NORMAL 자동 발화가 있으면 로그 제출.
5. ICC 차선·앞차출발은 순정 경고를 보존, **우리 앱이 새 음성을 낸다고 가정하지 말 것**.
6. 분할은 먼저 ADB 상태 진단 → 2개 앱·비율 → dumpsys/bounds 검증. AutoSplit 기존 정상 앱 설정을 덮어쓰지 않음.
7. EQ는 음원과 볼륨 동일 조건으로 기본/강화 및 모드 3개를 비교. 왜곡 시 미세 강화 OFF로 원복.
8. 롤백: 앱 내 BSD 즉시 알림 OFF, 회전/화면 정책 원복; 앱 제거·이전 서명 APK 재설치 전 데이터와 설정 백업.

**최종 판단:** `INTEGRATED_SOURCE_READY / LOCAL_TEST_PARTIAL_PASS / ANDROID_CI_REQUIRED / REALCAR_REVERIFY_REQUIRED`. 어떠한 미검증 기능도 VERIFIED로 승격시키지 않음.
