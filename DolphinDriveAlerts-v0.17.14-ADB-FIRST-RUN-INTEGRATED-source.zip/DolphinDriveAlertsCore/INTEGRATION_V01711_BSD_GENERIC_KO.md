# v0.17.11 — BSD 감지 + 어느 쪽이든 깜빡이 = 일반 후측방 경고

## 요구사항 (2026-10-10 사용자 실차 요구)
1. **좌측/우측 장애물 감지 방향은 미확정**: 깜빡이 방향을 물체 방향으로 착각하지 않음.
2. ADAS_BSD_STATE(0x41800008) LinkLock 계열 값 2를 BSD 활성 후보로 사용하는 기존 진단을 유지함. 실제 물체 검출 vs 기능 상태가 완전히 분리됐다는 의미는 아님.
3. BSD 활성 상황에서 왼쪽 또는 오른쪽 깜빡이 ON을 감지하면 **`BSD_WARNING` + `Side.UNKNOWN`**을 1회 재생함.
4. 그 BSD 활성 상태가 유지되는 동안 반대 방향으로 깜빡이를 바꿔도 반복하지 않음. BSD 비활성→다음 활성에서 재무장.
5. 왼쪽·오른쪽·일반 음성 3개 × 남성/여성 총 6개 원본 매니페스트 유지. 미래 좌우 감지 신호가 확정될 때만 `Side.LEFT/RIGHT` 연결.
6. 진입 당시 깜빡이가 꺼져 있어도 나중에 켜면 발화. 전방위 시스템 설정 ON/OFF로 오인한 것인지는 실차 로그 확인 필요.
7. 양쪽 깜빡이가 동시에 1(비상등)인 경우와 읽기 실패/미확정 값인 경우는 임의 경고하지 않음. 좌우 getter 중 하나가 미제공이어도 반대쪽 1이 명확하면 진단 후보 발화 가능.

## 변경 파일 및 동작
- `vehicle/ReferenceVehicleEventBridge.kt`: BSD 활성당 일반 알림 1회; BSD 좌우 신호 연구는 별개; raw 및 gate 로그 보존.
- `vehicle/TurnSignalReadback.kt`: *깜빡이가 하나라도 ON인지*를 독립적으로 판정, 양쪽 ON은 안전하게 제외. 기존 side 진단 필드는 보존하지만 이번 BSD 음성에는 사용하지 않음.
- `service/DrivingAlertService.kt`: BSD 판단 간격을 기존 450ms에서 150ms로 조정. 활성 아닌 경우 추가 조회 없음. 오토홀드 확인 450ms 유지.
- `model/AlertModels.kt`/`VOICE_PACK_MANIFEST.csv`: 남/여 일반·왼쪽·오른쪽 음성 원형 유지.
- `tools/verify_v01711_bsd_any_indicator.py`: 실제 BSD 서비스 브리지·조명 조회기 Kotlin 코드를 컴파일한 후 좌/우·비상등·무지시등·중복제어·재무장·3종 음성 의미 재현.
- 이전 버전 회귀 테스트에서는 좌우 알림 가정을 최신 사용자 사양대로 교정. 앱 패키지명, 기존 정상 신호·EQ·미디어·DPI 소스 보존.

## 실차 검증/미해결
- 이 빌드의 **실제 Android APK 빌드·차량 시험은 아직 완료되지 않음**. Kotlin 스텁 컴파일 성공은 OEM 서비스 실행 성공의 증거가 아님.
- 중요: BYDAutoLightDevice getter는 현재 실차에서 호출 성공이 확정되지 않음. 기록되는 `BSD_GATE_SUPPRESSED` 이유와 `light.leftTurn/rightTurn` 원시값을 확인해야 함. 앱이 경고하지 않으면 호출 경로/메서드 및 1=ON 의미를 확정 후 보완 필요.
- `0x41800008 raw2`는 LinkLock 경고 경로 기준 활성 후보이며 펌웨어의 BSD 설정/이벤트 이름 충돌이 있음. 실제 장애물 동시 조건 검증 필요.
- 좌우 BSD 센서 신호 0x4180002c/2e 등은 연구중; 이 빌드에서 LEFT/RIGHT 자동 음성 활성화하지 않음.
- 양쪽 비상등을 켰을 때 정책은 일단 제외, 추후 사용자 요구에 따라 변경 가능.
- **주행 안전 경고는 순정 안전 기능과 별개이며 이를 대체하지 않음.**

## 버전 및 배포
- versionName: `0.17.11-bsd-any-blinker-generic`; versionCode: `37`; applicationId `com.byd.dolphin.drivealerts` 유지.
- GitHub Actions YAML은 별도 업로드, 기존 디버그 서명키를 같은 GitHub Secret으로 복원해야 앱 업데이트 설치 가능.
- 자세한 로컬 검사: `STATIC_GATES_V01711.log`.
