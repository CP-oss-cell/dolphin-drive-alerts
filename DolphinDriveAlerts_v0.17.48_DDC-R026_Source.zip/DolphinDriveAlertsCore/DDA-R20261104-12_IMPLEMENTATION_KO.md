# DDA-R20261104-12 — v0.17.47 수정 후보

2026-11-04. **검증 상태: 소스 정적 회귀 검사 통과, Android APK 실제 컴파일 및 실차 개선 검증은 미수행.**

## 사용자 최신 실차 기준

- `DrivingAlertService` 시동 자동실행 정상: 코드 변경 금지/미변경.
- 에코·노멀·스포츠 중 NORMAL 음성은 실차에서 완결: `vehicle/*` 음성/상태 해석 코드 변경 금지/미변경.
- 지정 앱 자동실행/미디어 자동재생 실패, 2분할 실패: 2026-11-04 19:26 로그로 재현.

## 변경 사항

1. `BootReceiver`: 지정 앱 시퀀스에 한해 단조 경과시간으로 중복 요청을 제한, 버전 마이그레이션을 처리하고 `ACC_ON/IGN_ON`만 트리거로 유지. 요청 직전 실패 시 가드를 되돌리며, 자동실행 별도 설정·선택 항목·트리거·상태를 기록. **BOOT_COMPLETED만으로 미디어 앱을 재생하지 않음**(주차 상태 오탐 방지).
2. `AutoLaunchSequenceService`: 서비스 실행 요청이 Android에서 거부되면 Boolean 결과를 호출부로 전달. 수동/시동 실행 기록 및 전달 ACK와 실제 수행 성공의 차이를 구분.
3. `FeatureProfiles`: 사용자 정의 실행 항목 중 하나가 손상됐을 때 전체 목록을 버리지 않고 정상 항목만 파싱, 손상 행/설정을 로깅. 원본 설정 문자열을 자동 삭제하지 않음.
4. `MediaPlaybackObserver`: Android 알림 리스너 접근 상태를 먼저 조회. 승인되지 않았다면 1회 진단만 남기고 중복 `getActiveSessions()` 호출 중단. 미디어 앱 시작 요청과 `PLAYING` 검증은 계속 독립적으로 판단.
5. `AutoLaunchSettingsActivity`: 미디어 권한 상태를 간단한 한국어로 표시. 기존 권한 승인 버튼 유지.
6. `AutoSplitBehaviorEngine`: 실제 ADB 쉘 성공 및 exit=0 확인, 시작 후 스택을 읽고 3번(primary)이 없으면 앱 자체 Ghost Activity를 **최대 한 번** 시험적으로 열어 모드3 스택을 만들고 기존 첫 앱 Task를 연결 시도. 카메라 화면에서 각 쓰기 단계 중단, 실제 mode3/mode4의 서로 다른 Task 확인이 없으면 `SPLIT_NOT_CONFIRMED` 유지.
7. GitHub Actions: Android 34 플랫폼, build tools 34.0.0 설치·존재 검증 및 v0.17.47 소스 회귀 검사 추가. 프로젝트 v0.17.47 / versionCode=73.

## 명확한 한계

- 임의 ADB 명령은 실제 OEM Android10 창 관리자 권한·resizeability·Task 동작에 따라 거부될 수 있다. Ghost 보완 경로도 **실차 미검증이며 완전한 AutoSplit 복제가 아니다**.
- `ACC_ON/IGN_ON`이 차량에서 방송되지 않으면 이번 수정만으로 지정 앱 자동실행이 발생하지 않는다. `BOOT_COMPLETED`를 곧바로 ACC_ON이라고 바꾸지 않았다.
- 알림 리스너 권한은 사용자의 명시적 승인 혹은 승인된 권한부여 환경이 필요하다. 권한이 있어도 선택 미디어 플레이어의 브라우저 바인드/재생 큐가 없으면 자동재생이 실패할 수 있다.
- 기존 앱에 덮어쓰기 설치하려면 GitHub Secrets에 기존 앱과 **동일한 인증서의 서명키**가 있어야 한다. 일회성 디버그키 빌드는 설치형이더라도 업데이트 설치를 보장하지 않는다.

## 검사 게이트

- `python3 tools/verify_v01747_dashboard_deep.py`: 기존 27개 기능 보존/코드 상태 게이트 + 순수 Kotlin fixture.
- `python3 tools/verify_v01747_r12_patch.py`: R12 신규 구조 정적 검사.
- `python3 tools/verify_v01746_core_kotlin.py`: 기존 독립 Kotlin 3 fixture (CI 실행용).
- GitHub Actions `:app:compileDebugKotlin`, `:app:assembleDebug`, `apksigner`, APK 버전 확인이 최종 관문.
- 실차 동작은 기존 검증된 기능과 별도로 후속 로그가 있어야만 성공 판정한다. 무검증 기능에 VERIFIED를 부여하지 않는다.
