# DDC-R025 — v0.17.47 기준 최소 안전 통합

- 기준: 사용자가 업로드한 `DDA_v01747_Reissued_20261104.zip`의 소스. 이전 v0.17.49를 기준으로 하지 않음.
- 변경 파일: `app/src/main/java/com/byd/dolphin/drivealerts/dpi/TemporaryAppDpiController.kt` 1개.
- 변경: 접근성 포그라운드 감지에 의한 **자동** DPI 변경 시 OEM/시스템 앱을 제외. `ThirdPartyDpiRules.isSystem` 판정을 재사용. 앱별 DPI가 전역 `wm density`라는 사실은 변하지 않음.
- 명시적으로 사용자가 누르는 앱 실행+DPI 변경 및 전역 DPI 복원 버튼의 기존 동작은 유지. 따라서 OEM 카메라 공백 문제를 해결한 것이 아님.
- 미해결: OEM 360 카메라·런처 고정 dp/리소스 분기 수정, 미디어 자동재생, 분할 화면.
- 안전: 차량 신호/주차선/영상 Surface 수정 없음. 새로운 권한 추가 없음.
- 검증: 소스 ZIP 무결성, 변경 영역의 정적 단언, 워크플로 YAML 구조 확인. Android 컴파일 및 실차 작동은 이 패키징만으로 입증되지 않음.
