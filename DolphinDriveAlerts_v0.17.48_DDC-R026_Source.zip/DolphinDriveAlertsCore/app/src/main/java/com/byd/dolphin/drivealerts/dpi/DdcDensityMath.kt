package com.byd.dolphin.drivealerts.dpi

/** Fixed-dp hypothesis calculator only. Not a measurement or repair. */
object DdcDensityMath {
    fun ratio(physicalDpi: Int, currentDpi: Int): String {
        if (physicalDpi <= 0 || currentDpi <= 0) return "UNKNOWN"
        val percent = currentDpi * 100.0 / physicalDpi
        return String.format(java.util.Locale.US, "%.1f%%", percent)
    }
}
