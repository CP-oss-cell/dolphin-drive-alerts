package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** DDC-R024 integration candidate. Strictly read-only: never issues wm density/size writes. */
object DdcReadOnlyDiagnostic {
    private val sizePattern = Regex("""(?i)(physical|override)\s+size:\s*(\d+)x(\d+)""")
    private val framePattern = Regex("""(?i)(?:mFrame=|frame=)\[(\d+),(\d+)\]\[(\d+),(\d+)\]""")
    private val watched = listOf("com.android.launcher3", "com.byd.card", "com.byd.avc", "bydautocamera", "byd.camera", "airconditioning")

    private fun read(app: Context, command: String): Pair<String?, String> {
        val response = AuthorizedAdbRuntime.read(app, command, timeoutMs = 7_000L)
        val result = response.result
        return if (result.success && response.state == AuthorizedAdbRuntime.State.READY) result.output to "OK"
            else null to "${response.state} · ${result.exitCode}"
    }

    /** Returns a compact privacy-reduced summary, never the full raw dumpsys body. */
    fun collect(context: Context): String {
        val app = context.applicationContext
        val density = DisplaySettingsController.readDensity(app)
        val (sizeRaw, sizeStatus) = read(app, "wm size")
        val sizeLines = sizeRaw?.lineSequence()?.mapNotNull { line ->
            sizePattern.find(line)?.let { "${it.groupValues[1]} ${it.groupValues[2]}x${it.groupValues[3]}" }
        }?.toList().orEmpty()
        val (windowRaw, windowStatus) = read(app, "dumpsys window windows")
        val lines = windowRaw?.lineSequence()?.take(8_000)?.toList().orEmpty()
        val frames = mutableListOf<String>()
        for (index in lines.indices) {
            val window = lines[index]
            if (!window.contains("Window{")) continue
            val owner = watched.firstOrNull { window.contains(it, ignoreCase = true) } ?: continue
            // A window frame is not the same thing as an internal view or video surface.
            // Never attribute the following window's frame to this window.
            val bound = minOf(lines.size, index + 36)
            val end = ((index + 1) until bound).firstOrNull { lines[it].contains("Window{") } ?: bound
            val frame = lines.subList(index + 1, end).firstNotNullOfOrNull {
                framePattern.find(it)?.groupValues?.drop(1)?.joinToString(",")
            }
            if (frames.size < 8) frames += "$owner: ${frame ?: "프레임 미확인"}"
        }
        val (activityRaw, activityStatus) = read(app, "dumpsys activity activities")
        val relevantModes = activityRaw?.lineSequence()?.filter { line ->
            watched.any { pkg -> line.contains(pkg, ignoreCase = true) } &&
                (line.contains("mode", ignoreCase = true) || line.contains("Task{", ignoreCase = true))
        }?.take(5)?.map { line ->
            val pkg = watched.firstOrNull { line.contains(it, ignoreCase = true) } ?: "OEM"
            val mode = Regex("""(?i)(?:windowingMode|mWindowingMode)\s*[=:]\s*([A-Za-z0-9_-]+)""")
                .find(line)?.groupValues?.get(1) ?: "UNKNOWN"
            "$pkg: $mode"
        }?.toList().orEmpty()
        val base = density?.physical
        val current = density?.override ?: density?.physical
        val estimate = if (base != null && current != null && base > 0 && sizeLines.isNotEmpty()) {
            "고정dp 가설상 화면 점유비율: ${DdcDensityMath.ratio(base,current)} (실제 빈공간 면적을 측정한 결과 아님)"
        } else "고정dp 가설 수치 판정: UNKNOWN (DPI/화면 크기 부족)"
        val summary = buildString {
            appendLine("순정 DPI 화면 진단 — 읽기 전용")
            appendLine("DPI physical=${base ?: "UNKNOWN"}, override=${density?.override ?: "없음/불명"}")
            appendLine("wm size($sizeStatus): ${sizeLines.joinToString().ifBlank { "UNKNOWN" }}")
            appendLine(estimate)
            appendLine("OEM 창 프레임($windowStatus): ${frames.joinToString("; ").ifBlank { "UNKNOWN" }}")
            appendLine("OEM 작업 모드($activityStatus): ${relevantModes.joinToString("; ").ifBlank { "UNKNOWN" }}")
            appendLine("판정: WINDOW_OR_VIEW_OR_SURFACE_UNKNOWN · 실제 내부 View/360 영상 크기 원인 확정 불가")
            append("변경 명령 0건 · 360 영상/주차선 변경 없음")
        }
        // These values are reduced diagnostic metadata; never retain full dumpsys content.
        CoreLog.i("DPI", "DDC_READ_ONLY ${summary.replace('\n',' ').take(1300)}")
        return summary
    }
}
