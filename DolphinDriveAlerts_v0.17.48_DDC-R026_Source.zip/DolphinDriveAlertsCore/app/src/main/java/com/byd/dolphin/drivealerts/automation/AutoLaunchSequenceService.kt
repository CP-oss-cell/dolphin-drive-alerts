package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/** Ignition-scheduled, cancellable ordered launches. Manual and ignition triggers share one engine. */
class AutoLaunchSequenceService : Service() {
    @Volatile private var generation=0
    override fun onBind(intent:Intent?): IBinder?=null
    override fun onCreate(){
        super.onCreate()
        val m=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26)m.createNotificationChannel(NotificationChannel("app_sequence","차량 앱 자동 실행",NotificationManager.IMPORTANCE_LOW))
        startForeground(763,Notification.Builder(this,"app_sequence")
            .setContentTitle("시동 앱 실행 시퀀스").setSmallIcon(android.R.drawable.ic_media_play).build())
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_CANCEL){generation++;stopSelf();return START_NOT_STICKY}
        if(intent?.action!=ACTION_RUN) return START_NOT_STICKY
        val manual=intent.getBooleanExtra("manual",false)
        val enabled=FeatureProfiles.sequenceEnabled(this)
        val stepList=FeatureProfiles.steps(this).filter{it.enabled}
        CoreLog.i("AUTO_SEQUENCE", "REQUEST_RECEIVED source=${if(manual) "MANUAL" else "IGNITION"} enabled=$enabled stepCount=${stepList.size}")
        if(!manual) IgnitionSequenceAlarmReceiver.acknowledge(this) // delivery ACK != work success
        if(!manual && !enabled) {CoreLog.w("AUTO_SEQUENCE","REQUEST_INELIGIBLE disabled");stopSelf();return START_NOT_STICKY}
        if(stepList.isEmpty()){CoreLog.w("AUTO_SEQUENCE","REQUEST_INELIGIBLE noEnabledSteps");stopSelf();return START_NOT_STICKY}
        val seq=++generation
        Thread({runSteps(stepList,seq,manual)},"dolphin-autostart-sequence").start()
        return START_NOT_STICKY
    }
    private fun runSteps(steps:List<LaunchStep>,seq:Int,manual:Boolean) {
        val power=getSystemService(PowerManager::class.java)
        val lock=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"DriveAlerts:LaunchSequence")
        try {
            // Limit wake time and ignore app sequences longer than ten minutes.
            lock.acquire(600_000L)
            val launchStart=System.currentTimeMillis()
            // ADB is NOT a prerequisite for controlling an already running media session.
            // A global 30-second wait here caused avoidable ignition media delay.
            CoreLog.i("AUTO_SEQUENCE", "SEQUENCE_START source=${if(manual) "MANUAL" else "IGNITION"} steps=${steps.size} backgroundMedia=${steps.count { it.isMedia && it.restoreBackground }}")
            for(step in steps) {
                if(seq!=generation || System.currentTimeMillis()-launchStart>600_000L) break
                if(!pause(step.delaySeconds,seq))break
                // Door/sentry wake must not restart playback after a documented ACC OFF.
                if(!manual && getSharedPreferences("ignition_sequence_guard",MODE_PRIVATE)
                        .getBoolean("armed",true)) {
                    CoreLog.w("AUTO_SEQUENCE","ABORT_IGNITION_OFF_BEFORE_STEP pkg=${step.packageName}")
                    break
                }
                // For background-only media, never open the player Activity even on cold start.
                // This route requires the target app's MediaSession or exported MediaBrowserService.
                if (step.isMedia && step.restoreBackground) {
                    var playing=MediaPlaybackObserver.playWithoutUi(this, step.packageName)
                    CoreLog.i("AUTO_SEQUENCE", "MEDIA_EXISTING_OR_BROWSER pkg=${step.packageName} playing=$playing")
                    if (!playing) {
                        // v0.17.17 silently skipped cold players without a BrowserService.
                        // AutoStart reference opens the configured player once, then resumes its session.
                        // This is user-configured auto launch only; never launch unrelated apps.
                        val component=AppSelection.safeComponent(this,step.packageName)
                        if (component==null) { CoreLog.w("AUTO_SEQUENCE","MEDIA_COLD_NO_COMPONENT pkg=${step.packageName}");continue }
                        val adb=AuthorizedAdbRuntime.awaitReady(this,20_000L) { seq!=generation }
                        if (adb.state==AuthorizedAdbRuntime.State.READY) {
                            val result=AuthorizedAdbRuntime.writeOnce(this,"am start --user 0 -n '$component'",timeoutMs=9_000L).result
                            CoreLog.i("AUTO_SEQUENCE","MEDIA_COLD_ADB_LAUNCH pkg=${step.packageName} success=${result.success} output=${result.output.take(400)}")
                        } else {
                            CoreLog.w("AUTO_SEQUENCE","MEDIA_COLD_ADB_NOT_READY pkg=${step.packageName} state=${adb.state};trying Android launcher")
                            runCatching {
                                val intent=packageManager.getLaunchIntentForPackage(step.packageName)
                                    ?: error("launch intent unavailable")
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(intent)
                            }.onFailure { CoreLog.w("AUTO_SEQUENCE","MEDIA_COLD_ACTIVITY_BLOCKED pkg=${step.packageName} ${it.message}") }
                        }
                        if (!pause(step.playDelaySeconds.coerceAtLeast(2),seq)) break
                        repeat(3) { retry ->
                            if (!playing && seq==generation) {
                                playing=MediaPlaybackObserver.play(this,step.packageName)
                                CoreLog.i("AUTO_SEQUENCE","MEDIA_COLD_RETRY pkg=${step.packageName} try=$retry playing=$playing")
                                if (!playing) Thread.sleep(750L)
                            }
                        }
                    }
                    if (!playing && seq==generation) {
                        // Some OEM media apps accept Android media-key PLAY but expose no usable
                        // notification MediaSession until after their Activity is foreground.
                        // Only send this targeted fallback if THE USER-SELECTED media app is
                        // definitely foreground; never send blind play while parked.
                        playing=playFocusedMediaKey(step.packageName,manual)
                    }
                    if (playing) {
                        val adb=AuthorizedAdbRuntime.health(this)
                        if (adb.state==AuthorizedAdbRuntime.State.READY) {
                            val home=AuthorizedAdbRuntime.writeOnce(this,"input keyevent 3").result
                            CoreLog.i("AUTO_SEQUENCE","MEDIA_COLD_HOME pkg=${step.packageName} success=${home.success}")
                        } else CoreLog.w("AUTO_SEQUENCE","MEDIA_PLAYING_HOME_UNAVAILABLE pkg=${step.packageName}")
                    } else CoreLog.w("AUTO_SEQUENCE","MEDIA_COLD_RETRY_EXHAUSTED pkg=${step.packageName};notVerified=true")
                    continue
                }
                val authorization = AuthorizedAdbRuntime.awaitReady(this,30_000L) { seq != generation }
                if (authorization.state != AuthorizedAdbRuntime.State.READY) {
                    CoreLog.w("AUTO_SEQUENCE", "STEP_BLOCKED_BY_ADB pkg=${step.packageName} state=${authorization.state}")
                    continue
                }
                if(step.packageName.startsWith("split:")) {
                    // Never seize the split stack while the OEM 360/reverse camera is foreground.
                    val foreground=AutoSplitBehaviorEngine.screenToken(this).orEmpty()
                    if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground)) {
                        CoreLog.w("AUTO_SEQUENCE", "SPLIT_SKIPPED_CAMERA_FOREGROUND")
                        continue
                    }
                    val profileId=step.packageName.removePrefix("split:")
                    val profile=FeatureProfiles.splits(this).firstOrNull{it.id==profileId}
                    if(profile==null){CoreLog.w("AUTO_SEQUENCE","Missing split profile: $profileId");continue}
                    val result=AutoSplitBehaviorEngine.launch(this,profile)
                    CoreLog.i("AUTO_SEQUENCE","split=${profile.title} success=${result.success} result=${result.message}")
                    if(result.success)SplitRecoveryService.start(this,profile.id)
                    continue
                }
                // If a media session is already registered, play WITHOUT ever opening its UI.
                // This implements background-resume for players that publish a usable session.
                if (step.isMedia && MediaPlaybackObserver.playExisting(this, step.packageName)) {
                    CoreLog.i("AUTO_SEQUENCE", "MEDIA_BACKGROUND_REUSED pkg=${step.packageName}; launch skipped")
                    continue
                }
                val component=AppSelection.safeComponent(this,step.packageName)
                if(component==null){CoreLog.w("AUTO_SEQUENCE","No installed launcher: ${step.packageName}");continue}
                // Never override a running OEM reverse/360 camera view.
                val foreground=AutoSplitBehaviorEngine.screenToken(this).orEmpty()
                if(Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground)) {
                    CoreLog.w("AUTO_SEQUENCE","OEM camera foreground; skipped ${step.packageName}")
                    continue
                }
                val launched=AuthorizedAdbRuntime.writeOnce(this,"am start -n $component").result
                CoreLog.i("AUTO_SEQUENCE","pkg=${step.packageName} delay=${step.delaySeconds} result=${launched.success} msg=${launched.message}")
                if(!launched.success)continue
                var mediaPlaying = !step.isMedia
                if(step.isMedia){
                    if(!pause(step.playDelaySeconds,seq))break
                    mediaPlaying=MediaPlaybackObserver.play(this,step.packageName)
                    if(!mediaPlaying) mediaPlaying=playFocusedMediaKey(step.packageName,manual)
                    CoreLog.i("AUTO_SEQUENCE","media=${step.packageName} playDelay=${step.playDelaySeconds} statePlaying=$mediaPlaying")
                }
                if(step.restoreBackground && !mediaPlaying) CoreLog.w("AUTO_SEQUENCE", "HOME_SUPPRESSED: media session not PLAYING/BUFFERING; require readback")
                if(step.restoreBackground && mediaPlaying){
                    // Do not kill the media process: restore launcher task after requesting playback.
                    val home=AuthorizedAdbRuntime.writeOnce(this,"input keyevent 3").result
                    CoreLog.i("AUTO_SEQUENCE","background=${step.packageName} home=${home.success} msg=${home.message}")
                }
            }
        }catch(t:Throwable){CoreLog.w("AUTO_SEQUENCE","sequence failure: ${t.message}")}
        finally {if(lock.isHeld)lock.release();if(seq==generation)stopSelf()}
    }
    /** Last resort for an explicit, user-selected player only. Never use a global
     * media key when a different app is foreground, the ignition is OFF, or the
     * ADB state is unknown. Do not claim playback until a session readback confirms it.
     */
    private fun playFocusedMediaKey(pkg:String,manual:Boolean):Boolean {
        if(!manual && getSharedPreferences("ignition_sequence_guard",MODE_PRIVATE)
                .getBoolean("armed",true)) return false
        val top=AutoSplitBehaviorEngine.screenToken(this).orEmpty()
        if(!top.contains("$pkg/")) {
            CoreLog.w("AUTO_SEQUENCE","MEDIA_KEY_SKIPPED_OTHER_FOREGROUND pkg=$pkg top=${top.take(150)}")
            return false
        }
        if(AuthorizedAdbRuntime.health(this).state!=AuthorizedAdbRuntime.State.READY)return false
        val sent=AuthorizedAdbRuntime.writeOnce(this,"input keyevent 126",timeoutMs=5_000L).result
        if(!sent.success)return false
        Thread.sleep(1_100L)
        val playing=MediaPlaybackObserver.isPlaybackActive(this,pkg)
        CoreLog.i("AUTO_SEQUENCE","MEDIA_KEY_FOCUSED_ONLY pkg=$pkg playReadback=$playing")
        return playing
    }

    private fun pause(seconds:Int,seq:Int):Boolean {
        repeat(seconds.coerceIn(0,600)) {if(generation!=seq)return false;try{Thread.sleep(1000)}catch(_ : InterruptedException){return false}}
        return generation==seq
    }
    override fun onDestroy(){generation++;super.onDestroy()}
    companion object {
        const val ACTION_RUN="com.byd.dolphin.drivealerts.AUTO_SEQUENCE_RUN"
        const val ACTION_CANCEL="com.byd.dolphin.drivealerts.AUTO_SEQUENCE_CANCEL"
        fun start(context:Context, manual:Boolean=false):Boolean {
            return try {
                context.startForegroundService(Intent(context,AutoLaunchSequenceService::class.java)
                    .setAction(ACTION_RUN).putExtra("manual",manual))
                CoreLog.i("AUTO_SEQUENCE", "START_REQUEST_ACCEPTED source=${if(manual) "MANUAL" else "IGNITION"};deliveryUnverified=true")
                true
            } catch(t:Throwable) {
                CoreLog.w("AUTO_SEQUENCE","START_REQUEST_REJECTED ${t.javaClass.simpleName}: ${t.message}")
                false
            }
        }
    }
}
