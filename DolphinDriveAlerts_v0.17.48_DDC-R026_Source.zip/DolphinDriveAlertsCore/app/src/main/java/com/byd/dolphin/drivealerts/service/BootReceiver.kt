package com.byd.dolphin.drivealerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.automation.AutoLaunchSequenceService
import com.byd.dolphin.drivealerts.automation.IgnitionSequenceAlarmReceiver
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.automation.IgnitionOffAppStopper
import com.byd.dolphin.drivealerts.automation.IgnitionOffStopService
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.log.CaptureContinuity

/**
 * Starts the always-on foreground monitor after Android/BYD boot and vehicle wake signals.
 * OverDrive v48.18 showed BYD ACC/IGN broadcasts in addition to Quick Boot, so v0.12 listens
 * to those read-only lifecycle hints as well. ACC_OFF / power-disconnect are intentionally
 * observation-only and never start a fresh service.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "<null>"
        val enabled = AlertPreferences.isEnabled(context)
        val autoStart = AlertPreferences.autoStartEnabled(context)
        CoreLog.i("BOOT", "BOOT_RX_TIME action=$action elapsedRealtimeMs=${android.os.SystemClock.elapsedRealtime()} enabled=$enabled autoStart=$autoStart")

        val recording = UnifiedLogCapture.state(context).takeIf {
            it.status == UnifiedLogCapture.RECORDING && it.id.isNotBlank()
        }
        if (action == Intent.ACTION_POWER_DISCONNECTED) {
            // Android USB/charging disconnect does not prove BYD ACC_OFF. It must
            // neither cancel ignition music nor start a new driving service.
            CoreLog.i("BOOT", "ANDROID_POWER_DISCONNECTED observation-only; ignition state unchanged")
            return
        }
        if (action in STOP_SIDE_ACTIONS) {
            if (recording != null) runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            // Re-arm ignition sequence only at a documented off edge.
            context.getSharedPreferences("ignition_sequence_guard", Context.MODE_PRIVATE)
                .edit().putBoolean("armed",true).apply()
            IgnitionSequenceAlarmReceiver.cancel(context)
            context.stopService(Intent(context,AutoLaunchSequenceService::class.java))
            CoreLog.i("BOOT", "vehicle/power stop-side signal observed; auto sequence cancelled: $action")
            // Only an explicit BYD ACC_OFF can authorize force-stopping selected packages.
            if (action == "com.byd.action.ACC_OFF" && IgnitionOffAppStopper.enabled(context)) {
                IgnitionOffStopService.start(context.applicationContext)
            }
            return
        }
        // A user-controlled recording must be resumed even if background auto-launch
        // of other apps was disabled. Android may still block a background FGS start.
        // Only accepted start-side hints can resume; never start on ACC_OFF.
        if (recording != null && action in CAPTURE_WAKE_ACTIONS) {
            runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            runCatching { DrivingAlertService.wakeRecording(context.applicationContext, action) }
                .onFailure { CoreLog.w("BOOT", "capture wake request failed: $action ${it.message}", it) }
        } else if (enabled && autoStart) {
            runCatching { DrivingAlertService.start(context.applicationContext) }
                .onSuccess { CoreLog.i("BOOT", "foreground service start requested: $action") }
                .onFailure { CoreLog.w("BOOT", "start failed for $action: ${it.message}", it) }
        }
        if (action in AUTO_SEQUENCE_ACTIONS) {
            val seqEnabled=FeatureProfiles.sequenceEnabled(context)
            val steps=FeatureProfiles.steps(context).count { it.enabled }
            val guard=context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
            val now=android.os.SystemClock.elapsedRealtime()
            val previous=guard.getLong("last_started_elapsed",-1L)
            // A new boot resets elapsedRealtime. Legacy v0.17.46 has only a wall-clock
            // timestamp, so a first verified ACC/IGN ON safely migrates the old latch.
            val sameBoot=previous>=0L && now>=previous
            val armed=guard.getBoolean("armed",true) || !sameBoot
            CoreLog.i("BOOT","AUTO_SEQUENCE_TRIGGER action=$action enabled=$seqEnabled steps=$steps armed=$armed elapsed=$now lastElapsed=$previous")
            if (!seqEnabled) {
                CoreLog.i("BOOT","AUTO_SEQUENCE_DISABLED action=$action")
            } else if(steps==0) {
                CoreLog.w("BOOT","AUTO_SEQUENCE_NO_ENABLED_STEPS action=$action")
            } else if(armed && (!sameBoot || now-previous>2_000L)) {
                // Persist the ignition session guard before requesting async service
                // delivery. If Android rejects service dispatch, roll it back.
                val stored=guard.edit().putBoolean("armed",false)
                    .putLong("last_started_elapsed",now).commit()
                if(!stored) {
                    CoreLog.w("BOOT","AUTO_SEQUENCE_GUARD_PERSIST_FAILED action=$action")
                } else {
                    IgnitionSequenceAlarmReceiver.schedule(context.applicationContext)
                    val accepted=AutoLaunchSequenceService.start(context.applicationContext)
                    if(!accepted) {
                        IgnitionSequenceAlarmReceiver.cancel(context.applicationContext)
                        guard.edit().putBoolean("armed",true).commit()
                        CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_REJECTED action=$action;rearmed=true")
                    } else {
                        CoreLog.i("BOOT","AUTO_SEQUENCE_DELIVERY_REQUESTED action=$action;notVerified=true")
                    }
                }
            } else CoreLog.i("BOOT","AUTO_SEQUENCE_DUPLICATE_SUPPRESSED action=$action armed=$armed")
        } else if (action==Intent.ACTION_BOOT_COMPLETED) {
            // A system boot or door/sentry wake does not prove that ACC is on.
            // Never start selected music solely because Android reports BOOT_COMPLETED.
            CoreLog.i("BOOT","AUTO_SEQUENCE_BOOT_OBSERVED enabled=${FeatureProfiles.sequenceEnabled(context)} enabledSteps=${FeatureProfiles.steps(context).count{it.enabled}};notIgnitionProof=true")
        }
    }

    companion object {
        private val CAPTURE_WAKE_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_USER_PRESENT, Intent.ACTION_USER_UNLOCKED,
            Intent.ACTION_SCREEN_ON, Intent.ACTION_POWER_CONNECTED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON", "com.byd.intent.action.QUICKBOOT_POWERON",
            "com.qualcomm.action.QUICKBOOT_POWERON", "com.byd.action.ACC_ON", "com.byd.action.IGN_ON",
            "com.byd.accmode.ACC_MODE_CHANGED"
        )
        // Android/door/sentry wake (SCREEN_ON, USER_PRESENT, BOOT_COMPLETED) is NOT ignition ON.
        // Prevent parked vehicle from restarting selected music apps merely because UI wakes.
        private val AUTO_SEQUENCE_ACTIONS = setOf(
            "com.byd.action.ACC_ON", "com.byd.action.IGN_ON"
        )
        // Generic charger cable disconnect is NOT verified vehicle ignition OFF.
        private val STOP_SIDE_ACTIONS = setOf("com.byd.action.ACC_OFF")
    }
}
