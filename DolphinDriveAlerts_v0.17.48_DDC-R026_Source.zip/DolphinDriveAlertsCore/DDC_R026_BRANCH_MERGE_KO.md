# Dolphin Drive Alerts · 분기 통합 검토 R026 (2026-11-04)

## 확인된 입력
- `DDA_R025_REDOWNLOAD.zip`: `v0.17.47_DDC-R025_Source.zip` + 동명 CI YML. 전체 Android 프로젝트 454개 항목(기준 기준).
- `DDA_DDC_v01747_ReadOnly_IntegrationPatch.zip`: R024 추가 Kotlin 2개 + AppPolicyActivity 기존 대비 12줄 추가 + patch/manifest. **두 번째 전체 앱/독립 버전 소스가 아님.**
- 이 자료만으로 v0.17.49 독립 브랜치를 비교하거나 v0.17.49에서 해결된 기능을 판단할 수 없음.

## 유지·선별 통합·배제
1. **R025 유지:** `TemporaryAppDpiController`의 `ThirdPartyDpiRules.isSystem` 검사, 자동 OEM 전면 전환 DPI 차단, 현재 저장된 DPI 복원 저널.
2. **R024 채택:** ADB 인증 상태가 허용할 때 `wm size`, `dumpsys window windows`, `dumpsys activity activities` 조회로 물리/override 밀도, 창 프레임/작업 모드의 간단한 요약만 기록하는 순정 DPI 읽기 전용 조사. `DdcDensityMath` 고정 dp 점유비율 계산을 *가설*로만 표시.
3. **R024 보완:** `com.byd.avc` 카메라 창 추가 감시, 창과 다음 창의 프레임 오인 방지, 덤프 파싱 8,000줄 제한, 조회 중 예외를 사용자 메시지로 처리, 기능 이름을 원인 자동 진단에서 조사로 변경.
4. **버림:** R024의 “고정 dp 비율로 원인을 확정할 수 있다”는 인상/주장. 창 프레임만으로는 내부 View, Surface, 360 영상이 크기 고정인지 판정 못 함.
5. **통합 시 절대 수정하지 않음:** 차량 이벤트/노멀/오토홀드/회생/BSD, 주행 알림 음성 엔진, 운전석 오디오 라우팅, 시동 이벤트, 미디어 자동재생, 분할 실행/비율, 360 영상/주차선. 기존 동작·결함 모두 그대로 이어짐.
6. **빌드 구성 보완:** R025 소스에 `gradle-wrapper.jar`이 없어 `./gradlew` 실행 시 `GradleWrapperMain` 오류 예상. 외부 GitHub Actions YML에서 `gradle/actions/setup-gradle@v4` + Gradle 8.7으로 대체. Java17/Android API34 명시 컴파일/서명 검사 유지.

## 식별자·업데이트
- 패키지 ID: `com.byd.dolphin.drivealerts` 불변.
- 새 통합 후보: `v0.17.48` / `versionCode 74` (기존 R025 `v0.17.47`/73에서 +1).
- 이는 *검증되지 않은 v0.17.49를 기반으로 하는 통합이 아니다.* 만약 설치된 APK가 versionCode 74 이상이면, 다운그레이드 없이 설치할 수 있는지는 설치 상태에 따라 달라진다.
- 동일한 서명 인증서가 없다면 **기존 앱 위에 업데이트 설치 불가**. 기존 차량의 설정 보존을 위해 무작정 삭제/재설치하지 말 것.

## 검증 상태
- R025 기존 최신 소스 게이트 `verify_v01747_dashboard_deep.py`, `verify_v01746_core_kotlin.py`, `verify_v01747_r12_patch.py`에서 버전 변경 검사를 포함해 재실행.
- 새로운 `verify_merge_v01748_R026.py`: 정적 보호 명령 확인, 신규 Kotlin 로직과 가상 ADB 응답의 JVM 컴파일/실행, Gradle 사용 YML 검증.
- 제공된 파일로는 **Android SDK 실컴파일 / GitHub Actions 실제 실행 / BYD 실차 검증을 할 수 없음**. 결과물은 APK가 아니라 GitHub 빌드용 전체 소스팩임.
- 과거 세대별 일부 회귀 스크립트에는 더 이상 일치하지 않는 UI/시간 조건이 남아 있어 이전 버전 테스트 실패를 최신 기능 고장이라고 단정하면 안 됨.

## 미해결 계속 추적
- 순정 런처·360에서 DPI120/140 빈공간 실제 확대/복원 원리 (진단으로 원인 확정되지 않음)
- 시동 시 선택 앱 자동 실행/미디어 자동재생 미확인
- 2앱 순차 실행만 되고 실제 분할 미작동, 비율/복원 미확인
- 앱별 운전석 독립 음성 라우팅 확인되지 않음
- 기존 정상 확인된 NORMAL 알림은 보존하되 R026에서 다시 실차 시험했다고 주장하지 않음
