package com.byd.dolphin.drivealerts.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.byd.dolphin.drivealerts.util.CoreLog
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.abs

/**
 * Ultra-Low-Resource Stopped-Only Lead-Car Departure Engine (v0.17.69):
 * - Runs ONLY while armed (D-gear stopped <= 0.8 km/h) at ~4 fps (250ms interval); 0% CPU while driving.
 * - Priority 1 (Daytime): Memory-mapped INT8 Quantized SSD-MobileNetV1 (assets/lead_detect.tflite)
 *   with XNNPACK 2 threads, locking strictly onto central vehicles (COCO car=2, bus=5, truck=7)
 *   to reject crosswalk pedestrians, wipers, and adjacent-lane traffic.
 * - Priority 2 (Nighttime / Low-Light): Twin-red taillight spacing & vertical-rise tracker
 *   on the central dewarped front ROI.
 * - Fallback (if .tflite model not present): 3-filter central ROI width/edge shrink tracker.
 * - Requires: (1) lead-car lock-on for >= 1.0s, (2) 3 consecutive frames of consistent departure
 *   before firing.
 */
class TfliteLeadCarDetector(context: Context) {
    data class Detection(
        val detected: Boolean,
        val departed: Boolean,
        val mode: String,
        val detail: String
    )

    private val app = context.applicationContext
    @Volatile private var interpreter: Interpreter? = null
    @Volatile private var modelTried = false
    @Volatile private var modelLoaded = false

    private val inputBuffer: ByteBuffer = ByteBuffer.allocateDirect(INPUT_SIZE * INPUT_SIZE * 3)
        .order(ByteOrder.nativeOrder())
    private val outLocations = Array(1) { Array(MAX_DETECTIONS) { FloatArray(4) } }
    private val outClasses = Array(1) { FloatArray(MAX_DETECTIONS) }
    private val outScores = Array(1) { FloatArray(MAX_DETECTIONS) }
    private val outCount = FloatArray(1)

    // Tracking state (reset on disarm)
    private var lockWidth: Float = 0f
    private var lockFrames: Int = 0
    private var departStreak: Int = 0
    private var nightBaseSpan: Float = 0f
    private var nightLockFrames: Int = 0
    private var nightDepartStreak: Int = 0
    private var lastRunMs: Long = 0L

    fun isModelAvailable(): Boolean {
        ensureModelLoaded()
        return modelLoaded
    }

    fun resetTracking() {
        lockWidth = 0f
        lockFrames = 0
        departStreak = 0
        nightBaseSpan = 0f
        nightLockFrames = 0
        nightDepartStreak = 0
    }

    /** Release interpreter when moving/disarmed to keep driving RAM & CPU at 0. */
    fun releaseInterpreter() {
        resetTracking()
        runCatching { interpreter?.close() }
        interpreter = null
        modelLoaded = false
        modelTried = false
    }

    private fun ensureModelLoaded() {
        if (modelTried) return
        modelTried = true
        val mapped = loadMappedModel() ?: return
        runCatching {
            val opts = Interpreter.Options().apply {
                setNumThreads(2)
                setUseXNNPACK(true)
            }
            interpreter = Interpreter(mapped, opts)
            modelLoaded = true
            CoreLog.i("LEAD_AI", "TFLite SSD-MobileNetV1 INT8 loaded (XNNPACK 2 threads)")
        }.onFailure { e ->
            CoreLog.w("LEAD_AI", "TFLite init failed, falling back to light tracker: ${e.message}")
            modelLoaded = false
        }
    }

    private fun loadMappedModel(): MappedByteBuffer? = runCatching {
        val afd = app.assets.openFd(MODEL_ASSET)
        FileInputStream(afd.fileDescriptor).use { fis ->
            fis.channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.length)
        }
    }.getOrNull()

    /**
     * Evaluate one 320x240 RGBA/ARGB front-quadrant bitmap at max 4fps (250ms throttle).
     */
    fun analyzeFrontBitmap(bmp: Bitmap, sensitivity: Int): Detection {
        val now = System.currentTimeMillis()
        if (now - lastRunMs < 240L) {
            return Detection(false, false, "THROTTLED", "4fps gate")
        }
        lastRunMs = now

        val avgLuma = estimateCenterLuma(bmp)
        val isNight = avgLuma < 52f

        // 1. Daytime / Lit road: TFLite SSD-MobileNetV1 INT8 (car/bus/truck only)
        if (!isNight) {
            ensureModelLoaded()
            val interp = interpreter
            if (modelLoaded && interp != null) {
                val res = runTfliteInference(interp, bmp, sensitivity)
                if (res.detected || lockFrames > 0) return res
            }
        }

        // 2. Nighttime or TFLite fallback: Twin-red taillight spacing tracker
        return runNightTaillightTracker(bmp, sensitivity, isNight)
    }

    private fun runTfliteInference(interp: Interpreter, bmp: Bitmap, sensitivity: Int): Detection {
        val scaled = if (bmp.width == INPUT_SIZE && bmp.height == INPUT_SIZE) bmp
        else Bitmap.createScaledBitmap(bmp, INPUT_SIZE, INPUT_SIZE, false)

        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        scaled.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        if (scaled !== bmp) scaled.recycle()

        inputBuffer.rewind()
        for (px in pixels) {
            inputBuffer.put(((px shr 16) and 0xFF).toByte())
            inputBuffer.put(((px shr 8) and 0xFF).toByte())
            inputBuffer.put((px and 0xFF).toByte())
        }
        inputBuffer.rewind()

        val outputs = mapOf(
            0 to outLocations,
            1 to outClasses,
            2 to outScores,
            3 to outCount
        )
        runCatching { interp.runForMultipleInputsOutputs(arrayOf(inputBuffer), outputs) }
            .onFailure { return Detection(false, false, "TFLITE_ERR", it.javaClass.simpleName) }

        val n = outCount[0].toInt().coerceIn(0, MAX_DETECTIONS)
        var bestWidth = 0f
        var bestScore = 0f
        for (i in 0 until n) {
            val score = outScores[0][i]
            val cls = outClasses[0][i].toInt()
            // COCO quantized SSD-MobileNetV1: 2=car, 5=bus, 7=truck
            if (score < 0.42f || cls !in VEHICLE_CLASSES) continue
            val top = outLocations[0][i][0]
            val left = outLocations[0][i][1]
            val bottom = outLocations[0][i][2]
            val right = outLocations[0][i][3]
            val cx = (left + right) * 0.5f
            val bw = (right - left).coerceAtLeast(0f)
            // Strict central lane ROI (0.32..0.68) and reasonable lower-half vehicle size
            if (cx in 0.30f..0.70f && bottom >= 0.38f && bw >= 0.12f && score > bestScore) {
                bestScore = score
                bestWidth = bw
            }
        }

        val shrinkRatio = when (sensitivity) {
            0 -> 0.16f // 둔감
            2 -> 0.09f // 민감
            else -> 0.12f // 보통
        }

        if (bestWidth > 0f) {
            if (lockFrames < 4) {
                lockWidth = if (lockFrames == 0) bestWidth else (lockWidth * 0.6f + bestWidth * 0.4f)
                lockFrames++
                departStreak = 0
                return Detection(true, false, "TFLITE_LOCKING", "w=${"%.2f".format(bestWidth)} s=${"%.2f".format(bestScore)}")
            }
            val shrink = (lockWidth - bestWidth) / lockWidth.coerceAtLeast(0.05f)
            if (shrink >= shrinkRatio) {
                departStreak++
                if (departStreak >= 4) {
                    val msg = "TFLite 앞차 폭 축소 ${"%.2f".format(lockWidth)}->${"%.2f".format(bestWidth)} (${(shrink * 100).toInt()}%)"
                    resetTracking()
                    return Detection(true, true, "TFLITE_AI", msg)
                }
            } else {
                departStreak = 0
                if (bestWidth > lockWidth) lockWidth = lockWidth * 0.8f + bestWidth * 0.2f
            }
            return Detection(true, false, "TFLITE_TRACK", "w=${"%.2f".format(bestWidth)} streak=$departStreak")
        } else if (lockFrames >= 4) {
            // Lead vehicle disappeared after being locked -> count toward 3-frame departure
            departStreak++
            if (departStreak >= 4) {
                val msg = "TFLite 앞차 시야 이탈 (기준폭 ${"%.2f".format(lockWidth)})"
                resetTracking()
                return Detection(true, true, "TFLITE_AI", msg)
            }
        }
        return Detection(false, false, "TFLITE_IDLE", "no central car")
    }

    /**
     * Nighttime twin-red taillight horizontal-span tracker (zero ML cost, works in darkness/rain).
     */
    private fun runNightTaillightTracker(bmp: Bitmap, sensitivity: Int, isNight: Boolean): Detection {
        val w = bmp.width
        val h = bmp.height
        val x0 = (w * 0.28f).toInt()
        val x1 = (w * 0.72f).toInt()
        val y0 = (h * 0.30f).toInt()
        val y1 = (h * 0.78f).toInt()
        var minRedX = Int.MAX_VALUE
        var maxRedX = Int.MIN_VALUE
        var redCount = 0

        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val px = bmp.getPixel(x, y)
                val r = Color.red(px)
                val g = Color.green(px)
                val b = Color.blue(px)
                if (r >= 165 && r - g >= 65 && r - b >= 65) {
                    redCount++
                    if (x < minRedX) minRedX = x
                    if (x > maxRedX) maxRedX = x
                }
                x += 2
            }
            y += 2
        }

        val span = if (redCount >= 8 && maxRedX > minRedX) (maxRedX - minRedX).toFloat() / w else 0f
        val shrinkReq = when (sensitivity) { 0 -> 0.17f; 2 -> 0.10f; else -> 0.13f }

        if (span >= 0.08f) {
            if (nightLockFrames < 4) {
                nightBaseSpan = if (nightLockFrames == 0) span else (nightBaseSpan * 0.6f + span * 0.4f)
                nightLockFrames++
                nightDepartStreak = 0
                return Detection(true, false, if (isNight) "NIGHT_LOCK" else "LIGHT_LOCK", "span=${"%.2f".format(span)}")
            }
            val shrink = (nightBaseSpan - span) / nightBaseSpan.coerceAtLeast(0.05f)
            if (shrink >= shrinkReq) {
                nightDepartStreak++
                if (nightDepartStreak >= 5) {
                    val msg = "야간 후미등 간격 축소 ${"%.2f".format(nightBaseSpan)}->${"%.2f".format(span)} (${(shrink * 100).toInt()}%)"
                    resetTracking()
                    return Detection(true, true, "NIGHT_TAILLIGHT", msg)
                }
            } else {
                nightDepartStreak = 0
            }
            return Detection(true, false, "NIGHT_TRACK", "span=${"%.2f".format(span)}")
        } else if (nightLockFrames >= 4 && abs(span) < 0.01f) {
            nightDepartStreak++
            if (nightDepartStreak >= 5) {
                val msg = "야간 앞차 후미등 소실 (기준 간격 ${"%.2f".format(nightBaseSpan)})"
                resetTracking()
                return Detection(true, true, "NIGHT_TAILLIGHT", msg)
            }
        }
        return Detection(false, false, "IDLE", "luma=${avgLumaTag(isNight)}")
    }

    private fun avgLumaTag(isNight: Boolean): String = if (isNight) "night" else "day"

    private fun estimateCenterLuma(bmp: Bitmap): Float {
        var sum = 0f
        var cnt = 0
        val stepX = (bmp.width / 12).coerceAtLeast(1)
        val stepY = (bmp.height / 12).coerceAtLeast(1)
        var y = bmp.height / 4
        while (y < (bmp.height * 3) / 4) {
            var x = bmp.width / 4
            while (x < (bmp.width * 3) / 4) {
                val px = bmp.getPixel(x, y)
                sum += 0.299f * Color.red(px) + 0.587f * Color.green(px) + 0.114f * Color.blue(px)
                cnt++
                x += stepX
            }
            y += stepY
        }
        return if (cnt > 0) sum / cnt else 128f
    }

    companion object {
        private const val MODEL_ASSET = "lead_detect.tflite"
        private const val INPUT_SIZE = 300
        private const val MAX_DETECTIONS = 10
        private val VEHICLE_CLASSES = setOf(2, 5, 7) // COCO: car, bus, truck
    }
}
