package com.byd.dolphin.drivealerts.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Clean-Room BVM Blind-Spot Camera Controller (v0.17.67):
 * - Priority 1: BYD DiLink 3 BmmCamera / AVMCamera (/system/framework/bmmcamera.jar)
 *               rendered through OpenGL ES 3.0 precomputed LUT fisheye-dewarp +
 *               5-tap unsharp-mask sharpness + direct GPU Brightness/Contrast/Saturation/Gamma.
 * - Priority 2: Standard Camera2 API fallback.
 * - Priority 3: Legacy Camera1 API fallback.
 * - Immediate yield on Reverse gear so stock 360 AVM never conflicts.
 */
class BsdCameraOverlayController(context: Context) {
    private val app = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var camThread: HandlerThread? = null
    private var camHandler: Handler? = null

    private val avmBackend = BydAvmCameraBackend(app)
    private var glRenderer: GlLutDewarpRenderer? = null
    private var glWindowSurface: Surface? = null

    private var overlayView: FrameLayout? = null
    private var textureView: TextureView? = null
    private var statusBadge: TextView? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var activeSurface: Surface? = null
    @Suppress("DEPRECATION") private var legacyCamera: android.hardware.Camera? = null

    @Volatile private var currentSide: Side = Side.UNKNOWN
    @Volatile private var lastSignalMs: Long = 0L
    @Volatile private var previewUntilMs: Long = 0L

    private val hideRunnable = Runnable { hide("hold_expired") }

    fun isOverlayActive(): Boolean = currentSide != Side.UNKNOWN

    /** Probe BYD AVMCamera (bmmcamera.jar) + Camera2 + Legacy Camera1 + /dev/video* nodes. */
    @Suppress("DEPRECATION")
    fun probeCameras(): String {
        val sb = StringBuilder()
        val avm = avmBackend.probe()
        sb.appendLine("1) ${avm.detail}")

        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        val c2Ids = runCatching { cm?.cameraIdList?.toList() ?: emptyList() }.getOrDefault(emptyList())
        sb.appendLine("2) Camera2 장치: ${c2Ids.size}개 ${if (c2Ids.isEmpty()) "(미노출)" else c2Ids.joinToString(", ")}")
        for (id in c2Ids) {
            val info = runCatching {
                val ch = cm!!.getCameraCharacteristics(id)
                val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                    CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                    CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
                    else -> "UNKNOWN"
                }
                val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
                    ?.take(3)?.joinToString(",") { "${it.width}x${it.height}" } ?: "none"
                " - ID=$id ($facing) sizes=$sizes"
            }.getOrElse { " - ID=$id (err:${it.javaClass.simpleName})" }
            sb.appendLine(info)
        }
        val c1Count = runCatching { android.hardware.Camera.getNumberOfCameras() }.getOrDefault(0)
        sb.appendLine("3) Camera1(레거시) 장치: ${c1Count}개")
        val devVideos = runCatching {
            java.io.File("/dev").listFiles { _, name -> name.startsWith("video") }?.map { it.name }?.sorted()?.take(8) ?: emptyList()
        }.getOrDefault(emptyList())
        if (devVideos.isNotEmpty()) sb.appendLine("4) V4L2 노드: ${devVideos.joinToString(", ")}")
        if (!avm.available && c2Ids.isEmpty() && c1Count == 0) {
            sb.appendLine("※ AVMCamera와 표준 카메라 API가 모두 미노출 상태입니다.")
        }
        return sb.toString().trim()
    }

    /** Auto-detect BYD AVM / Camera2 / Camera1 IDs and apply optimal LUT BVM preset. */
    @Suppress("DEPRECATION")
    fun autoDetectAndCalibrate(): String {
        val avm = avmBackend.probe()
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        val c2Ids = runCatching { cm?.cameraIdList?.toList() ?: emptyList() }.getOrDefault(emptyList())
        val c1Count = runCatching { android.hardware.Camera.getNumberOfCameras() }.getOrDefault(0)
        BsdCameraPreferences.applyHyundaiKiaBvmPreset(app)

        if (avm.available) {
            DashcamPreferences.setCameraId(app, "AVM")
            LeadCarDeparturePreferences.setFrontCameraId(app, "AVM")
            BsdCameraPreferences.setLeftCameraId(app, "AVM")
            BsdCameraPreferences.setRightCameraId(app, "AVM")
            BsdCameraPreferences.setCropMode(app, 2) // 4-quadrant AVM (2560x1920)
            LeadCarDeparturePreferences.setAvmFrontQuadrant(app, true)
            return "자동 감지 완료 (BYD AVMCamera · 4분할 쿼드 + OpenGL ES 3.0 LUT 어안·선명도·밝기·채도 자동 보정 적용)"
        }
        return when {
            c2Ids.size >= 4 -> {
                DashcamPreferences.setCameraId(app, c2Ids[0])
                LeadCarDeparturePreferences.setFrontCameraId(app, c2Ids[0])
                BsdCameraPreferences.setLeftCameraId(app, c2Ids[1])
                BsdCameraPreferences.setRightCameraId(app, c2Ids[2])
                BsdCameraPreferences.setCropMode(app, 0)
                LeadCarDeparturePreferences.setAvmFrontQuadrant(app, false)
                "자동 감지 완료 (4채널 개별 ID: 전방=${c2Ids[0]}, 좌=${c2Ids[1]}, 우=${c2Ids[2]}, 후방=${c2Ids[3]}) + 자동 보정 적용"
            }
            c2Ids.isNotEmpty() -> {
                val id0 = c2Ids[0]
                DashcamPreferences.setCameraId(app, id0)
                LeadCarDeparturePreferences.setFrontCameraId(app, id0)
                BsdCameraPreferences.setLeftCameraId(app, id0)
                BsdCameraPreferences.setRightCameraId(app, id0)
                BsdCameraPreferences.setCropMode(app, 2)
                LeadCarDeparturePreferences.setAvmFrontQuadrant(app, true)
                "자동 감지 완료 (단일 AVM 스트림 ID=$id0 · 4분할 자동 크롭) + LUT 어안·화질 자동 보정 적용"
            }
            c1Count > 0 -> {
                DashcamPreferences.setCameraId(app, "0")
                BsdCameraPreferences.setLeftCameraId(app, "0")
                BsdCameraPreferences.setRightCameraId(app, "0")
                BsdCameraPreferences.setCropMode(app, 2)
                "레거시 Camera1 ${c1Count}개 감지됨 (ID=0 폴백) + 자동 보정 적용"
            }
            else -> "AVMCamera·Camera2·Camera1 미감지 (자동 보정 프리셋만 저장됨)"
        }
    }

    fun onVehicleTurnState(side: Side, isReverseGear: Boolean, speedKmH: Float? = null) {
        val now = System.currentTimeMillis()
        if (isReverseGear) {
            if (currentSide != Side.UNKNOWN) hide("reverse_gear_yield")
            return
        }
        if (now < previewUntilMs) return
        if (!BsdCameraPreferences.enabled(app)) {
            if (currentSide != Side.UNKNOWN) hide("disabled")
            return
        }
        if (speedKmH != null) {
            val speedOk = when (BsdCameraPreferences.speedFilterMode(app)) {
                1 -> speedKmH in 5f..80f
                2 -> speedKmH in 10f..110f
                else -> true
            }
            if (!speedOk) {
                if (currentSide != Side.UNKNOWN) hide("speed_out_of_range")
                return
            }
        }
        if (side == Side.LEFT || side == Side.RIGHT) {
            lastSignalMs = now
            mainHandler.removeCallbacks(hideRunnable)
            if (currentSide != side) show(side, isPreview = false)
            mainHandler.postDelayed(hideRunnable, BsdCameraPreferences.holdMs(app))
        } else if (currentSide != Side.UNKNOWN && now - lastSignalMs >= BsdCameraPreferences.holdMs(app)) {
            hide("signal_off")
        }
    }

    fun startPreview(side: Side, durationMs: Long = 5_000L) {
        previewUntilMs = System.currentTimeMillis() + durationMs
        mainHandler.removeCallbacks(hideRunnable)
        show(side, isPreview = true)
        mainHandler.postDelayed(hideRunnable, durationMs)
    }

    fun hide(reason: String = "manual") {
        mainHandler.post {
            mainHandler.removeCallbacks(hideRunnable)
            previewUntilMs = 0L
            currentSide = Side.UNKNOWN
            closeCamera()
            removeOverlayView()
            CoreLog.i("BSD_CAM", "overlay hidden reason=$reason")
        }
    }

    fun shutdown() {
        hide("shutdown")
        runCatching { camThread?.quitSafely() }
        camThread = null
        camHandler = null
    }

    private fun ensureCameraThread() {
        if (camThread != null && camThread!!.isAlive) return
        camThread = HandlerThread("bsd-camera2").apply { start() }
        camHandler = Handler(camThread!!.looper)
    }

    private fun show(side: Side, isPreview: Boolean) {
        mainHandler.post {
            if (!Settings.canDrawOverlays(app)) { CoreLog.w("BSD_CAM", "overlay permission missing"); return@post }
            if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                CoreLog.w("BSD_CAM", "CAMERA permission missing"); return@post
            }
            currentSide = side
            closeCamera()
            removeOverlayView()
            createOverlayView(side, isPreview)
        }
    }

    private fun dp(v: Int): Int = (app.resources.displayMetrics.density * v + 0.5f).toInt()

    private fun buildGlParams(side: Side): GlLutDewarpRenderer.Params {
        val userPanX = BsdCameraPreferences.panX(app) / 100f
        // Level horizon BYD Dolphin side-mirror BVM (no forced 50deg tilt or 0.20 shift)
        val panX = if (side == Side.RIGHT) -userPanX else userPanX
        return GlLutDewarpRenderer.Params(
            quadCrop = BsdCameraPreferences.cropMode(app),
            quadrantIndex = if (side == Side.RIGHT) 1 else 3, // 5120x960 strip: 1=Right (0.50..0.75), 3=Left (0.75..1.00)
            mirrorX = BsdCameraPreferences.mirrorHorizontal(app),
            flipY = BsdCameraPreferences.flipVertical(app),
            rotationDeg = BsdCameraPreferences.rotationDeg(app).toFloat().let { if (side == Side.RIGHT) it else -it },
            tiltDeg = BsdCameraPreferences.tiltDeg(app).toFloat(),
            zoom = (BsdCameraPreferences.zoomPercent(app) / 100f).coerceIn(0.8f, 2.2f),
            panX = panX.coerceIn(-0.4f, 0.4f),
            panY = (BsdCameraPreferences.panY(app) / 100f).coerceIn(-0.4f, 0.4f),
            fisheyeK = 0.32f, // Natural wide-angle fisheye dewarp preserving side-lane clarity
            brightness = (BsdCameraPreferences.brightness(app) / 125f).coerceIn(-0.35f, 0.35f),
            contrast = (BsdCameraPreferences.contrastPercent(app) / 100f).coerceIn(0.7f, 1.7f),
            saturation = (BsdCameraPreferences.saturationPercent(app) / 100f).coerceIn(0.4f, 1.8f),
            gamma = 0.95f,
            sharpness = 0.42f
        )
    }

    private fun createOverlayView(side: Side, isPreview: Boolean) {
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val (wDp, hDp) = BsdCameraPreferences.customSizeDp(app) ?: when (BsdCameraPreferences.sizeTier(app)) {
            0 -> 380 to 230
            2 -> 580 to 350
            else -> 480 to 290
        }
        val container = FrameLayout(app).apply {
            background = GradientDrawable().apply {
                setColor(0xF0090F1A.toInt())
                cornerRadius = dp(24).toFloat()
                setStroke(dp(3), 0xFF38D9E6.toInt())
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val tv = TextureView(app)
        val badge = TextView(app).apply {
            val sideKo = if (side == Side.LEFT) "◀ 좌측 BVM 후측방" else "우측 BVM 후측방 ▶"
            text = if (isPreview) "$sideKo (미리보기)" else sideKo
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0xBB090F1A.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        val closeHint = TextView(app).apply {
            text = "✕"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xBB1C2C44.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { hide("user_tap_close") }
        }
        val resizeHandle = TextView(app).apply {
            text = "⤢"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF38D9E6.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xCC0D1829.toInt())
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), 0x8838D9E6.toInt())
            }
        }
        container.addView(tv, FrameLayout.LayoutParams(-1, -1))
        container.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(12), dp(10), 0, 0)
        })
        container.addView(closeHint, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(8), dp(10), 0)
        })
        container.addView(resizeHandle, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(8), dp(8))
        })

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                openCameraWithGlPipeline(tv, side, surface, width, height)
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
                val ws = glWindowSurface
                if (ws != null && ws.isValid && SharedAvmSession.isSessionOpen()) {
                    SharedAvmSession.attachBsdDisplay(app, ws, width, height, buildGlParams(side)) { _, _ -> }
                } else {
                    applyBvmTransform(tv, side, width, height)
                }
            }
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                closeCamera()
                return true
            }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }

        val dm = app.resources.displayMetrics
        val isRight = side == Side.RIGHT
        val savedPos = BsdCameraPreferences.customPosPx(app, isRight)
        val initW = dp(wDp)
        val initH = dp(hDp)
        val defaultX = if (isRight) (dm.widthPixels - initW - dp(24)).coerceAtLeast(dp(12)) else dp(24)
        val defaultY = dp(18) // Default TOP placement

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            initW, initH, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (savedPos?.first ?: defaultX).coerceIn(0, (dm.widthPixels - initW).coerceAtLeast(0))
            y = (savedPos?.second ?: defaultY).coerceIn(0, (dm.heightPixels - initH).coerceAtLeast(0))
        }

        // Free touch drag-to-move on overlay body
        var dragStartX = 0f; var dragStartY = 0f
        var lpStartX = 0; var lpStartY = 0
        container.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = ev.rawX; dragStartY = ev.rawY
                    lpStartX = lp.x; lpStartY = lp.y
                    if (previewUntilMs > 0L) {
                        previewUntilMs = System.currentTimeMillis() + 8_000L
                        mainHandler.removeCallbacks(hideRunnable)
                        mainHandler.postDelayed(hideRunnable, 8_000L)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (lpStartX + (ev.rawX - dragStartX).toInt()).coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
                    lp.y = (lpStartY + (ev.rawY - dragStartY).toInt()).coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
                    runCatching { wm.updateViewLayout(container, lp) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    BsdCameraPreferences.setCustomPosPx(app, isRight, lp.x, lp.y)
                    true
                }
                else -> false
            }
        }

        // Free touch corner resize handle (bottom-right)
        var resStartX = 0f; var resStartY = 0f
        var resStartW = 0; var resStartH = 0
        resizeHandle.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    resStartX = ev.rawX; resStartY = ev.rawY
                    resStartW = lp.width; resStartH = lp.height
                    if (previewUntilMs > 0L) {
                        previewUntilMs = System.currentTimeMillis() + 8_000L
                        mainHandler.removeCallbacks(hideRunnable)
                        mainHandler.postDelayed(hideRunnable, 8_000L)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxW = minOf(dp(760), (dm.widthPixels - lp.x).coerceAtLeast(dp(260)))
                    val maxH = minOf(dp(480), (dm.heightPixels - lp.y).coerceAtLeast(dp(160)))
                    val newW = (resStartW + (ev.rawX - resStartX).toInt()).coerceIn(dp(260), maxW)
                    val newH = (resStartH + (ev.rawY - resStartY).toInt()).coerceIn(dp(160), maxH)
                    lp.width = newW
                    lp.height = newH
                    runCatching { wm.updateViewLayout(container, lp) }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dens = dm.density.coerceAtLeast(1f)
                    BsdCameraPreferences.setCustomSizeDp(app, (lp.width / dens).toInt(), (lp.height / dens).toInt())
                    true
                }
                else -> false
            }
        }

        runCatching {
            wm.addView(container, lp)
            overlayView = container
            textureView = tv
            statusBadge = badge
        }.onFailure {
            CoreLog.w("BSD_CAM", "addView failed: ${it.message}")
        }
    }

    /** Priority 1: Open BYD AVMCamera via OpenGL ES 3.0 LUT Dewarp + Sharpness + Color Grading. */
    private fun openCameraWithGlPipeline(
        tv: TextureView,
        side: Side,
        surfaceTexture: SurfaceTexture,
        width: Int,
        height: Int
    ) {
        if (SharedAvmSession.isAvailable(app)) {
            val winSurf = Surface(surfaceTexture)
            glWindowSurface = winSurf
            SharedAvmSession.attachBsdDisplay(app, winSurf, width, height, buildGlParams(side)) { ok, msg ->
                if (!ok) {
                    CoreLog.w("BSD_CAM", "SharedAvmSession attach failed ($msg); falling back to Camera2")
                    mainHandler.post {
                        closeGlOnly()
                        applyColorCalibration(tv)
                        applyBvmTransform(tv, side, width, height)
                        openStandardCamera(side, surfaceTexture)
                    }
                } else {
                    CoreLog.i("BSD_CAM", "SharedAvmSession BVM active: $msg")
                }
            }
            return
        }
        applyColorCalibration(tv)
        applyBvmTransform(tv, side, width, height)
        openStandardCamera(side, surfaceTexture)
    }

    private fun applyColorCalibration(tv: TextureView) {
        val bright = BsdCameraPreferences.brightness(app) * 2.0f
        val contrast = BsdCameraPreferences.contrastPercent(app) / 100f
        val sat = BsdCameraPreferences.saturationPercent(app) / 100f
        val satMatrix = ColorMatrix().apply { setSaturation(sat) }
        val t = (1f - contrast) * 128f + bright
        val bcMatrix = ColorMatrix(floatArrayOf(
            contrast, 0f, 0f, 0f, t,
            0f, contrast, 0f, 0f, t,
            0f, 0f, contrast, 0f, t,
            0f, 0f, 0f, 1f, 0f
        ))
        satMatrix.postConcat(bcMatrix)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(satMatrix) }
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun applyBvmTransform(tv: TextureView, side: Side, viewW: Int, viewH: Int) {
        val w = viewW.toFloat().coerceAtLeast(1f)
        val h = viewH.toFloat().coerceAtLeast(1f)
        val cropMode = BsdCameraPreferences.cropMode(app)
        val zoom = BsdCameraPreferences.zoomPercent(app) / 100f
        val mirrorH = BsdCameraPreferences.mirrorHorizontal(app)
        val flipV = BsdCameraPreferences.flipVertical(app)
        val rawPanX = BsdCameraPreferences.panX(app) / 100f
        val panX = if (side == Side.RIGHT) -rawPanX else rawPanX
        val panY = BsdCameraPreferences.panY(app) / 100f

        val m = Matrix()
        when (cropMode) {
            1 -> {
                m.setScale(2f, 1f)
                if (side == Side.RIGHT) m.postTranslate(-w, 0f)
            }
            2 -> {
                m.setScale(2f, 2f)
                m.postTranslate(if (side == Side.RIGHT) -w else 0f, -h)
            }
            else -> m.reset()
        }
        m.postScale(zoom, zoom, w / 2f, h / 2f)
        val sx = if (mirrorH) -1f else 1f
        val sy = if (flipV) -1f else 1f
        if (mirrorH || flipV) m.postScale(sx, sy, w / 2f, h / 2f)
        m.postTranslate(panX * w, panY * h)
        tv.setTransform(m)
    }

    private fun openStandardCamera(side: Side, surfaceTexture: SurfaceTexture) {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        val requestedId = if (side == Side.LEFT) BsdCameraPreferences.leftCameraId(app) else BsdCameraPreferences.rightCameraId(app)
        val available = runCatching { cm.cameraIdList.toList() }.getOrDefault(emptyList())
        val camId = if (requestedId in available) requestedId else available.firstOrNull()
        if (camId == null) {
            if (tryOpenLegacyCamera1(surfaceTexture)) return
            mainHandler.post { statusBadge?.text = "카메라 미노출 (AVM·Camera2 모두 없음)" }
            return
        }
        ensureCameraThread()
        val handler = camHandler ?: return
        runCatching {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (currentSide == Side.UNKNOWN) { runCatching { camera.close() }; return }
                    cameraDevice = camera
                    startPreviewSession(camera, camId, cm, surfaceTexture, handler)
                }
                override fun onDisconnected(camera: CameraDevice) {
                    runCatching { camera.close() }
                    hide("camera_disconnected")
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    mainHandler.post { statusBadge?.text = "카메라 열기 오류 (code=$error)" }
                    runCatching { camera.close() }
                }
            }, handler)
        }.onFailure {
            mainHandler.post { statusBadge?.text = "카메라 접근 실패: ${it.javaClass.simpleName}" }
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreviewSession(
        camera: CameraDevice,
        camId: String,
        cm: CameraManager,
        surfaceTexture: SurfaceTexture,
        handler: Handler
    ) {
        runCatching {
            val bestSize = runCatching {
                cm.getCameraCharacteristics(camId)
                    .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    ?.getOutputSizes(SurfaceTexture::class.java)
                    ?.filter { it.width <= 1920 && it.height <= 1080 }
                    ?.maxByOrNull { it.width * it.height }
            }.getOrNull()
            surfaceTexture.setDefaultBufferSize(bestSize?.width ?: 1280, bestSize?.height ?: 720)
            val surface = Surface(surfaceTexture)
            activeSurface = surface
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
                runCatching {
                    val range = cm.getCameraCharacteristics(camId).get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                    if (range != null && range.lower < range.upper) {
                        val normalized = BsdCameraPreferences.brightness(app) / 50f
                        val aeVal = (normalized * range.upper).toInt().coerceIn(range.lower, range.upper)
                        set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, aeVal)
                    }
                }
            }
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (cameraDevice == null) { runCatching { session.close() }; return }
                    captureSession = session
                    runCatching { session.setRepeatingRequest(builder.build(), null, handler) }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    mainHandler.post { statusBadge?.text = "카메라 스트림 구성 실패" }
                }
            }, handler)
        }.onFailure {
            CoreLog.w("BSD_CAM", "startPreviewSession failed: ${it.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun tryOpenLegacyCamera1(surfaceTexture: SurfaceTexture): Boolean = runCatching {
        val count = android.hardware.Camera.getNumberOfCameras()
        if (count <= 0) return false
        val c = android.hardware.Camera.open(0) ?: return false
        legacyCamera = c
        c.setPreviewTexture(surfaceTexture)
        c.startPreview()
        CoreLog.i("BSD_CAM", "Opened legacy Camera1 fallback (count=$count)")
        true
    }.getOrDefault(false)

    private fun closeGlOnly() {
        runCatching { SharedAvmSession.detachBsdDisplay() }
        runCatching { glRenderer?.release() }
        glRenderer = null
        runCatching { glWindowSurface?.release() }
        glWindowSurface = null
    }

    private fun closeCamera() {
        runCatching { avmBackend.close() }
        closeGlOnly()
        runCatching { legacyCamera?.stopPreview() }
        runCatching { legacyCamera?.release() }
        legacyCamera = null
        runCatching { captureSession?.stopRepeating() }
        runCatching { captureSession?.close() }
        captureSession = null
        runCatching { cameraDevice?.close() }
        cameraDevice = null
        runCatching { activeSurface?.release() }
        activeSurface = null
    }

    private fun removeOverlayView() {
        val view = overlayView ?: return
        overlayView = null
        textureView = null
        statusBadge = null
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        runCatching { wm.removeViewImmediate(view) }
    }
}
