package com.byd.dolphin.drivealerts.camera

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hardware H.264 MediaCodec + MediaMuxer MP4 Recorder (v0.17.107).
 *
 * Supports two input pipelines:
 * 1. Surface input (useSurfaceInput = true): Zero-copy EGL RGB888 Surface from GlLutDewarpRenderer.
 * 2. ByteBuffer YUV420 input (useSurfaceInput = false): Automatic LinkLock-proven NV12/I420 fallback
 *    for Snapdragon DiLink 3.0 head units where EGL Surface encoding stalls at 0 frames.
 */
class HardwareAvcMp4Recorder(
    private val outputFile: File,
    val width: Int,
    val height: Int,
    private val bitrate: Int,
    private val fps: Int = 24,
    val useSurfaceInput: Boolean = true
) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var surface: Surface? = null
    private var drainThread: Thread? = null
    private val stopping = AtomicBoolean(false)
    private val released = AtomicBoolean(false)
    private var yuvColorFormat: Int = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
    private var yuvScratch: ByteArray? = null
    private var argbScratch: IntArray? = null
    private var inputFrameCount: Long = 0L
    private var startTimeNs: Long = 0L

    @Volatile var trackIndex: Int = -1
        private set
    @Volatile var muxerStarted: Boolean = false
        private set
    @Volatile var framesEncoded: Long = 0L
        private set
    @Volatile var bytesWritten: Long = 0L
        private set
    @Volatile var lastError: String? = null
        private set

    fun inputSurface(): Surface? = surface

    private fun pickYuvColorFormat(): Int {
        return runCatching {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            for (info in list.codecInfos) {
                if (!info.isEncoder) continue
                if (!info.supportedTypes.any { it.equals(MediaFormat.MIMETYPE_VIDEO_AVC, ignoreCase = true) }) continue
                val caps = info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
                val fmts = caps.colorFormats
                if (MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar in fmts) {
                    return@runCatching MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                }
                if (MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar in fmts) {
                    return@runCatching MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
                }
                if (MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible in fmts) {
                    return@runCatching MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                }
            }
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
        }.getOrDefault(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
    }

    fun start(): Boolean {
        return runCatching {
            val colorFmt = if (useSurfaceInput) {
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
            } else {
                pickYuvColorFormat().also { yuvColorFormat = it }
            }
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFmt)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val mc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            mc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf = if (useSurfaceInput) mc.createInputSurface() else null
            mc.start()

            val mx = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            codec = mc
            surface = surf
            muxer = mx
            startTimeNs = System.nanoTime()

            val t = Thread({ drainLoop(mc, mx) }, "avc-muxer-drain")
            drainThread = t
            t.start()
            CoreLog.i(
                "DASHCAM",
                "AVC_CODEC_STARTED mode=${if (useSurfaceInput) "SURFACE" else "NV12_BUF"} fmt=$colorFmt file=${outputFile.name} ${width}x${height}@${fps} br=$bitrate"
            )
            true
        }.onFailure { e ->
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            CoreLog.w("DASHCAM", "AVC_CODEC_START_FAILED: $lastError", e)
            stopAndRelease()
        }.getOrDefault(false)
    }

    /**
     * Feed a live Bitmap (e.g. front-camera crop from SharedAvmSession) into the ByteBuffer H.264 encoder.
     * Safe to call from any thread; no-op in Surface mode or after stop.
     */
    @Synchronized
    fun feedArgbBitmap(src: Bitmap) {
        if (useSurfaceInput || released.get() || stopping.get() || src.isRecycled) return
        val mc = codec ?: return
        runCatching {
            val scaled = if (src.width == width && src.height == height) {
                src
            } else {
                Bitmap.createScaledBitmap(src, width, height, false)
            }
            try {
                val frameSize = width * height
                val yuvSize = frameSize * 3 / 2
                val argb = argbScratch?.takeIf { it.size == frameSize } ?: IntArray(frameSize).also { argbScratch = it }
                val yuv = yuvScratch?.takeIf { it.size == yuvSize } ?: ByteArray(yuvSize).also { yuvScratch = it }
                scaled.getPixels(argb, 0, width, 0, 0, width, height)
                encodeArgbToYuv420(argb, yuv, width, height, semiPlanar = (yuvColorFormat != MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar))

                val inIdx = mc.dequeueInputBuffer(15_000L)
                if (inIdx >= 0) {
                    val inBuf = mc.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        inBuf.clear()
                        val copyLen = minOf(inBuf.capacity(), yuv.size)
                        inBuf.put(yuv, 0, copyLen)
                        val ptsUs = ((System.nanoTime() - startTimeNs) / 1_000L).coerceAtLeast(inputFrameCount * (1_000_000L / fps.coerceAtLeast(1)))
                        inputFrameCount++
                        mc.queueInputBuffer(inIdx, 0, copyLen, ptsUs, 0)
                    }
                }
            } finally {
                if (scaled !== src) runCatching { scaled.recycle() }
            }
        }.onFailure { e ->
            lastError = "feed:${e.javaClass.simpleName}:${e.message}"
        }
    }

    private fun encodeArgbToYuv420(argb: IntArray, yuv: ByteArray, w: Int, h: Int, semiPlanar: Boolean) {
        val frameSize = w * h
        var yIndex = 0
        var uvIndex = frameSize
        var uIndex = frameSize
        var vIndex = frameSize + frameSize / 4
        var idx = 0
        for (j in 0 until h) {
            for (i in 0 until w) {
                val p = argb[idx++]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                yuv[yIndex++] = y.coerceIn(0, 255).toByte()
                if ((j and 1) == 0 && (i and 1) == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    if (semiPlanar) {
                        if (uvIndex + 1 < yuv.size) {
                            yuv[uvIndex++] = u.coerceIn(0, 255).toByte()
                            yuv[uvIndex++] = v.coerceIn(0, 255).toByte()
                        }
                    } else {
                        if (uIndex < yuv.size) yuv[uIndex++] = u.coerceIn(0, 255).toByte()
                        if (vIndex < yuv.size) yuv[vIndex++] = v.coerceIn(0, 255).toByte()
                    }
                }
            }
        }
    }

    private fun drainLoop(mc: MediaCodec, mx: MediaMuxer) {
        val info = MediaCodec.BufferInfo()
        var lastPtsUs = 0L
        while (!released.get()) {
            val idx = try {
                mc.dequeueOutputBuffer(info, 25_000L)
            } catch (e: Throwable) {
                if (!stopping.get()) {
                    lastError = "${e.javaClass.simpleName}: ${e.message}"
                    CoreLog.w("DASHCAM", "AVC_DEQUEUE_ERR: $lastError")
                }
                break
            }
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (stopping.get()) break
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxerStarted) {
                        val fmt = mc.outputFormat
                        trackIndex = mx.addTrack(fmt)
                        mx.start()
                        muxerStarted = true
                        CoreLog.i("DASHCAM", "AVC_MUXER_STARTED track=$trackIndex file=${outputFile.name}")
                    }
                }
                idx >= 0 -> {
                    val buf = runCatching { mc.getOutputBuffer(idx) }.getOrNull()
                    if (buf != null) {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            info.size = 0
                        }
                        if (info.size > 0 && muxerStarted && trackIndex >= 0) {
                            if (info.presentationTimeUs <= lastPtsUs) {
                                info.presentationTimeUs = lastPtsUs + (1_000_000L / fps.coerceAtLeast(1))
                            }
                            lastPtsUs = info.presentationTimeUs
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            runCatching {
                                mx.writeSampleData(trackIndex, buf, info)
                                framesEncoded++
                                bytesWritten += info.size
                            }.onFailure { e ->
                                lastError = "mux:${e.javaClass.simpleName}:${e.message}"
                            }
                        }
                    }
                    runCatching { mc.releaseOutputBuffer(idx, false) }
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                }
            }
        }
    }

    fun stopAndRelease() {
        if (!released.compareAndSet(false, true)) return
        stopping.set(true)
        if (useSurfaceInput) {
            runCatching { codec?.signalEndOfInputStream() }
        } else {
            runCatching {
                val mc = codec
                if (mc != null) {
                    val inIdx = mc.dequeueInputBuffer(50_000L)
                    if (inIdx >= 0) {
                        mc.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    }
                }
            }
        }
        runCatching { drainThread?.join(1_500L) }
        drainThread = null
        if (muxerStarted) {
            runCatching { muxer?.stop() }.onFailure { CoreLog.w("DASHCAM", "muxer.stop failed: ${it.message}") }
        }
        runCatching { muxer?.release() }
        muxer = null
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codec = null
        runCatching { surface?.release() }
        surface = null
        yuvScratch = null
        argbScratch = null
        CoreLog.i("DASHCAM", "AVC_CODEC_STOPPED mode=${if (useSurfaceInput) "SURFACE" else "NV12_BUF"} file=${outputFile.name} frames=$framesEncoded bytes=$bytesWritten fileLen=${outputFile.length()}")
    }
}
