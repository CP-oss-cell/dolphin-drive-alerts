package com.byd.dolphin.drivealerts.notify

import android.content.Context

/**
 * Persistent settings for Telegram Bot real-time vehicle alerts
 * (Bot Token, Chat ID, and per-event notification toggles).
 */
object TelegramPreferences {
    private const val PREF = "dolphin_telegram_prefs"
    private const val KEY_ENABLED = "tg_enabled"
    private const val KEY_BOT_TOKEN = "tg_bot_token"
    private const val KEY_CHAT_ID = "tg_chat_id"
    private const val KEY_NOTIFY_SENTRY = "tg_notify_sentry"
    private const val KEY_NOTIFY_SENTRY_PHOTO = "tg_notify_sentry_photo"
    private const val KEY_NOTIFY_BATTERY = "tg_notify_battery"
    private const val KEY_NOTIFY_DASHCAM_EVT = "tg_notify_dashcam_evt"
    private const val KEY_NOTIFY_IGNITION = "tg_notify_ignition"

    private const val KEY_MIGRATED_V109 = "tg_migrated_v109"

    private fun sp(c: Context): android.content.SharedPreferences {
        val prefs = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_MIGRATED_V109, false)) {
            val hasToken = !prefs.getString(KEY_BOT_TOKEN, "").isNullOrBlank()
            val hasChat = !prefs.getString(KEY_CHAT_ID, "").isNullOrBlank()
            val ed = prefs.edit().putBoolean(KEY_MIGRATED_V109, true)
            if (hasToken && hasChat) {
                ed.putBoolean(KEY_ENABLED, true)
                ed.putBoolean(KEY_NOTIFY_IGNITION, true)
            }
            ed.apply()
        }
        return prefs
    }

    fun enabled(c: Context): Boolean = sp(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_ENABLED, v).apply() }

    fun botToken(c: Context): String = sp(c).getString(KEY_BOT_TOKEN, "").orEmpty().trim()
    fun setBotToken(c: Context, v: String) {
        val clean = v.trim()
        val ed = sp(c).edit().putString(KEY_BOT_TOKEN, clean)
        if (clean.isNotBlank() && chatId(c).isNotBlank()) ed.putBoolean(KEY_ENABLED, true)
        ed.apply()
    }

    fun chatId(c: Context): String = sp(c).getString(KEY_CHAT_ID, "").orEmpty().trim()
    fun setChatId(c: Context, v: String) {
        val clean = v.trim()
        val ed = sp(c).edit().putString(KEY_CHAT_ID, clean)
        if (clean.isNotBlank() && botToken(c).isNotBlank()) ed.putBoolean(KEY_ENABLED, true)
        ed.apply()
    }

    fun notifySentry(c: Context): Boolean = sp(c).getBoolean(KEY_NOTIFY_SENTRY, true)
    fun setNotifySentry(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_NOTIFY_SENTRY, v).apply() }

    fun notifySentryPhoto(c: Context): Boolean = sp(c).getBoolean(KEY_NOTIFY_SENTRY_PHOTO, true)
    fun setNotifySentryPhoto(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_NOTIFY_SENTRY_PHOTO, v).apply() }

    fun notifyBatteryGuard(c: Context): Boolean = sp(c).getBoolean(KEY_NOTIFY_BATTERY, true)
    fun setNotifyBatteryGuard(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_NOTIFY_BATTERY, v).apply() }

    fun notifyDashcamEvent(c: Context): Boolean = sp(c).getBoolean(KEY_NOTIFY_DASHCAM_EVT, true)
    fun setNotifyDashcamEvent(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_NOTIFY_DASHCAM_EVT, v).apply() }

    fun notifyIgnition(c: Context): Boolean = sp(c).getBoolean(KEY_NOTIFY_IGNITION, true)
    fun setNotifyIgnition(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_NOTIFY_IGNITION, v).apply() }

    fun isConfigured(c: Context): Boolean =
        enabled(c) && botToken(c).isNotBlank() && chatId(c).isNotBlank()
}
