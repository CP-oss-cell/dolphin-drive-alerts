package com.byd.dolphin.drivealerts.sentry

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import android.speech.tts.TextToSpeech
import com.byd.dolphin.drivealerts.camera.SharedAvmSession
import com.byd.dolphin.drivealerts.notify.TelegramNotifier
import com.byd.dolphin.drivealerts.notify.TelegramPreferences
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Clean-Room LinkLock-Style Sentry Mode (Parking Guard) Controller (v0.17.70):
 * - Arms automatically when parked (gearRaw == 3 / P, speed <= 0.5 km/h) outside GPS Safe Zones.
 * - Ultra-low-resource 2fps (500ms) 4-quadrant localized block-motion detector with illumination
 *   change rejection (ignores clouds/headlight global flashes, triggers only on localized approach).
 * - Paired with IMU 3-axis accelerometer impact detection.
 * - Protects vehicle 12V & HV batteries with automatic low-voltage / low-SOC / max-duration cutoff.
 * - On trigger: records a protected sentry event MP4 clip + optional Tesla-style warning screen.
 * - On boarding (shifting out of P): disarms immediately & announces unseen sentry event count.
 */
class SentryMonitorController(
    context: Context,
    private val onSentryEventTriggered: (reason: String) -> Unit
) {
    private val app = context.applicationContext
    @Volatile private var armed = false
    @Volatile private var parkedSinceMs = 0L
    @Volatile private var armedSinceMs = 0L
    @Volatile private var lastTriggerMs = 0L
    @Volatile private var lastMotionCheckMs = 0L
    @Volatile private var lastBatteryCheckMs = 0L
    @Volatile private var motionStreak = 0
    @Volatile private var ignitionOff = false
    @Volatile private var lastPowerPollMs = 0L
    @Volatile private var cachedPowerLevel = 3
    @Volatile private var warmupFramesRemaining = 0
    @Volatile private var prevGrid: IntArray? = null
    @Volatile private var lastSnapshotJpeg: ByteArray? = null
    @Volatile private var lastCutoffReason: String? = null
    @Volatile var statusText: String = "대기 중 (주행 중)"
        private set

    private val wakeKeeper = SentryWakeKeeper(app)
    private var sensorManager: SensorManager? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false

    private val imuListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            val e = event ?: return
            if (!armed || !SentryPreferences.impactEnabled(app)) return
            val gForce = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.80665f
            val deltaG = abs(gForce - 1.0f)
            val threshold = when (SentryPreferences.sensitivity(app)) {
                0 -> 0.55f
                2 -> 0.25f
                else -> 0.38f
            }
            if (deltaG >= threshold) {
                triggerEvent("충격 감지 (${"%.2f".format(Locale.US, deltaG)}G)")
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    fun isArmed(): Boolean = armed

    /** Called on ACC_OFF or 60s heartbeat alarm to keep Wi-Fi/CPU/MCU alive for Sentry & Telegram. */
    fun onWakePulse(fromAccOff: Boolean) {
        if (!SentryPreferences.enabled(app) || !SentryPreferences.keepAwakeOnOff(app)) {
            wakeKeeper.release("pulse_disabled")
            return
        }
        if (lastCutoffReason != null || insideSafeZoneName() != null) {
            wakeKeeper.release("pulse_cutoff_or_safezone")
            return
        }
        if (fromAccOff) { ignitionOff = true; cachedPowerLevel = 0 }
        if (armed || fromAccOff) {
            wakeKeeper.acquire(if (fromAccOff) "acc_off" else "heartbeat")
            if (armed) SentryWakeKeeper.scheduleHeartbeat(app)
        }
    }

    fun onVehicleFrame(frame: RawVehicleFrame) {
        val enabled = SentryPreferences.enabled(app)
        val now = frame.timestampMs
        val powerLv = pollPowerLevel(now)
        if (powerLv >= 2) ignitionOff = false
        val powerIsOff = (powerLv == 0) || ignitionOff
        val isParked = frame.gearRaw == 3 && (frame.speedKmH == null || frame.speedKmH <= 0.5f) && powerIsOff

        if (!enabled) {
            if (armed) disarm("disabled", announceBoarding = false)
            statusText = "센트리 OFF"
            return
        }

        if (!isParked) {
            val wasArmed = armed
            parkedSinceMs = 0L
            lastCutoffReason = null
            if (wasArmed) disarm("shifted_out_of_P", announceBoarding = true)
            else checkAndAnnounceBoardingIfPending()
            statusText = if (frame.gearRaw == 3) "시동 ON 대기 중 · 시동 OFF(주차) 시 자동 무장" else "주행 중 · 시동 OFF 주차 시 자동 무장"
            return
        }

        // Parked in P
        if (lastCutoffReason != null) {
            statusText = "보호 차단됨 ($lastCutoffReason)"
            return
        }

        if (!armed) {
            if (parkedSinceMs == 0L) parkedSinceMs = now
            // Wait 8s after shifting to P so driver can exit cleanly before arming
            if (now - parkedSinceMs < 5_000L) {
                statusText = "주차 확인 중 (${((5_000L - (now - parkedSinceMs)) / 1000L) + 1}초 후 무장)"
                return
            }
            val safeName = insideSafeZoneName()
            if (safeName != null) {
                statusText = "제외 구역($safeName) · 센트리 자동 일시중지"
                return
            }
            val battProblem = checkBatteryGuard()
            if (battProblem != null) {
                lastCutoffReason = battProblem
                statusText = "배터리 보호 차단 ($battProblem)"
                return
            }
            arm(now)
            return
        }

        // Already armed: check max duration & periodic 60s battery guard
        val maxMs = SentryPreferences.maxHours(app) * 3_600_000L
        if (now - armedSinceMs >= maxMs) {
            lastCutoffReason = "최대 감시 시간(${SentryPreferences.maxHours(app)}시간) 도달"
            disarm("max_duration", announceBoarding = false)
            return
        }
        if (now - lastBatteryCheckMs >= 60_000L) {
            lastBatteryCheckMs = now
            val battProblem = checkBatteryGuard()
            if (battProblem != null) {
                lastCutoffReason = battProblem
                disarm("low_battery", announceBoarding = false)
                statusText = "배터리 보호 차단 ($battProblem)"
                if (TelegramPreferences.notifyBatteryGuard(app)) {
                    TelegramNotifier.sendTextAsync(app, "🔋 센트리 배터리 보호 차단", "$battProblem 조건으로 센트리 감시를 안전 종료했습니다.")
                }
            }
        }
    }

    /** Receive 320x240 4-quadrant bitmap from SharedAvmSession; throttled to 2fps (500ms). */
    fun acceptQuadBitmap(bmp: Bitmap) {
        if (!armed) return
        val now = System.currentTimeMillis()
        if (now - lastMotionCheckMs < 480L) return
        if (warmupFramesRemaining > 0) { warmupFramesRemaining--; prevGrid = null; return }
        lastMotionCheckMs = now

        // Build 16x12 luma grid (192 cells covering all 4 AVM quadrants)
        val cols = 16
        val rows = 12
        val grid = IntArray(cols * rows)
        val stepX = (bmp.width / cols).coerceAtLeast(1)
        val stepY = (bmp.height / rows).coerceAtLeast(1)
        var meanLuma = 0
        for (r in 0 until rows) {
            val py = (r * stepY + stepY / 2).coerceAtMost(bmp.height - 1)
            for (c in 0 until cols) {
                val px = (c * stepX + stepX / 2).coerceAtMost(bmp.width - 1)
                val color = bmp.getPixel(px, py)
                val y = (Color.red(color) * 3 + Color.green(color) * 6 + Color.blue(color)) / 10
                grid[r * cols + c] = y
                meanLuma += y
            }
        }
        meanLuma /= grid.size

        val prev = prevGrid
        prevGrid = grid
        if (prev == null) return

        // Illumination-change filter: subtract global brightness delta so passing clouds/lights don't false-trigger
        var prevMean = 0
        for (v in prev) prevMean += v
        prevMean /= prev.size
        val globalDelta = meanLuma - prevMean
        if (abs(globalDelta) > 45) {
            motionStreak = 0
            return
        }

        val cellDiffThresh = when (SentryPreferences.sensitivity(app)) {
            0 -> 34
            2 -> 20
            else -> 26
        }
        val minChangedCells = when (SentryPreferences.sensitivity(app)) {
            0 -> 14
            2 -> 6
            else -> 9
        }
        var changedCells = 0
        for (i in grid.indices) {
            val localDelta = abs((grid[i] - prev[i]) - globalDelta)
            if (localDelta >= cellDiffThresh) changedCells++
        }

        if (changedCells in minChangedCells..135) {
            motionStreak++
            if (motionStreak >= 2) {
                motionStreak = 0
                lastSnapshotJpeg = TelegramNotifier.compressBitmapToJpeg(bmp)
                triggerEvent("주변 움직임 감지 (${changedCells}셀)")
            }
        } else {
            motionStreak = 0
        }
    }

    private fun arm(now: Long) {
        armed = true
        armedSinceMs = now
        lastBatteryCheckMs = now
        prevGrid = null
        motionStreak = 0
        wakeKeeper.acquire("sentry_armed")
        registerImu()
        SharedAvmSession.acquireSentry(app)
        statusText = "센트리 무장 중 · 4방향 감시 활성"
        CoreLog.i("SENTRY", "ARMED")
        if (TelegramPreferences.notifyIgnition(app)) {
            TelegramNotifier.sendTextAsync(app, "🅿️ 주차(P) · 센트리 무장", "주차 상태가 확인되어 4방향 센트리 감시를 시작했습니다.")
        }
    }

    private fun disarm(reason: String, announceBoarding: Boolean) {
        armed = false
        prevGrid = null
        motionStreak = 0
        unregisterImu()
        SharedAvmSession.releaseSentry()
        wakeKeeper.release(reason)
        CoreLog.i("SENTRY", "DISARMED reason=$reason")
        if (announceBoarding) checkAndAnnounceBoardingIfPending()
    }

    private fun triggerEvent(reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastTriggerMs < 22_000L) return
        lastTriggerMs = now
        val count = SentryPreferences.incrementUnseenEvents(app)
        statusText = "이벤트 녹화 중 ($reason · 누적 ${count}건)"
        CoreLog.i("SENTRY", "EVENT_TRIGGERED reason=$reason unseen=$count")
        onSentryEventTriggered(reason)
        if (TelegramPreferences.notifySentry(app)) {
            val snap = if (TelegramPreferences.notifySentryPhoto(app)) lastSnapshotJpeg else null
            TelegramNotifier.sendPhotoAsync(app, "🚨 센트리 경고: $reason (누적 ${count}건)", snap)
        }
        lastSnapshotJpeg = null
        if (SentryPreferences.warningScreenEnabled(app)) {
            SentryWarningActivity.launch(app, reason, 12_000L)
        }
    }

    private fun checkAndAnnounceBoardingIfPending() {
        val count = SentryPreferences.unseenEventCount(app)
        if (count <= 0) return
        SentryPreferences.clearUnseenEvents(app)
        if (!SentryPreferences.boardingVoiceEnabled(app)) return
        val phrase = if (count >= 100) "주차 중 센트리 녹화 백 건 이상이 있습니다."
        else "주차 중 센트리 녹화 ${count}건이 있습니다."
        speakKorean(phrase)
    }

    private fun speakKorean(text: String) {
        if (tts == null) {
            tts = TextToSpeech(app) { st ->
                ttsReady = (st == TextToSpeech.SUCCESS)
                if (ttsReady) {
                    tts?.language = Locale.KOREAN
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sentry_boarding")
                }
            }
        } else if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sentry_boarding")
        }
    }

    private fun insideSafeZoneName(): String? {
        val zones = SentryPreferences.safeZones(app)
        if (zones.isEmpty()) return null
        if (app.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            app.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val loc = runCatching {
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }.getOrNull() ?: return null
        val results = FloatArray(1)
        for (z in zones) {
            Location.distanceBetween(loc.latitude, loc.longitude, z.lat, z.lon, results)
            if (results[0] <= z.radiusM) return z.name
        }
        return null
    }

    /** Check 12V & HV battery safety floors via BYDAutoPowerDevice/StatisticDevice or BatteryManager. */
    private fun checkBatteryGuard(): String? {
        val min12v = SentryPreferences.min12vDeciVolts(app) / 10.0f
        val minHv = SentryPreferences.minHvPercent(app)

        // Probe BYD HV SOC if exposed
        val hvPct = runCatching {
            val cls = Class.forName("android.hardware.bydauto.statistic.BYDAutoStatisticDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, app)
            val m = cls.getMethod("getElecPercentageValue")
            (m.invoke(inst) as? Number)?.toDouble()?.let { v -> if (v <= 1.0) (v * 100.0).toInt() else v.toInt() }
        }.getOrNull()
        if (hvPct != null && hvPct in 1..100 && hvPct < minHv) {
            return "고전압 배터리 ${hvPct}% < 하한 ${minHv}%"
        }

        // Probe 12V via BatteryManager voltage fallback (mV) if reported on vehicle ROM
        val mv = runCatching {
            app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        }.getOrDefault(-1)
        if (mv in 9_000..16_000) {
            val volts = mv / 1000f
            if (volts < min12v) return "12V 배터리 ${"%.1f".format(Locale.US, volts)}V < 하한 ${"%.1f".format(Locale.US, min12v)}V"
        }
        return null
    }

    private fun registerImu() {
        val sm = app.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sensorManager = sm
        runCatching { sm.registerListener(imuListener, accel, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    private fun unregisterImu() {
        runCatching { sensorManager?.unregisterListener(imuListener) }
        sensorManager = null
    }

    fun shutdown() {
        disarm("shutdown", announceBoarding = false)
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
    }

    private fun pollPowerLevel(nowMs: Long): Int {
        if (nowMs - lastPowerPollMs < 2_000L) return cachedPowerLevel
        lastPowerPollMs = nowMs
        val lv = runCatching {
            val wrapped = BydPermissionContext.wrap(app)
            val cls = Class.forName("android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice")
            val dev = cls.getMethod("getInstance", Context::class.java).invoke(null, wrapped)
            (cls.getMethod("getPowerLevel").invoke(dev) as? Number)?.toInt()
        }.getOrNull()
        if (lv != null && lv in 0..3) cachedPowerLevel = lv
        return cachedPowerLevel
    }
}
