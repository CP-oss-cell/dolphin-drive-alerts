package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext

/**
 * Clean-Room Climate & Reverse-Hazard Automation Engine (v0.17.82):
 * 1. Cold/Hot Weather Auto-Climate: reads BYDAutoInstrumentDevice.getOutCarTemperature()
 *    (real-car verified on BYD Dolphin DiLink 5.0) and applies configured heating (HI=27°C)
 *    or cooling (LOW=17°C).
 * 2. After-Blow: runs PURE fresh-air ventilation (A/C compressor OFF + Heater OFF +
 *    setAcVentilationState(1) + OUTLOOP) for configured minutes on ACC_OFF, then shuts climate OFF.
 * 3. Reverse Hazard Light: R-gear continuous ON, R->N/D 10s hold (early-cancel on turn signal
 *    or speed >= 12 km/h), P/ACC_OFF immediate OFF. Uses real-car BYDAutoLightDevice
 *    DOUBLE_FLASH (960495667) / EMERGENCY (950009880) feature-set + BydPermissionContext.
 */
class ClimateAutomationController(context: Context) {
    private val app = context.applicationContext
    private val bydCtx = BydPermissionContext.wrap(app)
    private val comfort = BydComfortController(app)
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var acUsedThisTrip = false
    @Volatile private var weatherAutoAppliedTrip = false
    @Volatile private var afterBlowActive = false
    @Volatile private var hazardAppliedByUs = false
    @Volatile private var hazardUsedPulseBuffer = false
    @Volatile private var lastHazardPulseMs = 0L
    @Volatile private var lastTempCheckMs = 0L
    private var afterBlowWakeLock: PowerManager.WakeLock? = null

    @Volatile private var lastGearRaw: Int? = null
    private val afterBlowStopRunnable = Runnable { finishAfterBlow("timer_done") }
    private val hazardOffRunnable = Runnable { turnOffHazardNow("nd_10s_timer_done") }

    fun onVehicleFrame(frame: RawVehicleFrame, blinkerSide: Side = Side.UNKNOWN) {
        val now = frame.timestampMs
        val gear = frame.gearRaw
        val isReverse = gear == 1
        val isPark = gear == 3
        val isND = gear == 0 || gear == 2 // BYD Dolphin: 0=N, 1=R, 2=D, 3=P
        val isDrivingOrReady = gear in listOf(0, 1, 2)

        if (ClimateAutomationPreferences.reverseHazardEnabled(app)) {
            when {
                isReverse -> {
                    handler.removeCallbacks(hazardOffRunnable)
                    if (!hazardAppliedByUs) {
                        val (ok, detail) = setHazardLightsDetailed(true)
                        if (ok) {
                            hazardAppliedByUs = true
                            hazardUsedPulseBuffer = detail.startsWith("auto.setBuffer")
                            lastHazardPulseMs = now
                        }
                    } else if (hazardUsedPulseBuffer && now - lastHazardPulseMs >= 4_500L) {
                        lastHazardPulseMs = now
                        sendBydAutoHazardBuffer(22)
                    }
                }
                isPark -> {
                    if (hazardAppliedByUs) turnOffHazardNow("gear_P_immediate")
                }
                isND && hazardAppliedByUs -> {
                    val blinkerOn = blinkerSide == Side.LEFT || blinkerSide == Side.RIGHT
                    val speedUp = (frame.speedKmH ?: 0f) >= 12f
                    if (blinkerOn || speedUp) {
                        turnOffHazardNow(if (blinkerOn) "blinker_early_cancel" else "speed_12kmh_early_cancel")
                    } else if (lastGearRaw == 1) {
                        handler.removeCallbacks(hazardOffRunnable)
                        handler.postDelayed(hazardOffRunnable, 10_000L)
                        CoreLog.i("CLIMATE_AUTO", "HAZARD_HOLD_10S gear=$gear")
                    }
                }
            }
        } else if (hazardAppliedByUs) {
            turnOffHazardNow("feature_disabled")
        }
        lastGearRaw = gear

        if (afterBlowActive && isDrivingOrReady) {
            finishAfterBlow("driver_returned")
        }

        if (now - lastTempCheckMs >= 5_000L) {
            lastTempCheckMs = now
            val snap = comfort.refreshSnapshot()
            if (snap.acOn || snap.acCompressorOn) {
                acUsedThisTrip = true
            }
            if (isDrivingOrReady && !weatherAutoAppliedTrip) {
                weatherAutoAppliedTrip = true
                applyWeatherAutomation()
            }
        }
    }

    fun applyWeatherAutomation(): String {
        val outC = readOutsideTempC() ?: return "외기 온도 미수신 (적용 보류)"
        if (ClimateAutomationPreferences.coldAutoEnabled(app) && outC <= ClimateAutomationPreferences.coldThresholdC(app)) {
            if (ClimateAutomationPreferences.coldSteeringHeat(app)) comfort.setSteeringHeatDirect(true)
            val drv = ClimateAutomationPreferences.coldDriverSeat(app)
            if (drv > 0) comfort.setSeatHeatDirect(1, drv)
            val pas = ClimateAutomationPreferences.coldPassengerSeat(app)
            if (pas > 0) comfort.setSeatHeatDirect(2, pas)
            if (ClimateAutomationPreferences.coldHeaterHi(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(BydComfortController.MAX_TEMP_C) // 27°C = HI
                comfort.setHeaterDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.coldHeaterFan(app))
            }
            val msg = "추위 자동 난방 적용 (${outC.toInt()}°C ≤ ${ClimateAutomationPreferences.coldThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        if (ClimateAutomationPreferences.hotAutoEnabled(app) && outC >= ClimateAutomationPreferences.hotThresholdC(app)) {
            if (ClimateAutomationPreferences.hotAcLow(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(BydComfortController.MIN_TEMP_C) // 17°C = LOW
                comfort.setAcCompressorDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.hotAcFan(app))
                acUsedThisTrip = true
            }
            val msg = "더위 자동 냉방 적용 (${outC.toInt()}°C ≥ ${ClimateAutomationPreferences.hotThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        return "외기 ${outC.toInt()}°C · 기준 온도 범위 외 (자동 공조 대기)"
    }

    fun onIgnitionOff() {
        weatherAutoAppliedTrip = false
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
        if (ClimateAutomationPreferences.afterBlowEnabled(app) && acUsedThisTrip) {
            acUsedThisTrip = false
            startAfterBlow()
        }
    }

    fun startAfterBlow(forceTest: Boolean = false) {
        if (afterBlowActive) return
        if (!forceTest && !ClimateAutomationPreferences.afterBlowEnabled(app)) return
        val minutes = ClimateAutomationPreferences.afterBlowMinutes(app)
        val fan = ClimateAutomationPreferences.afterBlowFanLevel(app)
        afterBlowActive = true

        runCatching {
            val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
            afterBlowWakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Dolphin:AfterBlow")
                ?.apply { setReferenceCounted(false); acquire((minutes + 1) * 60_000L) }
        }

        // Pure fresh-air ventilation ONLY (A/C OFF + Heater OFF + Ventilation ON + OUTLOOP)
        comfort.startPureVentilation(fan)

        handler.removeCallbacks(afterBlowStopRunnable)
        handler.postDelayed(afterBlowStopRunnable, minutes * 60_000L)
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_STARTED minutes=$minutes fan=$fan forceTest=$forceTest")
    }

    private fun finishAfterBlow(reason: String) {
        if (!afterBlowActive) return
        afterBlowActive = false
        handler.removeCallbacks(afterBlowStopRunnable)
        if (reason == "timer_done") {
            comfort.setClimatePowerDirect(false)
        }
        runCatching { afterBlowWakeLock?.let { if (it.isHeld) it.release() } }
        afterBlowWakeLock = null
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_FINISHED reason=$reason")
    }

    private fun readOutsideTempC(): Float? {
        // 1. Primary real-car verified source: BYDAutoInstrumentDevice.getOutCarTemperature()
        runCatching {
            val cls = Class.forName("android.hardware.bydauto.instrument.BYDAutoInstrumentDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx)
            if (inst != null) {
                for (name in listOf("getOutCarTemperature", "getOutsideTemperature")) {
                    val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
                    val v = (m.invoke(inst) as? Number)?.toFloat()
                    if (v != null && v in -35f..60f) return v
                }
            }
        }
        // 2. Fallback: BYDAutoAcDevice
        return runCatching {
            val cls = Class.forName("android.hardware.bydauto.ac.BYDAutoAcDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx) ?: return@runCatching null
            for (name in listOf("getOutCarTemperature", "getOutSideTemperature", "getOutsideTemperature")) {
                val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
                val v = (m.invoke(inst) as? Number)?.toFloat()
                if (v != null && v in -35f..60f) return@runCatching v
            }
            null
        }.getOrNull()
    }

    private fun turnOffHazardNow(reason: String) {
        handler.removeCallbacks(hazardOffRunnable)
        if (hazardAppliedByUs) {
            if (!hazardUsedPulseBuffer) {
                setHazardLights(false)
            }
            hazardAppliedByUs = false
            hazardUsedPulseBuffer = false
            CoreLog.i("CLIMATE_AUTO", "HAZARD_OFF reason=$reason")
        }
    }

    /** One-tap 3-second hazard test from UI (works even in Park). */
    fun testHazardPulse(durationMs: Long = 3_000L): String {
        val (ok, detail) = setHazardLightsDetailed(true)
        if (ok) {
            if (!detail.startsWith("auto.setBuffer")) {
                handler.postDelayed({ setHazardLightsDetailed(false) }, durationMs)
            }
            return "비상등 점멸 성공 ($detail)"
        }
        return "비상등 제어 실패: $detail"
    }

    private fun findProtectedBaseSet(cls: Class<*>): java.lang.reflect.Method? {
        var cur: Class<*>? = cls
        while (cur != null) {
            val m = runCatching {
                cur!!.getDeclaredMethod("set", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
                    .apply { isAccessible = true }
            }.getOrNull()
            if (m != null) return m
            cur = cur.superclass
        }
        return null
    }

    private fun readDeviceType(inst: Any): Int {
        for (mName in listOf("getDevicetype", "getDeviceType", "getType")) {
            val v = runCatching { (inst.javaClass.getMethod(mName).invoke(inst) as? Number)?.toInt() }.getOrNull()
            if (v != null && v > 0) return v
        }
        return 1010
    }

    private fun setHazardLights(on: Boolean): Boolean = setHazardLightsDetailed(on).first

    /**
     * LinkLock real-car proven BYD Dolphin DiLink 3.0 hazard flash command:
     * context.getSystemService("auto").setBuffer(1034, 0xAA000004, byte[26] { [22] = 22 })
     */
    private fun sendBydAutoHazardBuffer(code: Int = 22): Pair<Boolean, String> = runCatching {
        val autoMgr = app.getSystemService("auto") ?: bydCtx.getSystemService("auto")
            ?: return@runCatching false to "auto_service=null"
        val buf = ByteArray(26)
        buf[22] = code.toByte()
        val m = autoMgr.javaClass.getMethod(
            "setBuffer",
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType,
            ByteArray::class.java
        )
        val rc = (m.invoke(autoMgr, 1034, -1442840572, buf) as? Number)?.toInt()
        if (rc != null && rc != -2147482648 && rc >= 0) {
            val info = "auto.setBuffer(1034, 0xAA000004, [22]=$code)=$rc"
            CoreLog.i("CLIMATE_AUTO", "HAZARD_BUFFER_OK $info")
            true to info
        } else {
            false to "auto.setBuffer rc=$rc"
        }
    }.getOrElse { e ->
        false to "auto.setBuffer:${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}:${e.cause?.message ?: e.message}"
    }

    private fun setHazardLightsDetailed(on: Boolean): Pair<Boolean, String> = runCatching {
        // 0. Priority 1 (LinkLock real-car proven on BYD Dolphin DiLink 3.0):
        //    auto.setBuffer(1034, 0xAA000004, byte[26]{[22]=22}) flashes hazard lights natively on the car.
        if (on) {
            val (bufOk, bufInfo) = sendBydAutoHazardBuffer(22)
            if (bufOk) return@runCatching true to bufInfo
        }
        val cls = Class.forName("android.hardware.bydauto.light.BYDAutoLightDevice")
        val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx)
            ?: return@runCatching false to "BYDAutoLightDevice=null"
        val bydState = if (on) 1 else 2 // Real-car verified: getDoubleFlashLightState 1=ON, 2=OFF
        val binState = if (on) 1 else 0
        val devType = readDeviceType(inst)

        // 1. Primary BYD DiLink 5.0 path (verified on Dolphin):
        //    Walk superclass hierarchy for protected AbsBYDAutoDevice.set(int devType, int featureId, int value)
        //    with DOUBLE_FLASH = 960495667 (0x39400033) and EMERGENCY = 950009880 (0x38a00018)
        val baseSet = findProtectedBaseSet(inst.javaClass)
        val errors = mutableListOf<String>()
        if (baseSet != null) {
            val attempts = listOf(
                960495667 to bydState,
                960495667 to binState,
                950009880 to bydState,
                950009880 to binState
            )
            for ((fid, v) in attempts) {
                val res = runCatching { (baseSet.invoke(inst, devType, fid, v) as? Number)?.toInt() }
                val code = res.getOrNull()
                if (code != null && code != -2147482648 && code >= 0) {
                    val info = "baseSet(dev=$devType, fid=$fid, val=$v)=$code"
                    CoreLog.i("CLIMATE_AUTO", "HAZARD_OK on=$on $info")
                    return@runCatching true to info
                }
                errors += "fid=$fid,v=$v->${code ?: res.exceptionOrNull()?.javaClass?.simpleName}"
            }
        } else {
            errors += "baseSet=MISSING"
        }

        // 2. Direct named setter fallback if present on firmware
        for (mName in listOf("setDoubleFlashLightState", "setHazardLightState", "setDoubleFlashState", "setWarningLightState")) {
            val m = runCatching { cls.getMethod(mName, Int::class.javaPrimitiveType) }.getOrNull()
            if (m != null) {
                val r = runCatching { (m.invoke(inst, if (mName.contains("DoubleFlashLight")) bydState else binState) as? Number)?.toInt() }.getOrNull()
                if (r == null || (r != -2147482648 && r >= 0)) {
                    val info = "$mName(on=$on)=$r"
                    CoreLog.i("CLIMATE_AUTO", "HAZARD_OK $info")
                    return@runCatching true to info
                }
            }
        }

        // 3. setLight / setLightState fallback
        for (mName in listOf("setLight", "setLightState")) {
            val m = runCatching { cls.getMethod(mName, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType) }.getOrNull()
            if (m != null) {
                val r = runCatching { (m.invoke(inst, 4, binState) as? Number)?.toInt() }.getOrNull()
                if (r == null || (r != -2147482648 && r >= 0)) {
                    val info = "$mName(4,$binState)=$r"
                    CoreLog.i("CLIMATE_AUTO", "HAZARD_OK $info")
                    return@runCatching true to info
                }
            }
        }
        // 4. Try BYDAutoBodyworkDevice baseSet fallback (some DiLink 3.0/5.0 builds route hazard via Bodywork)
        runCatching {
            val bCls = Class.forName("android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice")
            val bInst = bCls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx)
            val bSet = bInst?.let { findProtectedBaseSet(it.javaClass) }
            if (bInst != null && bSet != null) {
                val bDevType = readDeviceType(bInst)
                for ((fid, v) in listOf(960495667 to bydState, 950009880 to bydState)) {
                    val code = runCatching { (bSet.invoke(bInst, bDevType, fid, v) as? Number)?.toInt() }.getOrNull()
                    if (code != null && code != -2147482648 && code >= 0) {
                        val info = "bodywork.baseSet(dev=$bDevType, fid=$fid, val=$v)=$code"
                        CoreLog.i("CLIMATE_AUTO", "HAZARD_OK on=$on $info")
                        return@runCatching true to info
                    }
                }
            }
        }
        val errMsg = errors.joinToString("; ")
        CoreLog.w("CLIMATE_AUTO", "HAZARD_FAIL on=$on dev=$devType $errMsg")
        false to "BYD 차량 펌웨어에서 외부 앱 비상등 제어(BYDAUTO_LIGHT_SET)를 차단했습니다 ($errMsg)" 
    }.getOrElse { e ->
        val err = "${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}: ${e.cause?.message ?: e.message}"
        CoreLog.w("CLIMATE_AUTO", "HAZARD_EXCEPTION on=$on $err")
        false to err
    }

    fun shutdown() {
        finishAfterBlow("shutdown")
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
    }
}
