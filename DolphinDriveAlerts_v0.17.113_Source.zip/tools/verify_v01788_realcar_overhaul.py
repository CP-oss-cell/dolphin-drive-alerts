#!/usr/bin/env python3
"""Static verification for v0.17.88 real-car overhaul."""
import os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def read(rel): return open(os.path.join(ROOT, rel), "r", encoding="utf-8").read()

def check_balanced(rel):
    txt = read(rel)
    d = 0; s = False; lc = False; bc = False; i = 0; n = len(txt)
    while i < n:
        c = txt[i]; nx = txt[i+1] if i+1 < n else ""
        if lc:
            if c == "\n": lc = False
        elif bc:
            if c == "*" and nx == "/": bc = False; i += 1
        elif s:
            if c == "\\": i += 1
            elif c == '"': s = False
        else:
            if c == "/" and nx == "/": lc = True; i += 1
            elif c == "/" and nx == "*": bc = True; i += 1
            elif c == '"': s = True
            elif c == "{": d += 1
            elif c == "}": d -= 1; assert d >= 0, f"Unbalanced }} in {rel}"
        i += 1
    assert not s and d == 0, f"Unbalanced braces ({d}) or string in {rel}"

modified = [
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/GlLutDewarpRenderer.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/BsdCameraOverlayController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/SharedAvmSession.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/VehicleCameraHub.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/sentry/SentryMonitorController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/BydComfortController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockPreferences.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt",
]
for f in modified:
    check_balanced(f)

gl = read(modified[0])
assert "setDefaultBufferSize(5120, 960)" in gl and "frontLutTexId" in gl and "rotationDeg" in gl

bsd = read(modified[1])
assert "rotationDeg = BsdCameraPreferences.rotationDeg(app)" in bsd

vch = read(modified[3])
assert "Triple(1280, 720, 6_000_000)" in vch

sm = read(modified[4])
assert "pollPowerLevel" in sm and "warmupFramesRemaining" in sm

bcc = read(modified[5])
assert "Math.round(roundedHalf * 2.0f)" in bcc and "comfortExecutor" in bcc

dp = read(modified[6])
assert "getBoolean(KEY_RESERVE_SCREEN_SPACE, false)" in dp and "dockCoreOrder" in dp

fdc = read(modified[8])
assert "adjustTemp(-0.5f)" in fdc and "adjustTemp(0.5f)" in fdc
assert "(0 until 2).map" in fdc
assert "com.byd.carsettings" in fdc
assert "tactilePillBg" in fdc
assert "showReorderPopup" in fdc
assert "backdrop.addView(card" in fdc

ma = read(modified[9])
assert "screen.setPadding(dp(78), dp(14), dp(78), dp(22))" in ma
assert "UnifiedLogCapture.lastZip(this)" in ma

bg = read("app/build.gradle.kts")
m = re.search(r"versionCode\s*=\s*(\d+)", bg); assert m and int(m.group(1)) >= 114
print("VERIFY_V01788_PASS: All 10 modified files + real-car overhaul invariants verified.")
