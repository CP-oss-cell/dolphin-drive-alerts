#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node tools/test-youtube-mic-bridge.js
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
b=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
g=Path('app/build.gradle').read_text()
manifest=Path('app/src/main/AndroidManifest.xml').read_text()
checks={
 'voice prompt uses trusted origin': 'VoicePermissionPolicy.isTrustedOrigin(url)' in s and 'MHT_YOUTUBE_VOICE_SEARCH_0111' in s,
 'voice bridge injected on YouTube page finish': 'injectYouTubeMicBridge();' in s,
 'toolbar voice button is separate from scroller': 'toolbarRow.addView(separateVoiceButton' in s and 'toolbarRow.addView(toolsScroll' in s,
 'BACK holds physical key': 'event.startTracking();' in s and 'onKeyLongPress(int keyCode' in s,
 'Android14 back events': 'OnBackAnimationCallback' in s and 'onBackStarted(BackEvent event)' in s,
 'Android13 back fallback': 'systemBackCallback = this::back;' in s,
 'cancellation does not exit': 'setNegativeButton("취소", null)' in s,
 'mic permission has Android runtime check': 'Manifest.permission.RECORD_AUDIO' in s,
 'standalone audio stream prefetch': 'prefetchStream(visiblePageUrl, false)' in b,
 'same video handoff waits or reuses prefetched stream (canonical media ID)': 'isValidPrefetchedStream(url)' in b and 'mediaKey.equals(YouTubeStreamResolver.canonicalMediaKey(activeNativeUrl))' in b,
 'stream failure diagnostics': 'noteAudioStage("전환 실패", message)' in b and 'showAudioDiagnostics()' in s,
 'real native player owns playback': 'nativePlayer.play();' in b and 'nativePlayer.setMediaItem' in b,
 'foreground audio service permissions': 'FOREGROUND_SERVICE_MEDIA_PLAYBACK' in manifest,
 'updated version': "versionName '0.1.20'" in g and 'versionCode 21' in g,
}
for label, check in checks.items():
 assert check, label
print('PASS: v0.1.11 source wiring: %d checks'%len(checks))
PY
