#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text()
a=Path('app/src/main/java/app/mideumhanatube/android/BackgroundAudioService.java').read_text()
r=Path('app/src/main/java/app/mideumhanatube/android/YouTubeStreamResolver.java').read_text()
c=Path('app/src/main/java/app/mideumhanatube/android/ExtractionFailureClassifier.java').read_text()
j=Path('app/src/main/assets/cleaner.js').read_text()
b=Path('app/build.gradle').read_text()
w=Path('.github/workflows/MideumHanaTube_v0.1.20_Source.yml').read_text()
assert "versionName '0.1.20'" in b and 'versionCode 21' in b
assert 'MideumHanaTube_v0.1.20_Source.zip' in w and 'assembleDebug' in w
assert 'boolean startAudio = backgroundAudio && (!autoPip || !canAutoPip)' in s
assert 'boolean canAutoPip = autoPip && lastKnownVideoPlaying' in s
assert 'if (!exiting && !launchingNativeVideo && backgroundAudio && wasPlayingImmediatelyBeforeLeaving()' in s
assert 'VIDEO_RETURN_NATIVE_PAUSED' in a and 'nativePlayer.pause();' in a
assert 'DUAL_AUDIO_PREVENTED' in s and 'WEB_PLAY_TOOK_OVER' in s
assert 'nativeAudioActive && !activityBackgrounded ? 250 : 1200' in s
assert 'restartNativeAfterFailedReturn' in s
assert 'EXTRACT_BACKOFF' in a and 'FAILURE_RETRY_BACKOFF_MS = 20_000L' in a
assert 'EXTRACT_EXCEPTION_CLASS' in a and 'ExtractionFailureClassifier.safeClassName(error)' in a
assert 'LAST_HTTP_ERROR' in r and 'HttpFailure' in r and 'LAST_HTTP_ERROR.remove()' in r
assert 'HTTP_429' in c and 'NETWORK_TIMEOUT' in c
assert 'querySelectorAll(css)' in j
assert 'video.currentTime' not in j and '.playbackRate' not in j
assert 'MHT_KEYSTORE_BASE64' not in w and 'assembleRelease' not in w
print('v0.1.16 log-driven PIP / exclusive playback / extraction tests PASS')
PY
mkdir -p /tmp/mht_v0116_test
javac -encoding UTF-8 -d /tmp/mht_v0116_test \
 app/src/main/java/app/mideumhanatube/android/ExtractionFailureClassifier.java \
 tools/TestExtractionFailureClassifier.java
java -cp /tmp/mht_v0116_test app.mideumhanatube.android.TestExtractionFailureClassifier
node --check app/src/main/assets/cleaner.js
