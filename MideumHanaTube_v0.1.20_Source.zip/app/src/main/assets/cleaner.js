/* MideumHanaTube on-page promotional UI filter (best effort; no promise to remove in-stream ads). */
(function () {
  "use strict";
  if (!/(^|\.)youtube\.com$/i.test(location.hostname)) return;
  const styleId = "mideumhanatube-sponsored-style-v015";
  const selectors = [
    "ytm-promoted-sparkles-web-renderer", "ytm-promoted-video-renderer",
    "ytm-ad-slot-renderer", "ytm-companion-ad-renderer", "ytm-display-ad-renderer",
    "ytm-promoted-slot-renderer", "ytd-promoted-sparkles-text-search-renderer",
    "ytm-promoted-sparkles-text-search-renderer", "ytm-promoted-sparkles-text-search-renderer",
    "ytd-promoted-video-renderer", "ytd-promoted-sparkles-web-renderer",
    "ytd-display-ad-renderer", "ytd-ad-slot-renderer",
    "ytd-companion-slot-renderer", "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer", "ytd-statement-banner-renderer",
    "ytd-rich-item-renderer[is-ad]", ".ytp-ad-overlay-container",
    ".ytp-ad-image-overlay", "#player-ads", "#masthead-ad"
  ];
  function syncStyle() {
    const existing = document.getElementById(styleId);
    if (window.__CS_HIDE) {
      if (!existing) {
        const style = document.createElement("style");
        style.id = styleId;
        style.textContent = selectors.join(",") + "{display:none !important;visibility:hidden !important;}";
        (document.head || document.documentElement).appendChild(style);
      }
    } else if (existing) existing.remove();
  }
  syncStyle();
  function adVisible() {
    return !!document.querySelector('.ad-showing, .ytp-ad-player-overlay, ytm-ad-player, ytd-ad-slot-renderer');
  }
  function reportAdState() {
    // Anonymous best-effort detection, never a verified ad-block success count.
    const active=adVisible();
    if (active && !window.__MHT_AD_WAS_VISIBLE) {
      window.__MHT_AD_WAS_VISIBLE=true;
      try { prompt('MHT_AD_DETECTED_0120',''); } catch(e) {}
    } else if (!active) window.__MHT_AD_WAS_VISIBLE=false;
  }
  function reportSkip() {
    const now=Date.now();
    if (now-(window.__MHT_LAST_SKIP_REPORT||0)<2500) return;
    window.__MHT_LAST_SKIP_REPORT=now;
    try { prompt('MHT_AD_SKIP_CLICKED_0120',''); } catch(e) {}
  }
  function skipVisibleAd() {
    reportAdState();
    if (!window.__CS_SKIP) return;
    const selectors = [
      ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern", ".ytp-skip-ad-button",
      "button.ytp-ad-skip-button-modern", ".ytp-ad-skip-button-slot button",
      "button[aria-label*=\"Skip Ads\"]",
      "button[aria-label*=\"Skip ad\"]", "button[aria-label*=\"광고 건너뛰기\"]"
    ];
    // Only click visible buttons that are actually part of the player ad UI.
    // Never seek, accelerate or skip the actual video or creator sponsorship.
    for (const css of selectors) {
      const buttons = document.querySelectorAll(css);
      for (const button of buttons) {
        if (button && button.getClientRects().length && !button.disabled) {
          button.click();
          reportSkip();
          return;
        }
      }
    }
    // Mobile YouTube may use localized, unlabeled buttons. Only consider
    // extra candidates while the player explicitly reports an active ad.
    if (document.querySelector('.ad-showing, .ytp-ad-player-overlay')) {
      const buttons = document.querySelectorAll('button');
      for (const b of buttons) {
        const t = String(b.textContent || b.getAttribute('aria-label') || '').trim();
        if (b.getClientRects().length && /^(광고 건너뛰기|건너뛰기|Skip ads?|Skip Ad)$/i.test(t)) {
          b.click(); reportSkip(); return;
        }
      }
    }
  }
  if (!window.__MHT_SKIP_TIMER) {
    window.__MHT_SKIP_TIMER = setInterval(skipVisibleAd, 350);
    document.addEventListener("visibilitychange", skipVisibleAd);
    // SPA navigation doesn't always reload the document. Re-check injected CSS
    // if the site swaps <head> or its stylesheet nodes.
    window.__MHT_STYLE_TIMER = setInterval(syncStyle, 4000);
    document.addEventListener("yt-navigate-finish", function(){ syncStyle(); skipVisibleAd(); });
    document.addEventListener("yt-page-data-updated", function(){ syncStyle(); skipVisibleAd(); });
  }
})();
