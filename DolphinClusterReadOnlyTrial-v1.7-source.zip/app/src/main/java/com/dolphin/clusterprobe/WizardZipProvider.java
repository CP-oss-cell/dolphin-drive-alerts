package com.dolphin.clusterprobe;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Shares only a generated, redacted app-owned evidence ZIP. Never exposes vehicle paths or keys. */
public final class WizardZipProvider extends ContentProvider {
    public static final String AUTHORITY = "com.dolphin.clusterprobe.v15.wizard";
    public static final String FILE = "DolphinCluster-V1.7-AutoCapture.zip";
    public static final Uri URI = Uri.parse("content://"+AUTHORITY+"/"+FILE);
    private File file(Uri uri) throws FileNotFoundException {
        if (!URI.equals(uri)) throw new FileNotFoundException("invalid URI");
        File f = new File(new File(getContext().getCacheDir(), "wizard_reports"), FILE);
        if (!f.isFile() || !f.canRead()) throw new FileNotFoundException("no report");
        return f;
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){return "application/zip";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("read only");
        return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {
        try {
            File f = file(uri);
            String[] cols = projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor out=new MatrixCursor(cols);Object[] row=new Object[cols.length];
            for(int i=0;i<cols.length;i++) {
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i]=FILE;
                if(OpenableColumns.SIZE.equals(cols[i])) row[i]=f.length();
            }
            out.addRow(row);return out;
        } catch (FileNotFoundException e) {return null;}
    }
    @Override public Uri insert(Uri uri,ContentValues v){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String s,String[] a){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
