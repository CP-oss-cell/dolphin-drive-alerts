package com.dolphin.clusterprobe;

import java.util.*;
import java.util.regex.*;

/** Deterministic, conservative classification of shell text as CANDIDATES, never as verified cluster links. */
public final class CandidateParser {
    private static final Pattern TARGET=Pattern.compile("(?i)fission|cluster|byd|cell|surfaceflinger");
    private static final Pattern LIB=Pattern.compile("/(?:system|vendor)/lib64/[A-Za-z0-9_.+-]+\\.so");
    private CandidateParser(){}
    /** Return cluster/Fission processes first, not merely the first 3 from ps order. */
    public static List<String> processes(String output){
        LinkedHashMap<String,String> found=new LinkedHashMap<>();
        for(String line:output.split("\\r?\\n")) {
            if(!TARGET.matcher(line).find()) continue;
            String[] p=line.trim().split("\\s+");
            if(p.length>2 && p[1].matches("[0-9]{1,7}"))
                found.put(p[1],p[1]+"|"+clip(p[p.length-1],75));
        }
        List<String> ranked=new ArrayList<>(found.values());
        ranked.sort((a,b)->Integer.compare(priority(a),priority(b)));
        return ranked.size()>32 ? new ArrayList<>(ranked.subList(0,32)) : ranked;
    }
    private static int priority(String s){
        String k=s.toLowerCase(Locale.ROOT);
        if(k.contains("fission_service") || k.contains("fissiond")) return 0;
        if(k.contains("cluster") || k.contains("cell")) return 1;
        if(k.contains("surfaceflinger")) return 2;
        if(k.contains("byd")) return 3;
        return 4;
    }
    public static String displayDeviceCount(String dumpsysDisplay){
        Matcher m=Pattern.compile("(?m)^Display Devices: size=([0-9]+)\\s*$").matcher(dumpsysDisplay);
        return m.find()?m.group(1):"UNKNOWN";
    }
    public static List<String> libraries(String output){
        LinkedHashSet<String> found=new LinkedHashSet<>();
        for(String line:output.split("\\r?\\n")) {
            Matcher m=LIB.matcher(line);
            while(m.find()) {
                String path=m.group();
                if(TARGET.matcher(path).find() || path.toLowerCase(Locale.ROOT).contains("qt")) found.add(path);
            }
            if(found.size()>=24)break;
        }
        return new ArrayList<>(found);
    }
    public static List<String> displays(String a,String b){
        LinkedHashSet<String> found=new LinkedHashSet<>();
        for(String text:new String[]{a,b}) for(String line:text.split("\\r?\\n")) {
            if(TARGET.matcher(line).find() || Pattern.compile("(?i)physicaldisplay|displaydevice|displayinfo|virtualdisplay").matcher(line).find())
                found.add(clip(line.trim(),180));
            if(found.size()>=20)break;
        }
        return new ArrayList<>(found);
    }
    private static String clip(String s,int n){return s.length()>n?s.substring(0,n):s;}
}
