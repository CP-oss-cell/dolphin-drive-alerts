package com.dolphin.clusterprobe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Display;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Non-expert read-only cluster probe. No vehicle writes, root or arbitrary shell. */
public final class StageWizardActivity extends Activity {
    private static final int BG=Color.rgb(8,17,30), FG=Color.rgb(235,243,255), ACCENT=Color.rgb(255,208,128);
    private static final int REQ_SAVE=602;
    private static final String PREFS="cluster_probe_session";
    private static final String LOG="cluster-session.txt", NDJSON="cluster-events.jsonl";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<String> checks=new ArrayList<>();
    private volatile boolean busy=false, dead=false, collecting=false, connected=false;
    private LocalAdb adb;
    private TextView banner, details, progress;
    private Button startBtn, autoBtn, manualBtn, stopBtn, shareBtn;
    private String status="READY", started="", savedName="";
    private int observed=0, blocked=0, unknown=0, failures=0, processed=0, autoRuns=0;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        adb=new LocalAdb(getFilesDir());
        collecting=getPreferences(MODE_PRIVATE).getBoolean("collecting",false);
        started=getPreferences(MODE_PRIVATE).getString("started","");
        status=collecting?"INTERRUPTED_RESUMABLE":"READY";
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        banner=new TextView(this);banner.setTextColor(ACCENT);banner.setTextSize(21);
        banner.setPadding(dp(18),dp(14),dp(18),dp(4));banner.setText("돌핀 순정 계기판 · 자동 진단");root.addView(banner);
        TextView warning=new TextView(this);warning.setTextColor(Color.rgb(255,180,130));warning.setTextSize(13);
        warning.setPadding(dp(18),dp(0),dp(18),dp(9));
        warning.setText("정차·P단에서만 검사 | 읽기 전용 | 계기판·차량 신호 변경 없음");root.addView(warning);
        LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.HORIZONTAL);root.addView(a);
        startBtn=button(a,"① 로그 수집 시작",this::startCollection);
        autoBtn=button(a,"② 자동 테스트",this::runAutomatic);
        LinearLayout bRow=new LinearLayout(this);bRow.setOrientation(LinearLayout.HORIZONTAL);root.addView(bRow);
        manualBtn=button(bRow,"③ 수동 확인 항목",this::showManual);
        stopBtn=button(bRow,"④ 수집 종료 · ZIP 저장",this::finishCollection);
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.HORIZONTAL);root.addView(c);
        shareBtn=button(c,"ZIP 공유",this::share);
        progress=new TextView(this);progress.setTextColor(ACCENT);progress.setTextSize(16);
        progress.setPadding(dp(18),dp(10),dp(18),dp(5));root.addView(progress);
        ScrollView scroll=new ScrollView(this);details=new TextView(this);details.setTextColor(FG);details.setTextSize(15);
        details.setPadding(dp(18),dp(12),dp(18),dp(18));scroll.addView(details);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if(collecting){
            // Recovery is explicit; do not infer ADB connection or silently restart probes.
            record("INFO","resume","previous capture session reopened after Activity restart; ADB disconnected");
            details.setText("진행 중이던 수집 기록을 보존했습니다. 자동 테스트를 다시 누르거나 수집 종료를 눌러 ZIP을 저장하세요.");
        }else details.setText("사용 방법\n\n1. 로그 수집 시작\n2. 자동 테스트 버튼 한 번\n3. 안내에 나온 필요한 수동 확인만 진행\n4. 수집 종료: 다운로드 폴더에 ZIP 자동 생성\n5. ZIP 공유\n\n전문가용 PID·명령어·파일 경로를 입력할 필요가 없습니다.\n실제 5인치/5.4인치 패널 변경 기능은 아직 검증되지 않았습니다.");
        refresh();
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private Button button(LinearLayout row,String name,Runnable click){
        Button v=new Button(this);v.setText(name);v.setTextSize(15);v.setAllCaps(false);
        row.addView(v,new LinearLayout.LayoutParams(0,dp(62),1));v.setOnClickListener(x->{if(!busy)click.run();});return v;
    }
    private String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.KOREA).format(new Date());}
    private String stamp(){return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.ROOT).format(new Date());}
    private void refresh(){
        if(dead)return;
        progress.setText("상태: "+status+" · 자동검사 "+autoRuns+"회 | 조회 "+observed+" · 제한 "+blocked+" · 미확인 "+unknown+" · 오류 "+failures);
        startBtn.setEnabled(!busy&&!collecting);
        autoBtn.setEnabled(!busy&&collecting);
        manualBtn.setEnabled(!busy&&collecting);
        stopBtn.setEnabled(!busy&&collecting);
        shareBtn.setEnabled(!busy&&new File(new File(getCacheDir(),"wizard_reports"),WizardZipProvider.FILE).isFile());
    }
    private synchronized void startCollection(){
        if(collecting)return;
        try{
            // Retain interrupted data in an archive rather than silently discarding it.
            File old=new File(getFilesDir(),LOG);
            if(old.isFile())old.renameTo(new File(getFilesDir(),"previous-session-"+stamp()+".txt"));
            File events=new File(getFilesDir(),NDJSON);
            if(events.isFile())events.renameTo(new File(getFilesDir(),"previous-events-"+stamp()+".jsonl"));
            started=now();collecting=true;connected=false;status="COLLECTING";
            new File(new File(getCacheDir(),"wizard_reports"),WizardZipProvider.FILE).delete();
            observed=blocked=unknown=failures=processed=autoRuns=0;checks.clear();
            getPreferences(MODE_PRIVATE).edit().putBoolean("collecting",true).putString("started",started).apply();
            record("INFO","start","read-only capture started; no hidden background daemon");
            details.setText("로그 수집이 시작됐습니다.\n\n이제 '자동 테스트'를 한 번 누르세요.\nADB 허용창이 나타나면 화면에서 직접 '허용'을 누르는 것만 필요합니다.");
        }catch(Exception e){status="START_ERROR";details.setText("수집 준비 실패: "+e.getMessage());}refresh();
    }
    private void setStep(String step){runOnUiThread(()->{if(!dead){details.setText(step);progress.setText("자동 검사 "+processed+"단계 진행 중\n"+step);}});}
    private void runAutomatic(){
        if(!collecting||busy)return;
        busy=true;status="AUTO_RUNNING";refresh();
        worker.execute(()->{
            try{
                autoRuns++; record("INFO","auto-run","자동검사 "+autoRuns+"회 시작 (기존 로그 유지)");
                setStep("기기 정보와 센터 디스플레이 조회");
                StringBuilder basic=new StringBuilder("Android "+Build.VERSION.RELEASE+" / SDK "+Build.VERSION.SDK_INT+" / 모델 "+Build.MODEL+"\n");
                DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
                if(dm!=null)for(Display d:dm.getDisplays()){
                    DisplayMetrics metrics=new DisplayMetrics();d.getRealMetrics(metrics);
                    basic.append("Display ").append(d.getDisplayId()).append(": ").append(metrics.widthPixels).append("x").append(metrics.heightPixels).append(" dpi=").append(metrics.densityDpi).append("\n");
                }
                record("OBSERVED","android-display",basic.toString());step("기본 환경 읽기",true);
                setStep("로컬 ADB 연결/인증 확인 (최대 2회)\n승인창이 뜨면 '허용'을 누르세요.");
                try{adb.connectSession(s->record("AUTH","adb-status",s));connected=true;
                    record("OBSERVED","adb","127.0.0.1:5555 local session authorized");step("로컬 ADB",true);
                }catch(Exception ex){connected=false;record("BLOCKED","adb","ADB unavailable: "+ex.getClass().getSimpleName()+"; cannot query protected routes; no bypass attempted");step("로컬 ADB",false);}
                if(connected){
                    setStep("Fission 서비스·계기판 파일·권한 조사");
                    for(String[] item:new String[][]{
                        {"shell-identity","id"},
                        {"fissiond","getprop init.svc.fissiond"},
                        {"FissionHostSvc","getprop init.svc.FissionHostSvc"},
                        {"single-os","getprop ro.build.system.fission_single_os"},
                        {"vehicle-type","getprop ro.vehicle.type"},
                        {"rcc-themes","ls -l /system/lib64/cluster_theme1.rcc /system/lib64/cluster_theme2.rcc"},
                        {"fission-files","ls -l /system/bin/fissiond /system/bin/fission_service /system/lib64/libfission_services.so"},
                        {"clu-size-permission","ls -l /sys/module/max96745/parameters/clu_size"},
                        {"clu-size-read","cat /sys/module/max96745/parameters/clu_size"},
                        {"cell-device","ls -l /dev/cells"}
                    }) {safeQuery(item[0],item[1]);processed++;}
                    setStep("실행 중인 프로세스 자동 분석");
                    // Parse complete ps output in memory; export only relevant lines, not a clipped head
                    // that can hide the actual fission_service process.
                    String ps;
                    try { ps=adb.queryReadOnly("ps -A").replace('\0',' ').trim(); }
                    catch(Exception ex) { ps="[READ_FAILED] "+ex.getClass().getSimpleName(); }
                    List<String> candidates=CandidateParser.processes(ps);
                    if(ps.contains("[READ_FAILED]")||ps.toLowerCase(Locale.ROOT).contains("permission denied"))
                        record("BLOCKED","process-list","PID 열람 제한; 후보 0개가 프로세스 부재를 뜻하지 않음");
                    else record("OBSERVED","process-candidates",candidates.toString());
                    processed++;
                    record("INFO","candidate-count","relevant matching processes="+candidates.size()+"; priority=fission > cluster > surface > byd; inspection up to 3");
                    int count=0;
                    for(String candidate:candidates){
                        if(count>=3)break;
                        String[] parts=candidate.split("\\|",2);
                        if(parts.length!=2||!parts[0].matches("[0-9]{1,7}"))continue;
                        String pid=parts[0];
                        setStep("프로세스 "+(++count)+"/3 검사: "+parts[1]);
                        safeQuery("exe-pid-"+pid,"readlink /proc/"+pid+"/exe");
                        safeQuery("cmd-pid-"+pid,"cat /proc/"+pid+"/cmdline");
                        String maps=safeQuery("maps-pid-"+pid,"cat /proc/"+pid+"/maps");
                        List<String> libs=CandidateParser.libraries(maps);
                        record("INFO","library-candidates-"+pid,libs.toString());
                        for(int j=0;j<Math.min(3,libs.size());j++)safeQuery("mapped-lib-"+pid,"ls -l "+libs.get(j));
                        processed++;
                    }
                    if(count==0)record("BLOCKED","proc-mapping","no readable matching PID; not evidence of absent cluster");
                    setStep("화면 및 레이어 단서 자동 수집");
                    String displays=safeQuery("display-service","dumpsys display");processed++;
                    String layers=safeQuery("surface-layers","dumpsys SurfaceFlinger --list");processed++;
                    record("INFO","display-candidates",CandidateParser.displays(displays,layers).toString());
                    // Android DisplayManager is not proof of the separate instrument-cluster path.
                    String deviceCount=CandidateParser.displayDeviceCount(displays);
                    record("INFO","android-display-summary","Android Display Devices="+deviceCount+
                        "; 5.4-inch OEM instrument-cluster link NOT VERIFIED by this query");
                }else{
                    record("BLOCKED","adb-dependent-tests","Fission/PID/maps/Qt/RCC/Display shell tests skipped because authorization unavailable");
                }
                status="AUTO_COMPLETED_READ_ONLY";
                record("GATE","safety","READ_ONLY_COMPLETE; OEM_CLUSTER_PANEL_MAPPING=UNVERIFIED; VEHICLE_WRITES=NONE");
                final String summary="자동 테스트가 끝났습니다.\n\n확인 가능한 항목: "+observed+"\n권한·경로 제한: "+blocked+"\n미확인: "+unknown+"\n오류: "+failures
                    +"\n\n권한·경로가 막힌 것은 성공으로 표시하지 않았습니다.\n\n이제 '수동 확인 항목'에서 필요한 것만 체크한 후 '수집 종료'를 누르세요.\n\n주의: 순정 계기판에 테마 적용·CAN/SPI 송신을 시도하지 않았습니다.";
                runOnUiThread(()->{if(!dead)details.setText(summary);});
            }catch(Exception ex){status="AUTO_PARTIAL";record("ERROR","automation",ex.getClass().getSimpleName()+": "+ex.getMessage());
                runOnUiThread(()->{if(!dead)details.setText("자동 검사가 일부 중단되었습니다. 지금도 로그를 ZIP으로 저장할 수 있습니다.\n"+ex.getClass().getSimpleName());});
            }finally{busy=false;runOnUiThread(this::refresh);}
        });
    }
    private void step(String name,boolean ok){processed++;record(ok?"INFO":"BLOCKED","stage",name+(ok?" observed":" blocked"));}
    private String safeQuery(String label,String cmd){
        try{
            String r=adb.queryReadOnly(cmd).replace('\0',' ').trim();
            String lc=r.toLowerCase(Locale.ROOT);
            boolean deny=lc.contains("permission denied")||lc.contains("permission denial")||lc.contains("not permitted")||lc.contains("(timeout)")||lc.contains("[read_failed]");
            String state=deny?"BLOCKED":(r.length()==0||lc.contains("no such file or directory")||lc.contains("not found")?"UNKNOWN":"OBSERVED");
            record(state,label,clip(r,7000));return r;
        }catch(Exception ex){record("BLOCKED",label,ex.getClass().getSimpleName()+": "+ex.getMessage());return "[READ_FAILED] "+ex.getClass().getSimpleName();}
    }
    private void showManual(){
        if(!collecting)return;
        String[] choices={"순정 계기판 기본 화면 정상", "순정 계기판 표시 이상 발견", "직접 확인하지 못함"};
        new AlertDialog.Builder(this).setTitle("직접 해야 하는 확인만 선택")
            .setMessage("반드시 정차·P단에서만 확인하세요.\n\n① 계기판 기본 화면이 정상인지 확인\n② 눈에 보이는 이상이 있다면 '표시 이상' 선택\n③ 확신할 수 없으면 '확인하지 못함' 선택\n\nADB 승인은 자동 검사 도중 요청될 때만 화면에서 허용하면 됩니다. PID·명령어 입력은 필요 없습니다.")
            .setItems(choices,(d,which)->{
                String result=choices[which];record("MANUAL","user-confirmed",result);
                details.setText("수동 확인 결과 저장: "+result+"\n\n이제 '수집 종료 · ZIP 저장'을 누르세요.");
                refresh();
            }).setNegativeButton("닫기",null).show();
    }
    private void finishCollection(){
        if(!collecting||busy)return;
        busy=true;status="SAVING";refresh();
        worker.execute(()->{
            String message;
            try{
                record("INFO","stop","capture closed; exports are read-only snapshots");
                collecting=false;getPreferences(MODE_PRIVATE).edit().putBoolean("collecting",false).apply();
                status="COLLECTED_UNVERIFIED";
                File report=createZip();
                if(Build.VERSION.SDK_INT>=29){
                    savedName="DolphinCluster_"+stamp()+".zip";
                    Uri dest=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME,savedName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,"application/zip");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/");
                    values.put(MediaStore.MediaColumns.IS_PENDING,1);
                    Uri uri=getContentResolver().insert(dest,values);
                    if(uri==null)throw new IOException("Downloads insert returned null");
                    try{
                        try(InputStream in=new FileInputStream(report);OutputStream out=getContentResolver().openOutputStream(uri)){
                            if(out==null)throw new IOException("Downloads stream unavailable");byte[] buffer=new byte[8192];int count;
                            while((count=in.read(buffer))!=-1)out.write(buffer,0,count);
                        }
                        ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
                        getContentResolver().update(uri,ready,null,null);
                    }catch(Exception e){getContentResolver().delete(uri,null,null);throw e;}
                    status="ZIP_SAVED";message="로그 수집 종료\n\n다운로드 폴더에 ZIP 저장 완료\n파일: "+savedName+"\n\n이제 'ZIP 공유' 버튼을 누르세요.\n차량 제어 동작은 전혀 수행하지 않았습니다.";
                }else{
                    status="SAVE_PICKER_REQUIRED";message="Android 9 이하에서는 폴더 접근 권한 대신 저장 위치 선택창을 사용합니다.\n위치: 다운로드 폴더 선택";
                    runOnUiThread(()->{Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/zip");intent.putExtra(Intent.EXTRA_TITLE,"DolphinCluster_"+stamp()+".zip");
                        startActivityForResult(intent,REQ_SAVE);});
                }
            }catch(Exception ex){status="ZIP_SAVE_ERROR";record("ERROR","downloads-export",ex.getClass().getSimpleName()+": "+ex.getMessage());
                message="수집은 종료됐지만 Downloads 저장에 실패했습니다.\n"+ex.getMessage()+"\n\n'ZIP 공유'로 생성된 파일을 전달할 수 있습니다.";}
            final String display=message;
            busy=false;runOnUiThread(()->{if(!dead){details.setText(display);refresh();}});
        });
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=REQ_SAVE||result!=RESULT_OK||data==null||data.getData()==null)return;
        try{
            File file=new File(new File(getCacheDir(),"wizard_reports"),WizardZipProvider.FILE);
            try(InputStream in=new FileInputStream(file);OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
                if(out==null)throw new IOException("No target stream");byte[] buffer=new byte[8192];int n;
                while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            }
            status="ZIP_SAVED";details.setText("선택한 다운로드 위치에 ZIP 저장 완료. 'ZIP 공유'를 눌러 전달하세요.");refresh();
        }catch(Exception ex){status="ZIP_SAVE_ERROR";details.setText("ZIP 저장 실패: "+ex.getMessage());refresh();}
    }
    private void share(){
        if(busy)return;
        File file=new File(new File(getCacheDir(),"wizard_reports"),WizardZipProvider.FILE);
        if(!file.isFile()){details.setText("먼저 수집 종료 버튼을 누르세요.");return;}
        new AlertDialog.Builder(this).setTitle("계기판 진단 ZIP 공유")
            .setMessage("프로세스 정보와 시스템 빌드 정보가 포함될 수 있습니다. 공유 대상을 확인하세요.\nVIN·ADB 개인키·시스템 파일 원본은 의도적으로 수집하지 않습니다.")
            .setPositiveButton("공유",(d,w)->{
                Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/zip");
                i.putExtra(Intent.EXTRA_STREAM,WizardZipProvider.URI);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(ClipData.newUri(getContentResolver(),"계기판 진단",WizardZipProvider.URI));
                try{startActivity(Intent.createChooser(i,"ZIP 공유"));}catch(Exception ex){details.setText("공유 앱을 열 수 없습니다. 다운로드 폴더의 ZIP을 사용하세요.");}
            }).setNegativeButton("취소",null).show();
    }
    private File createZip()throws Exception{
        File folder=new File(getCacheDir(),"wizard_reports");if(!folder.isDirectory()&&!folder.mkdirs())throw new IOException("report folder failed");
        File dest=new File(folder,WizardZipProvider.FILE);
        JSONObject summary=new JSONObject();summary.put("schema","DolphinClusterReadOnlyV1.7");
        summary.put("automatic_runs",autoRuns);
        summary.put("started_at",started);summary.put("ended_at",now());summary.put("status",status);
        summary.put("observed",observed);summary.put("blocked",blocked);summary.put("unknown",unknown);summary.put("errors",failures);
        summary.put("adb_authorized_this_activity",connected);
        summary.put("oem_cluster_panel_mapping_verified",false);
        summary.put("oem_theme_write_permitted",false);
        summary.put("oem_vehicle_writes_executed",false);
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(dest))){
            writeZip(z,"summary.json",summary.toString(2));
            writeZip(z,"diagnostics.txt",loadFile(LOG));
            writeZip(z,"events.jsonl",loadFile(NDJSON));
            writeZip(z,"MANUAL_CHECK_KO.txt","정차·P단에서만 확인: 순정 계기판 기본 표시 정상 여부.\nADB 승인은 자동 검사 도중 요청될 때만 직접 허용.\n계기판 테마 변경·차량 송신은 미실행.\n");
            writeZip(z,"README_KO.txt","BYD Dolphin 순정 계기판 읽기 전용 자동진단 V1.7.\n상태 OBSERVED는 정보 조회를 뜻하며 5인치 패널 출력·테마 변경 성공을 뜻하지 않습니다.\nBLOCKED는 인증/권한 제한, ERROR는 예외입니다. 차량을 정차시키고 검증하세요.\n");
        }
        return dest;
    }
    private void writeZip(ZipOutputStream z,String name,String body)throws IOException{
        z.putNextEntry(new ZipEntry(name));z.write(body.getBytes(StandardCharsets.UTF_8));z.closeEntry();
    }
    private String loadFile(String name)throws IOException{
        File f=new File(getFilesDir(),name);if(!f.isFile())return "";
        if(f.length()>950000)return "[LOG_SIZE_LIMIT]";
        try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            return out.toString("UTF-8");
        }
    }
    private synchronized void record(String state,String key,String value){
        if(dead||!collecting&&!(state.equals("ERROR")&&key.equals("downloads-export")))return;
        String clipped=clip(value,7000);String time=now();
        if("OBSERVED".equals(state))observed++;else if("BLOCKED".equals(state))blocked++;else if("UNKNOWN".equals(state))unknown++;else if("ERROR".equals(state))failures++;
        String human="["+time+"] "+state+" / "+key+"\n"+clipped+"\n";
        try{
            appendFile(LOG,human);
            JSONObject json=new JSONObject();json.put("time",time);json.put("status",state);json.put("item",key);json.put("result",clipped);
            appendFile(NDJSON,json.toString()+"\n");
        }catch(Exception e){status="LOG_WRITE_ERROR";}
    }
    private void appendFile(String name,String s)throws IOException{
        File file=new File(getFilesDir(),name);
        if(file.length()>900000)return;
        try(OutputStream out=openFileOutput(name,MODE_APPEND)){out.write(s.getBytes(StandardCharsets.UTF_8));}
    }
    private static String clip(String s,int n){if(s==null)return "";return s.length()>n?s.substring(0,n)+" [TRUNCATED]":s;}
    @Override protected void onDestroy(){dead=true;worker.shutdownNow();try{adb.close();}catch(Exception ignored){}super.onDestroy();}
}
