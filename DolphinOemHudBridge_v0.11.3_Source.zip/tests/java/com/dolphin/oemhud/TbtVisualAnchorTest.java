package com.dolphin.oemhud;

public final class TbtVisualAnchorTest {
    private static int passed = 0;

    private static void ok(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        passed++;
        System.out.println("PASS ANCHOR " + name);
    }

    public static void main(String[] args) {
        TbtVisualAnchor.clear();
        ok(TbtVisualAnchor.isValidArrowRect(20, 20, 120, 120), "100x100 arrow valid");
        ok(!TbtVisualAnchor.isValidArrowRect(0, 0, 10, 10), "tiny icon rejected");
        ok(!TbtVisualAnchor.isValidArrowRect(0, 0, 800, 500), "map view rejected");
        ok(!TbtVisualAnchor.isValidArrowRect(0, 0, 200, 40), "wide banner rejected");

        int[][] candidates = {
            new int[]{900, 500, 1000, 600}, // far away unrelated icon
            new int[]{30, 30, 120, 120},    // co-located TBT arrow next to distance
            new int[]{0, 0, 1280, 720}      // full screen map
        };
        int chosen = TbtVisualAnchor.selectBestArrow(140, 40, 280, 110, candidates);
        ok(chosen == 1, "selects co-located arrow next to distance");

        int[][] farOnly = { new int[]{800, 400, 900, 500} };
        ok(TbtVisualAnchor.selectBestArrow(20, 20, 140, 80, farOnly) == -1, "rejects distant arrow");

        TbtVisualAnchor.Snapshot snap = new TbtVisualAnchor.Snapshot(
            "com.tmap.auto.byd", 300, 140, 40, 280, 110, 30, 30, 120, 120, 5000L);
        TbtVisualAnchor.update(snap);
        ok(TbtVisualAnchor.getFresh("com.tmap.auto.byd", 7999L) != null, "fresh within 3s");
        ok(TbtVisualAnchor.getFresh("com.tmap.auto.byd", 8000L) == null, "expired at 3s");
        ok(TbtVisualAnchor.getFresh("com.skt.tmap.ku", 6000L) == null, "package mismatch rejected");
        TbtVisualAnchor.clear();
        ok(TbtVisualAnchor.getLatest() == null, "clear resets anchor");

        System.out.println("TBT VISUAL ANCHOR TESTS: " + passed + " PASS");
    }
}
