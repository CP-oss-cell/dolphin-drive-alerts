import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 99" in gr and 'versionName = "0.17.73"' in gr
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)

for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        txt = read(rel)
        assert len(txt) > 50, f"Empty/truncated Kotlin file: {rel}"
        clean = strip_kt(txt)
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

main = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
assert "블랙박스 · 센트리 · 카메라" in main
assert "dashcamCameraCards(accent)" in main
assert "DashcamViewerActivity::class.java" in main
assert "SentrySettingsActivity::class.java" in main
assert "TelegramSettingsActivity::class.java" in main
print("V01773_DEDICATED_DASHCAM_MENU_AND_ALL_STATIC_GATES_PASS")
