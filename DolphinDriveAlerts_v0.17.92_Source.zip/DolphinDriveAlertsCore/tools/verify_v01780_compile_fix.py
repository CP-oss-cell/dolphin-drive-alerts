#!/usr/bin/env python3
"""Regression guard for v0.17.80 (vc 106):
1. Rejects any unescaped newline inside single-line double-quoted string literals across ALL .kt files.
2. Verifies MainActivity.kt private fun addPanel(...) declaration syntax and runtime permission panel placement inside permissionAdbCards().
3. Verifies VehicleCameraHub.kt checkFormatPermission() uses escaped \n.
4. Verifies versionName 0.17.80 / versionCode 106 consistency.
"""
import glob, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def check_unclosed_strings():
    kt_files = sorted(glob.glob(os.path.join(ROOT, "app/src/main/java/**/*.kt"), recursive=True))
    assert len(kt_files) >= 140, f"Unexpected .kt file count: {len(kt_files)}"
    issues = []
    for path in kt_files:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        in_block_comment = False
        in_raw_string = False
        for idx, line in enumerate(lines, 1):
            i = 0
            n = len(line)
            in_str = False
            while i < n:
                if in_block_comment:
                    if line[i:i+2] == "*/":
                        in_block_comment = False
                        i += 2
                        continue
                    i += 1
                    continue
                if in_raw_string:
                    if line[i:i+3] == '"""':
                        in_raw_string = False
                        i += 3
                        continue
                    i += 1
                    continue
                if not in_str:
                    if line[i:i+2] == "//":
                        break
                    if line[i:i+2] == "/*":
                        in_block_comment = True
                        i += 2
                        continue
                    if line[i:i+3] == '"""':
                        in_raw_string = True
                        i += 3
                        continue
                    if line[i] == "'":
                        i += 1
                        if i < n and line[i] == "\\":
                            i += 2
                        else:
                            i += 1
                        if i < n and line[i] == "'":
                            i += 1
                        continue
                    if line[i] == '"':
                        in_str = True
                        i += 1
                        continue
                    i += 1
                else:
                    if line[i] == "\\":
                        i += 2
                        continue
                    if line[i] == '"':
                        in_str = False
                        i += 1
                        continue
                    i += 1
            if in_str:
                issues.append(f"{os.path.relpath(path, ROOT)}:{idx}: {line.rstrip()}")
    if issues:
        raise AssertionError("Unescaped newline in single-line string literal:\n" + "\n".join(issues))
    print(f"[PASS] All {len(kt_files)} Kotlin files have zero unclosed single-line string literals.")

def check_main_activity():
    p = os.path.join(ROOT, "app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
    with open(p, "r", encoding="utf-8") as f:
        s = f.read()
    expected_decl = "    private fun addPanel(\n        title: String,"
    assert expected_decl in s, "MainActivity.kt private fun addPanel declaration is corrupted!"
    perm_idx = s.index("private fun permissionAdbCards(accent: Int)")
    panel_idx = s.index('addPanel("필수 앱 권한 즉시 승인 (카메라 · 위치 · 저장소)"')
    assert panel_idx > perm_idx, "Runtime permission panel is not placed inside permissionAdbCards()!"
    assert '?: "0.17.80"' in s, "MainActivity.kt version fallback is not 0.17.80!"
    print("[PASS] MainActivity.kt addPanel declaration and permissionAdbCards() placement verified.")

def check_vehicle_camera_hub():
    p = os.path.join(ROOT, "app/src/main/java/com/byd/dolphin/drivealerts/camera/VehicleCameraHub.kt")
    with open(p, "r", encoding="utf-8") as f:
        s = f.read()
    assert '저장소 쓰기 권한 없음: ${root.absolutePath}\\nUSB/SD카드는' in s, "VehicleCameraHub.kt newline escape missing!"
    print("[PASS] VehicleCameraHub.kt checkFormatPermission() string verified.")

def check_version():
    g = open(os.path.join(ROOT, "app/build.gradle.kts"), encoding="utf-8").read()
    assert "versionCode = 106" in g and 'versionName = "0.17.80"' in g
    wf = open(os.path.join(ROOT, ".github/workflows/DolphinDriveAlerts_v0.17.80_Source.yml"), encoding="utf-8").read()
    assert "SOURCE_ZIP: DolphinDriveAlerts_v0.17.80_Source.zip" in wf
    print("[PASS] Version 0.17.80 (versionCode 106) and workflow verified.")

if __name__ == "__main__":
    check_unclosed_strings()
    check_main_activity()
    check_vehicle_camera_hub()
    check_version()
    print("ALL v0.17.80 VERIFICATIONS PASSED!")
