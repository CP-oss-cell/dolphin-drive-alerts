#!/usr/bin/env python3
"""Static verification for v0.17.83 (Dock Overscan Screen Reservation + First-Position Recent Apps)."""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def read(rel):
    with open(os.path.join(ROOT, rel), "r", encoding="utf-8") as f:
        return f.read()

def check_balanced_braces(rel):
    txt = read(rel)
    depth = 0
    in_str = False
    in_line_comment = False
    in_block_comment = False
    i = 0
    n = len(txt)
    while i < n:
        c = txt[i]
        nxt = txt[i+1] if i+1 < n else ""
        if in_line_comment:
            if c == "\n":
                in_line_comment = False
        elif in_block_comment:
            if c == "*" and nxt == "/":
                in_block_comment = False
                i += 1
        elif in_str:
            if c == "\\":
                i += 1
            elif c == '"':
                in_str = False
        else:
            if c == "/" and nxt == "/":
                in_line_comment = True
                i += 1
            elif c == "/" and nxt == "*":
                in_block_comment = True
                i += 1
            elif c == '"':
                in_str = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                assert depth >= 0, f"Unbalanced closing brace in {rel}"
        i += 1
    assert not in_str, f"Unclosed string in {rel}"
    assert depth == 0, f"Unbalanced braces ({depth}) in {rel}"

files = [
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockPreferences.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt",
]
for f in files:
    check_balanced_braces(f)

dp = read(files[0])
assert "KEY_RESERVE_SCREEN_SPACE" in dp and "fun reserveScreenSpace" in dp

di = read(files[1])
assert "RECENTS," in di and "Kind.RECENTS ->" in di

fdc = read(files[2])
assert "FLAG_LAYOUT_IN_OVERSCAN" in fdc
assert "wm overscan $targetSpec" in fdc
assert "wm overscan reset" in fdc
assert "GLOBAL_ACTION_RECENTS" in fdc
assert "input keyevent 187" in fdc
assert "overscanExecutor" in fdc
idx_recents = fdc.index("DockIcons.Kind.RECENTS")
idx_collapse = fdc.index("DockIcons.Kind.COLLAPSE")
assert idx_collapse < idx_recents, "COLLAPSE must be the very first icon tile before RECENTS (v0.17.88)"

dbs = read(files[3])
assert "DockPreferences.reserveScreenSpace" in dbs

bg = read("app/build.gradle.kts")
import re; m = re.search(r"versionCode\s*=\s*(\d+)", bg); assert m and int(m.group(1)) >= 109

print("VERIFY_V01783_PASS: Overscan screen reservation + First-position Recent Apps + Gradle v0.17.83 (109) verified.")
