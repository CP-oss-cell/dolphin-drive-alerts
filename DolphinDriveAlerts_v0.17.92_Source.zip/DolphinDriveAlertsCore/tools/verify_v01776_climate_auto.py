import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 102" in gr and 'versionName = "0.17.76"' in gr
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)
assert "ClimateAutomationActivity" in mf and "BYDAUTO_LIGHT_SET" in mf

for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        txt = read(rel)
        assert len(txt) > 50, f"Empty file: {rel}"
        clean = strip_kt(txt)
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

ca = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/ClimateAutomationController.kt")
assert "startAfterBlow" in ca and "applyWeatherAutomation" in ca and "setHazardLights" in ca
assert "dolphin_climate_auto_prefs" in read("app/src/main/java/com/byd/dolphin/drivealerts/config/SettingsBackupManager.kt")
assert "ClimateAutomationActivity::class.java" in read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
print("V01776_CLIMATE_AUTO_AFTERBLOW_HAZARD_ALL_STATIC_GATES_PASS")
