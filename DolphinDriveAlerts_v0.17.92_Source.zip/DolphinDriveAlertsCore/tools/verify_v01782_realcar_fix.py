import re
#!/usr/bin/env python3
"""Comprehensive static & regression verification for v0.17.82 (versionCode 108)."""
import glob, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def read(rel):
    with open(os.path.join(ROOT, rel), "r", encoding="utf-8") as f:
        return f.read()

def check_unclosed_strings():
    kt_files = sorted(glob.glob(os.path.join(ROOT, "app/src/main/java/**/*.kt"), recursive=True))
    assert len(kt_files) >= 140
    issues = []
    for path in kt_files:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        in_block = False
        in_raw = False
        for idx, line in enumerate(lines, 1):
            i, n, in_str = 0, len(line), False
            while i < n:
                if in_block:
                    if line[i:i+2] == "*/": in_block = False; i += 2; continue
                    i += 1; continue
                if in_raw:
                    if line[i:i+3] == '"""': in_raw = False; i += 3; continue
                    i += 1; continue
                if not in_str:
                    if line[i:i+2] == "//": break
                    if line[i:i+2] == "/*": in_block = True; i += 2; continue
                    if line[i:i+3] == '"""': in_raw = True; i += 3; continue
                    if line[i] == "'":
                        i += 2 if (i + 1 < n and line[i+1] == "\\") else 1
                        if i < n and line[i] == "'": i += 1
                        continue
                    if line[i] == '"': in_str = True; i += 1; continue
                    i += 1
                else:
                    if line[i] == "\\": i += 2; continue
                    if line[i] == '"': in_str = False; i += 1; continue
                    i += 1
            if in_str:
                issues.append(f"{os.path.relpath(path, ROOT)}:{idx}: {line.rstrip()}")
    assert not issues, "Unclosed single-line strings:\n" + "\n".join(issues)
    print(f"[PASS] All {len(kt_files)} Kotlin files have zero unclosed single-line strings.")

def check_balanced_braces():
    targets = [
        "app/src/main/java/com/byd/dolphin/drivealerts/camera/BydAvmCameraBackend.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dock/BydComfortController.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dock/ClimateAutomationController.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockPreferences.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dpi/AppPermissionRules.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/dpi/SelectedAppPermissionManager.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/ui/AppPermissionManagerActivity.kt",
        "app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt",
    ]
    for rel in targets:
        s = read(rel)
        # Rough brace balance check ignoring strings/comments
        depth = 0
        in_str = False
        in_raw = False
        in_blk = False
        i, n = 0, len(s)
        while i < n:
            if in_blk:
                if s[i:i+2] == "*/": in_blk = False; i += 2; continue
                i += 1; continue
            if in_raw:
                if s[i:i+3] == '"""': in_raw = False; i += 3; continue
                i += 1; continue
            if in_str:
                if s[i] == "\\": i += 2; continue
                if s[i] == '"': in_str = False; i += 1; continue
                i += 1; continue
            if s[i:i+2] == "//":
                nl = s.find("\n", i)
                i = n if nl == -1 else nl + 1; continue
            if s[i:i+2] == "/*": in_blk = True; i += 2; continue
            if s[i:i+3] == '"""': in_raw = True; i += 3; continue
            if s[i] == '"': in_str = True; i += 1; continue
            if s[i] == "{": depth += 1
            elif s[i] == "}": depth -= 1
            i += 1
        assert depth == 0, f"Unbalanced braces in {rel}: depth={depth}"
    print(f"[PASS] Balanced braces verified across {len(targets)} modified Kotlin files.")

def check_v01782_features():
    avm = read("app/src/main/java/com/byd/dolphin/drivealerts/camera/BydAvmCameraBackend.kt")
    for tok in ["BmmCameraInfo", "getValidCameraTag", "getCameraId", "addPreviewSurface", "IEventCallback"]:
        assert tok in avm, f"Missing {tok} in BydAvmCameraBackend.kt"

    com = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/BydComfortController.kt")
    for tok in ["BydPermissionContext.wrap", "MAX_TEMP_C = 27.0f", "usesHalfDegreeScale", "setSteeringWheelHeatingState", "setSeatHeatingState", "setDayTimeLightState", "startPureVentilation", "setWindModeAll"]:
        assert tok in com, f"Missing {tok} in BydComfortController.kt"

    cli = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/ClimateAutomationController.kt")
    for tok in ["BYDAutoInstrumentDevice", "getOutCarTemperature", "startPureVentilation", "960495667", "BydPermissionContext.wrap"]:
        assert tok in cli, f"Missing {tok} in ClimateAutomationController.kt"

    dock = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt")
    for tok in ["EDGE_TOP", "EDGE_LEFT", "EDGE_RIGHT", "DOCK_HANDLE", "Kind.DRL", "setWindModeAll", "attachEdgeDragListener", "showEdgeSnapPopup"]:
        assert tok in dock, f"Missing {tok} in FloatingDockController.kt"

    icons = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt")
    for tok in ["Kind.DOCK_HANDLE", "Kind.DRL", "Kind.WIND_ALL", '"AUTO"']:
        assert tok in icons, f"Missing {tok} in DockIcons.kt"

    mf = read("app/src/main/AndroidManifest.xml")
    assert "android.permission.BYD_CAMERA" in mf
    assert 'android:requestLegacyExternalStorage="true"' in mf
    assert 'maxSdkVersion="28"' not in mf

    ma = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
    assert "maybeRunFirstLaunchPermissionOnboarding" in ma
    assert '?: "0.17.82"' in ma

    g = read("app/build.gradle.kts")
    m_vc = re.search(r"versionCode\s*=\s*(\d+)", g); assert m_vc and int(m_vc.group(1)) >= 108

    wf = read(".github/workflows/DolphinDriveAlerts_v0.17.82_Source.yml")
    assert "SOURCE_ZIP: DolphinDriveAlerts_v0.17.82_Source.zip" in wf
    assert "verify_v01782_realcar_fix.py" in wf
    print("[PASS] All v0.17.82 real-car API, camera, dock UX, and permission invariants verified.")

if __name__ == "__main__":
    check_unclosed_strings()
    check_balanced_braces()
    check_v01782_features()
    print("ALL v0.17.82 VERIFICATIONS PASSED!")
