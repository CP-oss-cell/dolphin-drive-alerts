#!/usr/bin/env python3
"""Static verification for v0.17.89 Automotive Cockpit UI/UX Overhaul."""
import os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def read(rel): return open(os.path.join(ROOT, rel), "r", encoding="utf-8").read()

def check_balanced(rel):
    txt = read(rel)
    d = 0; s = False; lc = False; bc = False; i = 0; n = len(txt)
    while i < n:
        c = txt[i]; nx = txt[i+1] if i+1 < n else ""
        if lc:
            if c == "\n": lc = False
        elif bc:
            if c == "*" and nx == "/": bc = False; i += 1
        elif s:
            if c == "\\": i += 1
            elif c == '"': s = False
        else:
            if c == "/" and nx == "/": lc = True; i += 1
            elif c == "/" and nx == "*": bc = True; i += 1
            elif c == '"': s = True
            elif c == "{": d += 1
            elif c == "}": d -= 1; assert d >= 0, f"Unbalanced }} in {rel}"
        i += 1
    assert not s and d == 0, f"Unbalanced braces ({d}) or string in {rel}"

files = [
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DarkSpinnerAdapter.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DashboardUi.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/AudioTuningActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DashcamActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/BsdCameraSettingsActivity.kt",
]
for f in files:
    check_balanced(f)

dui = read(files[1])
for kw in ["fun styleSeekBar", "fun styleCheckBox", "fun styleSpinner", "fun addTwoColumnGrid"]:
    assert kw in dui, f"Missing {kw} in DashboardUi.kt"

ma = read(files[2])
assert ma.index("기능별 설정 메뉴") < ma.index("실시간 시스템 상태"), "Feature cards must come BEFORE telemetry on Home!"

at = read(files[3])
assert "buildBandCard" in at and "addTwoColumnGrid" in at and "styleSeekBar" in at

dbs = read(files[4])
assert dbs.count("DashboardUi.segmentedBar(") >= 3 and "addTwoColumnGrid" in dbs

da = read(files[5])
assert da.count("DashboardUi.segmentedBar(") >= 5

bsda = read(files[6])
assert "sliderCard" in bsda and "addTwoColumnGrid" in bsda

bg = read("app/build.gradle.kts")
m = re.search(r"versionCode\s*=\s*(\d+)", bg); assert m and int(m.group(1)) >= 115
print("VERIFY_V01789_PASS: Feature-first Home + Big-finger 2-col EQ + Segmented Bars + Tactile CheckBoxes/SeekBars/Spinners verified.")
