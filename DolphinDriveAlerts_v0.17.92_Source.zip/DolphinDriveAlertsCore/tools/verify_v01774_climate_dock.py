import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 100" in gr and 'versionName = "0.17.74"' in gr
for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        txt = read(rel)
        assert len(txt) > 50, f"Empty file: {rel}"
        clean = strip_kt(txt)
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

fd = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt")
assert '"공조"' in fd and "showClimateDetailPopup()" in fd
bc = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/BydComfortController.kt")
assert "toggleAcCompressor()" in bc and "toggleHeater()" in bc
print("V01774_CLIMATE_DOCK_ALL_STATIC_GATES_PASS")
