import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 103" in gr and 'versionName = "0.17.77"' in gr
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)
for req in [
    "ACCESS_BACKGROUND_LOCATION", "ACCESS_NETWORK_STATE", "SENTRY_HEARTBEAT",
    "BYDAUTO_STATISTIC_GET", "BYDAUTO_GEARBOX_GET", "BYDAUTO_SPEED_GET",
    "BYDAUTO_ADAS_GET", "BYDAUTO_ENERGY_GET", "BYDAUTO_LIGHT_SET", "BYDAUTO_POWER_SET"
]:
    assert req in mf, f"Missing in manifest: {req}"

for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        txt = read(rel)
        assert len(txt) > 50, f"Empty file: {rel}"
        clean = strip_kt(txt)
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

assert "TelegramPreferences.notifyIgnition" in read("app/src/main/java/com/byd/dolphin/drivealerts/service/BootReceiver.kt")
assert "TelegramPreferences.notifyIgnition" in read("app/src/main/java/com/byd/dolphin/drivealerts/sentry/SentryMonitorController.kt")
assert "ACCESS_BACKGROUND_LOCATION" in read("app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt")
assert "dolphin_split_sequence_v013" in read("app/src/main/java/com/byd/dolphin/drivealerts/config/SettingsBackupManager.kt")
print("V01777_ZERO_OMISSION_FULL_AUDIT_PASS")
