#!/usr/bin/env python3
"""Static verification for v0.17.84 (Label-free OEM Dock Icons + 78dp Sub-Menu Scroll Gutters)."""
import os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def read(rel): return open(os.path.join(ROOT, rel), "r", encoding="utf-8").read()

def check_balanced(rel):
    txt = read(rel)
    d = 0; s = False; lc = False; bc = False; i = 0; n = len(txt)
    while i < n:
        c = txt[i]; nx = txt[i+1] if i+1 < n else ""
        if lc:
            if c == "\n": lc = False
        elif bc:
            if c == "*" and nx == "/": bc = False; i += 1
        elif s:
            if c == "\\": i += 1
            elif c == '"': s = False
        else:
            if c == "/" and nx == "/": lc = True; i += 1
            elif c == "/" and nx == "*": bc = True; i += 1
            elif c == '"': s = True
            elif c == "{": d += 1
            elif c == "}": d -= 1; assert d >= 0, f"Unbalanced }} in {rel}"
        i += 1
    assert not s and d == 0, f"Unbalanced braces ({d}) or string in {rel}"

for f in [
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DashboardUi.kt",
]:
    check_balanced(f)

di = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt")
assert "3 vertical bars" in di and ("Home ring" in di or "rounded house" in di) and "curved return arrow" in di

fdc = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt")
assert "oemIconTile" in fdc and "seatHeatTile" in fdc and "fanStepperGroup" in fdc and "tempStepperGroup" in fdc

dui = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/DashboardUi.kt")
assert dui.count("dp(a, 78)") >= 4, "78dp scroll-safe side gutters missing in DashboardUi.kt"

bg = read("app/build.gradle.kts")
m = re.search(r"versionCode\s*=\s*(\d+)", bg); assert m and int(m.group(1)) >= 110

print("VERIFY_V01784_PASS: OEM label-free dock icons + LED indicators + 78dp sub-menu side scroll gutters verified.")
