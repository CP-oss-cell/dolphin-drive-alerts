package com.byd.dolphin.drivealerts.ui

import android.os.Bundle
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.dock.ClimateAutomationController
import com.byd.dolphin.drivealerts.dock.ClimateAutomationPreferences
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity

/**
 * UI for After-Blow, Cold-Weather Auto Heating (individual toggles for steering/driver/passenger/HI heater + fan),
 * Hot-Weather Auto Cooling (LOW A/C + fan), and Reverse-Gear Automatic Hazard Lights.
 */
class ClimateAutomationActivity : DensityAwareActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = DashboardUi.dp(this@ClimateAutomationActivity, v)

    private fun render() {
        val accent = DashboardUi.accentColor(this)
        val screen = DashboardUi.page(
            this,
            "공조 자동화 · 애프터 블로우 · 후진 비상등",
            "추위/더위 자동 냉난방 · 에어컨 건조 송풍 · 후진 시 비상등 자동 점멸",
            DashboardIcons.IconKind.CAR_ALERT,
            accent
        ) { render() }

        // 1. 애프터 블로우
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "애프터 블로우 (시동 OFF 후 에어컨 건조)",
            "주행 중 에어컨을 사용했다면 시동 OFF 시 컴프레서를 끄고 외기 송풍으로 습기·냄새를 말린 뒤 자동 종료합니다.",
            DashboardIcons.IconKind.SPEAKER,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "애프터 블로우 켜기 (ON/OFF)", ClimateAutomationPreferences.afterBlowEnabled(this)) {
                ClimateAutomationPreferences.setAfterBlowEnabled(this, it)
            })
            val minOpts = listOf(1, 2, 3, 5, 7, 10)
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, minOpts.map { "송풍 유지 시간: ${it}분" })
                setSelection(minOpts.indexOf(ClimateAutomationPreferences.afterBlowMinutes(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setAfterBlowMinutes(this@ClimateAutomationActivity, minOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })

            val fanOpts = (1..7).toList()
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, fanOpts.map { "송풍 풍량: ${it}단" })
                setSelection(fanOpts.indexOf(ClimateAutomationPreferences.afterBlowFanLevel(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setAfterBlowFanLevel(this@ClimateAutomationActivity, fanOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })

            p.addView(DashboardUi.action(this, "애프터 블로우 지금 테스트 실행", DashboardIcons.IconKind.PLAY, accent) {
                ClimateAutomationController(applicationContext).startAfterBlow(forceTest = true)
                Toast.makeText(this, "애프터 블로우 테스트 송풍 시작됨", Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(-1, dp(46)))
        })

        // 2. 추운 날씨 자동 난방 (개별 ON/OFF + HI + 풍량)
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "추운 날씨 자동 난방 · 열선",
            "외기 온도가 기준 이하일 때 시동·출발 시 선택한 열선과 히터(HI)를 자동으로 켭니다.",
            DashboardIcons.IconKind.POWER_LAUNCH,
            DashboardUi.warnColor(this)
        ) { p ->
            p.addView(DashboardUi.toggle(this, "추운 날씨 자동 난방 켜기", ClimateAutomationPreferences.coldAutoEnabled(this)) {
                ClimateAutomationPreferences.setColdAutoEnabled(this, it)
            })
            val cOpts = listOf(4, 6, 8, 10, 12, 14, 16)
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, cOpts.map { "추움 기준 온도: ${it}°C 이하" })
                setSelection(cOpts.indexOf(ClimateAutomationPreferences.coldThresholdC(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setColdThresholdC(this@ClimateAutomationActivity, cOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })

            p.addView(DashboardUi.toggle(this, "핸들 열선 자동 켜기", ClimateAutomationPreferences.coldSteeringHeat(this)) {
                ClimateAutomationPreferences.setColdSteeringHeat(this, it)
            })
            val seatLabels = listOf("끔 (자동 작동 안 함)", "1단 (약)", "2단 (강)")
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, seatLabels.map { "운전석 열선: $it" })
                setSelection(ClimateAutomationPreferences.coldDriverSeat(this@ClimateAutomationActivity))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setColdDriverSeat(this@ClimateAutomationActivity, pos)
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(4)) })

            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, seatLabels.map { "동승석 열선: $it" })
                setSelection(ClimateAutomationPreferences.coldPassengerSeat(this@ClimateAutomationActivity))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setColdPassengerSeat(this@ClimateAutomationActivity, pos)
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(4)) })

            p.addView(DashboardUi.toggle(this, "히터 자동 켜기 (온도 HI 최고 설정)", ClimateAutomationPreferences.coldHeaterHi(this)) {
                ClimateAutomationPreferences.setColdHeaterHi(this, it)
            })
            val fanOpts = (1..7).toList()
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, fanOpts.map { "히터 풍량: ${it}단" })
                setSelection(fanOpts.indexOf(ClimateAutomationPreferences.coldHeaterFan(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setColdHeaterFan(this@ClimateAutomationActivity, fanOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2))
        })

        // 3. 더운 날씨 자동 냉방 (LOW + 풍량)
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "더운 날씨 자동 냉방 (에어컨 LOW)",
            "외기 온도가 기준 이상일 때 에어컨을 최저 온도(LOW)와 설정 풍량으로 자동 작동합니다.",
            DashboardIcons.IconKind.GAUGE,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "더운 날씨 자동 냉방 켜기", ClimateAutomationPreferences.hotAutoEnabled(this)) {
                ClimateAutomationPreferences.setHotAutoEnabled(this, it)
            })
            val hOpts = listOf(22, 24, 26, 28, 30, 32)
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, hOpts.map { "더움 기준 온도: ${it}°C 이상" })
                setSelection(hOpts.indexOf(ClimateAutomationPreferences.hotThresholdC(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setHotThresholdC(this@ClimateAutomationActivity, hOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })

            p.addView(DashboardUi.toggle(this, "에어컨 자동 켜기 (온도 LOW 최저 설정)", ClimateAutomationPreferences.hotAcLow(this)) {
                ClimateAutomationPreferences.setHotAcLow(this, it)
            })
            val fanOpts = (1..7).toList()
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@ClimateAutomationActivity, fanOpts.map { "에어컨 풍량: ${it}단" })
                setSelection(fanOpts.indexOf(ClimateAutomationPreferences.hotAcFan(this@ClimateAutomationActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        ClimateAutomationPreferences.setHotAcFan(this@ClimateAutomationActivity, fanOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })

            p.addView(DashboardUi.action(this, "현재 외기 온도로 자동 공조 즉시 테스트", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                val msg = ClimateAutomationController(applicationContext).applyWeatherAutomation()
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }, LinearLayout.LayoutParams(-1, dp(46)))
        })

        // 4. 후진 시 비상등 자동 점멸
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "후진 시 비상등 자동 점멸",
            "후진(R) 중 계속 유지 · N/D 전환 시 10초 유지(깜박이/12km/h 이상 조기 해제) · P단/시동 OFF 시 즉시 끕니다.",
            DashboardIcons.IconKind.CAR_ALERT,
            DashboardUi.dangerColor(this)
        ) { p ->
            p.addView(DashboardUi.toggle(this, "후진(R) 시 비상등 자동 켜기 (ON/OFF)", ClimateAutomationPreferences.reverseHazardEnabled(this)) {
                ClimateAutomationPreferences.setReverseHazardEnabled(this, it)
            })
        })
    }
}
