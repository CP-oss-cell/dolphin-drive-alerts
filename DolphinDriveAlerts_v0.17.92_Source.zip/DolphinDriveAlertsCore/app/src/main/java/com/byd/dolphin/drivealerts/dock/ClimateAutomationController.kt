package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext

/**
 * Clean-Room Climate & Reverse-Hazard Automation Engine (v0.17.82):
 * 1. Cold/Hot Weather Auto-Climate: reads BYDAutoInstrumentDevice.getOutCarTemperature()
 *    (real-car verified on BYD Dolphin DiLink 5.0) and applies configured heating (HI=27°C)
 *    or cooling (LOW=17°C).
 * 2. After-Blow: runs PURE fresh-air ventilation (A/C compressor OFF + Heater OFF +
 *    setAcVentilationState(1) + OUTLOOP) for configured minutes on ACC_OFF, then shuts climate OFF.
 * 3. Reverse Hazard Light: R-gear continuous ON, R->N/D 10s hold (early-cancel on turn signal
 *    or speed >= 12 km/h), P/ACC_OFF immediate OFF. Uses real-car BYDAutoLightDevice
 *    DOUBLE_FLASH (960495667) / EMERGENCY (950009880) feature-set + BydPermissionContext.
 */
class ClimateAutomationController(context: Context) {
    private val app = context.applicationContext
    private val bydCtx = BydPermissionContext.wrap(app)
    private val comfort = BydComfortController(app)
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var acUsedThisTrip = false
    @Volatile private var weatherAutoAppliedTrip = false
    @Volatile private var afterBlowActive = false
    @Volatile private var hazardAppliedByUs = false
    @Volatile private var lastTempCheckMs = 0L
    private var afterBlowWakeLock: PowerManager.WakeLock? = null

    @Volatile private var lastGearRaw: Int? = null
    private val afterBlowStopRunnable = Runnable { finishAfterBlow("timer_done") }
    private val hazardOffRunnable = Runnable { turnOffHazardNow("nd_10s_timer_done") }

    fun onVehicleFrame(frame: RawVehicleFrame, blinkerSide: Side = Side.UNKNOWN) {
        val now = frame.timestampMs
        val gear = frame.gearRaw
        val isReverse = gear == 1
        val isPark = gear == 3
        val isND = gear == 2 || gear == 4
        val isDrivingOrReady = gear in listOf(1, 2, 4)

        if (ClimateAutomationPreferences.reverseHazardEnabled(app)) {
            when {
                isReverse -> {
                    handler.removeCallbacks(hazardOffRunnable)
                    if (!hazardAppliedByUs && setHazardLights(true)) {
                        hazardAppliedByUs = true
                    }
                }
                isPark -> {
                    if (hazardAppliedByUs) turnOffHazardNow("gear_P_immediate")
                }
                isND && hazardAppliedByUs -> {
                    val blinkerOn = blinkerSide == Side.LEFT || blinkerSide == Side.RIGHT
                    val speedUp = (frame.speedKmH ?: 0f) >= 12f
                    if (blinkerOn || speedUp) {
                        turnOffHazardNow(if (blinkerOn) "blinker_early_cancel" else "speed_12kmh_early_cancel")
                    } else if (lastGearRaw == 1) {
                        handler.removeCallbacks(hazardOffRunnable)
                        handler.postDelayed(hazardOffRunnable, 10_000L)
                        CoreLog.i("CLIMATE_AUTO", "HAZARD_HOLD_10S gear=$gear")
                    }
                }
            }
        } else if (hazardAppliedByUs) {
            turnOffHazardNow("feature_disabled")
        }
        lastGearRaw = gear

        if (afterBlowActive && isDrivingOrReady) {
            finishAfterBlow("driver_returned")
        }

        if (now - lastTempCheckMs >= 5_000L) {
            lastTempCheckMs = now
            val snap = comfort.refreshSnapshot()
            if (snap.acOn || snap.acCompressorOn) {
                acUsedThisTrip = true
            }
            if (isDrivingOrReady && !weatherAutoAppliedTrip) {
                weatherAutoAppliedTrip = true
                applyWeatherAutomation()
            }
        }
    }

    fun applyWeatherAutomation(): String {
        val outC = readOutsideTempC() ?: return "외기 온도 미수신 (적용 보류)"
        if (ClimateAutomationPreferences.coldAutoEnabled(app) && outC <= ClimateAutomationPreferences.coldThresholdC(app)) {
            if (ClimateAutomationPreferences.coldSteeringHeat(app)) comfort.setSteeringHeatDirect(true)
            val drv = ClimateAutomationPreferences.coldDriverSeat(app)
            if (drv > 0) comfort.setSeatHeatDirect(1, drv)
            val pas = ClimateAutomationPreferences.coldPassengerSeat(app)
            if (pas > 0) comfort.setSeatHeatDirect(2, pas)
            if (ClimateAutomationPreferences.coldHeaterHi(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(BydComfortController.MAX_TEMP_C) // 27°C = HI
                comfort.setHeaterDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.coldHeaterFan(app))
            }
            val msg = "추위 자동 난방 적용 (${outC.toInt()}°C ≤ ${ClimateAutomationPreferences.coldThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        if (ClimateAutomationPreferences.hotAutoEnabled(app) && outC >= ClimateAutomationPreferences.hotThresholdC(app)) {
            if (ClimateAutomationPreferences.hotAcLow(app)) {
                comfort.setClimatePowerDirect(true)
                comfort.setTemperatureDirect(BydComfortController.MIN_TEMP_C) // 17°C = LOW
                comfort.setAcCompressorDirect(true)
                comfort.setFanLevelDirect(ClimateAutomationPreferences.hotAcFan(app))
                acUsedThisTrip = true
            }
            val msg = "더위 자동 냉방 적용 (${outC.toInt()}°C ≥ ${ClimateAutomationPreferences.hotThresholdC(app)}°C)"
            CoreLog.i("CLIMATE_AUTO", msg)
            return msg
        }
        return "외기 ${outC.toInt()}°C · 기준 온도 범위 외 (자동 공조 대기)"
    }

    fun onIgnitionOff() {
        weatherAutoAppliedTrip = false
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
        if (ClimateAutomationPreferences.afterBlowEnabled(app) && acUsedThisTrip) {
            acUsedThisTrip = false
            startAfterBlow()
        }
    }

    fun startAfterBlow(forceTest: Boolean = false) {
        if (afterBlowActive) return
        if (!forceTest && !ClimateAutomationPreferences.afterBlowEnabled(app)) return
        val minutes = ClimateAutomationPreferences.afterBlowMinutes(app)
        val fan = ClimateAutomationPreferences.afterBlowFanLevel(app)
        afterBlowActive = true

        runCatching {
            val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
            afterBlowWakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Dolphin:AfterBlow")
                ?.apply { setReferenceCounted(false); acquire((minutes + 1) * 60_000L) }
        }

        // Pure fresh-air ventilation ONLY (A/C OFF + Heater OFF + Ventilation ON + OUTLOOP)
        comfort.startPureVentilation(fan)

        handler.removeCallbacks(afterBlowStopRunnable)
        handler.postDelayed(afterBlowStopRunnable, minutes * 60_000L)
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_STARTED minutes=$minutes fan=$fan forceTest=$forceTest")
    }

    private fun finishAfterBlow(reason: String) {
        if (!afterBlowActive) return
        afterBlowActive = false
        handler.removeCallbacks(afterBlowStopRunnable)
        if (reason == "timer_done") {
            comfort.setClimatePowerDirect(false)
        }
        runCatching { afterBlowWakeLock?.let { if (it.isHeld) it.release() } }
        afterBlowWakeLock = null
        CoreLog.i("CLIMATE_AUTO", "AFTER_BLOW_FINISHED reason=$reason")
    }

    private fun readOutsideTempC(): Float? {
        // 1. Primary real-car verified source: BYDAutoInstrumentDevice.getOutCarTemperature()
        runCatching {
            val cls = Class.forName("android.hardware.bydauto.instrument.BYDAutoInstrumentDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx)
            if (inst != null) {
                for (name in listOf("getOutCarTemperature", "getOutsideTemperature")) {
                    val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
                    val v = (m.invoke(inst) as? Number)?.toFloat()
                    if (v != null && v in -35f..60f) return v
                }
            }
        }
        // 2. Fallback: BYDAutoAcDevice
        return runCatching {
            val cls = Class.forName("android.hardware.bydauto.ac.BYDAutoAcDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx) ?: return@runCatching null
            for (name in listOf("getOutCarTemperature", "getOutSideTemperature", "getOutsideTemperature")) {
                val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
                val v = (m.invoke(inst) as? Number)?.toFloat()
                if (v != null && v in -35f..60f) return@runCatching v
            }
            null
        }.getOrNull()
    }

    private fun turnOffHazardNow(reason: String) {
        handler.removeCallbacks(hazardOffRunnable)
        if (hazardAppliedByUs) {
            setHazardLights(false)
            hazardAppliedByUs = false
            CoreLog.i("CLIMATE_AUTO", "HAZARD_OFF reason=$reason")
        }
    }

    private fun setHazardLights(on: Boolean): Boolean = runCatching {
        val cls = Class.forName("android.hardware.bydauto.light.BYDAutoLightDevice")
        val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, bydCtx) ?: return@runCatching false
        val bydState = if (on) 1 else 2 // Real-car verified: getDoubleFlashLightState 1=ON, 2=OFF
        val binState = if (on) 1 else 0

        // 1. Direct named setter if present on firmware
        for (mName in listOf("setDoubleFlashLightState", "setHazardLightState", "setDoubleFlashState", "setWarningLightState")) {
            val m = runCatching { cls.getMethod(mName, Int::class.javaPrimitiveType) }.getOrNull()
            if (m != null) {
                val r = runCatching { m.invoke(inst, if (mName.contains("DoubleFlashLight")) bydState else binState) }.getOrNull()
                if (!(r is Int && r < 0)) {
                    CoreLog.i("CLIMATE_AUTO", "HAZARD $mName ok on=$on")
                    return@runCatching true
                }
            }
        }

        // 2. BYD AbsBYDAutoDevice.set(int deviceType, int featureId, int value) with verified IDs:
        //    DOUBLE_FLASH = 960495667 (0x39400033), EMERGENCY = 950009880 (0x38a00018)
        val devType = runCatching { (cls.getMethod("getType").invoke(inst) as? Number)?.toInt() }.getOrDefault(1010)
        val set3 = runCatching {
            cls.getMethod("set", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
        }.getOrNull()
        if (set3 != null) {
            for (fid in listOf(960495667, 950009880)) {
                val r = runCatching { set3.invoke(inst, devType, fid, binState) }.getOrNull()
                if (r is Int && r >= 0) {
                    CoreLog.i("CLIMATE_AUTO", "HAZARD set($devType, $fid, $binState) -> $r")
                    return@runCatching true
                }
            }
        }

        // 3. setLight / setLightState fallback
        for (mName in listOf("setLight", "setLightState")) {
            val m = runCatching { cls.getMethod(mName, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType) }.getOrNull()
            if (m != null) {
                val r = runCatching { m.invoke(inst, 4, binState) }.getOrNull()
                if (!(r is Int && r < 0)) {
                    CoreLog.i("CLIMATE_AUTO", "HAZARD $mName(4, $binState) ok")
                    return@runCatching true
                }
            }
        }
        false
    }.getOrDefault(false)

    fun shutdown() {
        finishAfterBlow("shutdown")
        if (hazardAppliedByUs) {
            turnOffHazardNow("ignition_off_or_shutdown")
        }
    }
}
