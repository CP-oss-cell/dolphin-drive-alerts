package com.byd.dolphin.drivealerts.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.camera.DashcamPreferences
import com.byd.dolphin.drivealerts.camera.VehicleCameraHub
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity

/** Ultra-low-resource Dashcam Settings: USB/SD storage, soft-format, event protection, telemetry & viewer. */
class DashcamActivity : DensityAwareActivity() {
    private var localHub: VehicleCameraHub? = null
    private lateinit var storageView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        localHub = VehicleCameraHub(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@DashcamActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@DashcamActivity, 18), DashboardUi.dp(this@DashcamActivity, 14),
                DashboardUi.dp(this@DashcamActivity, 18), DashboardUi.dp(this@DashcamActivity, 24))
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "주행 녹화 (초저리소스 블랙박스)", "USB/SD 저장 · 이벤트 보호 · GPS/주행정보 · 발열 보호")

        val accent = DashboardUi.accentColor(this)
        val hub = requireNotNull(localHub)

        // 1. Master Toggle + Viewer + Manual Event Lock
        val mainPanel = DashboardUi.panel(
            this,
            "초저리소스 하드웨어 주행 녹화",
            "Zero-Copy 하드웨어 H.264 인코딩과 단일 카메라 공유 허브로 시스템 저하 없이 앞차 출발·후측방과 동시 작동합니다.",
            DashboardIcons.IconKind.RECORD_DOT,
            DashboardUi.dangerColor(this)
        ) { p ->
            p.addView(DashboardUi.toggle(this, "D/N 기어 주행 중 자동 순환 녹화 사용", DashcamPreferences.enabled(this)) {
                DashcamPreferences.setEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "주행 정보·GPS·SRT 자막 동기화 저장 (기어·속도·브레이크·경로)", DashcamPreferences.telemetryEnabled(this)) {
                DashcamPreferences.setTelemetryEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "고온 발열 보호 (60°C 이상 자동 일시정지 · 53°C 이하 자동 재개)", DashcamPreferences.thermalGuardEnabled(this)) {
                DashcamPreferences.setThermalGuardEnabled(this, it)
            })
            p.addView(
                DashboardUi.actionRow(
                    this, "녹화 영상 · GPS 주행 궤적 뷰어 열기",
                    "일반/이벤트 보호 영상 재생 · 속도·기어·브레이크 · 오프라인 경로 지도",
                    DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this), "뷰어"
                ) { startActivity(Intent(this, DashcamViewerActivity::class.java)) },
                LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this@DashcamActivity, 6), 0, DashboardUi.dp(this@DashcamActivity, 6)) }
            )
            val permRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            permRow.addView(
                DashboardUi.action(this, "카메라 권한 요청", DashboardIcons.IconKind.KEY_PERM, accent) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "카메라 권한 허용됨", Toast.LENGTH_SHORT).show()
                    } else requestPermissions(arrayOf(Manifest.permission.CAMERA), 9103)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamActivity, 48), 1f).apply { setMargins(0, 0, DashboardUi.dp(this@DashcamActivity, 4), 0) }
            )
            permRow.addView(
                DashboardUi.action(this, "위치(GPS) 권한 요청", DashboardIcons.IconKind.NAV_ARROW, accent) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "GPS 위치 권한 허용됨", Toast.LENGTH_SHORT).show()
                    } else requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 9104)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamActivity, 48), 1f).apply { setMargins(DashboardUi.dp(this@DashcamActivity, 4), 0, 0, 0) }
            )
            p.addView(permRow)
        }
        mainPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, mainPanel)

        // 2. Storage Volume (Internal / USB / SD) + Event Protection + G-Sensor + Quality
        val configPanel = DashboardUi.panel(
            this,
            "저장 매체(USB/SD) · 이벤트 보호 · 순환 정책",
            "이벤트 녹화(충격·급제동·수동 + 직전 프리롤)는 일반 삭제에서 보호되며 상한 초과 시에만 순차 삭제됩니다.",
            DashboardIcons.IconKind.SHIELD_ADB,
            accent
        ) { p ->
            val volumes = hub.availableVolumes()
            p.addView(DashboardUi.label(this, "저장 매체 선택 (USB/SD 분리 시 내장 자동 폴백)", 13f))
            val volSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@DashcamActivity, volumes.map { it.label })
                setSelection(volumes.indexOfFirst { it.index == DashcamPreferences.storageVolumeIndex(this@DashcamActivity) }.coerceAtLeast(0))
            }
            p.addView(volSpinner)

            p.addView(DashboardUi.label(this, "녹화 카메라 ID / 화질 / 분할 길이", 13f))
            val camInput = EditText(this).apply { setText(DashcamPreferences.cameraId(this@DashcamActivity)); hint = "카메라 ID (기본 0)" }
            p.addView(camInput)

            var selQual = DashcamPreferences.qualityTier(this)
            var selSegIdx = DashcamPreferences.segmentOptions.indexOf(DashcamPreferences.segmentMinutes(this)).coerceAtLeast(0)
            var selCapIdx = DashcamPreferences.storageOptions.indexOf(DashcamPreferences.maxStorageGb(this)).coerceAtLeast(0)
            var selEvIdx = DashcamPreferences.eventMaxOptions.indexOf(DashcamPreferences.eventMaxCount(this)).coerceAtLeast(0)
            var selG = DashcamPreferences.gsensorLevel(this)

            p.addView(DashboardUi.label(this, "녹화 화질 · 분할 길이", 13.5f, true))
            p.addView(DashboardUi.segmentedBar(this, listOf("480p 저용량", "720p 균형", "원본 고화질"), selQual, accent) {
                selQual = it; DashcamPreferences.setQualityTier(this, it)
            })
            p.addView(DashboardUi.segmentedBar(this, listOf("1분 분할", "3분 분할", "5분 분할"), selSegIdx, accent) {
                selSegIdx = it; DashcamPreferences.setSegmentMinutes(this, DashcamPreferences.segmentOptions[it])
            })

            p.addView(DashboardUi.label(this, "일반 녹화 순환 용량 상한", 13.5f, true))
            p.addView(DashboardUi.segmentedBar(this, DashcamPreferences.storageOptions.map { "${it} GB" }, selCapIdx, accent) {
                selCapIdx = it; DashcamPreferences.setMaxStorageGb(this, DashcamPreferences.storageOptions[it]); refreshStorage()
            })

            p.addView(DashboardUi.label(this, "이벤트 · 센트리 보호 최대 개수", 13.5f, true))
            p.addView(DashboardUi.segmentedBar(this, DashcamPreferences.eventMaxOptions.map { "${it}개" }, selEvIdx, accent) {
                selEvIdx = it; DashcamPreferences.setEventMaxCount(this, DashcamPreferences.eventMaxOptions[it]); refreshStorage()
            })

            p.addView(DashboardUi.label(this, "충격(G-센서) · 급제동 자동 보호 민감도", 13.5f, true))
            p.addView(DashboardUi.segmentedBar(this, listOf("끄기", "둔감", "보통", "민감"), selG, accent) {
                selG = it; DashcamPreferences.setGsensorLevel(this, it)
            })

            p.addView(
                DashboardUi.action(this, "저장 매체 · 카메라 ID 저장", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
                    DashcamPreferences.setStorageVolumeIndex(this, volumes[volSpinner.selectedItemPosition].index)
                    DashcamPreferences.setCameraId(this, camInput.text.toString())
                    DashcamPreferences.setQualityTier(this, selQual)
                    DashcamPreferences.setSegmentMinutes(this, DashcamPreferences.segmentOptions[selSegIdx])
                    DashcamPreferences.setMaxStorageGb(this, DashcamPreferences.storageOptions[selCapIdx])
                    DashcamPreferences.setEventMaxCount(this, DashcamPreferences.eventMaxOptions[selEvIdx])
                    DashcamPreferences.setGsensorLevel(this, selG)
                    refreshStorage()
                    Toast.makeText(this, "블랙박스 저장·보호 설정 저장 완료", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this@DashcamActivity, 48)).apply { setMargins(0, DashboardUi.dp(this@DashcamActivity, 8), 0, 0) }
            )
        }
        configPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, configPanel)

        // 3. Storage Status + Soft Format + Manual Recording / Event Lock Test
        val managePanel = DashboardUi.panel(
            this,
            "저장소 관리 · 녹화 폴더 초기화(소프트 포맷) · 수동 테스트",
            "Android 안전 정책상 물리 파티션 포맷 대신 녹화 폴더 내 파일만 안전하게 일괄 초기화합니다.",
            DashboardIcons.IconKind.DIAG_LOG,
            DashboardUi.warnColor(this)
        ) { p ->
            storageView = DashboardUi.label(this, "조회 중…", 12.5f)
            p.addView(storageView)

            val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btnRow.addView(
                DashboardUi.action(this, "수동 녹화 시작", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                    hub.startManual(); refreshStorage()
                    Toast.makeText(this, "수동 녹화 시작 (${hub.statusText})", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamActivity, 48), 1f).apply { setMargins(0, DashboardUi.dp(this@DashcamActivity, 4), DashboardUi.dp(this@DashcamActivity, 4), 0) }
            )
            btnRow.addView(
                DashboardUi.action(this, "수동 이벤트 잠금", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.warnColor(this)) {
                    hub.triggerEventLock("MANUAL")
                    Toast.makeText(this, "현재 및 직전 구간을 이벤트 보호 폴더로 예약했습니다.", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamActivity, 48), 1f).apply { setMargins(DashboardUi.dp(this@DashcamActivity, 2), DashboardUi.dp(this@DashcamActivity, 4), DashboardUi.dp(this@DashcamActivity, 2), 0) }
            )
            btnRow.addView(
                DashboardUi.action(this, "녹화 중지", DashboardIcons.IconKind.STOP, DashboardUi.dangerColor(this)) {
                    hub.stopManual(); refreshStorage()
                    Toast.makeText(this, "녹화 중지 및 MP4 저장 완료", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamActivity, 48), 1f).apply { setMargins(DashboardUi.dp(this@DashcamActivity, 4), DashboardUi.dp(this@DashcamActivity, 4), 0, 0) }
            )
            p.addView(btnRow)

            p.addView(
                DashboardUi.action(this, "녹화 저장소 초기화 (권한 확인 후 소프트 포맷)", DashboardIcons.IconKind.RESCUE, DashboardUi.dangerColor(this)) {
                    val (canWrite, permMsg) = hub.checkFormatPermission()
                    if (!canWrite) {
                        AlertDialog.Builder(this).setTitle("포맷 권한 부족").setMessage(permMsg).setPositiveButton("확인", null).show()
                        return@action
                    }
                    AlertDialog.Builder(this)
                        .setTitle("녹화 저장소 초기화")
                        .setMessage("어떤 녹화 파일을 비우시겠습니까? (차량 시스템 파일은 건드리지 않습니다)")
                        .setPositiveButton("일반 녹화만 비우기") { _, _ ->
                            val n = hub.softFormatStorage(includeEvents = false)
                            refreshStorage()
                            Toast.makeText(this, "일반 녹화 파일 ${n}개 삭제 완료", Toast.LENGTH_SHORT).show()
                        }
                        .setNeutralButton("이벤트 포함 전체 비우기") { _, _ ->
                            val n = hub.softFormatStorage(includeEvents = true)
                            refreshStorage()
                            Toast.makeText(this, "전체 녹화 파일 ${n}개 초기화 완료", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this@DashcamActivity, 48)).apply { setMargins(0, DashboardUi.dp(this@DashcamActivity, 8), 0, 0) }
            )
            refreshStorage()
        }
        managePanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, managePanel)
    }

    private fun refreshStorage() {
        val hub = localHub ?: return
        storageView.text = "${hub.storageSummary()}\n현재 상태: ${hub.statusText}"
    }

    override fun onDestroy() {
        runCatching { localHub?.shutdown() }
        localHub = null
        super.onDestroy()
    }
}
