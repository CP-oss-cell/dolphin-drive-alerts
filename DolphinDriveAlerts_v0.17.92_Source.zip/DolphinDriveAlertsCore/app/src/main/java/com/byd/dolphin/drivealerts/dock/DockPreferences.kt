package com.byd.dolphin.drivealerts.dock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent settings for the System Bar hide mode and 4-Edge Snapping Floating Dock Bar
 * (Bottom / Top / Left / Right edges, auto-collapse, opacity, bar size, popup grid,
 * optional extra stock BYD functions, pinned apps, and app folders).
 */
object DockPreferences {
    private const val PREF = "dolphin_floating_dock_prefs"
    private const val KEY_ENABLED = "dock_enabled"
    private const val KEY_SYSBAR_MODE = "sysbar_mode"
    private const val KEY_EDGE_POS = "dock_edge_pos"
    private const val KEY_RESERVE_SCREEN_SPACE = "dock_reserve_screen_space"
    private const val KEY_AUTO_COLLAPSE = "dock_auto_collapse"
    private const val KEY_AUTO_COLLAPSE_SEC = "dock_auto_collapse_sec"
    private const val KEY_HEIGHT_DP = "dock_height_dp"
    private const val KEY_OPACITY_PCT = "dock_opacity_pct"
    private const val KEY_POPUP_COLS = "dock_popup_cols"
    private const val KEY_POPUP_ROWS = "dock_popup_rows"
    private const val KEY_POPUP_OPACITY_PCT = "dock_popup_opacity_pct"
    private const val KEY_EXTRA_STOCK = "dock_extra_stock_csv"
    private const val KEY_PINNED_APPS = "dock_pinned_apps_csv"
    private const val KEY_FOLDERS_JSON = "dock_folders_json"
    private const val KEY_FREEFORM_SLOTS = "dock_freeform_slots_csv"
    private const val KEY_DOCK_ORDER = "dock_core_order_csv"

    const val EDGE_BOTTOM = 0
    const val EDGE_TOP = 1
    const val EDGE_LEFT = 2
    const val EDGE_RIGHT = 3

    val edgeLabels = listOf("하단바 (기본)", "상단바", "왼쪽 끝 (세로)", "오른쪽 끝 (세로)")

    data class AppFolder(val id: String, val name: String, val packages: List<String>)

    enum class ExtraStockAction(val key: String, val label: String) {
        AC_AUTO("ac_auto", "AUTO 공조"),
        FRONT_DEFROST("front_defrost", "앞유리 급속 성에제거"),
        VENTILATE("ventilate", "환기(창문 살짝 열기)"),
        CLOSE_WINDOWS("close_windows", "전체 창문 닫기"),
        SUNSHADE_OPEN("sunshade_open", "썬셰이드 열기"),
        SUNSHADE_CLOSE("sunshade_close", "썬셰이드 닫기"),
        DASHCAM_LOCK("dashcam_lock", "블랙박스 이벤트 잠금"),
        SPLIT_QUICK("split_quick", "화면 분할 실행")
    }

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_ENABLED, v).apply() }

    fun systemBarMode(c: Context): Int = sp(c).getInt(KEY_SYSBAR_MODE, SystemBarController.MODE_STOCK).coerceIn(0, 3)
    fun setSystemBarMode(c: Context, v: Int) { sp(c).edit().putInt(KEY_SYSBAR_MODE, v.coerceIn(0, 3)).apply() }

    fun edgePosition(c: Context): Int = sp(c).getInt(KEY_EDGE_POS, EDGE_BOTTOM).coerceIn(0, 3)
    fun setEdgePosition(c: Context, edge: Int) { sp(c).edit().putInt(KEY_EDGE_POS, edge.coerceIn(0, 3)).apply() }

    fun reserveScreenSpace(c: Context): Boolean = sp(c).getBoolean(KEY_RESERVE_SCREEN_SPACE, false)
    fun setReserveScreenSpace(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_RESERVE_SCREEN_SPACE, v).apply() }

    fun autoCollapse(c: Context): Boolean = sp(c).getBoolean(KEY_AUTO_COLLAPSE, false)
    fun setAutoCollapse(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_AUTO_COLLAPSE, v).apply() }

    fun autoCollapseSeconds(c: Context): Int = sp(c).getInt(KEY_AUTO_COLLAPSE_SEC, 10).coerceIn(4, 60)
    fun setAutoCollapseSeconds(c: Context, sec: Int) { sp(c).edit().putInt(KEY_AUTO_COLLAPSE_SEC, sec.coerceIn(4, 60)).apply() }

    fun heightDp(c: Context): Int = sp(c).getInt(KEY_HEIGHT_DP, 68).coerceIn(54, 84)
    fun setHeightDp(c: Context, dp: Int) { sp(c).edit().putInt(KEY_HEIGHT_DP, dp.coerceIn(54, 84)).apply() }

    fun opacityPercent(c: Context): Int = sp(c).getInt(KEY_OPACITY_PCT, 92).coerceIn(55, 100)
    fun setOpacityPercent(c: Context, pct: Int) { sp(c).edit().putInt(KEY_OPACITY_PCT, pct.coerceIn(55, 100)).apply() }

    fun popupCols(c: Context): Int = sp(c).getInt(KEY_POPUP_COLS, 2).coerceIn(2, 6)
    fun setPopupCols(c: Context, cols: Int) { sp(c).edit().putInt(KEY_POPUP_COLS, cols.coerceIn(2, 6)).apply() }

    fun popupRows(c: Context): Int = sp(c).getInt(KEY_POPUP_ROWS, 2).coerceIn(2, 5)
    fun setPopupRows(c: Context, rows: Int) { sp(c).edit().putInt(KEY_POPUP_ROWS, rows.coerceIn(2, 5)).apply() }

    fun popupOpacityPercent(c: Context): Int = sp(c).getInt(KEY_POPUP_OPACITY_PCT, 78).coerceIn(40, 100)
    fun setPopupOpacityPercent(c: Context, pct: Int) { sp(c).edit().putInt(KEY_POPUP_OPACITY_PCT, pct.coerceIn(40, 100)).apply() }

    fun extraStockActions(c: Context): Set<String> =
        sp(c).getString(KEY_EXTRA_STOCK, "ac_auto,front_defrost")
            .orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun setExtraStockActions(c: Context, keys: Set<String>) {
        sp(c).edit().putString(KEY_EXTRA_STOCK, keys.joinToString(",")).apply()
    }

    fun pinnedApps(c: Context): List<String> =
        sp(c).getString(KEY_PINNED_APPS, "")
            .orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    fun setPinnedApps(c: Context, pkgs: List<String>) {
        sp(c).edit().putString(KEY_PINNED_APPS, pkgs.distinct().joinToString(",")).apply()
    }

    fun addPinnedApp(c: Context, pkg: String) {
        val list = pinnedApps(c).toMutableList()
        if (pkg !in list) {
            list.add(pkg)
            setPinnedApps(c, list)
        }
    }

    fun removePinnedApp(c: Context, pkg: String) {
        setPinnedApps(c, pinnedApps(c).filterNot { it == pkg })
    }

    fun folders(c: Context): List<AppFolder> {
        val raw = sp(c).getString(KEY_FOLDERS_JSON, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = obj.optString("id").ifBlank { return@mapNotNull null }
                val name = obj.optString("name").ifBlank { "폴더" }
                val pkgsArr = obj.optJSONArray("pkgs") ?: JSONArray()
                val pkgs = (0 until pkgsArr.length()).mapNotNull { j ->
                    pkgsArr.optString(j).takeIf { it.isNotBlank() }
                }
                AppFolder(id, name, pkgs)
            }
        }.getOrDefault(emptyList())
    }

    fun saveFolders(c: Context, list: List<AppFolder>) {
        val arr = JSONArray()
        for (f in list) {
            val obj = JSONObject()
            obj.put("id", f.id)
            obj.put("name", f.name)
            val pa = JSONArray()
            f.packages.distinct().forEach { pa.put(it) }
            obj.put("pkgs", pa)
            arr.put(obj)
        }
        sp(c).edit().putString(KEY_FOLDERS_JSON, arr.toString()).apply()
    }

    fun upsertFolder(c: Context, folder: AppFolder) {
        val list = folders(c).toMutableList()
        val idx = list.indexOfFirst { it.id == folder.id }
        if (idx >= 0) list[idx] = folder else list.add(folder)
        saveFolders(c, list)
    }

    fun deleteFolder(c: Context, id: String) {
        saveFolders(c, folders(c).filterNot { it.id == id })
    }

    fun freeformSlotApps(c: Context): List<String> {
        val raw = sp(c).getString(KEY_FREEFORM_SLOTS, "") ?: ""
        val parts = raw.split(",").map { it.trim() }
        return List(4) { i -> parts.getOrElse(i) { "" } }
    }

    fun setFreeformSlotApp(c: Context, slotIdx: Int, pkg: String) {
        val list = freeformSlotApps(c).toMutableList()
        if (slotIdx in 0..3) {
            list[slotIdx] = pkg.trim()
            sp(c).edit().putString(KEY_FREEFORM_SLOTS, list.joinToString(",")).apply()
        }
    }

    val defaultCoreOrder = listOf(
        "recents", "home", "back", "ac", "temp", "fan", "wind", "recirc",
        "steer", "seat_l", "seat_r", "rear_def", "drl", "settings", "drawer"
    )

    fun dockCoreOrder(c: Context): List<String> {
        val raw = sp(c).getString(KEY_DOCK_ORDER, "") ?: ""
        val saved = raw.split(",").map { it.trim() }.filter { it in defaultCoreOrder }.distinct()
        return if (saved.isEmpty()) defaultCoreOrder else saved + defaultCoreOrder.filterNot { it in saved }
    }

    fun setDockCoreOrder(c: Context, order: List<String>) {
        val clean = order.filter { it in defaultCoreOrder }.distinct() + defaultCoreOrder.filterNot { it in order }
        sp(c).edit().putString(KEY_DOCK_ORDER, clean.joinToString(",")).apply()
    }

    fun moveCoreItem(c: Context, key: String, delta: Int) {
        val list = dockCoreOrder(c).toMutableList()
        val idx = list.indexOf(key)
        if (idx < 0) return
        val target = (idx + delta).coerceIn(0, list.lastIndex)
        if (target != idx) {
            list.removeAt(idx)
            list.add(target, key)
            setDockCoreOrder(c, list)
        }
    }
}
