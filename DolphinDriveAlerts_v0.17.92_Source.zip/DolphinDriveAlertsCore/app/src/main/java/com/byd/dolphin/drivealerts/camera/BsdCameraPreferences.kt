package com.byd.dolphin.drivealerts.camera

import android.content.Context

/** Preferences for Hyundai/Kia BVM-style Camera2 turn-signal blind-spot camera overlay. */
object BsdCameraPreferences {
    private const val PREF = "bsd_camera_overlay"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_LEFT_CAM_ID = "left_cam_id"
    private const val KEY_RIGHT_CAM_ID = "right_cam_id"
    private const val KEY_CROP_MODE = "crop_mode"
    private const val KEY_SIZE_TIER = "size_tier"
    private const val KEY_HOLD_MS = "hold_ms"
    private const val KEY_MIRROR_H = "mirror_h"
    private const val KEY_FLIP_V = "flip_v"
    private const val KEY_ZOOM_PCT = "zoom_pct"
    private const val KEY_PAN_X = "pan_x"
    private const val KEY_PAN_Y = "pan_y"
    private const val KEY_BRIGHTNESS = "brightness"
    private const val KEY_CONTRAST = "contrast"
    private const val KEY_SATURATION = "saturation"
    private const val KEY_SPEED_MODE = "speed_mode"

    val cropLabels = listOf("전체 영상", "좌/우 절반 크롭", "4분할 사분면 크롭 (BYD AVM)")
    val sizeLabels = listOf("작게 (380×230)", "보통 (480×290 · 현대/기아 BVM 비율)", "크게 (580×350)")
    val speedLabels = listOf("모든 속도에서 작동", "시속 5 ~ 80 km/h (도심 권장)", "시속 10 ~ 110 km/h (고속도로 포함)")

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = prefs(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun leftCameraId(c: Context): String = prefs(c).getString(KEY_LEFT_CAM_ID, "0") ?: "0"
    fun setLeftCameraId(c: Context, id: String) = prefs(c).edit().putString(KEY_LEFT_CAM_ID, id.trim().ifBlank { "0" }).apply()

    fun rightCameraId(c: Context): String = prefs(c).getString(KEY_RIGHT_CAM_ID, "0") ?: "0"
    fun setRightCameraId(c: Context, id: String) = prefs(c).edit().putString(KEY_RIGHT_CAM_ID, id.trim().ifBlank { "0" }).apply()

    fun cropMode(c: Context): Int = prefs(c).getInt(KEY_CROP_MODE, 0).coerceIn(0, 2)
    fun setCropMode(c: Context, mode: Int) = prefs(c).edit().putInt(KEY_CROP_MODE, mode.coerceIn(0, 2)).apply()

    fun sizeTier(c: Context): Int = prefs(c).getInt(KEY_SIZE_TIER, 1).coerceIn(0, 2)
    fun setSizeTier(c: Context, tier: Int) = prefs(c).edit().putInt(KEY_SIZE_TIER, tier.coerceIn(0, 2)).apply()

    fun holdMs(c: Context): Long = prefs(c).getLong(KEY_HOLD_MS, 1_800L).coerceIn(500L, 5_000L)
    fun setHoldMs(c: Context, ms: Long) = prefs(c).edit().putLong(KEY_HOLD_MS, ms.coerceIn(500L, 5_000L)).apply()

    // Hyundai/Kia BVM geometry & color calibration
    fun mirrorHorizontal(c: Context): Boolean = prefs(c).getBoolean(KEY_MIRROR_H, true)
    fun setMirrorHorizontal(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_MIRROR_H, v).apply()

    fun flipVertical(c: Context): Boolean = prefs(c).getBoolean(KEY_FLIP_V, false)
    fun setFlipVertical(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_FLIP_V, v).apply()

    fun zoomPercent(c: Context): Int = prefs(c).getInt(KEY_ZOOM_PCT, 120).coerceIn(100, 220)
    fun setZoomPercent(c: Context, v: Int) = prefs(c).edit().putInt(KEY_ZOOM_PCT, v.coerceIn(100, 220)).apply()

    fun panX(c: Context): Int = prefs(c).getInt(KEY_PAN_X, 0).coerceIn(-40, 40)
    fun setPanX(c: Context, v: Int) = prefs(c).edit().putInt(KEY_PAN_X, v.coerceIn(-40, 40)).apply()

    fun panY(c: Context): Int = prefs(c).getInt(KEY_PAN_Y, 0).coerceIn(-40, 40)
    fun setPanY(c: Context, v: Int) = prefs(c).edit().putInt(KEY_PAN_Y, v.coerceIn(-40, 40)).apply()

    fun brightness(c: Context): Int = prefs(c).getInt(KEY_BRIGHTNESS, 5).coerceIn(-50, 50)
    fun setBrightness(c: Context, v: Int) = prefs(c).edit().putInt(KEY_BRIGHTNESS, v.coerceIn(-50, 50)).apply()

    fun contrastPercent(c: Context): Int = prefs(c).getInt(KEY_CONTRAST, 110).coerceIn(50, 180)
    fun setContrastPercent(c: Context, v: Int) = prefs(c).edit().putInt(KEY_CONTRAST, v.coerceIn(50, 180)).apply()

    fun saturationPercent(c: Context): Int = prefs(c).getInt(KEY_SATURATION, 108).coerceIn(0, 200)
    fun setSaturationPercent(c: Context, v: Int) = prefs(c).edit().putInt(KEY_SATURATION, v.coerceIn(0, 200)).apply()

    fun speedFilterMode(c: Context): Int = prefs(c).getInt(KEY_SPEED_MODE, 0).coerceIn(0, 2)
    fun setSpeedFilterMode(c: Context, v: Int) = prefs(c).edit().putInt(KEY_SPEED_MODE, v.coerceIn(0, 2)).apply()

    /** One-tap Hyundai/Kia BVM standard side-mirror angle & clarity calibration. */
    fun applyHyundaiKiaBvmPreset(c: Context) {
        prefs(c).edit()
            .putBoolean(KEY_MIRROR_H, true)
            .putBoolean(KEY_FLIP_V, false)
            .putInt(KEY_ZOOM_PCT, 125)
            .putInt(KEY_PAN_X, 8)
            .putInt(KEY_PAN_Y, 4)
            .putInt(KEY_BRIGHTNESS, 8)
            .putInt(KEY_CONTRAST, 114)
            .putInt(KEY_SATURATION, 110)
            .putInt(KEY_SIZE_TIER, 1)
            .apply()
    }
}
