package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import com.byd.dolphin.drivealerts.camera.VehicleCameraHub
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import java.io.File
import org.json.JSONObject

/** In-app Dashcam Video Player + Synchronized Telemetry Summary + Offline GPS Track Map Viewer. */
class DashcamViewerActivity : DensityAwareActivity() {
    private lateinit var hub: VehicleCameraHub
    private lateinit var videoView: VideoView
    private lateinit var telemetryInfo: TextView
    private lateinit var mapView: GpsTrackMapView
    private lateinit var listContainer: LinearLayout
    private var showingEvents = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hub = VehicleCameraHub(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@DashcamViewerActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@DashcamViewerActivity, 16), DashboardUi.dp(this@DashcamViewerActivity, 12),
                DashboardUi.dp(this@DashcamViewerActivity, 16), DashboardUi.dp(this@DashcamViewerActivity, 24))
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "녹화 영상 · 주행 궤적 뷰어", "일반 / 이벤트 보호 · 속도·기어·브레이크 · GPS 경로")

        val accent = DashboardUi.accentColor(this)

        val playerPanel = DashboardUi.panel(
            this,
            "영상 재생 · GPS 주행 궤적 지도",
            "아래 목록에서 MP4를 선택하면 영상과 동기화된 기어·브레이크·속도·GPS 경로를 함께 확인합니다.",
            DashboardIcons.IconKind.PLAY,
            accent
        ) { p ->
            val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            videoView = VideoView(this).apply {
                setMediaController(MediaController(this@DashcamViewerActivity))
            }
            mapView = GpsTrackMapView(this)
            topRow.addView(videoView, LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 240), 1.5f).apply {
                setMargins(0, 0, DashboardUi.dp(this@DashcamViewerActivity, 8), 0)
            })
            topRow.addView(mapView, LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 240), 1f))
            p.addView(topRow)

            telemetryInfo = DashboardUi.label(this, "재생할 녹화 파일을 선택하세요.", 13f, true)
            p.addView(telemetryInfo)
        }
        playerPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, playerPanel)

        val listPanel = DashboardUi.panel(
            this,
            "녹화 파일 목록",
            "이벤트 보호 폴더의 파일은 일반 순환 삭제에서 보호됩니다.",
            DashboardIcons.IconKind.DIAG_LOG,
            DashboardUi.okColor(this)
        ) { p ->
            p.addView(DashboardUi.segmentedBar(this, listOf("일반 녹화 (normal)", "이벤트 보호 (event)"), 0, accent) { idx ->
                showingEvents = (idx == 1)
                reloadList()
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this@DashcamViewerActivity, 4), 0, DashboardUi.dp(this@DashcamViewerActivity, 8)) })
            listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            p.addView(listContainer)
        }
        listPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, listPanel)

        reloadList()
    }

    private fun reloadList() {
        listContainer.removeAllViews()
        val dir = if (showingEvents) hub.eventDir() else hub.normalDir()
        val files = hub.listMp4(dir)
        if (files.isEmpty()) {
            listContainer.addView(DashboardUi.label(this, "저장된 녹화 파일이 없습니다.", 13.5f))
            return
        }
        val accent = if (showingEvents) DashboardUi.dangerColor(this) else DashboardUi.accentColor(this)
        files.take(30).forEach { file ->
            val sizeMb = "%.1f MB".format(file.length() / (1024.0 * 1024.0))
            val hasTele = File(file.parentFile, file.nameWithoutExtension + ".jsonl").isFile
            val row = DashboardUi.actionRow(
                this,
                file.name,
                "$sizeMb · ${if (hasTele) "주행정보/GPS 포함" else "영상 전용"}",
                if (showingEvents) DashboardIcons.IconKind.SHIELD_ADB else DashboardIcons.IconKind.PLAY,
                accent,
                if (showingEvents) "보호됨" else "재생"
            ) {
                playFile(file)
            }
            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(file.name)
                    .setItems(arrayOf("영상 재생", "파일 삭제")) { _, which ->
                        if (which == 0) playFile(file)
                        else {
                            hub.deleteWithSidecars(file)
                            Toast.makeText(this, "삭제 완료", Toast.LENGTH_SHORT).show()
                            reloadList()
                        }
                    }.show()
                true
            }
            listContainer.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, DashboardUi.dp(this@DashcamViewerActivity, 3), 0, DashboardUi.dp(this@DashcamViewerActivity, 3))
            })
        }
    }

    private fun playFile(mp4: File) {
        runCatching {
            videoView.setVideoURI(Uri.fromFile(mp4))
            videoView.start()
        }.onFailure {
            Toast.makeText(this, "재생 오류: ${it.message}", Toast.LENGTH_SHORT).show()
        }
        val jsonl = File(mp4.parentFile, mp4.nameWithoutExtension + ".jsonl")
        if (!jsonl.isFile) {
            telemetryInfo.text = "${mp4.name} · 동기화된 주행 정보(.jsonl) 없음"
            mapView.setTrack(emptyList())
            return
        }
        val pts = mutableListOf<Pair<Double, Double>>()
        var maxSpd = 0.0
        var brakeSamples = 0
        var samples = 0
        val gears = linkedSetOf<String>()
        runCatching {
            jsonl.forEachLine(Charsets.UTF_8) { line ->
                if (line.isBlank()) return@forEachLine
                val o = JSONObject(line)
                samples++
                val s = o.optDouble("spd", 0.0)
                if (s > maxSpd) maxSpd = s
                if (o.optInt("brk", 0) == 1) brakeSamples++
                gears.add(o.optString("gear", "?"))
                if (o.has("lat") && o.has("lon")) {
                    pts.add(o.getDouble("lat") to o.getDouble("lon"))
                }
            }
        }
        telemetryInfo.text = "${mp4.name} · 최고속도 ${"%.1f".format(maxSpd)} km/h · 기어[${gears.joinToString(",")}] · 브레이크 ${brakeSamples}초 · GPS ${pts.size}점"
        mapView.setTrack(pts)
    }

    /** Offline Canvas GPS Route Minimap (renders clean navigation-style trajectory without internet). */
    private class GpsTrackMapView(context: Context) : View(context) {
        private var points: List<Pair<Double, Double>> = emptyList()
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0D1626.toInt() }
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1F324D.toInt(); strokeWidth = 1.5f }
        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF38D9E6.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private val startPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2EE59D.toInt() }
        private val endPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B6B.toInt() }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9BB0C9.toInt(); textSize = 26f; textAlign = Paint.Align.CENTER }

        fun setTrack(pts: List<Pair<Double, Double>>) {
            points = pts
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            canvas.drawRoundRect(0f, 0f, w, h, 20f, 20f, bgPaint)
            // Subtle navigation grid
            for (i in 1..3) {
                canvas.drawLine(w * i / 4f, 0f, w * i / 4f, h, gridPaint)
                canvas.drawLine(0f, h * i / 4f, w, h * i / 4f, gridPaint)
            }
            if (points.size < 2) {
                canvas.drawText("GPS 주행 경로 대기", w / 2f, h / 2f, textPaint)
                return
            }
            val minLat = points.minOf { it.first }; val maxLat = points.maxOf { it.first }
            val minLon = points.minOf { it.second }; val maxLon = points.maxOf { it.second }
            val spanLat = (maxLat - minLat).coerceAtLeast(0.0002)
            val spanLon = (maxLon - minLon).coerceAtLeast(0.0002)
            val pad = 28f
            fun px(lon: Double) = pad + ((lon - minLon) / spanLon).toFloat() * (w - pad * 2)
            fun py(lat: Double) = (h - pad) - ((lat - minLat) / spanLat).toFloat() * (h - pad * 2)

            val path = Path()
            points.forEachIndexed { idx, (lat, lon) ->
                val x = px(lon); val y = py(lat)
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, trackPaint)
            val first = points.first(); val last = points.last()
            canvas.drawCircle(px(first.second), py(first.first), 9f, startPaint)
            canvas.drawCircle(px(last.second), py(last.first), 10f, endPaint)
        }
    }
}
