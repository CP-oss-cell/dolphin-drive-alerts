package com.byd.dolphin.drivealerts.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.camera.BsdCameraOverlayController
import com.byd.dolphin.drivealerts.dock.ClimateAutomationController
import com.byd.dolphin.drivealerts.dock.FloatingDockController
import com.byd.dolphin.drivealerts.sentry.SentryMonitorController
import com.byd.dolphin.drivealerts.camera.SharedAvmSession
import com.byd.dolphin.drivealerts.camera.VehicleCameraHub
import com.byd.dolphin.drivealerts.camera.BsdCameraPreferences
import com.byd.dolphin.drivealerts.vehicle.TurnSignalReadback
import com.byd.dolphin.drivealerts.vehicle.LeadCarDepartureFusionDetector
import com.byd.dolphin.drivealerts.vehicle.IccLeadCarDepartureDetector
import com.byd.dolphin.drivealerts.vehicle.BsdSideFusionClassifier
import com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences
import com.byd.dolphin.drivealerts.audio.GlobalEqualizerEngine
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.ForegroundPackageMonitor
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.log.CaptureContinuity
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal
import com.byd.dolphin.drivealerts.log.ReadOnlySignalProbe
import com.byd.dolphin.drivealerts.log.AudioRouteProbe
import com.byd.dolphin.drivealerts.log.FeatureIdCatalog
import com.byd.dolphin.drivealerts.log.SystemDiagnosticsCollector
import com.byd.dolphin.drivealerts.log.TargetedSignalProbe
import com.byd.dolphin.drivealerts.ui.MainActivity
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.AlertGate
import com.byd.dolphin.drivealerts.vehicle.BydVehicleReader
import com.byd.dolphin.drivealerts.vehicle.VehicleEventDetector
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Safe-start foreground monitor.
 *
 * Important:
 * - startForeground() happens before any BYD/vendor probing.
 * - every optional vehicle/diagnostic component is initialized independently.
 * - the direct BYD listener tap is NOT created at app startup; it is enabled only when an
 *   AVAS diagnostic capture is explicitly requested. This keeps an OEM listener ABI mismatch
 *   from killing the launcher Activity.
 */
class DrivingAlertService : Service() {
    private var audio: AlertAudioPlayer? = null
    @Volatile private var lastDriveModeEvent: AlertEvent? = null
    @Volatile private var lastDriveModeMs: Long = 0L
    private var bsdCameraController: BsdCameraOverlayController? = null
    private var floatingDock: FloatingDockController? = null
    private var climateAutomation: ClimateAutomationController? = null
    private var sentryMonitor: SentryMonitorController? = null
    private var cameraHub: VehicleCameraHub? = null
    private var turnSignalReadback: TurnSignalReadback? = null
    private var leadCarDetector: LeadCarDepartureFusionDetector? = null
    private var iccLeadCarDetector: IccLeadCarDepartureDetector? = null
    private var bsdSideClassifier: BsdSideFusionClassifier? = null
    private var reader: BydVehicleReader? = null
    private var gate: AlertGate? = null
    private var detector: VehicleEventDetector? = null
    private val executor = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "byd-signal-poller") }
    private val commandExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "drive-alert-command") }
    private val referenceExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "byd-reference-listener-init") }
    private val serviceStopping = AtomicBoolean(false)
    private var task: ScheduledFuture<*>? = null
    private var tick = 0L

    private var rawLogger: RawSignalLogger? = null
    private var signalProbe: ReadOnlySignalProbe? = null
    private var targetedSignalProbe: TargetedSignalProbe? = null
    private var audioRouteProbe: AudioRouteProbe? = null
    private var featureIds: FeatureIdCatalog? = null
    private var diagnostics: SystemDiagnosticsCollector? = null
    private var bydEventTap: Any? = null
    private var nextTapRetryMs = 0L
    private var lastTapWakeRebindMs = 0L
    @Volatile private var lastReferenceRebindMs = 0L
    private val tapRetryQueued = AtomicBoolean(false)
    @Volatile private var referenceEventBridge: Any? = null
    private var foregroundPackageMonitor: ForegroundPackageMonitor? = null
    private var equalizerEngine: GlobalEqualizerEngine? = null

    override fun onCreate() {
        val t0 = android.os.SystemClock.elapsedRealtime()
        super.onCreate()

        // Meet Android's foreground-service deadline before touching BYD/vendor classes.
        runCatching { startForeground(NOTIFICATION_ID, notification()) }
            .onFailure { CoreLog.w("SERVICE", "startForeground failed: ${it.message}", it) }

        UnifiedLogCapture.recoverInterruptedSave(this)
        IgnitionAuditJournal.record(this,"MONITOR_SERVICE_CREATED", "elapsedMs=${android.os.SystemClock.elapsedRealtime()}")
        rawLogger = safeInit("RawSignalLogger") { RawSignalLogger(this) }
        activeLogger = rawLogger
        rawLogger?.marker("SERVICE_STARTED_V014_UNIFIED_LOG")
        val recovering = UnifiedLogCapture.state(this)
        if (recovering.status == UnifiedLogCapture.RECORDING && recovering.id.isNotBlank()) {
            val gap = runCatching { CaptureContinuity.serviceRestored(this, recovering.id) }
                .onFailure { rawLogger?.diagnostic("CAPTURE_JOURNAL_RESTORE_FAILED", it.javaClass.simpleName) }.getOrNull()
            rawLogger?.marker("UNIFIED_CAPTURE_PROCESS_RESUME", "id=${recovering.id} sinceHeartbeatMs=${gap ?: "unknown"}")
        }

        audio = safeInit("AlertAudioPlayer") { AlertAudioPlayer(this) }
        bsdCameraController = safeInit("BsdCameraOverlay") { BsdCameraOverlayController(applicationContext) }
        climateAutomation = safeInit("ClimateAutomation") { ClimateAutomationController(applicationContext) }
        floatingDock = safeInit("FloatingDock") { FloatingDockController(applicationContext) { cameraHub?.triggerEventLock("DOCK_MANUAL") }.also { it.refreshFromPreferences() } }
        sentryMonitor = safeInit("SentryMonitor") { SentryMonitorController(applicationContext) { reason -> cameraHub?.triggerSentryEventClip(reason) } }
        turnSignalReadback = safeInit("TurnSignalReadback") { TurnSignalReadback(applicationContext) }
        bsdSideClassifier = safeInit("BsdSideFusion") { BsdSideFusionClassifier(applicationContext) }
        cameraHub = safeInit("VehicleCameraHub") {
            VehicleCameraHub(applicationContext).apply {
                setAnalysisNeededGate {
                    (leadCarDetector?.isArmed() == true) ||
                        (BsdSideInferencePreferences.enabled(this@DrivingAlertService) &&
                            BsdSideInferencePreferences.mode(this@DrivingAlertService) != 1)
                }
                addFrameListener { img ->
                    leadCarDetector?.acceptSharedFrame(img)
                    bsdSideClassifier?.acceptSharedFrame(img)
                }
            }
        }
        SharedAvmSession.setAnalysisConsumer(
            gate = {
                (leadCarDetector?.isArmed() == true) ||
                    (sentryMonitor?.isArmed() == true) ||
                    (com.byd.dolphin.drivealerts.camera.DashcamPreferences.enabled(this@DrivingAlertService) &&
                        BsdSideInferencePreferences.enabled(this@DrivingAlertService) &&
                        BsdSideInferencePreferences.mode(this@DrivingAlertService) != 1)
            },
            consumer = { bmp ->
                leadCarDetector?.acceptSharedBitmap(bmp)
                bsdSideClassifier?.acceptSharedQuadBitmap(bmp)
                sentryMonitor?.acceptQuadBitmap(bmp)
            }
        )
        iccLeadCarDetector = safeInit("IccLeadCarDeparture") {
            IccLeadCarDepartureDetector(applicationContext) { req, reason ->
                rawLogger?.diagnostic("ICC_LEAD_CAR_DEPARTURE", reason)
                if (AlertPreferences.isEnabled(this) && AlertPreferences.eventEnabled(this, req.event)) {
                    gate?.submit(req)
                }
            }
        }
        leadCarDetector = safeInit("LeadCarDepartureFusion") {
            LeadCarDepartureFusionDetector(applicationContext) { req, reason ->
                rawLogger?.diagnostic("LEAD_CAR_DEPARTURE_FUSION", reason)
                if (AlertPreferences.isEnabled(this) && AlertPreferences.eventEnabled(this, req.event)) {
                    gate?.submit(req)
                }
            }
        }
        equalizerEngine = safeInit("GlobalEqualizerEngine") { GlobalEqualizerEngine(this).also { it.start() } }
        foregroundPackageMonitor = safeInit("ForegroundPackageMonitor") { ForegroundPackageMonitor(this).also { it.start() } }
        reader = safeInit("BydVehicleReader") { BydVehicleReader(this) }
        gate = safeInit("AlertGate") {
            AlertGate { request ->
                // User preferences gate only our extra voice; never disable OEM warnings.
                if (AlertPreferences.isEnabled(this) && AlertPreferences.eventEnabled(this, request.event)) {
                    val finalReq = if (request.event == AlertEvent.BSD_WARNING && request.side == Side.UNKNOWN) {
                        val (inferredSide, detail) = bsdSideClassifier?.resolveSide(request.side) ?: (Side.UNKNOWN to "none")
                        if (inferredSide != Side.UNKNOWN) {
                            rawLogger?.diagnostic("BSD_SIDE_FUSION", "side=$inferredSide;$detail")
                            request.copy(side = inferredSide)
                        } else request
                    } else request
                    val isDriveMode = finalReq.event == AlertEvent.DRIVE_ECO ||
                        finalReq.event == AlertEvent.DRIVE_NORMAL || finalReq.event == AlertEvent.DRIVE_SPORT
                    if (isDriveMode) {
                        val nowMs = System.currentTimeMillis()
                        if (lastDriveModeEvent == finalReq.event && nowMs - lastDriveModeMs < 2_500L) {
                            return@AlertGate
                        }
                        lastDriveModeEvent = finalReq.event
                        lastDriveModeMs = nowMs
                    }
                    audio?.play(finalReq)
                } else if (!AlertPreferences.eventEnabled(this, request.event)) {
                    rawLogger?.diagnostic("ALERT_MUTED_BY_USER", request.event.name)
                }
            }
        }
        detector = gate?.let { g -> safeInit("VehicleEventDetector") { VehicleEventDetector(g::submit) } }
        signalProbe = safeInit("ReadOnlySignalProbe") { ReadOnlySignalProbe(this) }
        targetedSignalProbe = safeInit("TargetedSignalProbe") { TargetedSignalProbe(this) }
        audioRouteProbe = safeInit("AudioRouteProbe") { AudioRouteProbe(this) }
        featureIds = safeInit("FeatureIdCatalog") { FeatureIdCatalog() }

        // Restore the normal-runtime listener path from Byd_SubAI_Beta_v13. The bridge is
        // reflection-loaded so an OEM ABI mismatch cannot stop the foreground service itself.
        val normalLogger = rawLogger
        val normalGate = gate
        if (normalLogger != null && normalGate != null) {
            lastReferenceRebindMs = android.os.SystemClock.elapsedRealtime()
            // OEM device registration may block for several seconds at ignition.
            // Keep the critical FGS/UI bootstrap responsive and register on a dedicated worker.
            referenceExecutor.execute {
              if (serviceStopping.get()) return@execute
              val started = android.os.SystemClock.elapsedRealtime()
              val bridge = safeInit("ReferenceVehicleEventBridge") { createReferenceBridge(normalLogger, normalGate) }
              if (serviceStopping.get()) {
                  runCatching { bridge?.javaClass?.getMethod("close")?.invoke(bridge) }
              } else {
                  referenceEventBridge = bridge
                  rawLogger?.diagnostic("REFERENCE_LISTENER_ASYNC_READY", "durationMs=${android.os.SystemClock.elapsedRealtime()-started};success=${bridge!=null}")
              }
            }
        }

        val logger = rawLogger
        val ids = featureIds
        if (logger != null && ids != null) {
            diagnostics = safeInit("SystemDiagnosticsCollector") { SystemDiagnosticsCollector(this, logger, ids) }
        }
        activeDiagnostics = diagnostics

        audioRouteProbe?.let { probe ->
            runCatching { rawLogger?.recordAudioRoute(probe.snapshot()) }
                .onFailure { CoreLog.w("SERVICE", "initial audio route failed: ${it.message}") }
        }

        // Keep the OEM subclass out of normal service startup. Only a user-started,
        // persistently RECORDING session authorizes recovering this optional listener.
        if (recovering.status == UnifiedLogCapture.RECORDING && recovering.id.isNotBlank()) {
            commandExecutor.execute { rebindCaptureTap("process-restart", force = false) }
        }
        if (reader != null && detector != null && rawLogger != null) {
            task = executor.scheduleAtFixedRate(::sampleSafely, 0, 150, TimeUnit.MILLISECONDS)
            CoreLog.i("SERVICE", "SERVICE_MONITOR_READY uptimeMs=${android.os.SystemClock.elapsedRealtime()} initDurationMs=${android.os.SystemClock.elapsedRealtime()-t0}")
            rawLogger?.diagnostic("SERVICE_INIT_DURATION", "${android.os.SystemClock.elapsedRealtime()-t0}ms")
        } else {
            rawLogger?.diagnostic("SERVICE_PARTIAL_START", startupStatus())
            CoreLog.w("SERVICE", "partial start: ${startupStatus()}")
        }
    }

    private fun <T> safeInit(name: String, block: () -> T): T? =
        try {
            block().also {
                rawLogger?.diagnostic("INIT_OK", name)
                CoreLog.i("SERVICE", "init ok: $name")
            }
        } catch (t: Throwable) {
            rawLogger?.diagnostic("INIT_FAILED", "$name:${t.javaClass.simpleName}:${t.message}")
            CoreLog.w("SERVICE", "init failed $name: ${t.message}", t)
            null
        }

    private fun startupStatus(): String =
        "audio=${audio != null},reader=${reader != null},gate=${gate != null},detector=${detector != null}," +
            "logger=${rawLogger != null},probe=${signalProbe != null},targeted=${targetedSignalProbe != null},route=${audioRouteProbe != null}," +
            "featureIds=${featureIds != null},reference=${referenceEventBridge != null},diag=${diagnostics != null}"

    private fun ensureBydEventTap(): Boolean {
        if (bydEventTap != null) return true
        val logger = rawLogger ?: return false
        val ids = featureIds ?: return false
        return try {
            // Keep OEM listener subclasses completely out of normal service class verification.
            // They are loaded only when AVAS diagnostics are explicitly requested.
            val c = Class.forName("com.byd.dolphin.drivealerts.log.BydEventTap")
            val ctor = c.getConstructor(Context::class.java, RawSignalLogger::class.java, FeatureIdCatalog::class.java)
            val tap = ctor.newInstance(this, logger, ids)
            c.getMethod("start").invoke(tap)
            val active = c.getMethod("hasActiveBindings").invoke(tap) as? Boolean ?: false
            if (!active) {
                logger.diagnostic("BYD_EVENT_TAP_LAZY_EMPTY", "No compatible OEM listener could register")
                runCatching { c.getMethod("close").invoke(tap) }
                return false
            }
            bydEventTap = tap
            logger.diagnostic("BYD_EVENT_TAP_LAZY_STARTED", "reflection-ok")
            true
        } catch (t: Throwable) {
            logger.diagnostic("BYD_EVENT_TAP_LAZY_FAILED", "${t.javaClass.simpleName}:${t.cause?.message ?: t.message}")
            CoreLog.w("BYD_EVENT_TAP", "lazy start failed: ${t.cause?.message ?: t.message}", t)
            false
        }
    }


    /** Serialized with capture begin/end: boot can rebind a stale OEM listener after MCU sleep. */
    private fun rebindCaptureTap(reason: String, force: Boolean) {
        val state = UnifiedLogCapture.state(this)
        if (state.status != UnifiedLogCapture.RECORDING || state.id.isBlank()) return
        val now = System.currentTimeMillis()
        val hardAttempt = force && now - lastTapWakeRebindMs >= 8_000L
        if (hardAttempt) lastTapWakeRebindMs = now
        if (hardAttempt && bydEventTap != null) {
            runCatching {
                bydEventTap?.let { tap ->
                    tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
                }
            }.onFailure { rawLogger?.diagnostic("UNIFIED_TAP_CLOSE_FAILED", it.javaClass.simpleName) }
            bydEventTap = null
        }
        if (bydEventTap == null && (hardAttempt || now >= nextTapRetryMs)) {
            val ok = ensureBydEventTap()
            // Registration alone is not proof that callbacks were received or AVAS played.
            runCatching { CaptureContinuity.tapState(this, state.id,
                if (ok) "REGISTERED_UNCONFIRMED" else "RETRY_PENDING", "reason=$reason") }
            rawLogger?.marker("UNIFIED_TAP_RECONNECT", "id=${state.id} registered=$ok reason=$reason")
            nextTapRetryMs = if (ok) 0L else now + 30_000L
        }
    }

    /** Launch user-selected app or split profile on steering wheel multi-tap (replaces legacy voice). */
    private fun launchSelectedSteeringApp(source: String) {
        val target = SteeringTriggerPreferences.launchTargetPackage(this)
        if (target.isBlank()) {
            CoreLog.w("STEERING", "STEERING_LAUNCH_NO_TARGET source=$source")
            rawLogger?.diagnostic("STEERING_LAUNCH_NO_TARGET", "source=$source")
            return
        }
        CoreLog.i("STEERING", "STEERING_APP_LAUNCH target=$target source=$source")
        rawLogger?.marker("STEERING_APP_LAUNCH", "target=$target;source=$source")
        Thread({
            if (target.startsWith("split:")) {
                val id = target.removePrefix("split:")
                val profile = com.byd.dolphin.drivealerts.automation.FeatureProfiles.splits(applicationContext)
                    .firstOrNull { it.id == id }
                if (profile != null) {
                    val res = com.byd.dolphin.drivealerts.automation.AutoSplitBehaviorEngine.launch(applicationContext, profile)
                    CoreLog.i("STEERING", "STEERING_SPLIT_LAUNCH id=$id ok=${res.success} msg=${res.message}")
                }
                return@Thread
            }
            val started = runCatching {
                val intent = packageManager.getLaunchIntentForPackage(target) ?: error("no_launch_intent")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                true
            }.getOrDefault(false)
            if (!started) {
                val comp = com.byd.dolphin.drivealerts.automation.AppSelection.safeComponent(applicationContext, target)
                if (comp != null && com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime.health(applicationContext).state ==
                    com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime.State.READY) {
                    val res = com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime.writeOnce(applicationContext, "am start --user 0 -n '$comp'", 8_000L).result
                    CoreLog.i("STEERING", "STEERING_ADB_LAUNCH target=$target ok=${res.success}")
                }
            }
        }, "dolphin-steering-launch").start()
    }

    private fun createReferenceBridge(normalLogger: RawSignalLogger, normalGate: AlertGate): Any {
                val c = Class.forName("com.byd.dolphin.drivealerts.vehicle.ReferenceVehicleEventBridge")
                val ctor = c.getConstructor(Context::class.java, RawSignalLogger::class.java, AlertGate::class.java, Runnable::class.java)
                val tripleTap = Runnable {
                    if (SteeringTriggerPreferences.enabled(this) &&
                        com.byd.dolphin.drivealerts.steering.SteeringPlaybackGuard.allow()) {
                        normalLogger.marker("STEERING_TRIPLE_TAP_PLAY", "SubAI INSTRUMENT_2IN1_MENU_STATE")
                        launchSelectedSteeringApp("subai-reference-menu-triple")
                    } else normalLogger.diagnostic("STEERING_DUPLICATE_SUPPRESSED", "source=SubAI")
                }
                return ctor.newInstance(this, normalLogger, normalGate, tripleTap).also { c.getMethod("start").invoke(it) }
    }

    /** Rebind normal ADAS/energy/pilot listeners on ignition after vendor binder sleep.
     *  Serialized off the main thread; this does not alter ECU state or issue setters. */
    private fun rebindReferenceListeners(wake: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastReferenceRebindMs < 8_000L || serviceStopping.get()) return
        lastReferenceRebindMs = now
        referenceExecutor.execute {
            if (serviceStopping.get()) return@execute
            val bridge = referenceEventBridge
            if (bridge == null) {
                val logger = rawLogger
                val alertGate = gate
                if (logger != null && alertGate != null) {
                    referenceEventBridge = safeInit("ReferenceVehicleEventBridgeWake") {
                        createReferenceBridge(logger, alertGate)
                    }
                    logger.diagnostic("REFERENCE_WAKE_RECREATE",
                        "source=$wake;created=${referenceEventBridge != null};callbacksStillUnconfirmed=true")
                }
                return@execute
            }
            runCatching {
                bridge.javaClass.getMethod("close").invoke(bridge)
                bridge.javaClass.getMethod("start").invoke(bridge)
                rawLogger?.diagnostic("REFERENCE_WAKE_REBIND_ATTEMPTED",
                    "source=$wake;callbackReceptionNotYetConfirmed=true")
            }.onFailure {
                rawLogger?.diagnostic("REFERENCE_WAKE_REBIND_FAILED", "source=$wake;${it.javaClass.simpleName}:${it.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
            ACTION_POWER_OFF_FLUSH -> { runCatching { cameraHub?.flushForPowerOff() }; return START_STICKY }
                null -> {
                    // BootReceiver's plain start() also reaches an already-running FGS.
                    // Rebind normal OEM listeners there (capture may not be enabled).
                    rebindReferenceListeners("normal-boot-service-start")
                }
                ACTION_TEST_ALERT -> {
                    val event = intent.getStringExtra(EXTRA_EVENT)?.let { runCatching { AlertEvent.valueOf(it) }.getOrNull() }
                    val side = intent.getStringExtra(EXTRA_SIDE)?.let { runCatching { Side.valueOf(it) }.getOrNull() } ?: Side.UNKNOWN
                    if (event != null) gate?.submit(AlertRequest(event, side))
                }

                ACTION_PLAY_ONE_SHOT -> {
                    val source = intent.getStringExtra(EXTRA_SOURCE) ?: "unknown"
                    rawLogger?.marker("ONE_SHOT_PLAY_REQUEST", source)
                    launchSelectedSteeringApp(source)
                }

                ACTION_MARKER -> {
                    rawLogger?.marker(
                        intent.getStringExtra(EXTRA_LABEL) ?: "MARKER",
                        intent.getStringExtra(EXTRA_DETAIL)
                    )
                }

                ACTION_REFRESH_DOCK -> { floatingDock?.refreshFromPreferences() }
            ACTION_REFRESH_EQ -> {
                    equalizerEngine?.refresh()
                    rawLogger?.marker("EQ_REFRESH", "user/settings")
                }

                ACTION_CAPTURE_BEGIN -> {
                    IgnitionAuditJournal.record(this,"CAPTURE_BEGIN_RECEIVED", "enqueue=true")
                    commandExecutor.execute {
                        val result = UnifiedLogCapture.begin(this, rawLogger, diagnostics)
                        IgnitionAuditJournal.record(this,"CAPTURE_BEGIN_RESULT", "result=${result.take(180)}")
                        rebindCaptureTap("manual-start", force = false)
                        updateNotification(result)
                    }
                }

                ACTION_CAPTURE_WAKE -> {
                    val source = intent.getStringExtra(EXTRA_WAKE_SOURCE) ?: "unknown"
                    commandExecutor.execute {
                        val current = UnifiedLogCapture.state(this)
                        if (current.status == UnifiedLogCapture.RECORDING) {
                            rawLogger?.marker("UNIFIED_CAPTURE_IGNITION_WAKE", "id=${current.id} action=$source")
                            val hardWake = source == "com.byd.action.ACC_ON" || source == "com.byd.action.IGN_ON" ||
                                source == Intent.ACTION_BOOT_COMPLETED || source.contains("QUICKBOOT_POWERON")
                            rebindCaptureTap("ignition:$source", force = hardWake)
                            if (hardWake) rebindReferenceListeners("capture-ignition:$source")
                        }
                    }
                }

                ACTION_CAPTURE_END -> {
                    IgnitionAuditJournal.record(this,"CAPTURE_END_RECEIVED", "enqueue=true")
                    commandExecutor.execute {
                        val result = UnifiedLogCapture.finish(this, rawLogger, diagnostics)
                        IgnitionAuditJournal.record(this,"CAPTURE_END_RESULT", "ok=${result.isSuccess} type=${result.exceptionOrNull()?.javaClass?.simpleName ?: "none"}")
                        nextTapRetryMs = 0L
                        runCatching {
                            bydEventTap?.let { tap ->
                                tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
                            }
                            bydEventTap = null
                        }.onFailure { CoreLog.w("UNIFIED_LOG", "tap stop failed: ${it.message}", it) }
                        updateNotification(result.fold(
                            { "수집 종료 · 저장 완료: $it" },
                            { "로그 저장 실패: ${it.message ?: it.javaClass.simpleName}" }
                        ))
                    }
                }

                ACTION_CAPTURE_STEERING -> {
                    val seconds = intent.getIntExtra(EXTRA_SECONDS, 10)
                    diagnostics?.captureSteeringKeyWindow(seconds)
                }

                ACTION_CAPTURE_DEEP -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "DEEP"
                    rawLogger?.marker(label)
                    diagnostics?.captureDeep(label)
                }

                ACTION_CAPTURE_QUICK -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "QUICK"
                    rawLogger?.marker(label)
                    diagnostics?.captureQuick(label)
                }

                ACTION_CAPTURE_WINDOW -> {
                    ensureBydEventTap()
                    val label = intent.getStringExtra(EXTRA_LABEL) ?: "WINDOW"
                    val seconds = intent.getIntExtra(EXTRA_SECONDS, 12)
                    diagnostics?.captureWindow(label, seconds)
                }

                ACTION_EXPORT -> {
                    val logger = rawLogger
                    if (logger != null) {
                        commandExecutor.execute {
                            val result = com.byd.dolphin.drivealerts.log.DiagnosticsExporter
                                .exportToDownloads(this, logger, diagnostics)
                            logger.diagnostic(
                                if (result.isSuccess) "EXPORT_OK" else "EXPORT_FAILED",
                                result.fold({ it }, { "${it.javaClass.simpleName}:${it.message}" })
                            )
                            updateNotification(
                                result.fold(
                                    { "로그 생성 완료: $it" },
                                    { "로그 생성 실패: ${it.message ?: it.javaClass.simpleName}" }
                                )
                            )
                        }
                    } else {
                        updateNotification("로그 생성 실패: logger unavailable")
                    }
                }
            }
        } catch (t: Throwable) {
            rawLogger?.diagnostic("COMMAND_FAILED", "${intent?.action}:${t.javaClass.simpleName}:${t.message}")
            CoreLog.w("SERVICE", "command failed ${intent?.action}: ${t.message}", t)
        }
        return START_STICKY
    }

    private fun sampleSafely() {
        try {
            val r = reader ?: return
            val d = detector ?: return
            val logger = rawLogger ?: return

            val frame = r.readFrame()
            val currentTick = ++tick
            val energy = if (currentTick % 4L == 0L) r.readReferenceEnergySignals() else emptyMap()
            val probe = if (currentTick % 7L == 0L) {
                linkedMapOf<String, String>().apply {
                    putAll(signalProbe?.snapshot().orEmpty())
                    putAll(targetedSignalProbe?.snapshot().orEmpty())
                }
            } else emptyMap()

            if (currentTick % 7L == 0L) {
                audioRouteProbe?.let { route ->
                    runCatching { logger.recordAudioRoute(route.snapshot()) }
                }
            }

            logger.record(frame, energy, probe)
            if (currentTick % 200L == 0L) {
                val bridge = referenceEventBridge
                if (bridge != null) runCatching {
                    val health = bridge.javaClass.getMethod("callbackHealth").invoke(bridge)
                    logger.diagnostic("REFERENCE_CALLBACK_HEALTH", "$health;listenerRegisteredNotSufficient=true")
                }.onFailure { logger.diagnostic("REFERENCE_CALLBACK_HEALTH_FAILED", it.javaClass.simpleName) }
                val tap = bydEventTap
                if (tap != null) runCatching {
                    val reception = tap.javaClass.getMethod("healthSnapshot").invoke(tap)
                    logger.diagnostic("BYD_CALLBACK_HEALTH", "$reception;bindingDoesNotProveAllDomains=true")
                }.onFailure { logger.diagnostic("BYD_CALLBACK_HEALTH_FAILED", it.javaClass.simpleName) }
            }
            if (currentTick % 7L == 0L) {
              val capture = UnifiedLogCapture.state(this)
              if (capture.status == UnifiedLogCapture.RECORDING) {
                runCatching { CaptureContinuity.heartbeat(this, capture.id) }
                    .onFailure { logger.diagnostic("CAPTURE_HEARTBEAT_FAILED", it.javaClass.simpleName) }
                // Retry only an absent tap; never reset a healthy binding during sampling.
                if (bydEventTap == null && System.currentTimeMillis() >= nextTapRetryMs &&
                    tapRetryQueued.compareAndSet(false, true)) {
                    commandExecutor.execute {
                        try { rebindCaptureTap("retry", force = false) }
                        finally { tapRetryQueued.set(false) }
                    }
                }
              }
            }
            if (currentTick % 8L == 0L) {
                runCatching {
                    referenceEventBridge?.javaClass?.getMethod("pollNormalOperationMode")?.invoke(referenceEventBridge)
                }.onFailure { logger.diagnostic("NORMAL_READBACK_POLL_FAILED", "${it.javaClass.simpleName}:${it.message}") }
            }
            d.accept(frame, energy)
            if (BsdSideInferencePreferences.enabled(this)) {
                runCatching {
                    val bSide = turnSignalReadback?.read()?.side ?: Side.UNKNOWN
                    bsdSideClassifier?.accept(frame, bSide)
                }.onFailure { logger.diagnostic("BSD_SIDE_POLL_FAILED", it.javaClass.simpleName) }
            }
                        runCatching { iccLeadCarDetector?.accept(frame) }
                .onFailure { logger.diagnostic("ICC_LEAD_POLL_FAILED", it.javaClass.simpleName) }
            runCatching { leadCarDetector?.accept(frame) }
                .onFailure { logger.diagnostic("LEAD_DEP_POLL_FAILED", it.javaClass.simpleName) }
            runCatching {
                val curBlinker = turnSignalReadback?.read()?.side ?: Side.UNKNOWN
                climateAutomation?.onVehicleFrame(frame, curBlinker)
                sentryMonitor?.onVehicleFrame(frame)
                cameraHub?.onVehicleState(frame, curBlinker, bsdCameraController?.isOverlayActive() == true)
            }.onFailure { logger.diagnostic("DASHCAM_HUB_POLL_FAILED", it.javaClass.simpleName) }
            if (BsdCameraPreferences.enabled(this)) {
                runCatching {
                    val reading = turnSignalReadback?.read()
                    val isReverse = frame.gearRaw == 1
                    bsdCameraController?.onVehicleTurnState(reading?.side ?: Side.UNKNOWN, isReverse, frame.speedKmH)
                }.onFailure { logger.diagnostic("BSD_CAM_POLL_FAILED", it.javaClass.simpleName) }
            }
            // A blinker may be activated AFTER BSD is already active. Re-check while
            // active, without polling another device or blindly announcing hazards.
            // Inspect the pulsed blinkers every 150 ms while a BSD event is active.
            // A 450 ms poll could repeatedly land on the OFF portion of a blinker pulse.
            runCatching {
                referenceEventBridge?.javaClass?.getMethod("pollBsdWithIndicator")?.invoke(referenceEventBridge)
            }.onFailure { logger.diagnostic("BSD_INDICATOR_POLL_FAILED", it.javaClass.simpleName) }
            if (currentTick % 3L == 0L) {
                runCatching {
                    referenceEventBridge?.javaClass?.getMethod("pollAutoHoldEngagement")?.invoke(referenceEventBridge)
                }.onFailure { logger.diagnostic("AUTOHOLD_ENGAGEMENT_POLL_FAILED", it.javaClass.simpleName) }
            }
        } catch (t: Throwable) {
            CoreLog.w("SERVICE", "sample failed: ${t.message}", t)
            rawLogger?.diagnostic("SAMPLE_FAILED", "${t.javaClass.simpleName}:${t.message}")
        }
    }



    override fun onTaskRemoved(rootIntent: Intent?) {
        rawLogger?.marker("TASK_REMOVED_KEEP_SERVICE")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        serviceStopping.set(true)
        runCatching { bsdCameraController?.shutdown() }
        runCatching { leadCarDetector?.shutdown() }
        runCatching { bsdSideClassifier?.shutdown() }
        runCatching { iccLeadCarDetector?.shutdown() }
        runCatching { cameraHub?.shutdown() }
        referenceExecutor.shutdownNow()
        task?.cancel(true)
        executor.shutdownNow()
        commandExecutor.shutdownNow()
        rawLogger?.marker("SERVICE_STOPPED")
        IgnitionAuditJournal.record(this,"MONITOR_SERVICE_DESTROYED", "capture=${UnifiedLogCapture.state(this).status}")
        runCatching {
            bydEventTap?.let { tap ->
                tap.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(tap)
            }
        }
        runCatching {
            referenceEventBridge?.let { bridge ->
                bridge.javaClass.methods.firstOrNull { it.name == "close" && it.parameterCount == 0 }?.invoke(bridge)
            }
        }
        runCatching { diagnostics?.close() }
        runCatching { foregroundPackageMonitor?.close() }
        runCatching { sentryMonitor?.shutdown() }
        runCatching { SharedAvmSession.shutdown() }
        runCatching { climateAutomation?.shutdown() }
        runCatching { floatingDock?.shutdown() }
        runCatching { equalizerEngine?.close() }
        runCatching { targetedSignalProbe?.close() }
        runCatching { rawLogger?.close() }
        activeLogger = null
        activeDiagnostics = null
        runCatching { audio?.shutdown() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String = "BYD 차량 신호 감시 · SAFE START") : Notification {
        val channelId = "drive_alert_core"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "주행 보조 알림", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("주행 보조 알림 작동 중")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
        }
    }

    companion object {
        const val ACTION_POWER_OFF_FLUSH = "com.byd.dolphin.drivealerts.POWER_OFF_FLUSH"
        const val ACTION_SENTRY_HEARTBEAT = "com.byd.dolphin.drivealerts.SENTRY_HEARTBEAT"
        fun pulseSentryWake(context: Context) {
            runCatching { launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_SENTRY_HEARTBEAT)) }
        }
        fun flushDashcamForPowerOff(context: Context) {
            runCatching {
                context.startService(Intent(context, DrivingAlertService::class.java).setAction(ACTION_POWER_OFF_FLUSH))
            }
        }
        const val ACTION_TEST_ALERT = "com.byd.dolphin.drivealerts.TEST_ALERT"
        const val ACTION_PLAY_ONE_SHOT = "com.byd.dolphin.drivealerts.PLAY_ONE_SHOT"
        const val ACTION_MARKER = "com.byd.dolphin.drivealerts.MARKER"
        const val ACTION_REFRESH_EQ = "com.byd.dolphin.drivealerts.REFRESH_EQ"
        const val ACTION_REFRESH_DOCK = "com.byd.dolphin.drivealerts.REFRESH_DOCK"
        const val ACTION_CAPTURE_STEERING = "com.byd.dolphin.drivealerts.CAPTURE_STEERING"
        const val ACTION_CAPTURE_DEEP = "com.byd.dolphin.drivealerts.CAPTURE_DEEP"
        const val ACTION_CAPTURE_QUICK = "com.byd.dolphin.drivealerts.CAPTURE_QUICK"
        const val ACTION_CAPTURE_WINDOW = "com.byd.dolphin.drivealerts.CAPTURE_WINDOW"
        const val ACTION_EXPORT = "com.byd.dolphin.drivealerts.EXPORT" // legacy, not exposed in UI
        const val ACTION_CAPTURE_BEGIN = "com.byd.dolphin.drivealerts.UNIFIED_CAPTURE_BEGIN"
        const val ACTION_CAPTURE_END = "com.byd.dolphin.drivealerts.UNIFIED_CAPTURE_END"

        const val EXTRA_EVENT = "event"
        const val EXTRA_SIDE = "side"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_LABEL = "label"
        const val EXTRA_DETAIL = "detail"
        const val EXTRA_SECONDS = "seconds"
        const val ACTION_CAPTURE_WAKE = "com.byd.dolphin.drivealerts.CAPTURE_WAKE"
        const val EXTRA_WAKE_SOURCE = "wake_source"

        private const val NOTIFICATION_ID = 1414

        @Volatile var activeLogger: RawSignalLogger? = null
            private set
        @Volatile var activeDiagnostics: SystemDiagnosticsCollector? = null
            private set

        private fun launch(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }

        fun start(context: Context) = launch(context, Intent(context, DrivingAlertService::class.java))

        fun wakeRecording(context: Context, source: String) = launch(context,
            Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_WAKE)
                .putExtra(EXTRA_WAKE_SOURCE, source))

        fun test(context: Context, event: AlertEvent, side: Side = Side.UNKNOWN) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_TEST_ALERT)
                    .putExtra(EXTRA_EVENT, event.name)
                    .putExtra(EXTRA_SIDE, side.name)
            )

        fun playOneShot(context: Context, source: String = "manual") =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_PLAY_ONE_SHOT)
                    .putExtra(EXTRA_SOURCE, source)
            )

        fun marker(context: Context, label: String, detail: String? = null) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_MARKER)
                    .putExtra(EXTRA_LABEL, label)
                    .putExtra(EXTRA_DETAIL, detail)
            )

        fun refreshDock(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_REFRESH_DOCK))

        fun refreshEqualizer(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_REFRESH_EQ))

        fun captureSteering(context: Context, seconds: Int = 10) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_STEERING)
                    .putExtra(EXTRA_SECONDS, seconds)
            )

        fun captureDeep(context: Context, label: String) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_DEEP)
                    .putExtra(EXTRA_LABEL, label)
            )

        fun captureQuick(context: Context, label: String) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_QUICK)
                    .putExtra(EXTRA_LABEL, label)
            )

        fun captureWindow(context: Context, label: String, seconds: Int = 12) =
            launch(
                context,
                Intent(context, DrivingAlertService::class.java)
                    .setAction(ACTION_CAPTURE_WINDOW)
                    .putExtra(EXTRA_LABEL, label)
                    .putExtra(EXTRA_SECONDS, seconds)
            )

        fun beginUnifiedCapture(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_BEGIN))

        fun endUnifiedCapture(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_CAPTURE_END))

        fun export(context: Context) =
            launch(context, Intent(context, DrivingAlertService::class.java).setAction(ACTION_EXPORT))
    }
}
