package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.camera.FrontCameraDepartureAnalyzer
import android.graphics.Bitmap
import android.media.Image
import com.byd.dolphin.drivealerts.camera.SharedAvmSession
import com.byd.dolphin.drivealerts.camera.TfliteLeadCarDetector
import com.byd.dolphin.drivealerts.camera.DashcamPreferences
import com.byd.dolphin.drivealerts.camera.LeadCarDeparturePreferences
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Sensor-fused lead-car departure detector combining:
 * 1. Vehicle stopped-in-D arming gate (gearRaw == 2 && speedKmH <= 0.8 for >= 1.5s)
 * 2. Front radar/ultrasonic obstacle distance clearing (BYDAutoRadarDevice)
 * 3. Front Camera2 YUV ROI normalized motion analysis (FrontCameraDepartureAnalyzer)
 * Zero ECU/CAN writes. Immediately releases Camera2 whenever moving or shifting out of D.
 */
class LeadCarDepartureFusionDetector(
    context: Context,
    private val onDepartureConfirmed: (request: AlertRequest, reason: String) -> Unit
) {
    private val app = context.applicationContext
    private val cameraAnalyzer = FrontCameraDepartureAnalyzer(app) { score, detail ->
        onCameraSignal(score, detail)
    }
    private val tfliteDetector = TfliteLeadCarDetector(app)

    @Volatile private var stoppedSinceMs: Long = 0L
    @Volatile private var armed: Boolean = false
    fun isArmed(): Boolean = armed
    @Volatile private var lastFiredMs: Long = 0L

    // Front radar tracking
    private var radarBaselineCm: Int? = null
    private var radarPresentSinceMs: Long = 0L
    private var radarClearingSinceMs: Long = 0L
    @Volatile private var lastSensorDepartureMs: Long = 0L
    @Volatile private var lastCameraDepartureMs: Long = 0L

    @Volatile var statusText: String = "대기 중"
        private set

    fun accept(frame: RawVehicleFrame) {
        if (!LeadCarDeparturePreferences.enabled(app)) {
            disarm("disabled")
            return
        }
        val now = frame.timestampMs
        val inDrive = frame.gearRaw == 2 // VehicleEventDetector: 2 -> GEAR_D
        val speed = frame.speedKmH
        val isStopped = inDrive && speed != null && speed <= 0.8f

        if (!isStopped) {
            if (armed || stoppedSinceMs != 0L) disarm(if (!inDrive) "gear_not_D" else "vehicle_moving")
            return
        }

        if (stoppedSinceMs == 0L) stoppedSinceMs = now
        if (!armed && now - stoppedSinceMs >= 1_500L) {
            armed = true
            radarBaselineCm = null
            radarPresentSinceMs = 0L
            radarClearingSinceMs = 0L
            val mode = LeadCarDeparturePreferences.mode(app)
            if (mode != 2) { // mode 2 = sensor only
                tfliteDetector.resetTracking()
                if (DashcamPreferences.enabled(app)) {
                    cameraAnalyzer.resetBaseline()
                } else if (SharedAvmSession.isAvailable(app)) {
                    SharedAvmSession.acquireLeadOnDemand(app)
                } else {
                    cameraAnalyzer.startIfPermitted()
                }
            }
            statusText = "정차 무장 완료 (앞차 감시 중)"
            CoreLog.i("LEAD_DEP", "ARMED mode=$mode speed=$speed")
        }

        if (!armed) return

        // Evaluate front radar channels (first 4 channels, valid positive distances <= 250cm)
        val mode = LeadCarDeparturePreferences.mode(app)
        if (mode != 1) { // mode 1 = camera only
            evaluateFrontRadar(frame.radarDistances, now)
        }
    }

    private fun evaluateFrontRadar(distances: IntArray?, now: Long) {
        if (distances == null || distances.isEmpty()) return
        val frontCount = minOf(4, distances.size)
        var minFront = Int.MAX_VALUE
        for (i in 0 until frontCount) {
            val d = distances[i]
            if (d in 1..250 && d < minFront) minFront = d
        }
        val hasFrontTarget = minFront <= 185

        val base = radarBaselineCm
        if (base == null) {
            if (hasFrontTarget) {
                if (radarPresentSinceMs == 0L) radarPresentSinceMs = now
                if (now - radarPresentSinceMs >= 800L) {
                    radarBaselineCm = minFront
                    statusText = "전방 센서 앞차 포착 (${minFront}cm)"
                    CoreLog.i("LEAD_DEP", "FRONT_RADAR_LOCKED baselineCm=$minFront")
                }
            } else {
                radarPresentSinceMs = 0L
            }
            return
        }

        val deltaThreshold = when (LeadCarDeparturePreferences.sensitivity(app)) {
            0 -> 35 // 둔감
            2 -> 18 // 민감
            else -> 25 // 보통
        }
        val departedBySensor = !hasFrontTarget || (minFront - base >= deltaThreshold)
        if (departedBySensor) {
            if (radarClearingSinceMs == 0L) radarClearingSinceMs = now
            if (now - radarClearingSinceMs >= 450L) {
                lastSensorDepartureMs = now
                radarBaselineCm = null
                radarPresentSinceMs = 0L
                radarClearingSinceMs = 0L
                val detail = "frontRadar base=${base}cm -> now=${if (hasFrontTarget) "${minFront}cm" else "CLEAR"}"
                CoreLog.i("LEAD_DEP", "SENSOR_DEPARTURE $detail")
                tryEmit("FRONT_SENSOR", detail, now)
            }
        } else {
            radarClearingSinceMs = 0L
            // Update baseline gently if lead car creeps closer
            if (minFront < base) radarBaselineCm = minFront
        }
    }

    private fun onCameraSignal(score: Float, detail: String) {
        if (!armed) return
        val now = System.currentTimeMillis()
        lastCameraDepartureMs = now
        tryEmit("FRONT_CAMERA", "score=${"%.1f".format(score)} $detail", now)
    }

    private fun tryEmit(source: String, detail: String, now: Long) {
        if (!armed) return
        if (now - lastFiredMs < 6_000L) return

        val mode = LeadCarDeparturePreferences.mode(app)
        val allow = when (mode) {
            0 -> true // Fusion OR: either verified sensor or camera triggers
            1 -> source == "FRONT_CAMERA"
            2 -> source == "FRONT_SENSOR"
            3 -> (now - lastSensorDepartureMs <= 2_500L) && (now - lastCameraDepartureMs <= 2_500L)
            else -> true
        }
        if (!allow) {
            statusText = "$source 감지됨 (교차 확인 대기 중)"
            return
        }

        lastFiredMs = now
        statusText = "앞차 출발 감지 ($source)"
        CoreLog.i("LEAD_DEP", "EMIT_LEAD_CAR_DEPARTURE source=$source mode=$mode $detail")
        onDepartureConfirmed(AlertRequest(AlertEvent.LEAD_CAR_DEPARTURE), "fusion=$source;mode=$mode;$detail")
    }

    private fun disarm(reason: String) {
        if (armed) CoreLog.i("LEAD_DEP", "DISARMED reason=$reason")
        stoppedSinceMs = 0L
        armed = false
        radarBaselineCm = null
        radarPresentSinceMs = 0L
        radarClearingSinceMs = 0L
        cameraAnalyzer.stop()
        SharedAvmSession.releaseLeadOnDemand()
        tfliteDetector.releaseInterpreter()
        statusText = "대기 중 ($reason)"
    }

    /** Receive shared YUV frame from VehicleCameraHub when dashcam is active (zero extra camera open). */
    /** Receive 320x240 front-quadrant bitmap from SharedAvmSession (only called while armed at 4fps). */
    fun acceptSharedBitmap(bmp: Bitmap) {
        if (!armed) return
        val res = tfliteDetector.analyzeFrontBitmap(bmp, LeadCarDeparturePreferences.sensitivity(app))
        if (res.departed) {
            onCameraSignal(100f, "${res.mode}: ${res.detail}")
        } else if (res.detected) {
            statusText = "앞차 감시 중 (${res.mode} · ${res.detail})"
        }
    }

    fun acceptSharedFrame(img: Image) {
        if (!armed) return
        if (!LeadCarDeparturePreferences.enabled(app)) return
        if (LeadCarDeparturePreferences.mode(app) == 2) return
        cameraAnalyzer.acceptExternalImage(img)
    }

    fun shutdown() {
        disarm("shutdown")
    }
}
