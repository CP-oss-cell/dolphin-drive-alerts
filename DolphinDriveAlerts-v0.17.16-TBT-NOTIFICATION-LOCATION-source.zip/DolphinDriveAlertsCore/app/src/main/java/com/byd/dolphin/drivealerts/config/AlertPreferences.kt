package com.byd.dolphin.drivealerts.config

import android.content.Context
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.OutputRoute

object AlertPreferences {
    private const val PREF = "drive_alert_core"
    private const val KEY_ROUTE = "route"
    private const val KEY_STYLE = "style"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_AUTOSTART = "auto_start"
    private const val KEY_BSD_INDICATOR = "bsd_blinker_enabled"
    private const val KEY_BSD_INSTANT = "bsd_instant_enabled"

    fun route(context: Context): OutputRoute = runCatching {
        OutputRoute.valueOf(prefs(context).getString(KEY_ROUTE, OutputRoute.DRIVER_STREAM14.name)!!)
    }.getOrDefault(OutputRoute.DRIVER_STREAM14)

    fun setRoute(context: Context, route: OutputRoute) =
        prefs(context).edit().putString(KEY_ROUTE, route.name).apply()

    fun style(context: Context): AlertStyle = runCatching {
        AlertStyle.valueOf(prefs(context).getString(KEY_STYLE, AlertStyle.FEMALE.name)!!)
    }.getOrDefault(AlertStyle.FEMALE)

    fun setStyle(context: Context, style: AlertStyle) =
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

    /** Enabled by default: after first install/open, vehicle boot/quick-boot starts the service automatically. */
    fun autoStartEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTOSTART, true)
    fun setAutoStartEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_AUTOSTART, enabled).apply()

    /** Left/right *blinker* presence only; does NOT identify BSD hazard side. */
    fun bsdBlinkerEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INDICATOR, true)
    fun setBsdBlinkerEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INDICATOR, enabled).apply()

    /** Optional generic immediate voice, OFF by default until each car's BSD raw is verified. */
    fun bsdInstantEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INSTANT, false)
    fun setBsdInstantEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INSTANT, enabled).apply()

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
