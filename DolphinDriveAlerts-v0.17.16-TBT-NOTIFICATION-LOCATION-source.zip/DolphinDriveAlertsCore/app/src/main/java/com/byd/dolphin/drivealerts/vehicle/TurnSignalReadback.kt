package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/** Read-only indicator probe. No sound-status or speculative CAN mapping is promoted to an active signal. */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    data class Result(val side: Side, val detail: String, val anyBlinkerActive: Boolean = false)

    // Earlier global2602 capture: both getter results null. Do not turn null into an ON state.
    internal fun classify(left: Int?, right: Int?): Boolean =
        (left == 1 || right == 1) && !(left == 1 && right == 1)

    private data class Sample(val method: String, val value: Int?)
    private val classes = listOf(
        "android.hardware.bydauto.light.BYDAutoLightDevice",
        "android.hardware.bydauto.BYDAutoLightDevice"
    )
    private val leftMethods = listOf("getLeftTurnLightState", "getLeftTurnSignalState",
        "getLeftTurnLampState", "getLeftTurnState", "getLeftTurnSignalLightState")
    private val rightMethods = listOf("getRightTurnLightState", "getRightTurnSignalState",
        "getRightTurnLampState", "getRightTurnState", "getRightTurnSignalLightState")

    fun read(): Result {
        val notes = mutableListOf<String>()
        var left: Sample? = null
        var right: Sample? = null
        for (className in classes) {
            if (left != null && right != null) break
            val cls = try { Class.forName(className) } catch (t: Throwable) {
                notes += "class:${className.substringAfterLast('.')}=${t.javaClass.simpleName}"
                continue
            }
            val device = try {
                cls.getMethod("getInstance", Context::class.java).invoke(null, app)
            } catch (t: Throwable) {
                notes += "instance:${cls.simpleName}=${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                continue
            }
            if (device == null) { notes += "instance:${cls.simpleName}=NULL"; continue }
            fun readSide(names: List<String>, tag: String): Sample? {
                for (name in names) {
                    val method = cls.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
                    val raw = try { method.invoke(device) } catch (t: Throwable) {
                        notes += "$tag.$name:${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                        continue
                    }
                    if (raw is Number) return Sample("${cls.simpleName}.$name", raw.toInt())
                    notes += "$tag.$name:nonNumeric=${raw?.javaClass?.simpleName ?: "null"}"
                }
                notes += "$tag:noCallableGetter"
                return null
            }
            if (left == null) left = readSide(leftMethods, "LEFT")
            if (right == null) right = readSide(rightMethods, "RIGHT")
        }
        val l = left?.value
        val r = right?.value
        val side = when {
            l == 1 && r == 0 -> Side.LEFT
            r == 1 && l == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        val detail = "left=$l right=$r;leftMethod=${left?.method ?: "MISSING"};" +
            "rightMethod=${right?.method ?: "MISSING"};reason=${notes.take(10).joinToString("|")};" +
            "SDK_ON_1_CANDIDATE;hazardSide=UNKNOWN;turnSoundIsOnlyCorrelationCandidate=true"
        return Result(side, detail, anyBlinkerActive = classify(l,r))
    }
}
