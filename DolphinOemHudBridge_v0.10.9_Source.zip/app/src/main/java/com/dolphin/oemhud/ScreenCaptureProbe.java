package com.dolphin.oemhud;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import java.nio.ByteBuffer;

/** One-shot, consent-gated diagnostic. Never persists pixels or sends navigation packets. */
public final class ScreenCaptureProbe {
    public interface Callback { void done(String status); }
    private ScreenCaptureProbe(){}
    public static void runOnce(Activity activity,int resultCode,Intent data,Callback cb){
        final Handler handler=new Handler(Looper.getMainLooper());
        MediaProjection projection=null;
        ImageReader reader=null;
        VirtualDisplay display=null;
        try{
            DisplayMetrics dm=new DisplayMetrics();activity.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            int w=dm.widthPixels,h=dm.heightPixels;
            if(w<1||h<1||w>4096||h>4096)throw new IllegalStateException("invalid display");
            MediaProjectionManager manager=(MediaProjectionManager)activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(resultCode,data);
            if(projection==null)throw new IllegalStateException("projection null");
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            final MediaProjection mp=projection;
            final ImageReader ir=reader;
            final VirtualDisplay vd=projection.createVirtualDisplay("HUD consented diagnostic",w,h,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
            display=vd;
            final boolean[] finished={false};
            final Runnable cleanup=()->{try{vd.release();}catch(Exception ignored){}try{ir.close();}catch(Exception ignored){}try{mp.stop();}catch(Exception ignored){}};
            final Runnable timeout=()->{if(!finished[0]){finished[0]=true;cleanup.run();cb.done("TIMEOUT_NO_FRAME");}};
            handler.postDelayed(timeout,3500);
            reader.setOnImageAvailableListener(r->{
                if(finished[0])return;
                Image img=null;
                try{
                    img=r.acquireLatestImage();if(img==null)return;
                    Image.Plane plane=img.getPlanes()[0];ByteBuffer pixels=plane.getBuffer();
                    int stride=plane.getRowStride(),step=plane.getPixelStride();
                    long samples=0,visible=0;int min=255,max=0;
                    for(int y=0;y<h;y+=Math.max(1,h/40))for(int x=0;x<w;x+=Math.max(1,w/60)){
                        int pos=y*stride+x*step;if(pos+2>=pixels.limit())continue;
                        int v=((pixels.get(pos)&255)+(pixels.get(pos+1)&255)+(pixels.get(pos+2)&255))/3;
                        min=Math.min(min,v);max=Math.max(max,v);if(v>15)visible++;samples++;
                    }
                    String status=samples==0?"NO_PIXELS":(visible==0?"BLACK_OR_PROTECTED":"FRAME_VISIBLE")+
                        " size="+w+"x"+h+" sample="+samples+" visible="+visible+" range="+min+"-"+max+
                        " (TBT_NOT_VERIFIED)";
                    finished[0]=true;handler.removeCallbacks(timeout);img.close();img=null;cleanup.run();cb.done(status);
                }catch(Exception e){if(!finished[0]){finished[0]=true;handler.removeCallbacks(timeout);cleanup.run();cb.done("ERROR_"+e.getClass().getSimpleName());}}
                finally{if(img!=null)img.close();}
            },handler);
        }catch(Exception e){if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();cb.done("ERROR_"+e.getClass().getSimpleName());}
    }
}
