package com.dolphin.oemhud;

public final class SafetyCueTest {
    private static int passed;
    private static void ok(boolean value,String label){
        if(!value)throw new AssertionError(label);
        passed++;System.out.println("PASS SAFETY "+label);
    }
    private static SafetyCue parse(String text){return SafetyCue.fromText("com.tmap.auto.byd",text,1000);}
    public static void main(String[] args){
        SafetyCue cue=parse("300m 앞 과속 단속, 제한속도 50km/h");
        ok(cue!=null&&cue.distanceMeters==300&&cue.limitKmh==50,"explicit camera, limit and distance");
        ok(MconHudQProtocol.hex(MconSafetyProtocol.fromCue(cue)).equals("194D020601320000012C2F"),"independently derived legacy camera wire example");
        ok(parse("1.2km 앞 구간단속, 제한속도 80km/h").cameraMask==33,"section camera legacy bit mask");
        ok(parse("200m 앞 신호 과속 단속, 제한속도 60km/h").cameraMask==3,"signal plus speed camera");
        ok(parse("100m 앞 어린이 보호구역, 제한속도 30km/h").cameraMask==4,"child zone legacy bit mask");
        ok(parse("300m 우회전") == null,"turn is not a safety warning");
        ok(parse("300m 앞 과속 단속") == null,"missing speed limit rejected");
        ok(parse("제한속도 50km/h") == null,"limit alone is not a camera");
        ok(parse("과속 단속 제한속도 50km/h") == null,"km/h is never a camera distance");
        ok(parse("과속 단속 제한속도 10km / h") == null,"spaced speed unit is never a distance");
        ok(parse("-300m 앞 과속단속 제한속도 50km/h") == null,"negative distance is not made positive");
        ok(parse("목적지까지 300m 과속단속 제한속도 50km/h") == null,"trip total is not camera distance");
        ok(parse("300m 앞 과속 단속\n제한속도 50km/h") == null,"unrelated rows never paired");
        ok(parse("300m 앞 과속 단속 제한속도 50km/h, 700m 우회전") == null,"multiple distances rejected");
        ok(parse("300m 앞 과속 단속 제한속도 50km/h, 제한속도 80km/h") == null,"conflicting limits rejected");
        ok(parse("300m 앞 과속 단속 없음 제한속도 50km/h") == null,"negated warning rejected");
        ok(parse("300m 앞 과속 단속 테스트 제한속도 50km/h") == null,"test text rejected");
        ok(parse("300m 앞 과속 단속 제한속도 255km/h") == null,"invalid road limit rejected");
        ok(parse("300m 앞 신호 단속 카메라 제한속도 50km/h") == null,"signal-only camera never invented as a speed camera");
        ok(SafetyCue.inputDiagnosis("300m").equals("단속 종류 글자 없음"),"distance-only OEM observation stays diagnostic");
        ok(SafetyCue.inputDiagnosis("300m 과속단속").equals("제한속도 글자·단위 미확인"),"missing speed is visible in diagnosis");
        ok(parse("20000m 앞 과속 단속 제한속도 50km/h") == null,"out of scope camera distance rejected");
        ok(cue.isFresh(5999)&&!cue.isFresh(6000)&&!cue.isFresh(999),"monotonic five second lifetime and future rejection");
        ok(MconHudQProtocol.hex(MconSafetyProtocol.clear()).equals("194D02060000000000002F"),"camera clear is separate from turn clear");
        ok(MconSafetyProtocol.isFrame(MconSafetyProtocol.clear()),"clear packet validates");
        ok(!MconSafetyProtocol.isFrame(MconHudQProtocol.turn(5,300,false)),"turn cannot enter safety channel");
        ok(parse("300m 앞 과속 단속 제한속도 50km/h").safeDisplay().equals("과속 단속 · 제한 50km/h · 300m"),"diagnostics contain no road or raw input");
        ok(parse("150m 앞 스쿨존, 제한속도 30km/h").cameraMask==4,"school zone synonym legacy bit mask");
        System.out.println("SAFETY PARSER AND WIRE "+passed+" PASS");
    }
}
