package com.dolphin.oemhud;

public final class MconSpeedProtocolTest {
    private static int passed = 0;

    private static void ok(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        passed++;
        System.out.println("PASS SPEED " + name);
    }

    public static void main(String[] args) {
        byte[] zero = MconSpeedProtocol.currentSpeed(0);
        ok(MconSpeedProtocol.isFrame(zero) && "194D030200002F".equals(MconHudQProtocol.hex(zero)), "speed 0 km/h frame");
        byte[] sixty = MconSpeedProtocol.currentSpeed(60);
        ok(MconSpeedProtocol.isFrame(sixty) && "194D0302003C2F".equals(MconHudQProtocol.hex(sixty)), "speed 60 km/h frame");
        byte[] clampedHi = MconSpeedProtocol.currentSpeed(320);
        ok((clampedHi[5] & 255) == 255, "clamped max 255");
        byte[] clampedLo = MconSpeedProtocol.currentSpeed(-5);
        ok((clampedLo[5] & 255) == 0, "clamped min 0");
        ok(!MconSpeedProtocol.isFrame(MconSafetyProtocol.clear()), "safety frame rejected");
        System.out.println("MCON SPEED PROTOCOL TESTS: " + passed + " PASS");
    }
}
