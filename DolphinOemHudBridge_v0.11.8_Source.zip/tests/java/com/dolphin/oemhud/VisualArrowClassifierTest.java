package com.dolphin.oemhud;

import java.nio.ByteBuffer;

public final class VisualArrowClassifierTest {
    private static int passed = 0;

    private static void ok(boolean condition, String name) {
        if (!condition) throw new AssertionError(name);
        passed++;
        System.out.println("PASS VISUAL " + name);
    }

    private static int[] renderGrid(int size, int bg, int fg, int kind) {
        int[] g = new int[size * size];
        for (int i = 0; i < g.length; i++) g[i] = bg;
        int pad = size / 6;
        int inner = size - pad * 2;
        if (kind == 0) { // 직진
            rect(g, size, pad + inner * 6 / 16, pad + inner * 4 / 16, pad + inner * 10 / 16, pad + inner, fg);
            for (int r = 0; r <= inner * 5 / 16; r++) {
                int half = r + inner / 16;
                int cx = size / 2;
                rect(g, size, cx - half, pad + r, cx + half, pad + r + 1, fg);
            }
        } else if (kind == 1) { // 좌회전
            rect(g, size, pad + inner * 10 / 16, pad + inner * 4 / 16, pad + inner * 14 / 16, pad + inner, fg);
            rect(g, size, pad + inner * 3 / 16, pad + inner * 4 / 16, pad + inner * 14 / 16, pad + inner * 8 / 16, fg);
            for (int c = 0; c <= inner * 4 / 16; c++) {
                int cy = pad + inner * 6 / 16;
                rect(g, size, pad + c, cy - c - 1, pad + c + 1, cy + c + 1, fg);
            }
        } else if (kind == 2) { // 우회전
            rect(g, size, pad + inner * 2 / 16, pad + inner * 4 / 16, pad + inner * 6 / 16, pad + inner, fg);
            rect(g, size, pad + inner * 2 / 16, pad + inner * 4 / 16, pad + inner * 13 / 16, pad + inner * 8 / 16, fg);
            for (int c = 0; c <= inner * 4 / 16; c++) {
                int cy = pad + inner * 6 / 16;
                rect(g, size, pad + inner - c - 1, cy - c - 1, pad + inner - c, cy + c + 1, fg);
            }
        } else if (kind == 3) { // 좌전방
            rect(g, size, pad + inner * 10 / 16, pad + inner * 9 / 16, pad + inner * 14 / 16, pad + inner, fg);
            thickLine(g, size, pad + inner * 11 / 16, pad + inner * 10 / 16, pad + inner * 3 / 16, pad + inner * 2 / 16, 2, fg);
            rect(g, size, pad, pad, pad + inner * 6 / 16, pad + inner * 3 / 16, fg);
            rect(g, size, pad, pad, pad + inner * 3 / 16, pad + inner * 6 / 16, fg);
        } else if (kind == 4) { // 우전방
            rect(g, size, pad + inner * 2 / 16, pad + inner * 9 / 16, pad + inner * 6 / 16, pad + inner, fg);
            thickLine(g, size, pad + inner * 4 / 16, pad + inner * 10 / 16, pad + inner * 12 / 16, pad + inner * 2 / 16, 2, fg);
            rect(g, size, pad + inner * 9 / 16, pad, pad + inner, pad + inner * 3 / 16, fg);
            rect(g, size, pad + inner * 13 / 16, pad, pad + inner, pad + inner * 6 / 16, fg);
        } else if (kind == 5) { // 유턴
            rect(g, size, pad + inner * 11 / 16, pad + inner * 2 / 16, pad + inner * 15 / 16, pad + inner, fg);
            rect(g, size, pad + inner * 3 / 16, pad, pad + inner * 14 / 16, pad + inner * 4 / 16, fg);
            rect(g, size, pad + inner * 2 / 16, pad + inner * 2 / 16, pad + inner * 6 / 16, pad + inner * 13 / 16, fg);
            for (int r = 0; r <= inner * 3 / 16; r++) {
                int cx = pad + inner * 4 / 16;
                rect(g, size, cx - r - 1, pad + inner - r - 1, cx + r + 1, pad + inner - r, fg);
            }
        }
        return g;
    }

    private static void rect(int[] g, int size, int x0, int y0, int x1, int y1, int color) {
        for (int y = Math.max(0, y0); y < Math.min(size, y1); y++) {
            for (int x = Math.max(0, x0); x < Math.min(size, x1); x++) {
                g[y * size + x] = color;
            }
        }
    }

    private static void thickLine(int[] g, int size, int x0, int y0, int x1, int y1, int rad, int color) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / Math.max(1, steps);
            int y = y0 + (y1 - y0) * i / Math.max(1, steps);
            rect(g, size, x - rad, y - rad, x + rad + 1, y + rad + 1, color);
        }
    }

    public static void main(String[] args) {
        String[] expected = {"직진", "좌회전", "우회전", "좌전방", "우전방", "유턴"};
        for (int k = 0; k < expected.length; k++) {
            VisualArrowClassifier.Result darkBg = VisualArrowClassifier.classifyLumaGrid(renderGrid(48, 20, 240, k), 48, 48);
            ok(darkBg.isAccepted() && expected[k].equals(darkBg.direction), "dark card " + expected[k]);
            VisualArrowClassifier.Result lightBg = VisualArrowClassifier.classifyLumaGrid(renderGrid(48, 240, 25, k), 48, 48);
            ok(lightBg.isAccepted() && expected[k].equals(lightBg.direction), "light card " + expected[k]);
        }
        int[] blank = new int[48 * 48];
        VisualArrowClassifier.Result rBlank = VisualArrowClassifier.classifyLumaGrid(blank, 48, 48);
        ok(!rBlank.isAccepted() && "BLANK_OR_LOW_CONTRAST".equals(rBlank.reason), "blank rejected");

        int[] fullFill = new int[48 * 48];
        for (int y = 2; y < 46; y++) for (int x = 2; x < 46; x++) fullFill[y * 48 + x] = 250;
        VisualArrowClassifier.Result rFull = VisualArrowClassifier.classifyLumaGrid(fullFill, 48, 48);
        ok(!rFull.isAccepted(), "solid block rejected");

        // RGBA ByteBuffer region slicing test (right turn inside 128x128 frame)
        int[] rightArrow = renderGrid(48, 15, 245, 2);
        ByteBuffer buf = ByteBuffer.allocate(128 * 128 * 4);
        for (int y = 0; y < 48; y++) {
            for (int x = 0; x < 48; x++) {
                int v = rightArrow[y * 48 + x];
                int pos = ((y + 20) * 128 + (x + 16)) * 4;
                buf.put(pos, (byte) v);
                buf.put(pos + 1, (byte) v);
                buf.put(pos + 2, (byte) v);
                buf.put(pos + 3, (byte) 255);
            }
        }
        VisualArrowClassifier.Result rgbaRes = VisualArrowClassifier.classifyRgbaRegion(
            buf, 128, 128, 128 * 4, 4, 16, 20, 64, 68);
        ok(rgbaRes.isAccepted() && "우회전".equals(rgbaRes.direction), "RGBA slice right turn");

        // Stability filter tests
        VisualArrowClassifier.StabilityFilter sf = new VisualArrowClassifier.StabilityFilter();
        ok(sf.accept("우회전", 1000L) == null, "1st frame awaits confirmation");
        ok("우회전".equals(sf.accept("우회전", 2200L)), "2nd consecutive frame accepted");
        ok(sf.accept("좌회전", 3000L) == null, "direction change resets streak");
        ok(sf.accept("좌회전", 8000L) == null, "stale gap resets streak");
        ok("좌회전".equals(sf.accept("좌회전", 9200L)), "fresh 2nd frame accepted");

        // Colored badge test: bright outer map (210) + dark rounded badge (40) + white right arrow (248)
        int[] badge = renderGrid(48, 40, 248, 2);
        for (int i = 0; i < 48; i++) {
            badge[i] = 210; badge[47 * 48 + i] = 210;
            badge[i * 48] = 210; badge[i * 48 + 47] = 210;
        }
        VisualArrowClassifier.Result badgeRes = VisualArrowClassifier.classifyLumaGrid(badge, 48, 48);
        ok(badgeRes.isAccepted() && "우회전".equals(badgeRes.direction) && badgeRes.shapeHex8x8.length() == 16, "colored badge bright right arrow");
        // Daytime light badge test: dark outer frame (50) + bright card (240) + dark left arrow (25)
        int[] dayBadge = renderGrid(48, 240, 25, 1);
        for (int i = 0; i < 48; i++) {
            dayBadge[i] = 50; dayBadge[47 * 48 + i] = 50;
            dayBadge[i * 48] = 50; dayBadge[i * 48 + 47] = 50;
        }
        VisualArrowClassifier.Result dayRes = VisualArrowClassifier.classifyLumaGrid(dayBadge, 48, 48);
        ok(dayRes.isAccepted() && "좌회전".equals(dayRes.direction), "daytime dark arrow on light badge");
        // OEM TMAP curved top-aligned right-turn arrow (must NEVER misclassify as 유턴)
        int[] oemRight = new int[48 * 48];
        for (int i = 0; i < oemRight.length; i++) oemRight[i] = 45;
        rect(oemRight, 48, 8, 16, 14, 42, 245);   // left stem
        rect(oemRight, 48, 8, 12, 34, 20, 245);   // top horizontal bar
        rect(oemRight, 48, 30, 6, 40, 26, 245);   // right arrowhead
        VisualArrowClassifier.Result oemRes = VisualArrowClassifier.classifyLumaGrid(oemRight, 48, 48);
        ok(oemRes.isAccepted() && "우회전".equals(oemRes.direction), "OEM curved top-aligned right turn not misclassified as U-turn");
        System.out.println("VISUAL ARROW CLASSIFIER TESTS: " + passed + " PASS");
    }
}
