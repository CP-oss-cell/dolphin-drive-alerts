package com.dolphin.oemhud;

import android.bluetooth.*;
import android.os.*;
import android.content.*;

/** Real production parser, service and connector; synthetic Android/GATT and controlled clock. */
public final class SafetyEndToEndTest {
    private static int passed;
    private static void ok(boolean value,String label){if(!value)throw new AssertionError(label);passed++;System.out.println("PASS SAFETY FLOW "+label);}
    private static final String OEM="com.tmap.auto.byd",MAC="AA:BB:CC:11:22:33";
    private static SafetyCue warning(int metres){return SafetyCue.fromText(OEM,metres+"m 앞 과속 단속 제한속도 50km/h",SystemClock.elapsedRealtime());}
    private static BridgeService service(){
        BridgeService s=new BridgeService();
        s.getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("enabled",true).putBoolean("safety_enabled",true).putString("nav_package",OEM).putString("hud_mac",MAC).apply();
        s.onCreate();s.onStartCommand(null,0,1);Handler.advance(0);return s;
    }
    public static void main(String[] args){
        Handler.reset();BluetoothGatt.automaticConnection=true;BluetoothGatt.discoverReply=true;
        BluetoothGatt.writeReply=true;BluetoothGatt.hasWriter=true;BluetoothGatt.hasNotify=false;BluetoothGatt.profileMode=1;BluetoothGatt.descriptorReply=true;
        Context.resetStore();
        BridgeService s=service();int start=BluetoothGatt.writes;
        BridgeService.onSafety(warning(300));Handler.advance(0);
        ok(BluetoothGatt.writes==start+1,"validated warning reaches real connector");
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D020601320000012C2F"),"real FFF2 writes independent safety example");
        ok(s.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_safety_callback_confirmed",0)==1,"safety callback independently counted");
        ok(s.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_nav_write_completed",0)==0,"safety does not inflate turn success");
        BridgeService.onCue(new NavCue("TMAP 화면:"+OEM,"우회전",400,"",-1,-1,""));Handler.advance(70);
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D010500050001902F"),"turn still transmits after safety");
        BridgeService.onSafety(warning(300));Handler.advance(0);
        ok(BluetoothGatt.writes==start+2,"identical rapid warning suppresses duplicate transport");
        Handler.advance(5500);
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D02060000000000002F"),"expired warning sends camera clear");
        ok(s.getSharedPreferences(BridgeLog.STORE,0).getString("last_safety","x").isEmpty(),"expired local warning removed");
        int before=BluetoothGatt.writes;
        BridgeService.onSafety(SafetyCue.fromText("com.other.app","200m 과속 단속 제한속도 50km/h",SystemClock.elapsedRealtime()));Handler.advance(0);
        ok(BluetoothGatt.writes==before,"unselected package cannot send a warning");
        BridgeService.onSafety(warning(200));Handler.advance(100);
        s.getSharedPreferences(BridgeLog.STORE,0).edit().putString("nav_package","com.skt.tmap.ku").apply();Handler.advance(600);
        ok(MconSafetyProtocol.isClear(BluetoothGatt.lastValue),"changing selected app clears camera state");
        s.getSharedPreferences(BridgeLog.STORE,0).edit().putBoolean("enabled",false).apply();before=BluetoothGatt.writes;
        BridgeService.onSafety(warning(100));Handler.advance(0);
        ok(BluetoothGatt.writes==before,"disabled bridge rejects safety input");
        s.onDestroy();Handler.reset();

        // Disconnected warnings retain their original timestamp, not reconnection time.
        BluetoothGatt.automaticConnection=false;Context.resetStore();
        Context context=new Context();HudConnector h=new HudConnector(context);
        h.connect(new BluetoothDevice("ARIA HUD Q",MAC),text->{});
        h.sendSafety(warning(300));h.sendTurn(new NavCue("test","좌회전",700,"",-1,-1,""));
        before=BluetoothGatt.writes;Handler.advance(5500);BluetoothDevice.latest.simulateConnected();Handler.advance(200);
        ok(BluetoothGatt.writes==before+2,"expired safety clear and independent turn both drain");
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D010500020002BC2F"),"safety queue never replaces queued turn");
        ok(context.getSharedPreferences(BridgeLog.STORE,0).getInt("hud_safety_write_completed",0)==1,"expired warning only emits clear");h.disconnect();

        Handler.reset();Context.resetStore();BluetoothGatt.automaticConnection=true;BluetoothGatt.profileMode=2;
        h=new HudConnector(new Context());h.connect(new BluetoothDevice("HUD Q MAX",MAC),text->{});Handler.advance(0);
        before=BluetoothGatt.writes;ok(!h.sendSafety(warning(300)),"unverified non-FFEA safety profile rejected");
        ok(BluetoothGatt.writes==before,"no legacy safety frame sent to different protocol");h.disconnect();BluetoothGatt.profileMode=0;

        // Hold the real connector's ATT operation open, then queue newer camera and turn.
        Handler.reset();Context.resetStore();BluetoothGatt.profileMode=1;BluetoothGatt.writeReply=false;
        h=new HudConnector(new Context());h.connect(new BluetoothDevice("ARIA HUD Q",MAC),text->{});Handler.advance(0);
        h.sendSafety(warning(300));before=BluetoothGatt.writes;
        h.sendTurn(new NavCue("test","좌회전",700,"",-1,-1,""));h.sendSafety(warning(200));
        ok(BluetoothGatt.writes==before,"safety and turn wait for active ATT transaction");
        BluetoothDevice.latest.simulateCurrentWrite();Handler.advance(70);
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D02060132000000C82F"),"only latest queued safety survives");
        BluetoothDevice.latest.simulateCurrentWrite();Handler.advance(70);
        ok(MconHudQProtocol.hex(BluetoothGatt.lastValue).equals("194D010500020002BC2F"),"queued turn follows safety without overlap");
        BluetoothDevice.latest.simulateCurrentWrite();h.disconnect();BluetoothGatt.writeReply=true;

        Handler.reset();Context.resetStore();s=service();BridgeService.onSafety(warning(300));Handler.advance(4000);
        BridgeService.onSafety(warning(300));Handler.advance(2000);
        ok(!MconSafetyProtocol.isClear(BluetoothGatt.lastValue),"fresh repeated observation extends input lifetime");
        Handler.advance(3500);
        ok(MconSafetyProtocol.isClear(BluetoothGatt.lastValue),"clear follows final live observation expiry");s.onDestroy();BluetoothGatt.profileMode=0;
        System.out.println("SAFETY SERVICE + REAL CONNECTOR "+passed+" PASS");
    }
}
