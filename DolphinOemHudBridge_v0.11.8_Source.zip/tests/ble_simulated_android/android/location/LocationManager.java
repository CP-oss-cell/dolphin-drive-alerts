package android.location;import android.os.Looper;public class LocationManager{public static final String GPS_PROVIDER="gps";public void requestLocationUpdates(String p,long t,float d,LocationListener l,Looper lo){}
public void removeUpdates(LocationListener l){}}
