package android.location;public class Location{public boolean hasSpeed(){return false;}public float getSpeed(){return 0f;}}
