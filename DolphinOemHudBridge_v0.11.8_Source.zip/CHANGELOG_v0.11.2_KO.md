# v0.11.2 / versionCode 34

기준본: v0.11.1 (versionCode 33) + 2026-11-25 실차 진단(`report.txt`) 반영.

## 2026-11-25 실차 확인 사실
- BYD Dolphin (`1280×720`)에서 Android 10 `MediaProjection` 화면 캡처가 **`FRAME_VISIBLE size=1280x720 sample=2440 visible=2383 range=11-255`**로 정상 동작함을 최초 확인했습니다(`SecurityException`·검은 화면 없음).
- 다만 첫 진단 시 `anchor=dist=56m arrow=79x80@(529,484)`로 화면 하단 중앙 아이콘이 선택되었고, 컬러 배지 배경 차이로 `FILL_OUT_OF_RANGE`가 발생했으며, 화면 화살표 보조 인식은 아직 시작되지 않은 상태(`미시작`)였습니다.

## v0.11.2 개선 사항
- **상단 TBT 카드 우선 앵커 (`NavAccessibilityService.java`, `TbtVisualAnchor.java`)**: 화면 상단(`y < 400`)의 거리·화살표 후보에 우선순위를 부여해 하단 지도 버튼(`y=484`)이 TBT 앵커를 가로채지 않도록 개선했습니다.
- **컬러 배지 밝은 화살표 추출 (`VisualArrowClassifier.java`)**: 테두리 대비 채움률이 68%를 넘는 컬러 배지 아이콘에서 내부 밝은 화살표 전경만 자동 추출하는 fallback을 추가해 `FILL_OUT_OF_RANGE` 오거부를 해결했습니다.
- **익명 좌표·실루엣 진단 (`MainActivity.java`, `ScreenCaptureProbe.java`)**: 앱 복귀 시 마지막 유효 앵커가 지워지지 않도록 `tbt_last_ready_anchor`를 별도 보존하고, 도로명·텍스트 없는 `tbt_layout_probe`(좌표만) 및 익명 8×8 이진 실루엣 16진수(`hex=`)를 `report.txt`에 기록합니다.
