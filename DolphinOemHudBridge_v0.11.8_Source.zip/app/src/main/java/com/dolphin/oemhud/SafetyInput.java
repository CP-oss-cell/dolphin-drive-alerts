package com.dolphin.oemhud;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;

/** Same-process adapter called only by package-filtered accessibility/notification readers. */
public final class SafetyInput {
    private SafetyInput(){}
    public static void observe(Context context,String pkg,String text){
        SharedPreferences p=context.getSharedPreferences(BridgeLog.STORE,0);
        if(!p.getBoolean("enabled",false)||!p.getBoolean("safety_enabled",true)||!BridgeLog.isNavPackage(context,pkg))return;
        SafetyCue cue=SafetyCue.fromText(pkg,text,SystemClock.elapsedRealtime());
        p.edit().putInt("safety_observations",p.getInt("safety_observations",0)+1)
            .putString("safety_input_diagnosis",SafetyCue.inputDiagnosis(text))
            .putLong("safety_observed_at",System.currentTimeMillis()).apply();
        if(cue==null)return;
        if(BridgeService.onSafety(cue))return;
        // Do not persist/replay warnings after a process restart. The next live observation
        // can deliver it once the foreground bridge has started.
        try{
            Intent service=new Intent(context,BridgeService.class);
            if(Build.VERSION.SDK_INT>=26)context.startForegroundService(service);else context.startService(service);
        }catch(Exception e){BridgeLog.event(context,"안전운전 브리지 시작 불가: "+e.getClass().getSimpleName());}
    }
}
