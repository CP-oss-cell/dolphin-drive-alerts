package com.dolphin.oemhud;

/**
 * Pure-Java spatial anchor linking a visible TBT distance widget and its co-located
 * arrow ROI within the same navigation card.
 * v0.11.4: excludes route-preview totals (>15km) and derives a bounded relative arrow ROI
 * next to the distance widget when OEM TMAP hides the arrow ImageView from Accessibility.
 * Never persists screenshots, road names, destinations, or raw screen text.
 */
public final class TbtVisualAnchor {
    public static final long MAX_AGE_MS = 3000L;
    public static final int MAX_TURN_DISTANCE_M = 15000;
    public static final int MIN_ARROW_PX = 24;
    public static final int MAX_ARROW_PX = 320;
    public static final double MAX_ASPECT_RATIO = 2.2;

    public static final class Snapshot {
        public final String packageName;
        public final int distanceMeters;
        public final int distLeft, distTop, distRight, distBottom;
        public final int arrowLeft, arrowTop, arrowRight, arrowBottom;
        public final boolean derivedRoi;
        public final long observedElapsed;

        public Snapshot(String pkg, int meters,
                        int dL, int dT, int dR, int dB,
                        int aL, int aT, int aR, int aB,
                        long elapsed) {
            this(pkg, meters, dL, dT, dR, dB, aL, aT, aR, aB, false, elapsed);
        }

        public Snapshot(String pkg, int meters,
                        int dL, int dT, int dR, int dB,
                        int aL, int aT, int aR, int aB,
                        boolean derived, long elapsed) {
            packageName = pkg == null ? "" : pkg;
            distanceMeters = meters;
            distLeft = dL; distTop = dT; distRight = dR; distBottom = dB;
            arrowLeft = aL; arrowTop = aT; arrowRight = aR; arrowBottom = aB;
            derivedRoi = derived;
            observedElapsed = elapsed;
        }

        public boolean isFresh(long nowElapsed) {
            return nowElapsed >= observedElapsed && (nowElapsed - observedElapsed) < MAX_AGE_MS;
        }

        public boolean matchesPackage(String pkg) {
            return pkg != null && !pkg.isEmpty() && pkg.equals(packageName);
        }

        public int arrowWidth() { return Math.max(0, arrowRight - arrowLeft); }
        public int arrowHeight() { return Math.max(0, arrowBottom - arrowTop); }

        public String safeSummary() {
            return "dist=" + distanceMeters + "m@(" + distLeft + "," + distTop + ") arrow="
                + arrowWidth() + "x" + arrowHeight() + "@(" + arrowLeft + "," + arrowTop + ")"
                + (derivedRoi ? "[derived]" : "[node]");
        }
    }

    private static volatile Snapshot latest;

    private TbtVisualAnchor() {}

    public static void clear() { latest = null; }

    public static Snapshot getLatest() { return latest; }

    public static Snapshot getFresh(String pkg, long nowElapsed) {
        Snapshot s = latest;
        if (s == null || !s.isFresh(nowElapsed)) return null;
        if (pkg != null && !pkg.isEmpty() && !s.matchesPackage(pkg)) return null;
        return s;
    }

    public static void update(Snapshot snapshot) {
        if (snapshot == null || snapshot.distanceMeters < 0 || snapshot.distanceMeters > MAX_TURN_DISTANCE_M
                || !isValidArrowRect(snapshot.arrowLeft, snapshot.arrowTop, snapshot.arrowRight, snapshot.arrowBottom)) {
            return;
        }
        latest = snapshot;
    }

    public static boolean isValidArrowRect(int left, int top, int right, int bottom) {
        int w = right - left;
        int h = bottom - top;
        if (w < MIN_ARROW_PX || h < MIN_ARROW_PX || w > MAX_ARROW_PX || h > MAX_ARROW_PX) return false;
        double ratio = w >= h ? (double) w / h : (double) h / w;
        return ratio <= MAX_ASPECT_RATIO;
    }

    /** Edge-to-edge Manhattan gap between two screen rectangles (0 when overlapping/touching). */
    public static int boxGap(int aL, int aT, int aR, int aB, int bL, int bT, int bR, int bB) {
        int dx = aR < bL ? bL - aR : (bR < aL ? aL - bR : 0);
        int dy = aB < bT ? bT - aB : (bB < aT ? aT - bB : 0);
        return dx + dy;
    }

    /**
     * Selects the closest valid unlabeled arrow ImageView co-located with the distance widget.
     * Prefers candidates in the upper half of the display (where OEM TMAP places the TBT card).
     */
    public static int selectBestArrow(int dL, int dT, int dR, int dB, int[][] arrowRects) {
        if (arrowRects == null || arrowRects.length == 0) return -1;
        if (dR <= dL || dB <= dT) return -1;
        int bestIdx = -1;
        int bestScore = Integer.MAX_VALUE;
        for (int i = 0; i < arrowRects.length; i++) {
            int[] a = arrowRects[i];
            if (a == null || a.length < 4) continue;
            if (!isValidArrowRect(a[0], a[1], a[2], a[3])) continue;
            int maxDim = Math.max(a[2] - a[0], a[3] - a[1]);
            int allowedGap = Math.max(160, (int) Math.round(2.5 * maxDim));
            int gap = boxGap(dL, dT, dR, dB, a[0], a[1], a[2], a[3]);
            if (gap <= allowedGap) {
                int dCy = (dT + dB) / 2;
                int aCy = (a[1] + a[3]) / 2;
                int alignPenalty = Math.abs(dCy - aCy);
                int score = gap + alignPenalty;
                if (score < bestScore) {
                    bestScore = score;
                    bestIdx = i;
                }
            }
        }
        return bestIdx;
    }

    /**
     * Derives a bounded arrow ROI adjacent to an upper-screen TBT distance widget when
     * Accessibility does not expose the arrow ImageView directly.
     * Returns int[4]{l, t, r, b} or null if the distance rect is not in the upper TBT zone.
     */
    public static int[] deriveRelativeArrowRect(int dL, int dT, int dR, int dB) {
        if (dR <= dL || dB <= dT || dT >= 360 || dL >= 640) return null;
        int dh = dB - dT;
        int side = Math.max(64, Math.min(120, dh * 2));
        if (dL >= side + 8) {
            int aR = dL - 4;
            int aL = Math.max(4, aR - side);
            int cy = (dT + dB) / 2;
            int aT = Math.max(56, cy - side / 2);
            int aB = aT + side;
            return new int[]{aL, aT, aR, aB};
        }
        if (dT >= 56 + side / 2) {
            int cx = (dL + dR) / 2;
            int aL = Math.max(4, cx - side / 2);
            int aR = aL + side;
            int aB = Math.max(56 + side, dT - 4);
            int aT = Math.max(56, aB - side);
            return new int[]{aL, aT, aR, aB};
        }
        return null;
    }
}
