package com.dolphin.oemhud;

/**
 * Interoperability encoder for the legacy FFEA/FFF2 HUD Q current vehicle speed frame.
 * Derived directly from MCon+K_2.2.1_APKPure.xapk classes2.dex (Llh5;->g0):
 * prefix 19 4D 03 02, speedType (00 = current car speed), speed km/h (0..255), end 2F.
 */
public final class MconSpeedProtocol {
    private MconSpeedProtocol() {}

    public static byte[] currentSpeed(int kmh) {
        int clamped = Math.max(0, Math.min(255, kmh));
        return new byte[]{0x19, 0x4d, 0x03, 0x02, 0x00, (byte) clamped, 0x2f};
    }

    public static boolean isFrame(byte[] f) {
        return f != null && f.length == 7 && f[0] == 0x19 && f[1] == 0x4d
            && f[2] == 0x03 && f[3] == 0x02 && f[4] == 0x00 && f[6] == 0x2f;
    }
}
