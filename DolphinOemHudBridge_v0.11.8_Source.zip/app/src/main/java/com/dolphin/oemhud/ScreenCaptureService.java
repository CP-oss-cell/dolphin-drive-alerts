package com.dolphin.oemhud;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Consent-gated foreground projection service (one-shot diagnostic or opt-in visual arrow assist). */
public final class ScreenCaptureService extends Service {
    public static final String ACTION_PROBE_ONCE="com.dolphin.oemhud.SCREEN_PROBE_ONCE";
    public static final String ACTION_START_ASSIST="com.dolphin.oemhud.VISUAL_ASSIST_START";
    public static final String ACTION_STOP_ASSIST="com.dolphin.oemhud.VISUAL_ASSIST_STOP";
    private static final String CHANNEL="hud_screen_diagnostic";
    private static volatile boolean assistActive=false;
    private boolean running=false;
    private ScreenCaptureProbe.VisualAssistSession assistSession;

    public static boolean isAssistActive(){return assistActive;}

    @Override public IBinder onBind(Intent intent){return null;}

    private void promoteForeground(String title,String text){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26 && nm!=null){
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"HUD 화면 진단·보조 인식",NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification n=builder.setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29){
            startForeground(2709,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        }else{
            startForeground(2709,n);
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String action=intent==null?ACTION_PROBE_ONCE:intent.getAction();
        if(ACTION_STOP_ASSIST.equals(action)){
            stopAssistAndSelf();
            return START_NOT_STICKY;
        }
        if(running){
            if(ACTION_START_ASSIST.equals(action) && assistSession!=null)return START_NOT_STICKY;
            if(assistSession!=null){assistSession.stop();assistSession=null;}
            assistActive=false;
        }
        running=true;
        try{
            int code=intent==null?0:intent.getIntExtra("resultCode",0);
            Intent data=intent==null?null:(Intent)intent.getParcelableExtra("resultData");
            if(ACTION_START_ASSIST.equals(action)){
                promoteForeground("HUD 화면 화살표 보조 인식 중","사용자 동의 기반 · 화면 저장 없음");
                assistActive=true;
                final ScreenCaptureProbe.VisualAssistSession[] ref=new ScreenCaptureProbe.VisualAssistSession[1];
                ref[0]=new ScreenCaptureProbe.VisualAssistSession(this,()->{
                    if(assistSession!=ref[0])return;
                    assistSession=null;
                    assistActive=false;
                    running=false;
                    try{stopForeground(true);}catch(Exception ignored){}
                    stopSelf();
                });
                assistSession=ref[0];
                if(!assistSession.start(code,data)){
                    assistActive=false;
                    running=false;
                    stopForeground(true);
                    stopSelf(startId);
                }
            }else{
                promoteForeground("HUD 화면 캡처 진단 중","사용자 동의로 1회 화면 검사");
                ScreenCaptureProbe.runOnce(this,code,data,status->{
                    BridgeLog.event(this,"화면 캡처 진단: "+status);
                    getSharedPreferences(BridgeLog.STORE,MODE_PRIVATE).edit()
                        .putString("screen_probe_status",status)
                        .putLong("screen_probe_time",System.currentTimeMillis()).apply();
                    running=false;
                    stopForeground(true);
                    stopSelf(startId);
                });
            }
        }catch(Exception e){
            BridgeLog.event(this,"화면 캡처 서비스 오류: ERROR_SERVICE_"+e.getClass().getSimpleName());
            getSharedPreferences(BridgeLog.STORE,MODE_PRIVATE).edit()
                .putString("screen_probe_status","ERROR_SERVICE_"+e.getClass().getSimpleName()).apply();
            assistActive=false;
            running=false;
            try{stopForeground(true);}catch(Exception ignored){}
            stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    private void stopAssistAndSelf(){
        if(assistSession!=null){
            assistSession.stop();
            assistSession=null;
        }
        assistActive=false;
        running=false;
        getSharedPreferences(BridgeLog.STORE,MODE_PRIVATE).edit()
            .putString("visual_assist_state","STOPPED_BY_USER").apply();
        BridgeLog.event(this,"화면 화살표 보조 인식 중지");
        try{stopForeground(true);}catch(Exception ignored){}
        stopSelf();
    }

    @Override public void onDestroy(){
        if(assistSession!=null){
            assistSession.stop();
            assistSession=null;
        }
        assistActive=false;
        running=false;
        super.onDestroy();
    }
}
