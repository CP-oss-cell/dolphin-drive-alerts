package com.dolphin.oemhud;

/**
 * Pure-Java spatial anchor linking an OEM TMAP speed-limit circle (e.g. "30") and its
 * co-located camera distance badge (e.g. "179m") directly below it.
 * Never asserts speed camera without visual red-ring confirmation.
 */
public final class SafetyVisualAnchor {
    public static final long MAX_AGE_MS = 3000L;
    public static final int MAX_CAMERA_DIST_M = 3000;

    public static final class Snapshot {
        public final String packageName;
        public final int limitKmh;
        public final int distanceMeters;
        public final int signLeft, signTop, signRight, signBottom;
        public final long observedElapsed;

        public Snapshot(String pkg, int limit, int meters,
                        int sL, int sT, int sR, int sB, long elapsed) {
            packageName = pkg == null ? "" : pkg;
            limitKmh = limit;
            distanceMeters = meters;
            signLeft = sL; signTop = sT; signRight = sR; signBottom = sB;
            observedElapsed = elapsed;
        }

        public boolean isFresh(long nowElapsed) {
            return nowElapsed >= observedElapsed && (nowElapsed - observedElapsed) < MAX_AGE_MS;
        }

        public boolean matchesPackage(String pkg) {
            return pkg != null && !pkg.isEmpty() && pkg.equals(packageName);
        }
    }

    private static volatile Snapshot latest;

    private SafetyVisualAnchor() {}

    public static void clear() { latest = null; }

    public static void update(Snapshot s) {
        if (s == null || s.limitKmh < 10 || s.limitKmh > 150 || s.limitKmh % 5 != 0
                || s.distanceMeters < 0 || s.distanceMeters > MAX_CAMERA_DIST_M) {
            return;
        }
        latest = s;
    }

    public static Snapshot getFresh(String pkg, long nowElapsed) {
        Snapshot s = latest;
        if (s == null || !s.isFresh(nowElapsed)) return null;
        if (pkg != null && !pkg.isEmpty() && !s.matchesPackage(pkg)) return null;
        return s;
    }

    /** Pairs a speed-limit number rect with a camera distance rect directly below it. */
    public static boolean isCoLocatedCameraPair(int sL, int sT, int sR, int sB,
                                                int dL, int dT, int dR, int dB) {
        if (sR <= sL || sB <= sT || dR <= dL || dB <= dT) return false;
        if (sL >= 360 || sT < 180 || sT > 520) return false;
        int sCx = (sL + sR) / 2;
        int dCx = (dL + dR) / 2;
        int vGap = dT - sB;
        return Math.abs(sCx - dCx) <= 75 && vGap >= -10 && vGap <= 90;
    }
}
