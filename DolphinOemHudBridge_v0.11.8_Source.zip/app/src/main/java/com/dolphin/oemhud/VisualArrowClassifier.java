package com.dolphin.oemhud;

import java.nio.ByteBuffer;

/**
 * Lightweight, zero-dependency, fail-closed on-device geometric arrow classifier.
 * Operates strictly in memory on a cropped TBT arrow ROI; never persists pixels.
 * v0.11.6: calibrated right/left turn templates to OEM TMAP top-aligned curved arrows
 * and added U-turn vs turn bottom-quadrant structural guard to prevent U-turn false positives.
 */
public final class VisualArrowClassifier {
    public static final int GRID = 16;
    public static final int MIN_CONTRAST = 28;
    public static final double MIN_FILL = 0.04;
    public static final double MAX_FILL = 0.68;
    public static final double MIN_CONFIDENCE = 0.50;
    public static final double MIN_MARGIN = 0.05;

    public static final class Result {
        public final String direction; // null when rejected (fail-closed)
        public final double confidence;
        public final double margin;
        public final String reason;
        public final String shapeHex8x8;

        public Result(String dir, double conf, double gap, String why) {
            this(dir, conf, gap, why, "");
        }

        public Result(String dir, double conf, double gap, String why, String hex8x8) {
            direction = dir;
            confidence = conf;
            margin = gap;
            reason = why == null ? "" : why;
            shapeHex8x8 = hex8x8 == null ? "" : hex8x8;
        }

        public boolean isAccepted() { return direction != null && !direction.isEmpty(); }
    }

    /** Requires two consecutive identical detections within 2.5s (at 300ms cadence -> ~0.6s). */
    public static final class StabilityFilter {
        public static final long MAX_GAP_MS = 2500L;
        private String lastCandidate;
        private long lastAtElapsed;
        private int streak;

        public synchronized String accept(String direction, long nowElapsed) {
            if (direction == null || direction.isEmpty()) {
                reset();
                return null;
            }
            if (direction.equals(lastCandidate) && nowElapsed >= lastAtElapsed
                    && (nowElapsed - lastAtElapsed) <= MAX_GAP_MS) {
                streak++;
            } else {
                lastCandidate = direction;
                streak = 1;
            }
            lastAtElapsed = nowElapsed;
            return streak >= 2 ? direction : null;
        }

        public synchronized void reset() {
            lastCandidate = null;
            lastAtElapsed = 0L;
            streak = 0;
        }
    }

    private static final String[] LABELS = {"직진", "좌회전", "우회전", "좌전방", "우전방", "유턴"};
    private static final boolean[][] TEMPLATES = buildTemplates();

    private VisualArrowClassifier() {}

    /** Classify directly from an RGBA_8888 Image.Plane buffer slice without allocating a Bitmap. */
    public static Result classifyRgbaRegion(ByteBuffer pixels, int fullW, int fullH,
                                            int rowStride, int pixelStride,
                                            int left, int top, int right, int bottom) {
        if (pixels == null || fullW <= 0 || fullH <= 0 || pixelStride < 3) {
            return new Result(null, 0, 0, "INVALID_BUFFER");
        }
        int x0 = Math.max(0, Math.min(fullW - 1, left));
        int y0 = Math.max(0, Math.min(fullH - 1, top));
        int x1 = Math.max(x0 + 1, Math.min(fullW, right));
        int y1 = Math.max(y0 + 1, Math.min(fullH, bottom));
        int rw = x1 - x0;
        int rh = y1 - y0;
        if (rw < 16 || rh < 16) return new Result(null, 0, 0, "ROI_TOO_SMALL");

        final int sampleN = 32;
        int[] luma = new int[sampleN * sampleN];
        int limit = pixels.limit();
        for (int sy = 0; sy < sampleN; sy++) {
            int py = y0 + (sy * rh) / sampleN;
            for (int sx = 0; sx < sampleN; sx++) {
                int px = x0 + (sx * rw) / sampleN;
                int pos = py * rowStride + px * pixelStride;
                if (pos < 0 || pos + 2 >= limit) continue;
                int r = pixels.get(pos) & 255;
                int g = pixels.get(pos + 1) & 255;
                int b = pixels.get(pos + 2) & 255;
                luma[sy * sampleN + sx] = (r * 30 + g * 59 + b * 11) / 100;
            }
        }
        return classifyLumaGrid(luma, sampleN, sampleN);
    }

    /** Checks whether a region contains a red speed-limit ring (for OEM camera sign verification). */
    public static boolean hasRedRing(ByteBuffer pixels, int fullW, int fullH,
                                     int rowStride, int pixelStride,
                                     int left, int top, int right, int bottom) {
        if (pixels == null || fullW <= 0 || fullH <= 0 || pixelStride < 3) return false;
        int x0 = Math.max(0, Math.min(fullW - 1, left));
        int y0 = Math.max(0, Math.min(fullH - 1, top));
        int x1 = Math.max(x0 + 1, Math.min(fullW, right));
        int y1 = Math.max(y0 + 1, Math.min(fullH, bottom));
        int rw = x1 - x0, rh = y1 - y0;
        if (rw < 16 || rh < 16) return false;
        int limit = pixels.limit();
        int redHits = 0, total = 0;
        for (int sy = 0; sy < 20; sy++) {
            int py = y0 + (sy * rh) / 20;
            for (int sx = 0; sx < 20; sx++) {
                int px = x0 + (sx * rw) / 20;
                int pos = py * rowStride + px * pixelStride;
                if (pos < 0 || pos + 2 >= limit) continue;
                int r = pixels.get(pos) & 255;
                int g = pixels.get(pos + 1) & 255;
                int b = pixels.get(pos + 2) & 255;
                if (r >= 150 && (r - g) >= 50 && (r - b) >= 50) redHits++;
                total++;
            }
        }
        return total > 0 && redHits >= Math.max(12, total / 18);
    }

    /** Pure-Java entry point for JVM unit tests and in-memory luminance grids. */
    public static Result classifyLumaGrid(int[] luma, int width, int height) {
        if (luma == null || width < 8 || height < 8 || luma.length < width * height) {
            return new Result(null, 0, 0, "INVALID_GRID");
        }
        long borderSum = 0;
        int borderCount = 0;
        for (int x = 0; x < width; x++) {
            borderSum += luma[x];
            borderSum += luma[(height - 1) * width + x];
            borderCount += 2;
        }
        for (int y = 1; y < height - 1; y++) {
            borderSum += luma[y * width];
            borderSum += luma[y * width + (width - 1)];
            borderCount += 2;
        }
        int bg = (int) (borderSum / Math.max(1, borderCount));

        int minLuma = 255, maxLuma = 0, maxDiff = 0;
        for (int i = 0; i < width * height; i++) {
            int v = luma[i];
            if (v < minLuma) minLuma = v;
            if (v > maxLuma) maxLuma = v;
            int d = Math.abs(v - bg);
            if (d > maxDiff) maxDiff = d;
        }
        if (maxDiff < MIN_CONTRAST) {
            return new Result(null, 0, 0, "BLANK_OR_LOW_CONTRAST");
        }

        int threshold = Math.max(MIN_CONTRAST, (int) (maxDiff * 0.42));
        boolean[] borderMask = new boolean[width * height];
        for (int i = 0; i < width * height; i++) {
            if (Math.abs(luma[i] - bg) >= threshold) borderMask[i] = true;
        }
        Result best = evaluateMask(borderMask, width, height, "B", bg, minLuma, maxLuma);
        if (best.isAccepted() && best.confidence >= 0.72) return best;

        int insetX = Math.max(1, width / 10);
        int insetY = Math.max(1, height / 10);
        int innerMin = 255, innerMax = 0;
        for (int y = insetY; y < height - insetY; y++) {
            for (int x = insetX; x < width - insetX; x++) {
                int v = luma[y * width + x];
                if (v < innerMin) innerMin = v;
                if (v > innerMax) innerMax = v;
            }
        }
        if (innerMax - innerMin >= MIN_CONTRAST) {
            int brightCut = innerMax - (int) ((innerMax - innerMin) * 0.35);
            int darkCut = innerMin + (int) ((innerMax - innerMin) * 0.35);
            boolean[] brightMask = new boolean[width * height];
            boolean[] darkMask = new boolean[width * height];
            for (int y = insetY; y < height - insetY; y++) {
                for (int x = insetX; x < width - insetX; x++) {
                    int idx = y * width + x;
                    if (luma[idx] >= brightCut) brightMask[idx] = true;
                    if (luma[idx] <= darkCut) darkMask[idx] = true;
                }
            }
            Result rBright = evaluateMask(brightMask, width, height, "L", bg, minLuma, maxLuma);
            Result rDark = evaluateMask(darkMask, width, height, "D", bg, minLuma, maxLuma);
            best = pickBetter(best, rBright);
            best = pickBetter(best, rDark);
        }
        return best;
    }

    private static Result pickBetter(Result a, Result b) {
        if (b == null) return a;
        if (a == null) return b;
        if (b.isAccepted() && !a.isAccepted()) return b;
        if (a.isAccepted() && !b.isAccepted()) return a;
        if (b.confidence > a.confidence) return b;
        return a;
    }

    private static Result evaluateMask(boolean[] mask, int width, int height, String mode,
                                       int bg, int minLuma, int maxLuma) {
        int fgCount = 0;
        int minX = width, minY = height, maxX = -1, maxY = -1;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (mask[y * width + x]) {
                    fgCount++;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        double fill = (double) fgCount / (width * height);
        if (fill < MIN_FILL || fill > MAX_FILL || maxX <= minX || maxY <= minY) {
            return new Result(null, 0, 0, "FILL_OUT_OF_RANGE(" + mode + ",fill=" + Math.round(fill * 100)
                + "%,bg=" + bg + ",rng=" + minLuma + "-" + maxLuma + ")");
        }

        boolean[] norm = new boolean[GRID * GRID];
        int bw = maxX - minX + 1;
        int bh = maxY - minY + 1;
        for (int ny = 0; ny < GRID; ny++) {
            int sy = minY + (ny * bh) / GRID;
            for (int nx = 0; nx < GRID; nx++) {
                int sx = minX + (nx * bw) / GRID;
                norm[ny * GRID + nx] = mask[sy * width + sx];
            }
        }
        String shapeHex = encode8x8Hex(norm);

        // Structural quadrant densities to prevent U-turn false positives on L/R turns:
        // U-turn has strong foreground in BOTH bottom-left and bottom-right quadrants.
        int blCount = countRegion(norm, 0, 10, 6, 15);
        int brCount = countRegion(norm, 9, 10, 15, 15);

        double bestScore = -1.0;
        double secondScore = -1.0;
        int bestIdx = -1;
        for (int i = 0; i < TEMPLATES.length; i++) {
            double score = diceScore(norm, TEMPLATES[i]);
            // Penalize U-turn if either bottom-left or bottom-right stem is absent
            if (i == 5 && (blCount < 5 || brCount < 5)) {
                score -= 0.25;
            }
            if (score > bestScore) {
                secondScore = bestScore;
                bestScore = score;
                bestIdx = i;
            } else if (score > secondScore) {
                secondScore = score;
            }
        }
        double margin = bestScore - Math.max(0.0, secondScore);
        if (bestIdx < 0 || bestScore < MIN_CONFIDENCE) {
            return new Result(null, bestScore, margin, "LOW_CONFIDENCE_" + mode, shapeHex);
        }
        if (margin < MIN_MARGIN) {
            return new Result(null, bestScore, margin, "AMBIGUOUS_MARGIN_" + mode, shapeHex);
        }
        return new Result(LABELS[bestIdx], bestScore, margin, "ACCEPTED_" + mode, shapeHex);
    }

    private static int countRegion(boolean[] norm, int x0, int y0, int x1, int y1) {
        int c = 0;
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) {
                if (norm[y * GRID + x]) c++;
            }
        }
        return c;
    }

    private static String encode8x8Hex(boolean[] norm16) {
        char[] hex = "0123456789ABCDEF".toCharArray();
        char[] out = new char[16];
        for (int r = 0; r < 8; r++) {
            int rowBits = 0;
            for (int c = 0; c < 8; c++) {
                int votes = 0;
                for (int dy = 0; dy < 2; dy++) {
                    for (int dx = 0; dx < 2; dx++) {
                        if (norm16[(r * 2 + dy) * GRID + (c * 2 + dx)]) votes++;
                    }
                }
                if (votes >= 2) rowBits |= (1 << (7 - c));
            }
            out[r * 2] = hex[(rowBits >>> 4) & 15];
            out[r * 2 + 1] = hex[rowBits & 15];
        }
        return new String(out);
    }

    private static double diceScore(boolean[] a, boolean[] b) {
        int inter = 0, ca = 0, cb = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i]) ca++;
            if (b[i]) cb++;
            if (a[i] && b[i]) inter++;
        }
        if (ca + cb == 0) return 0.0;
        return (2.0 * inter) / (ca + cb);
    }

    private static boolean[][] buildTemplates() {
        boolean[][] t = new boolean[LABELS.length][GRID * GRID];
        // 0: 직진 (vertical stem + top arrowhead)
        fillRect(t[0], 6, 4, 9, 15);
        for (int r = 0; r <= 5; r++) fillRect(t[0], 7 - r, r, 8 + r, r);

        // 1: 좌회전 (right stem + top-aligned horizontal bar + left arrowhead, matching OEM TMAP)
        fillRect(t[1], 11, 2, 14, 15);
        fillRect(t[1], 4, 2, 14, 5);
        for (int c = 0; c <= 4; c++) fillRect(t[1], c, 3 - Math.min(3, c), c, 4 + c);

        // 2: 우회전 (left stem + top-aligned horizontal bar + right arrowhead, matching OEM TMAP)
        fillRect(t[2], 1, 2, 4, 15);
        fillRect(t[2], 1, 2, 11, 5);
        for (int c = 0; c <= 4; c++) fillRect(t[2], 15 - c, 3 - Math.min(3, c), 15 - c, 4 + c);

        // 3: 좌전방 (lower-right vertical stem + diagonal up-left shaft + top-left arrowhead)
        fillRect(t[3], 10, 9, 13, 15);
        drawThickLine(t[3], 11, 10, 3, 2, 1);
        fillRect(t[3], 0, 0, 6, 2);
        fillRect(t[3], 0, 0, 2, 6);

        // 4: 우전방 (lower-left vertical stem + diagonal up-right shaft + top-right arrowhead)
        fillRect(t[4], 2, 9, 5, 15);
        drawThickLine(t[4], 4, 10, 12, 2, 1);
        fillRect(t[4], 9, 0, 15, 2);
        fillRect(t[4], 13, 0, 15, 6);

        // 5: 유턴 (right stem up + top arch + left stem down + downward arrowhead at bottom-left)
        fillRect(t[5], 11, 2, 14, 15);
        fillRect(t[5], 3, 0, 13, 3);
        fillRect(t[5], 2, 2, 5, 13);
        for (int r = 0; r <= 3; r++) fillRect(t[5], 3 - r, 15 - r, 4 + r, 15 - r);

        return t;
    }

    private static void fillRect(boolean[] g, int x0, int y0, int x1, int y1) {
        for (int y = Math.max(0, y0); y <= Math.min(GRID - 1, y1); y++) {
            for (int x = Math.max(0, x0); x <= Math.min(GRID - 1, x1); x++) {
                g[y * GRID + x] = true;
            }
        }
    }

    private static void drawThickLine(boolean[] g, int x0, int y0, int x1, int y1, int radius) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (steps == 0) { fillRect(g, x0 - radius, y0 - radius, x0 + radius, y0 + radius); return; }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / steps;
            int y = y0 + (y1 - y0) * i / steps;
            fillRect(g, x - radius, y - radius, x + radius, y + radius);
        }
    }
}
