package com.dolphin.oemhud;

/** Independently derived legacy FFEA HUD Q safety frame; no Rubie/THUD extensions.
 * MCon K 2.1.5.004: Lma/p.e0, La/a.A/x, Lqa/d.<clinit>, Lma/p.c.
 * 19 4D 02 06 [camera bits] [limit km/h] [violation flag] [24-bit metres] 2F.
 * No overspeed assertion is made: this bridge has no verified current-speed input.
 */
public final class MconSafetyProtocol {
    private MconSafetyProtocol(){}
    public static byte[] fromCue(SafetyCue cue){
        if(cue==null)return null;
        return new byte[]{0x19,0x4d,0x02,0x06,(byte)cue.cameraMask,(byte)cue.limitKmh,0,
            (byte)(cue.distanceMeters>>>16),(byte)(cue.distanceMeters>>>8),(byte)cue.distanceMeters,0x2f};
    }
    public static byte[] clear(){return new byte[]{0x19,0x4d,0x02,0x06,0,0,0,0,0,0,0x2f};}
    public static boolean isClear(byte[] f){
        return isFrame(f)&&f[4]==0;
    }
    public static boolean isFrame(byte[] f){
        if(f==null||f.length!=11||f[0]!=0x19||f[1]!=0x4d||f[2]!=2||f[3]!=6||f[10]!=0x2f||f[6]!=0)return false;
        int mask=f[4]&255,speed=f[5]&255,meters=(f[7]&255)<<16|(f[8]&255)<<8|f[9]&255;
        if(mask==0)return speed==0&&meters==0;
        return (mask==1||mask==3||mask==4||mask==33)&&speed>=10&&speed<=150&&speed%5==0&&meters<=10000;
    }
}
