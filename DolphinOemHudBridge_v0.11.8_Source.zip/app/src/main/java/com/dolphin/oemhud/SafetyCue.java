package com.dolphin.oemhud;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Explicit warning from one selected navigation text row. No inferred vehicle speed. */
public final class SafetyCue {
    public static final long MAX_AGE_MS=5000;
    public final String sourcePackage, label;
    public final int cameraMask, limitKmh, distanceMeters;
    public final long observedElapsed;
    private SafetyCue(String pkg,String name,int mask,int speed,int meters,long at){
        sourcePackage=pkg;label=name;cameraMask=mask;limitKmh=speed;distanceMeters=meters;observedElapsed=at;
    }
    public boolean isFresh(long now){return now>=observedElapsed&&now-observedElapsed<MAX_AGE_MS;}
    public String key(){return sourcePackage+"/"+cameraMask+"/"+limitKmh+"/"+distanceMeters;}
    public String safeDisplay(){return label+" · 제한 "+limitKmh+"km/h · "+distanceMeters+"m";}
    private static final Pattern LIMIT=Pattern.compile("제한\\s*속도\\s*[:：]?\\s*([0-9]{1,3})\\s*(?:km\\s*/\\s*h|㎞\\s*/\\s*h|킬로미터\\s*/\\s*시)",Pattern.CASE_INSENSITIVE);
    private static final Pattern DISTANCE=Pattern.compile("(?<![0-9A-Za-z.,+\\-])([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+(?:[.,][0-9]+)?)\\s*(km|㎞|킬로미터|m|미터)(?![A-Za-z]|\\s*/)",Pattern.CASE_INSENSITIVE);
    private static final Pattern NEGATED=Pattern.compile("없음|없습니다|해제|종료|통과|테스트|예시|모의|시험|목적지|도착까지|총\\s*거리|전체\\s*거리");
    private static final Pattern CAMERA=Pattern.compile("과속\\s*(?:단속|카메라)|속도\\s*단속|단속\\s*카메라");
    /** Token presence is diagnostic only. It never pairs unrelated views into a warning. */
    public static String inputDiagnosis(String text){
        if(text==null||text.trim().isEmpty())return "화면·알림 글자 없음";
        if(text.length()>3000)return "입력 범위 초과";
        if(fromText("diagnostic.only",text,0)!=null)return "단속·제한속도·거리 확인";
        if(!CAMERA.matcher(text).find()&&!text.matches("(?s).*(?:구간\\s*단속|어린이\\s*보호\\s*구역|스쿨존).*"))return "단속 종류 글자 없음";
        if(!LIMIT.matcher(text).find())return "제한속도 글자·단위 미확인";
        if(!DISTANCE.matcher(text).find())return "단속까지 거리 미확인";
        return "정보 짝·범위 미확인";
    }
    public static SafetyCue fromText(String pkg,String text,long elapsed){
        if(pkg==null||!pkg.matches("[A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+")||text==null||elapsed<0)return null;
        if(text.length()>3000)return null;
        SafetyCue result=null;
        for(String row:text.split("[\\r\\n|]+")){
            String s=row.replaceAll("\\s+"," ").trim();
            if(s.isEmpty()||s.length()>240||NEGATED.matcher(s).find()||NavCue.hasDirectionToken(s))continue;
            int mask;String name;
            if(s.matches(".*(?:어린이\\s*보호\\s*구역|스쿨존).*")){mask=4;name="어린이 보호구역";}
            else if(s.matches(".*구간\\s*단속.*")){mask=33;name="구간 단속";}
            else if(CAMERA.matcher(s).find()){
                if(s.contains("신호")&&!s.matches(".*(?:과속|속도\\s*단속).*"))continue;
                mask=s.contains("신호")?3:1;name=mask==3?"신호·과속 단속":"과속 단속";
            }else continue;
            Matcher speed=LIMIT.matcher(s);
            if(!speed.find())continue;
            int limit=Integer.parseInt(speed.group(1));
            if(speed.find()||limit<10||limit>150||limit%5!=0)continue;
            Matcher distance=DISTANCE.matcher(s);
            if(!distance.find())continue;
            int meters=NavCue.distanceText(distance.group());
            if(distance.find()||meters<0||meters>10000)continue;
            SafetyCue candidate=new SafetyCue(pkg,name,mask,limit,meters,elapsed);
            // Duplicate notification fields are harmless; conflicting warnings are not.
            if(result!=null&&!result.key().equals(candidate.key()))return null;
            result=candidate;
        }
        return result;
    }
}
