# HUD 브릿지 R51 — 순정 TMAP 화면 화살표 공간 앵커·온디바이스 분류 및 멀티 내비 확장 (v0.11.1)

작성일: 2026-11-24 KST. 차량 기준: 한국형 BYD Dolphin 스탠다드 / 글로벌 2608(2602·2606 동일 개발 환경) / Android 10 / DiLink 3 / 1280×720 / ARIA HUD Q. 기준본 v0.11.0(code 32) → 산출물 v0.11.1(code 33).

## 1. 근본 원인 분리 및 설계 판단

기존 RE-001~RE-012 및 R27~R29, R50 증거에 따르면 순정 TMAP(`com.tmap.auto.byd`) 자동 TBT 미수신의 핵심 원인은 BLE 계층이 아니라 **입력 경로의 구조적 분리**입니다.

- **방향 화살표 비노출(RE-008/010)**: `TmapAutoTbtView`의 방향 화살표는 `contentDescription`과 방향성 View ID가 없는 동적 `ImageView`로 렌더링되며, 거리는 `TbtDistanceTextView` 텍스트로만 노출됩니다. 따라서 접근성 반복 조회 횟수를 늘려도 방향은 0건으로 남습니다.
- **순정 IPC/방송 한계(RE-004~011)**: `NaviService` AIDL은 바인딩(`AIDL_BOUND_NO_TBT`)만 확인되었고 다음 회전 TBT 계약이 미확정이며, 실제 확인된 순정 방송(`NAVIGATION_STATE_CHANGED`, `MAP_ACTIVITY_STATE_CHANGED`)은 상태 전용입니다. 권한 없는 내부 서비스나 비틀 런처 클러스터 콜백에 강제 접근하지 않습니다.
- **MediaProjection 진단 한계(R27~R29)**: Android 10에서는 `mediaProjection` 유형 전경 서비스가 필요하며([Android Developers — Foreground service types](https://developer.android.com/about/versions/14/changes/fgs-types-required)), `MediaProjection.Callback.onStop()`으로 시스템 중단에 대응해야 합니다([Android Developers — Media projection](https://developer.android.com/media/grow/media-projection)). v0.11.0의 `ScreenCaptureService`는 1회 픽셀 존재 여부만 확인하고 종료했으며 실제 화살표 ROI 해석 경로가 없었습니다.

## 2. v0.11.1 구현 구조 (온디바이스 공간 앵커 + 기하 분류기)

1. **공간 정합성 앵커 (`TbtVisualAnchor.java`, `NavAccessibilityService.java`)**:
   - 접근성 트리에서 `TbtDistanceTextView`(또는 상단 거리 위젯)의 화면 `Rect`와 동일 TBT 카드 주변의 무라벨 `ImageView` `Rect`를 추출해 크기(`24~320px`), 종횡비(`<= 2.2`), 박스 간격(`<= max(160px, 2.5×크기)`)으로 공간 정합성을 검증합니다.
   - 회전·분할화면에서도 고정 픽셀 좌표에 의존하지 않으며, 단조 시계 기준 3초(`MAX_AGE_MS=3000ms`)가 지난 거리는 즉시 폐기합니다.
2. **온디바이스 기하 화살표 분류기 (`VisualArrowClassifier.java`)**:
   - 외부 ML/네이티브 라이브러리 없이 순수 Java로 RGBA 버퍼의 화살표 ROI만 메모리 내에서 32×32 휘도 그리드로 샘플링합니다.
   - 테두리 배경 휘도 추정으로 다크/라이트 TBT 카드에 자동 적응하며, 16×16 정규화 바운딩 박스와 6방향(`직진`, `좌회전`, `우회전`, `좌전방`, `우전방`, `유턴`) 템플릿의 Dice 유사도를 계산합니다.
   - 최소 신뢰도(`0.52`), 1·2위 마진(`0.06`), 채움률(`0.04~0.68`) 및 **2프레임 연속 일치(`StabilityFilter`)**를 모두 통과해야만 `NavCue`를 생성합니다.
3. **일반 내비 및 안전운전 보강**:
   - 카카오내비(`com.locnall.kimgisa`), 카카오맵(`net.daum.android.map`) 명시 인식(`NavPackageMatcher.java`).
   - 알림 확장 필드(`EXTRA_TITLE_BIG`, `EXTRA_INFO_TEXT`, `EXTRA_TEXT_LINES`) 독립 줄 수집(`NavNotificationService.java`).
   - `NavCue.java`에 고속도로 좌/우 진·출입(MCon 코드 8~11) 추가, `SafetyCue.java`에 `스쿨존` 동의어 추가.

## 3. 추가 차량정보 표시 가능성 연구 (ARIA HUD Q 경계)

ARIA HUD Q(TPLAY HUD Q, MCon K BLE 프로토콜, [HL만도 아리아 HUD](http://topnkorea.kr/product/aria-hud/))는 범용 HDMI 디스플레이가 아니라 **고정 세그먼트/아이콘 전용 HUD**입니다.
- 확인된 프로토콜 범위: 길안내 회전 코드(`0x01 0x05`, 코드 0~18 + 24비트 거리), 안전운전 카메라/제한속도/거리(`0x02 0x06`, R50 DEX 근거), 부저·밝기 설정.
- **미지원 항목(임의 변환 금지)**: 배터리 잔량(SOC), 주행 가능거리(DTE), 타이어 공기압(TPMS), BSD 좌/우 감지, 차선이탈(LDW) 등은 ARIA HUD Q 프로토콜에 검증된 전용 프레임이 없으며, 차량 CAN/ECU 읽기·쓰기 없이 안전하게 표시할 수 없으므로 임의 숫자/아이콘으로 매핑하지 않습니다.

## 4. 검증 범위 및 한계

- **수행 완료(로컬 VM)**: 기존 Python 정적/회귀 게이트 6종 + v0.11.1 신규 게이트 9개, 보호 파일 4종 SHA-256 무변경 확인, Java 구문/브레이스/스텁 정합성 검증, `VisualArrowClassifier`·`TbtVisualAnchor`·정규식 알고리즘 Python 교차 검증.
- **로컬 미수행(환경 제약)**: 본 VM에 `javac`, Gradle, Android SDK가 없어 로컬 `:app:assembleDebug` APK 컴파일은 미수행(GitHub Actions `DolphinOemHudBridge_v0.11.1_Source.yml`로 즉시 빌드 가능). `DolphinOemHud_20261124_204136.zip`은 샌드박스 미마운트로 미분석.
- **실차 미검증**: 순정 TMAP 실제 화살표 이미지 인식 정확도, R50 안전운전 패킷 및 v0.11.1 화면 보조 인식의 ARIA HUD Q 실물 표시.

## 참고 공식 문서

- [Android Developers — Media projection](https://developer.android.com/media/grow/media-projection)
- [Android Developers — Foreground service types are required](https://developer.android.com/about/versions/14/changes/fgs-types-required)
- [Android Developers — AccessibilityService](https://developer.android.com/guide/topics/ui/accessibility/service)
- [Android Developers — BluetoothGattCallback](https://developer.android.com/reference/android/bluetooth/BluetoothGattCallback)
- [HL만도 아리아 HUD 제품 소개](http://topnkorea.kr/product/aria-hud/)
