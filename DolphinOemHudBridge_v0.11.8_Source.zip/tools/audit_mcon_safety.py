#!/usr/bin/env python3
"""Read-only protocol evidence from user-provided MCon K 2.1.5.004 XAPK.
No APK code execution, extraction of credentials, or device communication.
DEX parser helpers are retained from the user's HUD-RE-002 research package.
"""
from pathlib import Path
from zipfile import ZipFile
from tempfile import TemporaryDirectory
import argparse,hashlib,io,json,struct,sys,zlib

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'research/HUD-R50-20261117/analysis'))
from dex_inspect import Dex
from dex_call_audit import sizes,scan

def instructions(d,mid):
    ins=d.insns(mid);p=0
    while p<len(ins):
        w=ins[p];op=w&255;n=sizes.get(op,1)
        if op==0 and w>>8:
            kind=w>>8
            if kind==1:n=4+2*ins[p+1]
            elif kind==2:n=2+4*ins[p+1]
            elif kind==3:n=4+(ins[p+1]*(ins[p+2]|ins[p+3]<<16)+1)//2
        assert p+n<=len(ins)
        yield p,op,ins[p:p+n]
        p+=n

def fields(d):
    count,offset=struct.unpack_from('<II',d.data,0x50)
    result=[]
    for i in range(count):
        c,t,n=struct.unpack_from('<HHI',d.data,offset+8*i)
        result.append((d.types[c],d.strs[n],d.types[t]))
    return result

def method(d,cls,name):
    return next(i for i,(c,n,_) in enumerate(d.methods) if c==cls and n==name and i in d.code)

def strings(d,mid):return {v for kind,v,_ in scan(d,mid) if kind=='string'}

def verify_dex(data):
    assert data[:4]==b'dex\n'
    assert hashlib.sha1(data[32:]).digest()==data[12:32]
    assert zlib.adler32(data[12:])&0xffffffff==struct.unpack_from('<I',data,8)[0]

def audit(path):
    with ZipFile(path) as outer:
        apk=outer.read('kr.co.telecons.mcon.apk')
    with ZipFile(io.BytesIO(apk)) as z:
        raw=[z.read('classes.dex'),z.read('classes2.dex')]
    for data in raw:verify_dex(data)
    with TemporaryDirectory() as tmp:
        dex=[]
        for i,data in enumerate(raw):
            p=Path(tmp)/f'{i}.dex';p.write_bytes(data);dex.append(Dex(p))
        main,second=dex
        framing=method(main,'La/a;','x');builder=method(main,'La/a;','A')
        assert {'0x194d','2f'}<=strings(main,framing)
        assert {'02','06'}<=strings(main,builder)
        send=method(second,'Lma/p;','e0')
        calls={v for k,v,_ in scan(second,send) if k=='call'}
        assert ('La/a;','A') in calls and ('La/a;','x') in calls

        # Recover Kotlin enum-to-switch mapping, using actual ordinal calls and aput.
        fs=fields(second);regs={};pending=None;cases={}
        mid=method(second,'Lqa/d;','<clinit>')
        for pc,op,w in instructions(second,mid):
            word=w[0]
            if op==0x12:regs[word>>8&15]=(word>>12)-16 if word>>12>=8 else word>>12
            elif op==0x13:regs[word>>8]=struct.unpack('<h',struct.pack('<H',w[1]))[0]
            elif op==0x62:regs[word>>8]=fs[w[1]]
            elif op==0x6e and second.methods[w[1]][:2]==('Ljava/lang/Enum;','ordinal'):
                pending=regs.get(w[2]&15)
            elif op==0x0a:regs[word>>8]=pending
            elif op==0x4b:
                key=regs.get(w[1]>>8);value=regs.get(word>>8)
                if isinstance(key,tuple) and key[0]=='Loa/q;' and isinstance(value,int):cases[key[1]]=value

        add=method(second,'Lma/p;','c');ins=second.insns(add);code=list(instructions(second,add))
        literal={}
        for pc,op,w in code:
            if pc>=89:break
            if op==0x1a:literal[w[0]>>8]=second.strs[w[1]]
        switch=next((p,w) for p,op,w in code if op==0x2b)
        switchpc,words=switch
        offset=words[1]|words[2]<<16
        if offset&0x80000000:offset-=0x100000000
        payload=switchpc+offset
        assert ins[payload]==0x100
        count=ins[payload+1];first=ins[payload+2]|ins[payload+3]<<16
        targets={}
        for i in range(count):
            delta=ins[payload+4+2*i]|ins[payload+5+2*i]<<16
            if delta&0x80000000:delta-=0x100000000
            targets[first+i]=switchpc+delta
        bits={}
        for name,case in cases.items():
            target=targets[case]
            parse_calls=[w for p,op,w in code if target<=p<target+13 and op==0x71 and second.methods[w[1]][:2]==('Ljava/lang/Integer;','parseInt')]
            assert len(parse_calls)==2
            register=parse_calls[1][2]&15
            bits[name]=int(literal[register])
        assert bits['CAMERA']==1 and bits['SIGNAL_SPEED_CAMERA']==2
        assert bits['CHILD_PROTECTION_ZONE']==4 and bits['SECTION_CAMERA']==32
        return {'input_name':Path(path).name,'input_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'dex_sha256':[hashlib.sha256(b).hexdigest() for b in raw],
            'dex_integrity':'SHA1/Adler32 PASS','framing':'19 4D 02 06 [camera bits] [limit] [violation] [distance BE24] 2F',
            'native_camera_bits':bits,'bridge_supported_masks':{'speed':1,'signal_speed':3,'child':4,'section':33},
            'scope':'Static interoperability evidence only. No physical HUD or OEM automatic input validation.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('xapk');args=parser.parse_args()
    print(json.dumps(audit(args.xapk),ensure_ascii=False,indent=2))
