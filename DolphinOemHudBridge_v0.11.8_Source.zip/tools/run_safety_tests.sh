#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"; trap 'rm -rf "$out"' EXIT
javac -encoding UTF-8 -d "$out" tests/java/android/os/Bundle.java \
  app/src/main/java/com/dolphin/oemhud/{NavCue,MconHudQProtocol,SafetyCue,MconSafetyProtocol}.java \
  tests/java/com/dolphin/oemhud/SafetyCueTest.java
java -cp "$out" com.dolphin.oemhud.SafetyCueTest

javac -encoding UTF-8 -d "$out" tests/java/android/os/Bundle.java app/src/main/java/com/dolphin/oemhud/{NavCue,MconHudQProtocol,SafetyCue,MconSafetyProtocol,MconSpeedProtocol}.java tests/java/com/dolphin/oemhud/MconSpeedProtocolTest.java
java -cp "$out" com.dolphin.oemhud.MconSpeedProtocolTest
