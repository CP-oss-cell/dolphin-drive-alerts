# v0.11.1 / versionCode 33

기준본: v0.11.0 (versionCode 32). 기존 정상 작동 기능(BLE GATT FFEA/FFF2, 수동 우회전 300m, 수동·자동 밝기 및 시간표, R50 안전운전 프로토콜, ADB Kotlin 구현, RE-012 보호 파일 4종 SHA-256)을 그대로 보존했습니다.

## 주요 변경 사항

- **`TbtVisualAnchor.java` (신규)**: `NavAccessibilityService`가 순정 TMAP(`com.tmap.auto.byd`) 또는 선택 내비의 `TbtDistanceTextView`(거리 위젯)와 같은 TBT 카드 영역에 인접한 무라벨 `ImageView`(방향 화살표)의 화면 `Rect`를 공간 거리·크기·종횡비 기준으로 검증해 3초 유효 앵커로 묶습니다. 화면 픽셀·도로명·목적지는 저장하지 않습니다.
- **`VisualArrowClassifier.java` (신규)**: 외부 라이브러리 없이 순수 Java 메모리 내에서 동작하는 6방향(`직진`, `좌회전`, `우회전`, `좌전방`, `우전방`, `유턴`) 기하 화살표 분류기 및 2프레임 연속 일치 안정화 필터(`StabilityFilter`)를 구현했습니다. 검은 화면·저대비·모호한 마진·비정상 채움률은 fail-closed로 차단하며 추측값을 HUD에 보내지 않습니다.
- **`ScreenCaptureService.java` / `ScreenCaptureProbe.java` (개선)**:
  - Android 10(API 29)에서 `startForeground(..., ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)`를 명시 호출하고 `MediaProjection.Callback.onStop()`을 등록해 시스템 종료 시 리소스를 안전하게 해제합니다.
  - 기존 1회 화면 캡처 진단에 TBT 앵커 ROI 및 분류기 진단 결과를 함께 기록합니다(HUD 송신 없음).
  - 사용자 명시적 동의 기반의 **순정 화살표 화면 보조 인식** 세션(`1.2초` 주기, 메모리 내 처리, 2프레임 연속 일치 + 3초 신선 앵커 결합)을 실험·실차 검증 기능으로 추가했습니다(기본 OFF).
- **일반 내비 및 안전운전 파서 확장**:
  - `NavPackageMatcher.java`: 카카오내비(`com.locnall.kimgisa`), 카카오맵(`net.daum.android.map`), 일반 TMAP(`com.skt.tmap.ku`), 네이버지도(`com.nhn.android.nmap`)를 패키지명만으로 명시 인식합니다.
  - `NavNotificationService.java`: 기존 필드 외 `EXTRA_TITLE_BIG`, `EXTRA_INFO_TEXT`, `EXTRA_TEXT_LINES`를 각각 독립 줄로 수집합니다(서로 다른 줄 결합 금지 정책 유지).
  - `NavCue.java`: `MconHudQProtocol`이 이미 지원하는 고속도로 좌/우 진·출입(`고속도로 왼쪽 진입`, `고속도로 오른쪽 진입`, `고속도로 왼쪽 진출`, `고속도로 오른쪽 진출`, 코드 8~11)을 파싱하도록 확장했습니다.
  - `SafetyCue.java`: `어린이 보호구역`의 한국어 동의어 `스쿨존`을 추가했습니다(동일 행 명시적 제한속도 `km/h` + 거리 필수 정책 유지).
- **자동 진단 및 대시보드 (`MainActivity.java`, `NavInputTrace.java`)**:
  - `NavInputTrace`에 `visual_assist` 채널을 독립 추가했습니다.
  - 정차 시 **실제 HUD 표시 확인(미확인 / 수동 표시 확인 / 자동 표시 확인)**을 기록해 원터치 진단 ZIP(`report.txt`)에 자동 포함하도록 개선했습니다.

## 미검증 및 환경 제한 사항

- 본 샌드박스 VM에는 `javac`, Gradle, Android SDK 및 외부 인터넷이 설치되어 있지 않아 `:app:assembleDebug` 로컬 APK 컴파일은 수행하지 못했습니다. 동봉된 `DolphinOemHudBridge_v0.11.1_Source.yml`(GitHub Actions)에서 Android SDK 34 + Gradle 8.6으로 전체 단위 테스트·시뮬레이션·APK 컴파일을 자동 실행할 수 있습니다.
- 첨부 목록에 표시된 `DolphinOemHud_20261124_204136.zip`은 샌드박스 파일시스템에 마운트되지 않아 분석에 포함하지 못했습니다.
- 사용자 동의 기반 화면 화살표 보조 인식과 R50 안전운전 패킷의 실제 차량 및 ARIA HUD Q 실물 표시는 **아직 실차 미검증**이며, 실차 확인 전까지 자동 연동 성공으로 판정하지 않습니다.
