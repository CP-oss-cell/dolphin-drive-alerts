# R29 v0.10.11 진단 수정
- 근거: 2026-11-09 07:43 실차 로그, `ERROR_AT_GET_MEDIA_PROJECTION_SecurityException` 2회.
- 원인 가설: Android 10 mediaProjection 유형 foreground service 미사용. 단정 불가.
- 수정: 사용자 동의 결과를 mediaProjection 유형 포그라운드 서비스로 전달하고 `startForeground()` 이후 `getMediaProjection()` 호출.
- 프레임은 메모리 내 샘플링만 하고 이미지·텍스트 저장 없음. 자동 HUD 안내 송신 없음.
- 기존 BLE 및 자동 밝기 소스 미변경. 실제 APK 컴파일과 실차 성공 미검증.
