package com.dolphin.oemhud;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.util.Locale;

/**
 * Consent-gated MediaProjection screen diagnostic and opt-in on-device arrow assist.
 * Never persists screenshots, raw pixels, road names, or destinations.
 */
public final class ScreenCaptureProbe {
    public interface Callback { void done(String status); }
    private ScreenCaptureProbe(){}

    /** One-shot diagnostic: verifies frame visibility and checks TBT ROI classifier without HUD TX. */
    public static void runOnce(Context activity,int resultCode,Intent data,Callback cb){
        final Handler handler=new Handler(Looper.getMainLooper());
        MediaProjection projection=null;
        ImageReader reader=null;
        VirtualDisplay display=null;
        String stage="INIT";
        try{
            if(resultCode!=Activity.RESULT_OK || data==null){cb.done("CONSENT_MISSING");return;}
            stage="DISPLAY_METRICS";
            DisplayMetrics dm=new DisplayMetrics();
            ((WindowManager)activity.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            int w=dm.widthPixels,h=dm.heightPixels;
            if(w<1||h<1||w>4096||h>4096)throw new IllegalStateException("invalid display");
            stage="PROJECTION_MANAGER";
            MediaProjectionManager manager=(MediaProjectionManager)activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if(manager==null)throw new IllegalStateException("manager null");
            stage="GET_MEDIA_PROJECTION";
            projection=manager.getMediaProjection(resultCode,data);
            if(projection==null)throw new IllegalStateException("projection null");
            stage="IMAGE_READER";
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            final MediaProjection mp=projection;
            final ImageReader ir=reader;
            final boolean[] finished={false};
            final Runnable[] cleanupRef={null};
            final Runnable[] timeoutRef={null};
            mp.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop(){
                    if(!finished[0]){
                        finished[0]=true;
                        if(timeoutRef[0]!=null)handler.removeCallbacks(timeoutRef[0]);
                        if(cleanupRef[0]!=null)cleanupRef[0].run();
                        cb.done("PROJECTION_STOPPED_BY_SYSTEM");
                    }
                }
            },handler);
            stage="CREATE_VIRTUAL_DISPLAY";
            final VirtualDisplay vd=projection.createVirtualDisplay("HUD consented diagnostic",w,h,dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
            if(vd==null)throw new IllegalStateException("display null");
            display=vd;
            final long readyAt=SystemClock.uptimeMillis()+5000;
            final Runnable cleanup=()->{try{vd.release();}catch(Exception ignored){}try{ir.close();}catch(Exception ignored){}try{mp.stop();}catch(Exception ignored){}};
            cleanupRef[0]=cleanup;
            final Runnable timeout=()->{if(!finished[0]){finished[0]=true;cleanup.run();cb.done("TIMEOUT_NO_FRAME_AFTER_CONSENT");}};
            timeoutRef[0]=timeout;
            handler.postDelayed(timeout,9500);
            stage="FRAME_LISTENER";
            reader.setOnImageAvailableListener(r->{
                if(finished[0])return;
                Image img=null;
                try{
                    img=r.acquireLatestImage();if(img==null)return;
                    if(SystemClock.uptimeMillis()<readyAt)return;
                    Image.Plane plane=img.getPlanes()[0];ByteBuffer pixels=plane.getBuffer();
                    int stride=plane.getRowStride(),step=plane.getPixelStride();
                    long samples=0,visible=0;int min=255,max=0;
                    for(int y=0;y<h;y+=Math.max(1,h/40))for(int x=0;x<w;x+=Math.max(1,w/60)){
                        int pos=y*stride+x*step;if(pos+2>=pixels.limit())continue;
                        int v=((pixels.get(pos)&255)+(pixels.get(pos+1)&255)+(pixels.get(pos+2)&255))/3;
                        min=Math.min(min,v);max=Math.max(max,v);if(v>15)visible++;samples++;
                    }
                    String visualNote=" anchor=NONE";
                    TbtVisualAnchor.Snapshot anchor=TbtVisualAnchor.getFresh(null,SystemClock.elapsedRealtime());
                    if(anchor!=null && visible>0){
                        VisualArrowClassifier.Result res=VisualArrowClassifier.classifyRgbaRegion(
                            pixels,w,h,stride,step,anchor.arrowLeft,anchor.arrowTop,anchor.arrowRight,anchor.arrowBottom);
                        visualNote=String.format(Locale.US," anchor=%s visual=%s(%.2f/%s)",
                            anchor.safeSummary(),res.isAccepted()?res.direction:"REJECT",res.confidence,res.reason);
                    }
                    String status=(samples==0?"NO_PIXELS":(visible==0?"BLACK_OR_PROTECTED":"FRAME_VISIBLE"))+
                        " size="+w+"x"+h+" sample="+samples+" visible="+visible+" range="+min+"-"+max+
                        visualNote+" (DIAGNOSTIC_ONLY)";
                    finished[0]=true;handler.removeCallbacks(timeout);cleanup.run();cb.done(status);
                }catch(Exception e){if(!finished[0]){finished[0]=true;handler.removeCallbacks(timeout);cleanup.run();cb.done("FRAME_ERROR_"+e.getClass().getSimpleName());}}
                finally{if(img!=null)img.close();}
            },handler);
        }catch(Exception e){if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();cb.done("ERROR_AT_"+stage+"_"+e.getClass().getSimpleName());}
    }

    /**
     * Opt-in, low-cadence (1.2s) consented visual arrow assist session.
     * Classifies ONLY the spatially co-located arrow ImageView ROI anchored by NavAccessibilityService
     * and requires 2 consecutive identical frames before emitting a NavCue.
     */
    public static final class VisualAssistSession {
        private static final long SAMPLE_INTERVAL_MS=1200L;
        private final Context context;
        private final Handler handler=new Handler(Looper.getMainLooper());
        private final VisualArrowClassifier.StabilityFilter stability=new VisualArrowClassifier.StabilityFilter();
        private final Runnable onStopped;
        private MediaProjection projection;
        private ImageReader reader;
        private VirtualDisplay display;
        private int width, height;
        private long lastSampleElapsed;
        private String lastSentKey="";
        private long lastSentElapsed;
        private volatile boolean stopped;

        public VisualAssistSession(Context ctx,Runnable stoppedCallback){
            context=ctx.getApplicationContext();
            onStopped=stoppedCallback;
        }

        public boolean start(int resultCode,Intent data){
            String stage="INIT";
            try{
                if(resultCode!=Activity.RESULT_OK || data==null){recordState("CONSENT_MISSING");return false;}
                stage="DISPLAY_METRICS";
                DisplayMetrics dm=new DisplayMetrics();
                ((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
                width=dm.widthPixels;height=dm.heightPixels;
                if(width<1||height<1||width>4096||height>4096)throw new IllegalStateException("invalid display");
                stage="PROJECTION_MANAGER";
                MediaProjectionManager manager=(MediaProjectionManager)context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                if(manager==null)throw new IllegalStateException("manager null");
                stage="GET_MEDIA_PROJECTION";
                projection=manager.getMediaProjection(resultCode,data);
                if(projection==null)throw new IllegalStateException("projection null");
                projection.registerCallback(new MediaProjection.Callback(){
                    @Override public void onStop(){
                        recordState("STOPPED_BY_SYSTEM");
                        stop();
                    }
                },handler);
                stage="IMAGE_READER";
                reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
                stage="CREATE_VIRTUAL_DISPLAY";
                display=projection.createVirtualDisplay("HUD visual arrow assist",width,height,dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
                if(display==null)throw new IllegalStateException("display null");
                reader.setOnImageAvailableListener(this::onFrameAvailable,handler);
                recordState("ACTIVE_WAITING_ANCHOR");
                BridgeLog.event(context,"화면 화살표 보조 인식 시작 · 온디바이스 메모리 전용");
                return true;
            }catch(Exception e){
                recordState("ERROR_AT_"+stage+"_"+e.getClass().getSimpleName());
                stop();
                return false;
            }
        }

        private void onFrameAvailable(ImageReader r){
            if(stopped)return;
            Image img=null;
            try{
                img=r.acquireLatestImage();
                if(img==null)return;
                long nowElapsed=SystemClock.elapsedRealtime();
                if(nowElapsed-lastSampleElapsed<SAMPLE_INTERVAL_MS)return;
                lastSampleElapsed=nowElapsed;

                SharedPreferences p=context.getSharedPreferences(BridgeLog.STORE,0);
                if(!p.getBoolean("enabled",false)){
                    stability.reset();
                    return;
                }
                String selected=p.getString("nav_package","").trim();
                TbtVisualAnchor.Snapshot anchor=TbtVisualAnchor.getFresh(selected,nowElapsed);
                if(anchor==null){
                    stability.reset();
                    p.edit().putString("visual_assist_state","ACTIVE_NO_FRESH_ANCHOR").apply();
                    return;
                }
                Image.Plane plane=img.getPlanes()[0];
                VisualArrowClassifier.Result res=VisualArrowClassifier.classifyRgbaRegion(
                    plane.getBuffer(),width,height,plane.getRowStride(),plane.getPixelStride(),
                    anchor.arrowLeft,anchor.arrowTop,anchor.arrowRight,anchor.arrowBottom);
                int checked=p.getInt("visual_frames_checked",0)+1;
                String confText=String.format(Locale.US,"%.2f",res.confidence);
                if(!res.isAccepted()){
                    stability.reset();
                    p.edit().putInt("visual_frames_checked",checked)
                        .putInt("visual_arrow_rejected",p.getInt("visual_arrow_rejected",0)+1)
                        .putString("visual_last_reason",res.reason)
                        .putString("visual_last_confidence",confText)
                        .putString("visual_assist_state","ACTIVE_REJECTED_"+res.reason).apply();
                    NavInputTrace.observe(context,anchor.packageName,"visual_assist",1,false,true,false);
                    return;
                }
                String stableDir=stability.accept(res.direction,nowElapsed);
                if(stableDir==null){
                    p.edit().putInt("visual_frames_checked",checked)
                        .putString("visual_last_reason","AWAITING_2ND_FRAME")
                        .putString("visual_last_confidence",confText)
                        .putString("visual_assist_state","ACTIVE_CONFIRMING_"+res.direction).apply();
                    return;
                }
                NavCue cue=new NavCue("순정화면인식:"+anchor.packageName,stableDir,anchor.distanceMeters,"",-1,-1,"");
                boolean usable=cue.isUsable();
                NavInputTrace.observe(context,anchor.packageName,"visual_assist",1,true,true,usable);
                p.edit().putInt("visual_frames_checked",checked)
                    .putInt("visual_arrow_accepted",p.getInt("visual_arrow_accepted",0)+1)
                    .putString("visual_last_reason","ACCEPTED")
                    .putString("visual_last_confidence",confText)
                    .putString("visual_last_direction",stableDir)
                    .putString("visual_assist_state","ACTIVE_ACCEPTED_"+stableDir+"_"+anchor.distanceMeters+"m").apply();
                if(usable){
                    String key=stableDir+"/"+anchor.distanceMeters;
                    if(!key.equals(lastSentKey) || (nowElapsed-lastSentElapsed)>=8000L){
                        lastSentKey=key;lastSentElapsed=nowElapsed;
                        p.edit().putInt("nav_parsed_count",p.getInt("nav_parsed_count",0)+1)
                            .putInt("nav_session_parsed",p.getInt("nav_session_parsed",0)+1)
                            .putLong("nav_last_parsed_at",System.currentTimeMillis())
                            .putString("last_nav_input_source",cue.source).apply();
                        BridgeLog.cue(context,cue);
                    }
                }
            }catch(Exception e){
                recordState("FRAME_ERROR_"+e.getClass().getSimpleName());
            }finally{
                if(img!=null)img.close();
            }
        }

        private void recordState(String state){
            context.getSharedPreferences(BridgeLog.STORE,0).edit()
                .putString("visual_assist_state",state)
                .putLong("visual_assist_updated_at",System.currentTimeMillis()).apply();
        }

        public synchronized void stop(){
            if(stopped)return;
            stopped=true;
            stability.reset();
            try{if(display!=null)display.release();}catch(Exception ignored){}
            try{if(reader!=null)reader.close();}catch(Exception ignored){}
            try{if(projection!=null)projection.stop();}catch(Exception ignored){}
            display=null;reader=null;projection=null;
            if(onStopped!=null)handler.post(onStopped);
        }
    }
}
