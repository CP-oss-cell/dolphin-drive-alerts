package com.dolphin.oemhud;

import java.nio.ByteBuffer;

/**
 * Lightweight, zero-dependency, fail-closed on-device geometric arrow classifier.
 * Operates strictly in memory on a cropped TBT arrow ROI; never persists pixels.
 * Supported maneuvers: 직진, 좌회전, 우회전, 좌전방, 우전방, 유턴.
 */
public final class VisualArrowClassifier {
    public static final int GRID = 16;
    public static final int MIN_CONTRAST = 28;
    public static final double MIN_FILL = 0.04;
    public static final double MAX_FILL = 0.68;
    public static final double MIN_CONFIDENCE = 0.52;
    public static final double MIN_MARGIN = 0.06;

    public static final class Result {
        public final String direction; // null when rejected (fail-closed)
        public final double confidence;
        public final double margin;
        public final String reason;

        public Result(String dir, double conf, double gap, String why) {
            direction = dir;
            confidence = conf;
            margin = gap;
            reason = why == null ? "" : why;
        }

        public boolean isAccepted() { return direction != null && !direction.isEmpty(); }
    }

    /** Requires two consecutive identical detections within 3.5s before emitting a turn. */
    public static final class StabilityFilter {
        public static final long MAX_GAP_MS = 3500L;
        private String lastCandidate;
        private long lastAtElapsed;
        private int streak;

        public synchronized String accept(String direction, long nowElapsed) {
            if (direction == null || direction.isEmpty()) {
                reset();
                return null;
            }
            if (direction.equals(lastCandidate) && nowElapsed >= lastAtElapsed
                    && (nowElapsed - lastAtElapsed) <= MAX_GAP_MS) {
                streak++;
            } else {
                lastCandidate = direction;
                streak = 1;
            }
            lastAtElapsed = nowElapsed;
            return streak >= 2 ? direction : null;
        }

        public synchronized void reset() {
            lastCandidate = null;
            lastAtElapsed = 0L;
            streak = 0;
        }
    }

    private static final String[] LABELS = {"직진", "좌회전", "우회전", "좌전방", "우전방", "유턴"};
    private static final boolean[][] TEMPLATES = buildTemplates();

    private VisualArrowClassifier() {}

    /** Classify directly from an RGBA_8888 Image.Plane buffer slice without allocating a Bitmap. */
    public static Result classifyRgbaRegion(ByteBuffer pixels, int fullW, int fullH,
                                            int rowStride, int pixelStride,
                                            int left, int top, int right, int bottom) {
        if (pixels == null || fullW <= 0 || fullH <= 0 || pixelStride < 3) {
            return new Result(null, 0, 0, "INVALID_BUFFER");
        }
        int x0 = Math.max(0, Math.min(fullW - 1, left));
        int y0 = Math.max(0, Math.min(fullH - 1, top));
        int x1 = Math.max(x0 + 1, Math.min(fullW, right));
        int y1 = Math.max(y0 + 1, Math.min(fullH, bottom));
        int rw = x1 - x0;
        int rh = y1 - y0;
        if (rw < 16 || rh < 16) return new Result(null, 0, 0, "ROI_TOO_SMALL");

        final int sampleN = 32;
        int[] luma = new int[sampleN * sampleN];
        int limit = pixels.limit();
        for (int sy = 0; sy < sampleN; sy++) {
            int py = y0 + (sy * rh) / sampleN;
            for (int sx = 0; sx < sampleN; sx++) {
                int px = x0 + (sx * rw) / sampleN;
                int pos = py * rowStride + px * pixelStride;
                if (pos < 0 || pos + 2 >= limit) continue;
                int r = pixels.get(pos) & 255;
                int g = pixels.get(pos + 1) & 255;
                int b = pixels.get(pos + 2) & 255;
                luma[sy * sampleN + sx] = (r * 30 + g * 59 + b * 11) / 100;
            }
        }
        return classifyLumaGrid(luma, sampleN, sampleN);
    }

    /** Pure-Java entry point for JVM unit tests and in-memory luminance grids. */
    public static Result classifyLumaGrid(int[] luma, int width, int height) {
        if (luma == null || width < 8 || height < 8 || luma.length < width * height) {
            return new Result(null, 0, 0, "INVALID_GRID");
        }
        long borderSum = 0;
        int borderCount = 0;
        for (int x = 0; x < width; x++) {
            borderSum += luma[x];
            borderSum += luma[(height - 1) * width + x];
            borderCount += 2;
        }
        for (int y = 1; y < height - 1; y++) {
            borderSum += luma[y * width];
            borderSum += luma[y * width + (width - 1)];
            borderCount += 2;
        }
        int bg = (int) (borderSum / Math.max(1, borderCount));

        int maxDiff = 0;
        for (int i = 0; i < width * height; i++) {
            int d = Math.abs(luma[i] - bg);
            if (d > maxDiff) maxDiff = d;
        }
        if (maxDiff < MIN_CONTRAST) {
            return new Result(null, 0, 0, "BLANK_OR_LOW_CONTRAST");
        }

        int threshold = Math.max(MIN_CONTRAST, (int) (maxDiff * 0.42));
        boolean[] mask = new boolean[width * height];
        int fgCount = 0;
        int minX = width, minY = height, maxX = -1, maxY = -1;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int idx = y * width + x;
                if (Math.abs(luma[idx] - bg) >= threshold) {
                    mask[idx] = true;
                    fgCount++;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        double fill = (double) fgCount / (width * height);
        if (fill < MIN_FILL || fill > MAX_FILL || maxX <= minX || maxY <= minY) {
            return new Result(null, 0, 0, "FILL_OUT_OF_RANGE");
        }

        // Normalize tight foreground bounding box into 16x16 grid.
        boolean[] norm = new boolean[GRID * GRID];
        int bw = maxX - minX + 1;
        int bh = maxY - minY + 1;
        for (int ny = 0; ny < GRID; ny++) {
            int sy = minY + (ny * bh) / GRID;
            for (int nx = 0; nx < GRID; nx++) {
                int sx = minX + (nx * bw) / GRID;
                norm[ny * GRID + nx] = mask[sy * width + sx];
            }
        }

        double bestScore = -1.0;
        double secondScore = -1.0;
        int bestIdx = -1;
        for (int i = 0; i < TEMPLATES.length; i++) {
            double score = diceScore(norm, TEMPLATES[i]);
            if (score > bestScore) {
                secondScore = bestScore;
                bestScore = score;
                bestIdx = i;
            } else if (score > secondScore) {
                secondScore = score;
            }
        }
        double margin = bestScore - Math.max(0.0, secondScore);
        if (bestIdx < 0 || bestScore < MIN_CONFIDENCE) {
            return new Result(null, bestScore, margin, "LOW_CONFIDENCE");
        }
        if (margin < MIN_MARGIN) {
            return new Result(null, bestScore, margin, "AMBIGUOUS_MARGIN");
        }
        return new Result(LABELS[bestIdx], bestScore, margin, "ACCEPTED");
    }

    private static double diceScore(boolean[] a, boolean[] b) {
        int inter = 0, ca = 0, cb = 0;
        for (int i = 0; i < a.length; i++) {
            if (a[i]) ca++;
            if (b[i]) cb++;
            if (a[i] && b[i]) inter++;
        }
        if (ca + cb == 0) return 0.0;
        return (2.0 * inter) / (ca + cb);
    }

    private static boolean[][] buildTemplates() {
        boolean[][] t = new boolean[LABELS.length][GRID * GRID];
        // 0: 직진 (vertical stem + top arrowhead)
        fillRect(t[0], 6, 4, 9, 15);
        for (int r = 0; r <= 5; r++) fillRect(t[0], 7 - r, r, 8 + r, r);

        // 1: 좌회전 (right-side vertical stem + horizontal left arm + left arrowhead)
        fillRect(t[1], 10, 4, 13, 15);
        fillRect(t[1], 3, 4, 13, 7);
        for (int c = 0; c <= 4; c++) fillRect(t[1], c, 5 - c, c, 6 + c);

        // 2: 우회전 (left-side vertical stem + horizontal right arm + right arrowhead)
        fillRect(t[2], 2, 4, 5, 15);
        fillRect(t[2], 2, 4, 12, 7);
        for (int c = 0; c <= 4; c++) fillRect(t[2], 15 - c, 5 - c, 15 - c, 6 + c);

        // 3: 좌전방 (lower-right vertical stem + diagonal up-left shaft + top-left arrowhead)
        fillRect(t[3], 10, 9, 13, 15);
        drawThickLine(t[3], 11, 10, 3, 2, 1);
        fillRect(t[3], 0, 0, 6, 2);
        fillRect(t[3], 0, 0, 2, 6);

        // 4: 우전방 (lower-left vertical stem + diagonal up-right shaft + top-right arrowhead)
        fillRect(t[4], 2, 9, 5, 15);
        drawThickLine(t[4], 4, 10, 12, 2, 1);
        fillRect(t[4], 9, 0, 15, 2);
        fillRect(t[4], 13, 0, 15, 6);

        // 5: 유턴 (right stem up + top arch + left stem down + downward arrowhead at bottom-left)
        fillRect(t[5], 11, 2, 14, 15);
        fillRect(t[5], 3, 0, 13, 3);
        fillRect(t[5], 2, 2, 5, 12);
        for (int r = 0; r <= 3; r++) fillRect(t[5], 3 - r, 15 - r, 4 + r, 15 - r);

        return t;
    }

    private static void fillRect(boolean[] g, int x0, int y0, int x1, int y1) {
        for (int y = Math.max(0, y0); y <= Math.min(GRID - 1, y1); y++) {
            for (int x = Math.max(0, x0); x <= Math.min(GRID - 1, x1); x++) {
                g[y * GRID + x] = true;
            }
        }
    }

    private static void drawThickLine(boolean[] g, int x0, int y0, int x1, int y1, int radius) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (steps == 0) { fillRect(g, x0 - radius, y0 - radius, x0 + radius, y0 + radius); return; }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / steps;
            int y = y0 + (y1 - y0) * i / steps;
            fillRect(g, x - radius, y - radius, x + radius, y + radius);
        }
    }
}
