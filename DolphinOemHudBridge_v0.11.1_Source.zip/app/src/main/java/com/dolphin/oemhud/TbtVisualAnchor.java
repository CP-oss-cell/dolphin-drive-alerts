package com.dolphin.oemhud;

/**
 * Pure-Java spatial anchor linking a visible TBT distance widget and its co-located
 * unlabeled arrow ImageView within the same navigation card.
 * Never persists screenshots, road names, destinations, or raw screen text.
 */
public final class TbtVisualAnchor {
    public static final long MAX_AGE_MS = 3000L;
    public static final int MIN_ARROW_PX = 24;
    public static final int MAX_ARROW_PX = 320;
    public static final double MAX_ASPECT_RATIO = 2.2;

    public static final class Snapshot {
        public final String packageName;
        public final int distanceMeters;
        public final int distLeft, distTop, distRight, distBottom;
        public final int arrowLeft, arrowTop, arrowRight, arrowBottom;
        public final long observedElapsed;

        public Snapshot(String pkg, int meters,
                        int dL, int dT, int dR, int dB,
                        int aL, int aT, int aR, int aB,
                        long elapsed) {
            packageName = pkg == null ? "" : pkg;
            distanceMeters = meters;
            distLeft = dL; distTop = dT; distRight = dR; distBottom = dB;
            arrowLeft = aL; arrowTop = aT; arrowRight = aR; arrowBottom = aB;
            observedElapsed = elapsed;
        }

        public boolean isFresh(long nowElapsed) {
            return nowElapsed >= observedElapsed && (nowElapsed - observedElapsed) < MAX_AGE_MS;
        }

        public boolean matchesPackage(String pkg) {
            return pkg != null && !pkg.isEmpty() && pkg.equals(packageName);
        }

        public int arrowWidth() { return Math.max(0, arrowRight - arrowLeft); }
        public int arrowHeight() { return Math.max(0, arrowBottom - arrowTop); }

        public String safeSummary() {
            return "dist=" + distanceMeters + "m arrow=" + arrowWidth() + "x" + arrowHeight()
                + "@(" + arrowLeft + "," + arrowTop + ")";
        }
    }

    private static volatile Snapshot latest;

    private TbtVisualAnchor() {}

    public static void clear() { latest = null; }

    public static Snapshot getLatest() { return latest; }

    public static Snapshot getFresh(String pkg, long nowElapsed) {
        Snapshot s = latest;
        if (s == null || !s.isFresh(nowElapsed)) return null;
        if (pkg != null && !pkg.isEmpty() && !s.matchesPackage(pkg)) return null;
        return s;
    }

    public static void update(Snapshot snapshot) {
        if (snapshot == null || snapshot.distanceMeters < 0 || !isValidArrowRect(
                snapshot.arrowLeft, snapshot.arrowTop, snapshot.arrowRight, snapshot.arrowBottom)) {
            return;
        }
        latest = snapshot;
    }

    public static boolean isValidArrowRect(int left, int top, int right, int bottom) {
        int w = right - left;
        int h = bottom - top;
        if (w < MIN_ARROW_PX || h < MIN_ARROW_PX || w > MAX_ARROW_PX || h > MAX_ARROW_PX) return false;
        double ratio = w >= h ? (double) w / h : (double) h / w;
        return ratio <= MAX_ASPECT_RATIO;
    }

    /** Edge-to-edge Manhattan gap between two screen rectangles (0 when overlapping/touching). */
    public static int boxGap(int aL, int aT, int aR, int aB, int bL, int bT, int bR, int bB) {
        int dx = aR < bL ? bL - aR : (bR < aL ? aL - bR : 0);
        int dy = aB < bT ? bT - aB : (bB < aT ? aT - bB : 0);
        return dx + dy;
    }

    /**
     * Selects the closest valid unlabeled arrow ImageView co-located with the distance widget.
     * Returns the index into arrowRects (each int[4]{l,t,r,b}), or -1 if none qualify.
     */
    public static int selectBestArrow(int dL, int dT, int dR, int dB, int[][] arrowRects) {
        if (arrowRects == null || arrowRects.length == 0) return -1;
        if (dR <= dL || dB <= dT) return -1;
        int bestIdx = -1;
        int bestGap = Integer.MAX_VALUE;
        for (int i = 0; i < arrowRects.length; i++) {
            int[] a = arrowRects[i];
            if (a == null || a.length < 4) continue;
            if (!isValidArrowRect(a[0], a[1], a[2], a[3])) continue;
            int maxDim = Math.max(a[2] - a[0], a[3] - a[1]);
            int allowedGap = Math.max(160, (int) Math.round(2.5 * maxDim));
            int gap = boxGap(dL, dT, dR, dB, a[0], a[1], a[2], a[3]);
            if (gap <= allowedGap && gap < bestGap) {
                bestGap = gap;
                bestIdx = i;
            }
        }
        return bestIdx;
    }
}
