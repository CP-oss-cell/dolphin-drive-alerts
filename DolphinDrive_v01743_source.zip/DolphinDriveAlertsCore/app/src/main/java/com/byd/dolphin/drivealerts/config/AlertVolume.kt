package com.byd.dolphin.drivealerts.config

import android.content.Context
import kotlin.math.abs

/** Local app audio only. Never changes system volume, OEM safety alerts or other apps. */
object AlertVolume {
    private const val KEY = "alert_volume_tier"
    private const val PREF = "drive_alert_core"
    val labels = listOf("조금 작게", "작게", "보통", "크게")
    fun tier(context: Context): Int = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getInt(KEY, 2).coerceIn(0, 3)
    fun setTier(context: Context, value: Int): Boolean = value in 0..3 &&
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY, value).commit()
    /** User requested label order: slightly quiet, quiet, normal (unchanged), louder. */
    fun trackGain(tier: Int): Float = when (tier.coerceIn(0,3)) {
        0 -> 0.70f  // slightly quieter than today's 0.88
        1 -> 0.52f  // quiet
        2 -> 0.88f  // exact current AudioTrack volume
        else -> 1.0f
    }
    /** Peak-limited +15% boost for the loud tier. Prevent 16-bit clipping. */
    fun safeLoudPcm(samples: ShortArray): ShortArray {
        if (samples.isEmpty()) return samples
        val peak = samples.maxOf { abs(it.toInt()) }
        val scale = minOf(1.15, 30000.0 / peak.coerceAtLeast(1))
        return if (scale <= 1.0) samples else ShortArray(samples.size) { i ->
            (samples[i] * scale).toInt().coerceIn(-32768,32767).toShort()
        }
    }
}
