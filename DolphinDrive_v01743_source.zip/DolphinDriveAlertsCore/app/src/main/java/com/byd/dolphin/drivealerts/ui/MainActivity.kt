package com.byd.dolphin.drivealerts.ui

import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentUris
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.RotationPolicy
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

class MainActivity : DensityAwareActivity() {
    private lateinit var unifiedCaptureStatus: TextView
    private val statusTiles = mutableMapOf<String, TextView>()
    private var adbCheckGeneration = 0
    private var dashboardBack: (() -> Unit)? = null
    private var detailVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(buildUi())
        } catch (t: Throwable) {
            setContentView(TextView(this).apply {
                text = "Dolphin Drive Alerts SAFE START\n\nUI 초기화 오류: ${t.javaClass.simpleName}: ${t.message}\n\n이 화면이 보이면 앱 자체 실행은 정상입니다."
                textSize = 18f
                setPadding(32, 32, 32, 32)
            })
        }
        com.byd.dolphin.drivealerts.dpi.TemporaryAppDpiController.recoverOnStartup(this)
        if (AdbSetupActivity.shouldShowFirstRun(this)) {
            AdbSetupActivity.markFirstRunShown(this)
            AlertDialog.Builder(this)
                .setTitle("첫 실행 · 차량 ADB 연결 안내")
                .setMessage("2분할 기능은 차량 자체 로컬 ADB 인증이 필요할 수 있습니다. " +
                    "PC 없이 차량 화면에서 RSA 승인 요청을 시도할 수 있습니다. " +
                    "지금 연결하거나 나중에 화면에서 연결할 수 있습니다. " +
                    "차량 adbd가 닫혀 있으면 승인창이 나타나지 않을 수 있습니다.")
                .setPositiveButton("연결 화면 열기") { _, _ ->
                    startActivity(Intent(this, AdbSetupActivity::class.java))
                }
                .setNegativeButton("나중에", null)
                .show()
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure {
                Toast.makeText(this, "차량 감시 서비스 시작 실패: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B111D.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "Dolphin Drive Alerts · 0.17.35"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "한국형 돌핀: 오버레이는 순정 설정, 접근성·알림 접근·사용기록은 승인된 ADB를 통한 설정 및 상태 확인."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실"))
        box.addView(Button(this).apply {
            text = "오디오 라우팅 실험실 · 순정 스캔 → 후보 청취 → 5종 내비 비교 → ZIP 저장"
            setOnClickListener { startActivity(Intent(this@MainActivity, NavAudioLabActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "Route 5/6 운전석 자체 시험음은 기존 실차 성공 사례. 다른 UID의 실제 내비 안내음 강제 변경은 지원 권한 확인 전까지 불가능하며 성공으로 표시하지 않습니다."
            textSize = 13f
        })
        box.addView(section("NEW · ECO/NORMAL/SPORT 실차 3상태 교정"))
        box.addView(Button(this).apply {
            text="주행모드 원본값 기록 · ECO / NORMAL / SPORT"
            setOnClickListener { startActivity(Intent(this@MainActivity, DriveModeCalibrationActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text="차량 P 상태에서 세 모드를 각각 읽기 전용 기록. 신호가 구별되지 않으면 NORMAL 자동 안내를 억지로 켜지 않습니다."
            textSize=13f
        })
        box.addView(section("로컬 ADB / 최초 승인 · PC 연결 불필요"))
        box.addView(Button(this).apply {
            text = "차량 ADB 연결 · RSA 승인 요청 · 상태 확인"
            setOnClickListener { startActivity(Intent(this@MainActivity, AdbSetupActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "ADB RSA 승인 여부는 차량 화면의 실제 팝업에서 직접 확인합니다. " +
                "연결 성공만으로 분할화면까지 성공한 것은 아닙니다. " +
                "연결 후 별도 화면 분할 프로필에서 2개 앱 실행과 비율을 시험하세요."
            textSize = 13f
        })
        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val raw14 = RadioButton(this).apply { text = "운전석(raw14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(raw14); route.addView(media); box.addView(route)
        when (AlertPreferences.route(this)) {
            OutputRoute.DRIVER_STREAM14 -> driver.isChecked = true
            OutputRoute.DRIVER_RAW14 -> raw14.isChecked = true
            OutputRoute.MEDIA -> media.isChecked = true
        }
        route.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setRoute(this, when (id) {
                driver.id -> OutputRoute.DRIVER_STREAM14
                raw14.id -> OutputRoute.DRIVER_RAW14
                else -> OutputRoute.MEDIA
            })
        }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개 + 단발 기본음 남/여 2개(총 60개)를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        // Real-car verified: keep a single ON/OFF switch.
        // Vehicle event listener and fallback KeyEvent detector remain active in DrivingAlertService.
        box.addView(section("주행 알림 음량 · 4단계"))
        val volumeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        com.byd.dolphin.drivealerts.config.AlertVolume.labels.forEachIndexed { index, name ->
            volumeGroup.addView(RadioButton(this).apply {
                text = name; id = View.generateViewId()
                isChecked = index == com.byd.dolphin.drivealerts.config.AlertVolume.tier(this@MainActivity)
                setOnClickListener {
                    val saved = com.byd.dolphin.drivealerts.config.AlertVolume.setTier(this@MainActivity,index)
                    Toast.makeText(this@MainActivity, if(saved) "알림 음량: $name" else "음량 저장 실패", Toast.LENGTH_SHORT).show()
                }
            })
        }
        box.addView(volumeGroup)
        box.addView(TextView(this).apply { text="현재 음량 = 보통 (기본값). 차량 미디어·순정 경고 볼륨은 변경하지 않습니다."; textSize=13f })
        box.addView(section("주행모드 · 에코 / 노멀 / 스포츠"))
        box.addView(CheckBox(this).apply {
            text="에코 해제 → 노멀 자동 알림 (기본 ON)"
            isChecked=AlertPreferences.normalNoticeCandidateEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                AlertPreferences.setNormalNoticeCandidateEnabled(this@MainActivity,on)
            }
        })
        box.addView(TextView(this).apply {
            text="Audio Feedback의 스포츠 ON/OFF 이벤트 처리와 실차 로그의 363→ECO(1), " +
                "365→SPORT(2), 그 사이 364 변화를 대조합니다. " +
                "ECO 확인 직후 364가 들어올 때만 노멀 음성을 안내하며, " +
                "계기판 알림 코드 364 자체는 제조사 인증 주행모드 신호가 아닙니다. " +
                "오인식이 있으면 이 설정만 끌 수 있습니다."
            textSize=13f
        })
        box.addView(section("핸들 메뉴/이전 버튼 3연타"))
        box.addView(CheckBox(this).apply {
            text = "핸들 3연타 단발 음성 ON/OFF"
            isChecked = SteeringTriggerPreferences.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                SteeringTriggerPreferences.setEnabled(this@MainActivity, checked)
            }
        })

        box.addView(section("후측방 경고 · 두 가지 독립 설정"))
        box.addView(CheckBox(this).apply {
            text = "BSD 감지 + 어느 한쪽 깜빡이 → 일반 후측방 음성 (기본 ON)"
            isChecked = AlertPreferences.bsdBlinkerEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdBlinkerEnabled(this@MainActivity, on) }
        })
        box.addView(CheckBox(this).apply {
            text = "BSD 클릭음 기반 깜박이 보조 판독 · 시험 전용 (기본 OFF / 비상등 오인 가능)"
            isChecked = AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdTurnSoundExperimentalEnabled(this@MainActivity, on) }
        })
        box.addView(CheckBox(this).apply {
            text = "BSD 감지 즉시 일반 후측방 음성 (선택 ON, 기본 OFF)"
            isChecked = AlertPreferences.bsdInstantEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdInstantEnabled(this@MainActivity, on) }
        })
        box.addView(TextView(this).apply {
            text = "두 옵션을 동시에 켜도 감지 1회당 공통 음성 최대 1회. " +
                "왼쪽/오른쪽 전용 음성은 실제 좌우 BSD 위험 신호 검증 전 자동 실행하지 않습니다. " +
                "BSD(raw2)+실제 양쪽 중 하나의 깜박이 확인 시 1회 안내합니다. getter가 비어 있으면 " +
                "1→2 반복·3 종료의 계기판 클릭음 후보를 보조 사용하지만 비상등과는 구별되지 않을 수 있습니다. " +
                "위험 실제 감지 없는 깜박이만으로는 발화하지 않습니다. 순정 경고는 그대로 유지합니다."
            textSize = 13f
        })
        box.addView(section("ICC 차선이탈·앞차 출발 · 실차 신호 연구"))
        box.addView(TextView(this).apply {
            text = "글로벌 2602의 DiPilot 콜백·ADAS 원시값을 기록합니다. " +
                "ICC 작동 여부와 실제 차선이탈/앞차 출발 경고의 활성값이 연결되기 전에는 " +
                "설정 ON/OFF 값을 위험 경고로 오인해 음성을 내지 않습니다."
            textSize = 13f
        })
        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(CheckBox(this).apply {
            text = "시동 시 자동 백그라운드 실행"
            isChecked = AlertPreferences.autoStartEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> AlertPreferences.setAutoStartEnabled(this@MainActivity, checked) }
        })
        box.addView(TextView(this).apply {
            text = "기본값 ON. 최초 설치 후 앱을 1회 실행하면 이후 BOOT_COMPLETED, Android/BYD/Qualcomm Quick Boot, USER_PRESENT/USER_UNLOCKED, SCREEN_ON, ACTION_POWER_CONNECTED, 앱 업데이트와 BYD ACC_ON/IGN_ON/ACC_MODE_CHANGED 신호에서 foreground 서비스 시작을 재요청합니다. ACC_OFF/ACTION_POWER_DISCONNECTED는 종료측 상태로 기록만 하고 서비스를 새로 시작하지 않습니다. 서비스는 START_STICKY + stopWithTask=false라 최근 앱에서 지워도 계속 유지됩니다. 사용자가 Android 설정에서 강제 종료(force-stop)한 경우만 정책상 앱을 다시 한 번 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(Button(this).apply {
            text = "시동 앱 자동실행 · 여러 앱 순서/초 단위/미디어 재생 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AutoLaunchSettingsActivity::class.java)) }
        })
        box.addView(section("화면 분할 프로필"))
        box.addView(Button(this).apply {
            text = "주행보조 내부 2분할 · 비율 · 360 복원"
            setOnClickListener { startActivity(Intent(this@MainActivity,SplitProfilesActivity::class.java)) }
        })
        box.addView(section("통합 로그 수집"))
        box.addView(TextView(this).apply {
            text = "수집 시작을 누른 뒤 기능을 시험하고, 수집 종료를 누르면 해당 구간의 차량 RAW·음성·앱·오류 기록과 시스템 진단을 ZIP 하나로 Download 폴더에 저장합니다. 시동 주행알림 서비스는 수집 종료 후에도 정상 유지됩니다."
            textSize = 13f
        })
        unifiedCaptureStatus = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8) }
        box.addView(unifiedCaptureStatus)
        updateCaptureStatus()
        box.addView(Button(this).apply {
            text = "수집 시작"
            setOnClickListener {
                runCatching { DrivingAlertService.beginUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "수집 시작 요청 중… (서비스 알림에 결과 표시)" }
                    .onFailure { unifiedCaptureStatus.text = "시작 요청 실패: ${it.message}" }
            }
        })
        box.addView(Button(this).apply {
            text = "수집 종료"
            setOnClickListener {
                runCatching { DrivingAlertService.endUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "로그 저장 요청 중… (완료 시 상단 알림 및 Download 폴더 확인)" }
                    .onFailure { unifiedCaptureStatus.text = "저장 요청 실패: ${it.message}" }
            }
        })

        // v0.17.9: explicit read-only A/B markers, no unsafe AVAS/ECU writes.
        box.addView(section("글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구"))
        box.addView(TextView(this).apply {
            text = "먼저 '수집 시작'을 누르세요. 차량을 안전하게 정차해 둔 상태에서 순정 내비 안내음과 다른 내비 앱 안내음이 실제로 나올 때 각각 기록합니다. 아래 버튼은 차량 소리/제어를 변경하지 않습니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "① 순정 내비 안내음 출력 중 · 오디오 경로 기록"
            setOnClickListener { DrivingAlertService.captureQuick(this@MainActivity, "2602_OEM_NAV_GUIDANCE") }
        })
        box.addView(Button(this).apply {
            text = "② 다른 내비 안내음 출력 중 · 오디오 경로 기록"
            setOnClickListener { DrivingAlertService.captureQuick(this@MainActivity, "2602_THIRD_PARTY_NAV_GUIDANCE") }
        })
        box.addView(Button(this).apply {
            text = "③ 순정 보행자 경고음 설정 시험 구간만 기록 (12초)"
            setOnClickListener { DrivingAlertService.captureWindow(this@MainActivity, "2602_AVAS_STOCK_SETTING", 12) }
        })
        box.addView(TextView(this).apply {
            text = "③은 BYD 순정 설정을 사용자가 직접 조작할 때만 전후 로그를 채집합니다. 외부 스피커에 음성을 보내거나 AVAS를 끄는 명령은 절대 실행하지 않습니다."
            textSize = 12f
        })

        box.addView(section("ADB 권한 관리"))
        box.addView(Button(this).apply {
            text = "설치 앱 선택 · 알림 수신/TBT · 위치 권한/서비스 · ADB 권한 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AppPermissionManagerActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "차량에서 일반 권한 설정이 막힌 항목만 승인된 ADB로 적용합니다. 순정 화면 크기를 바꾸는 시험은 제공하지 않습니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "ADB 필수 권한 적용 · 접근성/알림 리스너/사용기록"
            setOnClickListener {
                isEnabled = false
                Thread {
                    val message = runCatching {
                        com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper.apply(this@MainActivity)
                            .lines.joinToString("\n")
                    }.getOrElse { "권한 설정 오류: ${it.javaClass.simpleName}: ${it.message}" }
                    runOnUiThread {
                        isEnabled = true
                        android.app.AlertDialog.Builder(this@MainActivity).setTitle("ADB 권한 적용 및 검증")
                            .setMessage(message).setPositiveButton("닫기", null).show()
                    }
                }.start()
            }
        })
        box.addView(section("디스플레이 DPI / 화면 회전 / 내비 음성"))
        box.addView(CheckBox(this).apply {
            text = "전역 화면 회전 ON/OFF"
            isChecked = RotationPolicy.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                RotationPolicy.setEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "회전 규칙 활성화" else "회전 오버레이 해제 · 순정 복원", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply { text = "주행보조 앱 DPI · 회전 · 내비 5종 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(TextView(this).apply {
            text = "화면 회전은 Orientation Control의 0×0 투명 오버레이 방식이며 모든 앱에 전역 적용됩니다. 앱 선택·UsageStats 감시에 의존하지 않습니다."
            textSize = 13f
        })
        box.addView(TextView(this).apply {
            text = "접근성·알림 접근·사용기록은 차량 순정 메뉴가 차단되어 있으므로 위 'ADB 필수 권한 적용'에서 설정합니다. ADB 서버가 닫혀 있다면 차량 내 ADB 활성화 경로를 먼저 확인해야 합니다. PC는 이 앱의 필수 절차가 아닙니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "화면 위 표시 권한 열기"
            setOnClickListener { SafeSettingsLauncher.open(this@MainActivity, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
        })
        box.addView(TextView(this).apply {
            text = "DPI는 주행보조 앱 화면에만 적용됩니다. 타사 앱 DPI는 일시적으로 전역 변경하는 방식이며 순정 UI에도 영향을 줍니다. 타 앱 운전석 출력은 BYD 오디오 UID 라우팅 구현 전까지 진단 대상만 저장합니다."
            textSize = 13f
        })

        box.addView(section("이퀄라이저 / 음향 효과"))
        box.addView(Button(this).apply {
            text = "저음 · 중음 · 고음 / Centerpoint 360 / Sound Focus"
            setOnClickListener { startActivity(Intent(this@MainActivity, AudioTuningActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "3밴드 조절은 사용 가능한 오디오 세션에서만 적용되며, 순정 차량 DSP 기반 360/공간 음장은 아직 지원하지 않습니다."
            textSize = 13f
        })

        organizeUi(box, scroll)
        return root
    }

    /**
     * Dashboard v0.17.35: navigation-only reshaping. Do not fork/replace any
     * existing checkbox, radio listener, command, activity, diagnostic, or source.
     * All existing legacy controls are moved to one of the six detail pages.
     */
    private fun organizeUi(box: LinearLayout, scroll: ScrollView) {
        val legacyToCategory = mapOf(
            "NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실" to 4,
            "NEW · ECO/NORMAL/SPORT 실차 3상태 교정" to 1,
            "로컬 ADB / 최초 승인 · PC 연결 불필요" to 5,
            "알림 출력 경로" to 1,
            "알림 종류" to 1,
            "주행 알림 음량 · 4단계" to 1,
            "노멀 모드 보조 알림 · 시험 설정" to 1,
            "핸들 메뉴/이전 버튼 3연타" to 1,
            "후측방 경고 · 두 가지 독립 설정" to 1,
            "ICC 차선이탈·앞차 출발 · 실차 신호 연구" to 1,
            "자동 실행 / 백그라운드" to 5,
            "화면 분할 프로필" to 3,
            "통합 로그 수집" to 6,
            "글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구" to 6,
            "ADB 권한 관리" to 5,
            "디스플레이 DPI / 화면 회전 / 내비 음성" to 3,
            "이퀄라이저 / 음향 효과" to 4
        )
        val groups = (1..6).associateWith { mutableListOf<View>() }
        val original = mutableListOf<View>()
        while (box.childCount > 0) {
            val v = box.getChildAt(0)
            box.removeViewAt(0)
            original.add(v)
        }
        var category = 0
        original.forEach { view ->
            val heading = (view as? TextView)?.text?.toString()
            if (heading != null && legacyToCategory.containsKey(heading)) {
                category = legacyToCategory.getValue(heading)
                if (view is TextView) view.text = when (heading) {
                    "NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실" -> "내비 음성 경로 · 상세 진단"
                    "NEW · ECO/NORMAL/SPORT 실차 3상태 교정" -> "주행모드 원본값 확인 · 고급 진단"
                    "로컬 ADB / 최초 승인 · PC 연결 불필요" -> "차량 ADB 연결"
                    "후측방 경고 · 두 가지 독립 설정" -> "후측방 음성 알림"
                    "ICC 차선이탈·앞차 출발 · 실차 신호 연구" -> "ICC · 차선이탈 · 앞차출발 상태"
                    "글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구" -> "외부 AVAS · 읽기 전용 진단"
                    "디스플레이 DPI / 화면 회전 / 내비 음성" -> "화면 회전 · 앱 전용 DPI"
                    else -> heading
                }
            }
            if (category == 0) return@forEach // obsolete banner; not an active setting
            // The two navigation snapshots logically belong under Audio / Navigation.
            val target = if (category == 6 && view is Button &&
                (view.text?.startsWith("① 순정 내비") == true ||
                 view.text?.startsWith("② 다른 내비") == true)) 4 else category
            groups.getValue(target).add(view)
        }
        // Preserve missing from UI: all original settings/listeners are kept in groups.
        // Inject explanatory summaries only; never claim unsupported OEM features work.
        groups.getValue(1).add(0, darkButton("23종 알림 개별 ON/OFF · 근거 상태", false) {
            startActivity(Intent(this, AlertEventSettingsActivity::class.java))
        })
        groups.getValue(1).add(0, CheckBox(this).apply {
            text = "주행보조 음성 알림 전체 ON/OFF"
            isChecked = AlertPreferences.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, enabled ->
                AlertPreferences.setEnabled(this@MainActivity, enabled)
                refreshDashboardStatus()
            }
        })
        groups.getValue(1).add(0, infoLabel("기어 P/D/N/R · 회생제동 · 오토홀드 · ECO/NORMAL/SPORT · ICC · 차선이탈 · 앞차출발 · 핸들 단발음\nNORMAL/ADAS 일부 이벤트는 아직 실차 미검증입니다."))
        groups.getValue(1).add(0, infoLabel("BSD는 주행보조 알림에 통합했습니다. 깜빡이 연동과 즉시 알림은 독립 설정이며 좌우 위험 구분은 미확정입니다."))
        groups.getValue(4).add(0, infoLabel("운전석 단독 내비 출력·Bose 원형 DSP는 구현 확정 전입니다. 내비 대상 체크는 실제 오디오 강제 전환이 아닙니다."))
        groups.getValue(6).add(0, infoLabel("외부 AVAS는 순정 신호의 읽기 전용 기록만 지원합니다. 임의 음성 송신은 하지 않습니다."))

        val titles = listOf("주행 알림", "BSD 알림", "화면 · 분할", "오디오 · 내비", "자동 실행 · 권한", "로그 · 진단")
        val subtitles = listOf(
            "기어 · 모드 · BSD · 오토홀드 · 음성",
            "후측방 · 깜빡이 · 즉시 알림",
            "2앱 분할 · 회전 · 타사/전역 DPI",
            "5종 내비 · 운전석 · 이퀄라이저",
            "시동 실행 · OFF 앱 종료 · ADB",
            "수집 · 자동 점검 · 연구실"
        )
        val symbols = listOf("01", "02", "03", "04", "05", "06")
        val dash = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        box.setBackgroundColor(Color.rgb(11, 17, 29))
        box.setPadding(dp(14), dp(10), dp(14), dp(20))
        box.addView(dash)
        box.addView(detail)

        fun showDashboard() {
            detail.removeAllViews()
            detail.visibility = View.GONE
            dash.visibility = View.VISIBLE
            detailVisible = false
            refreshDashboardStatus()
            scroll.post { scroll.scrollTo(0, 0) }
        }
        fun showCategory(id: Int) {
            val idx = id - 1
            detail.removeAllViews()
            dash.visibility = View.GONE
            detail.visibility = View.VISIBLE
            detailVisible = true
            val back = darkButton("‹  대시보드로 돌아가기", false) { showDashboard() }
            detail.addView(back)
            detail.addView(titleLabel(titles[idx], 25f))
            detail.addView(infoLabel(subtitles[idx]))
            val body = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(16))
                background = shape(0xFF18263B.toInt(), 16f)
            }
            // All original buttons and controls remain attached to this live page.
            groups.getValue(id).forEach { body.addView(it) }
            makeLegacyTextReadable(body)
            if (id == 4) {
                // Original v0.17.28 checkboxes for 5 nav apps, preserved as live settings.
                body.addView(section("내비 5종 대상 저장 (출력 성공 아님)"))
                com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.forEach { entry ->
                    body.addView(CheckBox(this).apply {
                        text = entry.title
                        isChecked = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.enabled(this@MainActivity, entry.pkg)
                        setOnCheckedChangeListener { _, enabled ->
                            com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.setEnabled(this@MainActivity, entry.pkg, enabled)
                        }
                    })
                }
            }
            if (id == 6) {
                val endIndex = (0 until body.childCount).firstOrNull { i ->
                    (body.getChildAt(i) as? Button)?.text == "수집 종료"
                } ?: body.childCount
                body.addView(darkButton("자동 점검 · 읽기 전용", false) { runReadOnlyAutoCheck() }, endIndex)
                body.addView(darkButton("최근 로그 ZIP 공유", false) { shareLatestLogZip() })
            }
            detail.addView(body)
            detail.addView(darkButton("‹  메인으로", false) { showDashboard() })
            scroll.post { scroll.scrollTo(0, 0) }
        }

        dashboardBack = { showDashboard() }
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        head.addView(titleLabel("DOLPHIN DRIVE", 27f))
        head.addView(infoLabel("주행보조 통합 대시보드   ·   v0.17.40"))
        dash.addView(head)
        dash.addView(titleLabel("차량 · 앱 상태", 18f))
        val width = resources.configuration.screenWidthDp
        val cols = when { width >= 900 -> 3; width >= 550 -> 3; width >= 360 -> 2; else -> 1 }
        val statusKeys = listOf("서비스", "자동실행", "ADB", "로그", "회전", "출력")
        statusKeys.chunked(cols).forEach { line ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in line) {
                val value = TextView(this).apply {
                    text = "$key · 확인 중"
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    setPadding(dp(12), dp(12), dp(8), dp(12))
                    gravity = Gravity.CENTER_VERTICAL
                    background = shape(0xFF19283B.toInt(), 12f)
                }
                statusTiles[key] = value
                row.addView(value, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            repeat(cols - line.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            dash.addView(row)
        }
        dash.addView(titleLabel("빠른 실행", 18f))
        val commands = listOf<Pair<String, () -> Unit>>(
            "수집 시작" to { performCapture(true) },
            "수집 종료" to { performCapture(false) },
            "자동 점검" to { runReadOnlyAutoCheck() },
            "ZIP 공유" to { shareLatestLogZip() },
            "화면 분할" to { startActivity(Intent(this, SplitProfilesActivity::class.java)) },
            "상태 새로고침" to { refreshDashboardStatus() }
        )
        commands.chunked(3).forEachIndexed { rowIdx, line ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.forEachIndexed { index, (text, action) ->
                val b = darkButton(text, rowIdx == 0 && index == 0, action)
                b.textSize = 13.5f
                row.addView(b, LinearLayout.LayoutParams(0, dp(50), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            dash.addView(row)
        }
        dash.addView(titleLabel("설정 메뉴", 18f))
        val cardsPerLine = if (width >= 650) 3 else if (width >= 330) 2 else 1
        listOf(1,3,4,5,6).chunked(cardsPerLine).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { id ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(14), dp(10), dp(12))
                    background = shape(0xFF1C2E46.toInt(), 17f)
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { showCategory(id) }
                }
                tile.addView(titleLabel(symbols[id - 1] + "    " + titles[id - 1], 17f))
                tile.addView(infoLabel(subtitles[id - 1]))
                row.addView(tile, LinearLayout.LayoutParams(0, dp(105), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            repeat(cardsPerLine - chunk.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            dash.addView(row)
        }
        dash.addView(infoLabel("주행 안전 원기능을 변경하지 않습니다. '실행 중'은 서비스 프로세스 상태이며 각 차량 신호의 실차 검증 완료를 뜻하지 않습니다."))
        refreshDashboardStatus()
    }

    private fun makeLegacyTextReadable(node: View) {
        if (node is TextView && node !is Button) {
            node.setTextColor(Color.WHITE)
            if (node is EditText) node.setHintTextColor(0xFFB6C5D8.toInt())
        }
        if (node is android.view.ViewGroup) {
            for (index in 0 until node.childCount) makeLegacyTextReadable(node.getChildAt(index))
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (detailVisible) dashboardBack?.invoke() else super.onBackPressed()
    }

    private fun shape(color: Int, cornerDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(cornerDp.toInt()).toFloat()
    }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + 0.5f).toInt()
    private fun titleLabel(value: String, size: Float): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(6), dp(10), dp(6), dp(5))
    }
    private fun infoLabel(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 12.5f
        setTextColor(0xFFB6C5D8.toInt())
        setPadding(dp(6), dp(2), dp(6), dp(8))
    }
    private fun darkButton(value: String, primary: Boolean, click: () -> Unit): Button = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = shape(if (primary) 0xFF087F84.toInt() else 0xFF283B54.toInt(), 11f)
        setOnClickListener { click() }
    }

    private fun performCapture(start: Boolean) {
        runCatching {
            if (start) DrivingAlertService.beginUnifiedCapture(this)
            else DrivingAlertService.endUnifiedCapture(this)
        }.onSuccess {
            Toast.makeText(this, if (start) "수집 시작 요청 전달" else "수집 종료 · ZIP 저장 요청 전달", Toast.LENGTH_SHORT).show()
            refreshDashboardStatus()
            // Service status is asynchronous. Never claim the request already succeeded.
        }.onFailure { Toast.makeText(this, "요청 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    private fun refreshDashboardStatus() {
        if (statusTiles.isEmpty()) return
        val alive = DrivingAlertService.activeLogger != null
        statusTiles["서비스"]?.text = if (alive) "서비스 · 프로세스 활성" else "서비스 · 확인 필요"
        statusTiles["자동실행"]?.text = "자동실행 · ${if (AlertPreferences.autoStartEnabled(this)) "ON" else "OFF"}"
        val record = UnifiedLogCapture.state(this)
        statusTiles["로그"]?.text = "로그 · ${when (record.status) {
            UnifiedLogCapture.RECORDING -> "수집 중"
            UnifiedLogCapture.SAVING -> "저장 중"
            UnifiedLogCapture.FAILED -> "저장 실패"
            else -> "대기"
        }}"
        statusTiles["회전"]?.text = "회전 · ${if (RotationPolicy.enabled(this)) "ON" else "OFF"}"
        statusTiles["출력"]?.text = "출력 · ${when (AlertPreferences.route(this)) {
            OutputRoute.MEDIA -> "미디어"
            OutputRoute.DRIVER_RAW14 -> "운전석 raw14"
            else -> "운전석 stream14"
        }}"
        statusTiles["ADB"]?.text = "ADB · 확인 중"
        val generation = ++adbCheckGeneration
        Thread({
            val result = runCatching { AuthorizedAdbRuntime.health(applicationContext).state }.getOrNull()
            runOnUiThread {
                if (isFinishing || isDestroyed || generation != adbCheckGeneration) return@runOnUiThread
                statusTiles["ADB"]?.text = "ADB · ${when (result) {
                    AuthorizedAdbRuntime.State.READY -> "인증 완료"
                    AuthorizedAdbRuntime.State.AUTH_REQUIRED -> "승인 필요"
                    AuthorizedAdbRuntime.State.PORT_CLOSED -> "연결 안 됨"
                    AuthorizedAdbRuntime.State.PERMISSION_DENIED -> "권한 부족"
                    else -> "확인 불가"
                }}"
            }
        }, "dashboard-adb-readonly").start()
    }

    private fun runReadOnlyAutoCheck() {
        val installed = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.map { app ->
            val exists = runCatching {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(app.pkg, 0) != null
            }.getOrDefault(false)
            "${app.title}: ${if (exists) "설치 확인" else "미설치/조회 불가"}"
        }
        val audio = getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
        val devices = runCatching {
            audio?.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)?.joinToString(", ") {
                "${it.type}:${it.productName}"
            }.orEmpty()
        }.getOrDefault("")
        val message = buildString {
            val events = com.byd.dolphin.drivealerts.model.AlertEventCatalog.entries
            val active = events.count { AlertPreferences.eventEnabled(this@MainActivity, it.event) }
            appendLine("추가 음성 23종: 사용자 허용 $active / ${events.size} (발화 성공 의미 아님)")
            appendLine("내비 타사 UID 운전석 단독 출력: 구현 미확정 · 원본 미디어 출력 제어 불가")
            appendLine("분할 비율/복원: 실제 Task bounds readback 필요")
            appendLine("타사 앱 DPI: 임시 전역 변경 규칙(사용자 동의/ADB 필요) · 진짜 독립 앱 DPI는 미지원")
            appendLine("NORMAL: 보조 후보=${AlertPreferences.normalNoticeCandidateEnabled(this@MainActivity)} (364+에코/스포츠 교차확인, 실차 미확정)")
            appendLine("음성 볼륨: ${com.byd.dolphin.drivealerts.config.AlertVolume.labels[com.byd.dolphin.drivealerts.config.AlertVolume.tier(this@MainActivity)]}")
            appendLine("BSD 좌우/ADAS: 실차 신호 판정 미완료 · 순정 안전 기능 유지")
            appendLine("Android SDK: ${android.os.Build.VERSION.SDK_INT}")
            appendLine("부팅 자동 실행: ${AlertPreferences.autoStartEnabled(this@MainActivity)}")
            appendLine("전역 회전: ${RotationPolicy.enabled(this@MainActivity)}")
            appendLine("로그 상태: ${UnifiedLogCapture.state(this@MainActivity).status}")
            appendLine("후측방 1번: ${AlertPreferences.bsdBlinkerEnabled(this@MainActivity)}")
            appendLine("후측방 2번: ${AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)}")
            appendLine("후측방 3번: ${AlertPreferences.bsdInstantEnabled(this@MainActivity)}")
            appendLine("\n내비 5종 설치 확인\n${installed.joinToString("\n")}")
            appendLine("\n오디오 출력장치: ${devices.ifBlank { "조회 불가" }}")
            appendLine("\n이것은 읽기 전용 상태 점검입니다. 실제 차량 신호 발화/오디오 라우팅의 성공 여부는 판정하지 않습니다.")
        }
        AlertDialog.Builder(this).setTitle("자동 점검 결과")
            .setMessage(message).setPositiveButton("확인", null).show()
        // Add a corresponding snapshot only when capture is already enabled.
        if (UnifiedLogCapture.state(this).status == UnifiedLogCapture.RECORDING) {
            runCatching { DrivingAlertService.captureQuick(this, "USER_AUTOMATED_READONLY_CHECK") }
        }
    }

    private fun shareLatestLogZip() {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            AlertDialog.Builder(this).setTitle("로그 공유")
                .setMessage("Android 9 이하에서는 다운로드 폴더의 파일 관리자에서 DolphinDriveLogs_ ZIP을 선택해 공유하세요.")
                .setPositiveButton("확인", null).show()
            return
        }
        val uri = runCatching {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("DolphinDriveLogs_%.zip")
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    ContentUris.withAppendedId(collection, cursor.getLong(0))
                } else null
            }
        }.getOrNull()
        if (uri == null) {
            AlertDialog.Builder(this).setTitle("로그 ZIP 없음")
                .setMessage("먼저 수집 시작 → 필요한 테스트 → 수집 종료를 완료하세요. ZIP 저장이 끝나면 다시 공유할 수 있습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, "실차 로그 ZIP 공유")) }
            .onFailure { Toast.makeText(this, "공유 앱 열기 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
        refreshDashboardStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 재시동 후 같은 세션 복구 시도 (전원 OFF 구간은 누락 가능) · '수집 종료'로 ZIP 저장"
            UnifiedLogCapture.SAVING -> "저장 중 · 완료되면 상단 알림으로 안내"
            UnifiedLogCapture.FAILED -> "저장 실패 · '수집 종료'를 다시 눌러 재시도"
            else -> "대기 중 · '수집 시작'을 눌러주세요"
        }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }

}
