package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.ApplicationInfo

/** PackageManager lookup; handles OEM apps without LAUNCHER activity. Scan on background thread. */
object DpiAppCatalog {
    data class Entry(val packageName:String, val title:String, val system:Boolean, val launchable:Boolean) {
        val label:String get() = "${if(system) "[순정/시스템]" else "[설치 앱]"} $title ($packageName)${if(!launchable) " · 직접 실행 아이콘 없음" else ""}"
    }
    fun load(context:Context):List<Entry> {
        val pm=context.packageManager
        val packages=runCatching { pm.getInstalledApplications(0) }.getOrDefault(emptyList())
        return packages.asSequence().filter { ThirdPartyDpiRules.allowed(context,it.packageName) }
            .map { info ->
                val title=runCatching { pm.getApplicationLabel(info).toString() }.getOrDefault(info.packageName)
                val system=(info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0 ||
                    info.packageName.startsWith("com.byd.")
                val launchable=runCatching { pm.getLaunchIntentForPackage(info.packageName)!=null }.getOrDefault(false)
                Entry(info.packageName,title,system,launchable)
            }.distinctBy {it.packageName}
            .sortedWith(compareBy<Entry> { it.system }.thenBy { it.title.lowercase() }.thenBy { it.packageName })
            .toList()
    }
    fun find(items:List<Entry>,filter:Int,query:String,limit:Int=100):List<Entry> {
        val q=query.trim()
        return items.asSequence().filter { filter==0 || (filter==1 && !it.system) || (filter==2 && it.system) }
            .filter { q.isEmpty() || it.title.contains(q,true) || it.packageName.contains(q,true) }
            .take(limit).toList()
    }
}
