package com.byd.dolphin.drivealerts.vehicle

/**
 * 2602 real-car 2026-11-02 independent, read-only mode evidence:
 * instrument notice 363 -> energy operationMode 1 (ECO),
 * instrument notice 365 -> energy operationMode 2 (SPORT),
 * instrument notice 364 occurs between ECO and SPORT without an energy value 0.
 *
 * The AutoFeedback v1.0 APK additionally calls onOperationModeChanged(1) SPORTS_OFF
 * and onOperationModeChanged(2) SPORTS_ON. That callback alone cannot encode all
 * three modes. Therefore NORMAL only comes from a correlated 363/1 -> 364 edge.
 * No mode is announced from an unpaired display message.
 */
internal class ModeNoticeCorrelator {
    private var lastNotice = 0
    private var noticeAt = 0L
    private var ecoMatchedAt = 0L
    private var sportMatchedAt = 0L
    private var currentEnergy = -1

    fun reset() { lastNotice=0;noticeAt=0L;ecoMatchedAt=0L;sportMatchedAt=0L;currentEnergy=-1 }

    /** A NORMAL transition must follow a recently confirmed ECO notice and callback.
     * SPORT confirmation further strengthens diagnostics but is not required for a
     * driver who starts the session in ECO and then selects NORMAL.
     */
    fun onDisplay(code: Int, now: Long): Boolean {
        if (code !in 363..365) {
            // A different instrument notice breaks the sequence; no stale NORMAL.
            lastNotice=0
            return false
        }
        if (code == lastNotice) return false
        val previous = lastNotice
        val previousAt = noticeAt
        lastNotice=code
        noticeAt=now
        return code==364 && previous==363 && currentEnergy==1 &&
            ecoMatchedAt>0 && now-ecoMatchedAt in 0L..6000L &&
            now-previousAt in 0L..6000L
    }

    fun onEnergy(value: Int, now: Long) {
        currentEnergy=value
        if (now-noticeAt !in 0L..2800L) return
        if (lastNotice==363 && value==1) ecoMatchedAt=now
        if (lastNotice==365 && value==2) sportMatchedAt=now
    }
    fun status():String = "ecoPair=${ecoMatchedAt>0};sportPair=${sportMatchedAt>0};lastNotice=$lastNotice;energy=$currentEnergy;inference=ECO_ON_TO_NORMAL_NOTICE;OEM_UNVERIFIED=true"
}
