package com.byd.dolphin.drivealerts.log

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import org.json.JSONArray
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream

/** Unified, user-controlled capture. The background safety monitor never stops. */
object UnifiedLogCapture {
    private const val PREF = "unified_log_capture"
    private const val STATUS = "status"
    private const val SESSION = "session"
    private const val START = "start"
    private const val END = "end"
    const val IDLE = "IDLE"
    const val RECORDING = "RECORDING"
    const val SAVING = "SAVING"
    const val FAILED = "FAILED"

    data class State(val status: String, val id: String, val startMs: Long, val endMs: Long)

    @Synchronized fun state(context: Context): State {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return State(prefs.getString(STATUS, IDLE) ?: IDLE,
            prefs.getString(SESSION, "") ?: "", prefs.getLong(START, 0L), prefs.getLong(END, 0L))
    }

    fun begin(context: Context, logger: RawSignalLogger?, diagnostics: SystemDiagnosticsCollector?): String {
        val current = state(context)
        if (current.status == RECORDING || current.status == SAVING) return "이미 수집 중입니다."
        if (current.status == FAILED) return "이전 로그 저장 실패: 먼저 '수집 종료'를 눌러 재저장하세요."
        if (logger == null) return "차량 로그 수집기를 사용할 수 없습니다."
        val id = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + "_" + UUID.randomUUID().toString().take(8)
        val start = System.currentTimeMillis()
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS, RECORDING).putString(SESSION, id).putLong(START, start).putLong(END, 0L).commit()
        if (!saved) return "수집 상태 저장 실패"
        runCatching { CaptureContinuity.reset(context, id, start) }
            .onFailure { logger.diagnostic("CAPTURE_JOURNAL_START_FAILED", it.javaClass.simpleName) }
        logger.marker("UNIFIED_CAPTURE_START", "id=$id")
        runCatching {
            logger.diagnostic("FEATURE_PREFS_START", RuntimeFeatureSnapshot.collect(context).toString())
        }.onFailure { CoreLog.w("UNIFIED_LOG", "feature snapshot not available: ${it.javaClass.simpleName}") }
        logger.diagnostic("UNIFIED_CAPTURE_ACTIVE", "id=$id start=$start")
        diagnostics?.captureQuick("UNIFIED_START_$id")
        return "로그 수집 시작: $id"
    }

    /** A crashed process may have left the preference in SAVING while no exporter exists. */
    fun recoverInterruptedSave(context: Context) {
        if (state(context).status == SAVING) {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(STATUS, FAILED).commit()
        }
    }

    /** No new session can start until an interrupted/failed save is retried. */
    fun finish(context: Context, logger: RawSignalLogger?, diagnostics: SystemDiagnosticsCollector?): Result<String> {
        val state = state(context)
        if (state.status == IDLE || state.id.isBlank() || state.startMs <= 0L)
            return Result.failure(IllegalStateException("수집 시작 후 종료를 눌러주세요."))
        if (state.status == SAVING)
            return Result.failure(IllegalStateException("이미 로그 저장 중입니다."))
        if (logger == null) return Result.failure(IllegalStateException("차량 로그 수집기를 사용할 수 없습니다."))

        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val end = if (state.endMs > state.startMs) state.endMs else {
            logger.marker("UNIFIED_CAPTURE_END", "id=${state.id}")
            logger.flush()
            System.currentTimeMillis()
        }
        if (!prefs.edit().putString(STATUS, SAVING).putLong(END, end).commit())
            return Result.failure(IllegalStateException("저장 상태 기록 실패"))
        // ADB may be unavailable: capture failures remain explicit in per-command diagnostic files.
        val captured = diagnostics?.captureDeepAndWait("UNIFIED_STOP_${state.id}") ?: false
        // A running 3/8/15s NAV scan must complete before its files can be archived.
        // On timeout FAILED is retryable with the original endMs/sessionId intact.
        val ready = awaitNavSessions(context, state.startMs, end)
        val exported = if (ready.isSuccess)
            export(context, logger, diagnostics, state.copy(status = SAVING, endMs = end), captured)
        else Result.failure(ready.exceptionOrNull() ?: IllegalStateException("내비 진단 완료 대기 실패"))
        if (exported.isSuccess) {
            if (prefs.edit().putString(STATUS, IDLE).remove(SESSION).remove(START).remove(END).commit()) {
                runCatching { CaptureContinuity.clear(context, state.id) }
            }
        } else {
            prefs.edit().putString(STATUS, FAILED).commit()
            CoreLog.w("UNIFIED_LOG", "save failed: ${exported.exceptionOrNull()?.message}")
        }
        return exported
    }

    private fun awaitNavSessions(context: Context, startMs: Long, endMs: Long): Result<Unit> = runCatching {
        val navRoot = File(context.filesDir, "nav_audio_lab")
        // Keep the UI responsive enough to retry if a slow/blocked ADB command holds a scan.
        val deadline = System.currentTimeMillis() + 20_000L
        while (true) {
            val pending = SessionDiagnosticSelector.navigationFolders(navRoot, startMs, endMs)
                .filter { SessionDiagnosticSelector.navigationStatus(it) == "IN_PROGRESS" }
            if (pending.isEmpty()) break
            if (System.currentTimeMillis() >= deadline)
                error("내비 진단이 아직 진행 중입니다 (${pending.joinToString { it.name }}). 완료 후 '수집 종료'를 다시 누르면 같은 기록을 ZIP으로 저장합니다.")
            Thread.sleep(750L)
        }
    }

    private fun verifyCompleteZip(file: File) {
        check(file.isFile && file.length() > 128L) { "임시 ZIP 크기가 너무 작습니다" }
        val found = mutableSetOf<String>()
        // ZipInputStream checks each entry's deflate and CRC when fully read.
        ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zip ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val entry = zip.nextEntry ?: break
                check(found.add(entry.name)) { "ZIP 중복 항목: ${entry.name}" }
                while (zip.read(buf) != -1) { /* drain for CRC */ }
                zip.closeEntry()
            }
        }
        check(found.containsAll(listOf("session.json", "lifecycle/capture_continuity.json",
            "logs/vehicle_events.jsonl"))) { "필수 로그 항목 누락: $found" }
        // EOCD check independently: truncated ZIP can sometimes yield partial entries.
        ZipFile(file).use { archive ->
            check(archive.size() >= 4) { "ZIP 중앙 디렉터리 불완전" }
            val manifest = JSONObject(archive.getInputStream(archive.getEntry("evidence_manifest.json")
                ?: error("증거 해시 목록 누락")).bufferedReader().use { it.readText() })
            val files = manifest.getJSONArray("files")
            check(files.length() + 1 == archive.size()) { "ZIP 증거 파일 개수 불일치" }
            for (i in 0 until files.length()) {
                val item = files.getJSONObject(i)
                val entry = archive.getEntry(item.getString("path")) ?: error("증거 파일 누락: $item")
                val digest = MessageDigest.getInstance("SHA-256")
                var copied = 0L
                archive.getInputStream(entry).use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        digest.update(buf, 0, n)
                        copied += n
                    }
                }
                check(copied == item.getLong("bytes") &&
                    digest.digest().joinToString("") { "%02x".format(it) } == item.getString("sha256")) {
                    "증거 SHA-256 오류: ${entry.name}"
                }
            }
        }
    }

    private fun export(context: Context, logger: RawSignalLogger, diagnostics: SystemDiagnosticsCollector?, state: State, captured: Boolean): Result<String> = runCatching {
        val filename = "DolphinDriveLogs_${state.id}.zip"
        // Never publish a half-written ZIP as a finished Download. Keep staged bytes for
        // interrupted export diagnostics until a successful copy has completed.
        val staged = File(context.cacheDir, "DolphinDriveLogs_${state.id}.staged.zip")
        try {
            FileOutputStream(staged).use { writeZip(context, logger, diagnostics, state, captured, it) }
            verifyCompleteZip(staged)
            val location = if (Build.VERSION.SDK_INT >= 29) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Download 파일 생성 실패(MediaStore)")
                try {
                    val stream = resolver.openOutputStream(uri, "w") ?: error("Download 쓰기 실패")
                    stream.use { dst -> staged.inputStream().use { it.copyTo(dst, 64 * 1024) } }
                    val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    check(resolver.update(uri, done, null, null) > 0) { "Download 저장 완료 표시 실패" }
                } catch (e: Throwable) {
                    resolver.delete(uri, null, null)
                    throw e
                }
                "Download/$filename"
            } else {
                @Suppress("DEPRECATION")
                val folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
                val output = File(folder, filename)
                staged.copyTo(output, overwrite = true)
                verifyCompleteZip(output)
                output.absolutePath
            }
            staged.delete()
            location
        } catch (t: Throwable) {
            // Leave validated or partially written staged data available to diagnose or recover;
            // a failed capture is never reported as successful.
            CoreLog.w("UNIFIED_LOG", "export staging failure session=${state.id}: ${t.javaClass.simpleName}")
            throw t
        }
    }

    private fun diagnosticCommandStatus(folders: List<File>): Pair<Int, Int> {
        var ok = 0
        var failed = 0
        folders.forEach { directory ->
            directory.listFiles()?.filter { it.isFile && it.extension == "txt" }?.forEach { file ->
                val header = runCatching { file.bufferedReader().use { reader ->
                    val first = reader.readLine().orEmpty()
                    val second = reader.readLine().orEmpty()
                    first to second
                } }.getOrNull()
                header?.let { (first, second) ->
                    if (first.startsWith("# command:")) {
                        if (second.contains("success=true")) ok++
                        else if (second.contains("success=false")) failed++
                    }
                }
            }
        }
        return ok to failed
    }

    private fun writeZip(context: Context, logger: RawSignalLogger, diagnostics: SystemDiagnosticsCollector?, state: State, captured: Boolean, stream: OutputStream) {
        logger.flush()
        val sysFolders = SessionDiagnosticSelector.diagnosticFolders(diagnostics?.directory(), state.startMs, state.endMs, state.id)
        val navFolders = SessionDiagnosticSelector.navigationFolders(File(context.filesDir, "nav_audio_lab"), state.startMs, state.endMs)
        check(navFolders.none { SessionDiagnosticSelector.navigationStatus(it) == "IN_PROGRESS" }) {
            "내비 진단 파일이 아직 완성되지 않았습니다. 같은 세션에서 저장을 재시도하세요."
        }
        val statuses = navFolders.map { it.name to SessionDiagnosticSelector.navigationStatus(it) }
        val commandStatus = diagnosticCommandStatus(sysFolders)
        val manifestFiles = JSONArray()
        val fileBuffer = ByteArray(64 * 1024)
        ZipOutputStream(BufferedOutputStream(stream)).use { zip ->
            fun addEntry(name: String, data: ByteArray) {
                require(!name.startsWith("/") && ".." !in name.split('/')) { "ZIP 상대 경로가 잘못되었습니다" }
                val hash = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
                zip.putNextEntry(ZipEntry(name))
                zip.write(data)
                zip.closeEntry()
                manifestFiles.put(JSONObject().put("path", name).put("bytes", data.size).put("sha256", hash))
            }
            fun addFile(name: String, file: File, root: File) {
                check(file.canonicalPath.startsWith(root.canonicalPath + File.separator)) { "진단 경로 탈출 차단" }
                val digest = MessageDigest.getInstance("SHA-256")
                var count = 0L
                zip.putNextEntry(ZipEntry(name))
                file.inputStream().use { input ->
                    while (true) {
                        val n = input.read(fileBuffer)
                        if (n < 0) break
                        zip.write(fileBuffer, 0, n)
                        digest.update(fileBuffer, 0, n)
                        count += n
                    }
                }
                zip.closeEntry()
                manifestFiles.put(JSONObject().put("path", name).put("bytes", count)
                    .put("sha256", digest.digest().joinToString("") { "%02x".format(it) }))
            }
            fun addTree(root: File, prefix: String) {
                root.walkTopDown().filter { it.isFile }.sortedBy { it.invariantSeparatorsPath }.forEach { file ->
                    val relative = file.relativeTo(root).invariantSeparatorsPath
                    addFile("$prefix/$relative", file, root)
                }
            }

            val metadata = JSONObject().apply {
                put("type", "unified_diagnostic_capture")
                put("sessionId", state.id)
                put("startMs", state.startMs)
                put("endMs", state.endMs)
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("sdk", Build.VERSION.SDK_INT)
                val pkg = runCatching { context.packageManager.getPackageInfo(context.packageName, 0) }.getOrNull()
                put("appVersionName", pkg?.versionName ?: "UNKNOWN")
                @Suppress("DEPRECATION")
                put("appVersionCode", pkg?.versionCode ?: -1)
                put("deepSnapshotAttemptSucceeded", captured)
                put("diagnosticShellCommandSuccessCount", commandStatus.first)
                put("diagnosticShellCommandFailureCount", commandStatus.second)
                put("diagnosticShellUsable", commandStatus.first > 0)
                put("includedDiagnosticFolders", JSONArray(sysFolders.map { it.name }))
                put("includedNavAudioFolders", JSONArray(navFolders.map { it.name }))
                put("navAudioResults", JSONArray(statuses.map { (name, status) ->
                    JSONObject().put("directory", name).put("status", status)
                }))
                put("navAudioScanFullySuccessful", statuses.isNotEmpty() && statuses.all { it.second == "COMPLETE" })
                put("note", "Only captures requested inside this session and its START/STOP snapshots are included. Navigation and AVAS read-only data are not proof of speaker routing. Shell logcat may contain earlier records.")
            }.toString(2)
            addEntry("session.json", metadata.toByteArray(Charsets.UTF_8))
            // Always embed a settings/evidence snapshot so the operator does not need
            // another manual test just to explain which alert preferences were active.
            val featureSnapshot = RuntimeFeatureSnapshot.collect(context)
            addEntry("settings/runtime_features.json", featureSnapshot.toString(2).toByteArray(Charsets.UTF_8))
            // Fatal UI crash evidence survives a process restart and is automatically archived.
            for(name in listOf("ui_last_crash.txt", "ui_last_theme_error.txt")) {
                val file=File(context.filesDir,name)
                if(file.isFile && file.length() in 1..65_536) {
                    addFile("diagnostics/$name",file,context.filesDir)
                }
            }

            val continuityJson = runCatching { CaptureContinuity.snapshot(context, state.id) }
                .getOrElse { JSONObject().put("sessionId", state.id).put("journalError", it.javaClass.simpleName) }
            addEntry("lifecycle/capture_continuity.json", continuityJson.toString(2).toByteArray(Charsets.UTF_8))

            // Vehicle JSONL is filtered to the active session; do not leak other journeys.
            val eventsDigest = MessageDigest.getInstance("SHA-256")
            var eventBytes = 0L
            zip.putNextEntry(ZipEntry("logs/vehicle_events.jsonl"))
            logger.directory().listFiles()?.asSequence()?.filter { it.isFile && it.extension == "jsonl" }
                ?.sortedBy { it.name }?.forEach { file ->
                    file.bufferedReader(Charsets.UTF_8).useLines { lines ->
                        lines.forEach { line ->
                            val timestamp = runCatching { JSONObject(line).optLong("ts", -1L) }.getOrDefault(-1L)
                            if (timestamp in state.startMs..state.endMs) {
                                val bytes = (line + "\n").toByteArray(Charsets.UTF_8)
                                zip.write(bytes)
                                eventsDigest.update(bytes)
                                eventBytes += bytes.size
                            }
                        }
                    }
                }
            zip.closeEntry()
            manifestFiles.put(JSONObject().put("path", "logs/vehicle_events.jsonl")
                .put("bytes", eventBytes)
                .put("sha256", eventsDigest.digest().joinToString("") { "%02x".format(it) }))

            // A quick stock-TMAP / third-party / AVAS capture previously disappeared here.
            sysFolders.forEach { folder -> addTree(folder, "diagnostics/${folder.name}") }
            // A 3/8/15 second lab scan was exported only by a separate UI ZIP before this patch.
            navFolders.forEach { folder -> addTree(folder, "nav_audio_lab/${folder.name}") }
            val navRoot = File(context.filesDir, "nav_audio_lab")
            listOf("observations.tsv", "uid_relay_status.log").forEach { filename ->
                val file = File(navRoot, filename)
                if (file.isFile) {
                    val selected = SessionDiagnosticSelector.filterTimedLines(file, state.startMs, state.endMs)
                    if (selected.isNotEmpty()) addEntry("nav_audio_lab/$filename", selected)
                }
            }
            // Inventory is generated from the exact archived bytes, not guessed file names.
            val manifest = JSONObject().put("schema", "DOLPHIN_SESSION_EVIDENCE_MANIFEST_V1")
                .put("sessionId", state.id).put("files", manifestFiles)
                .put("includedFileCount", manifestFiles.length())
                .put("navScanFailures", statuses.count { it.second != "COMPLETE" })
            zip.putNextEntry(ZipEntry("evidence_manifest.json"))
            zip.write(manifest.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }
}
