package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors

/** Temporary global density on external app foreground; restore original exact override on leave.
 * NEVER claim isolated per-app density. Changes entire display while target app is visible.
 */
object TemporaryAppDpiController {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r,"temporary-app-dpi") }
    private const val PREF = "temporary_app_dpi_session"
    private fun prefs(c:Context) = c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
    fun onForeground(context: Context, pkg: String) {
        val app=context.applicationContext
        worker.execute { process(app,pkg) }
    }
    fun disableAndRestore(context: Context) {
        val app=context.applicationContext
        worker.execute { restore(app) }
    }
    fun recoverOnStartup(context: Context) {
        val app=context.applicationContext
        worker.execute { restore(app) }
    }
    /** Same executor as foreground changes, so a manual global choice cannot race restoration. */
    fun applyExplicitGlobal(context: Context, dpi: Int?, onResult: (DisplaySettingsController.Result) -> Unit) {
        val app=context.applicationContext
        worker.execute {
            restore(app)
            val result=if (prefs(app).contains("target"))
                DisplaySettingsController.Result(false,"임시 DPI 복원이 완료되지 않아 수동 변경을 중단했습니다")
                else DisplaySettingsController.applyDensity(app,dpi)
            onResult(result)
        }
    }
    private fun process(c: Context, pkg: String) {
        if (!ThirdPartyDpiRules.enabled(c)) { restore(c); return }
        val dpi=ThirdPartyDpiRules.rule(c,pkg)
        if (dpi == 0) { restore(c);return }
        val existing=prefs(c)
        if (existing.getString("target",null)==pkg && existing.getInt("value",0)==dpi) return
        restore(c)
        // Never apply a second override if the previous one could not be restored.
        if (prefs(c).contains("target")) return
        if (AuthorizedAdbRuntime.health(c).state != AuthorizedAdbRuntime.State.READY) {
            CoreLog.w("DPI","ADB not ready; temporary rule skipped: $pkg");return
        }
        val before=DisplaySettingsController.readDensity(c) ?: return
        if (!prefs(c).edit().putString("target",pkg).putInt("value",dpi)
                .putInt("beforeOverride",before.override ?: -1).commit()) return
        val run=AuthorizedAdbRuntime.writeOnce(c,"wm density $dpi")
        val after=DisplaySettingsController.readDensity(c)
        if (!run.result.success || after?.override != dpi) {
            CoreLog.w("DPI","temporary apply failed target=$pkg state=${run.state} actual=$after")
            restore(c)
        } else CoreLog.i("DPI","temporary global $dpi target=$pkg, ALL OEM UI also affected")
    }
    private fun restore(c: Context) {
        val pref=prefs(c)
        if (!pref.contains("target")) return
        val assigned=pref.getInt("value",0)
        val before=pref.getInt("beforeOverride",-1)
        val now=DisplaySettingsController.readDensity(c)
        // Do not overwrite unrelated user/system changes that occurred while our rule was active.
        if (now?.override == assigned) {
            val cmd=if (before < 0) "wm density reset" else "wm density $before"
            val result=AuthorizedAdbRuntime.writeOnce(c,cmd)
            val after=DisplaySettingsController.readDensity(c)
            if (!result.result.success || after?.override != before.takeIf { it >= 0 }) {
                CoreLog.w("DPI","temporary restore failed; will retry on next foreground event")
                return
            }
        } else if (now == null) return
        pref.edit().clear().commit()
        CoreLog.i("DPI","temporary global override restoration completed")
    }
}
