package com.byd.dolphin.drivealerts.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Toast
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.camera.BsdCameraOverlayController
import com.byd.dolphin.drivealerts.camera.LeadCarDeparturePreferences
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest

/** Settings UI for Front-Camera + Front-Sensor fused Lead Car Departure Alert. */
class LeadCarDepartureActivity : DensityAwareActivity() {
    private var previewPlayer: AlertAudioPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        previewPlayer = AlertAudioPlayer(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@LeadCarDepartureActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                DashboardUi.dp(this@LeadCarDepartureActivity, 18),
                DashboardUi.dp(this@LeadCarDepartureActivity, 14),
                DashboardUi.dp(this@LeadCarDepartureActivity, 18),
                DashboardUi.dp(this@LeadCarDepartureActivity, 24)
            )
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "앞차 출발 감지", "전방 카메라 + 전방 센서 융합 · 정차 시 자동 감시")

        val accent = DashboardUi.accentColor(this)

        val iccPanel = DashboardUi.panel(
            this,
            "자율주행(ICC/ACC) 중 앞차 출발 감지 (차량 SDK 읽기 전용)",
            "BYD DiPilot / ADAS의 앞차 출발 신호(onFrontCarStartStateChange · getFrontCarStartState)를 읽기 전용으로 수신합니다.",
            DashboardIcons.IconKind.STEERING,
            DashboardUi.okColor(this)
        ) { p ->
            p.addView(DashboardUi.toggle(this, "자율주행(ICC/ACC) 앞차 출발 알림 사용", LeadCarDeparturePreferences.iccEnabled(this)) {
                LeadCarDeparturePreferences.setIccEnabled(this, it)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this, 4), 0, DashboardUi.dp(this, 4)) })
            p.addView(DashboardUi.toggle(this, "ICC/ACC 활성 상태일 때만 발화 (일반 주행과 분리)", LeadCarDeparturePreferences.iccRequireActive(this)) {
                LeadCarDeparturePreferences.setIccRequireActive(this, it)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this, 4), 0, 0) })
        }
        iccPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, iccPanel)

        val enablePanel = DashboardUi.panel(
            this,
            "전방 카메라 · 전방 센서 융합 앞차 출발 알림",
            "D 기어 정차(1.5초 이상) 상태에서만 자동 무장하며, 주행 시작 또는 R/P 전환 시 카메라를 즉시 반납합니다.",
            DashboardIcons.IconKind.CAR_ALERT,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "앞차 출발 융합 감지 사용", LeadCarDeparturePreferences.enabled(this)) {
                LeadCarDeparturePreferences.setEnabled(this, it)
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this, 4), 0, DashboardUi.dp(this, 6)) })

            p.addView(
                DashboardUi.action(this, "카메라 권한 요청 (전방 카메라 분석용)", DashboardIcons.IconKind.KEY_PERM, accent) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "카메라 권한이 이미 허용되어 있습니다.", Toast.LENGTH_SHORT).show()
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.CAMERA), 9102)
                    }
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this, 48)).apply { setMargins(0, DashboardUi.dp(this, 4), 0, 0) }
            )
        }
        enablePanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, enablePanel)

        val configPanel = DashboardUi.panel(
            this,
            "감지 방식 · 민감도 · 전방 카메라 설정",
            "일반 신호대기 거리(2m 이상)는 전방 카메라 분석이 효과적이며, 근접 정차 시 전방 레이더 센서가 함께 보완합니다.",
            DashboardIcons.IconKind.GAUGE,
            accent
        ) { p ->
            p.addView(DashboardUi.label(this, "감지 모드", 13f))
            val modeSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@LeadCarDepartureActivity, LeadCarDeparturePreferences.modeLabels)
                setSelection(LeadCarDeparturePreferences.mode(this@LeadCarDepartureActivity))
            }
            p.addView(modeSpinner)

            p.addView(DashboardUi.label(this, "감지 민감도", 13f))
            val sensSpinner = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@LeadCarDepartureActivity, LeadCarDeparturePreferences.sensitivityLabels)
                setSelection(LeadCarDeparturePreferences.sensitivity(this@LeadCarDepartureActivity))
            }
            p.addView(sensSpinner)

            p.addView(DashboardUi.label(this, "전방 카메라 ID (기본 0)", 13f))
            val camInput = EditText(this).apply {
                setText(LeadCarDeparturePreferences.frontCameraId(this@LeadCarDepartureActivity))
                hint = "예: 0"
            }
            p.addView(camInput)

            val avmCheck = CheckBox(this).apply {
                text = "BYD 4분할 AVM 합성 스트림에서 전방 사분면(좌상단)만 분석"
                isChecked = LeadCarDeparturePreferences.avmFrontQuadrant(this@LeadCarDepartureActivity)
            }
            p.addView(avmCheck)

            p.addView(
                DashboardUi.action(this, "앞차 출발 감지 설정 저장", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
                    LeadCarDeparturePreferences.setMode(this, modeSpinner.selectedItemPosition)
                    LeadCarDeparturePreferences.setSensitivity(this, sensSpinner.selectedItemPosition)
                    LeadCarDeparturePreferences.setFrontCameraId(this, camInput.text.toString())
                    LeadCarDeparturePreferences.setAvmFrontQuadrant(this, avmCheck.isChecked)
                    Toast.makeText(this, "앞차 출발 감지 설정 저장 완료", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this, 48)).apply { setMargins(0, DashboardUi.dp(this, 8), 0, 0) }
            )
        }
        configPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, configPanel)

        val probePanel = DashboardUi.panel(
            this,
            "전방 카메라 상태 및 알림 음성 테스트",
            "차량 Camera2 노출 상태 확인 및 '앞차 출발' 음성을 바로 테스트합니다.",
            DashboardIcons.IconKind.PLAY,
            DashboardUi.okColor(this)
        ) { p ->
            val probeText = BsdCameraOverlayController(applicationContext).probeCameras()
            p.addView(DashboardUi.label(this, probeText, 12.5f))
            p.addView(
                DashboardUi.action(this, "'앞차 출발' 음성 테스트 재생", DashboardIcons.IconKind.PLAY, accent) {
                    runCatching { previewPlayer?.play(AlertRequest(AlertEvent.LEAD_CAR_DEPARTURE)) }
                        .onFailure { Toast.makeText(this, "음성 테스트 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this, 48)).apply { setMargins(0, DashboardUi.dp(this, 6), 0, 0) }
            )
        }
        probePanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, probePanel)
    }

    override fun onDestroy() {
        runCatching { previewPlayer?.shutdown() }
        previewPlayer = null
        super.onDestroy()
    }
}
