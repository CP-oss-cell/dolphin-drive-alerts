package com.byd.dolphin.drivealerts.ui

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.audio.EqPreferences
import com.byd.dolphin.drivealerts.audio.GlobalEqualizerEngine
import com.byd.dolphin.drivealerts.audio.SoundFocusMode
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.service.DrivingAlertService

/** Hyundai/Kia Meridian-grade precision 10-band EQ, loudness compensation, spatial & stage balance UI. */
class AudioTuningActivity : DensityAwareActivity() {
    private lateinit var runtimeState: TextView

    private data class SoundPreset(
        val name: String,
        val bass: Int, val mid: Int, val treble: Int,
        val focus: SoundFocusMode,
        val spatialOn: Boolean, val spatialAmt: Int,
        val makeup: Float,
        val band10: List<Int>
    )

    private val presets = listOf(
        SoundPreset("원음 (Flat)", 0, 0, 0, SoundFocusMode.REFERENCE, false, 0, 1.5f, listOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
        SoundPreset("프리미엄 (Meridian 스타일)", 2, 0, 2, SoundFocusMode.SURROUND, true, 70, 2.5f, listOf(3, 2, 1, -2, 0, 1, 2, 3, 3, 2)),
        SoundPreset("딥 베이스 (Club)", 5, -1, 2, SoundFocusMode.CINEMA, true, 65, 2.5f, listOf(6, 5, 3, -2, -1, 0, 1, 2, 2, 1)),
        SoundPreset("보컬 선명 (Voice)", 0, 3, 2, SoundFocusMode.SURROUND, true, 55, 2.5f, listOf(-1, 0, 0, -2, 2, 4, 4, 3, 2, 1)),
        SoundPreset("콘서트홀 (Live)", 2, 0, 3, SoundFocusMode.SURROUND, true, 90, 3.0f, listOf(2, 2, 0, -3, 0, 1, 2, 4, 5, 4)),
        SoundPreset("야간 드라이브 (Soft)", 1, 1, -1, SoundFocusMode.REFERENCE, true, 40, 2.0f, listOf(2, 1, 0, -1, 1, 1, 0, -1, -1, -2))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DashboardUi.mount(this, buildUi(), "프리미엄 이퀄라이저 · 음장", "10밴드 정밀 · 볼륨 보상 리미터 · 좌/우 정위감")
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@AudioTuningActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@AudioTuningActivity, 18), DashboardUi.dp(this@AudioTuningActivity, 14),
                DashboardUi.dp(this@AudioTuningActivity, 18), DashboardUi.dp(this@AudioTuningActivity, 28))
        }
        val current = EqPreferences.read(this)
        val accent = DashboardUi.accentColor(this)

        // 1. Master EQ + Loudness Compensation + Limiter + MBC
        val masterPanel = DashboardUi.panel(
            this,
            "프리미엄 사운드 엔진 (볼륨 저하 방지)",
            "소프트 리미터와 게인 보상으로 EQ를 켜도 음량이 줄지 않고 선명도와 타격감이 살아납니다.",
            DashboardIcons.IconKind.EQUALIZER,
            accent
        ) { p ->
            runtimeState = DashboardUi.label(this, GlobalEqualizerEngine.readStatus(this), 12.5f)
            p.addView(runtimeState)
            p.addView(DashboardUi.toggle(this, "이퀄라이저 · 음장 엔진 사용", current.enabled) {
                EqPreferences.setEnabled(this, it); applyLive()
            })
            p.addView(DashboardUi.toggle(this, "다른 앱 음악에도 적용 (Global Mix 호환모드)", current.globalMix) {
                EqPreferences.setGlobalMix(this, it); applyLive()
            })
            p.addView(DashboardUi.toggle(this, "멀티밴드 다이내믹 확장 (3밴드 MBC · 풍성한 음색)", current.dynamicMbcEnabled) {
                EqPreferences.setDynamicMbcEnabled(this, it); applyLive()
            })
            p.addView(DashboardUi.toggle(this, "클리핑 방지 소프트 리미터 (왜곡 없이 음량 유지)", current.limiterEnabled) {
                EqPreferences.setLimiterEnabled(this, it); applyLive()
            })

            val gainLabel = DashboardUi.label(this, "출력 게인 보상 (볼륨 저하 보정): +${"%.1f".format(current.makeupGainDb)} dB", 13.5f, true)
            p.addView(gainLabel)
            p.addView(SeekBar(this).apply {
                max = 12 // 0.0 .. 6.0 dB in 0.5 dB steps
                progress = (current.makeupGainDb * 2f).toInt().coerceIn(0, 12)
                setOnSeekBarChangeListener(simpleSeek { v ->
                    val db = v * 0.5f
                    gainLabel.text = "출력 게인 보상 (볼륨 저하 보정): +${"%.1f".format(db)} dB"
                    EqPreferences.setMakeupGainDb(this@AudioTuningActivity, db)
                    applyLive()
                })
            })
        }
        masterPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, masterPanel)

        // 2. One-Tap Hyundai/Kia-style Signature Presets
        val presetPanel = DashboardUi.panel(
            this,
            "원터치 사운드 프리셋",
            "현대·기아 프리미엄 오디오 튜닝 커브를 원터치로 적용하고 아래에서 미세 조정할 수 있습니다.",
            DashboardIcons.IconKind.AUDIO_NAV,
            DashboardUi.okColor(this)
        ) { p ->
            presets.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEach { preset ->
                    row.addView(
                        DashboardUi.action(this, preset.name, DashboardIcons.IconKind.EQUALIZER, accent) {
                            EqPreferences.setEnabled(this, true)
                            EqPreferences.setBass(this, preset.bass)
                            EqPreferences.setMid(this, preset.mid)
                            EqPreferences.setTreble(this, preset.treble)
                            EqPreferences.setSoundFocus(this, preset.focus)
                            EqPreferences.setCenterpoint360(this, preset.spatialOn)
                            EqPreferences.setSpatialStrength(this, preset.spatialAmt)
                            EqPreferences.setMakeupGainDb(this, preset.makeup)
                            EqPreferences.setAllBand10(this, preset.band10)
                            applyLive()
                            Toast.makeText(this, "'${preset.name}' 프리셋 적용 완료", Toast.LENGTH_SHORT).show()
                            recreate()
                        },
                        LinearLayout.LayoutParams(0, DashboardUi.dp(this, 48), 1f).apply {
                            setMargins(DashboardUi.dp(this, 3), DashboardUi.dp(this, 3), DashboardUi.dp(this, 3), DashboardUi.dp(this, 3))
                        }
                    )
                }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                p.addView(row)
            }
        }
        presetPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, presetPanel)

        // 3. Sound Focus & Spatial Expansion & Driver Stage Balance
        val stagePanel = DashboardUi.panel(
            this,
            "음장 모드 (Sound Focus) · 공간감 · 운전석 정위감",
            "차량 스피커에서도 즉시 체감되는 음향 커브 + 스테레오 공간 확장 + 좌/우 밸런스",
            DashboardIcons.IconKind.SPEAKER,
            accent
        ) { p ->
            val modes = listOf(SoundFocusMode.REFERENCE, SoundFocusMode.SURROUND, SoundFocusMode.CINEMA)
            val labels = listOf("Reference (원음)", "Surround (입체 음장)", "Cinema (극장 저음)")
            p.addView(DashboardUi.segmentedBar(this, labels, modes.indexOf(current.soundFocus).coerceAtLeast(0), accent) { idx ->
                EqPreferences.setSoundFocus(this, modes[idx]); applyLive()
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this, 4), 0, DashboardUi.dp(this, 8)) })

            p.addView(DashboardUi.toggle(this, "공간 확장 (차량 360 어쿠스틱 스테이지)", current.centerpoint360) {
                EqPreferences.setCenterpoint360(this, it); applyLive()
            })

            val spLabel = DashboardUi.label(this, "공간감 확장 강도: ${current.spatialStrength}%", 13.5f, true)
            p.addView(spLabel)
            p.addView(SeekBar(this).apply {
                max = 100; progress = current.spatialStrength
                setOnSeekBarChangeListener(simpleSeek { v ->
                    spLabel.text = "공간감 확장 강도: $v%"
                    EqPreferences.setSpatialStrength(this@AudioTuningActivity, v); applyLive()
                })
            })

            val balText = { b: Int ->
                when {
                    b < 0 -> "운전석(좌) 집중 ${-b}단계"
                    b > 0 -> "동승석(우) 집중 ${b}단계"
                    else -> "중앙 균형 (0)"
                }
            }
            val balLabel = DashboardUi.label(this, "좌/우 스테이지 밸런스: ${balText(current.balanceLr)}", 13.5f, true)
            p.addView(balLabel)
            p.addView(SeekBar(this).apply {
                max = 20; progress = current.balanceLr + 10
                setOnSeekBarChangeListener(simpleSeek { v ->
                    val b = v - 10
                    balLabel.text = "좌/우 스테이지 밸런스: ${balText(b)}"
                    EqPreferences.setBalanceLr(this@AudioTuningActivity, b); applyLive()
                })
            })
        }
        stagePanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, stagePanel)

        // 4. Quick 3-Band Tone + Precision 10-Band Graphic EQ
        val eqPanel = DashboardUi.panel(
            this,
            "간편 3밴드 · 초정밀 10밴드 이퀄라이저",
            "31Hz 초저음부터 16kHz 초고음 공기감까지 1dB 단위로 세밀하게 조절합니다.",
            DashboardIcons.IconKind.EQUALIZER,
            accent
        ) { p ->
            fun addBandRow(title: String, initial: Int, onSave: (Int) -> Unit) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val tv = DashboardUi.label(this, "$title  ${if (initial > 0) "+$initial" else "$initial"} dB", 13f, true)
                row.addView(tv, LinearLayout.LayoutParams(DashboardUi.dp(this, 130), -2))
                row.addView(SeekBar(this).apply {
                    max = 20; progress = initial + 10
                    setOnSeekBarChangeListener(simpleSeek { v ->
                        val db = v - 10
                        tv.text = "$title  ${if (db > 0) "+$db" else "$db"} dB"
                        onSave(db); applyLive()
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                p.addView(row)
            }
            addBandRow("저음 (Bass)", current.bass) { EqPreferences.setBass(this, it) }
            addBandRow("중음 (Mid)", current.mid) { EqPreferences.setMid(this, it) }
            addBandRow("고음 (Treble)", current.treble) { EqPreferences.setTreble(this, it) }
            p.addView(DashboardUi.label(this, "── 10밴드 정밀 주파수 조절 (31Hz ~ 16kHz) ──", 12.5f))
            EqPreferences.BAND10_LABELS.forEachIndexed { idx, freqLabel ->
                addBandRow(freqLabel, current.band10.getOrElse(idx) { 0 }) { EqPreferences.setBand10(this, idx, it) }
            }
            p.addView(
                DashboardUi.action(this, "오디오 설정 모두 기본값으로 초기화", DashboardIcons.IconKind.RESCUE, DashboardUi.warnColor(this)) {
                    EqPreferences.setEnabled(this, false)
                    EqPreferences.setBass(this, 0); EqPreferences.setMid(this, 0); EqPreferences.setTreble(this, 0)
                    EqPreferences.setCenterpoint360(this, false); EqPreferences.setSpatialStrength(this, 50)
                    EqPreferences.setSoundFocus(this, SoundFocusMode.REFERENCE)
                    EqPreferences.setMakeupGainDb(this, 2.0f); EqPreferences.setBalanceLr(this, 0)
                    EqPreferences.setAllBand10(this, List(10) { 0 })
                    applyLive(); recreate()
                },
                LinearLayout.LayoutParams(-1, DashboardUi.dp(this, 48)).apply { setMargins(0, DashboardUi.dp(this, 10), 0, 0) }
            )
        }
        eqPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, eqPanel)

        scroll.addView(root)
        return scroll
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun applyLive() {
        DrivingAlertService.refreshEqualizer(this)
        runtimeState.postDelayed({
            if (!isFinishing && !isDestroyed) runtimeState.text = GlobalEqualizerEngine.readStatus(this)
        }, 300L)
    }

    override fun onResume() {
        super.onResume()
        if (::runtimeState.isInitialized) runtimeState.text = GlobalEqualizerEngine.readStatus(this)
    }
}
