#!/usr/bin/env python3
import argparse, hashlib, json, os, pathlib, shutil, subprocess, sys, tempfile, wave

VOICES = {
    "male": {"voice": "ko-KR-InJoonNeural", "rate": "-4%", "pitch": "-1Hz"},
    "female": {"voice": "ko-KR-SunHiNeural", "rate": "-3%", "pitch": "+0Hz"},
}

def run(cmd):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, check=True)

def wav_info(path):
    with wave.open(str(path), "rb") as w:
        return w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="app/src/main/assets/voice")
    ap.add_argument("--manifest", default="tools/voice_prompts.json")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    root = pathlib.Path(__file__).resolve().parents[1]
    out = (root / args.out).resolve()
    manifest = json.loads((root / args.manifest).read_text(encoding="utf-8"))
    if shutil.which("ffmpeg") is None:
        raise SystemExit("ffmpeg is required")
    try:
        import edge_tts  # noqa
    except Exception:
        raise SystemExit("edge-tts is required: pip install edge-tts==7.2.8")

    rows=[]
    with tempfile.TemporaryDirectory(prefix="drivealerts-tts-") as td:
        td=pathlib.Path(td)
        for style, cfg in VOICES.items():
            destdir=out/style
            destdir.mkdir(parents=True, exist_ok=True)
            for i,item in enumerate(manifest,1):
                dest=destdir/item["file"]
                if dest.exists() and not args.force:
                    print("skip", dest)
                else:
                    mp3=td/f"{style}-{i:02d}.mp3"
                    cmd=[sys.executable,"-m","edge_tts","--voice",cfg["voice"],"--rate",cfg["rate"],"--pitch",cfg["pitch"],"--text",item["text"],"--write-media",str(mp3)]
                    last=None
                    for attempt in range(1,4):
                        try:
                            run(cmd); last=None; break
                        except subprocess.CalledProcessError as e:
                            last=e
                            print(f"edge-tts attempt {attempt}/3 failed for {item['file']}", file=sys.stderr)
                    if last is not None: raise last
                    # PCM16 mono 44.1 kHz, trimmed and level-normalized for low-latency AudioTrack playback.
                    af="silenceremove=start_periods=1:start_duration=0.02:start_threshold=-48dB:stop_periods=-1:stop_duration=0.06:stop_threshold=-48dB,loudnorm=I=-16:LRA=6:TP=-1.5,apad=pad_dur=0.06"
                    run(["ffmpeg","-hide_banner","-loglevel","error","-y","-i",str(mp3),"-af",af,"-ac","1","-ar","44100","-c:a","pcm_s16le",str(dest)])
                ch,sw,sr,n=wav_info(dest)
                if (ch,sw,sr)!=(1,2,44100):
                    raise SystemExit(f"bad wav format {dest}: ch={ch} width={sw} sr={sr}")
                h=hashlib.sha256(dest.read_bytes()).hexdigest()
                rows.append({"style":style,"voice":cfg["voice"],"file":item["file"],"text":item["text"],"sample_rate":sr,"channels":ch,"frames":n,"sha256":h})
    report=out/"voice_pack_manifest.generated.json"
    report.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Generated/validated {len(rows)} WAV files -> {out}")
    if len(rows)!=60: raise SystemExit(f"expected 60 files, got {len(rows)}")

if __name__=="__main__": main()
