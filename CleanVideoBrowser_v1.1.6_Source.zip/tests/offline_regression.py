"""Run focused detector/quality tests without Android SDK or internet."""
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import textwrap

root = Path(__file__).resolve().parents[1]
src = root / 'app/src/main/java/com/personal/cleanvideobrowser'
with TemporaryDirectory() as d:
    work = Path(d)
    def put(name, text):
        p = work / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(textwrap.dedent(text))
        return str(p)
    uri = put('android/net/Uri.java', '''
        package android.net;
        public class Uri {
          private final java.net.URI u;
          private Uri(String s) { u=java.net.URI.create(s); }
          public static Uri parse(String s) { return new Uri(s); }
          public String getPath() { return u.getPath(); }
          public String getScheme() { return u.getScheme(); }
          public String getHost() { return u.getHost(); }
          public String getEncodedUserInfo() {return u.getRawUserInfo();}
        }
    ''')
    urlutil = put('android/webkit/URLUtil.java', '''
        package android.webkit;
        public class URLUtil {
          public static String guessFileName(String a, String b, String c) {return "video.mp4";}
        }
    ''')
    store = put('com/personal/cleanvideobrowser/DownloadStore.java', '''
        package com.personal.cleanvideobrowser;
        final class DownloadStore { static String safeFileName(String s) {return s;} }
    ''')
    runner = put('com/personal/cleanvideobrowser/Regression.java', '''
        package com.personal.cleanvideobrowser;
        import java.net.*;
        import java.io.*;
        import com.sun.net.httpserver.HttpServer;
        import java.nio.charset.StandardCharsets;
        import java.util.List;
        public class Regression {
          static void ok(boolean v, String name) { if(!v)throw new AssertionError(name); }
          public static void main(String[] args) throws Exception {
            VideoCandidate ad = new VideoCandidate("https://sample.org/videos/intro.mp4");
            ad.observe(2, 640,360, 10, false, "sample.org");
            ad.observe(3, 640,360, 10, true, "sample.org");
            ok(ad.recommended(), "directly playing short clip should remain visible");
            VideoCandidate passive = new VideoCandidate("https://sample.org/videos/preview.mp4");
            passive.observe(1, 0, 0, 15, false, "sample.org");
            ok(!passive.recommended(), "passive short resource should not be promoted");
            VideoCandidate movie = new VideoCandidate("https://sample.org/video/episode.m3u8");
            movie.observe(3,1920,1080,900,true, "sample.org");
            ok(movie.recommended(), "long playing video should be recommended");
            ok(MediaDetector.adLike("https://sample.org/ads/preroll.mp4"), "ad path filtered");
            ok(!MediaDetector.validWebUrl("https://trusted.example@evil.example/video.mp4"), "embedded credentials rejected");
            ok(!MediaDetector.adLike("https://sample.org/adventure/episode.mp4"), "normal path retained");
            HttpServer http = HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
            http.createContext("/master.m3u8", exc -> {
              byte[] b=("#EXTM3U\\n#EXT-X-STREAM-INF:BANDWIDTH=6000000,RESOLUTION=1920x1080\\n1080.m3u8\\n"+
                "#EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1280x720\\n720.m3u8\\n").getBytes(StandardCharsets.UTF_8);
              exc.getResponseHeaders().set("Content-Type", "application/vnd.apple.mpegurl");
              exc.sendResponseHeaders(200,b.length);
              try (OutputStream out=exc.getResponseBody()) {out.write(b);}
            });
            http.createContext("/split.m3u8", exc -> {
              byte[] b=("#EXTM3U\\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\\\"a1\\\",URI=\\\"audio.m3u8\\\"\\n"+
                "#EXT-X-STREAM-INF:BANDWIDTH=4000000,RESOLUTION=1280x720,AUDIO=\\\"a1\\\"\\nvideo.m3u8\\n").getBytes(StandardCharsets.UTF_8);
              exc.sendResponseHeaders(200,b.length);
              try (OutputStream out=exc.getResponseBody()) {out.write(b);}
            });
            http.start();
            try {
              String url="http://127.0.0.1:"+http.getAddress().getPort()+"/master.m3u8";
              List<HlsQualityResolver.Quality> choices=HlsQualityResolver.inspect(url,url,"test",null);
              ok(choices.size()==2,"two qualities detected");
              ok(choices.get(0).height==1080 && choices.get(1).height==720,"real resolutions sorted");
              ok(choices.get(0).url.endsWith("1080.m3u8"),"variant url resolution");
              boolean rejected=false;
              try { HlsQualityResolver.inspect(url.replace("master.m3u8","split.m3u8"),url,"test",null); }
              catch(Exception expected) { rejected=true; }
              ok(rejected,"separate audio variant must not be offered as silent video");
            } finally { http.stop(0); }
            System.out.println("OFFLINE_REGRESSION_OK: ad filter, main candidate, HLS qualities");
          }
        }
    ''')
    sources = [uri,urlutil,store,runner] + [str(src / (x+'.java')) for x in
         ['AdBlock','MediaDetector','VideoCandidate','HlsQualityResolver']]
    subprocess.run(['javac', '-d', str(work / 'classes'), *sources], check=True)
    subprocess.run(['java', '-cp', str(work/'classes'),
                    'com.personal.cleanvideobrowser.Regression'], check=True)
