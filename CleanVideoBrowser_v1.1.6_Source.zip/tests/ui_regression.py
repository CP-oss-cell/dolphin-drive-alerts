from pathlib import Path
base=Path(__file__).resolve().parents[1]
xml=(base/'app/src/main/res/layout/activity_main.xml').read_text()
java=(base/'app/src/main/java/com/personal/cleanvideobrowser/MainActivity.java').read_text()
assert 'quick_folder' in xml and 'quick_folder' in java
assert '화질 선택 · 받기' in xml and '원본 영상 받기' in java
assert '본편 추정 · 확인 필요' in java
assert 'StorageTarget.display(this)' in java
print('UI_REGRESSION_OK')
