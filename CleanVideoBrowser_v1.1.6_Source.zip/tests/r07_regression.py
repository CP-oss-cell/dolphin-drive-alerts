from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/personal/cleanvideobrowser/MainActivity.java').read_text()
js=(root/'app/src/main/assets/video_scan.js').read_text()
assert 'samePageDocument(page)' in main
assert 'reported.equals(visible)' in main
assert 'samePageHost(' not in main
assert 'window !== window.top' in js
assert 'addJavascriptInterface' not in main
assert 'evaluateJavascript(scanScript, json ->' in main
print('R07_ORIGIN_SAFE_QUERY_OK')
