# CleanVideoBrowser v1.1.6 검증 상태

- 완료: Java 구문 파서, XML 파싱, JavaScript 구문 검사, 본편/광고 후보 회귀 검사, HLS 오디오 분리 검사, bridge-free JS top-document 스캔 Node 테스트, 보안·UI 정적 회귀 검사.
- 완료: 소스/워크플로 이름 통일, 워크플로 자동 ZIP 압축해제 시뮬레이션, 바깥쪽 ZIP 두 파일 구성/CRC 검사.
- 미완료: Android SDK 기반 실제 APK 컴파일 및 휴대전화/실사이트 다운로드 시험.
- 제한: DRM/암호화, 분리 오디오 합치기, 라이브 HLS, 중단·재개, 본편 분류 100% 보장.
