# CleanVideoBrowser v1.1.6 — 통합 빌드

광고 SDK가 없는 한국어 브라우저 + 영상 감지·다운로드 앱. 별도 내장 동영상 플레이어 없음.

## 설치 후 사용 방법

1. 웹사이트 열기 → 원하는 영상 재생.
2. 웹페이지 아래 **재생 중인 영상** 카드에서 **원본 영상 받기** 또는 **화질 선택 · 받기** 누르기.
3. 필요하면 **저장 폴더 변경**에서 저장 위치 선택. 기본값: `내 파일 > 내부 저장공간 > Download > CleanVideo`.
4. **다운로드** 탭에서 진행 상태 확인 → 완료된 항목을 누르면 외부 영상 앱으로 엽니다.

광고/본편 판별은 추정이며 100% 정확하지 않습니다. 영상이 보이지 않으면 직접 영상을 재생 후 **영상 찾기**를 누르세요. 기본 대상은 원본 MP4 등 직접 URL과 비암호화 HLS VOD MPEG-TS입니다. HLS에서 별도 오디오, fMP4, DRM, 암호화, 실시간 방송, blob/MSE, 일부 인증 방식은 지원하지 않을 수 있습니다. 본인에게 저장 권한이 있는 영상만 받으세요.

## GitHub Actions 빌드 (두 파일 업로드)

바깥쪽 `CleanVideoBrowser_v1.1.6_Complete_Build_Package.zip`을 **한 번만 압축 해제**합니다.

- `CleanVideoBrowser_v1.1.6_Source.zip`: 압축을 **풀지 않고**, GitHub 저장소 최상위에 업로드
- `CleanVideoBrowser_v1.1.6_Source.yml`: `.github/workflows/CleanVideoBrowser_v1.1.6_Source.yml` 경로에 업로드

Actions에서 `CleanVideoBrowser v1.1.6 APK` → **Run workflow** 선택. 성공 시 `CleanVideoBrowser_v1.1.6_APK` 빌드 산출물의 APK를 내려받습니다.

**중요:** 같은 저장소에 예전 CleanVideoBrowser YML이 있으면 기존 버전 워크플로만 삭제하세요. **다른 앱의 YML은 삭제하지 마세요.** 이번 YML은 고유 앱 ZIP/YML 변경만 자동 빌드 이벤트로 감지합니다.

기존 `com.personal.cleanvideobrowser` 앱과 동일한 applicationId를 사용하지만 설치된 앱의 서명이 다르면 업데이트가 거부될 수 있습니다. 이 경우 데이터 백업 후 재설치가 필요할 수 있습니다.

## 설계 및 검증

- Android 10 이상, target SDK 35, Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9
- JS 네이티브 브리지 제거 후 현재 최상위 문서를 `evaluateJavascript`로 조회
- 후보/광고 필터, HLS 화질 선택, 폴더 선택 및 저장, 백그라운드 다운로드, 다운로드 목록, 즐겨찾기
- 외부 동영상 앱 열기, 부분 파일 감지, 완성 파일 URI 기록
- Java 구문 파서·JavaScript/Node 회귀 테스트·Android XML 검사 수행
- **실제 Android APK 컴파일과 휴대전화 실사용 검증은 수행하지 못함** (Android SDK가 없는 환경)

상세 변경 기록: `INTEGRATION_NOTES.md`. 1~7차 연구: `research/`.
