package com.personal.cleanvideobrowser;

import android.content.Context;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import java.io.OutputStream;

/** User-selected Storage Access Framework tree; otherwise public Downloads/CleanVideo. */
final class StorageTarget {
    private static final String PREFS = "clean_video_local";
    private static final String TREE = "target_tree_uri";
    private StorageTarget() {}

    static String selected(Context c) {
        return c.getSharedPreferences(PREFS, 0).getString(TREE, "");
    }
    static void choose(Context c, Uri tree) {
        c.getSharedPreferences(PREFS, 0).edit().putString(TREE, tree.toString()).apply();
    }
    static void reset(Context c) {
        c.getSharedPreferences(PREFS, 0).edit().remove(TREE).apply();
    }
    static String display(Context c) {
        String raw = selected(c);
        if (raw.isEmpty()) return "다운로드/CleanVideo";
        try {
            String id = DocumentsContract.getTreeDocumentId(Uri.parse(raw));
            int colon = id.indexOf(':');
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return path.isEmpty() ? "선택한 폴더" : path;
        } catch (Exception e) { return "선택한 폴더"; }
    }
    static final class FileOutput {
        final Uri uri;
        final boolean mediaStore;
        FileOutput(Uri u, boolean mediaStore) { this.uri = u; this.mediaStore = mediaStore; }
    }
    static FileOutput create(Context c, String treeRaw, String name, String mime) throws Exception {
        Uri uri;
        if (treeRaw != null && !treeRaw.isEmpty()) {
            Uri tree = Uri.parse(treeRaw);
            Uri document = DocumentsContract.buildDocumentUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            uri = DocumentsContract.createDocument(c.getContentResolver(), document, mime, name);
            if (uri == null) throw new Exception("선택한 폴더에 파일을 만들 수 없습니다. 폴더를 다시 지정하세요");
            return new FileOutput(uri, false);
        }
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/CleanVideo");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("기본 다운로드 폴더를 만들 수 없습니다");
        return new FileOutput(uri, true);
    }
    static OutputStream open(Context c, FileOutput target) throws Exception {
        OutputStream out = c.getContentResolver().openOutputStream(target.uri, "w");
        if (out == null) throw new Exception("저장 파일을 열 수 없습니다");
        return out;
    }
    static void finish(Context c, FileOutput target) throws Exception {
        if (!target.mediaStore) return;
        ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        if (c.getContentResolver().update(target.uri, ready, null, null) != 1)
            throw new Exception("저장 파일을 완료 상태로 전환할 수 없습니다");
    }
    static void delete(Context c, FileOutput target) {
        if (target == null) return;
        try { c.getContentResolver().delete(target.uri, null, null); }
        catch (Exception ignored) { }
    }
}
