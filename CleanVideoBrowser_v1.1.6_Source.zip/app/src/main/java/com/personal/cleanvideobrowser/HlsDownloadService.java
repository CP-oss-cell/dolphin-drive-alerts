package com.personal.cleanvideobrowser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads only clear, non-DRM, VOD HLS streams containing MPEG-TS segments. */
public final class HlsDownloadService extends Service {
    private static final String CHANNEL = "cleanvideo_downloads";
    private static final int NOTIFICATION_ID = 8901;
    private static final int MAX_MANIFEST_BYTES = 4 * 1024 * 1024;
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private NotificationManager notifications;

    @Override public void onCreate() {
        super.onCreate();
        notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(
                CHANNEL, "영상 다운로드", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        final String id = intent.getStringExtra("id");
        final String url = intent.getStringExtra("url");
        final String filename = intent.getStringExtra("filename");
        final String cookie = intent.getStringExtra("cookie");
        final String referer = intent.getStringExtra("referer");
        final String userAgent = intent.getStringExtra("ua");
        final String quality = intent.getStringExtra("quality");
        final String mode = intent.getStringExtra("mode");
        final String folder = intent.getStringExtra("folder");
        if (id == null || filename == null || !MediaDetector.validWebUrl(url)
                || !("direct".equals(mode) || "hls".equals(mode))) {
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification("영상 다운로드 준비 중", 0, true));
        jobs.execute(() -> {
            boolean ok = false;
            try {
                if ("hls".equals(mode))
                    process(id, url, filename, cookie, referer, userAgent, quality, folder);
                else
                    processDirect(id, url, filename, cookie, referer, userAgent, folder);
                ok = true;
                DownloadStore.update(this, id, "완료 · "
                        + ((folder == null || folder.isEmpty()) ? "다운로드/CleanVideo" : "선택한 폴더"), 100);
                notifications.notify(NOTIFICATION_ID,
                        buildNotification("다운로드 완료: " + filename, 100, false));
            } catch (Exception error) {
                String reason = error.getMessage();
                if (reason == null) reason = "네트워크 또는 저장 오류";
                if (reason.length() > 90) reason = reason.substring(0, 90);
                DownloadStore.update(this, id, "실패: " + reason, 0);
                notifications.notify(NOTIFICATION_ID,
                        buildNotification("다운로드 실패: " + reason, 0, false));
            } finally {
                if (stopSelfResult(startId)) {
                    stopForeground(STOP_FOREGROUND_REMOVE);
                    if (ok) notifications.notify(NOTIFICATION_ID + 1,
                            buildNotification("다운로드 완료: " + filename, 100, false));
                    else notifications.notify(NOTIFICATION_ID + 1,
                            buildNotification("영상 다운로드 실패 · 내역 확인", 0, false));
                }
            }
        });
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String message, int percent, boolean ongoing) {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(this, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("CleanVideo Browser")
                .setContentText(message)
                .setContentIntent(tap)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true);
        if (ongoing) builder.setProgress(100, percent, percent <= 0);
        else builder.setAutoCancel(true);
        return builder.build();
    }

    private static final class Source {
        final URL playlist;
        final String sourceHost;
        final String cookie;
        final String referer;
        final String ua;
        Source(String sourceUrl, String cookie, String referer, String ua) throws Exception {
            playlist = new URL(sourceUrl);
            sourceHost = playlist.getHost();
            this.cookie = cookie;
            this.referer = referer;
            this.ua = ua;
        }
    }

    private HttpURLConnection connect(URL url, Source context) throws Exception {
        String protocol = url.getProtocol().toLowerCase(Locale.ROOT);
        if (!protocol.equals("https") && !protocol.equals("http"))
            throw new Exception("웹 주소 형식만 지원합니다");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(18000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("Accept-Encoding", "identity");
        if (context.ua != null && !context.ua.isEmpty()) c.setRequestProperty("User-Agent", context.ua);
        if (context.referer != null && MediaDetector.validWebUrl(context.referer))
            c.setRequestProperty("Referer", context.referer);
        if (context.cookie != null && !context.cookie.isEmpty()
                && url.getHost().equalsIgnoreCase(context.sourceHost)) {
            c.setRequestProperty("Cookie", context.cookie);
        }
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            c.disconnect();
            throw new Exception("서버 응답 " + code);
        }
        return c;
    }

    private String readManifest(URL url, Source context) throws Exception {
        HttpURLConnection c = connect(url, context);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int read;
            while ((read = in.read(buf)) != -1) {
                if (out.size() + read > MAX_MANIFEST_BYTES) throw new Exception("재생목록 크기 초과");
                out.write(buf, 0, read);
            }
            String text = out.toString(StandardCharsets.UTF_8.name()).replace("\uFEFF", "");
            if (!text.trim().startsWith("#EXTM3U")) throw new Exception("HLS 재생목록이 아닙니다");
            return text;
        } finally { c.disconnect(); }
    }

    private static final class Variant {
        final URL url;
        final long bandwidth;
        Variant(URL url, long bandwidth) { this.url = url; this.bandwidth = bandwidth; }
    }

    private List<Variant> parseVariants(String playlist, URL base) throws Exception {
        List<Variant> variants = new ArrayList<>();
        String[] lines = playlist.split("\\r?\\n");
        long pending = -1;
        boolean unsupportedAudio = false;
        for (String sourceLine : lines) {
            String line = sourceLine.trim();
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                pending = 0;
                unsupportedAudio = line.matches("(?i).*\\bAUDIO=\"[^\"]+\".*");
                java.util.regex.Matcher matcher = java.util.regex.Pattern
                        .compile("(?:^|,)BANDWIDTH=(\\d+)")
                        .matcher(line.substring("#EXT-X-STREAM-INF:".length()));
                if (matcher.find()) pending = Long.parseLong(matcher.group(1));
            } else if (pending >= 0 && !line.isEmpty() && !line.startsWith("#")) {
                if (unsupportedAudio)
                    throw new Exception("오디오가 분리된 HLS는 현재 지원하지 않습니다 (무음 영상 방지)");
                variants.add(new Variant(new URL(base, line), pending));
                pending = -1;
            }
        }
        return variants;
    }

    private List<URL> parseSegments(String playlist, URL base) throws Exception {
        if (!playlist.contains("#EXT-X-ENDLIST")) {
            throw new Exception("실시간 방송은 지원하지 않습니다 (VOD만 지원)");
        }
        List<URL> urls = new ArrayList<>();
        boolean segmentExpected = false;
        for (String sourceLine : playlist.split("\\r?\\n")) {
            String line = sourceLine.trim();
            if (line.startsWith("#EXT-X-KEY:") && !line.matches("^#EXT-X-KEY:METHOD=NONE(?:,.*)?$"))
                throw new Exception("암호화된 HLS 영상은 지원하지 않습니다");
            if (line.startsWith("#EXT-X-BYTERANGE:"))
                throw new Exception("부분 범위 HLS는 지원하지 않습니다");
            if (line.startsWith("#EXT-X-MAP:"))
                throw new Exception("fMP4 HLS 형식은 아직 지원하지 않습니다");
            if (line.startsWith("#EXTINF:")) {
                segmentExpected = true;
            } else if (segmentExpected && !line.isEmpty() && !line.startsWith("#")) {
                URL segment = new URL(base, line);
                if (!segment.getProtocol().equals("https") && !segment.getProtocol().equals("http"))
                    throw new Exception("잘못된 영상 조각 주소");
                urls.add(segment);
                segmentExpected = false;
            }
            if (urls.size() > 5000) throw new Exception("영상 조각이 너무 많습니다");
        }
        if (urls.isEmpty()) throw new Exception("다운로드할 영상 조각이 없습니다");
        return urls;
    }

    private void process(String id, String url, String filename, String cookie,
                         String referer, String ua, String quality, String folder) throws Exception {
        Source source = new Source(url, cookie, referer, ua);
        URL manifestUrl = source.playlist;
        String manifest = readManifest(manifestUrl, source);
        for (int depth = 0; depth < 3; depth++) {
            List<Variant> variants = parseVariants(manifest, manifestUrl);
            if (variants.isEmpty()) break;
            Variant selected = variants.get(0);
            for (Variant v : variants) {
                boolean lower = "small".equals(quality);
                if ((lower && v.bandwidth < selected.bandwidth)
                        || (!lower && v.bandwidth > selected.bandwidth)) selected = v;
            }
            manifestUrl = selected.url;
            manifest = readManifest(manifestUrl, source);
        }
        if (!parseVariants(manifest, manifestUrl).isEmpty())
            throw new Exception("중첩된 재생목록은 지원하지 않습니다");
        List<URL> segments = parseSegments(manifest, manifestUrl);
        StorageTarget.FileOutput target = StorageTarget.create(this, folder,
                DownloadStore.safeFileName(filename), "video/mp2t");
        boolean completed = false;
        try (OutputStream out = StorageTarget.open(this, target)) {
            byte[] buffer = new byte[65536];
            for (int index = 0; index < segments.size(); index++) {
                if (Thread.currentThread().isInterrupted()) throw new Exception("다운로드가 중단되었습니다");
                HttpURLConnection c = connect(segments.get(index), source);
                try (InputStream in = c.getInputStream()) {
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (Thread.currentThread().isInterrupted()) throw new Exception("다운로드 중단");
                        out.write(buffer, 0, n);
                    }
                } finally { c.disconnect(); }
                int percent = (int) ((index + 1L) * 100 / segments.size());
                if (index == 0 || index == segments.size() - 1 || percent % 3 == 0) {
                    DownloadStore.update(this, id, "다운로드 중", percent);
                    notifications.notify(NOTIFICATION_ID, buildNotification(
                            "영상 조각 " + (index + 1) + "/" + segments.size(), percent, true));
                }
            }
            out.flush();
            completed = true;
        } finally {
            if (!completed) StorageTarget.delete(this, target);
        }
        try {
            StorageTarget.finish(this, target);
            DownloadStore.setUri(this, id, target.uri.toString());
        } catch (Exception e) {
            StorageTarget.delete(this, target);
            throw e;
        }
    }

    /** Direct file stream for user-selected folders. System DownloadManager handles default folder. */
    private void processDirect(String id, String url, String filename,
                               String cookie, String referer, String ua, String folder) throws Exception {
        Source source = new Source(url, cookie, referer, ua);
        HttpURLConnection connection = connect(new URL(url), source);
        StorageTarget.FileOutput target = null;
        try {
            String mime = connection.getContentType();
            if (mime != null && (mime.toLowerCase(Locale.ROOT).startsWith("text/html")
                    || mime.toLowerCase(Locale.ROOT).contains("application/json")))
                throw new Exception("사이트가 동영상 대신 웹페이지를 반환했습니다");
            String outputMime = filename.toLowerCase(Locale.ROOT).endsWith(".webm")
                    ? "video/webm" : filename.toLowerCase(Locale.ROOT).endsWith(".mov")
                    ? "video/quicktime" : "video/mp4";
            long total = connection.getContentLengthLong();
            target = StorageTarget.create(this, folder, DownloadStore.safeFileName(filename), outputMime);
            boolean completed = false;
            try (InputStream in = connection.getInputStream();
                 OutputStream out = StorageTarget.open(this, target)) {
                byte[] buffer = new byte[65536];
                long bytes = 0;
                int lastPercent = -1, n;
                while ((n = in.read(buffer)) != -1) {
                    if (Thread.currentThread().isInterrupted()) throw new Exception("다운로드 중단");
                    out.write(buffer, 0, n);
                    bytes += n;
                    int percent = total > 0 ? (int) Math.min(99, bytes * 100 / total) : 0;
                    if (percent != lastPercent && (percent % 3 == 0 || lastPercent == -1)) {
                        lastPercent = percent;
                        DownloadStore.update(this, id, "다운로드 중", percent);
                        notifications.notify(NOTIFICATION_ID,
                                buildNotification("파일 다운로드 중", percent, true));
                    }
                }
                if (total >= 0 && bytes != total)
                    throw new Exception("다운로드 크기 불일치 · 파일이 완전히 저장되지 않았습니다");
                out.flush();
                completed = true;
            } finally {
                if (!completed) StorageTarget.delete(this, target);
            }
            try {
                StorageTarget.finish(this, target);
                DownloadStore.setUri(this, id, target.uri.toString());
            } catch (Exception e) {
                StorageTarget.delete(this, target);
                throw e;
            }
        } finally { connection.disconnect(); }
    }

    @Override public void onDestroy() {
        jobs.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
