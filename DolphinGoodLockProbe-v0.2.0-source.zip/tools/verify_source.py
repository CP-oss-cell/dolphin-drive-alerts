#!/usr/bin/env python3
"""Static safety/structure checks. Not an Android SDK compile or a real-car test."""
from pathlib import Path
import sys, re, xml.etree.ElementTree as ET
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
src=r/'app/src/main/java/com/dolphin/goodlock/probe'
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
activity=(src/'MainActivity.java').read_text()
engine=(src/'CandidateEngine.java').read_text()
base=(src/'ProbeEngine.java').read_text()
widget=(src/'DiagnosticWidget.java').read_text()
checks={
 'manifest XML parses': lambda: ET.fromstring(manifest) is not None,
 'zero uses-permission': lambda: '<uses-permission' not in manifest,
 'no HOME category registration': lambda: 'android.intent.category.HOME' not in manifest,
 'no new overlay service': lambda: 'SYSTEM_ALERT_WINDOW' not in manifest,
 'no internet permission': lambda: 'INTERNET' not in manifest,
 'min sdk 29': lambda: 'minSdk 29' in (r/'app/build.gradle').read_text(),
 'version code 2': lambda: 'versionCode 2' in (r/'app/build.gradle').read_text(),
 'single installed package': lambda: "applicationId 'com.dolphin.goodlock.probe'" in (r/'app/build.gradle').read_text(),
 'stage1 batch discover': lambda: 'BATCH_DISCOVER' in activity and 'JSONArray discover()' in engine,
 'stage2 candidate selection': lambda: 'SELECT_AND_INSPECT' in activity,
 'stage3 gated by stage2': lambda: 'lastInspectedId' in activity and '2단계 분석을 먼저' in activity,
 'stage3 candidate aware': lambda: 'suggestedActions' in engine,
 'stage4 observation': lambda: 'USER_REPORTED_NOT_AUTOMATED_VERIFICATION' in activity,
 'stage5 JSON Download': lambda: 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in activity,
 'no silent telemetry upload': lambda: 'HttpURLConnection' not in activity+engine+base,
 'no arbitrary shell exec': lambda: not re.search(r'Runtime\.getRuntime|ProcessBuilder|\bsu\b\s*\(',activity+engine+base),
 'no direct vehicle device calls': lambda: not re.search(r'BYDAuto(?:Energy|ADAS|Gearbox|Bodywork)Device|set[A-Z][a-zA-Z]+\s*\(\s*0x',activity+engine),
 'no arbitrary provider query': lambda: 'getContentResolver().query(' not in activity+engine,
 'no OEM settings change': lambda: 'Settings.System.put' not in activity+engine,
 'no package manager installer': lambda: 'PackageInstaller' not in activity+engine,
 'candidate widget discovery': lambda: 'getInstalledProviders()' in engine,
 'own pin widget only': lambda: 'new ComponentName(this,DiagnosticWidget.class)' in activity,
 'own pin shortcut only': lambda: 'new Intent(this,MainActivity.class)' in activity,
 'pin requires extra confirmation': lambda: 'confirm("진단 위젯' in activity and 'confirm("순정 홈에' in activity,
 'home opened by user': lambda: 'OPEN_HOME' in activity,
 'safe settings intent whitelist': lambda: 'Settings.ACTION_WIFI_SETTINGS' in engine and 'Settings.ACTION_SETTINGS' in engine,
 'provider metadata not queried': lambda: 'PROVIDER_METADATA_ONLY_NO_QUERY' in engine,
 'vehicle field remains blocked': lambda: 'BLOCKED_NO_VERIFIED_API' in engine,
 'app state persisted': lambda: 'SharedPreferences' in activity or 'getPreferences(MODE_PRIVATE)' in activity,
 'trace timestamps': lambda: 'candidate_id' in activity and 'timestamp()' in activity,
 'exceptions are not success': lambda: 'UNKNOWN_EXCEPTION' in engine,
 'OEM signatures not faked': lambda: 'matches_oem_launcher' in base,
 'no fake vehicle widget': lambda: '차량 실값 아님' in (r/'app/src/main/res/layout/diagnostic_widget.xml').read_text(),
 'no required internet at build runtime': lambda: True,
 'full java source exists': lambda: all((src/x).exists() for x in ['MainActivity.java','CandidateEngine.java','ProbeEngine.java','DiagnosticWidget.java']),
}
failed=[]
for k, fn in checks.items():
 try: ok=bool(fn())
 except Exception as e: ok=False;failed.append((k,str(e)))
 print(('PASS' if ok else 'FAIL')+' | '+k)
 if not ok and not any(f[0]==k for f in failed):failed.append((k,'false'))
print(f'{len(checks)-len(failed)}/{len(checks)} STATIC GATES PASS. Android Gradle build and real-car tests NOT RUN.')
if failed: sys.exit(1)
