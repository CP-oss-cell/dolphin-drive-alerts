package com.dolphin.goodlock.probe;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ShortcutManager;
import android.provider.Settings;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Discovery metadata only. Never invokes arbitrary OEM activities/providers/services. */
public final class CandidateEngine {
    private final Context context;
    private final PackageManager pm;
    private final ArrayList<JSONObject> items = new ArrayList<>();

    public CandidateEngine(Context c) { context = c; pm = c.getPackageManager(); }

    public static void put(JSONObject o, String key, Object value) {
        try { o.put(key, value); } catch (Exception ignored) { }
    }
    private JSONObject add(String kind, String label, String target, String hint) {
        JSONObject o = new JSONObject();
        put(o,"id", String.format(java.util.Locale.US,"C%03d",items.size()+1));
        put(o,"kind",kind); put(o,"label",label); put(o,"target",target);
        put(o,"hint",hint); put(o,"level","DISCOVERED_NOT_VERIFIED");
        items.add(o);
        return o;
    }

    public JSONArray discover() {
        items.clear();
        String homeName = "UNKNOWN";
        try {
            ResolveInfo r = pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY);
            if (r != null && r.activityInfo != null) homeName = r.activityInfo.packageName + "/" + r.activityInfo.name;
        } catch (Exception ignored) { }
        add("HOME", "기본 홈/순정 복귀", homeName, "선택 후 순정 홈 표시·독바 수동 확인");
        add("WIDGET_OWN", "진단 위젯 고정/실제 추가", context.getPackageName()+"/"+DiagnosticWidget.class.getName(), "사용자 승인 후만 위젯 추가 요청");
        add("SHORTCUT", "진단 바로가기 추가", context.getPackageName()+"/"+MainActivity.class.getName(), "사용자 승인 후만 자기 앱 바로가기 요청");
        String[][] safeActions = {
          {"일반 설정",Settings.ACTION_SETTINGS},
          {"Wi-Fi 설정",Settings.ACTION_WIFI_SETTINGS},
          {"디스플레이 설정",Settings.ACTION_DISPLAY_SETTINGS},
          {"소리 설정",Settings.ACTION_SOUND_SETTINGS},
          {"앱 설정",Settings.ACTION_APPLICATION_SETTINGS}
        };
        for (String[] spec:safeActions) add("SETTINGS",spec[0],spec[1],"공개 Android 설정 화면만 수동 열기");

        String[] known = {"com.android.launcher3", "com.android.systemui", "com.byd.mycar",
          "com.byd.widget.mediacenter", "com.byd.automap.provider", "com.dolphin.launcher.v1", "com.byd.dolphin.drivealerts"};
        for (String name:known) {
            add("PACKAGE", "패키지 · "+name, name,"구성요소 메타데이터만 열람");
            try {
                PackageInfo info = pm.getPackageInfo(name,PackageManager.GET_PROVIDERS);
                if (info.providers != null) for (ProviderInfo p:info.providers) {
                    if (p.exported && items.size()<65) add("PROVIDER", "Provider · "+p.name,name+"|"+p.name,
                     "공개 여부·읽기 권한·authority만 확인. Provider에 쿼리/호출 금지");
                }
            } catch (Exception ignored) { }
        }
        try {
            AppWidgetManager wm = AppWidgetManager.getInstance(context);
            List<AppWidgetProviderInfo> widgets = wm.getInstalledProviders();
            if (widgets != null) for (AppWidgetProviderInfo w: widgets) {
                String p = w.provider.getPackageName();
                if (items.size()<85 && (p.startsWith("com.byd") || p.equals("com.android.launcher3"))) {
                    add("WIDGET_OEM", "OEM 위젯 · "+w.provider.getShortClassName(),w.provider.flattenToString(),
                        "위젯 후보의 공개 정보만 확인. 앱이 임의 설치/바인딩하지 않음");
                }
            }
        } catch (Exception ignored) { }
        add("RESEARCH_ONLY", "CardBar/독바 직접 변경 권한", "OEM_CARDBAR", "외부 변경 허가 미입증 · 런타임 코드 실행 불가");
        add("RESEARCH_ONLY", "차량 SOC/TPMS/트립 신호", "OEM_VEHICLE", "SDK API/허용 권한 미검증 · 값 읽기 시도 안 함");
        add("RESEARCH_ONLY", "RRO/overlayable 정책", "OEM_RRO", "시스템 리소스 허용 정책을 일반 앱에서 확인할 수 없으면 UNKNOWN");
        JSONArray out = new JSONArray();
        for (JSONObject item:items) out.put(item);
        return out;
    }

    public String[] suggestedActions(JSONObject candidate) {
        String kind = candidate.optString("kind");
        if ("HOME".equals(kind)) return new String[]{"순정 홈 열기(돌아와 결과 기록)","기본 홈 다시 확인"};
        if ("WIDGET_OWN".equals(kind)) return new String[]{"기존 진단 위젯 등록 수 조회", "위젯 추가 요청(사용자 승인)","수동 추가 결과 기록"};
        if ("SHORTCUT".equals(kind)) return new String[]{"핀 바로가기 지원 확인", "진단 바로가기 추가 요청(사용자 승인)","수동 추가 결과 기록"};
        if ("WIDGET_OEM".equals(kind)) return new String[]{"OEM 위젯 메타데이터 재조회", "순정 홈에서 수동 추가 확인"};
        if ("SETTINGS".equals(kind)) return new String[]{"설정 화면 핸들러 재확인", "해당 공개 설정 화면 열기"};
        if ("PACKAGE".equals(kind)||"PROVIDER".equals(kind)) return new String[]{"공개 구성요소/권한 재확인", "순정 홈에서 해당 기능 수동 관찰"};
        return new String[]{"현재 구현 가능한 안전한 호출 없음(근거 기록)"};
    }

    public JSONObject inspect(JSONObject candidate) {
        JSONObject o = new JSONObject();
        String kind=candidate.optString("kind"), target=candidate.optString("target");
        put(o,"candidate_id",candidate.optString("id")); put(o,"kind",kind); put(o,"target",target);
        put(o,"status","UNKNOWN_NOT_REALCAR_VERIFIED");
        try {
            switch (kind) {
                case "HOME": {
                    ResolveInfo ri = pm.resolveActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),PackageManager.MATCH_DEFAULT_ONLY);
                    String now= ri==null||ri.activityInfo==null?"UNKNOWN":ri.activityInfo.packageName+"/"+ri.activityInfo.name;
                    put(o,"current_home",now); put(o,"unchanged_since_discovery",now.equals(target));
                    put(o,"status","HOME_INTENT_OBSERVED"); break;
                }
                case "WIDGET_OWN": {
                    AppWidgetManager m=AppWidgetManager.getInstance(context);
                    put(o,"pin_supported",m.isRequestPinAppWidgetSupported());
                    int[] ids=m.getAppWidgetIds(new ComponentName(context,DiagnosticWidget.class));
                    put(o,"bound_widget_ids_count", ids==null?-1:ids.length);
                    put(o,"status","PIN_API_CHECKED_NOT_UI_CONFIRMED"); break;
                }
                case "SHORTCUT": {
                    ShortcutManager sm=(ShortcutManager)context.getSystemService(Context.SHORTCUT_SERVICE);
                    put(o,"pin_supported",sm!=null && sm.isRequestPinShortcutSupported());
                    put(o,"status","SHORTCUT_API_CHECKED_NOT_UI_CONFIRMED"); break;
                }
                case "SETTINGS": {
                    ResolveInfo ri=pm.resolveActivity(new Intent(target), PackageManager.MATCH_DEFAULT_ONLY);
                    put(o,"handler",ri==null||ri.activityInfo==null?"NO_PUBLIC_HANDLER":ri.activityInfo.packageName+"/"+ri.activityInfo.name);
                    put(o,"status","PUBLIC_INTENT_HANDLER_CHECKED"); break;
                }
                case "PACKAGE": {
                    PackageInfo p=pm.getPackageInfo(target,PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_PROVIDERS);
                    put(o,"version",p.versionName);
                    JSONArray exported=new JSONArray(); int count=0;
                    if (p.activities!=null) for(ActivityInfo a:p.activities) if(a.exported){ count++; if(exported.length()<40)exported.put("ACTIVITY "+a.name+" permission="+a.permission); }
                    if (p.services!=null) for(ServiceInfo s:p.services) if(s.exported){ count++; if(exported.length()<40)exported.put("SERVICE "+s.name+" permission="+s.permission); }
                    if (p.providers!=null) for(ProviderInfo pr:p.providers) if(pr.exported){ count++; if(exported.length()<40)exported.put("PROVIDER "+pr.name+" authority="+pr.authority+" read="+pr.readPermission); }
                    put(o,"exported_count",count); put(o,"exported_sample",exported);
                    put(o,"status","DECLARATION_OBSERVED_ACCESS_NOT_PROVEN"); break;
                }
                case "PROVIDER": {
                    String[] bits=target.split("\\|",2);
                    PackageInfo p=pm.getPackageInfo(bits[0],PackageManager.GET_PROVIDERS);
                    boolean found=false;
                    if(p.providers!=null) for(ProviderInfo pr:p.providers) if(pr.name.equals(bits[1])) {
                        found=true; put(o,"authority",pr.authority); put(o,"exported",pr.exported);
                        put(o,"read_permission",pr.readPermission); put(o,"write_permission",pr.writePermission);
                        put(o,"grant_uri_permissions",pr.grantUriPermissions);
                    }
                    put(o,"found",found); put(o,"status",found?"PROVIDER_METADATA_ONLY_NO_QUERY":"UNKNOWN_MISSING_PROVIDER"); break;
                }
                case "WIDGET_OEM": {
                    boolean found=false;
                    for(AppWidgetProviderInfo w:AppWidgetManager.getInstance(context).getInstalledProviders())
                        if(target.equals(w.provider.flattenToString())){
                            found=true; put(o,"label",w.loadLabel(pm)); put(o,"min_width",w.minWidth);
                            put(o,"min_height",w.minHeight); put(o,"category",w.widgetCategory); break;
                        }
                    put(o,"found",found); put(o,"status",found?"OEM_WIDGET_DECLARED_PIN_NOT_ATTEMPTED":"UNKNOWN_OEM_WIDGET"); break;
                }
                default: {
                    put(o,"status","BLOCKED_NO_VERIFIED_API");
                    put(o,"note","정적 자료만 존재. 시스템 권한·차량 신호 임의 호출을 하지 않음");
                }
            }
        } catch(Exception e) {
            put(o,"status","UNKNOWN_EXCEPTION");put(o,"error",e.getClass().getSimpleName());
            put(o,"message",e.getMessage());
        }
        put(o,"meaning","API/manifest 확인이지 OEM UI 변경·신호 접근 성공 증거 아님");
        return o;
    }
}
