# Dolphin Good Lock Probe 0.2.0 — 원샷 설치·단계선택 연속 검사

## 목적과 현재 한계
- 대상: 한국형 BYD 돌핀 스탠다드, Android 10 / 글로벌 2602.
- 기존 0.1.0 읽기 전용 검사 앱을 확장한 **별도 진단 앱**, 패키지 `com.dolphin.goodlock.probe` 그대로. 앱 재설치 대신 후보를 반복 선택해서 후속 검사를 수행한다.
- ① 후보 일괄 탐색 → ② 사용자가 하나 선택/구성요소 메타데이터 조회 → ③ 후보별 안전한 후속 시험 선택/진행 → ④ 홈에서 관찰한 결과 저장 → ⑤ 한 JSON 파일로 통합 내보내기.
- **차량 신호/ECU 데이터는 탐색하거나 호출하지 않는다.** `RRO`, `CardBar`, `SOC/TPMS/트립`은 정적 근거는 있지만 외부 앱 권한·실차 데이터 API 확인 전이므로 `BLOCKED_NO_VERIFIED_API`로 표시한다. 시스템 앱/서비스의 임의 액티비티 실행/Provider 쿼리도 하지 않는다.
- 한 번에 자동 실행하는 것은 안전한 메타데이터 탐색뿐이다. HOME 이동·설정 화면 열기·진단 위젯/바로가기 생성 요청은 사용자 직접 선택/승인으로만 진행한다.
- 서명·공개 선언·pin API 응답은 **실제 독바 수정이나 위젯 배치 성공의 증명이 아님**. `REQUEST_ACCEPTED_NOT_ACTUAL_PIN_PROOF`는 추가가 됐다는 뜻이 아니다.

## 개발 구현
- Android API: 기본 HOME resolve, PackageManager 공개 component/provider 정보, 설치된 OEM widget provider 메타데이터, 공식 AppWidget/Shortcut pin 지원, 기기 해상도·빌드·권한/서명 비교, 공개 설정 Intent.
- 모든 결과는 `candidate_id` / `kind` / `target` / `stage` / `time` / `state` / `evidence` 형태로 기록. 기존의 실패/미확인도 삭제하지 않음. 변경 없이 후보 간 자유 이동. 앱을 닫았다 열어도 SharedPreferences에서 최근 기록 복구.
- 위험 API 금지: 차량 CAN/MCU 명령, root/su/ADB/shell, OEM PackageManager 업데이트, 외부 Provider query/insert/delete/call, 시스템 설정 직접 write, 오버레이, 런처 강제 기본값 변경, 인터넷 전송.
- manifest `uses-permission` 0개. 위젯 추가/바로가기 추가는 사용자가 승인하면 **순정 홈의 사용자 배치가 바뀔 수 있으므로 완전 무변경은 아님**. 원상복구는 홈에서 추가한 위젯/아이콘 제거 또는 앱 제거.

## 실차 사용 순서
1. 차량 안전 정차(P)/주차 브레이크 상태, 순정 홈 보존 후 `돌핀 Good Lock 검사` 실행.
2. **1단계 실행** → 공개 API/위젯/바로가기/OEM 메타데이터 후보 발견 개수 확인.
3. 후보 드롭다운에서 먼저 `기본 홈/순정 복귀` 선택 → **선택한 후보 분석** → 3단계에서 순정 홈 열기 → 실제 아이콘/독바/편집 가능한 화면이 나오는지 확인.
4. 앱으로 돌아와 4단계 판정/메모 저장. **후보를 `진단 위젯 고정/실제 추가`로 변경** → 2단계 → 3단계 `기존 위젯 등록 수 조회` → 이어서 `위젯 추가 요청(사용자 승인)` → 순정 홈에서 수락/거부 및 실제 배치 화면 확인. 원치 않으면 승인 팝업에서 취소.
5. 앱으로 돌아와 후보별 판정 저장. 같은 방식으로 `진단 바로가기` 및 `공개 Android 설정`, OEM widget/provider 후보를 추가 확인. OEM Provider는 **읽기 권한/authority 메타데이터만** 본다.
6. `CardBar/독바 직접 변경 권한`, `차량 SOC/TPMS/트립 신호`, `RRO` 후보는 현재 호출 불가능 상태가 표시되는지 확인. 강제 시험 버튼이 없는 것이 정상.
7. **5단계 전체 JSON Download 저장**. `Download/DolphinGoodLockGuided_날짜_시간.json`을 이 대화에 첨부. 순정 홈/위젯 목록/추가 화면 스크린샷도 함께 제공.
8. 실패 시 JSON 저장 버튼 아래 `전체 JSON 복사` 사용. JSON에는 패키지·빌드 지문 등이 포함될 수 있어 공개 GitHub에 올리지 말 것.

## 결과 표기
- `DISCOVERED_NOT_VERIFIED`: 구조 후보 발견, 런타임 호출 성공 아님.
- `DECLARATION_OBSERVED_ACCESS_NOT_PROVEN`: exported 선언 발견, 접근 가능성/안전성 미확정.
- `PIN_API_CHECKED_NOT_UI_CONFIRMED`: OS 인터페이스 조회 성공, 실제 위젯 표시 검증 전.
- `BLOCKED_NO_VERIFIED_API`: OEM/차량 read API 아직 없음. 차량 신호 송수신 절대 하지 않음.
- `USER_REPORTED_NOT_AUTOMATED_VERIFICATION`: 사용자가 관찰한 결과, 자동 판정과 구분.
- GitHub Actions의 Android Gradle 빌드가 성공하고 APK가 생성된 경우에만 설치 시험 가능.

## 빌드
- Gradle 8.7 / AGP 8.5.2 / Java 17 / compileSdk 34 / minSdk 29 / targetSdk 29.
- `DolphinGoodLockProbe-v0.2.0-source.zip`을 GitHub 저장소 루트에 업로드, `build-goodlock-probe-v02.yml`을 `.github/workflows/`에 업로드.
- `Actions → BYD Dolphin Good Lock Guided Probe v0.2 → Run workflow`.
- artifact ZIP에서 `DolphinGoodLockProbe-v0.2.0-debug.apk`를 추출하여 차량에 설치.
- 기존 v0.1.0과 동일 패키지이나 **기존 APK와 서명키가 다르면 덮어 설치가 실패**할 수 있음. 사용자가 기존 0.1.0을 설치한 적이 없다면 바로 설치. 서명 불일치라면 기존 앱 JSON 백업 후 제거, 새 버전 설치. 다른 앱 및 OEM Launcher3에는 영향 없음.
- 정적 검증과 APK 생성·실차 기능 성공은 구분한다.
