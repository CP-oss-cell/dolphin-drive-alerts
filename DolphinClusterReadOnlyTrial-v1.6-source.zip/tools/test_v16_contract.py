from pathlib import Path
import xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/dolphin/clusterprobe/StageWizardActivity.java').read_text()
adb=(p/'app/src/main/java/com/dolphin/clusterprobe/LocalAdb.java').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
provider=(p/'app/src/main/java/com/dolphin/clusterprobe/WizardZipProvider.java').read_text()
checks={
    'five simple buttons': all(x in s for x in ['로그 수집 시작','자동 테스트','수동 확인 항목','수집 종료 · ZIP 저장','ZIP 공유']),
    'auto runs existing allowlist': 'adb.queryReadOnly(cmd)' in s and 'throw new SecurityException' in adb,
    'auto queries process and panel clues': all(x in s for x in ['ps -A','/proc/','dumpsys display','SurfaceFlinger --list','cluster_theme1.rcc']),
    'ADB deny means blocked': 'ADB unavailable:' in s and 'read-only' in s,
    'manual step separate': 'showManual()' in s and 'user-confirmed' in s,
    'automatic Downloads for Android10': 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in s and 'Environment.DIRECTORY_DOWNLOADS' in s,
    'pending finished safely': 'IS_PENDING' in s and 'getContentResolver().delete(uri' in s,
    'zip content and sharing': all(x in s for x in ['summary.json','diagnostics.txt','events.jsonl','ACTION_SEND','FLAG_GRANT_READ_URI_PERMISSION']),
    'permissions unchanged': 'WRITE_SECURE_SETTINGS' not in manifest and 'android.permission.INTERNET' in manifest,
    'stable appId': "applicationId 'com.dolphin.clusterprobe.v15'" in (p/'app/build.gradle').read_text(),
    'no root or vehicle changes': all(x not in s for x in ['mount -o','setprop ','pm grant','am force-stop','sendAutoNaviStatus','WRITE_SETTINGS']),
    'zip provider': 'MODE_READ_ONLY' in provider and 'AutoCapture.zip' in provider,
}
try: ET.fromstring(manifest)
except ET.ParseError: raise AssertionError('manifest XML')
assert manifest.count('android.intent.action.MAIN')==1
assert manifest.index('android:name=".StageWizardActivity"')<manifest.index('android.intent.action.MAIN')
for name,ok in checks.items():print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values())
