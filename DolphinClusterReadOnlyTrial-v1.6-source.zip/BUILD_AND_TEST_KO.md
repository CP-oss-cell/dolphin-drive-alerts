# V1.6 계기판 자동 진단 — 설치 및 빌드

- 통합 배포 ZIP의 `DolphinClusterReadOnlyTrial-v1.6-source.zip`를 GitHub 저장소 루트에 업로드합니다. **다른 앱의 app/ 소스와 합치지 않습니다.**
- 통합 배포 ZIP의 `build-cluster-v16-auto-capture.yml`을 `.github/workflows/`에 업로드합니다.
- Actions > Build Dolphin Cluster V1.6 Automatic Read-only Capture > Run workflow.
- `DolphinCluster-V1.6-VEHICLE-APK` artifact에서 APK 확인 후 차량 설치.
- 기존 v1.5와 applicationId가 같고 versionCode 7입니다. 같은 서명키로 빌드해야 업데이트 가능합니다. 서명키가 없으면 다른 디버그 키로 빌드되어 업데이트가 거절될 수 있습니다.
- 앱 첫 화면의 다섯 버튼: 로그 수집 시작, 자동 테스트, 수동 확인 항목, 수집 종료 · ZIP 저장, ZIP 공유.
- 다운로드 경로: Android 10 이상 `Download/DolphinCluster_YYYYMMDD_HHMMSS.zip` (MediaStore).
- 안전: READ-ONLY. OEM writes/CAN/SPI/theme changes NOT IMPLEMENTED/NOT VERIFIED.
- 테스트: Python static safety & mock-A DB suite + Java CandidateParser. 실제 GitHub Actions 컴파일 및 실차 수행 여부는 별도 확인.
