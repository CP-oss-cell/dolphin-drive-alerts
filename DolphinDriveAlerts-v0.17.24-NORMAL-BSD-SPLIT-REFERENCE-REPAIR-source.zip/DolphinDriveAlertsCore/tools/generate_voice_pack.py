#!/usr/bin/env python3
"""Resumable, provenance-tracked Korean voice asset generation for manual CI builds.

An Edge 403 must never substitute gender-unverified Korean voice.
Preserve verified original Neural WAVs; build effects-only instead when unavailable.
"""
import argparse
from array import array
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
import wave

VOICES = {
    'male': {'voice': 'ko-KR-InJoonNeural', 'rate': '-4%', 'pitch': '-1Hz'},
    'female': {'voice': 'ko-KR-SunHiNeural', 'rate': '-3%', 'pitch': '+0Hz'},
}


def wav_info(path):
    with wave.open(str(path), 'rb') as w:
        return w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()


def valid_wav(path):
    if not path.is_file():
        return False
    try:
        ch, sw, sr, n = wav_info(path)
        if (ch, sw, sr) != (1, 2, 44100) or n < 2205:
            return False
        with wave.open(str(path), 'rb') as w:
            raw = w.readframes(min(n, sr * 6))
        samples = array('h')
        samples.frombytes(raw[:len(raw) - (len(raw) % 2)])
        return bool(samples) and max(abs(v) for v in samples) >= 100
    except (OSError, EOFError, wave.Error):
        return False


def edge_mp3(output, text, cfg):
    """Return success, do not flood Actions logs with repeated service stacktraces."""
    cmd = [sys.executable, '-m', 'edge_tts', '--voice', cfg['voice'],
           f"--rate={cfg['rate']}", f"--pitch={cfg['pitch']}",
           '--text', text, '--write-media', str(output)]
    for attempt in range(1, 3):
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=65)
            if proc.returncode == 0 and output.is_file() and output.stat().st_size > 300:
                return True
            msg = (proc.stderr or proc.stdout or 'unknown failure')[-260:].replace('\n', ' ')
        except (OSError, subprocess.TimeoutExpired) as exc:
            msg = str(exc)[-260:]
        print(f'Edge TTS unavailable attempt={attempt}/2: {msg}', file=sys.stderr)
        if output.exists():
            output.unlink()
        if attempt == 1:
            time.sleep(3)
    return False


def convert_wav(mp3, wav, style, provider):
    # Runtime contract: original Edge Korean Neural voices only; no gender-shifting.
    af=['silenceremove=start_periods=1:start_duration=0.02:start_threshold=-48dB:'
           'stop_periods=-1:stop_duration=0.06:stop_threshold=-48dB',
           'loudnorm=I=-16:LRA=6:TP=-1.5', 'apad=pad_dur=0.06']
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(mp3),
                    '-af', ','.join(af), '-ac', '1', '-ar', '44100',
                    '-c:a', 'pcm_s16le', str(wav)], check=True, timeout=65)
    if not valid_wav(wav):
        wav.unlink(missing_ok=True)
        raise RuntimeError(f'Generated audio is invalid: {wav}')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out', default='app/src/main/assets/voice')
    ap.add_argument('--manifest', default='tools/voice_prompts.json')
    ap.add_argument('--force', action='store_true')
    args=ap.parse_args()
    root=pathlib.Path(__file__).resolve().parents[1]
    out=(root/args.out).resolve()
    prompts=json.loads((root/args.manifest).read_text(encoding='utf-8'))
    if len(prompts)!=30 or len({x['file'] for x in prompts})!=30:
        raise SystemExit('Refusing build: expected 30 unique Korean phrases')
    if not shutil.which('ffmpeg'):
        raise SystemExit('ffmpeg is required')
    report_file=out/'voice_pack_manifest.generated.json'
    previous={}
    if report_file.is_file():
        try:
            for x in json.loads(report_file.read_text(encoding='utf-8')):
                previous[(x['style'], x['file'])]=x
        except (ValueError, OSError, KeyError):
            previous={}
    rows=[]
    edge_unavailable=False
    with tempfile.TemporaryDirectory(prefix='drivealerts-tts-') as tmp:
        tmp=pathlib.Path(tmp)
        for style,cfg in VOICES.items():
            (out/style).mkdir(parents=True,exist_ok=True)
            for i,item in enumerate(prompts,1):
                dest=out/style/item['file']
                old=previous.get((style,item['file']),{})
                sha=hashlib.sha256(dest.read_bytes()).hexdigest() if valid_wav(dest) else None
                should_skip=(not args.force and sha is not None and old.get('sha256')==sha
                             and old.get('text')==item['text'] and old.get('provider')=='edge-tts'
                             and old.get('voice')==cfg['voice'])
                if should_skip:
                    provider=old.get('provider','cached-unknown')
                    voice=old.get('voice','cached-unknown')
                    print('verified cache hit:',style,item['file'])
                else:
                    # Never accept a corrupt or stale cached WAV as success.
                    mp3=tmp/f'{style}-{i:02d}.mp3'
                    wav_tmp=tmp/f'{style}-{i:02d}.wav'
                    provider='edge-tts'
                    if edge_unavailable or not edge_mp3(mp3,item['text'],cfg):
                        edge_unavailable=True
                        raise RuntimeError(
                            'Neural voice service unavailable. Refusing gTTS gender imitation; '
                            'choose effects_only build or supply previously verified neural assets. '
                            'Never label pitch-shifted single-provider Korean voice as male/female.'
                        )
                    convert_wav(mp3,wav_tmp,style,provider)
                    shutil.move(str(wav_tmp),str(dest))
                    mp3.unlink(missing_ok=True)
                    voice=cfg['voice']
                    sha=hashlib.sha256(dest.read_bytes()).hexdigest()
                ch,sw,sr,n=wav_info(dest)
                rows.append({'style':style,'voice':voice,'provider':provider,'file':item['file'],
                             'text':item['text'],'sample_rate':sr,'channels':ch,
                             'frames':n,'sha256':sha})
    if len(rows)!=60:
        raise SystemExit(f'expected 60 valid WAV, got {len(rows)}')
    report_file.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    stats={provider:sum(x['provider']==provider for x in rows) for provider in sorted(set(x['provider'] for x in rows))}
    print('VOICE_PACK_PROVENANCE:',json.dumps(stats,ensure_ascii=False),flush=True)
    if stats.get('gtts-fallback'):
        raise SystemExit('Gender-unverified voice pack rejected')

    print(f'Generated/validated {len(rows)} WAV files -> {out}',flush=True)

if __name__=='__main__':
    main()
