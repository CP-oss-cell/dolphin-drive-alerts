# BYD Dolphin 순정 런처 자동 연구 v0.4.0 (BETA)

이 프로젝트는 2026-10-18까지의 Good Lock v0.3 실차 기록을 바탕으로 v0.3의 5단계 복잡한 후보 선택 메뉴를 **버튼 3개 + 필요한 수동 확인 3건**으로 교체한 독립 APK입니다. 순정 Launcher3를 유지합니다. 새 패키지 `com.dolphin.goodlock.probe.v04`는 v0.3와 별도 설치되므로 기존 v0.3 수집 기록을 삭제하지 않습니다. v0.3/v0.4 간 APK 업데이트가 아니며 과거 서명키와 호환된다는 보장은 없습니다.

## 차량에서 누를 버튼

1. 안전 정차/P 상태에서 `① 로그 수집 시작`.
2. `② 자동 검색 · 테스트 · 결과`: 기본 HOME, 화면, 노출된 순정 패키지/Provider/위젯/바로가기/설정 Intent, 접근 권한을 공개 Android API 메타데이터만으로 한 번에 확인. 중간에 메뉴/경로/JSON 플랜을 선택할 필요 없음.
3. `수동 확인이 필요한 항목만 보기`: 순정 홈의 아이콘 실제 표시, 위젯 수동 추가 메뉴, 독바 편집·이동·스크롤 가능 여부 등 3건. 사용자는 화면에서 실제 확인 후 결과만 선택. 자기 앱 바로가기 추가 요청은 별도 승인할 경우만 실행.
4. `③ 수집 종료 · 다운로드 ZIP · 공유`: Android `Download/DolphinOEMResearch_날짜.zip` 저장, 공유창 열기. 공유를 취소해도 ZIP은 다운로드에 남음.

## ZIP 구성

- `session.json`: 시작~종료 앱 자체 작업 기록, 기기/순정 런처 읽기 전용 메타데이터, 후보별 결과와 권한 게이트.
- `summary.txt`: 쉽게 읽는 핵심 정리 및 미검증 상태.
- `manual-results.json`: 사용자 직접 확인 3건 (각각 자동 검증과 분리).
- `SHA256SUMS.txt`: ZIP 내부 핵심 항목의 SHA-256 체크섬.

## 실차 연구에서 확정·미확정

- v0.3에서는 `WRITE_HOME`, `READ_CARD`, `WRITE_CARD`가 signature+privileged 보호로 일반 APK에 미허가, OEM 직접 수정 불가.
- `READ_HOME`은 normal 보호 등급이지만 기존 v0.3에서 요청하지 않았음. v0.4는 이 read 권한 **요청/보유 여부만 확인**합니다. 이 권한을 받더라도 HomeProvider 읽기 API/데이터가 성공함을 뜻하지 않습니다.
- OEM CardWindowService의 exported 선언, `get_home_info` 문자열은 호출 권한/무해성 보증이 아니므로 **바인딩/호출 금지**.
- Android 10 공개 API로 다른 앱의 logcat 전체 접근은 보통 불가합니다. 이 앱의 '로그'는 **우리 앱 이벤트 + 공개 시스템 메타데이터**입니다. 순정 독바 원본 DB나 CAN 정보는 들어있지 않습니다.
- 차량정보 SOC/타이어 공기압/트립 실값, OEM CardBar 실제 수정, HOME 위젯 배치 등은 `NOT_VERIFIED`로 유지합니다.

## 안전 및 운영

순정 HOME 교체·OEM 패키지 삭제/교체·리소스 패치·ADB/root·임의 ContentProvider query/call·차량 신호 송신·네트워크 전송/원격 수집 없음. 순정 카메라/공조/안전 UI 보호. UI가 비정상 동작하면 즉시 검사 중단. ZIP 안에는 기기 빌드 지문 등 장치 정보가 포함될 수 있으므로 공개 저장소에 업로드하지 마세요.

## 빌드/판정

`tools/verify_source.py` 및 Java 구문 파서로 소스 구조 점검. **이 로컬 제작 환경에는 Android SDK/Gradle이 없어 Android APK 빌드와 실차 동작은 미검증**. 함께 제공하는 GitHub Actions workflow로 Android 34 빌드 후 debug APK를 artifacts에서 받으세요. 오류 시 APK 생성 성공이라고 표시하지 않습니다.

근거: DA-002 및 `/Dolphin Drive Alerts/DA002_GOODLOCK_V03_REALCAR_PERMISSION_AUDIT_20261018_KO.md`, 기존 v0.3 소스팩; 공식 순정 펌웨어 연구 차수는 이 앱의 독립 배포 번호로 변경하지 않습니다.
