#!/usr/bin/env python3
"""Read-only source safety regression gates; no claims of Android compile or real-car verification."""
from pathlib import Path
import re,sys,zipfile,xml.etree.ElementTree as ET
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
p=r/'app/src/main/java/com/dolphin/goodlock/probe'
main=(p/'MainActivity.java').read_text()
access=(p/'AccessGateEngine.java').read_text()
base=(p/'ProbeEngine.java').read_text()
candidates=(p/'CandidateEngine.java').read_text()
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
gradle=(r/'app/build.gradle').read_text()
alljava='\n'.join(f.read_text() for f in p.glob('*.java'))
checks={
 'manifest XML valid':lambda:ET.fromstring(manifest) is not None,
 'new independent v04 app id':lambda:"applicationId 'com.dolphin.goodlock.probe.v04'" in gradle,
 'Android10 minSdk29':lambda:'minSdk 29' in gradle,
 'versionCode4':lambda:'versionCode 4' in gradle,
 'does not become HOME':lambda:'android.intent.category.HOME' not in manifest,
 'normal OEM HOME read declared':lambda:'com.android.launcher3.home.permission.READ_HOME' in manifest,
 'write HOME never requested':lambda:'WRITE_HOME' not in manifest,
 'OEM card permission never requested':lambda:'READ_CARD' not in manifest and 'WRITE_CARD' not in manifest,
 'no dangerous/unneeded permissions':lambda:manifest.count('<uses-permission')==1,
 'no internet permission':lambda:'android.permission.INTERNET' not in manifest,
 'no Android privileged writes':lambda:not re.search(r'android.permission.(WRITE_SECURE_SETTINGS|SYSTEM_ALERT_WINDOW|READ_LOGS)',manifest),
 'three top-level stages':lambda:all(x in main for x in ('로그 수집 시작','자동 검색 · 테스트 · 결과','수집 종료 · 다운로드 ZIP · 공유')),
 'manual only 3 tasks':lambda:'MANUAL_TITLES' in main and 'MANUAL_GUIDES' in main and 'showManualStep' in main,
 'automatic baseline and candidates':lambda:'base.runAll()' in main and 'engine.discover()' in main,
 'automatic inspect all candidates':lambda:'engine.inspect(candidate)' in main,
 'automatic OEM permission gates':lambda:'gates.run()' in main,
 'no arbitrary provider query/call':lambda:not re.search(r'getContentResolver\(\)\.(?:query|call|update)\s*\(',access+base+candidates),
 'provider intentionally not invoked':lambda:'No bind/start/send attempted.' in access,
 'no OEM provider query anywhere':lambda:not re.search(r'getContentResolver\(\)\.(?:query|call)\s*\(',alljava),
 'no vehicle signal writer':lambda:not re.search(r'BYDAuto(?:Energy|ADAS|Gearbox|Bodywork)Device|can\.write\s*\(|/dev/(?:can|spi)',alljava),
 'no root or shell':lambda:not re.search(r'Runtime\.getRuntime|ProcessBuilder|\bexec\s*\("su"',alljava),
 'no external network upload':lambda:not re.search(r'HttpURLConnection|Socket\s*\(|URL\s*\(',alljava),
 'no overlay':lambda:'SYSTEM_ALERT_WINDOW' not in manifest,
 'ZIP archive export':lambda:'ZipOutputStream' in main and 'ZIP 저장 완료' in main,
 'Downloads mediastore':lambda:'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in main and 'Environment.DIRECTORY_DOWNLOADS' in main,
 'ZIP pending lifecycle':lambda:'MediaStore.MediaColumns.IS_PENDING' in main,
 'Android ACTION_SEND share':lambda:'Intent.ACTION_SEND' in main and 'Intent.EXTRA_STREAM' in main and 'FLAG_GRANT_READ_URI_PERMISSION' in main,
 'events and manual results in ZIP':lambda:all(x in main for x in ('session.json','summary.txt','manual-results.json','SHA256SUMS.txt')),
 'manifest CRC image':lambda:(r/'app/src/main/res/drawable-nodpi/probe_icon.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n'),
 'manual shortcut user-approval':lambda:'askPinShortcut()' in main and '사용자 승인 필요' in main,
 'no OEM write success claim':lambda:'NOT_VERIFIED / NO_OEM_WRITE' in main,
 'manual evidence tagged as self-report':lambda:'USER_REPORTED_NOT_MACHINE_VERIFIED' in main,
 'system logcat not falsely claimed':lambda:'시스템 전체 logcat 아님' in main,
 'zip error handling':lambda:'EXPORT_ERROR' in main,
 'all Java source exists':lambda:all((p/x).is_file() for x in ['MainActivity.java','CandidateEngine.java','ProbeEngine.java','AccessGateEngine.java','DiagnosticWidget.java'])
}
failed=[]
for name,fun in checks.items():
 try:ok=bool(fun())
 except Exception as e:ok=False
 print(('PASS' if ok else 'FAIL')+' | '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} PASS static source gates. NOT an Android SDK build or car verification.')
if failed:sys.exit(1)
