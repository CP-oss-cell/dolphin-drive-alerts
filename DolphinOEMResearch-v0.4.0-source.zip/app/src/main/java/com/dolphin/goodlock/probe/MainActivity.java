package com.dolphin.goodlock.probe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Three-button, read-only OEM launcher investigation workflow. Does not replace HOME. */
public final class MainActivity extends Activity {
    private static final String PREF_REPORT = "last_auto_session_v04";
    private static final String[] MANUAL_TITLES = {
            "순정 홈 바로가기 표시", "순정 홈의 위젯 메뉴", "순정 독바 편집·이동·스크롤"};
    private static final String[] MANUAL_GUIDES = {
            "차량을 P에 놓고 순정 홈을 보세요. 진단 앱 바로가기가 실제 추가되는지 확인합니다. 필요하면 아래 '바로가기 추가 요청'을 누른 다음 순정 홈에서 승인하고, 이 앱으로 돌아와 결과를 기록하세요. 요청 접수는 실제 배치 성공과 다릅니다.",
            "순정 HOME의 빈 공간을 길게 눌러 위젯을 추가하는 메뉴가 있는지 확인하세요. 메뉴가 있으면 이 앱으로 돌아와 '직접 확인함'을 누르세요. 자동 위젯 고정 API가 미지원이어도 수동 메뉴가 있을 수 있습니다.",
            "순정 홈의 하단 독바를 살펴보고, 사용자 편집·앱 추가·아이콘 드래그·가로 스크롤 메뉴가 있는지만 확인하세요. 실제 배치를 바꾸거나 순정 파일을 교체하지 마세요."};
    private JSONObject report;
    private TextView stateText, resultText;
    private Button startBtn, autoBtn, manualBtn, stopBtn;
    private boolean busy = false;
    private int manualStep = 0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        try {
            String raw = getPreferences(MODE_PRIVATE).getString(PREF_REPORT, "");
            report = raw.isEmpty() ? fresh() : new JSONObject(raw);
        } catch (Exception ignored) { report = fresh(); }
        setupUi();
        render();
    }
    private static String at(){return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",Locale.KOREA).format(new Date());}
    private static void put(JSONObject j,String key,Object v){try{j.put(key,v);}catch(Exception ignored){}}
    private JSONObject fresh(){
        JSONObject j=new JSONObject();
        put(j,"schema","DolphinOEMResearch/0.4");
        put(j,"app_version","0.4.0-auto-one-click-beta");
        put(j,"state","NOT_STARTED");
        put(j,"safety","READ_ONLY_NO_ROOT_NO_ADB_NO_OEM_IPC_NO_OEM_WRITE_NO_VEHICLE_SIGNAL_NO_NETWORK");
        put(j,"events",new JSONArray());
        put(j,"manual",new JSONObject());
        return j;
    }
    private void persist(){getPreferences(MODE_PRIVATE).edit().putString(PREF_REPORT,report.toString()).apply();}
    private void event(String action,String status){
        JSONArray events=report.optJSONArray("events");if(events==null){events=new JSONArray();put(report,"events",events);}
        JSONObject x=new JSONObject();put(x,"time",at());put(x,"action",action);put(x,"status",status);events.put(x);
        persist();
    }
    private TextView text(LinearLayout col,String value,int sp,boolean header){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(Color.rgb(26,36,47));
        t.setPadding(12,10,12,10);if(header)t.setTypeface(null,Typeface.BOLD);
        col.addView(t,new LinearLayout.LayoutParams(-1,-2));return t;
    }
    private Button button(LinearLayout col,String label,View.OnClickListener listener){
        Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(17);b.setOnClickListener(listener);
        col.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;
    }
    private void setupUi(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(12,14,12,25);
        scroll.addView(col);setContentView(scroll);
        text(col,"돌핀 순정 런처 · 자동 연구",23,true);
        text(col,"순정 HOME 유지 | 차량을 안전하게 P에 정차한 상태에서 사용 | BETA",14,false);
        stateText=text(col,"준비",15,true);
        startBtn=button(col,"① 로그 수집 시작",v->startSession());
        autoBtn=button(col,"② 자동 검색 · 테스트 · 결과",v->runAutomaticTests());
        manualBtn=button(col,"수동 확인이 필요한 항목만 보기",v->showManualStep(0));
        stopBtn=button(col,"③ 수집 종료 · 다운로드 ZIP · 공유",v->stopZipShare());
        resultText=text(col,"자동 결과와 쉬운 설명이 이곳에 표시됩니다.",14,false);
        text(col,"자동 검색은 공개 Android API 및 순정 구성요소의 허용된 메타데이터만 확인합니다. 차량의 실제 독바 변경이나 SOC·TPMS 값 수신은 검증 전까지 성공으로 표시하지 않습니다.",12,false);
    }
    private void render(){
        String state=report.optString("state","NOT_STARTED");
        boolean collecting="COLLECTING".equals(state)||"AUTO_FINISHED".equals(state);
        stateText.setText("현재 상태: "+("NOT_STARTED".equals(state)?"수집 전":"COLLECTING".equals(state)?"수집 중":"AUTO_FINISHED".equals(state)?"자동 검사 완료":"종료·저장 완료"));
        startBtn.setEnabled(!busy&&!collecting);
        autoBtn.setEnabled(!busy&&collecting);
        manualBtn.setEnabled(!busy&&"AUTO_FINISHED".equals(state));
        stopBtn.setEnabled(!busy&&collecting);
        JSONObject tally=report.optJSONObject("automatic_summary");
        if(tally!=null){
            String s="자동 검색: "+tally.optInt("inspected_candidates",0)+"개 후보 검사\n"+
                "접근·권한 검사: "+tally.optInt("access_gates",0)+"종\n"+
                "검사 오류: "+tally.optInt("errors",0)+"건\n"+
                "순정 UI 변경 성공: 검증되지 않음 (자동으로 변경하지 않음)\n"+
                "사용자가 직접 볼 것: 3개";
            resultText.setText(s);
        }else resultText.setText("① 로그 수집 시작 → ② 자동 검색 → 필요한 화면만 직접 확인 → ③ ZIP 공유");
    }
    private void startSession(){
        if(busy)return;
        String current=report.optString("state");
        if("COLLECTING".equals(current)||"AUTO_FINISHED".equals(current)){
            stateText.setText("이전 수집을 이어갑니다. 먼저 수집을 종료하고 ZIP으로 보관하세요.");return;
        }
        report=fresh();put(report,"started",at());put(report,"state","COLLECTING");
        event("START","APP_OWNED_LOGGING_STARTED");render();
    }
    private void runAutomaticTests(){
        if(busy||"NOT_STARTED".equals(report.optString("state")))return;
        busy=true;render();stateText.setText("자동 검사 중: 공개 정보와 접근 권한 확인...");
        new Thread(()->{
            JSONObject result=new JSONObject(),summary=new JSONObject();
            int errors=0,visited=0,gateCount=0;
            try{
                ProbeEngine base=new ProbeEngine(getApplicationContext());
                JSONObject baseline=base.runAll();put(result,"baseline",baseline);
                AccessGateEngine gates=new AccessGateEngine(getApplicationContext());
                JSONObject access=gates.run();put(result,"access_gates",access);
                gateCount=access.optJSONArray("steps_executed_in_order")==null?0:access.optJSONArray("steps_executed_in_order").length();
                CandidateEngine engine=new CandidateEngine(getApplicationContext());
                JSONArray candidates=engine.discover();put(result,"discovered",candidates);
                JSONArray checked=new JSONArray();
                HashSet<String> seen=new HashSet<>();
                for(int i=0;i<candidates.length();i++){
                    JSONObject candidate=candidates.optJSONObject(i);
                    if(candidate==null)continue;
                    String id=candidate.optString("id");
                    if(!seen.add(id))continue;
                    JSONObject inspected;
                    try{inspected=engine.inspect(candidate);}catch(Exception e){
                        inspected=new JSONObject();put(inspected,"status","UNKNOWN_ERROR");
                        put(inspected,"error_class",e.getClass().getSimpleName());errors++;
                    }
                    JSONObject item=new JSONObject();put(item,"candidate",candidate);put(item,"result",inspected);
                    checked.put(item);visited++;
                    if(inspected.optString("status").startsWith("UNKNOWN_ERROR"))errors++;
                }
                put(result,"inspected",checked);
                put(result,"meaning","Read-only API metadata, not proof of OEM widget placement or modification rights.");
            }catch(Throwable e){
                errors++;put(result,"fatal","UNKNOWN_ERROR_"+e.getClass().getSimpleName());
            }
            put(summary,"inspected_candidates",visited);put(summary,"access_gates",gateCount);
            put(summary,"errors",errors);put(summary,"realcar_ui_changes_verified",false);
            put(summary,"manual_visual_tasks",MANUAL_TITLES.length);
            final JSONObject rr=result,ss=summary;
            runOnUiThread(()->{
                busy=false;put(report,"automatic",rr);put(report,"automatic_summary",ss);
                put(report,"auto_completed_at",at());put(report,"state","AUTO_FINISHED");
                event("AUTO_TEST","READ_ONLY_METADATA_TESTS_COMPLETE_REALCAR_EDIT_UNVERIFIED");
                render();stateText.setText("자동 검사 완료. '수동 확인이 필요한 항목만 보기'를 누르세요.");
            });
        },"OEM-read-only-auto-probe").start();
    }
    private void showManualStep(int i){
        if(i>=MANUAL_TITLES.length){
            new AlertDialog.Builder(this).setTitle("수동 확인 종료")
                .setMessage("필요한 확인을 기록했습니다. '수집 종료'를 누르면 자동 결과와 수동 기록을 ZIP 한 개로 저장할 수 있습니다.")
                .setPositiveButton("확인",(d,w)->{}).show();return;
        }
        manualStep=i;
        String note="("+(i+1)+"/3) "+MANUAL_TITLES[i]+"\n\n"+MANUAL_GUIDES[i];
        AlertDialog.Builder dialog=new AlertDialog.Builder(this).setTitle("차량에서 직접 확인").setMessage(note);
        if(i==0){dialog.setNeutralButton("바로가기 추가 요청",(d,w)->askPinShortcut());}
        dialog.setPositiveButton("화면에서 확인함",(d,w)->recordManual(i,"USER_REPORTED_VISIBLE"));
        dialog.setNegativeButton("메뉴 없음·미작동",(d,w)->recordManual(i,"USER_REPORTED_NOT_AVAILABLE"));
        dialog.show();
    }
    private void askPinShortcut(){
        new AlertDialog.Builder(this).setTitle("사용자 승인 필요")
            .setMessage("우리 진단 앱의 바로가기만 순정 홈에 추가하도록 요청합니다. 실제 표시 여부는 순정 홈에서 직접 확인해야 합니다. 차량 설정·기본 HOME은 변경하지 않습니다.")
            .setPositiveButton("요청",(d,w)->{
                String result="UNKNOWN";
                try{
                    ShortcutManager sm=(ShortcutManager)getSystemService(Context.SHORTCUT_SERVICE);
                    if(sm==null||!sm.isRequestPinShortcutSupported())result="PIN_SHORTCUT_UNSUPPORTED";
                    else{
                        ShortcutInfo s=new ShortcutInfo.Builder(this,"goodlock_probe_diagnostic")
                            .setShortLabel("돌핀 런처 검사")
                            .setIcon(Icon.createWithResource(this,android.R.drawable.ic_menu_info_details))
                            .setIntent(new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW)).build();
                        result=sm.requestPinShortcut(s,null)?"REQUEST_ACCEPTED_NOT_VISIBLE_PROOF":"REQUEST_REJECTED";
                    }
                }catch(Exception e){result="UNKNOWN_"+e.getClass().getSimpleName();}
                event("MANUAL_SHORTCUT_REQUEST",result);
                stateText.setText("바로가기 요청: "+result+" · 홈에서 확인 후 수동 확인 메뉴로 돌아오세요.");
            }).setNegativeButton("취소",(d,w)->{}).show();
    }
    private void recordManual(int step,String answer){
        JSONObject manual=report.optJSONObject("manual");if(manual==null){manual=new JSONObject();put(report,"manual",manual);}
        JSONObject value=new JSONObject();put(value,"title",MANUAL_TITLES[step]);
        put(value,"at",at());put(value,"result",answer);put(value,"evidence_grade","USER_REPORTED_NOT_MACHINE_VERIFIED");
        put(manual,"M"+(step+1),value);event("MANUAL_M"+(step+1),answer);
        showManualStep(step+1);
    }
    private static byte[] utf(String s){return s.getBytes(StandardCharsets.UTF_8);}
    private static String sha256(byte[] data)throws Exception{
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder out=new StringBuilder();for(byte b:digest)out.append(String.format(Locale.US,"%02x",b&255));return out.toString();
    }
    private static void entry(ZipOutputStream zip,String name,byte[] data)throws Exception{
        ZipEntry e=new ZipEntry(name);zip.putNextEntry(e);zip.write(data);zip.closeEntry();
    }
    private String summaryText(){
        JSONObject a=report.optJSONObject("automatic_summary");JSONObject m=report.optJSONObject("manual");
        return "BYD 돌핀 순정 런처 자동 연구\n"+
            "자동 조사: "+(a==null?"미실행":a.optInt("inspected_candidates")+"개 후보")+"\n"+
            "읽기/접근 게이트: "+(a==null?0:a.optInt("access_gates"))+"개\n"+
            "자동 오류: "+(a==null?0:a.optInt("errors"))+"개\n"+
            "수동 확인 수: "+(m==null?0:m.length())+"/3\n"+
            "순정 홈/독바 직접 변경: NOT_VERIFIED / NO_OEM_WRITE\n"+
            "SOC/TPMS/Trip 실차 값: NOT_PROBED\n"+
            "기록 종류: 앱 자체 이벤트 및 공개 Android 메타데이터. 시스템 전체 logcat 아님.\n"+
            "주의: 사용자가 직접 확인했다고 신고한 결과는 자동 실차 검증과 분리함.\n";
    }
    private void stopZipShare(){
        if(busy)return;
        String status=report.optString("state");
        if(!"COLLECTING".equals(status)&&!"AUTO_FINISHED".equals(status))return;
        put(report,"ended",at());put(report,"state","ENDED");event("STOP","APP_LOGGING_STOPPED_EXPORT_REQUESTED");
        String name="DolphinOEMResearch_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".zip";
        Uri dest=null;
        try{
            byte[] session=utf(report.toString(2));
            byte[] overview=utf(summaryText());
            JSONObject m=report.optJSONObject("manual");byte[] manual=utf(m==null?"{}":m.toString(2));
            String hashes=sha256(session)+"  session.json\n"+sha256(overview)+"  summary.txt\n"+sha256(manual)+"  manual-results.json\n";
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(ZipOutputStream zip=new ZipOutputStream(bytes,StandardCharsets.UTF_8)){
                entry(zip,"session.json",session);
                entry(zip,"summary.txt",overview);
                entry(zip,"manual-results.json",manual);
                entry(zip,"SHA256SUMS.txt",utf(hashes));
            }
            ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
            values.put(MediaStore.MediaColumns.MIME_TYPE,"application/zip");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/");
            values.put(MediaStore.MediaColumns.IS_PENDING,1);
            dest=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(dest==null)throw new IllegalStateException("DOWNLOAD_INSERT_NULL");
            try(OutputStream out=getContentResolver().openOutputStream(dest)){
                if(out==null)throw new IllegalStateException("DOWNLOAD_STREAM_NULL");
                out.write(bytes.toByteArray());
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(dest,ready,null,null);
            render();
            stateText.setText("다운로드 폴더에 ZIP 저장 완료: "+name);
            Intent send=new Intent(Intent.ACTION_SEND).setType("application/zip")
                .putExtra(Intent.EXTRA_STREAM,dest).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(ClipData.newRawUri("Dolphin OEM Research ZIP",dest));
            try{startActivity(Intent.createChooser(send,"ZIP 파일 공유하기"));}
            catch(Exception e){stateText.setText("ZIP 저장 완료. 공유창을 열지 못했습니다. 다운로드 폴더에서 공유하세요.");}
        }catch(Exception e){
            if(dest!=null)try{getContentResolver().delete(dest,null,null);}catch(Exception ignored){}
            put(report,"state",status);event("EXPORT_ERROR",e.getClass().getSimpleName());render();
            new AlertDialog.Builder(this).setTitle("ZIP 저장 실패").setMessage(
                "저장 과정에서 오류가 발생했습니다: "+e.getClass().getSimpleName()+
                "\n수집 자료는 앱 내부에 유지됩니다. 수집 종료 버튼으로 다시 시도하세요.")
                .setPositiveButton("확인",(d,w)->{}).show();
        }
    }
}
