package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.AlertEvent

/**
 * User's Korean Dolphin three-position drive-mode hypothesis (2026-10-08):
 * 0 ECO, 1 NORMAL, 2 SPORT. This pertains ONLY to ENERGY_OPERATION_MODE,
 * not ADAS_ACC_MODE / INSTRUMENT drive interface / regeneration / snow mode.
 * Values 1 and 2 were seen in the user's 19:59 event log (0x2120000e),
 * but 0 has not yet been observed in that recording.
 */
internal object DriveModeDecoder {
    fun fromEnergyOperationMode(raw: Int): AlertEvent? = when (raw) {
        0 -> AlertEvent.DRIVE_ECO
        1 -> AlertEvent.DRIVE_NORMAL
        2 -> AlertEvent.DRIVE_SPORT
        else -> null
    }
}
