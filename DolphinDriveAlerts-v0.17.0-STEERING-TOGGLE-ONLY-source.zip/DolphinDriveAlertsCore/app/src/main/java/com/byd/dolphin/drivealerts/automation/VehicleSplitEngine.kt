package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/** Independent best-effort system split implementation. OEM stack commands require local ADB. */
object VehicleSplitEngine {
    data class Result(val success: Boolean, val message: String)
    private fun shell(c: Context, command: String): NativeAdbClient.ShellResult =
        if (command.startsWith("wm size") || command.startsWith("am stack list") || command.startsWith("dumpsys "))
            AuthorizedAdbRuntime.read(c,command,timeoutMs=4_000).result
        else AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=4_000).result

    fun launch(c: Context, profile: SplitProfile): Result {
        val one = AppSelection.safeComponent(c,profile.firstPackage) ?: return Result(false,"첫 번째 앱을 찾을 수 없음")
        val two = AppSelection.safeComponent(c,profile.secondPackage) ?: return Result(false,"두 번째 앱을 찾을 수 없음")
        if (one == two) return Result(false,"서로 다른 앱 2개를 선택해야 합니다")
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY)
            return Result(false,"승인된 ADB 미연결: ${adb.state}; Dolphin Drive ADB 연결 및 권한을 확인하세요")
        // Matches the basic Android/DiLink windowing modes found in the reference investigation.
        // Fail rather than claim that an ordinary pair of fullscreen launches was a split.
        val first = shell(c,"am start --windowingMode 3 -n $one")
        if (!first.success) return Result(false,"PRIMARY: ${first.message}")
        val second = shell(c,"am start --windowingMode 4 -n $two")
        if (!second.success) return Result(false,"SECONDARY: ${second.message}")
        // OEM may place our own task into secondary instead of the requested YouTube task.
        // Do not register recovery or report success unless BOTH selected packages are visible.
        Thread.sleep(500L)
        val ownership = shell(c, "dumpsys activity activities")
        if (!ownership.success || !ownership.output.contains(profile.firstPackage) || !ownership.output.contains(profile.secondPackage)) {
            CoreLog.w("SPLIT", "SPLIT_TARGET_MISMATCH first=${profile.firstPackage} second=${profile.secondPackage} " +
                "readable=${ownership.success} firstSeen=${ownership.output.contains(profile.firstPackage)} " +
                "secondSeen=${ownership.output.contains(profile.secondPackage)}")
            return Result(false, "분할 대상 오류: ${profile.firstPackage} / ${profile.secondPackage} 양쪽 실행 확인 실패. 분할 스택을 점검하세요")
        }
        val state = splitState(c)
        if (!state.success) return Result(false,"분할 상태 조회 불가: ${state.message}")
        // Do not resize if shell reports no docked stack (could resize unrelated foreground UI).
        if (!state.output.contains("docked",true) && !state.output.contains("split-screen",true)
            && !Regex("(?i)windowingMode[=:]\\s*3").containsMatchIn(state.output))
            return Result(false,"분할 스택 확인 실패 (am stack list 결과 필요)")
        val ratio = applyRatio(c,profile.primaryPercent)
        if (!ratio.success) return ratio
        FeatureProfiles.markSplit(c,profile.id)
        CoreLog.i("SPLIT", "profile=${profile.id} ratio=${profile.primaryPercent} state=launched")
        return Result(true,"분할 실행 및 비율 명령 전송; 화면 비율은 실차에서 최종 확인")
    }

    fun applyRatio(c: Context, pct: Int): Result {
        val size = shell(c,"wm size")
        if (!size.success) return Result(false,"화면 크기 조회 실패: ${size.message}")
        val match = Regex("(\\d+)x(\\d+)").findAll(size.output).lastOrNull()
            ?: return Result(false,"디스플레이 크기를 해석하지 못함")
        val w = match.groupValues[1].toIntOrNull() ?: return Result(false,"폭 파싱 실패")
        val h = match.groupValues[2].toIntOrNull() ?: return Result(false,"높이 파싱 실패")
        val split = pct.coerceIn(10,90)
        // Automotive head unit normally horizontal, but support portrait split too.
        val boundary = if (w >= h) (w*split/100) else (h*split/100)
        val rectangle = if (w >= h) "0 0 $boundary $h" else "0 0 $w $boundary"
        val command = "am stack resize-docked-stack $rectangle"
        val result = shell(c, command)
        if (!result.success) return Result(false,"비율 명령 거부: ${result.message}")
        val post = splitState(c)
        if (!post.success) return Result(false,"비율 적용 후 상태 확인 실패")
        // AutoSplit reference: verify actual windowing mode after resize before reporting success.
        val splitPresent = post.output.contains("docked", true) || post.output.contains("split-screen", true) ||
            Regex("""(?i)windowingMode[=:]\s*[34]""").containsMatchIn(post.output)
        CoreLog.i("SPLIT", "requested=$split screen=${w}x$h boundary=$boundary " +
            "splitPresent=$splitPresent stack=${post.output.take(200)}")
        if (!splitPresent) return Result(false,"비율 적용 후 분할 스택 유실; 다시 분할 실행 필요")
        // An `am stack` shell exit=0 does not guarantee the 20:80 bounds actually changed.
        // If the OEM doesn't expose bounds, FAIL CLOSED instead of a misleading 20:80 success.
        // OEM-specific bounds parsing is not yet reliable. Never assert 20:80 merely
        // because the shell accepted resize. The reference app remains the preferred path.
        if (split != 50) {
            CoreLog.w("SPLIT", "SPLIT_RATIO_UNVERIFIED requested=$split cmd=${result.success}")
            return Result(false, "${split}:${100-split} 비율 명령 전송, 실제 픽셀 비율 확인 불가; OEM 분할 상태 조회 필요")
        }
        return Result(true,"50:50 분할 스택 존재 확인 (대상 앱과 픽셀 비율은 독립 검증 필요)")
    }

    /** Older DiLink exposes `am stack list`; newer Android may require dumpsys. */
    private fun splitState(c: Context): NativeAdbClient.ShellResult {
        val legacy = shell(c, "am stack list")
        if (legacy.success && (legacy.output.contains("docked",true) ||
            legacy.output.contains("split-screen",true) || legacy.output.contains("windowingMode",true))) return legacy
        val fallback = shell(c, "dumpsys activity activities")
        if (fallback.success) CoreLog.i("SPLIT", "using dumpsys activity split state fallback")
        return if (fallback.success) fallback else legacy
    }

    fun screenToken(c: Context): String? {
        val s = shell(c,"dumpsys activity activities")
        if (!s.success) return null
        val top = s.output.lineSequence().filter {
            it.contains("topResumedActivity",true) || it.contains("mResumedActivity",true) || it.contains("ResumedActivity",true)
        }.lastOrNull() ?: return null
        return top.take(350)
    }
}
