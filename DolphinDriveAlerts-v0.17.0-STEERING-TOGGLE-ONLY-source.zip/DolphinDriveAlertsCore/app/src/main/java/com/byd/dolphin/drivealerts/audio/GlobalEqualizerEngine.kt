package com.byd.dolphin.drivealerts.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.media.audiofx.Equalizer
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap

/**
 * Bass/Mid/Treble and user-selected sound presets only.
 * EVSound reference used only for effect ownership, session lifecycle and readback.
 * No speed compensation (SVC), simulated engine audio, or other-UID speaker routing.
 * Session 0 is a legacy, deprecated compatibility path; the platform may reject it.
 */
class GlobalEqualizerEngine(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val sessions = ConcurrentHashMap<Int, SessionFx>()
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val data = intent ?: return
            val session = data.getIntExtra(EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            val pkg = data.getStringExtra(EXTRA_PACKAGE_NAME).orEmpty()
            when (data.action) {
                ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "session-open id=$session pkg=$pkg")
                    // Do not apply both session 0 and app session effects to the same stream.
                    sessions.remove(0)?.close()
                    attach(session)
                    refresh()
                }
                ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "session-close id=$session pkg=$pkg")
                    sessions.remove(session)?.close()
                    // Never fall back to deprecated global session 0 on a vehicle OEM DSP.
                    refresh()
                }
            }
        }
    }

    fun start() {
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                addAction(ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
            }
            runCatching { app.registerReceiver(receiver, filter) }
                .onSuccess { receiverRegistered = true }
                .onFailure { CoreLog.w("EQ", "session receiver unavailable: ${it.message}", it) }
        }
        refresh()
    }

    fun refresh() {
        val settings = EqPreferences.read(app)
        // Active session required; never create global session 0.
        val results = sessions.values.sortedBy { it.sessionId }.map { fx ->
            fx.sessionId to runCatching { fx.apply(settings) }
                .getOrElse { "ERROR:${it.javaClass.simpleName}" }
        }
        val operational = results.any { it.second.contains("eq=ON") }
        val status = when {
            !settings.enabled -> "EQ 사용 안 함 · 기존 음향 복원"
            operational -> "EQ API 적용/readback 확인(실제 청감 미확인): ${results.joinToString { "세션 ${it.first} ${it.second}" }}"
            else -> if (results.isEmpty()) "안전모드: 대상 오디오 세션 없음 (순정 음향 보호)" else "EQ 적용 미확인: ${results.joinToString { "세션 ${it.first} ${it.second}" }}"
        }
        app.getSharedPreferences(STATUS_PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS_KEY, status).apply()
        CoreLog.i("EQ", "enabled=${settings.enabled} bass=${settings.bass} mid=${settings.mid} " +
            "treble=${settings.treble} focus=${settings.soundFocus} $status")
    }

    private fun attach(sessionId: Int) {
        if (sessionId <= 0 || sessions.containsKey(sessionId)) return
        val fx = SessionFx(sessionId)
        sessions[sessionId] = fx
        CoreLog.i("EQ", "attached session=$sessionId")
    }

    override fun close() {
        if (receiverRegistered) {
            runCatching { app.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
        sessions.values.forEach { runCatching { it.close() } }
        sessions.clear()
    }

    /** Conservative, controllable 3-band trim: no deprecated global session or stacked DSP. */
    private class SessionFx(val sessionId: Int) : Closeable {
        private val equalizer: Equalizer? = runCatching { Equalizer(0, sessionId) }.getOrNull()
        private val eqEnabled: Boolean? = runCatching { equalizer?.enabled }.getOrNull()
        private val eqBands: List<Short>? = runCatching {
            equalizer?.let { e -> (0 until e.numberOfBands.toInt()).map { e.getBandLevel(it.toShort()) } }
        }.getOrNull()
        private fun owned(): Boolean = runCatching { equalizer?.hasControl() == true }.getOrDefault(false)
        private fun restore() {
            if (!owned()) return
            runCatching {
                eqBands?.forEachIndexed { i, value -> equalizer?.setBandLevel(i.toShort(), value) }
                if (eqEnabled != null) equalizer?.enabled = eqEnabled
            }.onFailure { CoreLog.w("EQ", "restore failed session=$sessionId: ${it.message}", it) }
        }
        fun apply(s: EqSettings): String {
            if (!s.enabled) { restore(); return "OFF/RESTORED" }
            if (!owned()) return "eq=NO_CONTROL session=$sessionId"
            val status = runCatching {
                val eq = requireNotNull(equalizer)
                val r = eq.bandLevelRange
                val lo = r[0].toInt(); val hi = r[1].toInt()
                var mismatched = 0
                for (b in 0 until eq.numberOfBands.toInt()) {
                    val band = b.toShort()
                    val hz = eq.getCenterFreq(band) / 1000
                    val trim = when { hz < 250 -> s.bass; hz < 4000 -> s.mid; else -> s.treble }
                    // User slider +/-10 maps to +/-300mB (= +/-3dB), never unrestricted OEM output gain.
                    val target = (trim.coerceIn(-10, 10) * 30).coerceIn(lo,hi).toShort()
                    eq.setBandLevel(band,target)
                    if (eq.getBandLevel(band) != target) mismatched++
                }
                val code = eq.setEnabled(true)
                if (code == AudioEffect.SUCCESS && eq.enabled && mismatched == 0) "ON"
                else "READBACK_FAIL(code=$code,mismatch=$mismatched)"
            }.getOrElse { "ERROR:${it.javaClass.simpleName}" }
            // 360/Surround/Cinema need verified BYD car DSP, NOT generic Android Virtualizer.
            return "eq=$status safeMode=THREE_BAND_ONLY 360=UNSUPPORTED_OEM_DSP SoundFocus=UNSUPPORTED_OEM_DSP"
        }
        override fun close() {
            restore()
            runCatching { equalizer?.release() }
        }
    }

    companion object {
        private const val STATUS_PREF = "audio_tuning_runtime"
        private const val STATUS_KEY = "eq_last_state"
        fun readStatus(context: Context): String = context.getSharedPreferences(
            STATUS_PREF, Context.MODE_PRIVATE).getString(STATUS_KEY, "EQ 적용 상태 확인 전").orEmpty()

        private const val ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION"
        private const val ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION"
        private const val EXTRA_AUDIO_SESSION = "android.media.extra.AUDIO_SESSION"
        private const val EXTRA_PACKAGE_NAME = "android.media.extra.PACKAGE_NAME"
    }
}
