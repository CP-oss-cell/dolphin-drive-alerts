"""Static assertions about the V2.3 source; NOT an Android compilation or real-car test."""
from pathlib import Path
import xml.etree.ElementTree as ET
import sys
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/dolphin/insidelightprobe/MainActivity.java').read_text()
provider=(root/'app/src/main/java/com/dolphin/insidelightprobe/LogShareProvider.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
gradle=(root/'app/build.gradle').read_text()
yaml=(root/'.github/workflows/build-apk.yml').read_text()
ns='{http://schemas.android.com/apk/res/android}'
x=ET.fromstring(manifest)
providers=x.findall('.//provider')
checks={
    'Manifest parses': x.tag=='manifest',
    'Existing session retained': 'dolphin_wizard_v2' in s and 'restore()' in s and 'persist()' in s,
    'Four steps': all(f'step=={n}' in s for n in (1,2,3)),
    'Dynamic OEM method listing': 'methodCandidates.add(signature(m))' in s,
    'Safe read-only method allowlist': 'READ_GETTERS' in s and 'getInsideLightDoorState' in s,
    'OEM getters actually invoked': 'getter.invoke(owner)' in s and 'GETTER_VALUE_RETURNED' in s,
    'OEM getter permission exception detected': 'GETTER_PERMISSION_DENIED' in s and 'SecurityException' in s,
    'OEM one-click multi getter read': 'batchReadLightGetters' in s and 'BATCH_GETTER' in s,
    'OEM control runs off UI thread': 'dolphin-single-oem-control' in s and 'CONTROL_STILL_PENDING' in s,
    'OEM control duplicates locked': 'if(busy || writePending || !permission(PERM_COMMON)' in s,
    'Evidence consecutive dedup': 'previous.optString("phase")' in s and 'SELECT_METHOD' in s,
    'OEM async 8-second watchdog': 'READ_TIMEOUT' in s and 'postDelayed' in s,
    'No arbitrary setter calls': 'setInsideLightDoorState(' not in s and 'getMethod("set' not in s,
    'OEM write single known API only': 'getMethod("turnOffInsideLight",int.class)' in s,
    'OEM write permission double gate': 'permission(PERM_COMMON) || !permission(PERM_SET)' in s,
    'OEM write needs physical confirmation': 'PHYSICAL_CHANGED' in s and 'PHYSICAL_UNCHANGED' in s,
    'OEM UI package overlay differentiation': 'RESOURCE_OVERLAY' in s and 'CODE_CANDIDATE' in s,
    'OEM permission metadata actual': 'getPermissionInfo(perm,0)' in s and 'protectionLevel' in s,
    'CarSettings value read only': 'insight_light_online' in s and 'getInt' in s and 'setInt' not in s,
    'isCanFd remains UNKNOWN': 'UNKNOWN_NOT_READABLE_FROM_THIRD_PARTY' in s,
    'Core one-click read suite': 'runCoreReadSuite' in s,
    'Private log file before Downloads': s.index('writePrivateReport(json)') < s.index('writeToDownloads(json, name)'),
    'Android 10 Scoped Downloads': 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' in s,
    'Log save fallback and exception handling': 'DOWNLOADS_FAILED_PRIVATE_OK' in s and 'safelyReportError' in s,
    'File share not massive EXTRA_TEXT': 'Intent.EXTRA_STREAM' in s and 'Intent.EXTRA_TEXT' not in s,
    'Read-only private provider': len(providers)==1 and providers[0].get(ns+'exported')=='false' and 'MODE_READ_ONLY' in provider,
    'No ADB / root / CAN write': all(token not in s for token in ('CAN_RAW','sendBroadcast(', 'Runtime.getRuntime(', 'ProcessBuilder(', 'Socket(', 'setprop ', 'su -c')),
    'No Internet / storage escalation': all(token not in manifest for token in ('INTERNET','MANAGE_EXTERNAL_STORAGE','WRITE_EXTERNAL_STORAGE')),
    'No HOME replacement': 'android.intent.category.HOME' not in manifest,
    'Three BYD requested permissions': all(t in manifest for t in ('BYDAUTO_SETTING_COMMON','BYDAUTO_SETTING_GET','BYDAUTO_SETTING_SET')),
    'Version v2.3 incremented': 'versionCode 5' in gradle and '2.3.0-integrated-wizard' in gradle,
    'Android 10 target API': 'targetSdk 29' in gradle,
    'Only 2 deployment files': 'Dolphin_InteriorLight_V2_3_Source.zip' in yaml and 'build-apk.yml' in yaml,
    'Non-legacy SDK setup': 'android-actions/setup-android@v4' in yaml and "packages: platform-tools" in yaml,
    'APK SHA and failure logs': 'apk_sha256.txt' in yaml and 'Dolphin-InteriorLight-V2-3-Build-Diagnostics' in yaml,
}
for name,ok in checks.items(): print(('PASS ' if ok else 'FAIL ')+name)
score=sum(checks.values())
print(f'STATIC_PASS={score}/{len(checks)} / APK_COMPILE_NOT_TESTED / PHYSICAL_NOT_TESTED')
sys.exit(0 if score==len(checks) else 1)
