# V2.3 연구·이슈·중복 통합 점검 (2026-10-15)

## 사용한 정본
- `/Dolphin Drive Alerts/00_MASTER_ISSUES.md` 최신 조회 사본 (2026-10-14 최종 편집).
- `/Dolphin Drive Alerts/01_REALCAR_EVIDENCE.md` (2026-10-11 최종 편집).
- `BYD_DOLPHIN_GOODLOCK_SPEC_20261013_KO.md` (기존 순정 HOME 유지 원칙, 이번 앱은 분리 독립 진단).
- 순정 SystemUI dexdump `InsightLightOnItem` / `AutoStudyUtil.getInitInsightLightOnlineState` 및 2026-10-14 사용자 실차 V2 JSON 로그.
- 실제 ZIP 세대 V2 → V2.1 → V2.2의 모든 파일(차이/중복/변경 검토).

## 기존 이슈 재사용, 신규 이슈번호 0개
- `DA-004` BYD/ADB 권한 여부와 보호등급 진단. 본 앱은 서명 권한을 우회하거나 ADB 권한을 부여하지 않음.
- `DA-013` GitHub Actions ZIP-only 빌드팩 / API 컴파일·해시·실패 로그.
- `DA-025` 순정 안전 UI/차량 제어 범위 보존. 정차 사용자 승인 조건.
- `DA-029` 진단 중복 메뉴/이력. V2.3 SELECT_METHOD 인접 중복 기록 제거.
- `DA-002` 연구 원본·OEM 참조 자료: Good Lock 커스터마이저와 별도 앱, 종속성 없음.

## 중복 제거 및 유지 판정
| 항목 | 처리 | 근거 |
|---|---|---|
| V2 후보 목록/수동 메서드 메타데이터 | V2.2 실호출 경로 유지 | V2 로그는 `METADATA_ONLY` 반복 |
| 반복 연타 동일 메서드 선택 | 인접 중복 이벤트 방지 | 실제 진단과 무관한 로그 노이즈 |
| V2.1 로그 저장/공유 | 그대로 유지 | 이전 사용자 강제 종료 신고, 원인 스택트레이스는 없음 |
| V2.2 API 조회/권한 보호등급 | 유지 | 이번 실차 첫 실사용 결과 확보할 수 있게 |
| 쓰기 메서드 실행 | `turnOffInsideLight(int)` 외 모두 차단 | OEM 메서드명만으로 안전성 추정 불가 |
| OEM UI 쓰기/ADB/root/CAN | 구현 없음 | 사용자 요청 범위·차량 안전 |
| 디버그 로그/README/YAML | 단일 빌드파이프라인 | ZIP 1개 + YAML 1개 |

**상태:** `V2.3_SOURCE_READY / LOCAL_STATIC_CHECK_PASS / JAVA_PARSER_PASS / GITHUB_ANDROID_BUILD_REQUIRED / REALCAR_REVERIFY_REQUIRED`. 원격 GitHub 업로드/이슈 갱신은 이 빌드팩 생성만으로 완료되지 않음.
