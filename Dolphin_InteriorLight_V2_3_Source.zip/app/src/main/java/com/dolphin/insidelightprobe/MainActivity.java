package com.dolphin.insidelightprobe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Standalone BYD Dolphin interactive diagnostic wizard.
 * NO arbitrary CAN frames, broadcasts, reflection method names entered by user,
 * system writes, signature bypass, ADB/root, firmware flash, or remote upload.
 * The only write candidate is a known OEM interior-light API, gated by permission,
 * stationary manual confirmation and one single user-initiated invocation.
 */
public final class MainActivity extends Activity {
    private static final String SETTINGS_DEVICE = "android.hardware.bydauto.setting.BYDAutoSettingDevice";
    private static final String CAR_SETTINGS = "android.provider.CarSettings$Global";
    private static final String PERM_COMMON = "android.permission.BYDAUTO_SETTING_COMMON";
    private static final String PERM_GET = "android.permission.BYDAUTO_SETTING_GET";
    private static final String PERM_SET = "android.permission.BYDAUTO_SETTING_SET";
    private static final int EXPORT_REQUEST = 219;
    private static final String SHARE_AUTHORITY = "com.dolphin.insidelightprobe.logs";
    private static final String LAST_REPORT = "latest-report.json";
    private static final int INK = Color.rgb(22, 43, 62);
    private static final int MUTED = Color.rgb(64, 83, 99);
    private static final int BLUE = Color.rgb(15, 94, 169);
    private static final int RED = Color.rgb(153, 64, 34);
    private SharedPreferences prefs;
    private LinearLayout page;
    private TextView title;
    private TextView subtitle;
    private TextView foot;
    private final JSONArray entries = new JSONArray();
    private final List<Candidate> candidates = new ArrayList<>();
    private String selected = "";
    private String selectedDetail = "";
    private final List<String> methodCandidates = new ArrayList<>();
    private final List<String> componentCandidates = new ArrayList<>();
    private final List<String> systemUiPackages = new ArrayList<>();
    private String featureGate = "UNKNOWN";
    private String permissionDiagnostics = "NOT_PROBED";
    private int readTicket;
    private int writeTicket;
    private boolean writePending;
    private static final Set<String> READ_GETTERS = new HashSet<>(Arrays.asList(
            "getInsideLightDoorState", "getAirLightPanelState", "getAirLightTextNumber",
            "getAirLightTextState", "getInsBacklightCtl", "getSmartWelcomeLightState",
            "getBackHomeLightDelay", "getBackHomeLightDelayValue", "getHomeLightTime",
            "getLeaveHomeLightTime", "getLeftHomeLightDelay", "getLeftHomeLightDelayValue",
            "getNightDRLightOnInd", "getNightDriveLightOnReminder"));
    private String lastAction = "";
    private String lastResult = "";
    private String lastOutcome = "NOT_TESTED";
    private int step = 1;
    private boolean availableOem;
    private boolean availableCarSettings;
    private String lastPkg = "";
    private boolean preflightPassed;
    private boolean busy;

    private static final class Candidate {
        final String id, name, detail;
        final boolean present;
        Candidate(String id, String name, String detail, boolean present) {
            this.id = id; this.name = name; this.detail = detail; this.present = present;
        }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("dolphin_wizard_v2", MODE_PRIVATE);
        restore();
        getWindow().setStatusBarColor(Color.rgb(12, 31, 48));
        getWindow().setNavigationBarColor(Color.rgb(12, 31, 48));
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(15),dp(12),dp(15),dp(10));
        container.setBackgroundColor(Color.rgb(244,248,251));
        title = label("돌핀 실내등 연속 검증  V2.3", 22, INK, true);
        container.addView(title);
        subtitle = label("설치 1회 · 후보 탐색 → 선택 → 읽기 검증 → 사용자 승인 시험 → 실물 판정", 13, MUTED, false);
        container.addView(subtitle);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        for (int i=1;i<=4;i++) {
            final int s=i;
            Button b=smallButton(new String[]{"", "1 환경", "2 후보", "3 경로", "4 결과"}[i], () -> {step=s; render();});
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(44),1));
        }
        container.addView(nav);
        ScrollView scroll = new ScrollView(this);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(0,dp(5),0,dp(12));
        scroll.addView(page);
        container.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        foot=label("", 11, MUTED, false);
        container.addView(foot);
        setContentView(container);
        if (entries.length()==0) record("START", "APP", "V2.3 | " + Build.MANUFACTURER + " / " + Build.MODEL + " / Android " + Build.VERSION.RELEASE, "READ_ONLY");
        scan();
        render();
    }

    private int dp(int v) {return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    private TextView label(String s,int sp,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(dp(4),dp(8),dp(5),dp(7)); if(bold)t.setTypeface(null,Typeface.BOLD);
        return t;
    }
    private Button smallButton(String name,Runnable action) {
        Button b=new Button(this);b.setText(name);b.setTextSize(13);b.setAllCaps(false);
        b.setOnClickListener(v -> {
            try { action.run(); }
            catch (Throwable error) { safelyReportError("UI_ACTION " + name, error); }
        });return b;
    }
    private void button(String name,Runnable action) {
        Button b=smallButton(name,action);
        page.addView(b,new LinearLayout.LayoutParams(-1,dp(47)));
    }
    private void section(String value) {page.addView(label(value,17,INK,true));}
    private void body(String value){page.addView(label(value,14,MUTED,false));}
    private void warn(String value){page.addView(label(value,13,RED,true));}
    private String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA).format(new Date());}
    private void record(String phase,String target,String result,String verdict) {
        JSONObject obj=new JSONObject();
        try {obj.put("timestamp",now());obj.put("phase",phase);obj.put("candidate",target);obj.put("result",result);obj.put("verdict",verdict);} catch(Exception ignored){}
        // Avoid filling the evidence window with accidental consecutive taps on the same metadata item.
        if ("SELECT_METHOD".equals(phase) && entries.length() > 0) {
            JSONObject previous = entries.optJSONObject(entries.length() - 1);
            if (previous != null && "SELECT_METHOD".equals(previous.optString("phase"))
                    && target.equals(previous.optString("candidate"))
                    && result.equals(previous.optString("result"))) return;
        }
        entries.put(obj);
        // Do not retain unbounded diagnostic data on the infotainment unit.
        if(entries.length()>160){entries.remove(0);}
        persist();
    }
    private void restore(){
        selected=prefs.getString("selected", "");
        selectedDetail=prefs.getString("selectedDetail", "");
        step=Math.max(1,Math.min(4,prefs.getInt("step",1)));
        lastAction=prefs.getString("lastAction", "");
        lastResult=prefs.getString("lastResult", "");
        lastOutcome=prefs.getString("lastOutcome", "NOT_TESTED");
        try {JSONArray prior=new JSONArray(prefs.getString("entries","[]")); for(int i=0;i<prior.length();i++)entries.put(prior.get(i));}catch(Exception ignored){}
    }
    private void persist(){
        if(prefs==null)return;
        prefs.edit().putString("selected",selected).putString("selectedDetail",selectedDetail).putInt("step",step)
                .putString("lastAction",lastAction).putString("lastResult",lastResult)
                .putString("lastOutcome",lastOutcome).putString("entries",entries.toString()).apply();
    }
    private static String exception(Throwable e){
        if(e instanceof InvocationTargetException && ((InvocationTargetException)e).getTargetException()!=null) e=((InvocationTargetException)e).getTargetException();
        return e.getClass().getSimpleName()+(e.getMessage()==null?"":": "+e.getMessage());
    }
    private boolean permission(String p){return getPackageManager().checkPermission(p,getPackageName())==PackageManager.PERMISSION_GRANTED;}
    private static boolean hasClass(String name){try{Class.forName(name);return true;}catch(Throwable t){return false;}}
    private String findSystemUi(){
        systemUiPackages.clear();
        String best = "";
        int bestScore = -1;
        try {
            for(PackageInfo i:getPackageManager().getInstalledPackages(0)){
                String pkg = i.packageName;
                String path = i.applicationInfo == null ? "" : String.valueOf(i.applicationInfo.sourceDir);
                String lower = (pkg + " " + path).toLowerCase(Locale.ROOT);
                if (!lower.contains("systemui") && !lower.contains("bydqsmodes")) continue;
                boolean overlay = pkg.toLowerCase(Locale.ROOT).contains("overlay") || lower.contains("/overlay/");
                boolean legacy = lower.contains("systemuiwithlegacyrecents");
                int score = overlay ? 0 : (legacy ? 4 : (pkg.equals("com.android.systemui") ? 3 : 1));
                systemUiPackages.add(pkg + " | type=" + (overlay ? "RESOURCE_OVERLAY" : "CODE_CANDIDATE") + " | source=" + path);
                if(score > bestScore){bestScore=score;best=pkg;}
            }
            java.util.Collections.sort(systemUiPackages);
        } catch(Throwable t){record("DISCOVER","SYSTEMUI_PACKAGES",exception(t),"ERROR");}
        return bestScore >= 1 ? best : "";
    }
    private static String signature(Method method) {
        StringBuilder b=new StringBuilder(method.getName()).append("(");
        Class<?>[] p=method.getParameterTypes();
        for(int i=0;i<p.length;i++){if(i>0)b.append(", ");b.append(p[i].getSimpleName());}
        return b.append(") → ").append(method.getReturnType().getSimpleName()).toString();
    }
    private void scan() {
        candidates.clear();
        methodCandidates.clear();
        componentCandidates.clear();
        availableOem=hasClass(SETTINGS_DEVICE);
        if(availableOem){
            try {
                for(Method m:Class.forName(SETTINGS_DEVICE).getMethods()) {
                    String n=m.getName().toLowerCase(Locale.ROOT);
                    if(n.contains("inside")||n.contains("light")||n.contains("cabin"))
                        methodCandidates.add(signature(m));
                }
                java.util.Collections.sort(methodCandidates);
            }catch(Throwable t){record("DISCOVER","OEM_METHODS",exception(t),"ERROR");}
        }
        availableCarSettings=hasClass(CAR_SETTINGS);
        lastPkg=findSystemUi();
        if(!lastPkg.isEmpty()) {
            try {
                int f=PackageManager.GET_ACTIVITIES|PackageManager.GET_RECEIVERS|PackageManager.GET_SERVICES|PackageManager.GET_PROVIDERS;
                PackageInfo pkg=getPackageManager().getPackageInfo(lastPkg,f);
                if(pkg.activities!=null)for(ActivityInfo a:pkg.activities)if(a.exported)componentCandidates.add("Activity | "+a.name+" | permission="+a.permission);
                if(pkg.receivers!=null)for(ActivityInfo a:pkg.receivers)if(a.exported)componentCandidates.add("Receiver | "+a.name+" | permission="+a.permission);
                if(pkg.services!=null)for(ServiceInfo a:pkg.services)if(a.exported)componentCandidates.add("Service | "+a.name+" | permission="+a.permission);
                if(pkg.providers!=null)for(ProviderInfo a:pkg.providers)if(a.exported)componentCandidates.add("Provider | "+a.name+" | permission="+a.readPermission);
                java.util.Collections.sort(componentCandidates);
            }catch(Throwable e){record("DISCOVER","SYSTEMUI_COMPONENTS",exception(e),"ERROR");}
        }
        candidates.add(new Candidate("OEM","BYDAutoSettingDevice", "순정 API 탐색 및 지정된 실내등 메서드",availableOem));
        candidates.add(new Candidate("CAR","CarSettings.Global", "insight_light_online 설정값 읽기 전용",availableCarSettings));
        candidates.add(new Candidate("UI","SystemUI", "설치된 순정 시스템 UI 및 exported 구성요소 읽기",!lastPkg.isEmpty()));
        candidates.add(new Candidate("PERM","권한·환경", "일반/제조사 권한의 현재 부여 상태 확인",true));
        record("DISCOVER", "ALL", "OEM="+availableOem+" CAR="+availableCarSettings+" SystemUI="+(!lastPkg.isEmpty()), "READ_ONLY");
        persist();
    }
    private Candidate selectedCandidate(){for(Candidate c:candidates)if(c.id.equals(selected))return c;return null;}
    private void render(){
        page.removeAllViews();
        foot.setText((busy || writePending ? "OEM 호출 진행 중 · 중복 실행 차단 · " : "")
                + "차량 명령 수동 승인 1회 · CAN/ADB/root/SELinux 변경 없음 · 기록 자동 보존");
        if(step==1)showEnv(); else if(step==2)showCandidates(); else if(step==3)showPath(); else showResults();
        persist();
    }
    private void showEnv(){
        section("1단계 · 환경과 기본 접근권한");
        body("기기: "+Build.MANUFACTURER+" / "+Build.MODEL+" · Android "+Build.VERSION.RELEASE+" / SDK "+Build.VERSION.SDK_INT);
        body("기준 차량: 한국 BYD 돌핀 Standard, 글로벌 2602. 현재 설치 펌웨어 식별은 아래 값과 실제 차량 설정을 대조하세요.");
        body("Build.DISPLAY = "+Build.DISPLAY);
        body("설정 COMMON: "+bool(permission(PERM_COMMON)));
        body("설정 GET: "+bool(permission(PERM_GET)));
        body("설정 SET: "+bool(permission(PERM_SET)));
        body("OEM 클래스: "+bool(availableOem));
        body("CarSettings 클래스: "+bool(availableCarSettings));
        body("SystemUI 코드 후보: "+(lastPkg.isEmpty()?"탐색되지 않음":lastPkg));
        body("검색된 SystemUI 유사 패키지: " + systemUiPackages.size() + "개 (오버레이와 코드 분리)");
        body("게이트 조건: insight_light_online==0 AND isCanFd==true (ShowAllItems는 표시용 우회)");
        body("isCanFd 실차값: UNKNOWN · 순정 내부 필드로 현재 앱에서 직접 조회 가능하다는 근거 없음");
        button("모든 핵심 항목 1회 연속 검사 (읽기 전용)", this::runCoreReadSuite);
        button("BYD 권한 보호 등급 · 부여 상태 실제 검사", this::probePermissionDetails);
        warn("중요: Manifest에 BYD 전용 권한을 선언해도 제조사 서명/시스템 권한은 자동 부여되지 않습니다.");
        button("읽기 전용 환경 재탐색",()->{scan();render();});
        button("다음: 후보 경로 선택",()->{step=2;render();});
    }
    private String bool(boolean v){return v?"발견/허용":"미발견/미허용";}
    private void showCandidates(){
        section("2단계 · 발견된 후보를 선택하세요");
        body("아래 항목은 API/설정/구성요소 후보입니다. 화면에 나타난 것은 신호 또는 CAN ID를 실제로 확인했다는 뜻이 아닙니다.");
        for(Candidate c:candidates){
            String mark=c.id.equals(selected)?"◉ ":"○ ";
            button(mark+c.name+" ["+(c.present?"발견":"미발견")+"]",()->{
                selected=c.id; selectedDetail=""; preflightPassed=false;
                record("SELECT", c.id, c.name,"CANDIDATE_ONLY");step=3;render();
            });
            body("    "+c.detail);
        }
        button("후보 재탐색",()->{scan();render();});
        button("앞 단계",()->{step=1;render();});
    }
    private void showPath(){
        Candidate c=selectedCandidate();
        section("3단계 · 선택 경로 검증");
        if(c==null){warn("선택한 후보가 없습니다.");button("후보 목록으로",()->{step=2;render();});return;}
        body("선택: "+c.name+" / "+c.detail);
        if(!c.present){warn("현재 환경에서는 이 항목을 찾지 못했습니다. 그래도 기록할 수 있으나 실행은 불가합니다.");}
        if("OEM".equals(c.id))showOemPath(c);
        else if("CAR".equals(c.id))showCarPath(c);
        else if("UI".equals(c.id))showUiPath(c);
        else showPermissionPath();
        button("다른 후보 선택",()->{step=2;render();});
        button("결과·이력으로",()->{step=4;render();});
    }
    private void showOemPath(Candidate c){
        body("동적 발견 메서드: "+methodCandidates.size()+"개. 조회 메서드는 실제 호출 가능 여부를 검사합니다.");
        if (availableOem) button("A. 실내등 관련 안전 조회 4종 연속 검사", this::batchReadLightGetters);
        body("일괄 조회: 문 연동, 실내 무드등 패널, 계기판 조도 설정, 웰컴라이트. 전체 실내등 ON/OFF 상태와는 다릅니다.");
        body("아래에서 순정 API 메서드를 직접 선택하세요. 목록은 실제 차량 펌웨어에 보이는 메서드만 표시됩니다.");
        for(int i=0;i<Math.min(28,methodCandidates.size());i++) {
            String m=methodCandidates.get(i);
            button((m.equals(selectedDetail)?"◉ ":"○ ")+m,()->{
                selectedDetail=m;preflightPassed=false;
                record("SELECT_METHOD","OEM",m,"METADATA_ONLY");render();
            });
        }
        if(methodCandidates.size()>28)body("메서드 목록이 많아 28개까지만 표시합니다. 리포트는 탐색된 전체 개수를 보존합니다.");
        if(selectedDetail.isEmpty()){body("우선 목록에서 메서드를 선택해 주세요.");return;}
        body("선택한 메서드: "+selectedDetail);
        body("경로: "+SETTINGS_DEVICE+".getInstance(Context) → 선택 메서드");
        body("BYDAUTO_SETTING_COMMON 권한: "+bool(permission(PERM_COMMON)));
        if (!selectedDetail.startsWith("turnOffInsideLight(int)")) {
            String getterName = selectedDetail.contains("(") ? selectedDetail.substring(0,selectedDetail.indexOf('(')) : "";
            if (READ_GETTERS.contains(getterName) && selectedDetail.contains("()")) {
                body("이 메서드는 읽기 전용 후보로 분류되었습니다. 실제 반환값과 권한 오류를 기록합니다.");
                button("B. 선택한 조회 메서드 실제 실행 (읽기)", () -> readOemGetter(getterName));
            } else {
                warn("이 메서드는 검증된 읽기 목록 밖이므로 호출하지 않고 이름만 기록합니다.");
                button("메서드 정보만 기록",()->{
                    lastAction="METHOD_METADATA";lastResult=selectedDetail;lastOutcome="UNVERIFIED_METHOD";
                    record("READ_PROBE","OEM",selectedDetail,lastOutcome);step=4;render();
                });
            }
            return;
        }
        warn("임의 인수/메서드/CAN 제어는 제공하지 않습니다. 검증 대상은 1·2만 허용합니다.");
        button("A. 선택 메서드 시그니처 확인 (읽기)",this::oemPreflight);
        if(!c.present)return;
        if (!permission(PERM_COMMON) || !permission(PERM_SET)) {
            warn("BYDAUTO_SETTING_COMMON 및 BYDAUTO_SETTING_SET 권한이 모두 필요합니다. 서명 권한을 임의 부여할 수 없으므로 쓰기 시험이 잠깁니다.");
            button("권한 차단 결과 저장",()->{
                lastAction="OEM_BLOCKED";lastResult="COMMON="+permission(PERM_COMMON)+", SET="+permission(PERM_SET);lastOutcome="BLOCKED_PERMISSION";
                record("BLOCKED","OEM",lastResult,lastOutcome);step=4;render();
            });
            return;
        }
        if(writePending){warn("이전 제어 호출이 완료되지 않았습니다. 추가 제어 명령은 잠긴 상태입니다.");return;}
        if(preflightPassed){
            button("B. 전체 점등 후보 (2) · 승인 후 1회",()->confirmOem(2));
            button("B. 전체 소등 후보 (1) · 승인 후 1회",()->confirmOem(1));
        }else body("A단계 시그니처 검증 통과 후 B단계가 열립니다.");
    }
    private void oemPreflight(){
        String outcome="API_VISIBLE";String result;
        try{
            Class<?> t=Class.forName(SETTINGS_DEVICE);
            Method get=t.getMethod("getInstance",Context.class);
            Method set=t.getMethod("turnOffInsideLight",int.class);
            result="getInstance="+get.getReturnType().getSimpleName()+" turnOffInsideLight="+set.getReturnType().getSimpleName()+" COMMON="+bool(permission(PERM_COMMON));
            preflightPassed=true;
        }catch(Throwable e){result=exception(e);outcome="API_NOT_VISIBLE";preflightPassed=false;}
        lastAction="OEM_SIGNATURE";lastResult=result;lastOutcome=outcome;
        record("READ_PROBE","OEM",result,outcome);
        render();toast(result);
    }
    private void confirmOem(int state){
        if(busy || writePending || !availableOem || !preflightPassed || !permission(PERM_COMMON) || !permission(PERM_SET))return;
        String title=state==2?"전체 점등(2)":"전체 소등(1)";
        // A checkbox is deliberately included with every trial; no prior consent is carried over.
        CheckBox confirm=new CheckBox(this);
        confirm.setText("P단 정차 + 주차 브레이크 체결 / 실물 조명 확인 가능 / 1회 명령에 동의");
        confirm.setPadding(dp(12),dp(10),dp(12),dp(10));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title+" 단발성 시험")
                .setMessage("제조사 API만 1회 호출합니다. 차량 신호 확인 없이 자동 성공 처리하지 않습니다. 사용자의 눈으로 조명 변화를 확인하세요.")
                .setView(confirm).setNegativeButton("취소",null)
                .setPositiveButton("동의하고 1회 시험", (d,w)->{if(confirm.isChecked())doOem(state);else toast("동의 체크가 없어 전송하지 않았습니다.");}).create();
        dialog.show();
    }
    private void doOem(int state){
        if(busy || writePending || !permission(PERM_COMMON) || !permission(PERM_SET))return;
        // Only one OEM control invocation is allowed to be in flight. An 8s UI watchdog
        // never releases this lock; a Binder call cannot be safely cancelled from UI.
        writePending=true;
        final int ticket=++writeTicket;
        final String name="TURN_OFF_INSIDE_LIGHT("+state+")";
        lastAction=name;
        lastResult="차량 OEM 응답 대기 중 (중복 명령 잠금)";
        lastOutcome="CONTROL_PENDING";
        record("CONTROL_START", "OEM", name, lastOutcome);
        step=4;render();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if(ticket!=writeTicket || !writePending)return;
            lastAction=name;
            lastResult="8초 경과: 차량 응답을 기다리는 중. 중복 제어는 계속 차단됩니다.";
            lastOutcome="CONTROL_STILL_PENDING";
            record("CONTROL_SLOW", "OEM", lastResult, lastOutcome);
            step=4;render();
        },8000);
        Thread oneCall=new Thread(() -> {
            String result;String verdict;
            try{
                Class<?> t=Class.forName(SETTINGS_DEVICE);
                Object instance=t.getMethod("getInstance",Context.class).invoke(null,getApplicationContext());
                if(instance==null)throw new IllegalStateException("getInstance returned null");
                Object returnVal=t.getMethod("turnOffInsideLight",int.class).invoke(instance,state);
                result="OEM 반환값="+String.valueOf(returnVal)+"; 실제 물리 조명 변화 미확인";
                verdict="API_RETURN_ONLY";
            }catch(Throwable error){
                result=exception(error);
                verdict=unwrap(error) instanceof SecurityException ? "CONTROL_PERMISSION_DENIED" : "INVOCATION_FAILED";
            }
            final String output=result, outcome=verdict;
            runOnUiThread(() -> {
                if(ticket!=writeTicket)return;
                writePending=false;
                lastAction=name;lastResult=output;lastOutcome=outcome;
                record("CONTROL_TRIAL", "OEM", name+" => "+output, outcome);
                step=4;render();
                if("API_RETURN_ONLY".equals(outcome))new AlertDialog.Builder(this)
                        .setTitle("실물 조명이 변화했습니까?")
                        .setMessage("OEM 반환값은 실제 점등·소등 증거가 아닙니다. 육안으로 확인하세요.")
                        .setPositiveButton("변화 확인",(d,w)->physical("PHYSICAL_CHANGED"))
                        .setNegativeButton("변화 없음",(d,w)->physical("PHYSICAL_UNCHANGED"))
                        .setNeutralButton("판단 보류",(d,w)->physical("PHYSICAL_UNKNOWN")).show();
            });
        }, "dolphin-single-oem-control");
        oneCall.setDaemon(true);oneCall.start();
    }
    private void physical(String value){
        lastOutcome=value;
        record("PHYSICAL_CHECK","OEM",lastAction+": "+value,value);
        step=4;render();
    }
    // Read only known, zero-argument OEM getter methods. Do not invoke arbitrary setters or user-entered methods.
    private void readOemGetter(String getterName) {
        if (busy || writePending || !READ_GETTERS.contains(getterName)) return;
        busy = true;
        final int ticket = ++readTicket;
        lastAction = "OEM_GETTER_" + getterName;
        record("READ_START", "OEM", getterName + "()", "READ_ONLY");
        render();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!busy || ticket != readTicket) return;
            ++readTicket; busy = false;
            lastAction = "OEM_GETTER_" + getterName;
            lastOutcome = "READ_TIMEOUT";
            lastResult = getterName + ": OEM binder 호출이 8초 안에 반환되지 않음";
            record("READ_TIMEOUT", "OEM", lastResult, lastOutcome);
            step = 4;render();
        }, 8000);
        Thread background = new Thread(() -> {
            String output;String verdict;
            try {
                Class<?> clazz = Class.forName(SETTINGS_DEVICE);
                Method getter = clazz.getMethod(getterName);
                if (getter.getParameterTypes().length != 0 ||
                        !(getter.getReturnType() == int.class || getter.getReturnType() == boolean.class))
                    throw new IllegalArgumentException("Getter must be zero-argument int/boolean");
                Object owner = clazz.getMethod("getInstance", Context.class).invoke(null,getApplicationContext());
                if (owner == null) throw new IllegalStateException("getInstance returned null");
                Object value = getter.invoke(owner);
                output = getterName + "() -> " + String.valueOf(value) + " (OEM 원시값; 실내등 전체 상태를 뜻하지 않음)";
                verdict = "GETTER_VALUE_RETURNED";
            } catch (Throwable error) {
                Throwable underlying = unwrap(error);
                output = getterName + "() -> " + exception(error);
                verdict = underlying instanceof SecurityException ? "GETTER_PERMISSION_DENIED" : "GETTER_CALL_FAILED";
            }
            final String finalOutput = output; final String finalVerdict = verdict;
            runOnUiThread(() -> {
                if (ticket != readTicket) return;
                busy=false;
                lastAction = "OEM_GETTER_" + getterName;
                lastResult = finalOutput;lastOutcome = finalVerdict;
                record("READ_INVOKE", "OEM", finalOutput, finalVerdict);
                step=4;render();
            });
        }, "dolphin-safe-oem-getter");
        background.setDaemon(true);
        background.start();
    }
    private static Throwable unwrap(Throwable error) {
        if (error instanceof InvocationTargetException &&
            ((InvocationTargetException)error).getTargetException() != null)
            return ((InvocationTargetException)error).getTargetException();
        return error;
    }
    private void batchReadLightGetters() {
        if (busy || writePending) return;
        // One press, four independent read-only attempts, subsequent attempts only after each result.
        final String[] getters = {"getInsideLightDoorState", "getAirLightPanelState",
                "getInsBacklightCtl", "getSmartWelcomeLightState"};
        busy = true;
        final int ticket = ++readTicket;
        lastAction = "BATCH_LIGHT_GETTERS";
        record("BATCH_START", "OEM", "4 allowed getters", "READ_ONLY");
        render();
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!busy || ticket != readTicket) return;
            ++readTicket;busy=false;
            lastOutcome="BATCH_TIMEOUT";
            lastResult="OEM 일괄 조회가 12초 안에 끝나지 않음";
            record("BATCH_TIMEOUT","OEM",lastResult,lastOutcome);
            step=4;render();
        }, 12000);
        Thread work = new Thread(() -> {
            final List<String> outcomes = new ArrayList<>();
            try {
                Class<?> clazz=Class.forName(SETTINGS_DEVICE);
                Object owner=clazz.getMethod("getInstance", Context.class).invoke(null,getApplicationContext());
                if(owner==null) throw new IllegalStateException("getInstance returned null");
                for(String name:getters){
                    try{
                        Method m=clazz.getMethod(name);
                        if (m.getParameterTypes().length != 0 || m.getReturnType() != int.class)
                            throw new IllegalArgumentException("Unexpected signature");
                        outcomes.add(name+"="+String.valueOf(m.invoke(owner)));
                    }catch(Throwable failure){outcomes.add(name+"="+exception(failure));}
                }
            }catch(Throwable failure){outcomes.add("getInstance="+exception(failure));}
            runOnUiThread(() -> {
                if(ticket != readTicket)return;
                busy=false;
                for(String line:outcomes)record("BATCH_GETTER", "OEM", line,
                    line.contains("SecurityException") ? "GETTER_PERMISSION_DENIED" :
                    line.contains("Exception") ? "GETTER_CALL_FAILED" : "RAW_VALUE_ONLY");
                lastResult=android.text.TextUtils.join("\n", outcomes);
                lastOutcome="BATCH_COMPLETED_NOT_PHYSICAL_PROOF";
                record("BATCH_END", "OEM", "4 getter read attempts", lastOutcome);
                step=4;render();
            });
        },"dolphin-batch-read");
        work.setDaemon(true);work.start();
    }
    private void runCoreReadSuite() {
        if(busy || writePending) return;
        probePermissionDetails();
        String result;String verdict;
        try {
            Class<?> clazz = Class.forName(CAR_SETTINGS);
            Object raw = clazz.getMethod("getInt", android.content.ContentResolver.class, String.class)
                    .invoke(null, getContentResolver(), "insight_light_online");
            result = "insight_light_online=" + String.valueOf(raw);
            featureGate = "0".equals(String.valueOf(raw)) ?
                    "FLAG_ZERO_CONDITION_MET_ISCANFD_UNKNOWN" : "FLAG_NOT_ZERO_CONDITION_FAILS";
            verdict = "READ_OK";
        }catch(Throwable error){result="insight_light_online: " + exception(error);verdict="READ_BLOCKED";}
        record("CORE_SUITE_CAR","CAR",result,verdict);
        record("CORE_SUITE_SYSTEMUI","UI","code_candidate="+lastPkg+"; matched="+systemUiPackages.size(),"READ_ONLY");
        if(availableOem)batchReadLightGetters();
        else {
            lastAction="CORE_SUITE_NO_OEM";lastResult="BYDAutoSettingDevice class not visible";
            lastOutcome="READ_ONLY_NO_OEM";
            record("CORE_SUITE","OEM",lastResult,lastOutcome);
            step=4;render();
        }
    }
    private void probePermissionDetails(){
        StringBuilder info = new StringBuilder();
        for(String perm:new String[]{PERM_COMMON, PERM_GET, PERM_SET}){
            if(info.length()>0)info.append("\n");
            info.append(perm).append(" granted=").append(permission(perm));
            try {
                PermissionInfo p=getPackageManager().getPermissionInfo(perm,0);
                info.append(" owner=").append(p.packageName)
                        .append(" protection=0x").append(Integer.toHexString(p.protectionLevel));
                int base=p.protectionLevel & 0xF;
                info.append(base==PermissionInfo.PROTECTION_SIGNATURE ? " (SIGNATURE)" :
                            base==PermissionInfo.PROTECTION_DANGEROUS ? " (DANGEROUS)" :
                            base==PermissionInfo.PROTECTION_NORMAL ? " (NORMAL)" : " (OTHER)");
            } catch(Throwable failure){info.append(" info=").append(exception(failure));}
        }
        permissionDiagnostics=info.toString();
        lastAction="PERMISSION_PROTECTION";lastResult=permissionDiagnostics;lastOutcome="READ_ONLY";
        record("PERMISSION_DETAIL","PERM",permissionDiagnostics,"READ_ONLY");
        step=4;render();
    }

    private void showCarPath(Candidate c){
        body("키: insight_light_online (기능 제공/표시 조건 후보; 현재 조명 ON/OFF 상태 아님)");
        if(c.present)button("CarSettings.Global 값 조회 (읽기)",()->{
            String value;String verdict="READ_OK";
            try{
                Class<?> t=Class.forName(CAR_SETTINGS);
                Method m=t.getMethod("getInt",android.content.ContentResolver.class,String.class);
                Object raw = m.invoke(null,getContentResolver(),"insight_light_online");
                value="insight_light_online="+String.valueOf(raw);
                featureGate = "0".equals(String.valueOf(raw)) ? "FLAG_ZERO_CONDITION_MET_ISCANFD_UNKNOWN" : "FLAG_NOT_ZERO_CONDITION_FAILS";
            }catch(Throwable e){value=exception(e);verdict="READ_BLOCKED";}
            lastAction="CAR_SETTINGS_READ";lastResult=value;lastOutcome=verdict;
            record("READ_PROBE","CAR",value,verdict);step=4;render();
        });
        body("이 경로는 설정값 변경을 하지 않습니다. 임의 값으로 기능 활성화를 시도하지 않습니다.");
    }
    private void showUiPath(Candidate c){
        body("순정 SystemUI 코드 후보: "+(lastPkg.isEmpty()?"없음":lastPkg));
        body("중요: com.android.systemui.overlay.common 은 리소스 오버레이일 수 있고, 실내등 기능 구현 APK가 아닙니다.");
        for (String candidate: systemUiPackages) body(candidate);
        body("실차에서 동적 검색된 exported 구성요소: "+componentCandidates.size()+"개. exported=true도 권한·실내등 제어 경로의 증거는 아닙니다.");
        if(c.present)button("전체 공개 구성요소 개수 조사 (읽기)",this::systemUiProbe);
        for(int i=0;i<Math.min(15,componentCandidates.size());i++){
            String component=componentCandidates.get(i);
            button((component.equals(selectedDetail)?"◉ ":"○ ")+component,()->{
                selectedDetail=component;record("SELECT_COMPONENT","UI",component,"METADATA_ONLY");render();
            });
        }
        if(componentCandidates.size()>15)body("목록이 길어 화면에는 15개까지만 표시합니다.");
        if(!selectedDetail.isEmpty())button("선택 구성요소 기록 (실행하지 않음)",()->{
            lastAction="SYSTEMUI_COMPONENT_SELECTED";lastResult=selectedDetail;lastOutcome="METADATA_ONLY";
            record("READ_PROBE","UI",selectedDetail,lastOutcome);step=4;render();
        });
        warn("개별 구성요소가 공개되어 있어도 임의 호출·브로드캐스트 송신은 하지 않습니다.");
    }
    private void systemUiProbe(){
        String result;String verdict="READ_OK";
        try{
            int flags=PackageManager.GET_ACTIVITIES|PackageManager.GET_SERVICES|PackageManager.GET_RECEIVERS|PackageManager.GET_PROVIDERS|PackageManager.GET_PERMISSIONS;
            PackageInfo pkg=getPackageManager().getPackageInfo(lastPkg, flags);
            int exposed=0, protectedCount=0, total=0;
            if(pkg.activities!=null)for(ActivityInfo a:pkg.activities){total++;if(a.exported){exposed++;if(a.permission!=null)protectedCount++;}}
            if(pkg.receivers!=null)for(ActivityInfo a:pkg.receivers){total++;if(a.exported){exposed++;if(a.permission!=null)protectedCount++;}}
            if(pkg.services!=null)for(ServiceInfo a:pkg.services){total++;if(a.exported){exposed++;if(a.permission!=null)protectedCount++;}}
            if(pkg.providers!=null)for(ProviderInfo a:pkg.providers){total++;if(a.exported){exposed++;if(a.readPermission!=null||a.writePermission!=null)protectedCount++;}}
            result="SystemUI="+pkg.packageName+" components="+total+" exported="+exposed+" exported+permission="+protectedCount+"; 실제 실내등 제어 공개 경로=미확인";
        }catch(Throwable e){result=exception(e);verdict="READ_BLOCKED";}
        lastAction="SYSTEMUI_METADATA";lastResult=result;lastOutcome=verdict;
        record("READ_PROBE","UI",result,verdict);step=4;render();
    }
    private void showPermissionPath(){
        button("BYD 권한 보호 등급과 현재 부여 여부 조사",this::probePermissionDetails);
        body("최근 권한 상세: " + permissionDiagnostics);
        button("설정 권한 3종 현재 상태 확인",()->{
            String result="COMMON="+permission(PERM_COMMON)+", GET="+permission(PERM_GET)+", SET="+permission(PERM_SET);
            lastAction="PERMISSION_READ";lastResult=result;lastOutcome="READ_OK";
            record("READ_PROBE","PERM",result,"READ_OK");step=4;render();
        });
        warn("권한 선언과 권한 부여는 다릅니다. 서명/privileged 권한은 ADB pm grant로 일반 앱에 부여할 수 없습니다.");
    }
    private void showResults(){
        section("4단계 · 실제 결과와 다음 후보");
        body("마지막 작업: "+(lastAction.isEmpty()?"아직 없음":lastAction));
        body("진단 응답: "+(lastResult.isEmpty()?"아직 없음":lastResult));
        body("판정: "+lastOutcome);
        if(writePending){warn("이전 차량 제어 명령의 반환을 기다리는 중입니다. 중복 제어는 금지됩니다.");}
        if("API_RETURN_ONLY".equals(lastOutcome)){
            warn("OEM API 반환값만 확인됐습니다. 조명의 실제 변화는 아직 확인되지 않았습니다.");
            button("실물 변화 확인",()->physical("PHYSICAL_CHANGED"));
            button("실물 변화 없음",()->physical("PHYSICAL_UNCHANGED"));
            button("실물 확인 불가",()->physical("PHYSICAL_UNKNOWN"));
        }
        button("다음: 다른 후보 선택 (재설치 불필요)",()->{step=2;render();});
        button("이 경로 재검증",()->{step=3;render();});
        button("로그 저장 (다운로드/내부 백업)",this::saveReport);
        button("로그 파일 공유 (JSON 파일)",this::shareReport);
        button("진단 리포트 복사 (JSON)",this::copyReport);
        body("저장 실패 시에도 앱 내부 최신 리포트가 보존됩니다. 외부 다운로드가 불가하면 공유 또는 복사로 전달하세요.");
        body("최근 진단 기록 (최대 160건 자동 저장)");
        for(int i=entries.length()-1;i>=Math.max(0,entries.length()-15);i--){
            JSONObject r=entries.optJSONObject(i);if(r!=null)
                body(r.optString("timestamp")+" · "+r.optString("phase")+" / "+r.optString("candidate")+"\n"+r.optString("verdict")+" · "+r.optString("result"));
        }
        button("진단 기록만 초기화",()->new AlertDialog.Builder(this)
                .setTitle("진단 기록 삭제")
                .setMessage("이 앱 내부에 저장된 진단 기록만 삭제합니다. 차량에는 아무 명령도 전송하지 않습니다.")
                .setNegativeButton("취소",null).setPositiveButton("삭제",(d,w)->{
                    while(entries.length()>0)entries.remove(entries.length()-1);
                    lastAction="";lastResult="";lastOutcome="NOT_TESTED";persist();render();
                }).show());
    }
    private String report(){
        JSONObject obj=new JSONObject();
        try {
            obj.put("schema","DOLPHIN_INTERIOR_LIGHT_WIZARD_V2_3");
            obj.put("generation_time",now());
            obj.put("device",Build.MANUFACTURER+" / "+Build.MODEL);
            obj.put("android",Build.VERSION.RELEASE);
            obj.put("selected",selected);obj.put("selected_detail",selectedDetail);
            obj.put("oem_discovered_methods",new JSONArray(methodCandidates));
            obj.put("systemui_exported_components",new JSONArray(componentCandidates));
            obj.put("systemui_package_candidates",new JSONArray(systemUiPackages));
            obj.put("feature_gate", featureGate);
            obj.put("isCanFd", "UNKNOWN_NOT_READABLE_FROM_THIRD_PARTY");
            obj.put("permission_detail", permissionDiagnostics);
            obj.put("last_action",lastAction);
            obj.put("last_outcome",lastOutcome);
            obj.put("last_result",lastResult);
            obj.put("events",entries);
            obj.put("note","No VIN/serial collected. Commands are user-confirmed. OEM API return alone never means physical light changed.");
            return obj.toString(2);
        }catch(Exception e){return entries.toString();}
    }
    // Always create an app-private fallback before invoking a platform provider/chooser.
    private File privateReportFile(){ return new File(getFilesDir(), LAST_REPORT); }

    private File writePrivateReport(String json) throws IOException {
        File target = privateReportFile();
        File temp = new File(getFilesDir(), "latest-report.tmp");
        try (FileOutputStream out = new FileOutputStream(temp, false)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
        if (!temp.renameTo(target)) {
            try (FileOutputStream out = new FileOutputStream(target, false)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }
        return target;
    }

    private static String safeName() {
        return "Dolphin_InteriorLight_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".json";
    }

    // Android 10+: write through MediaStore, without WRITE_EXTERNAL_STORAGE.
    // Never use raw public-path writes or silent storage permission escalation.
    private Uri writeToDownloads(String json, String name) throws IOException {
        ContentValues meta = new ContentValues();
        meta.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        meta.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
        meta.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DolphinLightLogs");
        meta.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, meta);
        if (uri == null) throw new IOException("MediaStore.Downloads insert returned null");
        boolean completed = false;
        try {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IOException("openOutputStream returned null");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (getContentResolver().update(uri, done, null, null) < 1)
                throw new IOException("MediaStore finalization returned 0 rows");
            completed = true;
            return uri;
        } finally {
            if (!completed) {
                try { getContentResolver().delete(uri, null, null); }
                catch (Throwable ignored) { /* avoid replacing the original failure */ }
            }
        }
    }

    private void saveReport(){
        String json;
        try {
            json = report();
            File local = writePrivateReport(json);
            if (!local.isFile() || local.length() == 0)
                throw new IOException("Private backup was empty");
        } catch (Throwable error) {
            safelyReportError("PRIVATE_LOG_BACKUP", error);
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                String name = safeName();
                writeToDownloads(json, name);
                record("EXPORT", "DOWNLOADS", name, "SAVED");
                showMessage("로그 저장 완료", "다운로드/DolphinLightLogs/" + name +
                        "\n\n앱 내부 백업도 생성했습니다.");
                return;
            } catch (Throwable error) {
                record("EXPORT", "DOWNLOADS", exception(error), "DOWNLOADS_FAILED_PRIVATE_OK");
                showExportFallback(exception(error));
                return;
            }
        }
        // Pre-Android 10 needs a user-picked document. The car may omit a file picker.
        try {
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType("application/json");
            create.putExtra(Intent.EXTRA_TITLE, safeName());
            startActivityForResult(create, EXPORT_REQUEST);
        } catch (Throwable error) {
            record("EXPORT", "DOCUMENT_PICKER", exception(error), "PICKER_UNAVAILABLE_PRIVATE_OK");
            showExportFallback(exception(error));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            record("EXPORT", "DOCUMENT_PICKER", "User cancelled or no Uri", "PRIVATE_BACKUP_ONLY");
            showMessage("기본 저장 유지", "파일 선택이 취소됐습니다. 앱 내부 백업은 보존되었습니다. 공유/복사 기능을 이용할 수 있습니다.");
            return;
        }
        try {
            String json = report();
            try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (out == null) throw new IOException("Picked document has no writable stream");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            record("EXPORT", "DOCUMENT_PICKER", "Saved via user-selected Uri", "SAVED");
            showMessage("로그 저장 완료", "선택한 위치에 JSON 로그를 저장했습니다.");
        } catch (Throwable error) {
            record("EXPORT", "DOCUMENT_PICKER", exception(error), "WRITE_FAILED_PRIVATE_OK");
            showExportFallback(exception(error));
        }
    }

    private void showExportFallback(String reason){
        showMessage("외부 저장 실패 · 앱 내부 백업 성공",
                "차량의 파일 저장 서비스가 막혔을 수 있습니다.\n" + reason +
                "\n\n앱은 종료되지 않습니다. '로그 파일 공유' 또는 '리포트 복사'를 사용하세요.");
    }

    private void showMessage(String title, String message){
        try {
            new AlertDialog.Builder(this).setTitle(title).setMessage(message)
                    .setPositiveButton("확인", null).show();
        } catch (Throwable error) {
            try { Toast.makeText(this, title, Toast.LENGTH_LONG).show(); }
            catch (Throwable ignored) { /* keep diagnostic session alive */ }
        }
    }

    private void safelyReportError(String action, Throwable failure){
        String detail = exception(failure);
        try {
            JSONObject event = new JSONObject();
            event.put("timestamp", now());
            event.put("phase", "UI_EXCEPTION");
            event.put("candidate", action);
            event.put("result", detail);
            event.put("verdict", "FAILED_NOT_CRASHED");
            entries.put(event);
            if (entries.length() > 160) entries.remove(0);
            persist();
        } catch (Throwable ignored) { /* failure recorder must never recurse */ }
        showMessage("오류를 기록했습니다", action + "\n" + detail +
                "\n\n앱 내부 데이터를 유지했습니다. 이 메시지와 로그를 공유해 주세요.");
    }

    private void copyReport(){
        try {
            ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if(cm==null) throw new IllegalStateException("ClipboardManager unavailable");
            cm.setPrimaryClip(ClipData.newPlainText("Dolphin Interior Light Wizard V2.3", report()));
            toast("로그 복사 완료 · 공유 전 내용 확인");
        } catch(Throwable error) { safelyReportError("COPY_REPORT", error); }
    }

    private void shareReport(){
        try {
            writePrivateReport(report());
            Uri uri = Uri.parse("content://" + SHARE_AUTHORITY + "/latest");
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Dolphin Interior Light Wizard V2.3");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.setClipData(ClipData.newUri(getContentResolver(), "Dolphin JSON Log", uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "진단 리포트 파일 공유"));
        } catch(Throwable error) {
            record("EXPORT", "SHARE", exception(error), "SHARE_FAILED_PRIVATE_OK");
            showExportFallback(exception(error));
        }
    }
    private void toast(String msg){
        try { Toast.makeText(this,msg,Toast.LENGTH_LONG).show(); }
        catch (Throwable ignored) { /* optional platform UI */ }
    }
}
