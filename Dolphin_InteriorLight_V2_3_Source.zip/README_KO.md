# BYD Dolphin 실내등 One-Install Wizard V2.3 — 통합 빌드

- 기준: 한국형 BYD Dolphin Standard, Android 10 / 글로벌 2602 실차 검증 대상. **차량 기능 작동 여부는 미검증**.
- 이 APK는 독립 진단 앱(`com.dolphin.insidelightprobe`)이며 OEM Launcher3, SystemUI, 계기판이나 펌웨어를 대체·패치하지 않습니다.
- `versionCode=5`, `versionName=2.3.0-integrated-wizard`.

## 이번 통합본의 실제 변경
1. 이전 V2.2의 **기기/권한/설정/SystemUI 탐색, 후보 선택, 읽기 메서드 실제 호출, 4종 일괄 검사** 기능 유지.
2. V2.1의 **Android 10 MediaStore Downloads JSON 저장, 앱 내부 백업, 읽기 전용 파일 공유, 복사, 실패 시 오류 표시** 기능 유지.
3. 위험한 쓰기/제어 메서드는 임의 선택 실행 금지. `turnOffInsideLight(int)`는 BYD COMMON+SET 권한이 허용되고, 시그니처 확인 및 **정차·주차브레이크 사용자 직접 확인** 후 1회만 호출할 수 있도록 제한.
4. V2.3: OEM **제어 명령을 UI 스레드에서 백그라운드 스레드로 분리**. 8초 경과 시 안내하되 **기존 호출이 실제 반환되기 전까지 재전송하지 않도록 잠금**. 사용자가 관찰한 실물 점등·소등은 API 반환값과 별도 기록.
5. V2.3: 같은 메서드를 연속으로 누른 **중복 SELECT_METHOD 기록은 정리**. 이전 세션 선호값/160개 이벤트 자동 보존(`dolphin_wizard_v2`) 유지.
6. GitHub Actions YAML은 별도 파일로만 제공하며, 다른 저장소의 소스와 섞이지 않도록 `.dolphin-light-build`로 압축을 풀어 빌드.

## 실차 연구 결과 — 절대 과장 금지
- 사용자 제공 V2 실차 JSON: `BYDAutoSettingDevice`, `turnOffInsideLight(int)` 및 무인수 변형 존재, `insight_light_online=0` 조회 성공, BYD COMMON/GET/SET 권한 모두 false. `GETTER_VALUE_RETURNED` 및 `CONTROL_TRIAL`의 정상 완료 증거는 아직 없음.
- 순정 `InsightLightOnItem`에서는 `turnOffInsideLight(2)` 호출이 정적 바이트코드로 확인됨. `turnOffInsideLight(1)`은 선행 앱 명세·추정 경로이므로 전체 소등 성공으로 단정하지 않음.
- 순정 `getInitInsightLightOnlineState`: `insight_light_online == 0` + `isCanFd == true` 조건. `isCanFd`의 실차값은 UNKNOWN. 설정값을 강제로 바꾸지 않음.
- `com.android.systemui.overlay.common`은 OEM 제어 코드 APK라고 볼 수 없으므로 코드 후보/리소스 오버레이를 별도 취급.
- 차량 앱의 메서드 메타데이터 존재와 차량 하드웨어 실작동, 외부 앱 권한 취득은 전혀 다름.

## GitHub에 업로드하는 **2개 파일**
1. **저장소 루트**: `Dolphin_InteriorLight_V2_3_Source.zip` 업로드. 압축 **해제 금지**.
2. **.github/workflows/build-apk.yml**: 별도로 제공한 `build-apk.yml` 파일 그대로 업로드(기존 파일 교체).

기존 `Dolphin_InteriorLight_V2_2_Source.zip`은 남겨도 이 YAML이 빌드하지 않습니다. 혼동 방지를 위해 예전 빌드 ZIP과 구버전 워크플로는 사용자 판단으로 정리할 수 있으나 다른 프로젝트 파일은 삭제하지 마세요.

`Actions → Build Dolphin Interior Light V2.3 Integrated → Run workflow`를 누르면 정적 검사·Java 파서·Android SDK 35·Gradle 8.9·`:app:assembleDebug` 순으로 진행합니다. 성공 시 Artifact `Dolphin-InteriorLight-V2-3-Integrated-APK`에서 `app-debug.apk`와 SHA256을 받습니다. 실패 시 `Dolphin-InteriorLight-V2-3-Build-Diagnostics`를 다운로드하여 제공하세요.

## 차량 시험(정차)
1. `1 환경 → 모든 핵심 항목 1회 연속 검사 (읽기 전용)`.
2. `2 후보 → OEM`에서 Getter 1~2개를 실제 실행하고 반환값/거부 오류 확인.
3. `4 결과 → 로그 저장`으로 `Downloads/DolphinLightLogs/*.json` 생성. 저장 실패 시 앱 내부 백업 + **로그 파일 공유** 또는 **진단 리포트 복사**.
4. 차량 실내등 점등·소등 명령은 OEM COMMON·SET 권한이 명시적으로 GRANTED되기 전까지 잠겨야 합니다. 권한 우회나 CAN 명령은 제공하지 않음.
5. 빌드마다 GitHub 기본 디버그 키가 달라지면 덮어쓰기 설치 불가할 수 있습니다. 이전 로그를 내보낸 다음 필요한 경우에만 구버전 제거하세요. 동일 앱을 삭제하면 내부 저장 데이터가 사라질 수 있습니다.

## 검증 수준
로컬 정적 35/35 PASS, 자바 파서 2/2 PASS, YAML/XML 파싱, ZIP CRC 확인. **실제 Android SDK/Gradle 컴파일과 실차 점등·소등은 아직 확인되지 않았습니다.**
