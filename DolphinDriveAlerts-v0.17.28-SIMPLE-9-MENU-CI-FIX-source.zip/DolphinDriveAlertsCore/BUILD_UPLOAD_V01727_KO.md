# v0.17.27 GitHub 빌드 안내

1. `DolphinDriveAlerts-v0.17.27-REALCAR-MODE-NAV-CAPTURE-source.zip`을 저장소 최상위에 업로드.
2. `build-v01727-realcar-mode-nav-capture.yml`을 `.github/workflows/`에 업로드.
3. Actions → **Build Dolphin Drive Alerts v0.17.27 Three-State Mode + Nav Audio Capture Trial** → Run workflow.
4. Edge TTS 7.3.1 WAV 60개 생성/검증 후 Android Gradle compile/assemble와 APK 서명 검사를 통과해야 Artifact 업로드.
5. 기존 앱 설정 보존하려면 최초 설치 때 사용한 **같은** `DOLPHIN_DEBUG_KEYSTORE_B64` GitHub Secret 사용. 개인키는 공개 저장소에 업로드 금지. Secret이 없을 때는 임시 서명 새 설치만 가능하며 후속 덮어쓰기 불가.
6. Android API 29, 서명키 같으면 versionCode 52→53 덮어 설치. 삭제하면 기존 데이터 복구 불가 가능성.
7. 자체 주행모드 로그 리플레이는 성공했으나 실차 음성·내비 5종 운전석 기능은 미검증.
