# v0.17.24 주차 상태 통합 실차 테스트

| ID | 시험 | 성공 기준 | 로그 표시 |
|---|---|---|---|
| MODE-1 | 순정 ECO / NORMAL / SPORT 각각 선택하고 앱에서 기록 | 서로 다른 3개 상태 서명, "구별 가능" 표시 | `MODE_CALIBRATED_TRANSITION` |
| MODE-2 | ECO→NORMAL→SPORT→ECO 반복 | 모드마다 해당 음성 한 번, 중복·오발화 0 | `MODE_RAW_SUPPRESSED_BY_CALIBRATION` |
| MODE-3 | 동일한 신호로 세 모드 구별 불가인 경우 | 명확한 "구별 불가" 표시, NORMAL 임의 발화 없음 | `NORMAL_READBACK_PROBE` |
| BSD-1 | 실제 후측방 감지 + 좌측 깜박이 | 일반 "후측방 조심" 1회 | `BSD_GATE_ACCEPTED` |
| BSD-2 | 실제 후측방 감지 + 우측 깜박이 | 일반 "후측방 조심" 1회 | `BSD_GATE_ACCEPTED` |
| BSD-3 | 깜박이만 / BSD만 | 모드 설정에 따라 침묵 | `BSD_GATE_SUPPRESSED` |
| BSD-4 | 비상등(안전한 환경에서 확인) | 클릭음 후보가 비상등과 혼동되는지 별도 확인. 미검증이면 기능 사용 중단 | `TURN_SOUND_CADENCE_CANDIDATE` |
| SPLIT-1 | 서로 다른 앱 두 개 20:80 | 두 앱 유지 + 실제 경계 이동 | `RATIO_READBACK`, `RATIO_COMMAND`, `RATIO_OBSERVED` |
| SPLIT-2 | 70:30 재적용 | 새 APK 없이 실제 경계 이동 | 위와 동일 |
| SPLIT-3 | 순정 360/다른 앱 후 복귀 | 두 앱 및 기존 비율 유지 | `SPLIT_POST_RATIO_TASKS` |

원시 로그에는 차량 민감한 세부 정보가 들어갈 수 있으니 공유 전 확인하세요. 무리한 주행·타차 접근 시험 금지.
