# Dolphin Drive Alerts v0.17.21 — GitHub 수동 빌드

## 준비물

- `DolphinDriveAlerts-v0.17.21-NAV-AUDIO-LAB-CI-VOICE-FIX-source.zip`
- `build-v01721-from-source-zip.yml`

## 한 번 업로드 후 빌드

1. 저장소 `CP-oss-cell/dolphin-drive-alerts`의 **최상위(root)** 에 새 Source ZIP을 업로드한다.
2. YML을 `.github/workflows/build-v01721-from-source-zip.yml` 에 업로드한다.
3. GitHub **Actions → Build Dolphin Drive Alerts v0.17.21 Nav Audio Lab Voice CI Recovery APK → Run workflow**.
4. 기본 입력: `refresh_voice_assets=false`, `require_original_edge_voices=false`.
5. 음성 단계가 통과하고 `:app:compileDebugKotlin`, `:app:assembleDebug`, `apksigner verify`가 성공하면 `DolphinDriveAlerts-v0.17.21-NAV-AUDIO-LAB-CI-VOICE-FIX` Artifact에서 APK 받기.

## 음성 오류 대응

- 사용자 로그의 Edge 서버 403은 오디오 코드 에러가 아니라 온라인 음성 생성 단계 장애.
- 새로운 빌드는 기존 캐시가 있으면 60개 WAV 재사용. 없으면 Edge를 시도하다 403이면 gTTS 한국어 서비스로 대체 가능.
- gTTS 대체는 Edge Neural과 목소리가 다를 수 있다. **음성 프로필이 바뀌면 주행 전 정차한 상태에서 전 문구 청취·음량 확인 필요**.
- 원래 음성이 꼭 필요하면 `require_original_edge_voices=true` 실행. Edge 장애 중이면 오류로 중단하므로 APK를 제공하지 못할 수 있다.
- 캐시가 깨졌거나 음색을 다시 생성하려면 `refresh_voice_assets=true`로 한 번만 별도 실행.
- 두 TTS 서비스 모두 실패하면 무음 대체나 파일 누락을 허용하지 않고 실패를 명시한다.

## 보존 및 주의

- 기존 5종 NAV 오디오 실험실, Route 5/6 자체 테스트, BSD 공통 음성, 회전·EQ·분할 관련 기능을 제거하지 않았다.
- 5종 타사 내비 실제 오디오의 운전석 재라우팅은 아직 권한·구현 미확정이다.
- 앱 ID는 `com.byd.dolphin.drivealerts`이고 versionCode는 47. 기존 APK 설치 업데이트의 서명키가 다르면 업데이트 불가. 필요 시 GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64`를 **기존 키와 동일하게** 설정.
- 이번 패치에 대해 로컬 소스 검사만 완료, GitHub Android 컴파일과 실차 시험은 미확인.
