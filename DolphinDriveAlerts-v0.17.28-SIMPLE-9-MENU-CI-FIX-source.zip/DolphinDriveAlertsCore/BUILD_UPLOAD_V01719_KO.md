# 0.17.19 GitHub 빌드·설치 요령

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 루트에 `DolphinDriveAlerts-v0.17.19-LAUNCHER-EVOLUTION-REFERENCE-source.zip` 1개 업로드. 기존 소스 ZIP은 절대 삭제·덮어쓰기 금지.
2. `.github/workflows/build-v01719-from-source-zip.yml` 에 동봉 YML 업로드.
3. GitHub Actions → `Build Dolphin Drive Alerts v0.17.19 Launcher Evolution Reference APK` → `Run workflow`.
4. `Preflight`/voice generation/`compileDebugKotlin`/`assembleDebug`/`apksigner verify` 모두 성공 확인.
5. Artifact `DolphinDriveAlerts-v0.17.19-LAUNCHER-EVOLUTION-REFERENCE` 안의 APK 다운로드/설치. 실패 시 `build-failure-log` 수집.
6. 테스트 순서(주차/정차 상태): 화면 분할 앱 2개 확인→20:80→360 카메라 복귀 후 2개 앱 재확인; 시동 직후 미디어 지정 앱 재생과 `AUTO_SEQUENCE_SERVICE_ACK_ALREADY_DELIVERED`/`AUTO_SEQUENCE_DELIVERY_MISSING` 로그 확인; ECO→NORMAL→SPORT 원시값+실제 음성 대조; BSD 즉시 모드 보존 및 깜빡이+위험 음성 중복 여부 확인.
7. 기존 설치와 동일한 debug 서명키를 사용해야 업데이트 가능. 서명키 다르면 원본 APK/설정 백업 후 대응, 기계적 앱 삭제 금지. 문제시 기존 0.17.18 정상 설치본으로 복구.

이 소스 ZIP은 APK가 아님. CI 및 실차 성공을 주장하지 않음. `com.dolphin.launcher.v1`은 별도 앱이므로 Drive Alerts 설치는 그 런처를 교체하지 않음.
