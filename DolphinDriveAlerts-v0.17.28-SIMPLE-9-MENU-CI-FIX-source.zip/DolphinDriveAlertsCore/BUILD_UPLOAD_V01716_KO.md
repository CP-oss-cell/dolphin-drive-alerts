# GitHub 빌드 안내 — v0.17.16

1. [CP-oss-cell/dolphin-drive-alerts](https://github.com/CP-oss-cell/dolphin-drive-alerts) 저장소 루트에 `DolphinDriveAlerts-v0.17.16-TBT-NOTIFICATION-LOCATION-source.zip` 올리기.
2. `.github/workflows/build-v01716-from-source-zip.yml` 경로로 YML 올리기.
3. GitHub Actions의 **Build Dolphin Drive Alerts v0.17.16 TBT Notification Location Permissions APK** → Run workflow.
4. `:app:compileDebugKotlin` 및 `:app:assembleDebug` 통과 후 APK Artifact `DolphinDriveAlerts-v0.17.16-TBT-NOTIFICATION-LOCATION.apk` 다운로드. 이전 설치 APK와 동일 서명이어야 업데이트 설치 가능.
5. 앱에서 지정 앱 ADB 권한 관리 → Dolphin Drive(알림 리스너) 및 내비 앱별 위치 권한 조회·명시적 적용.
6. `LOCATION_SERVICE`는 앱별 권한이 아닌 차량 전체 위치 스위치이며 별도 사용자 확인 후 ON 요청. 정책상 거부될 수 있음.

소스/정적·Kotlin 검사 통과와 Android CI/APK 생성/실차 검증을 구분하세요. 연결된 GitHub는 읽기 권한만 있으므로 원격 업로드·Actions 실행 안 함.
