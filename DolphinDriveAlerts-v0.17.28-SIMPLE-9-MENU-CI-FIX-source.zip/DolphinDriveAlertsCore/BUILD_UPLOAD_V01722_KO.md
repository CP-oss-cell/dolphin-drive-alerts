# Dolphin Drive Alerts v0.17.22 — GitHub 수동 빌드

1. `DolphinDriveAlerts-v0.17.22-AUDIO-ROUTE-NORMAL-VOICE-QUALITY-source.zip`를 `CP-oss-cell/dolphin-drive-alerts` 저장소의 최상위(root)에 업로드.
2. `build-v01722-from-source-zip.yml`를 `.github/workflows/build-v01722-from-source-zip.yml`로 업로드. (기존 v21 YML을 그대로 실행하지 말 것.)
3. GitHub Actions → `Build Dolphin Drive Alerts v0.17.22 Sound and Normal Evidence Recovery APK` → Run workflow.
4. 입력 `voice_mode`:
   - `effects_only` (기본): 원래 남녀 목소리를 갖고 있지 않은 상태에서 빌드를 반드시 진행할 수 있는 검사용. **남녀 말소리 대신 효과음으로 안내**. 성별이 뒤바뀐 gTTS는 절대 포함하지 않음.
   - `neural_only`: `ko-KR-InJoonNeural`(남성), `ko-KR-SunHiNeural`(여성) 60개만 허용. 60개 검증 원본 팩이 없다면 Edge 서버에 생성 요청; 403/네트워크 차단 때는 **실패 처리**. 새 가짜 대체 음성 사용 금지.
   - 원본 60개 WAV와 `voice_pack_manifest.generated.json`이 있으면 `DolphinDriveAlerts-verified-neural-voices.zip`으로 압축해 리포지토리 root에 추가하면 검증 후 재사용. zip 내부에는 `male/...`, `female/...`, `voice_pack_manifest.generated.json`이 있어야 함.
5. Actions Artifact에서 APK 다운로드. Android Gradle 미실행 환경이므로 GitHub CI 성공 이전 APK 성공 주장 금지.

## 정차(P) 실차 단일 설치 시험
1. 오디오 실험실 → Route 6 및 Route 5 각각 '시험음 재생'. 먼저 기존 성공 운전석 스트림을 확인.
2. MEDIA STREAM_MUSIC, MEDIA AudioAttributes 각각 재생. 무음일 경우 음량 로그(0/max), `preState/postState`, `written`, `head`를 ZIP에 기록. **안 들려도 성공으로 표시하지 않음**.
3. ECO → NORMAL → SPORT로 전환. 정상 음성/효과음이 나오지 않아도 `NORMAL_READBACK_PROBE`, `NORMAL_READBACK_STABLE`, `REFERENCE_OPERATION_MODE` 로그를 남겨 실제 getter 반환을 확인. **NORMAL 개선은 실차 재확인 전까지 미검증**.
4. 성별 문제: effects_only는 시험용 효과음뿐, neural_only는 실제 남녀 구별을 청취 후 검증. 5종 내비 cross-UID 출력은 여전히 지원 보장 안 됨.
5. 통합 ZIP 내보내기하여 제공. 기존 정상 오토홀드, 회생제동, 기어, BSD 안내 회귀 점검.

APK 패키지 ID 유지 `com.byd.dolphin.drivealerts`, versionCode 48. 서명키가 이전 설치와 다르면 덮어쓰기 설치 불가. 전체 차량 순정 시스템은 건드리지 않음.
