# v0.17.22 — 실차 무음, NORMAL 및 음성 성별 오류 대응 (2026-10-14)

## 근거와 버그
- 사용자 실제 보고: v0.17.21 대체 TTS 남성은 외계인처럼, 여성은 남성처럼 들림; NORMAL 발화 없음; 신호/미디어 시험음 모두 무음.
- `NavRouteLabPlayer.kt`: `MODE_STATIC` AudioTrack의 데이터를 쓰기 전 정상 상태인 `STATE_NO_STATIC_DATA(2)`를 실패로 차단. **코드 결함 확인**, 음성 무음 현상을 설명하는 후보. 실제 실차 재검증 전 확정 원인이라고 단정하지 않음.
- `generate_voice_pack.py`: Edge 장애 시 여성/남성 모두 같은 `gTTS` 한국어 음성, 남성만 피치 조작. **성별 검증 없이 생성했음이 코드로 확정**. 오류 수정에서는 해당 방식을 사용하지 않음.
- `ReferenceVehicleEventBridge.kt`: NORMAL 후보 `raw=0`은 기존 실차 기록 0회. 사용자 제안 ECO OFF→NORMAL은 SPORT OFF도 입증돼야 하므로 단순 ECO 미수신 기반 추정 금지.

## 변경 내용
- `NavRouteLabPlayer.kt`: `STATE_NO_STATIC_DATA`는 write 전 허용, write 후 `STATE_INITIALIZED` 검증. 미디어 직접 STREAM_MUSIC과 AudioAttributes 미디어를 분리 시험, 1.2초 톤/음량 증가, 실제 playback head·stream volume·routedDevice 로깅. 성공 반환은 API 요청 성공일 뿐 실제 들렸다는 뜻 아님.
- `NavAudioLabActivity.kt`: 기본 후보 Route 6 인덱스 수정, 시험 1.2초 반영, Neural 음성 부재 경고.
- `NormalModeReadbackGate.kt`, `ReferenceVehicleEventBridge`, `DrivingAlertService`: 1.2초마다 순정 Energy `getOperationMode()` 읽기 전용 폴링. 부수 getter 충돌이 없고 `raw0`가 3회 연속 관찰되며 직전 ECO(1) 또는 SPORT(2)가 확인된 경우에만 NORMAL 신호 출력. 이벤트 소실·초기 상태 등은 발화하지 않음. 2602 raw0/실제 NORMAL 대응은 아직 미확인.
- 음성팩: `gTTS` 남녀 변조 생성·캐시 사용 차단. `neural_only`는 원본 Edge 남녀 60개 WAV의 음성 종류/문구/SHA 검증 필요. `effects_only`는 음성파일이 없다면 무음 또는 가짜 성별 음성 대신 명시적으로 효과음 방식 출력. 이는 인간 음성 복구가 아니라 임시 진단 선택지임.
- 다른 앱 5종의 실제 오디오를 cross-UID로 운전석 채널에 재라우팅하는 기능은 미구현 그대로 표시. 차량 MCU/ADAS/AVAS 쓰기 변경 없음.

## 검증 상태
- 신규 소스 가드 및 NORMAL 순수 Kotlin gate 실행 PASS 18/18.
- 기존 v0.17.20 오디오 실험실 정적 가드 PASS 21/21.
- 기존 v0.17.19 런처 참조 정적 가드 PASS 16/16; v0.17.18 참고검사 PASS.
- YAML 구문/쉘 구문/ZIP CRC 검증, Android Gradle APK 빌드·실차 소리 검증 미실행.
- 기록: DA-003/005 NORMAL, DA-009/010 오디오, DA-013 음성 생성 빌드. 기존 DA-007 BSD 일반 '후측방 조심' 유지.
