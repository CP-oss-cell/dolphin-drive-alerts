#!/usr/bin/env python3
"""Compile and run the actual pure Kotlin lab evaluator."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s=r/'app/src/main/java/com/byd/dolphin/drivealerts/audio/NavRouteEvidence.kt'
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)
 (p/'Main.kt').write_text('''import com.byd.dolphin.drivealerts.audio.NavRouteEvidence
fun main() {
  check(NavRouteEvidence.classify(false,true,true).contains("BLOCKED"))
  check(NavRouteEvidence.classify(true,false,true).contains("ADB_REQUIRED"))
  check(NavRouteEvidence.classify(true,true,true).contains("NOT_IMPLEMENTED"))
  check(NavRouteEvidence.classify(true,true,false).contains("NOT_VERIFIED"))
  val rows=NavRouteEvidence.relevantLines("status clean\\nUID=90 stream=14\\noutput=BUS\\nignored text",50)
  check(rows.size==2 && rows[0].contains("UID") && rows[1].contains("BUS"))
  println("NAV_AUDIO_EVIDENCE_KOTLIN_RUNTIME_PASS")
}''')
 subprocess.run(['kotlinc',str(s),str(p/'Main.kt'),'-include-runtime','-d',str(p/'a.jar')],check=True,capture_output=True,text=True)
 t=subprocess.run(['java','-jar',str(p/'a.jar')],check=True,capture_output=True,text=True)
 assert 'PASS' in t.stdout
 print(t.stdout.strip())
