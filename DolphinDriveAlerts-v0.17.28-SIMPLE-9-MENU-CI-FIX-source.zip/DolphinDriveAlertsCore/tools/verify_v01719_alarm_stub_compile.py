#!/usr/bin/env python3
"""Compile real production AlarmReceiver with local Android test doubles; not Android SDK/real-car."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/byd/dolphin/drivealerts/automation/IgnitionSequenceAlarmReceiver.kt'
files={
'Context.kt':'''package android.content
open class Context {
 companion object { const val MODE_PRIVATE=0; const val ALARM_SERVICE="alarm" }
 val applicationContext:Context get()=this
 private val prefs=mutableMapOf<String,SharedPreferences>()
 val alarm=android.app.AlarmManager()
 fun getSharedPreferences(k:String,flags:Int):SharedPreferences=prefs.getOrPut(k){SharedPreferences()}
 fun getSystemService(k:String):Any?=if(k==ALARM_SERVICE) alarm else null
}
class SharedPreferences {
 private val longs=mutableMapOf<String,Long>();private val bools=mutableMapOf<String,Boolean>()
 fun getLong(k:String,def:Long)=longs[k]?:def
 fun getBoolean(k:String,def:Boolean)=bools[k]?:def
 inner class Editor {
  fun putLong(k:String,v:Long):Editor {longs[k]=v;return this}
  fun putBoolean(k:String,v:Boolean):Editor {bools[k]=v;return this}
  fun commit()=true
 }
 fun edit()=Editor()
}
open class BroadcastReceiver { open fun onReceive(context:Context,intent:Intent?){} }
class Intent(c:Context,t:Class<*>) {
 var action:String?=null;private val extras=mutableMapOf<String,Long>()
 fun setAction(a:String):Intent {action=a;return this}
 fun putExtra(k:String,v:Long):Intent {extras[k]=v;return this}
 fun getLongExtra(k:String,default:Long)=extras[k]?:default
}
''',
'Alarm.kt':'''package android.app
class PendingIntent { companion object { const val FLAG_UPDATE_CURRENT=1;const val FLAG_IMMUTABLE=2; fun getBroadcast(c:android.content.Context,id:Int,i:android.content.Intent,flags:Int)=PendingIntent() } }
class AlarmManager {
 companion object {const val ELAPSED_REALTIME_WAKEUP=2}
 var scheduled=0;var cancelled=0
 fun setAndAllowWhileIdle(kind:Int,whenMs:Long,pi:PendingIntent){scheduled++}
 fun cancel(pi:PendingIntent){cancelled++}
}
''',
'SystemClock.kt':'''package android.os
object SystemClock {var now=20000L;fun elapsedRealtime()=now++}
''',
'Dependencies.kt':'''package com.byd.dolphin.drivealerts.automation
object FeatureProfiles {fun sequenceEnabled(c:android.content.Context)=true}
object AutoLaunchSequenceService {var calls=0;fun start(c:android.content.Context){calls++}}
''',
'CoreLog.kt':'''package com.byd.dolphin.drivealerts.util
object CoreLog {fun i(k:String,s:String){};fun w(k:String,s:String){} }
''',
'Test.kt':'''import com.byd.dolphin.drivealerts.automation.*
import android.content.*
import android.os.SystemClock
fun main() {
 val c=Context();val receiver=IgnitionSequenceAlarmReceiver()
 c.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE).edit().putBoolean("armed",false).commit()
 IgnitionSequenceAlarmReceiver.schedule(c)
 check(c.alarm.scheduled==1)
 var t=c.getSharedPreferences("ignition_sequence_delivery_v01719",0).getLong("requested",-1L)
 val event=Intent(c,IgnitionSequenceAlarmReceiver::class.java).setAction("com.byd.dolphin.drivealerts.IGNITION_SEQUENCE_DELIVERY_CHECK").putExtra("request_elapsed",t)
 IgnitionSequenceAlarmReceiver.acknowledge(c)
 receiver.onReceive(c,event)
 check(AutoLaunchSequenceService.calls==0)
 SystemClock.now+=100L
 IgnitionSequenceAlarmReceiver.schedule(c)
 t=c.getSharedPreferences("ignition_sequence_delivery_v01719",0).getLong("requested",-1L)
 receiver.onReceive(c,Intent(c,IgnitionSequenceAlarmReceiver::class.java).setAction("com.byd.dolphin.drivealerts.IGNITION_SEQUENCE_DELIVERY_CHECK").putExtra("request_elapsed",t))
 check(AutoLaunchSequenceService.calls==1)
 IgnitionSequenceAlarmReceiver.schedule(c)
 t=c.getSharedPreferences("ignition_sequence_delivery_v01719",0).getLong("requested",-1L)
 IgnitionSequenceAlarmReceiver.cancel(c)
 receiver.onReceive(c,Intent(c,IgnitionSequenceAlarmReceiver::class.java).setAction("com.byd.dolphin.drivealerts.IGNITION_SEQUENCE_DELIVERY_CHECK").putExtra("request_elapsed",t))
 check(AutoLaunchSequenceService.calls==1)
 check(c.alarm.cancelled==1)
 println("PASS: V01719 ALARM RECEIVER COMPILED AND TARGET ACK/RETRY/CANCEL FIXTURE")
}'''
}
with tempfile.TemporaryDirectory() as tmp:
 d=Path(tmp)
 for n,s in files.items():(d/n).write_text(s)
 subprocess.run(['kotlinc',str(source),*[str(d/n) for n in files],'-include-runtime','-d',str(d/'test.jar')],check=True,timeout=60,stdout=subprocess.DEVNULL)
 subprocess.run(['java','-jar',str(d/'test.jar')],check=True,timeout=15)
