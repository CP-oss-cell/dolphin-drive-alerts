#!/usr/bin/env python3
"""Compile and execute REAL production Kotlin split parsers against reconstructed DiLink 3 fixtures."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts/automation'
code=r'''package com.byd.dolphin.drivealerts.automation
fun main() {
    val raw="""Stack #1: ActivityStack{a mWindowingMode=split-screen-primary}
TaskRecord{aaa #17 A=com.example.music U=0}
  ActivityRecord{bbb com.example.music/.Main}
Stack #2: ActivityStack{b mWindowingMode=split-screen-secondary}
TaskRecord{ccc #28 A=com.example.video U=0}
 ActivityRecord{eee com.example.video/.Main}
"""
    val primary=LegacySplitTaskLocator.findTask(raw,"com.example.music")
    val secondary=LegacySplitTaskLocator.findTask(raw,"com.example.video")
    check(primary==LegacySplitTaskLocator.State(17,1,3)) { "primary=$primary" }
    check(secondary==LegacySplitTaskLocator.State(28,2,4)) { "secondary=$secondary" }
    check(LegacySplitTaskLocator.findStack(raw,4)==2)
    val bounds="""Stack id=1 bounds=[0,0][251,720]
 mWindowingMode=split-screen-primary mActivityType=standard
Stack id=2 bounds=[257,0][1280,720]
 mWindowingMode=split-screen-secondary mActivityType=standard
"""
    val pair=SplitGeometry.parse(bounds) ?: error("bounds missing")
    check(SplitGeometry.percent(pair)==20) { "percent=${SplitGeometry.percent(pair)}" }
    check(SplitGeometry.resize(pair,20)?.command=="am stack resize-docked-stack 0 0 255 720 0 0 255 720")
    check(SplitGeometry.resize(pair,80)?.command=="am stack resize-docked-stack 0 0 1019 720 0 0 1019 720")
    check(SplitGeometry.parse("Stack id=1 bounds=[0,0][640,720]")==null)
    check(SplitGeometry.resize(SplitGeometry.PairBounds(SplitGeometry.Rect(0,0,640,720), SplitGeometry.Rect(0,0,640,720)),20)==null)
    println("PASS split legacy task / stack / independent bounds / 20:80 / 80:20 / false-positive guards")
}
'''
with tempfile.TemporaryDirectory() as tmp:
    q=Path(tmp); (q/'Test.kt').write_text(code)
    cmd=['kotlinc', str(src/'LegacySplitTaskLocator.kt'),str(src/'SplitGeometry.kt'), str(q/'Test.kt'),'-include-runtime','-d',str(q/'test.jar')]
    subprocess.run(cmd,check=True,timeout=90)
    subprocess.run(['java','-jar',str(q/'test.jar')],check=True,timeout=20)
# Guard the original reference flow's prerequisite to prevent future reversion.
engine=(src/'VehicleSplitEngine.kt').read_text()
media=(src/'AutoLaunchSequenceService.kt').read_text()
assert 'SplitGhostActivity' in engine and 'am stack move-task' in engine
assert 'SplitGeometry.resize(bounds,pct)' in engine and 'taskEvidence.hasDefinitiveMismatch' in engine
assert 'MEDIA_COLD_RETRY' in media and 'MediaPlaybackObserver.play(this,step.packageName)' in media
assert 'noActivityLaunched=true' not in media
assert 'com.byd.dolphin.drivealerts' in (root/'app/build.gradle.kts').read_text()
print('PASS reference recovery source regression gates')
