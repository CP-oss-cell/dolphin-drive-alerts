#!/usr/bin/env python3
"""v0.17.15 source-contract and actual Kotlin JVM checks. Does not replace Android/vehicle tests."""
import pathlib, subprocess, shutil, tempfile, textwrap, re, sys, zipfile
p=pathlib.Path(__file__).resolve().parents[1]
src=p/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda file:(src/file).read_text()
checks={
    'version_42_or_later': bool(re.search(r'versionCode\s*=\s*(4[2-9]|[5-9]\d|\d{3,})\b', (p/'app/build.gradle.kts').read_text())),
    'read_only_indicator': 'getLeftTurnLightState' in read('vehicle/TurnSignalReadback.kt') and 'hazardSide=UNKNOWN' in read('vehicle/TurnSignalReadback.kt') and 'getRightTurnState' in read('vehicle/TurnSignalReadback.kt'),
    'indicator_exception_reasons': 'noCallableGetter' in read('vehicle/TurnSignalReadback.kt') and 'nonNumeric=' in read('vehicle/TurnSignalReadback.kt'),
    'no_unverified_turn_sound_gate': ('NOT_USED_FOR_BSD_GATE' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'TURN_SOUND_CORRELATION_ONLY' in read('vehicle/ReferenceVehicleEventBridge.kt')) or ('UNVERIFIED_TURN_CLICK_CADENCE' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'linkLockBsdDecoder.isActive() && turnSoundCadence.probableActive' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'hazardsNotSeparatelyVerified' in read('vehicle/TurnSoundCadence.kt')),
    'normal_readback_without_cycle_guess': 'getOperationModeState' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'noBlindCycleInference=true' in read('vehicle/ReferenceVehicleEventBridge.kt'),
    'bsd_generic_voice_preserved': 'announceGenericBsd("BLINKER_ANY_SIDE;' in read('vehicle/ReferenceVehicleEventBridge.kt'),
    'single_alert_latch_preserved': 'announced = true' in read('vehicle/BsdAlertDecision.kt'),
    'adb_first_run_preserved': 'waitForAuthorization(' in read('dpi/NativeAdbClient.kt'),
    'split_first_second_commands': (('SPLIT_START_PRIMARY' in read('automation/VehicleSplitEngine.kt') and 'SPLIT_START_SECONDARY' in read('automation/VehicleSplitEngine.kt')) or ('PRIMARY_COLD' in read('automation/VehicleSplitEngine.kt') and 'SECONDARY_START' in read('automation/VehicleSplitEngine.kt') and 'PRIMARY_MOVE' in read('automation/VehicleSplitEngine.kt'))),
    'split_task_verified': ('taskEvidence.verified' in read('automation/VehicleSplitEngine.kt') or ('taskEvidence.hasDefinitiveMismatch' in read('automation/VehicleSplitEngine.kt') and 'primaryTask.taskId==secondaryTask.taskId' in read('automation/VehicleSplitEngine.kt'))) and 'firstTaskIds=' in read('automation/SplitTaskReadback.kt'),
    'split_no_self_app': 'profile.secondPackage == c.packageName' in read('automation/VehicleSplitEngine.kt'),
    'split_bounds_readback': ('SplitBoundsReadback.primaryPercent' in read('automation/VehicleSplitEngine.kt') or ('SplitGeometry.parse' in read('automation/VehicleSplitEngine.kt') and 'SplitGeometry::percent' in read('automation/VehicleSplitEngine.kt'))),
    'zip_staging_and_verify': 'verifyCompleteZip(staged)' in read('log/UnifiedLogCapture.kt') and 'ZipInputStream' in read('log/UnifiedLogCapture.kt') and 'ZipFile(file)' in read('log/UnifiedLogCapture.kt'),
    'zip_pending_remains': 'MediaStore.MediaColumns.IS_PENDING' in read('log/UnifiedLogCapture.kt'),
    'log_version': 'appVersionName' in read('log/UnifiedLogCapture.kt'),
    'dedup_preserves_transitions': 'previous.first == value' in read('log/RawSignalLogger.kt') and 'isBuzzer || isTimestamp' in read('log/RawSignalLogger.kt'),
    'other_raw_not_dropped': 'source == "reference.setting" && eventType == 0x99000198.toInt()' in read('log/RawSignalLogger.kt'),
    'eq_preserved': 'EQ 미세 강화' in read('ui/AudioTuningActivity.kt'),
    'idas_readonly': 'eventMeaningUnverified=true;iccConfirmed' in read('vehicle/ReferenceVehicleEventBridge.kt'),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()),'static contract failure'
if '--static-only' in sys.argv:
 print(f'V01715_SOURCE={sum(checks.values())}/{len(checks)}')
 sys.exit(0)
if not shutil.which('kotlinc'):
 print('Kotlin compiler unavailable: Android Gradle gate required')
 sys.exit(0)
with tempfile.TemporaryDirectory(prefix='v01715-kotlin-') as t:
 t=pathlib.Path(t)
 def put(name,data):
  x=t/name;x.parent.mkdir(parents=True,exist_ok=True);x.write_text(textwrap.dedent(data));return str(x)
 def run(sources,main):
  jar=t/'run.jar'
  c=subprocess.run(['kotlinc',*sources,main,'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=100)
  assert c.returncode==0,c.stdout+c.stderr
  c=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
  assert c.returncode==0,c.stdout+c.stderr
  print(c.stdout.strip())
 # Verify exact production split task parser, not a rewrite.
 split=str(src/'automation/SplitTaskReadback.kt')
 runner=put('SplitTest.kt','''
   import com.byd.dolphin.drivealerts.automation.SplitTaskReadback
   fun main() {
     val good="Task{a #17 windowingMode=3 com.alpha/.Main}\\nTask{b #18 windowingMode=4 com.beta/.Main}"
     val x=SplitTaskReadback.inspect(good,"com.alpha","com.beta")
     check(x.verified && !x.hasDefinitiveMismatch) {x.toString()}
     check(!SplitTaskReadback.inspect("Task{a #17 windowingMode=3 com.alpha com.beta}","com.alpha","com.beta").verified)
     check(!SplitTaskReadback.inspect("Task{a #17 windowingMode=1 com.alpha}\\nTask{b #18 windowingMode=1 com.beta}","com.alpha","com.beta").verified)
     check(!SplitTaskReadback.inspect("Task{a #17 com.alpha}\\nTask{b #18 com.beta}","com.alpha","com.beta").verified)
     println("SPLIT_ACTUAL_KOTLIN=4/4 PASS")
   }
 ''')
 run([split],runner)
 # Exact turn signal probe with in-memory fake SDK device used only in test.
 mock=[put('android/content/Context.kt','''
 package android.content
 open class Context { val applicationContext:Context get()=this }
 '''),put('com/byd/dolphin/drivealerts/vehicle/BydPermissionContext.kt','''
 package com.byd.dolphin.drivealerts.vehicle
 import android.content.Context
 object BydPermissionContext { fun wrap(c:Context)=c }
 '''),put('com/byd/dolphin/drivealerts/model/Side.kt','''
 package com.byd.dolphin.drivealerts.model
 enum class Side { LEFT, RIGHT, UNKNOWN }
 '''),put('android/hardware/bydauto/light/BYDAutoLightDevice.kt','''
 package android.hardware.bydauto.light
 import android.content.Context
 class BYDAutoLightDevice {
   companion object { var left=0;var right=0; @JvmStatic fun getInstance(c:Context)=BYDAutoLightDevice() }
   fun getLeftTurnLightState():Int=left
   fun getRightTurnLightState():Int=right
 }
 ''')]
 runner=put('TurnTest.kt','''
 import android.content.Context
 import android.hardware.bydauto.light.BYDAutoLightDevice as D
 import com.byd.dolphin.drivealerts.vehicle.TurnSignalReadback
 fun main() {
   val p=TurnSignalReadback(Context())
   D.left=1;D.right=0;check(p.read().anyBlinkerActive)
   D.left=0;D.right=1;check(p.read().anyBlinkerActive)
   D.left=1;D.right=1;check(!p.read().anyBlinkerActive)
   D.left=0;D.right=0;check(!p.read().anyBlinkerActive)
   println("TURN_SIGNAL_ACTUAL_KOTLIN=4/4 PASS")
 }
 ''')
 run([str(src/'vehicle/TurnSignalReadback.kt'),*mock],runner)
 # Real production ZIP CRC/completeness routine exercised with healthy and truncated archive.
 whole=read('log/UnifiedLogCapture.kt')
 a=whole.index('    private fun verifyCompleteZip(file: File) {')
 b=whole.index('    private fun export(',a)
 body=whole[a:b].replace('private fun verifyCompleteZip(', 'fun verifyCompleteZip(')
 testsrc='''import java.io.*\nimport java.util.zip.*\nobject CaptureContract {\n'''+body+'''\n}\n'''
 zipfix=put('CaptureContract.kt',testsrc)
 runner=put('ZipTest.kt','''
 import java.io.File
 import java.util.zip.ZipOutputStream
 import java.util.zip.ZipEntry
 fun main() {
   val f=File.createTempFile("test-recording-", ".zip")
   ZipOutputStream(f.outputStream()).use {z->
     listOf("session.json","lifecycle/capture_continuity.json","logs/vehicle_events.jsonl").forEach {name->
       z.putNextEntry(ZipEntry(name));z.write("\\"".repeat(250).toByteArray());z.closeEntry()
     }
   }
   CaptureContract.verifyCompleteZip(f)
   val truncated=File.createTempFile("test-broken-", ".zip")
   truncated.writeBytes(f.readBytes().dropLast(22).toByteArray())
   check(runCatching{CaptureContract.verifyCompleteZip(truncated)}.isFailure)
   f.delete();truncated.delete()
   println("ZIP_ACTUAL_KOTLIN=2/2 PASS")
 }
 ''')
 run([zipfix],runner)
print(f'V01715_VALIDATION={len(checks)}/{len(checks)} static + Kotlin tests PASS; Android/full-car NOT RUN')
