#!/usr/bin/env bash
# Usage: verify_apk_upgrade.sh OLD_INSTALLED_APK NEW_APK
set -euo pipefail
[ "$#" -eq 2 ] || { echo 'Usage: verify_apk_upgrade.sh installed.apk new.apk'; exit 2; }
OLD="$1"; NEW="$2"
for f in "$OLD" "$NEW"; do [ -f "$f" ] || { echo "missing file: $f"; exit 2; }; done
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
APKSIGNER="$ANDROID_SDK_ROOT/build-tools/34.0.0/apksigner"
AAPT="$ANDROID_SDK_ROOT/build-tools/34.0.0/aapt"
cert() { "$APKSIGNER" verify --print-certs "$1" | sed -n 's/^Signer #1 certificate SHA-256 digest: //p' | head -1 | tr -d '[:space:]:' | tr '[:lower:]' '[:upper:]'; }
pkgcode() { "$AAPT" dump badging "$1" | head -1; }
OLD_CERT="$(cert "$OLD")"; NEW_CERT="$(cert "$NEW")"
OLD_BADGE="$(pkgcode "$OLD")"; NEW_BADGE="$(pkgcode "$NEW")"
for B in "$OLD_BADGE" "$NEW_BADGE"; do echo "$B" | grep -F "name='com.byd.dolphin.drivealerts'" >/dev/null || { echo 'Package mismatch'; exit 1; }; done
[ -n "$OLD_CERT" ] && [ "$OLD_CERT" = "$NEW_CERT" ] || { echo 'SIGNATURE MISMATCH: In-place update NOT possible. DO NOT uninstall existing app.'; exit 1; }
old_code=$(echo "$OLD_BADGE" | sed -n "s/.*versionCode='\([0-9][0-9]*\)'.*/\1/p")
new_code=$(echo "$NEW_BADGE" | sed -n "s/.*versionCode='\([0-9][0-9]*\)'.*/\1/p")
[ -n "$old_code" ] && [ -n "$new_code" ] && [ "$new_code" -ge "$old_code" ] || { echo 'Version is lower than installed'; exit 1; }
echo "UPDATE COMPATIBLE: package / cert match, installed=$old_code new=$new_code"
