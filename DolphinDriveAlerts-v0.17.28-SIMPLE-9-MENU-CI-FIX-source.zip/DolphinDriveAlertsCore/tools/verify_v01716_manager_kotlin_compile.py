#!/usr/bin/env python3
"""Compile actual production SelectedAppPermissionManager against minimal Android API stubs.
No system permission, vehicle, or real ADB actions are performed.
"""
from pathlib import Path
import subprocess, shutil, tempfile, textwrap
p=Path(__file__).resolve().parents[1] /'app/src/main/java/com/byd/dolphin/drivealerts/dpi'
if not shutil.which('kotlinc'):
 print('KOTLINC_UNAVAILABLE; Android Gradle compile required');raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='v01716-manager-') as t:
 t=Path(t)
 def put(n,s):
  f=t/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(textwrap.dedent(s));return str(f)
 stubs=[put('android/content/Android.kt', '''
  package android.content
  import android.content.pm.PackageManager
  open class Context {
    val applicationContext:Context get()=this
    val packageManager=PackageManager()
    val packageName="com.byd.dolphin.drivealerts"
  }
  class Intent(action:String) { fun setPackage(pkg:String):Intent=this }
  class ComponentName(val pkg:String,val cls:String) { fun flattenToString():String="$pkg/$cls" }
 '''),put('android/content/pm/PM.kt', '''
  package android.content.pm
  class ApplicationInfo {val packageName="com.byd.dolphin.drivealerts";val enabled=true}
  class PackageInfo { val requestedPermissions:Array<String>? = arrayOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_BACKGROUND_LOCATION") }
  class ServiceInfo { val packageName="com.test";val name="com.test.Service" }
  class ResolveInfo { val serviceInfo:ServiceInfo? = ServiceInfo() }
  class PackageManager {
    companion object { const val GET_PERMISSIONS=4096 }
    fun getApplicationInfo(name:String, flags:Int):Any=Any()
    fun getInstalledApplications(flags:Int):List<ApplicationInfo> = listOf(ApplicationInfo())
    fun getApplicationLabel(info:ApplicationInfo):CharSequence="Dolphin Drive"
    fun getPackageInfo(name:String, flags:Int)=PackageInfo()
    fun queryIntentServices(intent:android.content.Intent,flags:Int):List<ResolveInfo> = listOf(ResolveInfo())
  }
 '''),put('android/os/Build.kt', '''
  package android.os
  object Build { object VERSION { const val SDK_INT=29 } }
  class Bundle
 '''),put('com/byd/dolphin/drivealerts/dpi/NativeAdbClient.kt', '''
  package com.byd.dolphin.drivealerts.dpi
  import android.content.Context
  object NativeAdbClient {
    data class ShellResult(val success:Boolean,val output:String,val message:String)
    fun executeShell(c:Context,cmd:String,timeoutMs:Long):ShellResult = when {
      cmd=="cmd location is-location-enabled" -> ShellResult(true,"true","")
      cmd.startsWith("dumpsys package") -> ShellResult(true,"android.permission.ACCESS_COARSE_LOCATION: granted=true\\nandroid.permission.ACCESS_FINE_LOCATION: granted=true\\nandroid.permission.ACCESS_BACKGROUND_LOCATION: granted=true","")
      cmd.startsWith("settings get secure") -> ShellResult(true,"com.test/com.test.Service","")
      cmd.startsWith("appops get") -> ShellResult(true,"allow","")
      else -> ShellResult(true,"","")
    }
  }
 '''),put('com/byd/dolphin/drivealerts/dpi/AuthorizedAdbRuntime.kt', '''
  package com.byd.dolphin.drivealerts.dpi
  import android.content.Context
  object AuthorizedAdbRuntime {
    data class Report(val result:NativeAdbClient.ShellResult,val state:String)
    fun awaitReady(c:Context,maxWaitMs:Long):Report=Report(NativeAdbClient.ShellResult(true,"",""),"READY")
  }
 '''),put('Test.kt', '''
  import com.byd.dolphin.drivealerts.dpi.SelectedAppPermissionManager as P
  import android.content.Context
  fun main() {
    val actions=setOf(P.Action.LOCATION_FOREGROUND,P.Action.LOCATION_BACKGROUND,P.Action.LOCATION_SERVICE)
    val check=P.process(Context(),"com.nav.test",actions,false)
    kotlin.check(check.okCount==3 && check.attempted==3) {check.toString()}
    val applied=P.process(Context(),"com.nav.test",actions,true)
    kotlin.check(applied.okCount==3 && applied.attempted==3) {applied.toString()}
    println("V01716_SELECTED_APP_MANAGER_ACTUAL_KOTLIN=2/2 PASS")
  }
 ''')]

 stubs += [put('android/app/UI.kt', """
package android.app
import android.content.Context
import android.os.Bundle
open class Activity:Context() {
    protected open fun onCreate(savedInstanceState:Bundle?) {}
    fun setContentView(v:Any) {}
    fun startActivity(intent:android.content.Intent) {}
    fun runOnUiThread(action:Runnable) {action.run()}
}
class AlertDialog {
    class Builder(ctx:Context) {
      fun setTitle(s:String)=this
      fun setMessage(s:String)=this
      fun setPositiveButton(label:String, callback:((Any?,Int)->Unit)?)=this
      fun setNegativeButton(label:String, callback:((Any?,Int)->Unit)?)=this
      fun show() {}
    }
}
"""), put('android/widget/UI.kt', """
package android.widget
import android.content.Context
open class Widget(ctx:Context) {fun setPadding(l:Int,t:Int,r:Int,b:Int) {} }
class ScrollView(ctx:Context):Widget(ctx) {fun addView(v:Any) {} }
class LinearLayout(ctx:Context):Widget(ctx) {
    companion object {const val VERTICAL=1}
    var orientation=0
    fun addView(v:Any) {}
}
open class TextView(ctx:Context):Widget(ctx) {var text:String="";var textSize=0f}
class CheckBox(ctx:Context):TextView(ctx) {var isChecked=false}
class Spinner(ctx:Context):Widget(ctx) {var adapter:Any?=null;val selectedItemPosition:Int=0}
class ArrayAdapter(ctx:Context, layout:Int, values:List<String>)
class Button(ctx:Context):TextView(ctx) {fun setOnClickListener(callback:(Any)->Unit) {} }
"""), put('android/R.kt',"""package android
object R {object layout {const val simple_spinner_dropdown_item=1} }
"""),put('android/provider/Settings.kt',"""
package android.provider
object Settings { const val ACTION_NOTIFICATION_LISTENER_SETTINGS="notification";const val ACTION_LOCATION_SOURCE_SETTINGS="location" }
""")]
 jar=t/'runner.jar'
 args=['kotlinc',str(p/'SelectedAppPermissionManager.kt'),str(p/'AppPermissionRules.kt'),str(p.parent/'ui/AppPermissionManagerActivity.kt'),*stubs,'-include-runtime','-d',str(jar)]
 c=subprocess.run(args,capture_output=True,text=True,timeout=110)
 assert c.returncode==0,c.stdout+c.stderr
 c=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=25)
 assert c.returncode==0,c.stdout+c.stderr
 print(c.stdout.strip())
 print("V01716_PERMISSION_UI_ACTUAL_KOTLIN=COMPILE PASS")
