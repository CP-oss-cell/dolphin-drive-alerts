#!/usr/bin/env python3
"""One-install lab source gates; no real-car or cross-UID implementation claims."""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
src=r/'app/src/main/java/com/byd/dolphin/drivealerts'
ui=(src/'ui/NavAudioLabActivity.kt').read_text()
service=(src/'audio/NavRouteCaptureService.kt').read_text()
player=(src/'audio/NavRouteLabPlayer.kt').read_text()
status=(src/'audio/NavRouteEvidence.kt').read_text()
main=(src/'ui/MainActivity.kt').read_text()
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'version_compatible': (lambda m: bool(m) and int(m.group(1)) >= 46)(__import__('re').search(r'versionCode\s*=\s*(\d+)\b', (r/'app/build.gradle.kts').read_text())),
 'five_fixed_navigation_apps_untouched': all(x in (src/'dpi/ExternalAppAudioRouter.kt').read_text() for x in ('com.skt.tmap.ku','com.nhn.android.nmap','net.daum.android.map','kr.mappers.AtlanSmart','kr.co.telecons.mcon')),
 'service_declared': '.audio.NavRouteCaptureService' in manifest,
 'activity_declared': '.ui.NavAudioLabActivity' in manifest,
 'main_entrypoint': 'NavAudioLabActivity::class.java' in main,
 'real_scheduled_readonly_capture': all(x in service for x in ('3_000L,8_000L,15_000L','dumpsys media.audio_policy','dumpsys media.audio_flinger','pm list packages -U')),
 'no_write_shell': all(x not in service for x in ('setprop ', 'settings put', 'tinymix -', 'am force-stop','setInt(', 'cmd audio set')),
 'per_snapshot_error_status': 'success=${result.success}' in service and 'PARTIAL_FAILED_COMMANDS.txt' in service,
 'route_5_6_real_audio': ('AudioTrack(14,' in player or ('AudioTrack(stream, rate' in player and 'if (route.id == "RAW14") 14' in player)) and 'setLegacyStreamType(14)' in player and 't.play()' in player,
 'no_media_fallback_fake': 'return Result(false, "Android preferredDevice 요청 거부' in player,
 'route_device_discovery': 'getDevices(AudioManager.GET_DEVICES_OUTPUTS)' in player,
 'permission_gate': 'MODIFY_AUDIO_ROUTING' in ui and 'NavRouteEvidence.classify' in ui,
 'unsupported_cross_uid_explicit': 'CROSS_UID_ROUTING_NOT_IMPLEMENTED_EVEN_WITH_PERMISSION' in status,
 'record_actual_user_listening': 'DRIVER_ONLY_HEARD' in ui and 'MEDIA_OR_ALL_HEARD' in ui and 'SILENT_OR_UNKNOWN' in ui,
 'scanner_app_launch': 'getLaunchIntentForPackage' in ui,
 'stock_target_comparison': 'latest("STOCK_TMAP")' in ui and 'fun compare(' in ui,
 'zip_document_save': 'Intent.ACTION_CREATE_DOCUMENT' in ui and 'ZipOutputStream' in ui,
 'restore_no_global_writes': 'NO_GLOBAL_CHANGES' in ui and 'stopSelfResult(startId)' in service,
 'preserve_bsd_voice': 'BSD_WARNING("후측방 조심"' in (src/'model/AlertModels.kt').read_text(),
 'existing_alert_route_preserved': 'buildDriverStream14Attributes()' in (src/'audio/AlertAudioPlayer.kt').read_text(),
 'no_new_vehicle_write': all(x not in (ui+service+player) for x in ('BYDAuto','BYDService.set','setVehicle','setInt(')),
}
ET.fromstring(manifest)
for name,passed in checks.items():print(('PASS' if passed else 'FAIL'),name)
assert all(checks.values()), 'Failed audio lab gate'
print('NAV_AUDIO_LAB_SOURCE_GATES=',len(checks),'PASS, Android CI and real-car tests are separate')
