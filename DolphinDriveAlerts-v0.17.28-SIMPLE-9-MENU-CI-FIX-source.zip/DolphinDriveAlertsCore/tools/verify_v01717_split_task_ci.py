#!/usr/bin/env python3
"""CI regression: execute the *production* task readback with OEM/Android dumpsys formats.
No claim of Android full build or real car verification is made by this JVM test.
"""
from pathlib import Path
import re, shutil, subprocess, tempfile, sys
root=Path(__file__).resolve().parents[1]
k=root/'app/src/main/java/com/byd/dolphin/drivealerts/automation/SplitTaskReadback.kt'
source=k.read_text()
gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'v01717_or_later_version': bool(re.search(r'versionCode\s*=\s*(4[3-9]|[5-9]\d|\d{3,})\b',gradle)) and bool(re.search(r'versionName\s*=\s*"0\.17\.(?:1[7-9]|[2-9]\d+)[-\w]*"',gradle)),
 'production_legacy_task_id_support': 'Task\\\\{\\\\s*' not in source and r'Task\{\s*(\d+)' in source,
 'production_modern_task_id_support': 'taskId' in source and 'Root' in source,
 'production_requires_independent_task': 'firstIds.intersect(secondIds).isEmpty()' in source,
 'production_collision_blocks_success': 'firstIds.intersect(secondIds).isNotEmpty()' in source,
 'previous_tests_preserved': (root/'tools/verify_v01713_policy_kotlin.py').is_file() and (root/'tools/verify_v01715_realcar_repair.py').is_file(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values()),'Task ID source contract mismatch'
if '--static-only' in sys.argv:
 print('V01717_SPLIT_STATIC=%d/%d' %(sum(checks.values()),len(checks)))
 sys.exit(0)
if not shutil.which('kotlinc'):
 raise RuntimeError('kotlinc unavailable; CI must install Kotlin compiler or verify full Android Gradle Kotlin compilation')
runner=r'''import com.byd.dolphin.drivealerts.automation.SplitTaskReadback
fun main() {
    fun confirmed(text:String): Boolean=SplitTaskReadback.inspect(text,"com.example.one","com.example.two").verified
    // Exact historic v0.17.13 fixture that failed v0.17.16 Actions.
    check(confirmed("""Task{101 mode=3 A=com.example.one} ActivityRecord{com.example.one/A}
Task{102 mode=4 A=com.example.two} ActivityRecord{com.example.two/B}"""))
    // Newer Android formats plus independent package/task ownership.
    check(confirmed("""Task{a #17 windowingMode=3 com.example.one/.Main}
Task{b #18 windowingMode=4 com.example.two/.Main}"""))
    check(confirmed("""RootTask #201 mode=3 com.example.one/.Main
RootTask #202 mode=4 com.example.two/.Main"""))
    check(confirmed("""Task #111 windowingMode=4 com.example.one/.Main
Task #112 windowingMode=3 com.example.two/.Main"""))
    check(confirmed("""Task{foo taskId=301 windowingMode=3 com.example.one/.Main}
Task{bar taskId=302 windowingMode=4 com.example.two/.Main}"""))
    check(!confirmed("""Task{101 mode=3 A=com.example.one com.example.two} ActivityRecord{com.example.one/A}
Task{102 mode=4 A=com.example.two} ActivityRecord{com.example.two/B}"""))
    check(!confirmed("""Task{101 mode=3 com.example.one com.example.two}"""))
    check(!confirmed("""Task{101 mode=1 com.example.one}
Task{102 mode=1 com.example.two}"""))
    check(!confirmed("""Task{a mode=3 com.example.one}
Task{b mode=4 com.example.two}"""))
    check(!confirmed("""Task{101 mode=3 com.example.one}
Task{101 mode=4 com.example.two}"""))
    check(!confirmed("dumpsys partial"))
    println("V01717_ACTUAL_KOTLIN_TASK_DUMPSYS=11/11 PASS")
}'''
with tempfile.TemporaryDirectory(prefix='dolphin_v01717_split_') as tmp:
 tmp=Path(tmp); f=tmp/'Runner.kt'; f.write_text(runner)
 jar=tmp/'split.jar'
 c=subprocess.run(['kotlinc',str(k),str(f),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=90)
 assert c.returncode==0,c.stdout+'\n'+c.stderr
 c=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=25)
 assert c.returncode==0,c.stdout+'\n'+c.stderr
 print(c.stdout.strip())
print(f'V01717_SPLIT_CHECKS={len(checks)}/{len(checks)} static + real Kotlin PASS')
