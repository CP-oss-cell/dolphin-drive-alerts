#!/usr/bin/env python3
"""Fail-closed source gate using anonymized event IDs and original timing from 2026-10-18 real-car log."""
import pathlib
root=pathlib.Path(__file__).resolve().parent.parent
src=(root/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/InstrumentDriveModeGate.kt').read_text()
bridge=(root/'app/src/main/java/com/byd/dolphin/drivealerts/vehicle/ReferenceVehicleEventBridge.kt').read_text()
relay=(root/'app/src/main/java/com/byd/dolphin/drivealerts/audio/NavPlaybackCaptureRelayService.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert all(x in src for x in ['363 -> Mode.ECO','364 -> Mode.NORMAL','365 -> Mode.SPORT','302 -> Mode.ECO','311 -> Mode.NORMAL','310 -> Mode.SPORT'])
assert all(x in bridge for x in ['0x26100008','0x34500030','MODE_2602_DUAL_SOURCE_CONFIRMED','instrumentDriveMode.isConfirmed()'])
assert all(x in relay for x in ['addMatchingUid(uid)','MediaProjectionManager','AudioRecord','setLegacyStreamType(14)','ACTION_STOP','nonzeroApproxBytes'])
assert 'android:foregroundServiceType="mediaProjection"' in manifest and 'android.permission.RECORD_AUDIO' in manifest
rows=[]
for line in (root/'tools/mode_events_20261018.tsv').read_text().splitlines():
 if line.strip():
  ms,source,event,raw=line.split('\t'); rows.append((int(ms),source,int(raw)))
assert len(rows)==24, len(rows)
i_map={363:'ECO',364:'NORMAL',365:'SPORT'}
s_map={302:'ECO',311:'NORMAL',310:'SPORT'}
i_last=s_last=None
last=None
results=[]
for t,source,raw in rows:
 if source=='reference.instrument':i_last=(i_map[raw],t) if raw in i_map else None
 if source=='reference.setting':s_last=(s_map[raw],t) if raw in s_map else None
 if not i_last or not s_last:continue
 if i_last[0]!=s_last[0] or t-i_last[1]>9000 or t-s_last[1]>9000:continue
 if last==i_last[0]:continue
 last=i_last[0];results.append(last)
expected=['SPORT','ECO','NORMAL','SPORT','ECO','NORMAL','SPORT','ECO']
assert results==expected,(results,expected)
print('PASS source references plus real-car 24 events replay => 8 3-state mode transitions')
print('PASS nav capture explicit uid / consent / stream14 / FGS / default-off safeguards')
