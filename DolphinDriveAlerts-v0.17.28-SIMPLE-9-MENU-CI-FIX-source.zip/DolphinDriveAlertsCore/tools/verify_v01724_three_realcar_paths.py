#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile,sys
base=Path(__file__).resolve().parents[1]; src=base/'app/src/main/java/com/byd/dolphin/drivealerts'; autom=src/'automation'; veh=src/'vehicle'
kt=r'''import com.byd.dolphin.drivealerts.automation.*
import com.byd.dolphin.drivealerts.vehicle.*
fun main() {
 val stack="""Stack id=1 bounds=[0,0][640,720] displayId=0
 mActivityType=standard mWindowingMode=split-screen-primary
 Stack id=2 bounds=[646,0][1280,720] displayId=0
 mActivityType=standard mWindowingMode=split-screen-secondary"""
 val pair=ReferenceAutoSplitRatio.parse(stack) ?: error("reference parser must accept AutoSplit format")
 check(SplitGeometry.percent(pair)==50)
 check(SplitGeometry.resize(pair,20)?.command=="am stack resize-docked-stack 0 0 255 720 0 0 255 720")
 check(ReferenceAutoSplitRatio.parse("Stack id=1 bounds=[0,0][1280,720]")==null)
 val left="""Stack id=1 bounds=[640,0][1280,720]
 mWindowingMode=split-screen-primary
 Stack id=2 bounds=[0,0][634,720]
 mWindowingMode=split-screen-secondary"""
 check(ReferenceAutoSplitRatio.parse(left)!=null)
 val blinker=TurnSoundCadence()
 blinker.sample(1,1000);blinker.sample(2,1350);blinker.sample(1,1700)
 check(!blinker.probableActive(1750))
 blinker.sample(2,2050)
 check(blinker.probableActive(2100))
 check(!blinker.probableActive(3500))
 blinker.sample(3,2200)
 check(!blinker.probableActive(2210))
 val mode=StableModeSelector()
 check(mode.accept("ECO")==null)
 check(mode.accept("ECO")==null) // baseline only
 check(mode.accept("NORMAL")==null)
 check(mode.accept("NORMAL")=="NORMAL")
 check(mode.accept("NORMAL")==null)
 check(mode.accept(null)==null)
 check(mode.accept("SPORT")==null)
 check(mode.accept("SPORT")=="SPORT")
 println("PASS V01724 JVM path tests: AutoSplit 4, click 4, calibrated mode 6")
}'''
with tempfile.TemporaryDirectory() as d:
 d=Path(d); (d/'Test.kt').write_text(kt)
 cmd=['kotlinc',str(autom/'SplitGeometry.kt'),str(autom/'ReferenceAutoSplitRatio.kt'),str(veh/'TurnSoundCadence.kt'),str(veh/'StableModeSelector.kt'),str(d/'Test.kt'),'-include-runtime','-d',str(d/'test.jar')]
 subprocess.run(cmd,check=True,timeout=110)
 subprocess.run(['java','-jar',str(d/'test.jar')],check=True,timeout=20)
ref=(veh/'ReferenceVehicleEventBridge.kt').read_text(); engine=(autom/'VehicleSplitEngine.kt').read_text(); man=(base/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'mode signature calibration':(veh/'DriveModeSignature.kt').exists() and 'calibratedSignature=' in ref and 'MODE_RAW_SUPPRESSED_BY_CALIBRATION' in ref,
 'mode user-facing capture activity':'.ui.DriveModeCalibrationActivity' in man and 'class DriveModeCalibrationActivity' in (src/'ui/DriveModeCalibrationActivity.kt').read_text(),
 'BSD overlap only':'linkLockBsdDecoder.isActive() && turnSoundCadence.probableActive' in ref and 'BSD_GATE_ACCEPTED' in ref and 'bsdTurnSoundExperimentalEnabled(app)' in ref,
 'BSD candidate labels':'UNVERIFIED_TURN_CLICK_CADENCE' in ref and 'hazardsNotSeparatelyVerified' in (veh/'TurnSoundCadence.kt').read_text(),
 'AutoSplit exact AOSP 8 args':'val command=resize.command' in engine and 'resize.fourArgCommand' not in engine,
 'split two app continuity':'TWO_APPS_VERIFIED_RATIO_NOT_VERIFIED' in engine and 'primaryTask.taskId==secondaryTask.taskId' in engine,
 'split measurement truth':'ReferenceAutoSplitRatio.parse(source)' in engine and 'RATIO_OBSERVED' in engine,
 'no risky OEM writes': 'setOperationMode(' not in (veh/'DriveModeSignature.kt').read_text(),
}
for name,p in checks.items():print(('PASS' if p else 'FAIL'),name)
assert all(checks.values())
