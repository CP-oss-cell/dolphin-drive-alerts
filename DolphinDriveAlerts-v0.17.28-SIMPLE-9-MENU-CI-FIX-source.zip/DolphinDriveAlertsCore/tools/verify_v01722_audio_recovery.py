#!/usr/bin/env python3
"""v0.17.22 audio and voice policy source gates; no claims of real car verification."""
from pathlib import Path
import json, re, subprocess, tempfile, shutil
p=Path(__file__).resolve().parents[1]
base=p/'app/src/main/java/com/byd/dolphin/drivealerts'
player=(base/'audio/NavRouteLabPlayer.kt').read_text()
bridge=(base/'vehicle/ReferenceVehicleEventBridge.kt').read_text()
service=(base/'service/DrivingAlertService.kt').read_text()
voice=(p/'tools/generate_voice_pack.py').read_text()
voice_verify=(p/'tools/verify_voice_pack.py').read_text()
style=(base/'config/AlertPreferences.kt').read_text()
checks={
'v01722_version_code': (lambda m: bool(m) and int(m.group(1)) >= 48)(re.search(r'versionCode\s*=\s*(\d+)', (p/'app/build.gradle.kts').read_text())),
'legacy_media_route_direct': 'AudioManager.STREAM_MUSIC' in player and 'AudioTrack(stream, rate' in player,
'raw14_route_preserved': '"RAW14"' in player and 'setLegacyStreamType(14)' in player,
'mode_static_prewritestate_2_allowed': 'AudioTrack.STATE_NO_STATIC_DATA' in player and player.index('val preWriteState') < player.index('val written = t.write'),
'after_write_initialized': 'require(t.state == AudioTrack.STATE_INITIALIZED)' in player,
'1_2sec_tone': 'val frames = rate * 12 / 10' in player and 'Thread.sleep(1350)' in player,
'log_track_head_and_stream_volume': 'playbackHeadPosition' in player and 'volume=$volume' in player,
'mode_no_eco_off_blind_guess': 'raw == 0' in (base/'vehicle/NormalModeReadbackGate.kt').read_text(),
'mode_polls_live': 'pollNormalOperationMode' in service and 'pollNormalOperationMode()' in bridge,
'getter_consensus_only': 'evidence.all { it.second == proposed }' in bridge and 'it.first == "getOperationMode"' in bridge,
'no_normal_at_boot_without_previous_eco_sport': 'lastOperationMode in 1..2' in bridge,
'no_unsafe_oem_writes': all(s not in bridge for s in ('setOperationMode(', 'setInt(', 'setBoolean(')),
'reject_gtts_gender': 'def google_mp3(' not in voice and 'pitch-lowered' not in voice,
'edge_male_female_explicit': 'ko-KR-InJoonNeural' in voice and 'ko-KR-SunHiNeural' in voice,
'provenance_sha_gate': "entry.get('provider') != 'edge-tts'" in voice_verify,
'no_voice_pack_forces_effect': 'else AlertStyle.EFFECT' in style and 'neuralVoicePackPresent' in style,
'retain_bsd_generic': 'BSD_WARNING("후측방 조심"' in (base/'model/AlertModels.kt').read_text(),
'five_nav_preserved': all(x in (base/'dpi/ExternalAppAudioRouter.kt').read_text() for x in ('com.skt.tmap.ku','com.nhn.android.nmap','net.daum.android.map','kr.mappers.AtlanSmart','kr.co.telecons.mcon')),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
assert all(checks.values())
if shutil.which('kotlinc') and shutil.which('java'):
 with tempfile.TemporaryDirectory() as tmp:
  kt=Path(tmp)/'Test.kt'
  kt.write_text('import com.byd.dolphin.drivealerts.vehicle.NormalModeReadbackGate\nfun main() {\n val g=NormalModeReadbackGate()\n check(!g.sample(1)); check(!g.sample(0)); check(!g.sample(null));\n check(!g.sample(0)); check(!g.sample(0)); check(g.sample(0)); check(g.sample(0))\n g.reset(); check(!g.sample(2)); check(!g.sample(0));check(!g.sample(1))\n println("NORMAL_DEBOUNCE_KOTLIN_PASS")\n}\n')
  jar=Path(tmp)/'test.jar'
  subprocess.run(['kotlinc',str(base/'vehicle/NormalModeReadbackGate.kt'),str(kt),'-include-runtime','-d',str(jar)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  subprocess.run(['java','-jar',str(jar)],check=True)
print('V01722_AUDIO_VOICE_GATES=',len(checks),'PASS')
