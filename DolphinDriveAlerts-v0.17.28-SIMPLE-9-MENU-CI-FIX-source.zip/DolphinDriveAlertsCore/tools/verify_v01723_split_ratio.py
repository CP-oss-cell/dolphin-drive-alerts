#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile
base=Path(__file__).resolve().parents[1]
src=base/'app/src/main/java/com/byd/dolphin/drivealerts/automation'
code=r'''package com.byd.dolphin.drivealerts.automation
fun main() {
  val stackOnly="""Stack id=1 bounds=[0,0][640,720] displayId=0
Stack id=2 bounds=[646,0][1280,720] displayId=0"""
  val activityModes="""Stack #1: ActivityStack{a mWindowingMode=split-screen-primary}
TaskRecord{aaa #17 A=com.example.music}
Stack #2: ActivityStack{b mWindowingMode=split-screen-secondary}
TaskRecord{bbb #18 A=com.example.nav}"""
  val pair=SplitGeometry.parse(stackOnly,activityModes) ?: error("two-source readback missing")
  check(SplitGeometry.percent(pair)==50)
  check(SplitGeometry.parse(stackOnly)==null) // cannot assign unidentified stacks
  check(SplitGeometry.parse("Stack id=1 bounds=[0,0][640,720]",activityModes)==null) // secondary absent
  check(SplitGeometry.resize(pair,20)?.command=="am stack resize-docked-stack 0 0 255 720 0 0 255 720")
  check(SplitGeometry.resize(pair,80)?.fourArgCommand=="am stack resize-docked-stack 0 0 1019 720")
  check(SplitGeometry.resize(pair,10)?.command?.contains("0 0 127 720")==true)
  check(SplitGeometry.resize(pair,90)?.command?.contains("0 0 1147 720")==true)
  val rawBoth="""Stack id=1 bounds=[0,0][251,720]
 mWindowingMode=split-screen-primary mActivityType=standard
Stack id=2 bounds=[257,0][1280,720]
 mWindowingMode=split-screen-secondary mActivityType=standard"""
  check(SplitGeometry.percent(SplitGeometry.parse(rawBoth)!!)==20)
  val rightDock="""Stack #3: ActivityStack{a mWindowingMode=split-screen-primary mBounds=Rect(646, 0 - 1280, 720)}
Stack #4: ActivityStack{b mWindowingMode=split-screen-secondary mBounds=Rect(0, 0 - 640, 720)}"""
  val right=SplitGeometry.parse(rightDock) ?: error("right dock")
  check(SplitGeometry.percent(right)==50)
  check(SplitGeometry.resize(right,20)?.command=="am stack resize-docked-stack 1025 0 1280 720 1025 0 1280 720")
  val vertical="""Stack id=3 bounds=[0,0][720,400] mode=3
Stack id=4 bounds=[0,406][720,1280] mode=4"""
  check(SplitGeometry.percent(SplitGeometry.parse(vertical)!!)==31)
  check(SplitGeometry.resize(SplitGeometry.parse(vertical)!!,80)?.axis=="Y")
  val taskPoison="""Stack #1: ActivityStack{a mWindowingMode=split-screen-primary}
 mBounds=Rect(0,0 - 640,720)
 TaskRecord{foo #1 A=whatever}
   mBounds=Rect(0,0 - 10,10)
Stack #2: ActivityStack{b mWindowingMode=split-screen-secondary}
 mBounds=Rect(646,0 - 1280,720)
 TaskRecord{bar #2 A=whatever}
   mBounds=Rect(0,0 - 25,25)"""
  check(SplitGeometry.percent(SplitGeometry.parse(taskPoison)!!)==50)
  check(SplitGeometry.parse("Stack id=1 bounds=[0,0][640,720]\nStack id=2 bounds=[0,0][640,720]",activityModes)==null)
  check(SplitGeometry.resize(SplitGeometry.PairBounds(SplitGeometry.Rect(0,0,640,720),SplitGeometry.Rect(0,0,640,720)),80)==null)
  println("PASS 14/14 geometry: two-source, fail-closed, both dock sides, percent 10..90, nested-task exclusion")
}'''
with tempfile.TemporaryDirectory() as temp:
  d=Path(temp);(d/'Test.kt').write_text(code)
  subprocess.run(['kotlinc',str(src/'SplitGeometry.kt'),str(d/'Test.kt'),'-include-runtime','-d',str(d/'test.jar')],check=True,timeout=110)
  subprocess.run(['java','-jar',str(d/'test.jar')],check=True,timeout=20)
engine=(src/'VehicleSplitEngine.kt').read_text();ui=(src/'SplitProfilesActivity.kt').read_text()
checks={
 'owner task logic retained':'SPLIT_POST_RATIO_TASKS' in engine and 'primaryTask.taskId==secondaryTask.taskId' in engine,
 'read both sources':'am stack list' in engine and 'dumpsys activity activities' in engine and 'SplitGeometry.parse(if(stacks.success)' in engine,
 'read back before success':'RATIO_OBSERVED' in engine and 'kotlin.math.abs(observed-pct)<=3' in engine,
 'two OEM signatures':'resize.fourArgCommand' in engine and 'resize.command' in engine,
 'original two-app launch preserved':'PRIMARY_GHOST' in engine and 'SECONDARY_START' in engine,
 'no silent clamp':'pct !in 10..90' in engine and 'requested.coerceIn(10,90)' in (src/'SplitGeometry.kt').read_text(),
 'do not interrupt split by UI':'finish()' in ui and 'Thread.sleep(350L)' in ui,
 'source version update':'versionCode = 49' in (base/'app/build.gradle.kts').read_text(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
assert all(checks.values())
