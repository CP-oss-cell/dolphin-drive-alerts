#!/usr/bin/env python3
"""Offline CI/source test for the Edge-403 recovery flow. No mock assets are shipped."""
from pathlib import Path
import ast
import importlib.util
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parents[1]
p=root/'tools/generate_voice_pack.py'
w=Path(__file__).resolve().parents[1] / 'tools/voice_prompts.json'
code=p.read_text()
results={
    'valid_source': bool(ast.parse(code)),
    'baseline_30_prompts': __import__('json').loads(w.read_text()).__len__()==30,
    'cached_wav_sha_check': "old.get('sha256')==sha" in code,
    'provider_provenance': "'provider':provider" in code,
    'edge_failure_circuit_breaker': 'edge_unavailable=True' in code,
    'independent_provider_fallback': 'google_mp3(mp3,item' in code,
    'no_placeholder_audio': 'Both independent TTS services failed' in code,
    'ffmpeg_pcm16_44khz': "'pcm_s16le'" in code and "'44100'" in code,
    'version47': 'versionCode = 47' in (root/'app/build.gradle.kts').read_text(),
}

spec=importlib.util.spec_from_file_location('generate_voice_pack_v01721',p)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='v01721-voice-test-') as td:
    t=Path(td)
    # This WAV tests only PCM conversion and checksum. It contains a synthetic
    # tone; test data are created in temp and NEVER copied to Android assets.
    mp3=t/'test-only.mp3'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                    '-i','sine=frequency=600:duration=0.45','-c:a','libmp3lame',
                    str(mp3)],check=True,timeout=20)
    m=t/'male-test.wav';f=t/'female-test.wav'
    module.convert_wav(mp3,m,'male','gtts-fallback')
    module.convert_wav(mp3,f,'female','gtts-fallback')
    results['fallback_pcm_stays_valid']=module.valid_wav(m) and module.valid_wav(f)
    results['fallback_gender_profile_is_distinct']=m.read_bytes()!=f.read_bytes()
    results['silent_wav_rejected']=False
    # Manually generate entirely silent 0.3s PCM to ensure silence cannot
    # get treated as valid voice output.
    import wave
    silent=t/'silent.wav'
    with wave.open(str(silent),'wb') as x:
        x.setnchannels(1);x.setsampwidth(2);x.setframerate(44100)
        x.writeframes(b'\x00\x00'*13230)
    results['silent_wav_rejected']=not module.valid_wav(silent)

for k,v in results.items():
    print(('PASS' if v else 'FAIL'),k)
if not all(results.values()):
    sys.exit(1)
print(f'VOICE_CI_OFFLINE_CONTRACT={len(results)} PASS; NO_EXTERNAL_TTS_REQUEST; NO_REALCAR_CLAIM')
