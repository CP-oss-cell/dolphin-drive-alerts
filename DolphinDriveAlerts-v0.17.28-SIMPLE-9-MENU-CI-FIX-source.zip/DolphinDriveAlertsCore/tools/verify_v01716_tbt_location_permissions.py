#!/usr/bin/env python3
"""v0.17.16 TBT notification-access + selected-app location permissions contract.
Static checks and actual Kotlin JVM AppPermissionRules tests. Android UI/ADB runtime requires GitHub CI & vehicle.
"""
from pathlib import Path
import subprocess, tempfile, shutil, sys, re
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda x: (p/x).read_text(encoding='utf-8')
gradle=(r/'app/build.gradle.kts').read_text()
m=read('dpi/SelectedAppPermissionManager.kt')
ui=read('ui/AppPermissionManagerActivity.kt')
rules=read('dpi/AppPermissionRules.kt')
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'version': bool(re.search(r'versionCode\s*=\s*(4[2-9]|[5-9]\d|\d{3,})\b', gradle)) and bool(re.search(r'versionName\s*=\s*"0\.17\.(?:1[6-9]|[2-9]\d+)[-\w]*"', gradle)),
 'own_app_can_be_selected':'it.packageName!=packageName' not in ui and 'Dolphin Drive (TBT/미디어 알림 수신용)' in ui,
 'listener_manifest_existing':'NotificationListenerService' in manifest and 'MediaPlaybackObserver' in manifest,
 'notification_access_selection':'Action.NOTIFICATION_ACCESS' in ui and 'NotificationListenerService' in m and 'cmd notification allow_listener' in rules,
 'location_foreground_ui':'Action.LOCATION_FOREGROUND' in ui,
 'location_background_ui':'Action.LOCATION_BACKGROUND' in ui,
 'global_location_ui':'Action.LOCATION_SERVICE' in ui and '차량 전체 위치 서비스 변경 확인' in ui,
 'global_location_confirmation':'전역 위치 ON 허용' in ui and 'val global=' in ui,
 'settings_fallback':'Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS' in ui and 'Settings.ACTION_LOCATION_SOURCE_SETTINGS' in ui,
 'only_declared_permissions':'permission !in requested' in m and '.filter { it in requested }' in m,
 'foreground_before_background':'configure && !foreground' in m,
 'no_arbitrary_grant':'require(permission in setOf(' in rules,
 'readback_instead_of_command_success':'AppPermissionRules.hasGrantedPermission(readback.output' in m and 'AppPermissionRules.locationEnabledReadback(readback.output)' in m,
 'no_automatic_global_write':'if(configure && beforeOn != true)' in m,
 'no_tbt_false_claim':'TBT 자동 표시는 별도 기능' in ui,
 'legacy_permissions_retained':all('Action.'+x in m for x in ['BATTERY','NOTIFICATION_POST','ACCESSIBILITY','USAGE_STATS']),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' '+k)
assert all(checks.values()),'permission contract failure'
if '--static-only' in sys.argv:
 print('V01716_STATIC=%d/%d PASS'%(sum(checks.values()),len(checks)))
 sys.exit(0)
if not shutil.which('kotlinc'):
 print('KOTLINC_UNAVAILABLE Gradle compile gate required');sys.exit(0)
with tempfile.TemporaryDirectory(prefix='v01716-kotlin-') as d:
 d=Path(d)
 test=d/'PermissionTest.kt'
 test.write_text('''
import com.byd.dolphin.drivealerts.dpi.AppPermissionRules as A
fun main() {
  check(A.locationGrantCommand("com.tmap.nav","android.permission.ACCESS_FINE_LOCATION") == "pm grant com.tmap.nav android.permission.ACCESS_FINE_LOCATION")
  check(A.locationGrantCommand("com.tmap.nav","android.permission.ACCESS_COARSE_LOCATION").endsWith("ACCESS_COARSE_LOCATION"))
  check(A.locationGrantCommand("com.tmap.nav","android.permission.ACCESS_BACKGROUND_LOCATION").endsWith("ACCESS_BACKGROUND_LOCATION"))
  check(runCatching { A.locationGrantCommand("com.app;bad", "android.permission.ACCESS_FINE_LOCATION") }.isFailure)
  check(runCatching { A.locationGrantCommand("com.good.app", "android.permission.WRITE_SECURE_SETTINGS") }.isFailure)
  val dumpsys="runtime permissions:\\n  android.permission.ACCESS_COARSE_LOCATION: granted=true, flags=[USER_SET]\\n  android.permission.ACCESS_FINE_LOCATION: granted=false, flags=[]"
  check(A.hasGrantedPermission(dumpsys,"android.permission.ACCESS_COARSE_LOCATION"))
  check(!A.hasGrantedPermission(dumpsys,"android.permission.ACCESS_FINE_LOCATION"))
  check(!A.hasGrantedPermission("", "android.permission.ACCESS_COARSE_LOCATION"))
  check(A.locationEnabledReadback("true\\n") == true)
  check(A.locationEnabledReadback("false") == false)
  check(A.locationEnabledReadback("Permission Denial: denied") == null)
  check(A.locationEnableCommand() == "cmd location set-location-enabled true")
  check(A.locationReadCommand() == "cmd location is-location-enabled")
  check(A.notificationListenerCommand("com.demo/.Alerts") == "cmd notification allow_listener com.demo/.Alerts")
  check(A.addAccessibilityService("com.old/.One", "com.new/.Two") == "com.old/.One:com.new/.Two")
  println("V01716_PERMISSION_RULES_KOTLIN=15/15 PASS")
}
''',encoding='utf-8')
 jar=d/'test.jar'
 c=subprocess.run(['kotlinc',str(p/'dpi/AppPermissionRules.kt'),str(test),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=110)
 assert c.returncode==0,c.stdout+c.stderr
 c=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=25)
 assert c.returncode==0,c.stdout+c.stderr
 print(c.stdout.strip())
print('V01716_LOCAL_PASS; Android APK and real-car NOT RUN')
