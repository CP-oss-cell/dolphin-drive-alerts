#!/usr/bin/env python3
"""Prevent regression: old Kotlin smoke suites must compile their NEW bridge dependencies.
This checks fixture coverage, not vehicle or Android runtime correctness.
"""
from pathlib import Path
p = Path(__file__).resolve().parents[1]
app = p / 'app/src/main/java/com/byd/dolphin/drivealerts/vehicle'
gate = app / 'InstrumentDriveModeGate.kt'
bridge = app / 'ReferenceVehicleEventBridge.kt'
assert gate.is_file(), 'InstrumentDriveModeGate Kotlin source is missing'
assert 'InstrumentDriveModeGate()' in bridge.read_text(), 'ReferenceBridge no longer references expected gate'
for test in ['verify_v0179_callback_kotlin_compile.py','verify_v01711_bsd_any_indicator.py']:
    body = (p / 'tools' / test).read_text()
    assert "'vehicle/InstrumentDriveModeGate.kt'" in body, f'{test} missing new Kotlin dependency'
    assert "'vehicle/ReferenceVehicleEventBridge.kt'" in body, f'{test} does not compile actual bridge'
    print(f'PASS {test}: gate dependency present')
print('CI_DEPENDENCY_FIX=PASS')
