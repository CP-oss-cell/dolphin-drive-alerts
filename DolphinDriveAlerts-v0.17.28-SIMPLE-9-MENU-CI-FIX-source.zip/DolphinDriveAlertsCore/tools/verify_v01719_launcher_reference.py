#!/usr/bin/env python3
"""Deterministic source/regression gates: V1 1.2.20 is a reference, not vehicle verification."""
from pathlib import Path
import re
r=Path(__file__).resolve().parents[1]
src=r/'app/src/main/java/com/byd/dolphin/drivealerts'
def code(rel):return (src/rel).read_text()
checks={
 'paired_indicators_only': '(left == 1 && right == 0) || (right == 1 && left == 0)' in code('vehicle/TurnSignalReadback.kt'),
 'same_sdk_provider_required': 'candidateLeft.value in 0..1 && candidateRight.value in 0..1' in code('vehicle/TurnSignalReadback.kt'),
 'null_still_unknown': 'hazardSide=UNKNOWN' in code('vehicle/TurnSignalReadback.kt'),
 'launcher_indicator_getters': all(x in code('vehicle/TurnSignalReadback.kt') for x in ('getLeftTurnLightState','getRightTurnLightState')),
 'normal_mapping_guard': all(x in code('vehicle/DriveModeDecoder.kt') for x in ('0 -> AlertEvent.DRIVE_NORMAL','1 -> AlertEvent.DRIVE_ECO','2 -> AlertEvent.DRIVE_SPORT')),
 'no_invented_raw': 'noBlindCycleInference=true' in code('vehicle/ReferenceVehicleEventBridge.kt'),
 'split_ghost_stack': 'am stack move-task' in code('automation/VehicleSplitEngine.kt'),
 'split_post_ratio_ownership': 'SPLIT_POST_RATIO_TASKS' in code('automation/VehicleSplitEngine.kt') and 'postPrimary.stackId==postSecondary.stackId' in code('automation/VehicleSplitEngine.kt'),
 'alarm_process_independent': 'alarm.setAndAllowWhileIdle' in code('automation/IgnitionSequenceAlarmReceiver.kt'),
 'alarm_no_double_batch': 'acknowledged >= request' in code('automation/IgnitionSequenceAlarmReceiver.kt'),
 'alarm_ignition_stop_cancels': 'IgnitionSequenceAlarmReceiver.cancel(context)' in code('service/BootReceiver.kt'),
 'alarm_ack_from_actual_service': 'IgnitionSequenceAlarmReceiver.acknowledge(this)' in code('automation/AutoLaunchSequenceService.kt'),
 'alarm_manifest_registered': '.automation.IgnitionSequenceAlarmReceiver' in (r/'app/src/main/AndroidManifest.xml').read_text(),
 'package_preserved': 'applicationId = "com.byd.dolphin.drivealerts"' in (r/'app/build.gradle.kts').read_text(),
 'version_45_or_newer': __import__('re').search(r'versionCode\s*=\s*(\d+)', (r/'app/build.gradle.kts').read_text()) is not None and int(__import__('re').search(r'versionCode\s*=\s*(\d+)', (r/'app/build.gradle.kts').read_text()).group(1)) >= 45,
 'voice_untouched': '60' in (r/'app/src/main/java/com/byd/dolphin/drivealerts/audio/VoiceAssetCatalog.kt').read_text() if False else (r/'app/src/main/java/com/byd/dolphin/drivealerts/audio/VoiceAssetCatalog.kt').exists(),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL'),name)
assert all(checks.values())
print('V01719_SOURCE_GATES=',len(checks),'PASS, NO ANDROID CI/REALCAR CLAIM')
