#!/usr/bin/env python3
"""Verify that every voice entry is present, non-silent and matches its manifest.

This deliberately does not require network, edge-tts or gTTS. A stale cache or
empty placeholder must not make an APK appear ready for vehicle audio testing.
"""
import hashlib
import json
from pathlib import Path
import sys
from generate_voice_pack import valid_wav

root=Path(__file__).resolve().parents[1]
folder=root/'app/src/main/assets/voice'
manifest_path=folder/'voice_pack_manifest.generated.json'
prompts=json.loads((root/'tools/voice_prompts.json').read_text(encoding='utf-8'))
errors=[]
if len(prompts)!=30 or len({p['file'] for p in prompts})!=30:
    errors.append('voice prompt manifest is not exactly 30 unique names')
try:
    indexed=json.loads(manifest_path.read_text(encoding='utf-8'))
except (OSError, ValueError) as e:
    indexed=[]
    errors.append('missing/bad voice provenance manifest: '+str(e))
by_key={}
for x in indexed:
    try:
        key=(x['style'],x['file'])
        if key in by_key:
            errors.append('duplicate manifest row '+str(key))
        by_key[key]=x
    except (KeyError,TypeError):
        errors.append('corrupt manifest entry')
if len(indexed)!=60:
    errors.append(f'expected 60 provenance rows, got {len(indexed)}')
expected={(style,p['file']) for style in ('male','female') for p in prompts}
if set(by_key)!=expected:
    errors.append('voice pack manifest keys do not match the source prompts')
for style in ('male','female'):
    for p in prompts:
        key=(style,p['file']); dest=folder/style/p['file']
        entry=by_key.get(key)
        if not valid_wav(dest):
            errors.append('missing, silent or invalid WAV '+str(dest.relative_to(root)))
            continue
        if entry is None:
            continue
        if entry.get('text')!=p['text']:
            errors.append('text mismatch '+str(key))
        if entry.get('sha256')!=hashlib.sha256(dest.read_bytes()).hexdigest():
            errors.append('SHA-256 mismatch '+str(key))
        expected_voice={'male':'ko-KR-InJoonNeural','female':'ko-KR-SunHiNeural'}[style]
        if entry.get('provider') != 'edge-tts' or entry.get('voice') != expected_voice:
            errors.append('gender-unverified or non-neural voice rejected '+str(key))
print('VOICE_PACK_CRC_HASH_NON_SILENT: expected=60 errors='+str(len(errors)))
for e in errors[:90]:print('ERROR',e)
if errors:sys.exit(1)
