# Dolphin Drive Alerts v0.17.16 — 지정 앱 TBT 알림 접근 및 위치 권한 통합

## 변경 기준과 범위
- 소스 기준: v0.17.15 Realcar Evidence Repair 소스 ZIP. 패키지 `com.byd.dolphin.drivealerts` 유지, `versionCode=42` / `versionName=0.17.16-notification-location-permissions`.
- 기존 DA-004(ADB 권한/지정앱 권한) 및 DA-025(TBT/계기판), DA-010(내비 앱) 관련. 신규 중복 DA 이슈 없음.
- 현재 v0.17.15의 BSD 상시알림, 깜빡이 진단, NORMAL 진단, 2분할, ADB 최초 승인, EQ 미세강화, UnifiedLogCapture 로직 보존.

## 실제 소스 수정
1. `AppPermissionManagerActivity`: 지정 앱에 **Dolphin Drive 자기 앱 포함(첫 번째)**. TBT용 '알림 수신 접근' 메뉴 이름 명확화. `LOCATION_FOREGROUND`, `LOCATION_BACKGROUND`, `LOCATION_SERVICE` 3개 선택 추가.
2. `SelectedAppPermissionManager`: 대상 앱 Manifest 선언을 실제로 확인한 후 `pm grant` 대략/정밀 위치 권한. Android 10+ 백그라운드 위치는 대상앱 선언 + 선행 foreground 권한 필요. 명령 성공이 아니라 `dumpsys package` readback으로 성공 판정.
3. 차량 위치 서비스는 앱별 위치 권한과 별도로 `cmd location is-location-enabled`로 readback; 사용자 체크와 **별도 전체 차량 스위치 변경 확인 대화상자**가 있는 경우만 `cmd location set-location-enabled true` 시도. 실패·미지원은 별도 안내. false 전환 명령 제공 안 함.
4. 알림 접근은 `NotificationListenerService` 선언된 서비스 컴포넌트에 한하여 기존 `cmd notification allow_listener` 실행·readback. **내비 앱에 알림 접근을 부여해야 우리가 내비 알림을 읽는 것이 아님**. Dolphin Drive가 자신의 알림 리스너를 허용받는 것이 목표.
5. Android 알림 접근 설정 및 위치 서비스 설정 링크 추가(해당 BYD 펌웨어가 차단하면 오류 표시). Shell 명령에 쓰이는 package/permission allowlist 검증.

## 제한사항 / 보안
- 이것은 '권한 관리' UI·로직입니다. **내비 TBT 콘텐츠 추출/파싱·별도 계기판 전송/테마 쓰기 기능을 구현한 것이 아닙니다.** 많은 내비 앱은 NotificationListenerService가 없으므로 해당 내비 앱을 선택하면 '없음'이 정상. Dolphin Drive 선택 후 알림 접근 허용 필요.
- 권한 선언하지 않은 앱에 부여 시도하지 않고, 백그라운드 위치는 앱의 정당한 용도에서만 선택. 차량 전체 위치 서비스 변경은 앱별 권한과 별개이며 개인정보·타 앱에 영향. 미지원 셸/정책 차단은 PASS로 표시하지 않음.
- Android 10 글로벌 2602 차량의 실제 ADB 승인/pm grant/위치 서비스 상태·TBT 알림·앱 실행은 미검증.

## 검증
- 기존 v0.17.8 회귀 57/57, v0.17.9 48/48, v0.17.13 25/25, v0.17.14 정적 17/17, v0.17.15 19/19 PASS.
- v0.17.16 신규 정적 16/16, `AppPermissionRules` 실제 Kotlin 15/15, `SelectedAppPermissionManager` 실제 Kotlin stub 2/2 + `AppPermissionManagerActivity` 실제 Kotlin UI stub compile PASS.
- Android SDK 전체 `:app:compileDebugKotlin`, `:app:assembleDebug`는 GitHub Actions에서 실행해야 하며, 완료 전 APK 작동 검증으로 표시하지 않음.

## 실차 검증(읽기/적용 사용자 명시 동의)
- 지정 앱 목록에서 Dolphin Drive가 첫 위치에 보이는지, 알림 수신 접근 선택 후 `enabled_notification_listeners` readback인지.
- 설치된 내비 각각의 Manifest에 따라 위치 대략/정밀 부여와 `dumpsys package` granted=true인지.
- 필요한 앱에서만 BACKGROUND 선택; foreground 선행/매니페스트 검증인지.
- 차량 전체 위치 SERVICE: 상태 조회는 스위치 변경 없이 수행되는지, 체크/2중 확인 시에만 ON 시도되고 읽기 결과가 ON인지.
- Android/DiLink가 기능을 차단하면 BLOCKED/UNVERIFIED를 유지.
