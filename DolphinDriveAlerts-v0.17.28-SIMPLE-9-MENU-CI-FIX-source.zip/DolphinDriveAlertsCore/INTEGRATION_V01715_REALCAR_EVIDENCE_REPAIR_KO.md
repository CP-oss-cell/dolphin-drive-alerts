# Dolphin Drive Alerts v0.17.15 — 2026-10-10 실차 전수분석 후 개선 통합보고

**기준:** v0.17.14 통합 소스(versionCode 40) → v0.17.15(versionCode 41). 사용자 제공 소형 ZIP(순정/타사 내비·외부스피커 테스트), 대형 ZIP(실주행 부분 복구), 18283/18285/18287 계기판 원본 영상, DEEP_REALCAR_AUDIT_20261010_KO.md, Library master v56·evidence v50와 DA-027/008/015 개별 이슈를 대조. 근거 문서의 '추정'을 '실차 검증'으로 승격하지 않음.

## 1. 실제 입력 제약 및 중복 이슈 검사
- 소형 ZIP의 유효 로그 6,933건, 대형 ZIP의 유효 JSONL 110,245건(마지막 압축 구간 손상·복원 데이터 부분만). 이 두 캡처의 시간·용도를 합쳐 해석하지 않음.
- DA-007 BSD 상시알림 vs 깜빡이 게이트 분리. DA-003/005 NORMAL 입력 신호 분리. DA-027 2분할 실행 vs ADB 인증 분리. DA-008 ICC ADAS 설정 vs 실제 위험 이벤트 분리. DA-015 기존 EQ 개선 유지. DA-010 운전석 cross-UID, DA-012 외부 AVAS는 연구만. DA-029 번호는 통합로그/메뉴정리 구기록 충돌이 있어 신규 중복번호 발급·기존기록 삭제하지 않음.
- 영상은 순정 계기판 중앙 돌핀 차량 도식·차선 및 주행 속도 변화 참고. BSD 좌우 특정 순간 신호와 영상의 정확한 타임스탬프 매칭은 입증되지 않음.

## 2. 수정 파일, 원인, 효과 및 한계
1. `vehicle/TurnSignalReadback.kt`: 기존 글로벌 2602의 `left=null right=null` 장애에 대해 장치 Class, getInstance, 좌우 getter 이름, 반환 숫자/예외를 텍스트로 수집. SDK에 존재할 수 있는 다른 getter 이름은 **읽기 전용 후보**로만 순서대로 검사. 양쪽 신호를 모르거나 hazard면 임의 ON 처리하지 않음. BSD 감지 raw2+실제 좌우 중 하나 ON=1 인 경우에만 일반 경고 1회, 상시모드와 중복 방지 유지. **새 후보 getter로 실차 문제가 해결됐는지는 미검증**.
2. `vehicle/ReferenceVehicleEventBridge.kt`: 실차 turn sound ID `0x1440002e` raw1/2/3를 BSD 위험 활성 여부와 타임라인으로 기록하되 **깜빡이 실제 ON·좌우라고 가정해 음성 게이트로 쓰지 않음**. NORMAL은 `ENERGY_OPERATION_MODE` 0(후보)/1(ECO)/2(SPORT) raw와 두 read-only SDK getter 결과 동시 기록. 2026-10-10 주행 로그 raw0=0건, 앱 NORMAL 발화 0건이므로 **해결 보류**. 실제 UI 주행모드 순환(ECO→NORMAL→SPORT→ECO)으로 raw를 임의 계산하지 않음.
3. `automation/VehicleSplitEngine.kt`, `SplitTaskReadback.kt`: 최초 ADB READY 흐름(v0.17.14)은 계승; profile에 자신의 앱이 있는 경우 거부. 두 앱을 MAIN/LAUNCHER 명시 `am start -W --windowingMode 3/4`로 실행, 각 명령 종료 코드·stdout·stderr와 요청 id 기록. 실제 Task ID와 모드 3/4가 **서로 다른** 태스크인지 여러 차례 읽어서 확인, 검증되지 않은 경우 성공 또는 자동 복원 상태로 기록 금지. 분할 bounds/비율 readback 유지. **2번째 칸 정상 실차 성공 미확정**. 앱 UI 종료 처리는 이전 v0.17.14에 이미 반영됐으므로 중복 개선 성과로 표기하지 않음.
4. `log/UnifiedLogCapture.kt`: 커스텀 앱 캐시에 ZIP을 먼저 완성한 뒤 ZipInputStream CRC 전체 읽기 + ZipFile 중앙 디렉터리 + 필수 entries 검증. 검증 후 Android MediaStore Downloads에 복사하고 IS_PENDING 해제. 실패하면 FAILED로 판정, 실패 원인 로그 기록, 단계 캐시파일 잔존. versionName/versionCode 세션 메타데이터 추가. 전송·공유앱이 저장완료 후 파일을 잘랐을 가능성은 **이 코드만으로 해결 보증할 수 없음**.
5. `log/RawSignalLogger.kt`: instrument buzzer `0x12d0003c`(원본/참조 중복)와 reference.setting timestamp `0x99000198`만 **같은 값의 1초 이내 반복** 축약. 값이 바뀌는 순간은 필히 보존. 누적 250개마다 요약 마커. BSD·ADAS·Energy·모드·방향지시등 이벤트는 절대 축약 대상 아님.
6. `log/ReadOnlySignalProbe.kt`, `TargetedSignalProbe.kt`: 중첩 `IntArray`/배열 구조를 `[[I@...` 객체 문자열 대신 실제 배열 원소로 재귀 직렬화, Short/Byte 배열도 처리.

## 3. 보존된 기능
- 3종 BSD 음성(일반/좌/우), 최신 사용자 지시에 따른 **좌우 위험 미확정 시 일반 음성만** 자동 사용. BSD 즉시 경고 ON/OFF 분리(기본 OFF), 깜빡이 모드(기본 ON), 실제 raw2 의미 추가 실차 검증 필요.
- DA-015 EQ 미세 강화 +12% 선택(기본 OFF), Reference/Surround/Cinema, 기존 헤드룸 보호·설정 보존.
- NORMAL·기어·SPORT·회생제동 음성 자산, ICC 앞차출발·차선 이벤트 읽기전용 진단, 회전·DPI 보호·미디어·시동복구, v0.17.14 ADB 최초 RSA 승인 UI·영구키.
- 외부 AVAS/운전석 스피커 OEM 라우팅/계기판 쓰기 명령은 일절 추가하지 않음.

## 4. 검사 결과와 정직한 상태표기
- 기존 v0.17.8 57/57, v0.17.9 48/48, v0.17.13 25/25, v0.17.14 17/17 **정적 게이트 PASS**.
- `verify_v01715_realcar_repair.py`: 신규 19/19 정적, 실제 코드의 SplitTaskReadback Kotlin 4/4, TurnSignalReadback Kotlin 4/4, ZIP CRC 루틴 Kotlin 2/2 **PASS** (Android/차량 모의환경).
- v0.17.10 ReferenceBridge Kotlin 반사조회/시작 동작 PASS, v0.17.14 ADB 인증 Kotlin PASS. 패키징 ZIP CRC/워크플로 shell syntax/필수파일 검사 기록 `STATIC_GATES_V01715.log`.
- **미실행:** 전체 Android Gradle CI `:app:compileDebugKotlin`, `:app:assembleDebug`, 서명 APK 설치, 차량 2602 실제 BSD 깜빡이 안내/NORMAL/2분할, 실제 오디오 버스/AVAS. 현 상태 `SOURCE_PATCH_CREATED / LOCAL_KOTLIN_AND_STATIC_PASS / GITHUB_CI_PENDING / REALCAR_REVERIFY_REQUIRED`.

## 5. 다음 실차 로그의 필수 성공조건
- BSD: `TurnSignalReadback`의 클래스/메서드/값/오류 원인, 두 방향 각각 실제 깜빡이 관찰과 SDK 값 일치, `BSD_GATE_ACCEPTED` 경고 1회, 비상등 제외, 상시 모드와 중복 없음. turn sound는 검증 전에는 진단에만 사용.
- NORMAL: 실차 버튼 ECO→NORMAL→SPORT→ECO와 energy callback/getter(서로 다른 이벤트) 및 여성/남성 WAV 발화 시각 대조. raw0 없는 구간은 NORMAL 검증 불가.
- SPLIT: 선택한 두 패키지명/두 태스크 ID/모드3·4/실제 bounds와 지정 비율, 별도 카메라 사용 후 복귀 및 인증 유지 검사. `am start -W` 성공 ≠ 실차 창 성공.
- 로그: 30분 이상 캡처 후 ZIP 압축종료·CRC 재검증, 장시간 반복 이벤트 요약, radar 배열 숫자 기록, 캡처 종료와 파일 공유 단계 분리.
- 외부 AVAS·타사 내비: 물리 출력은 별도 검증, 보행자 경고 안전음 쓰기 금지.
