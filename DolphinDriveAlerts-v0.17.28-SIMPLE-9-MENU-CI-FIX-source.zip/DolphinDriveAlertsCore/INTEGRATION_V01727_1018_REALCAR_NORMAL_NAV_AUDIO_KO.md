# 2026-10-18 실차 검증 기반 v0.17.27 통합 변경

## 실차 원본 로그
`DolphinDriveLogs_20261018_101152_216_afbe3190.zip` (2026-10-18 10:11:52~10:15:23 KST), v0.17.26 / versionCode 52, 8,635 valid JSONL, SDK29, 19/19 shell commands succeeded. 수집 도중 서비스 재시작 기록 존재; 전 구간 OEM 콜백 수집을 주장하지 않음.

## NORMAL 실질 원인 및 새 증거
- 기존 ENERGY_OPERATION_MODE(0x2120000e)는 1/2만 순환. 현재 `DriveModeDecoder`는 0을 NORMAL로 기다리므로 정상 상태에서 실행되지 않음.
- 같은 로그의 계기판 `0x26100008`은 363(ECO 후보), 364(NORMAL 후보), 365(SPORT 후보)를 반복; 설정 `0x34500030`은 302(ECO 후보),311(NORMAL 후보),310(SPORT 후보)를 반복. 세 상태 대응은 기존 사용자 확정 ECO→NORMAL→SPORT 반복 순서와 이 로그의 시간 동기성으로 **차량 한정 추론**하며 순정 SDK 상수로 단정하지 않음.
- 새로운 `InstrumentDriveModeGate`는 두 소스에 모두 같은 후보 모드가 9초 안에 들어온 경우에만 이벤트를 반환. 모드 중복 발화 방지, 다른 문자/설정 값 무시. 첫 교차확인 전까지 기존 경로 유지, 이후 모호한 1/2 구식 경로 억제.
- **실제 로그를 Kotlin 로직에 재입력**한 결과 8 전환(SPORT→ECO→NORMAL→SPORT→ECO→NORMAL→SPORT→ECO) 성공. 최초 정상 신호는 설정값 관측에서 95초 이상 떨어져 확증 부족으로 생략됨. 놓친 이벤트를 가짜 발화로 복원하지 않음.
- 기록 라벨: `MODE_2602_DUAL_SOURCE_CONFIRMED`, `MODE_ENERGY_12_SUPPRESSED`.
- 실차 v0.17.27 발화·사운드까지 성공한 증거는 **아직 없음**.

## 내비 5종 실제 한계와 추가 실험
- 현행 `ExternalAppAudioRouter`는 원래 5개 대상 체크박스만 저장. 타 UID 출력 변경은 구현되어 있지 않음. 기존 체크 ON 자체가 실제 라우팅을 뜻하지 않음.
- 2026-10-18 `dumpsys media.audio_policy`에 `primary navi` output, BYD OEM `AUDIO_OUTPUT_FLAG_NAVI|UE|GAODE`, `STREAM_NAVI` 14; MCon K 설치 UID 10131/allowPlaybackCapture=true 관측. **정책상 경로 존재와 제3자 UID 강제 라우팅 권한은 다름.**
- 신규 `NavPlaybackCaptureRelayService`는 사용자가 Android 재생 캡처를 승인한 경우에만 설치된 5개 패키지 중 하나의 정확한 UID의 MEDIA/GAME/UNKNOWN 신호를 AudioRecord로 수신하여 우리 앱 AudioTrack의 stream14로 **시험 출력**. 원본 PCM은 저장하지 않으며, 5초마다 전체 수신량/비영 PCM 양만 `nav_audio_lab/uid_relay_status.log` 기록. 사용자 STOP 버튼/시스템 캡처 중단 가능.
- Android 10 공식 캡처 정책상 `USAGE_ASSISTANCE_NAVIGATION_GUIDANCE`는 캡처 불가, 상대 앱의 허용 정책·MediaProjection 승인·같은 사용자 프로필 필요. 일반 미디어도 이미 출력되고 있다면 중복 재생될 수 있음. 비상등/차량 믹서/HAL 변경, 권한 우회는 없음. **다섯 앱의 운전석 길안내 확정 구현이 아니라 검증 가능한 선택적 경로**.
- UI: 내비 오디오 라우팅 실험실 → STEP 3B, 기본 OFF / 명시 동의 / 종료 / 실측값 조회. 미작동 앱이 있을 수 있고 5종 전체 성공 주장은 금지.

## 기타 유지
- v0.17.26의 Edge TTS 7.3.1, 남녀 한국어 WAV 60개 생성 필수 및 SHA256 APK 검사 유지.
- 2분할, BSD, 오토홀드, 회생제동 등 기존 코드 보존. 사진상 기존 체크 상태는 (기본 깜박이 게이트 ON, 클릭 보조 ON, 즉시 알림 OFF)이고 빨간 X/O 표시는 변경 희망으로 보이지만, 이번 텍스트 요청에서 직접 확인된 수정 대상은 NORMAL과 내비 출력이므로 BSD 기존 사용자 설정을 강제 변경하지 않음.
- 패키지 `com.byd.dolphin.drivealerts` 유지, versionCode 53, 동일 서명키일 때만 데이터 보존 덮어 설치 가능.

## 증명 수준 / 다음 단계
- 로컬 원본 JSONL 리플레이와 Kotlin gate 시험: 통과.
- 기존 v0.17.24, v0.17.22 소스·Kotlin 시험: 통과.
- APK 전체 Gradle 컴파일 / Edge 재생성: 이 컨테이너에서 미수행, GitHub Actions 필요.
- 자동차 2602에서 정상 음성 출력, 5종 앱 운전석 실제 출력: 미검증. 결과가 실제 청취와 UID 캡처 통계에 근거하기 전 VERIFIED로 올리지 않음.
