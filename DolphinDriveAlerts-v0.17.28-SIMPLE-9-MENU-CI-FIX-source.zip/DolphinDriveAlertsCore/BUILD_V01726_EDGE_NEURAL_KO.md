# v0.17.26 Edge Neural 빌드 안내

**반드시 기존 앱을 삭제하지 마세요.** 같은 패키지명, 증가한 versionCode=52와 기존 설치 APK의 동일 서명키를 사용해야 데이터가 유지됩니다.

## GitHub에 올릴 파일 2개
1. 저장소 최상위: `DolphinDriveAlerts-v0.17.26-EDGE-NEURAL-VOICE-RESTORE-source.zip`
2. `.github/workflows/build-v01726-edge-neural-signed-update.yml` 경로: 같은 이름의 YML

Actions에서 **Build Dolphin Drive Alerts v0.17.26 Edge Korean Neural 60 Voices Signed Update APK** 실행.
- `refresh_voice_assets=false`: 검증된 Edge 캐시 있으면 재사용, 없으면 Edge 7.3.1에서 60개 직접 생성.
- `refresh_voice_assets=true` (**이번 빌드 기본값**): 무조건 Edge 7.3.1에서 남/여 60개 다시 생성(서버 연결 테스트 포함).
- 남성 `ko-KR-InJoonNeural` 30개 / 여성 `ko-KR-SunHiNeural` 30개.
- 403 또는 서버 오류 시 남녀 파일을 제거하거나 가짜 음성으로 대체하지 않고 실패 처리.
- APK 내부에 60개 WAV가 포함됐는지, 각 해시/원천 음성이 맞는지 전량 확인 후 배포.

## 중요한 서명 제약
이전 v0.17.25의 서명 보호가 그대로 유지됩니다. 기존 설치된 APK 서명키가 Secrets `DOLPHIN_DEBUG_KEYSTORE_B64`와 일치하고, 설치 APK 인증서 SHA256을 Variables `DOLPHIN_INSTALLED_CERT_SHA256`에 등록해야 빌드가 진행됩니다. **기존에 사용한 키가 없다면 APK 파일만으로는 복구할 수 없습니다.** 새 임시 키로 덮어 설치하면 실패하므로 우회하지 마세요.

## 검증 범위
새 빌드에서는 v0.17.24의 NORMAL/BSD/분할 코드도 그대로 유지됩니다. TTS 라이브러리의 7.2.8 → 7.3.1 업데이트와 음성 필수 포함을 검증하려는 빌드입니다. GitHub 클라우드 실제 Edge 음성 생성/Android Gradle 빌드 및 실차 청취는 아직 실행하지 못했습니다.
