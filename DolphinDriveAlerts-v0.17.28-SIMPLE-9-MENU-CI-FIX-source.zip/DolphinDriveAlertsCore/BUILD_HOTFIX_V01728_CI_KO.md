# Dolphin Drive Alerts v0.17.28 — 2026-10-21 GitHub Actions Kotlin 회귀검사 수정

## 원본 증거
- 입력: `붙여넣은 마크다운(20261021-072255).md` / GitHub Actions run 39555076364, 2026-10-21 06:24 UTC.
- 실패 단계: `Verify actual EQ Kotlin source against Android API contract stubs`, 오래된 `tools/verify_v0179_callback_kotlin_compile.py`.
- 에러: `ReferenceVehicleEventBridge.kt:243`의 `unresolved reference 'InstrumentDriveModeGate'`와 `mode/instrumentRaw/settingRaw/deltaMs` 연쇄 오류.
- 원인: v0.17.27에서 사용하기 시작한 새 게이트를 v0.17.9·v0.17.11 옛 컴파일 fixture의 source set에서 누락. 전체 Android Gradle 컴파일 실패 증거는 아님.

## 실제 수정 파일 (기능 로직 변경 없음)
- `tools/verify_v0179_callback_kotlin_compile.py`: `InstrumentDriveModeGate.kt`를 실제 Kotlin 입력 목록에 추가.
- `tools/verify_v01711_bsd_any_indicator.py`: 동일 의존성 추가. 첫 번째 수정 후 두 번째 구식 테스트에서도 동일 결함을 발견해 교정.
- `tools/verify_v01728_ci_source_dependencies.py`: 위 두 목록 누락의 재발을 방지하는 사전 검사 추가.
- GitHub Actions YML: 이 검사 실행 및 고유한 CI 수정 소스 ZIP 사용.
- 변경 없음: Kotlin 앱 소스·9개 메뉴·BSD 설정·주행 모드·내비 오디오·Voice 60 WAV·Gradle `versionCode 54`·패키지명.

## 검증과 한계
- 문제를 일으킨 `verify_v0179_callback_kotlin_compile.py` 실제 `kotlinc` PASS.
- `verify_v01711_bsd_any_indicator.py` 실제 `kotlinc`/BSD 시험 PASS.
- 관련 기존 Kotlin 회귀 시험 13종 중 12종 최초 PASS, 나머지 1종 결함 수정 후 PASS.
- 기존 `verify_v01728_simple_menu.py` 16/16, `verify_v01727_realcar_mode_nav.py`, `verify_v0178_integration.py` 57/57, `verify_v0179_integration.py` 48/48 PASS.
- 원본 소스 ZIP 대비 실제 **모든 `app/src/main` 파일 바이트 동일**, UI/기능 변경 없음.
- GitHub Android 전체 컴파일 및 APK 생성은 이 환경에서 검증되지 않았음.
- 로그의 `DOLPHIN_SIGNING_MODE=ONE_TIME_EPHEMERAL`도 확인됨: 이번 빌드는 매회 임시키를 생성할 수 있어 기존 앱과 데이터 보존 업데이트 불가능. **키스토어 SECRET이 설정되기 전에는 기존 설치 앱 삭제 금지**.

## GitHub 사용
1. 저장소 루트에 `DolphinDriveAlerts-v0.17.28-SIMPLE-9-MENU-CI-FIX-source.zip` 업로드 (기존 source.zip 교체 불필요).
2. `.github/workflows/build-v01728-simple-9-menu-ci-fix.yml`로 새 YML 업로드.
3. Actions에서 `Build Dolphin Drive Alerts v0.17.28 Simple 9 Menu - CI source dependency fix` 실행.
4. Edge WAV 60개, Android Gradle, 서명, APK 포함 여부까지 최종 확인. Android/실차는 결과 확인 전 성공으로 간주하지 않음.
