# v0.17.28 UI 정리 빌드 방법
1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 최상위에 `DolphinDriveAlerts-v0.17.28-SIMPLE-9-MENU-source.zip` 업로드.
2. `.github/workflows/build-v01728-simple-9-menu.yml`로 동봉된 YML 업로드.
3. GitHub Actions에서 `Build Dolphin Drive Alerts v0.17.28 Simple 9-Menu UI + Voice/Nav/Alerts Preservation` 실행.
4. APK가 생성되면 Artifact에서 내려받아 기존 설치본에 **삭제하지 않고** 설치. 동일 앱 패키지/같은 서명키 및 더 높은 versionCode가 필요.
5. `voice_mode` 구성을 변경하지 않음. 기존 Edge Neural 60 WAV 생성/검증 구성을 계속 사용.
6. 정상 기능 회귀 시험: BSD 기존 1+2, 3; 부팅 자동실행; 2분할 앱2개; 회전; EQ; 로그 ZIP; 기존 세부 설정값 유지.

빌드 시 `DOLPHIN_DEBUG_KEYSTORE_B64` Secret(기존에 설치한 APK와 같은 키)을 사용해야 업데이트 설치와 설정 보존이 가능합니다. 키는 공개 저장소/다운로드용 빌드팩에 넣지 마세요. Secret 없이 빌드하면 해당 워크플로 정책에 따라 별도 신규 설치가 필요할 수 있습니다.

**Android APK 전체 컴파일은 본 작업환경에서 수행하지 않았습니다.** GitHub Actions 결과를 확인해야 합니다.
