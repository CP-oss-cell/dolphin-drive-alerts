package com.byd.dolphin.drivealerts.automation

/** Android 10/DiLink stack/task parser, derived from the v30 Assistant split implementation. */
internal object LegacySplitTaskLocator {
    data class State(val taskId: Int = -1, val stackId: Int = -1, val mode: Int = -1) {
        val found: Boolean get() = taskId >= 0 && stackId >= 0
    }

    fun findTask(raw: String, pkg: String, requiredMarker: String? = null): State {
        var stack = -1
        var mode = -1
        var task = -1
        raw.lineSequence().forEach { original ->
            val line = original.trim()
            stackId(line)?.let { stack = it; mode = -1; task = -1 }
            windowMode(line)?.let { mode = it }
            taskId(line)?.let { task = it }
            val owns = line.contains("A=$pkg") || line.contains("$pkg/") || line.contains(" $pkg ")
            if (task >= 0 && stack >= 0 && owns && (requiredMarker == null || line.contains(requiredMarker)))
                return State(task, stack, mode)
        }
        return State()
    }

    fun findStack(raw: String, targetMode: Int): Int {
        var stack = -1
        raw.lineSequence().forEach { original ->
            val line = original.trim()
            stackId(line)?.let { stack = it }
            if (stack >= 0 && windowMode(line) == targetMode) return stack
        }
        return -1
    }

    private fun stackId(line: String): Int? =
        Regex("""(?i)(?:ActivityStack[^#]*|(?:Root)?Stack\s*)#(\d+)""").find(line)?.groupValues?.get(1)?.toIntOrNull()

    private fun taskId(line: String): Int? {
        if (!line.contains("Task{",true) && !line.contains("TaskRecord{",true) &&
            !line.contains("Task #",true)) return null
        return Regex("""(?i)(?:TaskRecord|Task)\{[^}]*?#(\d+)\b""").find(line)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("""(?i)Task\{\s*(\d+)(?=\s|\})""").find(line)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("""(?i)Task\s+#(\d+)""").find(line)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun windowMode(line: String): Int? {
        val s = line.lowercase()
        if ("split-screen-primary" in s) return 3
        if ("split-screen-secondary" in s) return 4
        return Regex("""(?i)(?:mWindowingMode|windowingMode|mode)\s*[=:]\s*([134])\b""")
            .find(line)?.groupValues?.get(1)?.toIntOrNull()
    }
}
