package com.byd.dolphin.drivealerts.automation

/** Read-only verification: package mention != two different foreground split tasks. */
internal object SplitTaskReadback {
    data class Inspection(val hasDefinitiveMismatch: Boolean, val detail: String,
        val verified: Boolean = false)

    fun inspect(raw: String, first: String, second: String): Inspection {
        val blocks = raw.split(Regex("""(?=Task\{|Task #\d+|RootTask #\d+)""", RegexOption.IGNORE_CASE))
        data class Evidence(val task: String?, val modes: Set<Int>)
        fun evidenceFor(pkg: String): List<Evidence> = blocks.filter { pkg in it }.map { block ->
            // Android/DiLink dumpsys variants include Task{101 mode=3 ...},
            // Task{a #17 windowingMode=3 ...}, Task #101 and taskId=101.
            // The legacy Task{101 form appeared in v0.17.13's real Kotlin fixture;
            // it must not be accepted without an independently parsed task ID.
            val task = Regex("""(?i)\b(?:taskId\s*[=:]\s*|(?:Root)?Task\s+#)(\d+)\b""").find(block)
                ?.groupValues?.get(1)
                ?: Regex("""(?i)\bTask\{\s*(\d+)(?=\s|\})""").find(block)
                    ?.groupValues?.get(1)
                ?: Regex("""(?i)\bTask\{[^}]*?#(\d+)\b""").find(block)
                    ?.groupValues?.get(1)
            val modes = Regex("""(?i)(?:windowingMode|mode)\s*[=:]\s*(\d+)""")
                .findAll(block).mapNotNull { it.groupValues[1].toIntOrNull() }
                .filter { it in 1..5 }.toSet()
            Evidence(task, modes)
        }
        val a = evidenceFor(first)
        val b = evidenceFor(second)
        val firstModes = a.flatMap { it.modes }.toSet()
        val secondModes = b.flatMap { it.modes }.toSet()
        val firstIds = a.mapNotNull { it.task }.toSet()
        val secondIds = b.mapNotNull { it.task }.toSet()
        // A shared Task containing both packages must never be called a
        // verified independent 2-app split, even if another Task is also seen.
        val distinctTasks = firstIds.isNotEmpty() && secondIds.isNotEmpty() &&
            firstIds.intersect(secondIds).isEmpty()
        val splitModes = (3 in firstModes && 4 in secondModes) ||
            (4 in firstModes && 3 in secondModes)
        val selfCollision = firstIds.isNotEmpty() && secondIds.isNotEmpty() &&
            firstIds.intersect(secondIds).isNotEmpty()
        val mismatch = selfCollision || (firstModes.isNotEmpty() && secondModes.isNotEmpty() && !splitModes)
        val verified = !mismatch && distinctTasks && splitModes
        val verdict = when {
            mismatch -> "MISMATCH"
            verified -> "SPLIT_TASKS_SEEN"
            else -> "TASK_MODES_UNRESOLVED"
        }
        return Inspection(mismatch,
            "result=$verdict firstTaskIds=$firstIds secondTaskIds=$secondIds " +
            "firstModes=$firstModes secondModes=$secondModes;independent=$distinctTasks",
            verified)
    }
}
