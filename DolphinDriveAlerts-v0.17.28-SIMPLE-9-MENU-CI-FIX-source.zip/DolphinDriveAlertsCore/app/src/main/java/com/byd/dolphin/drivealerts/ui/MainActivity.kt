package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentUris
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.RotationPolicy
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

class MainActivity : Activity() {
    private lateinit var unifiedCaptureStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(buildUi())
        } catch (t: Throwable) {
            setContentView(TextView(this).apply {
                text = "Dolphin Drive Alerts SAFE START\n\nUI 초기화 오류: ${t.javaClass.simpleName}: ${t.message}\n\n이 화면이 보이면 앱 자체 실행은 정상입니다."
                textSize = 18f
                setPadding(32, 32, 32, 32)
            })
        }
        if (AdbSetupActivity.shouldShowFirstRun(this)) {
            AdbSetupActivity.markFirstRunShown(this)
            AlertDialog.Builder(this)
                .setTitle("첫 실행 · 차량 ADB 연결 안내")
                .setMessage("2분할 기능은 차량 자체 로컬 ADB 인증이 필요할 수 있습니다. " +
                    "PC 없이 차량 화면에서 RSA 승인 요청을 시도할 수 있습니다. " +
                    "지금 연결하거나 나중에 화면에서 연결할 수 있습니다. " +
                    "차량 adbd가 닫혀 있으면 승인창이 나타나지 않을 수 있습니다.")
                .setPositiveButton("연결 화면 열기") { _, _ ->
                    startActivity(Intent(this, AdbSetupActivity::class.java))
                }
                .setNegativeButton("나중에", null)
                .show()
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure {
                Toast.makeText(this, "차량 감시 서비스 시작 실패: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 24, 30, 30)
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "Dolphin Drive Alerts · 0.17.28"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "한국형 돌핀: 오버레이는 순정 설정, 접근성·알림 접근·사용기록은 승인된 ADB를 통한 설정 및 상태 확인."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실"))
        box.addView(Button(this).apply {
            text = "오디오 라우팅 실험실 · 순정 스캔 → 후보 청취 → 5종 내비 비교 → ZIP 저장"
            setOnClickListener { startActivity(Intent(this@MainActivity, NavAudioLabActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "Route 5/6 운전석 자체 시험음은 기존 실차 성공 사례. 다른 UID의 실제 내비 안내음 강제 변경은 지원 권한 확인 전까지 불가능하며 성공으로 표시하지 않습니다."
            textSize = 13f
        })
        box.addView(section("NEW · ECO/NORMAL/SPORT 실차 3상태 교정"))
        box.addView(Button(this).apply {
            text="주행모드 원본값 기록 · ECO / NORMAL / SPORT"
            setOnClickListener { startActivity(Intent(this@MainActivity, DriveModeCalibrationActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text="차량 P 상태에서 세 모드를 각각 읽기 전용 기록. 신호가 구별되지 않으면 NORMAL 자동 안내를 억지로 켜지 않습니다."
            textSize=13f
        })
        box.addView(section("로컬 ADB / 최초 승인 · PC 연결 불필요"))
        box.addView(Button(this).apply {
            text = "차량 ADB 연결 · RSA 승인 요청 · 상태 확인"
            setOnClickListener { startActivity(Intent(this@MainActivity, AdbSetupActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "ADB RSA 승인 여부는 차량 화면의 실제 팝업에서 직접 확인합니다. " +
                "연결 성공만으로 분할화면까지 성공한 것은 아닙니다. " +
                "연결 후 별도 화면 분할 프로필에서 2개 앱 실행과 비율을 시험하세요."
            textSize = 13f
        })
        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val raw14 = RadioButton(this).apply { text = "운전석(raw14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(raw14); route.addView(media); box.addView(route)
        when (AlertPreferences.route(this)) {
            OutputRoute.DRIVER_STREAM14 -> driver.isChecked = true
            OutputRoute.DRIVER_RAW14 -> raw14.isChecked = true
            OutputRoute.MEDIA -> media.isChecked = true
        }
        route.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setRoute(this, when (id) {
                driver.id -> OutputRoute.DRIVER_STREAM14
                raw14.id -> OutputRoute.DRIVER_RAW14
                else -> OutputRoute.MEDIA
            })
        }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개 + 단발 기본음 남/여 2개(총 60개)를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        // Real-car verified: keep a single ON/OFF switch.
        // Vehicle event listener and fallback KeyEvent detector remain active in DrivingAlertService.
        box.addView(section("핸들 메뉴/이전 버튼 3연타"))
        box.addView(CheckBox(this).apply {
            text = "핸들 3연타 단발 음성 ON/OFF"
            isChecked = SteeringTriggerPreferences.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                SteeringTriggerPreferences.setEnabled(this@MainActivity, checked)
            }
        })

        box.addView(section("후측방 경고 · 두 가지 독립 설정"))
        box.addView(CheckBox(this).apply {
            text = "BSD 감지 + 어느 한쪽 깜빡이 → 일반 후측방 음성 (기본 ON)"
            isChecked = AlertPreferences.bsdBlinkerEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdBlinkerEnabled(this@MainActivity, on) }
        })
        box.addView(CheckBox(this).apply {
            text = "BSD 클릭음 기반 깜박이 보조 판독 · 시험 전용 (기본 OFF / 비상등 오인 가능)"
            isChecked = AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdTurnSoundExperimentalEnabled(this@MainActivity, on) }
        })
        box.addView(CheckBox(this).apply {
            text = "BSD 감지 즉시 일반 후측방 음성 (선택 ON, 기본 OFF)"
            isChecked = AlertPreferences.bsdInstantEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on -> AlertPreferences.setBsdInstantEnabled(this@MainActivity, on) }
        })
        box.addView(TextView(this).apply {
            text = "두 옵션을 동시에 켜도 감지 1회당 공통 음성 최대 1회. " +
                "왼쪽/오른쪽 전용 음성은 실제 좌우 BSD 위험 신호 검증 전 자동 실행하지 않습니다. " +
                "BSD(raw2)+실제 양쪽 중 하나의 깜박이 확인 시 1회 안내합니다. getter가 비어 있으면 " +
                "1→2 반복·3 종료의 계기판 클릭음 후보를 보조 사용하지만 비상등과는 구별되지 않을 수 있습니다. " +
                "위험 실제 감지 없는 깜박이만으로는 발화하지 않습니다. 순정 경고는 그대로 유지합니다."
            textSize = 13f
        })
        box.addView(section("ICC 차선이탈·앞차 출발 · 실차 신호 연구"))
        box.addView(TextView(this).apply {
            text = "글로벌 2602의 DiPilot 콜백·ADAS 원시값을 기록합니다. " +
                "ICC 작동 여부와 실제 차선이탈/앞차 출발 경고의 활성값이 연결되기 전에는 " +
                "설정 ON/OFF 값을 위험 경고로 오인해 음성을 내지 않습니다."
            textSize = 13f
        })
        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(CheckBox(this).apply {
            text = "시동 시 자동 백그라운드 실행"
            isChecked = AlertPreferences.autoStartEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> AlertPreferences.setAutoStartEnabled(this@MainActivity, checked) }
        })
        box.addView(TextView(this).apply {
            text = "기본값 ON. 최초 설치 후 앱을 1회 실행하면 이후 BOOT_COMPLETED, Android/BYD/Qualcomm Quick Boot, USER_PRESENT/USER_UNLOCKED, SCREEN_ON, ACTION_POWER_CONNECTED, 앱 업데이트와 BYD ACC_ON/IGN_ON/ACC_MODE_CHANGED 신호에서 foreground 서비스 시작을 재요청합니다. ACC_OFF/ACTION_POWER_DISCONNECTED는 종료측 상태로 기록만 하고 서비스를 새로 시작하지 않습니다. 서비스는 START_STICKY + stopWithTask=false라 최근 앱에서 지워도 계속 유지됩니다. 사용자가 Android 설정에서 강제 종료(force-stop)한 경우만 정책상 앱을 다시 한 번 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(Button(this).apply {
            text = "시동 앱 자동실행 · 여러 앱 순서/초 단위/미디어 재생 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AutoLaunchSettingsActivity::class.java)) }
        })
        box.addView(section("화면 분할 프로필"))
        box.addView(Button(this).apply {
            text = "2앱 분할 프로필 · 비율 % · 이름/바로가기 · 카메라 복원"
            setOnClickListener { startActivity(Intent(this@MainActivity,SplitProfilesActivity::class.java)) }
        })
        box.addView(section("통합 로그 수집"))
        box.addView(TextView(this).apply {
            text = "수집 시작을 누른 뒤 기능을 시험하고, 수집 종료를 누르면 해당 구간의 차량 RAW·음성·앱·오류 기록과 시스템 진단을 ZIP 하나로 Download 폴더에 저장합니다. 시동 주행알림 서비스는 수집 종료 후에도 정상 유지됩니다."
            textSize = 13f
        })
        unifiedCaptureStatus = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8) }
        box.addView(unifiedCaptureStatus)
        updateCaptureStatus()
        box.addView(Button(this).apply {
            text = "수집 시작"
            setOnClickListener {
                runCatching { DrivingAlertService.beginUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "수집 시작 요청 중… (서비스 알림에 결과 표시)" }
                    .onFailure { unifiedCaptureStatus.text = "시작 요청 실패: ${it.message}" }
            }
        })
        box.addView(Button(this).apply {
            text = "수집 종료"
            setOnClickListener {
                runCatching { DrivingAlertService.endUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "로그 저장 요청 중… (완료 시 상단 알림 및 Download 폴더 확인)" }
                    .onFailure { unifiedCaptureStatus.text = "저장 요청 실패: ${it.message}" }
            }
        })

        // v0.17.9: explicit read-only A/B markers, no unsafe AVAS/ECU writes.
        box.addView(section("글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구"))
        box.addView(TextView(this).apply {
            text = "먼저 '수집 시작'을 누르세요. 차량을 안전하게 정차해 둔 상태에서 순정 내비 안내음과 다른 내비 앱 안내음이 실제로 나올 때 각각 기록합니다. 아래 버튼은 차량 소리/제어를 변경하지 않습니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "① 순정 내비 안내음 출력 중 · 오디오 경로 기록"
            setOnClickListener { DrivingAlertService.captureQuick(this@MainActivity, "2602_OEM_NAV_GUIDANCE") }
        })
        box.addView(Button(this).apply {
            text = "② 다른 내비 안내음 출력 중 · 오디오 경로 기록"
            setOnClickListener { DrivingAlertService.captureQuick(this@MainActivity, "2602_THIRD_PARTY_NAV_GUIDANCE") }
        })
        box.addView(Button(this).apply {
            text = "③ 순정 보행자 경고음 설정 시험 구간만 기록 (12초)"
            setOnClickListener { DrivingAlertService.captureWindow(this@MainActivity, "2602_AVAS_STOCK_SETTING", 12) }
        })
        box.addView(TextView(this).apply {
            text = "③은 BYD 순정 설정을 사용자가 직접 조작할 때만 전후 로그를 채집합니다. 외부 스피커에 음성을 보내거나 AVAS를 끄는 명령은 절대 실행하지 않습니다."
            textSize = 12f
        })

        box.addView(section("ADB 권한 관리"))
        box.addView(Button(this).apply {
            text = "설치 앱 선택 · 알림 수신/TBT · 위치 권한/서비스 · ADB 권한 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AppPermissionManagerActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "차량에서 일반 권한 설정이 막힌 항목만 승인된 ADB로 적용합니다. 순정 화면 크기를 바꾸는 시험은 제공하지 않습니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "ADB 필수 권한 적용 · 접근성/알림 리스너/사용기록"
            setOnClickListener {
                isEnabled = false
                Thread {
                    val message = runCatching {
                        com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper.apply(this@MainActivity)
                            .lines.joinToString("\n")
                    }.getOrElse { "권한 설정 오류: ${it.javaClass.simpleName}: ${it.message}" }
                    runOnUiThread {
                        isEnabled = true
                        android.app.AlertDialog.Builder(this@MainActivity).setTitle("ADB 권한 적용 및 검증")
                            .setMessage(message).setPositiveButton("닫기", null).show()
                    }
                }.start()
            }
        })
        box.addView(section("디스플레이 DPI / 화면 회전 / 내비 음성"))
        box.addView(CheckBox(this).apply {
            text = "전역 화면 회전 ON/OFF"
            isChecked = RotationPolicy.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                RotationPolicy.setEnabled(this@MainActivity, checked)
                Toast.makeText(this@MainActivity, if (checked) "회전 규칙 활성화" else "회전 오버레이 해제 · 순정 복원", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply { text = "디스플레이 DPI · 전역 회전 · 내비 5종 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(TextView(this).apply {
            text = "화면 회전은 Orientation Control의 0×0 투명 오버레이 방식이며 모든 앱에 전역 적용됩니다. 앱 선택·UsageStats 감시에 의존하지 않습니다."
            textSize = 13f
        })
        box.addView(TextView(this).apply {
            text = "접근성·알림 접근·사용기록은 차량 순정 메뉴가 차단되어 있으므로 위 'ADB 필수 권한 적용'에서 설정합니다. ADB 서버가 닫혀 있다면 차량 내 ADB 활성화 경로를 먼저 확인해야 합니다. PC는 이 앱의 필수 절차가 아닙니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "화면 위 표시 권한 열기"
            setOnClickListener { SafeSettingsLauncher.open(this@MainActivity, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
        })
        box.addView(TextView(this).apply {
            text = "DPI는 전체 화면에만 명시적으로 적용되며 변경 전 기준값을 저장합니다. 타 앱 운전석 출력은 BYD 오디오 UID 라우팅 구현 전까지 진단 대상만 저장합니다."
            textSize = 13f
        })

        box.addView(section("이퀄라이저 / 음향 효과"))
        box.addView(Button(this).apply {
            text = "저음 · 중음 · 고음 / Centerpoint 360 / Sound Focus"
            setOnClickListener { startActivity(Intent(this@MainActivity, AudioTuningActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "3밴드 조절은 사용 가능한 오디오 세션에서만 적용되며, 순정 차량 DSP 기반 360/공간 음장은 아직 지원하지 않습니다."
            textSize = 13f
        })

        organizeUi(box)
        return root
    }

    /** Navigation-only layout change. Existing switches, listeners and feature engines are reused. */
    private fun organizeUi(box: LinearLayout) {
        val headings = mapOf(
            "NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실" to 7,
            "NEW · ECO/NORMAL/SPORT 실차 3상태 교정" to 1,
            "로컬 ADB / 최초 승인 · PC 연결 불필요" to 9,
            "알림 출력 경로" to 1,
            "알림 종류" to 1,
            "핸들 메뉴/이전 버튼 3연타" to 1,
            "후측방 경고 · 두 가지 독립 설정" to 6,
            "ICC 차선이탈·앞차 출발 · 실차 신호 연구" to 1,
            "자동 실행 / 백그라운드" to 2,
            "화면 분할 프로필" to 3,
            "통합 로그 수집" to 10,
            "글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구" to 8,
            "ADB 권한 관리" to 9,
            "디스플레이 DPI / 화면 회전 / 내비 음성" to 4,
            "이퀄라이저 / 음향 효과" to 5
        )
        val sourceViews = ArrayList<View>()
        while (box.childCount > 0) {
            val view = box.getChildAt(0)
            box.removeViewAt(0)
            sourceViews.add(view)
        }
        val grouped = (1..10).associateWith { mutableListOf<View>() }
        var section = 0
        for (view in sourceViews) {
            val title = (view as? TextView)?.text?.toString()
            if (title != null && headings.containsKey(title)) section = headings[title] ?: 0
            if (section == 0) continue // old banner replaced with plain heading
            if (view is TextView && title != null && headings.containsKey(title)) {
                view.text = when (title) {
                    "NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실" -> "내비 안내음 출력·진단"
                    "NEW · ECO/NORMAL/SPORT 실차 3상태 교정" -> "주행모드 확인 (필요할 때만)"
                    "로컬 ADB / 최초 승인 · PC 연결 불필요" -> "ADB 연결 및 승인"
                    "후측방 경고 · 두 가지 독립 설정" -> "BSD 알림 세 가지 설정"
                    "ICC 차선이탈·앞차 출발 · 실차 신호 연구" -> "ICC · 차선이탈 · 앞차 출발"
                    "글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구" -> "외부 스피커 신호 점검 (읽기 전용)"
                    "디스플레이 DPI / 화면 회전 / 내비 음성" -> "화면 회전 · DPI 설정"
                    else -> title
                }
            }
            // Move the two navigation read-only snapshots to the navigation category;
            // the AVAS snapshot stays exclusively under external speaker.
            val destination = if (section == 8 && view is Button &&
                (view.text?.startsWith("① 순정 내비") == true ||
                 view.text?.startsWith("② 다른 내비") == true)) 7 else section
            grouped.getValue(destination).add(view)
        }
        val menuNames = listOf(
            "자동차 주행 보조 알림",
            "부팅 시 앱 자동 실행",
            "화면 분할",
            "화면 회전 · DPI",
            "이퀄라이저 · 음장 효과",
            "BSD 감지 알림",
            "내비 5종 운전석 알림",
            "외부 스피커(차량 밖) 알림",
            "ADB 권한 부여",
            "로그 수집 · 자동 점검 · ZIP 공유"
        )
        box.addView(TextView(this).apply {
            text = "Dolphin Drive Alerts"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 2, 0, 8)
        })
        box.addView(TextView(this).apply {
            text = "사용할 기능을 선택하세요. 필요한 메뉴만 열립니다. 기존 설정은 그대로 유지됩니다."
            textSize = 14f
            setPadding(0, 0, 0, 12)
        })
        val cards = mutableListOf<LinearLayout>()
        menuNames.forEachIndexed { index, label ->
            val key = index + 1
            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 4, 16, 18)
                visibility = View.GONE
            }
            grouped.getValue(key).forEach { details.addView(it) }
            when (key) {
                1 -> {
                    // Keep calibration accessible but not prominent on the home screen.
                    details.addView(TextView(this).apply {
                        text = "기어·오토홀드·회생제동·ECO/NORMAL/SPORT·ICC·앞차 출발·음성·핸들 3연타"
                        textSize = 13f
                    }, 0)
                }
                6 -> details.addView(TextView(this).apply {
                    text = "실차 확인: 1번 단독 미동작, 1번+2번 작동, 3번 작동. 정상 조합은 변경하지 않습니다."
                    textSize = 13f
                }, 0)
                7 -> {
                    details.addView(TextView(this).apply {
                        text = "5종 내비의 운전석 출력은 실차 검증 중입니다. 체크는 대상 저장이며 실제 출력 성공을 뜻하지 않습니다."
                        textSize = 13f
                    }, 0)
                    val navIndex = 1
                    com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.forEachIndexed { idx, entry ->
                        details.addView(CheckBox(this).apply {
                            text = entry.title
                            isChecked = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.enabled(this@MainActivity, entry.pkg)
                            setOnCheckedChangeListener { _, enabled ->
                                com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.setEnabled(this@MainActivity, entry.pkg, enabled)
                            }
                        }, navIndex + idx)
                    }
                }
                8 -> details.addView(TextView(this).apply {
                    text = "차량 밖 보행자 경고 스피커(AVAS)입니다. 운전석 스피커와 다릅니다. 현재 읽기 전용 진단만 제공하며 임의 음성 출력은 미구현입니다."
                    textSize = 13f
                }, 0)
                10 -> {
                    // Auto-check is intentionally read-only; it does not claim full vehicle feature success.
                    val endIndex = (0 until details.childCount).firstOrNull { idx ->
                        (details.getChildAt(idx) as? Button)?.text == "수집 종료"
                    } ?: details.childCount
                    details.addView(Button(this).apply {
                        text = "자동 점검 · 설정/앱/오디오 장치 확인 (읽기 전용)"
                        setOnClickListener { runReadOnlyAutoCheck() }
                    }, endIndex)
                    details.addView(Button(this).apply {
                        text = "최근 다운로드 로그 ZIP 공유"
                        setOnClickListener { shareLatestLogZip() }
                    })
                }
            }
            // Keep lengthy engineering notes accessible without showing them on every visit.
            val helpViews = mutableListOf<View>()
            var pos = details.childCount - 1
            while (pos >= 0) {
                val v = details.getChildAt(pos)
                if (v is TextView && v !is Button && v !is CheckBox && v !is RadioButton &&
                    (v.text?.length ?: 0) > 240) {
                    details.removeViewAt(pos)
                    helpViews.add(0, v)
                }
                pos--
            }
            if (helpViews.isNotEmpty()) {
                val helpPanel = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                }
                helpViews.forEach { helpPanel.addView(it) }
                details.addView(Button(this).apply {
                    text = "자세한 설명 보기 ▾"
                    isAllCaps = false
                    setOnClickListener { helpPanel.visibility = if (helpPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
                })
                details.addView(helpPanel)
            }
            val openButton = Button(this).apply {
                text = "${key}. $label   ▾"
                isAllCaps = false
                textSize = 17f
                setOnClickListener {
                    val opening = details.visibility != View.VISIBLE
                    cards.forEach { it.visibility = View.GONE }
                    if (opening) details.visibility = View.VISIBLE
                }
            }
            box.addView(openButton)
            box.addView(details)
            cards.add(details)
        }
    }

    private fun runReadOnlyAutoCheck() {
        val installed = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.map { app ->
            val exists = runCatching {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(app.pkg, 0) != null
            }.getOrDefault(false)
            "${app.title}: ${if (exists) "설치 확인" else "미설치/조회 불가"}"
        }
        val audio = getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
        val devices = runCatching {
            audio?.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)?.joinToString(", ") {
                "${it.type}:${it.productName}"
            }.orEmpty()
        }.getOrDefault("")
        val message = buildString {
            appendLine("Android SDK: ${android.os.Build.VERSION.SDK_INT}")
            appendLine("부팅 자동 실행: ${AlertPreferences.autoStartEnabled(this@MainActivity)}")
            appendLine("전역 회전: ${RotationPolicy.enabled(this@MainActivity)}")
            appendLine("로그 상태: ${UnifiedLogCapture.state(this@MainActivity).status}")
            appendLine("후측방 1번: ${AlertPreferences.bsdBlinkerEnabled(this@MainActivity)}")
            appendLine("후측방 2번: ${AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)}")
            appendLine("후측방 3번: ${AlertPreferences.bsdInstantEnabled(this@MainActivity)}")
            appendLine("\n내비 5종 설치 확인\n${installed.joinToString("\n")}")
            appendLine("\n오디오 출력장치: ${devices.ifBlank { "조회 불가" }}")
            appendLine("\n이것은 읽기 전용 상태 점검입니다. 실제 차량 신호 발화/오디오 라우팅의 성공 여부는 판정하지 않습니다.")
        }
        AlertDialog.Builder(this).setTitle("자동 점검 결과")
            .setMessage(message).setPositiveButton("확인", null).show()
        // Add a corresponding snapshot only when capture is already enabled.
        if (UnifiedLogCapture.state(this).status == UnifiedLogCapture.RECORDING) {
            runCatching { DrivingAlertService.captureQuick(this, "USER_AUTOMATED_READONLY_CHECK") }
        }
    }

    private fun shareLatestLogZip() {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            AlertDialog.Builder(this).setTitle("로그 공유")
                .setMessage("Android 9 이하에서는 다운로드 폴더의 파일 관리자에서 DolphinDriveLogs_ ZIP을 선택해 공유하세요.")
                .setPositiveButton("확인", null).show()
            return
        }
        val uri = runCatching {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("DolphinDriveLogs_%.zip")
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    ContentUris.withAppendedId(collection, cursor.getLong(0))
                } else null
            }
        }.getOrNull()
        if (uri == null) {
            AlertDialog.Builder(this).setTitle("로그 ZIP 없음")
                .setMessage("먼저 수집 시작 → 필요한 테스트 → 수집 종료를 완료하세요. ZIP 저장이 끝나면 다시 공유할 수 있습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, "실차 로그 ZIP 공유")) }
            .onFailure { Toast.makeText(this, "공유 앱 열기 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 재시동 후 같은 세션 복구 시도 (전원 OFF 구간은 누락 가능) · '수집 종료'로 ZIP 저장"
            UnifiedLogCapture.SAVING -> "저장 중 · 완료되면 상단 알림으로 안내"
            UnifiedLogCapture.FAILED -> "저장 실패 · '수집 종료'를 다시 눌러 재시도"
            else -> "대기 중 · '수집 시작'을 눌러주세요"
        }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }

}
