package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.SelectedAppPermissionManager

/** Explicit per-app power/notification/accessibility/usage permission manager. */
class AppPermissionManagerActivity: Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root=ScrollView(this)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(28,20,28,28) }
        root.addView(box);setContentView(root)
        fun label(text:String)=TextView(this).apply { this.text=text;textSize=15f;setPadding(0,8,0,8) }
        box.addView(label("설치 앱 · ADB 권한 관리"))
        box.addView(label("TBT 내비 알림 수신: 'Dolphin Drive' 앱을 고르고 '알림 수신 접근'을 허용하세요. 이 권한은 알림 수신에 필요하지만 TBT 자동 표시는 별도 기능입니다."))
        box.addView(label("위치 권한은 앱별 권한과 차량 전체 위치 서비스 스위치를 구분합니다. 앱에서 선언하지 않은 권한은 부여할 수 없고 ADB 연결 승인도 필요합니다."))
        val pm=packageManager
        val apps=pm.getInstalledApplications(0).filter { it.enabled }
            .sortedWith(compareByDescending<android.content.pm.ApplicationInfo> { it.packageName==packageName }
                .thenBy { pm.getApplicationLabel(it).toString().lowercase() })
        val names=apps.map {
            if(it.packageName==packageName) "Dolphin Drive (TBT/미디어 알림 수신용) (${it.packageName})"
            else "${pm.getApplicationLabel(it)} (${it.packageName})"
        }
        if(apps.isEmpty()){box.addView(label("설치된 앱이 조회되지 않습니다"));return}
        val appPicker=Spinner(this).apply { adapter=ArrayAdapter(this@AppPermissionManagerActivity,android.R.layout.simple_spinner_dropdown_item,names) }
        box.addView(appPicker)
        val selected=linkedMapOf(
            SelectedAppPermissionManager.Action.BATTERY to "배터리 최적화 예외 · deviceidle whitelist",
            SelectedAppPermissionManager.Action.NOTIFICATION_POST to "알림 게시 권한 (앱에 선언한 경우)",
            SelectedAppPermissionManager.Action.NOTIFICATION_ACCESS to "알림 수신 접근 (리스너 서비스 · TBT용은 Dolphin Drive 선택)",
            SelectedAppPermissionManager.Action.ACCESSIBILITY to "접근성 (서비스 있는 앱)",
            SelectedAppPermissionManager.Action.USAGE_STATS to "사용기록 접근 · GET_USAGE_STATS",
            SelectedAppPermissionManager.Action.LOCATION_FOREGROUND to "선택 앱 위치 권한 · 대략/정밀 (앱 선언 필요)",
            SelectedAppPermissionManager.Action.LOCATION_BACKGROUND to "선택 앱 백그라운드 위치 · 항상 허용 (앱 선언 필요)",
            SelectedAppPermissionManager.Action.LOCATION_SERVICE to "차량 전체 위치 서비스 ON (전역 변경 · 별도 확인)")
        val checkboxes=selected.map { (action,title) ->
            action to CheckBox(this).apply { text=title;isChecked=false;box.addView(this) }
        }.toMap()
        val status=label("권한 항목을 선택한 뒤 조회하거나 적용하세요")
        box.addView(status)
        fun run(configure:Boolean){
            val idx=appPicker.selectedItemPosition
            if(idx !in apps.indices)return
            val pkg=apps[idx].packageName
            val actions=checkboxes.filterValues{it.isChecked}.keys
            Thread {
                val result=runCatching { SelectedAppPermissionManager.process(applicationContext,pkg,actions,configure) }
                    .getOrElse { SelectedAppPermissionManager.Result(listOf("권한 실행 오류 ${it.message}"),0,actions.size) }
                runOnUiThread { status.text="$pkg\n${result.lines.joinToString("\n")}" }
            }.start()
        }
        box.addView(Button(this).apply { text="선택한 앱의 권한 상태 조회";setOnClickListener{run(false)} })
        box.addView(Button(this).apply { text="선택한 권한을 ADB로 적용하고 확인";setOnClickListener{
            val idx=appPicker.selectedItemPosition
            if(idx !in apps.indices)return@setOnClickListener
            val global=checkboxes[SelectedAppPermissionManager.Action.LOCATION_SERVICE]?.isChecked==true
            fun confirmApp() = AlertDialog.Builder(this@AppPermissionManagerActivity)
                .setTitle("ADB 권한 적용")
                .setMessage("${names[idx]}에 선택한 권한을 적용합니다. TBT 알림은 Dolphin Drive 앱의 알림 수신 접근을 허용해야 합니다. 진행할까요?")
                .setPositiveButton("적용"){_,_->run(true)}.setNegativeButton("취소",null).show()
            if(global) AlertDialog.Builder(this@AppPermissionManagerActivity)
                .setTitle("차량 전체 위치 서비스 변경 확인")
                .setMessage("선택 앱만이 아니라 차량 전체 위치 서비스를 ON으로 바꿀 수 있습니다. 다른 앱과 개인정보 설정에 영향을 줄 수 있습니다. 동의하시겠습니까?")
                .setPositiveButton("전역 위치 ON 허용"){_,_->confirmApp()}
                .setNegativeButton("취소",null).show()
            else confirmApp()
        } })
        box.addView(Button(this).apply { text="Android 알림 접근 설정 열기";setOnClickListener{
            runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                .onFailure { status.text="차량 펌웨어에서 알림 접근 설정 화면을 제공하지 않습니다: ${it.message}" }
        } })
        box.addView(Button(this).apply { text="차량 위치 서비스 설정 열기";setOnClickListener{
            runCatching { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                .onFailure { status.text="차량 펌웨어에서 위치 설정 화면을 제공하지 않습니다: ${it.message}" }
        } })
    }
}
