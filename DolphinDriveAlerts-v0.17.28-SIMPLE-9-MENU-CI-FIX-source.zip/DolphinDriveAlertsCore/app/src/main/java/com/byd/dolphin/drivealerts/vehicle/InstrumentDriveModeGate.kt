package com.byd.dolphin.drivealerts.vehicle

/**
 * Korean Dolphin 2602 observational signature, derived from the 2026-10-18
 * 10:11:52--10:15:23 car log. These are notification/text display IDs,
 * NOT CAN IDs or generic BYD drive mode constants.
 *
 * In three consecutive cycles, instrument 0x26100008 reported
 * 363(ECO), 364(NORMAL), 365(SPORT). Setting 0x34500030 reported
 * 302(ECO), 311(NORMAL), 310(SPORT). Never announce from one channel alone.
 * Return a mode only when BOTH agree within MAX_AGE_MS. Ignore unrelated
 * instrument text (198, 0) and startup/stale/unverified values.
 */
internal class InstrumentDriveModeGate {
    enum class Mode { ECO, NORMAL, SPORT }
    data class Evidence(val mode: Mode, val instrumentRaw: Int, val settingRaw: Int,
                        val deltaMs: Long)
    private data class Observation(val mode: Mode, val raw: Int, val time: Long)
    private var instrument: Observation? = null
    private var setting: Observation? = null
    private var lastEmitted: Mode? = null
    private var lastMatchTime = -1L

    fun isConfirmed(): Boolean = lastMatchTime >= 0L
    fun reset() { instrument = null; setting = null; lastEmitted = null; lastMatchTime = -1L }

    fun acceptInstrument(raw: Int, now: Long): Evidence? {
        val mode = when (raw) {
            363 -> Mode.ECO
            364 -> Mode.NORMAL
            365 -> Mode.SPORT
            else -> null
        }
        instrument = mode?.let { Observation(it, raw, now) }
        return tryPair(now)
    }
    fun acceptSetting(raw: Int, now: Long): Evidence? {
        val mode = when (raw) {
            302 -> Mode.ECO
            311 -> Mode.NORMAL
            310 -> Mode.SPORT
            else -> null
        }
        setting = mode?.let { Observation(it, raw, now) }
        return tryPair(now)
    }
    private fun tryPair(now: Long): Evidence? {
        val a = instrument ?: return null
        val b = setting ?: return null
        if (a.mode != b.mode || now - a.time > MAX_AGE_MS || now - b.time > MAX_AGE_MS ||
            kotlin.math.abs(a.time-b.time) > MAX_AGE_MS) return null
        lastMatchTime = now
        if (lastEmitted == a.mode) return null
        lastEmitted = a.mode
        return Evidence(a.mode, a.raw, b.raw, kotlin.math.abs(a.time-b.time))
    }
    companion object { const val MAX_AGE_MS = 9_000L }
}
