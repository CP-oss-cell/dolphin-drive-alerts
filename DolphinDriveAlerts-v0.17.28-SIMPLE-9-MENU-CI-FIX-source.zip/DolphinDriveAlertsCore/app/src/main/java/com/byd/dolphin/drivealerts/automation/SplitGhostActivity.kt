package com.byd.dolphin.drivealerts.automation

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** v30 Assistant split primary stack placeholder, never a user-selected second pane. */
class SplitGhostActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val close = Runnable { if (!isFinishing) finish() }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) }
    override fun onResume() { super.onResume(); handler.removeCallbacks(close); handler.postDelayed(close, 4500L) }
    override fun onDestroy() { handler.removeCallbacks(close); super.onDestroy() }
}
