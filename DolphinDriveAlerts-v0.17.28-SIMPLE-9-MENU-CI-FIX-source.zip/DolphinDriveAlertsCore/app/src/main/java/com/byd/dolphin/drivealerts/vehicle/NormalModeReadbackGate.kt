package com.byd.dolphin.drivealerts.vehicle

/** Accept NORMAL only after three consecutive read-only SDK getter observations of raw 0.
 * Missing samples reset the sequence; ECO/SPORT values never imply NORMAL.
 * This does NOT claim that raw 0 is emitted by the user's current car.
 */
internal class NormalModeReadbackGate(private val required: Int = 3) {
    private var count = 0
    fun sample(raw: Int?): Boolean {
        count = if (raw == 0) (count + 1).coerceAtMost(required) else 0
        return count >= required
    }
    fun reset() { count = 0 }
}
