package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Always-on, append-only calibration logger.
 * Keeps the active session in app-private storage; DiagnosticsExporter copies a ZIP to Downloads.
 */
class RawSignalLogger(context: Context) {
    private val root = File(context.filesDir, "raw_signal_logs").apply { mkdirs() }
    private val sessionId = utcStamp()
    private val file = File(root, "raw-$sessionId.jsonl")
    private val writer = BufferedWriter(OutputStreamWriter(FileOutputStream(file, true), Charsets.UTF_8), 32 * 1024)
    private var lastFrame: RawVehicleFrame? = null
    private var lastEnergy: Map<String, Int> = emptyMap()
    private var lastProbe: Map<String, String> = emptyMap()
    private var lastAudioRoute: Map<String, String> = emptyMap()
    private val instrumentSoundTracker = InstrumentSoundCandidateTracker()
    private val repeatTimes = linkedMapOf<String, Pair<String?, Long>>()
    private var collapsedUnchanged = 0L
    private var lastSnapshotMs = 0L
    private var lineCount = 0

    init {
        append(JSONObject().apply {
            put("type", "session_start")
            put("ts", System.currentTimeMillis())
            put("session", sessionId)
            put("schema", 4)
        })
    }

    @Synchronized
    fun record(frame: RawVehicleFrame, energy: Map<String, Int>, probe: Map<String, String> = emptyMap()) {
        val now = System.currentTimeMillis()
        val prev = lastFrame
        if (prev == null || now - lastSnapshotMs >= 1000L) {
            append(frameJson("snapshot", frame, energy, probe))
            lastSnapshotMs = now
        } else {
            val changes = JSONObject()
            putChanged(changes, "speedKmH", prev.speedKmH, frame.speedKmH)
            putChanged(changes, "gearRaw", prev.gearRaw, frame.gearRaw)
            putChanged(changes, "epbRaw", prev.epbRaw, frame.epbRaw)
            putChanged(changes, "brakePedalRaw", prev.brakePedalRaw, frame.brakePedalRaw)
            putChanged(changes, "avhRaw", prev.avhRaw, frame.avhRaw)
            putChanged(changes, "bsdRaw", prev.bsdRaw, frame.bsdRaw)
            putChanged(changes, "laneOffsetRaw", prev.laneOffsetRaw, frame.laneOffsetRaw)
            putChanged(changes, "tjaRaw", prev.tjaRaw, frame.tjaRaw)
            putChanged(changes, "driveInterfaceRaw", prev.driveInterfaceRaw, frame.driveInterfaceRaw)
            putChanged(changes, "energyFeedbackRaw", prev.energyFeedbackRaw, frame.energyFeedbackRaw)
            putChanged(changes, "driveConfigRaw", prev.driveConfigRaw, frame.driveConfigRaw)
            putChanged(changes, "deviationRaw", prev.deviationRaw, frame.deviationRaw)
            putChanged(changes, "pcwAlarmRaw", prev.pcwAlarmRaw, frame.pcwAlarmRaw)
            putChanged(changes, "laneLineStateRaw", prev.laneLineStateRaw, frame.laneLineStateRaw)
            if (!prev.radarDistances.contentEqualsNullable(frame.radarDistances)) {
                changes.put("radarDistances", frame.radarDistances?.let { JSONArray(it.toList()) } ?: JSONObject.NULL)
            }
            for ((k, v) in energy) if (lastEnergy[k] != v) changes.put("energy.$k", v)
            for ((k, v) in probe) if (lastProbe[k] != v) changes.put("probe.$k", v)
            if (changes.length() > 0) append(JSONObject().apply {
                put("type", "change")
                put("ts", now)
                put("changes", changes)
            })
        }
        lastFrame = frame
        if (energy.isNotEmpty()) lastEnergy = energy.toMap()
        if (probe.isNotEmpty()) lastProbe = probe.toMap()
        if (++lineCount % 12 == 0) runCatching { writer.flush() }
    }

    /** Records Android audio route/device changes without changing any route. */
    @Synchronized
    fun recordAudioRoute(snapshot: Map<String, String>) {
        if (snapshot.isEmpty()) return
        val changed = JSONObject()
        val keys = (lastAudioRoute.keys + snapshot.keys).toSortedSet()
        for (k in keys) {
            val before = lastAudioRoute[k]
            val after = snapshot[k]
            if (before != after) changed.put(k, after ?: JSONObject.NULL)
        }
        if (lastAudioRoute.isEmpty() || changed.length() > 0) {
            append(JSONObject().apply {
                put("type", if (lastAudioRoute.isEmpty()) "audio_route_snapshot" else "audio_route_change")
                put("ts", System.currentTimeMillis())
                put("values", if (lastAudioRoute.isEmpty()) JSONObject(snapshot) else changed)
            })
            writer.flush()
        }
        lastAudioRoute = snapshot.toMap()
    }

    /** Passive event tap from BYD listeners. No setter/control operation is performed. */
    @Synchronized
    fun bydEvent(source: String, eventType: Int, value: String?, featureNames: List<String> = emptyList(), detail: String? = null) {
        val eventAtMs = System.currentTimeMillis()
        // Real-car 2026-10-10: instrument buzzer + static setting timestamp were 96%
        // of the stream. Collapse ONLY identical high-frequency repeats; raw transitions
        // remain intact and safety/BSD/ENERGY/ADAS IDs are NEVER suppressed.
        val isBuzzer = (source == "instrument" || source == "reference.instrument") && eventType == 0x12d0003c
        val isTimestamp = source == "reference.setting" && eventType == 0x99000198.toInt()
        if (isBuzzer || isTimestamp) {
            val normalized = if (isBuzzer) "instrument" else "reference.setting"
            val key = "$normalized:$eventType"
            val previous = repeatTimes[key]
            if (previous != null && previous.first == value && eventAtMs - previous.second < 1000L) {
                collapsedUnchanged++
                if (collapsedUnchanged % 250L == 0L) diagnostic("HIGH_RATE_UNCHANGED_COLLAPSED",
                    "count=$collapsedUnchanged;lastSource=$source;event=0x${eventType.toUInt().toString(16)}")
                return
            }
            repeatTimes[key] = value to eventAtMs
            if (repeatTimes.size > 40) repeatTimes.clear()
        }
        append(JSONObject().apply {
            put("type", "byd_event")
            put("ts", eventAtMs)
            put("source", source)
            put("eventType", eventType)
            put("eventHex", "0x${eventType.toUInt().toString(16)}")
            if (featureNames.isNotEmpty()) put("featureNames", JSONArray(featureNames))
            if (value != null) put("value", value) else put("value", JSONObject.NULL)
            if (!detail.isNullOrBlank()) put("detail", detail)
        })
        // Enrich existing raw instrument signals; never infer that an exterior speaker played.
        // The legacy byd_event line is retained unchanged for backward-compatible exports.
        if (source == "instrument" || source == "reference.instrument") {
            instrumentSoundTracker.observe(eventType, value, eventAtMs)?.let { edge ->
                append(JSONObject().apply {
                    put("type", "instrument_sound_candidate")
                    put("ts", eventAtMs)
                    put("phase", edge.phase)
                    put("frequencyRaw", edge.frequencyRaw ?: JSONObject.NULL)
                    put("soundTypeRaw", edge.typeRaw ?: JSONObject.NULL)
                    put("startedAtMs", edge.startedAtMs)
                    put("elapsedMs", edge.elapsedMs ?: JSONObject.NULL)
                    put("interpretation", "INSTRUMENT_SOUND_PAIR_EXTERNAL_AVAS_UNCONFIRMED")
                    put("externalSpeakerConfirmed", false)
                    put("readOnly", true)
                    put("source", source)
                    val frame = lastFrame
                    val ageMs = frame?.let { eventAtMs - it.timestampMs }
                    if (frame != null && ageMs != null && ageMs in 0..2500L) {
                        put("frameAgeMs", ageMs)
                        put("speedKmH", frame.speedKmH ?: JSONObject.NULL)
                        put("gearRaw", frame.gearRaw ?: JSONObject.NULL)
                    } else {
                        put("frameAgeMs", JSONObject.NULL)
                    }
                })
            }
        }
        writer.flush()
    }

    @Synchronized
    fun diagnostic(message: String, detail: String? = null) {
        append(JSONObject().apply {
            put("type", "diagnostic")
            put("ts", System.currentTimeMillis())
            put("message", message)
            if (!detail.isNullOrBlank()) put("detail", detail)
        })
    }

    @Synchronized
    fun marker(label: String, detail: String? = null) {
        append(JSONObject().apply {
            put("type", "marker")
            put("ts", System.currentTimeMillis())
            put("label", label)
            if (!detail.isNullOrBlank()) put("detail", detail)
        })
        writer.flush()
    }

    @Synchronized
    fun flush() = runCatching { writer.flush() }.getOrDefault(Unit)

    @Synchronized
    fun close() {
        runCatching {
            append(JSONObject().apply { put("type", "session_end"); put("ts", System.currentTimeMillis()) })
            writer.flush(); writer.close()
        }
    }

    fun directory(): File = root
    fun activeFile(): File = file

    private fun frameJson(type: String, f: RawVehicleFrame, energy: Map<String, Int>, probe: Map<String, String>) = JSONObject().apply {
        put("type", type); put("ts", f.timestampMs)
        putNullable("speedKmH", f.speedKmH); putNullable("gearRaw", f.gearRaw); putNullable("epbRaw", f.epbRaw)
        putNullable("brakePedalRaw", f.brakePedalRaw); putNullable("avhRaw", f.avhRaw); putNullable("bsdRaw", f.bsdRaw); putNullable("laneOffsetRaw", f.laneOffsetRaw)
        putNullable("tjaRaw", f.tjaRaw); putNullable("driveInterfaceRaw", f.driveInterfaceRaw)
        putNullable("energyFeedbackRaw", f.energyFeedbackRaw); putNullable("driveConfigRaw", f.driveConfigRaw)
        putNullable("deviationRaw", f.deviationRaw); putNullable("pcwAlarmRaw", f.pcwAlarmRaw)
        putNullable("laneLineStateRaw", f.laneLineStateRaw)
        put("radarDistances", f.radarDistances?.let { JSONArray(it.toList()) } ?: JSONObject.NULL)
        put("energy", JSONObject(energy))
        put("probe", JSONObject(probe))
    }

    private fun append(obj: JSONObject) {
        try { writer.write(obj.toString()); writer.newLine() }
        catch (t: Throwable) { CoreLog.w("RAWLOG", "append failed: ${t.message}") }
    }

    private fun putChanged(o: JSONObject, key: String, a: Any?, b: Any?) { if (a != b) o.put(key, b ?: JSONObject.NULL) }
    private fun JSONObject.putNullable(key: String, value: Any?) { put(key, value ?: JSONObject.NULL) }
    private fun IntArray?.contentEqualsNullable(other: IntArray?): Boolean = when {
        this == null && other == null -> true
        this == null || other == null -> false
        else -> this.contentEquals(other)
    }

    companion object {
        private fun utcStamp(): String = SimpleDateFormat("yyyyMMdd-HHmmss-SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
    }
}
