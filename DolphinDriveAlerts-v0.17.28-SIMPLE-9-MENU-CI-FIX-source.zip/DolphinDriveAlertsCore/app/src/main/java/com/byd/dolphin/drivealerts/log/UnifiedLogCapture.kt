package com.byd.dolphin.drivealerts.log

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream

/** Unified, user-controlled capture. The background safety monitor never stops. */
object UnifiedLogCapture {
    private const val PREF = "unified_log_capture"
    private const val STATUS = "status"
    private const val SESSION = "session"
    private const val START = "start"
    private const val END = "end"
    const val IDLE = "IDLE"
    const val RECORDING = "RECORDING"
    const val SAVING = "SAVING"
    const val FAILED = "FAILED"

    data class State(val status: String, val id: String, val startMs: Long, val endMs: Long)

    @Synchronized fun state(context: Context): State {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return State(prefs.getString(STATUS, IDLE) ?: IDLE,
            prefs.getString(SESSION, "") ?: "", prefs.getLong(START, 0L), prefs.getLong(END, 0L))
    }

    fun begin(context: Context, logger: RawSignalLogger?, diagnostics: SystemDiagnosticsCollector?): String {
        val current = state(context)
        if (current.status == RECORDING || current.status == SAVING) return "이미 수집 중입니다."
        if (current.status == FAILED) return "이전 로그 저장 실패: 먼저 '수집 종료'를 눌러 재저장하세요."
        if (logger == null) return "차량 로그 수집기를 사용할 수 없습니다."
        val id = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + "_" + UUID.randomUUID().toString().take(8)
        val start = System.currentTimeMillis()
        val saved = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS, RECORDING).putString(SESSION, id).putLong(START, start).putLong(END, 0L).commit()
        if (!saved) return "수집 상태 저장 실패"
        runCatching { CaptureContinuity.reset(context, id, start) }
            .onFailure { logger.diagnostic("CAPTURE_JOURNAL_START_FAILED", it.javaClass.simpleName) }
        logger.marker("UNIFIED_CAPTURE_START", "id=$id")
        logger.diagnostic("UNIFIED_CAPTURE_ACTIVE", "id=$id start=$start")
        diagnostics?.captureQuick("UNIFIED_START_$id")
        return "로그 수집 시작: $id"
    }

    /** A crashed process may have left the preference in SAVING while no exporter exists. */
    fun recoverInterruptedSave(context: Context) {
        if (state(context).status == SAVING) {
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(STATUS, FAILED).commit()
        }
    }

    /** No new session can start until an interrupted/failed save is retried. */
    fun finish(context: Context, logger: RawSignalLogger?, diagnostics: SystemDiagnosticsCollector?): Result<String> {
        val state = state(context)
        if (state.status == IDLE || state.id.isBlank() || state.startMs <= 0L)
            return Result.failure(IllegalStateException("수집 시작 후 종료를 눌러주세요."))
        if (state.status == SAVING)
            return Result.failure(IllegalStateException("이미 로그 저장 중입니다."))
        if (logger == null) return Result.failure(IllegalStateException("차량 로그 수집기를 사용할 수 없습니다."))

        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val end = if (state.endMs > state.startMs) state.endMs else {
            logger.marker("UNIFIED_CAPTURE_END", "id=${state.id}")
            logger.flush()
            System.currentTimeMillis()
        }
        if (!prefs.edit().putString(STATUS, SAVING).putLong(END, end).commit())
            return Result.failure(IllegalStateException("저장 상태 기록 실패"))
        // ADB may be unavailable: capture failures remain explicit in per-command diagnostic files.
        val captured = diagnostics?.captureDeepAndWait("UNIFIED_STOP_${state.id}") ?: false
        val exported = export(context, logger, diagnostics, state.copy(status = SAVING, endMs = end), captured)
        if (exported.isSuccess) {
            if (prefs.edit().putString(STATUS, IDLE).remove(SESSION).remove(START).remove(END).commit()) {
                runCatching { CaptureContinuity.clear(context, state.id) }
            }
        } else {
            prefs.edit().putString(STATUS, FAILED).commit()
            CoreLog.w("UNIFIED_LOG", "save failed: ${exported.exceptionOrNull()?.message}")
        }
        return exported
    }

    private fun verifyCompleteZip(file: File) {
        check(file.isFile && file.length() > 128L) { "임시 ZIP 크기가 너무 작습니다" }
        val found = mutableSetOf<String>()
        // ZipInputStream checks each entry's deflate and CRC when fully read.
        ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zip ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val entry = zip.nextEntry ?: break
                check(found.add(entry.name)) { "ZIP 중복 항목: ${entry.name}" }
                while (zip.read(buf) != -1) { /* drain for CRC */ }
                zip.closeEntry()
            }
        }
        check(found.containsAll(listOf("session.json", "lifecycle/capture_continuity.json",
            "logs/vehicle_events.jsonl"))) { "필수 로그 항목 누락: $found" }
        // EOCD check independently: truncated ZIP can sometimes yield partial entries.
        java.util.zip.ZipFile(file).use { check(it.size() >= 3) { "ZIP 중앙 디렉터리 불완전" } }
    }

    private fun export(context: Context, logger: RawSignalLogger, diagnostics: SystemDiagnosticsCollector?, state: State, captured: Boolean): Result<String> = runCatching {
        val filename = "DolphinDriveLogs_${state.id}.zip"
        // Never publish a half-written ZIP as a finished Download. Keep staged bytes for
        // interrupted export diagnostics until a successful copy has completed.
        val staged = File(context.cacheDir, "DolphinDriveLogs_${state.id}.staged.zip")
        try {
            FileOutputStream(staged).use { writeZip(context, logger, diagnostics, state, captured, it) }
            verifyCompleteZip(staged)
            val location = if (Build.VERSION.SDK_INT >= 29) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Download 파일 생성 실패(MediaStore)")
                try {
                    val stream = resolver.openOutputStream(uri, "w") ?: error("Download 쓰기 실패")
                    stream.use { dst -> staged.inputStream().use { it.copyTo(dst, 64 * 1024) } }
                    val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    check(resolver.update(uri, done, null, null) > 0) { "Download 저장 완료 표시 실패" }
                } catch (e: Throwable) {
                    resolver.delete(uri, null, null)
                    throw e
                }
                "Download/$filename"
            } else {
                @Suppress("DEPRECATION")
                val folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
                val output = File(folder, filename)
                staged.copyTo(output, overwrite = true)
                verifyCompleteZip(output)
                output.absolutePath
            }
            staged.delete()
            location
        } catch (t: Throwable) {
            // Leave validated or partially written staged data available to diagnose or recover;
            // a failed capture is never reported as successful.
            CoreLog.w("UNIFIED_LOG", "export staging failure session=${state.id}: ${t.javaClass.simpleName}")
            throw t
        }
    }

    private fun diagnosticCommandStatus(diagnostics: SystemDiagnosticsCollector?, sessionId: String): Pair<Int, Int> {
        var ok = 0
        var failed = 0
        diagnostics?.directory()?.listFiles()?.filter { directory ->
            directory.isDirectory && (directory.name.endsWith("UNIFIED_START_$sessionId") ||
                directory.name.endsWith("UNIFIED_STOP_$sessionId"))
        }?.forEach { directory ->
            directory.listFiles()?.filter { it.isFile && it.extension == "txt" }?.forEach { file ->
                val header = runCatching { file.bufferedReader().use { reader ->
                    val first = reader.readLine().orEmpty()
                    val second = reader.readLine().orEmpty()
                    first to second
                } }.getOrNull()
                header?.let { (first, second) ->
                    if (first.startsWith("# command:")) {
                        if (second.contains("success=true")) ok++
                        else if (second.contains("success=false")) failed++
                    }
                }
            }
        }
        return ok to failed
    }

    private fun writeZip(context: Context, logger: RawSignalLogger, diagnostics: SystemDiagnosticsCollector?, state: State, captured: Boolean, stream: OutputStream) {
        logger.flush()
        ZipOutputStream(BufferedOutputStream(stream)).use { zip ->
            val metadata = JSONObject().apply {
                put("type", "unified_diagnostic_capture")
                put("sessionId", state.id)
                put("startMs", state.startMs)
                put("endMs", state.endMs)
                put("manufacturer", Build.MANUFACTURER)
                put("model", Build.MODEL)
                put("sdk", Build.VERSION.SDK_INT)
                val pkg = runCatching { context.packageManager.getPackageInfo(context.packageName, 0) }.getOrNull()
                put("appVersionName", pkg?.versionName ?: "UNKNOWN")
                @Suppress("DEPRECATION")
                put("appVersionCode", pkg?.versionCode ?: -1)
                put("deepSnapshotAttemptSucceeded", captured)
                // Task completion is not equivalent to all ADB diagnostics succeeding.
                // Derive the command success/failure count from the actual saved snapshots.
                val commandStatus = diagnosticCommandStatus(diagnostics, state.id)
                put("diagnosticShellCommandSuccessCount", commandStatus.first)
                put("diagnosticShellCommandFailureCount", commandStatus.second)
                put("diagnosticShellUsable", commandStatus.first > 0)
                put("note", "Vehicle JSONL is filtered to the selected time window. Ignition gaps and listener reconnection events are in lifecycle/capture_continuity.json; absence of callbacks is not proof of recording. Shell logcat buffers may include older records.")
            }.toString(2)
            zip.putNextEntry(ZipEntry("session.json"))
            zip.write(metadata.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("lifecycle/capture_continuity.json"))
            val continuityJson = runCatching { CaptureContinuity.snapshot(context, state.id) }
                .getOrElse { JSONObject().put("sessionId", state.id).put("journalError", it.javaClass.simpleName) }
            zip.write(continuityJson.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("logs/vehicle_events.jsonl"))
            logger.directory().listFiles()?.asSequence()?.filter { it.isFile && it.extension == "jsonl" }
                ?.sortedBy { it.name }?.forEach { file ->
                    file.bufferedReader(Charsets.UTF_8).useLines { lines ->
                        lines.forEach { line ->
                            val timestamp = runCatching { JSONObject(line).optLong("ts", -1L) }.getOrDefault(-1L)
                            if (timestamp in state.startMs..state.endMs) {
                                zip.write(line.toByteArray(Charsets.UTF_8))
                                zip.write('\n'.code)
                            }
                        }
                    }
                }
            zip.closeEntry()

            val root = diagnostics?.directory()
            root?.listFiles()?.asSequence()?.filter { file ->
                file.isDirectory && (file.name.endsWith("UNIFIED_START_${state.id}") ||
                    file.name.endsWith("UNIFIED_STOP_${state.id}"))
            }?.sortedBy { it.name }?.forEach { folder ->
                folder.walkTopDown().filter { it.isFile }.forEach { file ->
                    val rel = file.relativeTo(folder).invariantSeparatorsPath
                    zip.putNextEntry(ZipEntry("diagnostics/${folder.name}/$rel"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }
}
