package com.byd.dolphin.drivealerts.dpi

/** Non-privileged command construction; only installed package/service ids are accepted. */
object AppPermissionRules {
    private val PACKAGE = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    private val COMPONENT = Regex("[A-Za-z0-9_.$/]+")
    fun packageAllowed(pkg: String): Boolean = PACKAGE.matches(pkg)
    fun serviceAllowed(component: String): Boolean = COMPONENT.matches(component) && component.contains('/')
    fun addAccessibilityService(current: String, service: String): String {
        require(serviceAllowed(service))
        val existing = current.trim().takeIf { it != "null" }.orEmpty()
            .split(':').filter { it.isNotBlank() }.toMutableList()
        if (service !in existing) existing.add(service)
        return existing.joinToString(":")
    }
    fun batteryCommand(pkg: String): String {
        require(packageAllowed(pkg)); return "dumpsys deviceidle whitelist +$pkg"
    }
    fun grantNotificationCommand(pkg: String): String {
        require(packageAllowed(pkg)); return "pm grant $pkg android.permission.POST_NOTIFICATIONS"
    }
    fun usageStatsCommand(pkg: String): String {
        require(packageAllowed(pkg)); return "appops set $pkg GET_USAGE_STATS allow"
    }
    fun notificationListenerCommand(component: String): String {
        require(serviceAllowed(component)); return "cmd notification allow_listener $component"
    }
    /** App runtime location grants; never accepts arbitrary permission identifiers. */
    fun locationGrantCommand(pkg: String, permission: String): String {
        require(packageAllowed(pkg))
        require(permission in setOf(
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION"))
        return "pm grant $pkg $permission"
    }
    fun hasGrantedPermission(dumpsys: String, permission: String): Boolean = dumpsys.lineSequence().any { line ->
        line.trim().startsWith("$permission:") && "granted=true" in line
    }
    fun locationEnabledReadback(raw: String): Boolean? = when (raw.trim().lowercase()) {
        "true", "location enabled: true", "1" -> true
        "false", "location enabled: false", "0" -> false
        else -> null
    }
    fun locationEnableCommand(): String = "cmd location set-location-enabled true"
    fun locationReadCommand(): String = "cmd location is-location-enabled"
    fun accessibilityCommand(merged: String): String {
        require(merged.split(':').all { serviceAllowed(it) })
        return "settings put secure enabled_accessibility_services $merged"
    }
}
