package com.byd.dolphin.drivealerts.audio

/** Pure Kotlin classifier. Never treats a logged audio route as physical-speaker proof. */
object NavRouteEvidence {
    fun classify(permission: Boolean, adbReady: Boolean, ownTonePlayed: Boolean): String = when {
        !adbReady -> "CAPTURE_UNAVAILABLE_ADB_REQUIRED"
        !permission -> "CROSS_UID_ROUTING_BLOCKED_MODIFY_AUDIO_ROUTING_NOT_GRANTED"
        !ownTonePlayed -> "OWN_TONE_NOT_VERIFIED"
        else -> "CROSS_UID_ROUTING_NOT_IMPLEMENTED_EVEN_WITH_PERMISSION"
    }

    // Whitelist a few comparison terms; never infer an OEM UID-to-speaker relationship from lines alone.
    fun relevantLines(text: String, limit: Int = 100): List<String> = text.lineSequence()
        .filter { s ->
            val lower = s.lowercase()
            listOf("uid", "session", "output", "stream", "usage", "bus", "device", "mix", "route", "nav", "strategy", "track", "port").any { lower.contains(it) }
        }.take(limit).map { it.take(320) }.toList()
}
