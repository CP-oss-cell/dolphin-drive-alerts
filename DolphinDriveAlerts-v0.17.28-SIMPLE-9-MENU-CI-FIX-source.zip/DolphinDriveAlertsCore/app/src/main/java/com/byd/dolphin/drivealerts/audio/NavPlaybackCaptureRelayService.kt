package com.byd.dolphin.drivealerts.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File
import kotlin.concurrent.thread

/**
 * Explicit opt-in Android 10 playback-capture EXPERIMENT, not an OEM UID audio-route API.
 * Captures only the user-selected navigation UID, only if that source allows
 * USAGE_MEDIA / GAME / UNKNOWN capture; never captures VOICE or NAV_GUIDANCE.
 * Replays via Dolphin's own historical stream-14 output. No raw audio is saved.
 * User can stop from the lab at any time; does not modify the vehicle mixer.
 */
class NavPlaybackCaptureRelayService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { appendStatus("USER_STOP"); stopSelf(); return START_NOT_STICKY }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (running) return START_NOT_STICKY
        val uid = intent.getIntExtra(EXTRA_UID, -1)
        val pkg = intent.getStringExtra(EXTRA_PACKAGE).orEmpty()
        val allowed = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.navigationPackages
        val resolved = runCatching { packageManager.getApplicationInfo(pkg, 0).uid }.getOrNull()
        if (uid < 0 || pkg !in allowed || resolved != uid) {
            appendStatus("REJECT_INVALID_NAVIGATION_UID pkg=$pkg requested=$uid installed=$resolved")
            stopSelf(); return START_NOT_STICKY
        }
        @Suppress("DEPRECATION")
        val token = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (token == null) { appendStatus("REJECT_NO_USER_PROJECTION_CONSENT"); stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "내비 음성 릴레이 시험", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("${pkg} 안내음 운전석 시험 중")
            .setContentText("사용자 승인된 오디오 캡처 · 시험 종료는 앱에서")
            .setOngoing(true).build()
        startForeground(ONGOING_NOTIFICATION, notification)
        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val mp = runCatching {
            (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                .getMediaProjection(code, token)
        }.getOrElse { appendStatus("PROJECTION_DENIED ${it.javaClass.simpleName}"); stopSelf(); return START_NOT_STICKY }
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { appendStatus("PROJECTION_STOPPED"); stopSelf() }
        }, Handler(Looper.getMainLooper()))
        running = true
        appendStatus("START uid=$uid pkg=$pkg output=STREAM_NAVI_14 consent=GRANTED")
        worker = thread(name="nav-playback-relay",isDaemon=true) { relay(mp, pkg, uid) }
        return START_NOT_STICKY
    }

    private fun relay(mp: MediaProjection, pkg: String, uid: Int) {
        try {
            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUid(uid)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val inputFormat = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val outputFormat = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            val size = 19200
            val input = AudioRecord.Builder().setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(inputFormat).setBufferSizeInBytes(size).build()
            if (input.state != AudioRecord.STATE_INITIALIZED) error("AudioRecord not initialized")
            recorder=input
            val output = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setLegacyStreamType(14).build())
                .setAudioFormat(outputFormat).setBufferSizeInBytes(size)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            if (output.state != AudioTrack.STATE_INITIALIZED) error("AudioTrack stream14 not initialized")
            player=output
            input.startRecording();output.play()
            val pcm=ByteArray(3840)
            var total:Long=0;var nonzero:Long=0;var lastReport=System.currentTimeMillis()
            while(running) {
                val n = input.read(pcm,0,pcm.size,AudioRecord.READ_BLOCKING)
                if(n<=0) { if(n<0) appendStatus("READ_ERROR $n"); break }
                total+=n
                var active=false
                for(i in 0 until n) { if(pcm[i].toInt()!=0){active=true;break} }
                if(active) { nonzero+=n; val written=output.write(pcm,0,n,AudioTrack.WRITE_BLOCKING)
                    if(written<0){appendStatus("WRITE_ERROR $written");break}
                }
                if(System.currentTimeMillis()-lastReport>=5_000L){
                    appendStatus("STATUS uid=$uid inputBytes=$total nonzeroFramesApproxBytes=$nonzero output=STREAM14 " +
                        "note=nonzero does NOT prove driver-only audibility; source app must allow capture")
                    lastReport=System.currentTimeMillis()
                }
            }
            appendStatus("END uid=$uid inputBytes=$total nonzeroApproxBytes=$nonzero")
        } catch (e:Exception) {
            appendStatus("RELAY_FAILED ${e.javaClass.simpleName}: ${e.message?.take(200)}")
        } finally {
            running=false
            stopSelf()
        }
    }

    override fun onDestroy() {
        running=false
        runCatching { recorder?.stop() }; runCatching { recorder?.release() };recorder=null
        runCatching { player?.stop() }; runCatching { player?.release() };player=null
        runCatching { projection?.stop() };projection=null
        super.onDestroy()
    }
    private fun appendStatus(info:String) = runCatching {
        File(filesDir,"nav_audio_lab/uid_relay_status.log").apply {parentFile?.mkdirs()}
            .appendText("${System.currentTimeMillis()} $info\n")
    }
    companion object {
        const val ACTION_START="com.byd.dolphin.drivealerts.NAV_RELAY_START"
        const val ACTION_STOP="com.byd.dolphin.drivealerts.NAV_RELAY_STOP"
        const val EXTRA_UID="nav_relay_uid"
        const val EXTRA_PACKAGE="nav_relay_pkg"
        const val EXTRA_RESULT_CODE="nav_relay_projection_code"
        const val EXTRA_RESULT_DATA="nav_relay_projection_data"
        private const val CHANNEL="nav-audio-relay-consent"
        private const val ONGOING_NOTIFICATION=18726
    }
}
