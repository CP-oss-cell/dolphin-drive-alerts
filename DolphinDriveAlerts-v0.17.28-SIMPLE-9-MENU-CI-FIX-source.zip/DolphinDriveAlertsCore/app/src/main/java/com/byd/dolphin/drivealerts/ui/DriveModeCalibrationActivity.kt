package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.byd.dolphin.drivealerts.vehicle.DriveModeSignature

/** Parked-car, read-only 3-mode signal calibration; never changes vehicle settings. */
class DriveModeCalibrationActivity: Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val column=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(25,20,25,20) }
        status=TextView(this).apply { textSize=15f }
        column.addView(TextView(this).apply { text="주행모드 3상태 원본 신호 확인"; textSize=23f })
        column.addView(TextView(this).apply { text="주차(P) 상태에서 순정 조작부로 해당 모드를 선택하고 아래 버튼으로 값을 기록하세요. 차량 상태 변경은 이 앱이 하지 않습니다. 세 상태 값이 같으면 NORMAL을 임의로 발화하지 않습니다.";textSize=16f })
        listOf("ECO", "NORMAL", "SPORT").forEach { mode ->
            column.addView(Button(this).apply {
                text="현재 차량이 $mode 일 때 기록"
                setOnClickListener {
                    isEnabled=false
                    Thread {
                        val result=DriveModeSignature.record(applicationContext,mode)
                        runOnUiThread { status.text=result; isEnabled=true }
                    }.start()
                }
            })
        }
        column.addView(Button(this).apply { text="현재 읽기값/판별 상태 확인";setOnClickListener {
            Thread { val values=DriveModeSignature.snapshot(applicationContext)
                val explanation="현재 조회: $values\n${DriveModeSignature.profileStatus(applicationContext)}\n인식: ${DriveModeSignature.identify(applicationContext,values) ?: "불명"}"
                runOnUiThread { status.text=explanation }
            }.start()
        } })
        column.addView(Button(this).apply {text="기존 3상태 기록 초기화";setOnClickListener {
            DriveModeSignature.clear(this@DriveModeCalibrationActivity)
            status.text="초기화 완료. 기존 ECO/SPORT 자동 안내는 유지됩니다."
        }})
        column.addView(status)
        setContentView(ScrollView(this).apply {addView(column)})
        status.text=DriveModeSignature.profileStatus(this)
    }
}
