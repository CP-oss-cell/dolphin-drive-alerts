package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** User-requested ADB permissions for an explicitly selected installed app. */
object SelectedAppPermissionManager {
    enum class Action { BATTERY, NOTIFICATION_POST, NOTIFICATION_ACCESS, ACCESSIBILITY,
        USAGE_STATS, LOCATION_FOREGROUND, LOCATION_BACKGROUND, LOCATION_SERVICE }
    data class Result(val lines: List<String>, val okCount: Int, val attempted: Int)

    fun process(context: Context, packageName: String, actions: Set<Action>, configure: Boolean): Result {
        val app = context.applicationContext
        val lines=mutableListOf<String>()
        if (!AppPermissionRules.packageAllowed(packageName)) return Result(listOf("잘못된 앱 패키지"),0,0)
        if (runCatching { app.packageManager.getApplicationInfo(packageName,0) }.isFailure)
            return Result(listOf("설치되지 않은 앱: $packageName"),0,0)
        if (actions.isEmpty()) return Result(listOf("권한 항목을 선택하세요"),0,0)
        val connection=AuthorizedAdbRuntime.awaitReady(app,maxWaitMs=if(configure) 8000L else 3000L)
        if (!connection.result.success) return Result(listOf("ADB 승인 연결 실패: ${connection.state} ${connection.result.message}"),0,actions.size)
        fun exec(cmd:String) = NativeAdbClient.executeShell(app,cmd,timeoutMs=6500L)
        var ok=0
        fun check(action: Action, write: String?, read: String, verify:(String)->Boolean, suffix:String="") {
            if (configure && write!=null) {
                val r=exec(write)
                if (!r.success) { lines += "${action.name} 명령 실패: ${r.message}"; return }
            }
            val r=exec(read)
            val pass=r.success && verify(r.output)
            if(pass)ok++
            lines += "${action.name}: ${if(pass) "readback 확인" else "미확인/거부"} $suffix ${r.output.trim().replace('\n',' ').take(100)}"
        }
        val pm=app.packageManager
        val requested = runCatching { pm.getPackageInfo(packageName,PackageManager.GET_PERMISSIONS)
            .requestedPermissions?.toSet().orEmpty() }.getOrDefault(emptySet())
        fun services(actionName:String):List<String> = pm.queryIntentServices(Intent(actionName).setPackage(packageName),0)
            .mapNotNull { it.serviceInfo?.let { info -> ComponentName(info.packageName,info.name).flattenToString() } }
            .filter { AppPermissionRules.serviceAllowed(it) }.distinct().sorted()
        for (action in Action.entries) {
            if(action !in actions)continue
            when(action) {
                Action.BATTERY -> check(action,AppPermissionRules.batteryCommand(packageName),"dumpsys deviceidle whitelist",{ raw -> raw.lineSequence().any { it.contains(packageName) } })
                Action.NOTIFICATION_POST -> {
                    if("android.permission.POST_NOTIFICATIONS" !in requested) {
                        lines += "NOTIFICATION_POST: 앱에 POST_NOTIFICATIONS 선언 없음 (적용 불가)"
                    } else check(action,AppPermissionRules.grantNotificationCommand(packageName),"dumpsys package $packageName",{ raw ->
                        raw.lineSequence().any { it.contains("android.permission.POST_NOTIFICATIONS:") && it.contains("granted=true") }
                    })
                }
                Action.NOTIFICATION_ACCESS -> {
                    val list=services("android.service.notification.NotificationListenerService")
                    if(list.isEmpty()) lines += "NOTIFICATION_ACCESS: 앱에 NotificationListenerService 없음"
                    else {
                        val component=list.first()
                        check(action,AppPermissionRules.notificationListenerCommand(component),"settings get secure enabled_notification_listeners",{ it.split(':').map(String::trim).contains(component) },"서비스=$component")
                        if(list.size>1) lines += "알림 서비스 ${list.size}개 중 첫 번째만 적용: ${list.joinToString()}"
                    }
                }
                Action.ACCESSIBILITY -> {
                    val list=services("android.accessibilityservice.AccessibilityService")
                    if(list.isEmpty()) lines += "ACCESSIBILITY: 앱에 AccessibilityService 없음"
                    else {
                        val component=list.first()
                        val current=exec("settings get secure enabled_accessibility_services")
                        if(!current.success) {lines += "ACCESSIBILITY: 기존 서비스 목록 조회 실패, 변경하지 않음";continue}
                        val merged=AppPermissionRules.addAccessibilityService(current.output,component)
                        if(configure) {
                            val r=exec(AppPermissionRules.accessibilityCommand(merged))
                            if(r.success)exec("settings put secure accessibility_enabled 1")
                            else {lines += "ACCESSIBILITY: 변경 거부 ${r.message}";continue}
                        }
                        check(action,null,"settings get secure enabled_accessibility_services",{ it.split(':').map(String::trim).contains(component) },"서비스=$component")
                        if(list.size>1) lines += "접근성 서비스 ${list.size}개 중 첫 번째만 적용: ${list.joinToString()}"
                    }
                }
                Action.USAGE_STATS -> check(action,AppPermissionRules.usageStatsCommand(packageName),"appops get $packageName GET_USAGE_STATS",{ it.contains("allow",true) && !it.contains("ignore",true) })
                Action.LOCATION_FOREGROUND -> {
                    val permissions = listOf("android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION")
                        .filter { it in requested }
                    if (permissions.isEmpty()) {
                        lines += "LOCATION_FOREGROUND: 앱에 위치 권한 선언 없음 (적용 불가)"
                    } else {
                        for (permission in permissions) if (configure) {
                            val r=exec(AppPermissionRules.locationGrantCommand(packageName,permission))
                            if (!r.success) lines += "위치 권한 부여 실패 ${permission.substringAfterLast('.')}: ${r.message}"
                        }
                        val readback=exec("dumpsys package $packageName")
                        val granted=readback.success && permissions.all { AppPermissionRules.hasGrantedPermission(readback.output,it) }
                        if (granted) ok++
                        lines += "LOCATION_FOREGROUND: ${if(granted) "앱 위치 권한 확인" else "미허용/확인 불가"} (${permissions.joinToString { it.substringAfterLast('.') }})"
                    }
                }
                Action.LOCATION_BACKGROUND -> {
                    val permission="android.permission.ACCESS_BACKGROUND_LOCATION"
                    if (Build.VERSION.SDK_INT < 29) {
                        lines += "LOCATION_BACKGROUND: Android 10 미만에서는 별도 백그라운드 권한 없음"
                    } else if (permission !in requested) {
                        lines += "LOCATION_BACKGROUND: 앱에 ACCESS_BACKGROUND_LOCATION 선언 없음 (적용 불가)"
                    } else {
                        val before=exec("dumpsys package $packageName")
                        val foreground=before.success && listOf("android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION")
                            .any { AppPermissionRules.hasGrantedPermission(before.output,it) }
                        if (configure && !foreground) {
                            lines += "LOCATION_BACKGROUND: 먼저 해당 앱의 '위치 권한'을 허용하세요"
                        } else {
                            if (configure) {
                                val r=exec(AppPermissionRules.locationGrantCommand(packageName,permission))
                                if (!r.success) lines += "LOCATION_BACKGROUND 부여 실패: ${r.message}"
                            }
                            val readback=exec("dumpsys package $packageName")
                            val granted=readback.success && AppPermissionRules.hasGrantedPermission(readback.output,permission)
                            if(granted)ok++
                            lines += "LOCATION_BACKGROUND: ${if(granted) "백그라운드 위치 권한 확인" else "미허용/확인 불가"}"
                        }
                    }
                }
                Action.LOCATION_SERVICE -> {
                    // Device-wide setting: never run unless explicitly selected and confirmed in UI.
                    val before=exec(AppPermissionRules.locationReadCommand())
                    val beforeOn=if(before.success) AppPermissionRules.locationEnabledReadback(before.output) else null
                    if(configure && beforeOn != true) {
                        val response=exec(AppPermissionRules.locationEnableCommand())
                        if(!response.success) lines += "LOCATION_SERVICE: 차량 위치 ON 거부/미지원 ${response.message}; 설정 화면에서 확인하세요"
                    }
                    val readback=exec(AppPermissionRules.locationReadCommand())
                    val result=if(readback.success) AppPermissionRules.locationEnabledReadback(readback.output) else null
                    if(result==true) ok++
                    lines += "LOCATION_SERVICE: ${when(result) {true->"차량 전체 위치 서비스 ON 확인";false->"차량 전체 위치 서비스 OFF";null->"위치 상태 확인 불가"}} (앱별 권한과 별도)"
                }

            }
        }
        lines += "확인 $ok/${actions.size}개 · Shell 권한 확인은 실제 앱 팝업 제거/동작 성공의 보장이 아닙니다"
        return Result(lines,ok,actions.size)
    }
}
