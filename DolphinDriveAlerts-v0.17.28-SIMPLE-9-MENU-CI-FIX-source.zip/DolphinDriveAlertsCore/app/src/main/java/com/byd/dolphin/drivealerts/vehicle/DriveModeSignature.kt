package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import org.json.JSONObject

/** Read-only three-state calibration; a guessed numeric zero is NOT a third vehicle state. */
internal object DriveModeSignature {
    private const val PREF = "mode_three_state_calibration_v1"
    private val classes = listOf(
        "energy" to "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
        "setting" to "android.hardware.bydauto.setting.BYDAutoSettingDevice",
        "instrument" to "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice")
    private val methods = mapOf(
        "energy" to listOf("getOperationMode", "getOperationModeState", "getEnergyOperationMode2nd", "getEnergyOperationModeEv"),
        "setting" to listOf("getDriveConfig", "getDrivingMode", "getTargetDrivingMode"),
        "instrument" to listOf("getCurrentDriveInterFace", "getDrivingMode", "getCurrentDriveMode"))

    fun snapshot(context: Context): Map<String, Int> {
        val found = sortedMapOf<String, Int>()
        val wrapped = BydPermissionContext.wrap(context.applicationContext)
        for ((tag, path) in classes) {
            val klass = runCatching { Class.forName(path) }.getOrNull() ?: continue
            val instance = runCatching {
                klass.methods.firstOrNull { it.name == "getInstance" && it.parameterCount == 1 &&
                    it.parameterTypes[0].isAssignableFrom(Context::class.java) }?.invoke(null, wrapped)
                    ?: klass.methods.firstOrNull { it.name == "getInstance" && it.parameterCount == 0 }?.invoke(null)
            }.getOrNull() ?: continue
            for (method in methods[tag].orEmpty()) {
                val m = instance.javaClass.methods.firstOrNull { it.name == method && it.parameterCount == 0 } ?: continue
                val raw = runCatching { m.invoke(instance) }.getOrNull()
                if (raw is Number && raw.toInt() != -999999999) found["$tag.$method"] = raw.toInt()
            }
        }
        return found
    }
    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun encode(values: Map<String, Int>): String = JSONObject(values).toString()
    private fun decode(raw: String?): Map<String, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val j=JSONObject(raw)
            j.keys().asSequence().associateWith { key -> j.getInt(key) }
        }.getOrDefault(emptyMap())
    }
    fun record(context: Context, mode: String): String {
        require(mode in setOf("ECO", "NORMAL", "SPORT"))
        val values=snapshot(context)
        if (values.isEmpty()) return "신호 읽기 실패. 저장하지 않았습니다."
        prefs(context).edit().putString(mode, encode(values)).apply()
        return "${mode} 기록 ${values.size}개: $values; ${profileStatus(context)}"
    }
    private fun samples(context: Context): Map<String,Map<String,Int>> {
        val p=prefs(context)
        return listOf("ECO","NORMAL","SPORT").associateWith { decode(p.getString(it,null)) }
    }
    /** Only use getter(s) whose three recorded signatures are pairwise distinct. */
    fun discriminators(context: Context): List<String> {
        val s=samples(context)
        if (s.values.any { it.isEmpty() }) return emptyList()
        val common=s.values.map { it.keys }.reduce { a,b -> a.intersect(b) }
        val columns=common.sorted().filter { key -> s.values.map { it[key] }.distinct().size > 1 }
        if (columns.isEmpty()) return emptyList()
        // Prefer a single getter with a genuine three-state distinction; otherwise a compound signature.
        val single=columns.firstOrNull { key -> s.values.map { it[key] }.distinct().size==3 }
        return if (single!=null) listOf(single) else if (s.values.map { record -> columns.map {record[it]} }.distinct().size==3) columns else emptyList()
    }
    fun profileStatus(context: Context): String {
        val s=samples(context)
        val missing=s.filterValues { it.isEmpty() }.keys
        val keys=discriminators(context)
        return when {
            missing.isNotEmpty() -> "미기록=${missing.joinToString()}"
            keys.isEmpty() -> "구별 불가: 현재 SDK 조회값으로 ECO/NORMAL/SPORT 세 상태를 분리하지 못함"
            else -> "3상태 구별 가능: ${keys.joinToString()}"
        }
    }
    fun identify(context: Context, current: Map<String,Int>): String? {
        val keys=discriminators(context)
        if(keys.isEmpty() || keys.any { it !in current }) return null
        return samples(context).entries.singleOrNull { (_, s) -> keys.all { key -> s[key] == current[key] } }?.key
    }
    fun clear(context: Context) { prefs(context).edit().clear().apply() }
}

