package com.byd.dolphin.drivealerts.vehicle

/** Stable transition acceptance: first sample is a baseline, never a startup announcement. */
internal class StableModeSelector(private val required: Int=2) {
    private var candidate: String?=null
    private var count=0
    private var last: String?=null
    fun accept(value: String?): String? {
        if (value == null) { candidate=null;count=0;return null }
        if (candidate!=value) { candidate=value;count=1 } else count++
        if (count<required) return null
        if (last==null) { last=value;return null }
        if (last==value) return null
        last=value;return value
    }
}
