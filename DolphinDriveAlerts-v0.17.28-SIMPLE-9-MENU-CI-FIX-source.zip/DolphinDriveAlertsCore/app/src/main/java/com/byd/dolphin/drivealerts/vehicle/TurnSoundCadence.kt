package com.byd.dolphin.drivealerts.vehicle

/** 2602 instrument click raw=1/2 alternating, raw=3 terminal.
 * Candidate ON evidence only; can also describe hazards, does NOT imply side or prove indicator hardware.
 * The SDK left/right getter remains authoritative when available.
 */
internal class TurnSoundCadence {
    private var lastRaw: Int?=null
    private var lastAt=0L
    private var streak=0
    private var activeUntil=0L
    @Synchronized fun sample(raw: Int, timeMs: Long) {
        if(raw==3 || raw !in 1..2) { streak=0;lastRaw=null;activeUntil=0L;lastAt=timeMs;return }
        streak=if(lastRaw!=null && raw!=lastRaw && timeMs-lastAt in 100..850) (streak+1).coerceAtMost(12) else 1
        lastRaw=raw;lastAt=timeMs
        if(streak>=4) activeUntil=timeMs+1_000L
    }
    @Synchronized fun probableActive(timeMs: Long): Boolean = streak>=4 && timeMs<=activeUntil
    @Synchronized fun status(timeMs: Long): String = "turnClickRaw=$lastRaw streak=$streak age=${timeMs-lastAt}ms;candidate=${probableActive(timeMs)};hazardsNotSeparatelyVerified=true"
}
