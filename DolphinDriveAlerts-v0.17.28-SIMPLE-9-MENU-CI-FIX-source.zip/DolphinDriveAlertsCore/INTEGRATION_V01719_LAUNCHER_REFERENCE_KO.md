# Dolphin Drive Alerts 0.17.19 — Launcher V1 Evolution API 비교 통합

기준: v0.17.18 전체 소스 그대로 계승 / versionCode 45 / applicationId com.byd.dolphin.drivealerts, 별도 V1 앱 미교체.

| 이슈 | 변경 | 테스트 | 미확인 |
|---|---|---|---|
| DA-027 | `VehicleSplitEngine.launch` 비율 성공 후 실제 두 Task/stack ID, mode3/4 재검증. 앱2가 Drive로 바뀌면 성공 불가 | 정적 gate 및 기존 Kotlin split fixtures | 실제 2분할/20:80/360 화면 복귀 |
| DA-016 | `IgnitionSequenceAlarmReceiver` 12초 delivery fallback; process independent explicit Alarm; 서비스 ACK가 존재하면 중복 차단; ACC_OFF cancel | 새 게이트 및 receiver manifest 확인 | 시동 뒤 실제 MEDIA_PLAYING, 오디오 audible, FGS 정책 |
| DA-007 | `TurnSignalReadback` 양측 같은 장치·둘 다 0/1 확인, null·hazards 일반 경고 안전 유지, Launcher getter 후보 검색 확대 | 기존 Kotlin TurnSignalReadback stub 4/4 통과 | 실제 글로벌 2602 좌우 방향 신호/권한 |
| DA-003/005 | 코드 변경 안 함: APK와 현재 소스 모두 0/1/2 NORMAL/ECO/SPORT | 정적 매핑 일치 | Drive Alerts 실차 raw 0 관측되지 않아 NORMAL 음성 미해결 |

기존 성공 경로: 60 voice, EPB/기어/회생제동, EQ, 앱 권한, 화면 회전, 로그, 자동 패널 정책 보존. 시스템 CAN/ADAS/AVAS 쓰기 없음.

검증 구분: APK 원본 DEX/Registry 분석 `SOURCE_FOUND`; 위 파일 실제 수정 `CODE_CHANGED`; 이전 split Kotlin fixture와 v0.17.15 Kotlin 회귀 및 신규 16개 gate 통과 `LOCAL_TEST_PASS`. Android Gradle full compile/Actions APK `NOT_RUN`; 실차 `REALCAR_REVERIFY_REQUIRED`.

GitHub 수동 업로드: 새 full source ZIP(루트)에 배치, 새 workflow YML은 `.github/workflows/`에 배치, Actions 수동 실행. Debug 서명 불일치 시 기존 앱 덮어 설치 실패할 수 있으니 `DOLPHIN_DEBUG_KEYSTORE_B64` 기존 서명키 사용. 기존 사용자 설정/로그를 먼저 백업. 실패 시 v0.17.18 복귀.

안전 검증: 엔진/시동 시험은 정차 상태에서 실시, 차량 안전경고나 OEM 계기판을 비활성화하지 않는다. 정상 음성/재생은 청감+로그 모두 확인.
