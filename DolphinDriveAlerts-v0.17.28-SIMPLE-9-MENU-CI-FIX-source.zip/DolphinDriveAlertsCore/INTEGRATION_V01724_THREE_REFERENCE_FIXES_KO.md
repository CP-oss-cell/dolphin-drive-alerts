# Dolphin Drive Alerts v0.17.24 — DA-003/005, DA-007, DA-027 통합 수정

기준: v0.17.23 전체 소스 ZIP. 원본 실차 제출 로그(2026-10-10), Assistant v30 및 AutoSplit 1.2.0 비교.

## 1. NORMAL: 원시값 0 추측을 실제 3상태 원천 서명으로 대체
- 기존 raw1=ECO / raw2=SPORT 이벤트 및 음성 회귀 보존.
- 메인 화면 **주행모드 원본값 기록** → 차량을 안전하게 P에 둔 상태에서 순정 조작부로 ECO/NORMAL/SPORT 하나씩 선택한 뒤 각각 기록.
- read-only SDK getter 후보들(ENERGY/SETTING/INSTRUMENT)에서 3상태를 구별 가능한 키 또는 키 묶음만 승인. 중복 값이면 '구별 불가' 표시하고 추측 음성 차단.
- 교정 완료 시 2개 연속 관측, 최초 관측은 baseline, 그 뒤 모드 변경에만 알림. 콜백 1/2와의 중복 발화 방지를 위해 교정된 경로가 우선.
- **실차 3상태 신호가 실제로 구별되는지는 아직 검증되지 않았음.** 초기 raw1/2 단독으로 NORMAL 자동 발화 보장 불가.

## 2. BSD+깜박이: 실패한 null getter 단일 의존 제거
- **보조 클릭음 경로는 기본 OFF. 사용자가 시험 스위치를 직접 켠 경우에만 작동하며, 비상등과 구별 불가능할 수 있음.**
- 먼저 BYD 원래 좌/우 getter, getInstance(Context)/getInstance() 방식 모두 read-only 시도; SDK에서 실측 0/1이면 기존 경로.
- 2026-10-10 2602 로그 `INSTRUMENT_TURN_SIGNAL_SOUND` raw1→raw2 주기 반복, raw3 종료. 100~850ms 간격으로 네 단계 교대가 검출되면 최근 1초에 한해 클릭음 기반 후보로 평가. raw3/타임아웃이면 OFF.
- 반드시 LinkLock BSD raw2 활성 상태 & 사용자가 켠 BSD+깜박이 옵션 AND 신뢰할 수 있는 getter/클릭음 후보가 겹칠 때만 기존 `BSD_WARNING` (`후측방 조심`) 공통 1회. 위험 없이 깜박이만으로 자동 발화 금지. 기존 즉시 BSD 경고의 중복 억제 유지.
- **클릭음 후보는 비상등과 구분되지 않을 수 있음. 좌우 위험 방향 식별 기능 아님. 실차에서 false positive 검증 필요.** 순정 안전 장치 변경 없음.

## 3. AutoSplit: 원본 실행 순서 복원
- `am stack list` → AutoSplit style `Stack id=...bounds` + `mWindowingMode=split-screen-primary/secondary` 파싱을 먼저 적용; 기존 두 소스 병합 파서는 보조.
- AOSP 호환 8개 숫자의 `am stack resize-docked-stack`만 사용하고 부정확한 4개 숫자 우회 제거.
- 명령 실패 시 승인된 기존 로컬 ADB가 READY일 때만 한 번 재시도; 성공 응답 뒤 재조회가 50:50이면 성공으로 선언하지 않음.
- 두 앱이 확인됐다면 비율이 실패해도 `last_split_id`는 보존하고 '두 앱 성공, 비율 미검증'을 구분하여 360 복귀 후보 유지.
- 원본 AutoSplit 1.2.0은 사용자가 실제 비율 변경 성공 보고. 당사 v0.17.24가 실차 비율 성공한 것은 아직 아님.

## 종결 조건
1. NORMAL ECO/NORMAL/SPORT 순차 전환에서 각 1회 안내, 잘못된 모드 중복 금지.
2. BSD raw2 활성 + 좌/우 단일 방향지시등 = 일반 음성 1회; BSD만/깜박이만/비상등 구별/위험 해제 모두 확인.
3. 분할 A+B 앱 분리 유지, 20:80과 70:30 실 화면 변화, 360 화면 후 복귀, SHA/로그 증거.

상태: SOURCE_PATCHED / LOCAL_KOTLIN_VERIFIED / GITHUB_ANDROID_COMPILE_NOT_RUN / REALCAR_REVERIFY_REQUIRED.
오디오·순정 AVAS·차량 주행 ECU 관련 위험한 쓰기 신호 추가 없음.
