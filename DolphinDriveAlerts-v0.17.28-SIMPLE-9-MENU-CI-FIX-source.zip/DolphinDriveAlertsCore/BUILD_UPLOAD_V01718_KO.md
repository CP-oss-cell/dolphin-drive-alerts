# Dolphin Drive Alerts v0.17.18 GitHub 수동 빌드 안내

1. GitHub `CP-oss-cell/dolphin-drive-alerts` 저장소의 **최상위**에 `DolphinDriveAlerts-v0.17.18-REFERENCE-RECOVERY-CANDIDATE-source.zip` 업로드. 기존 v0.17.17 ZIP 삭제/덮어쓰기 금지.
2. `.github/workflows/build-v01718-from-source-zip.yml` 에 별도 YML 파일 업로드.
3. Actions → `Build Dolphin Drive Alerts v0.17.18 Reference Path Recovery Candidate APK` → Run workflow.
4. JVM split test → Kotlin Android `:app:compileDebugKotlin` → `:app:assembleDebug` → apksigner 통과한 후 Artifact `DolphinDriveAlerts-v0.17.18-REFERENCE-RECOVERY-CANDIDATE` 에서 실제 APK 받기.
5. `applicationId=com.byd.dolphin.drivealerts`, versionCode 44, Android 10+.
6. 기존 설치 앱과 디버그/릴리스 서명이 달라지면 업데이트 설치가 거부될 수 있음. 기존 정상 APK와 데이터는 백업하고 함부로 기존 앱을 삭제하지 않음.
7. 설치 후 **주행 전 안전한 정차 상태에서** 2분할/미디어를 시험. `INTEGRATION_V01718_REFERENCE_GAPS_KO.md`의 판정 기준대로 확인. 원복이 필요하면 이전 서명 일치 정상 APK로 되돌림.

경고: Kotlin 생산 코드 수정 + 로컬 JVM 테스트 결과이며 APK 빌드/실차 성공은 아직 아님. **NORMAL·BSD 깜빡이 문제는 이 파일로 해결됐다고 주장하지 않음.**
