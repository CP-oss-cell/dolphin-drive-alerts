# Dolphin Launcher V1 Evolution APK 정적 포렌식 전체 감사 — 2026-10-13 (KST)

## 출처·식별·수행 범위
- 사용자가 직접 업로드한 원본 `DolphinLauncherV1-Evolution.apk`, **원본 절대 변경 없음**.
- 원본 SHA-256 `51dd68e5d62b0066e2039af9b12000ef89e1d899576c2b62d2abf8bf7b8c99e2`, 5,856,987 bytes; ZIP CRC 검사 및 전체 각 파일 SHA 별첨.
- 바이너리 XML 직접 해석, DEX 구조 테이블 전수 추출(클래스·메서드 정의), 관련 메서드 DEX opcode / const-string / invoke 경로 추적, APK 내 Registry / known-bad / test-contract 대조. 설치/실차 실행/동적 hooking/전체 decompile 소스 복원은 **수행되지 않음**. `strings`의 존재 자체를 성공으로 승격하지 않음.
- APK 패키지 `com.dolphin.launcher.v1`, manifest `versionName=1.2.20-v1-premium-realcar-beta`, `versionCode=23`, minSdk 29, targetSdk 35, compileSdk 35. **Dolphin Drive Alerts 패키지와 구분**.
- APK 구조 55 ZIP entries, classes.dex 4,120,500 bytes, 3,380 DEX class definitions, 27,539 DEX method references, 27,441 DEX strings; 프로젝트 이름공간 클래스 277개, 프로젝트 선언 메서드 1,483개. 프로젝트 외 Kotlin/JUnit/picocli 등 클래스도 포함되어 있으므로 3,380개 모두 차량 제어 코드 아님.
- Manifest 구성: 19 activities(메인·검증센터·Ghost·비활성 동적 바로가기 16개 포함), 1 service(NotificationListener), 4 receivers, 5 uses-permission(BOOT/INTERNET/ACCESS_NETWORK_STATE/REQUEST_INSTALL_PACKAGES/SCHEDULE_EXACT_ALARM). `LauncherActivity` LAUNCHER만 등록, HOME category 미등록; 등록만으로 기본 홈 역할 확인되지 않음.
- 24 WAV / 6 JSON asset / native .so 0; `META-INF/DOLPHINA.RSA` 서명 증명서 subject `C=KR, O=Personal, CN=DolphinAssistant`, SHA-256 fingerprint `AB:7A:71:53:63:49:5A:F6:FE:EB:ED:52:7E:74:50:06:46:BF:1D:06:6C:28:9D:87:BC:4C:A7:A4:7F:CE:D8:74`. APK 전체 v2/v3 서명 검증은 미실시.
- 내장 검증 Registry v3: 기능 43개( BETA 19 / REVERIFY_REQUIRED 13 / BLOCKED 11); known-bad 17건, 테스트 로그 계약 63개. 완성·실차 VERIFIED 43개가 아니다.

## 증거 등급과 필수 구현 차이 비교

| 주제/이슈 | APK 원본에서 실제 발견한 입력 → 경로 | v0.17.18 Drive Alerts 실제 상태 | 새 v0.17.19 변경/한계 |
|---|---|---|---|
| DA-003/005 NORMAL | `VehicleReadOnlyMonitor.sample()` : `BYDAutoEnergyDevice.getOperationMode` → `changedNormalized("voice.energy.operationMode")` → `raw 0 / 1 / 2`를 NORMAL/ECO/SPORT로 매핑 → `onDriveMode` → `VehicleVoicePolicy.driveMode`/고정 음성. `known_bad_registry.json:KB-001`은 이 매핑을 **FIX_CANDIDATE**, 3회 실차 재검증 필요로 분류 | `DriveModeDecoder`에 **이미** `0→NORMAL,1→ECO,2→SPORT` 구현됨. 2026-10-11 Drive Alerts 실차 getter/callback 값 1/2만 관찰, raw0 없음 | 매핑 복사로 해결될 이슈 **아님**. 기존 안전한 0/1/2 매핑·기어 음성 유지, NORMAL 실차 변화 수집과 독립 getter/callback 확인 필요. 추가 정상 발화 강제 **없음** |
| DA-027 분할 | `SplitExecutionBridge.launch`: local dadb authorized → 기존 primary task 탐색 → 필요 시 `SplitGhostActivity` mode3 → `am stack move-task` → mode3 readback → secondary mode4 시작/이동/재시도 → `finalReadback` (`readback_verified`, `left_primary`, `right_secondary`). `KB-004` 여전히 FIX_CANDIDATE, 360 복귀 자동 복원은 증거 전 차단 | v0.17.18 `VehicleSplitEngine`에도 Ghost, 두 Task, mode3/4, 기존 task 이동과 ratio bounds readback 구현되어 있음. 복사만으로 개선 안 됨 | **새 변경** ratio readback 직후 primary·secondary Task ID, stack ID, mode 재검사. 2번째 앱이 자기 화면으로 바뀐 경우 성공 오판 차단. 실제 Task 전환 성공/복귀는 미입증 |
| DA-016 시동 앱/미디어 | `BootAutoLaunchRuntime`은 boot_count/elapsed 중복 회피 → `AlarmManager` PendingIntent 앱별 예약 → `BootAutoLaunchReceiver.execute` → `BackgroundMediaRuntime.requestPlay` 및 target package 세션 재시도. `KB-006`, `KB-012` 역시 실차 재검증 필요 | v0.17.18 `BootReceiver`는 FGS `AutoLaunchSequenceService.start` 호출과 프로세스 내 Thread의 미디어 세션 실행/재시도. 프로세스/서비스 전달 누락 복구 경로 부족 | **새 변경** 서비스 요청 후 12초 일회성 AlarmManager 전달 검사. `onStartCommand` 수신 ACK 존재하면 **중복 시작 금지**; 수신이 없으면 재시작 1회. ACC_OFF 취소. 미디어 재생 소리 자체는 별도 readback/실차 확인 필요 |
| DA-007 BSD+깜빡이 | `VehicleReadOnlyMonitor.sample` → `BYDAutoADASDevice.getBSDState` 및 `getLeftTurnLightState`·`getRightTurnLightState` → `turn_left_raw / turn_right_raw` → `onBsdRaw`/`onTurnRaw`. 해당 APK가 좌우 getter를 쓴다는 코드는 확인됐지만 글로벌 2602 차량에서 실제 값/소유 device class가 검증된 것은 아님 | `TurnSignalReadback`는 LightDevice 두 후보에서 읽고, 기존 classify 조건에서 한쪽 1·반대 null인 경우에도 true 가능. 실차 null/log 실패 | **새 변경** Read-only 후보 SDK class를 확장하고 **하나의 동일한 device instance**에서 얻은 두 개의 숫자 0/1만 한 쌍으로 채택. `1/0`,`0/1`에서만 깜빡이 활성, null/1·1/1·비정상 값은 차단. 기존 BSD 즉시 경고 경로/미확정 위험 좌우 음성 금지 보존. 실차 값은 아직 미확인 |
| DA-015 EQ / 기존 UI | APK `OwnedAudioEqualizer`, `OwnedSoundPosition`, `AudioCapabilityProbe`는 앱 소유 세션/효과 및 후보 기능; OEM DSP 360 구현 증거 아님 | 현재 Drive Alerts EQ 미세강화/원복 기능 존재 | 건드리지 않음 |
| DA-025 계기판/TBT/AVAS | `InstrumentCapabilityProbe`,`LaneDepartureCapabilityProbe`,`InteriorLightCapabilityProbe` 등 읽기/후보 경로와 Registry BLOCKED 존재 | 계기판 쓰기/AVAS 송신 검증되지 않음 | OEM 계기판·ADAS·AVAS 차량 쓰기 변경 **없음** |

## 중요한 부정 증거(오판 방지)
1. `DolphinLauncherV1-Evolution.apk` 자체는 **원본 source.zip이 아님**. 바이너리 DEX가 클래스·opcode를 보여도 원래 빌드의 Kotlin/Java 소스를 그대로 복원하지 못한다.
2. V1 `KB-001`의 0=NORMAL, 1=ECO, 2=SPORT은 `FIX_CANDIDATE`, 직접 현재 차량의 `raw0`를 확인했다는 의미가 아니다. Drive Alerts에서도 동일 매핑이 이미 존재했으므로 “정답 발견=기존 정상음성 복구 완료”는 거짓.
3. V1 `KB-004`는 primary/secondary readback 구현 **후에도** 사용자의 실차 검증이 필요하다. 동일 Ghost 이동을 중복 이식해도 2분할이 성공하는 것은 아니다.
4. V1 Manifest receiver가 BootCompleted용 부팅 리시버와 내부 Alarm receiver를 분리하고 있어, Android 10의 백그라운드 기동 성공을 API 등록만으로 보장하지 못한다.
5. 외부 APK의 원본 서명·패키지 ID를 Drive Alerts의 서로 다른 APK에 이식하지 않는다. ADB 승인과 앱 설치 퍼미션은 별도.
6. `TARGET_SDK=35`인 V1 런처 APK는 Drive Alerts `targetSdk=29`와 다른 권한/알람 런타임 정책을 가질 수 있다. 코드 패턴만 호환성 검증 없이 사용 금지.

## 전수 인덱스 (증거 첨부)
`LAUNCHER_V1_EVOLUTION_FORENSIC_INDEX_20261013.zip`에는 ZIP 55개별 크기·CRC·SHA, DEX 3380개 클래스 전수 색인, 프로젝트 1483개 메서드 전수 색인, 바이너리 XML Manifest 속성 해석, 24 음원 정보, 기능 Registry 43개, known-bad 17개 원본 JSON, 로그 계약 63개 ID/필드, 관련 클래스 DEX opcode 문자열/호출 추적을 넣었다. 이 목록은 코드의 기능 실행 동작이나 실차 성공을 증명하지 않는다.

## 적용 상태
`SOURCE_FOUND + CODE_CHANGED + LOCAL_TEST_PASS` (프로젝트 일부 Kotlin 독립 테스트/정적 검사). `ANDROID_CI_PASS` 미확인. `REALCAR_REVERIFY_REQUIRED`. 최종 발화/소리/분할 화면/부팅은 사용자의 한국형 Dolphin Standard + 글로벌 2602에서 별도 확인.
