# v0.17.17 CI 수정 및 원인 재현 — Dolphin Drive Alerts

기준: GitHub Actions `CP-oss-cell/dolphin-drive-alerts` run `38111674549`, checkout `db5703f1d51686b597d395fd38e96ffc65a08a8d`, 소스 ZIP SHA256 `1aea171eb798ee19f9444c424973c32620295c8dc483c040e26040b6b9b3a2b8`.

## 실제 실패 단계

- **실패 시간:** 2026-10-11 04:30:56 UTC. `Verify actual EQ Kotlin source against Android API contract stubs`에서 Python `tools/verify_v01713_policy_kotlin.py` → 실제 Kotlin 테스트 Runner.kt:25가 `IllegalStateException`으로 중단.
- 오류: `TASK_MODES_UNRESOLVED firstTaskIds=[] secondTaskIds=[] firstModes=[3] secondModes=[4];independent=false`.
- 그 전에 소스 ZIP 인식, 필수 문서, v0.17.13·14·15·16 정적 검증, EQ·미디어·OEM SDK·BSD·EQ Kotlin 테스트는 통과.
- **:app:compileDebugKotlin 및 :app:assembleDebug에 도달하지 못함.** APK 없음. setup-java@v4 사용중단 경고와 Kotlin Boolean 경고는 실패 원인이 아님.

## 원인 (실제 코드와 테스트 대조)

`tools/verify_v01713_policy_kotlin.py`에는 `Task{101 mode=3 ...}` / `Task{102 mode=4 ...}` 형식이 들어 있지만, 최근 v0.17.15에서 강화된 `SplitTaskReadback.kt`는 `taskId=101`, `Task #101`, `Task{a #101...}` 형태에서만 ID를 추출했다. 따라서 mode 3과 4의 존재에도 Task ID 집합이 비어 테스트 실패. 버그는 `SplitTaskReadback`의 레거시 `Task{101 ...}` 처리 누락이다.

## 실제 수정

1. `SplitTaskReadback.kt`: `Task{101 ...}`·`Task{a #17 ...}`·`Task #111`·`RootTask #201`·`taskId=301` 형식의 ID 추출 추가. ID를 확인하지 못하면 무조건 `UNRESOLVED` 유지.
2. 독립 Task 판정에서 양쪽 패키지가 같은 Task ID를 공유하면 즉시 `MISMATCH`로 분류. `am start` 명령 성공/패키지 텍스트 출현만으로 VERIFIED하지 않음.
3. 실제 과거 v0.17.13 Kotlin 테스트를 변경하지 않고 그대로 실행해 재발 방지. 추가 `tools/verify_v01717_split_task_ci.py`는 정상/공유/불명/일반 모드 등 **실제 운영 Kotlin 코드 11개 fixture**를 컴파일·실행.
4. 과거 검사 스크립트 `verify_v01710_reference_bridge_contract.py`, `verify_v01715_realcar_repair.py`, `verify_v01716_tbt_location_permissions.py`의 과도한 v0.17.16 버전 고정만 해제. 각 기능 계약은 유지.
5. Android 버전 `versionCode 43`, `versionName 0.17.17-split-task-readback-ci-fix`, 패키지 이름/SDK/기능 변경 없음.
6. GitHub Actions에 `v0.17.17` 테스트 및 파일 검사를 추가; 기존 v0.17.8/9와 v0.17.13~16 검사 유지.

## 안전·범위

- 이번 수정은 **CI 분할 Task 증거 판정 로직의 회귀 버그** 수정이지 실차 2분할 성공 보장 아님. 50:50 고정, 두 번째 칸 Dolphin Drive 실행 문제, ADB 포트/RSA, BSD 깜빡이, NORMAL, TBT 계기판 표시는 여전히 별도 실차 검증 필요.
- 기존 v0.17.16 권한 메뉴, v0.17.12 EQ, v0.17.11 BSD 상시, v0.17.14 ADB, v0.17.15 로그 안정화 소스는 변경하지 않음.
- 전체 Android APK 빌드 및 실차 시험은 GitHub Actions/차량에서 별도 확인. 로컬 `kotlinc`는 Android SDK 앱 전체 빌드가 아님.

## 로그 외 경고 구분

`actions/setup-java@v4` deprecation, Node 20/24 경고, `java.lang.Boolean` Kotlin 경고는 비차단. Android API 34 설치·APK 서명 단계는 실행 전 종료.
