# DA-013 · v0.17.20 GitHub Actions 음성 생성 403 실패 → v0.17.21 CI 수정

작성: 2026-10-13 (KST). 관련: DA-013 빌드/배포, DA-009 자체 음성 경로, DA-010 NAV 5종 오디오 실험실. 새 DA 번호 생성하지 않음.

## 실패 증거

- 사용자가 제출한 `logs_104050243685.zip`에는 GitHub Actions `Build Dolphin Drive Alerts v0.17.20 One-Install Nav Audio Lab APK` 로그가 들어 있다.
- Source ZIP 검증·압축 해제·배포 문서 검사·기존 통합 정적 검사와 신규 오디오 실험실 검사 **모두 통과**.
- `Generate and verify 60 Korean voice assets`에서 `gear_p.wav` 첫 남성 음성을 생성하는 중 Edge TTS WebSocket `403 Invalid response status`, 총 3회 실패. 최종 `subprocess.CalledProcessError`와 `exit code 1`.
- 이후 `:app:compileDebugKotlin`과 `:app:assembleDebug`는 실행되지 않았다. **이 로그로 Kotlin 컴파일 성공·실패를 판단하지 않음.**
- Node 20/24 경고는 실패의 직접 원인이 아니다.

## 실제 수정

1. 기존 소스를 기준으로 `tools/generate_voice_pack.py`를 재시도·대체 공급자·캐시 재사용·SHA/프로바이더 기록 방식으로 보강. Edge 서비스가 실패하면 같은 배치에서 Edge 호출을 반복하지 않는다.
2. 기본 출력 언어는 한국어, 기존 30개 문구 × 2 프로필(총 60개) 유지. 유효하지 않은 WAV/무음/텍스트·해시 불일치 시 빌드 차단.
3. `.github/workflows/build-v01721-from-source-zip.yml`에 `actions/cache@v4` 기반 재사용: 첫 빌드 성공 후 다음 빌드는 Edge나 대체 TTS를 호출하지 않음. 기존 `--force` 강제 재생성 제거.
4. Edge TTS 실패 시 gTTS 한국어 공급자로 합성 가능. **대체 음성은 기존 Edge 남성·여성 Neural과 동일한 음색이 아니다.** 남성 프로필은 피치만 낮춘 대체 음성이다. Actions Summary에 공급자/품질 경고. `require_original_edge_voices=true` 입력을 사용하면 대체 음성으로 빌드되는 것을 차단.
5. `refresh_voice_assets=true`로 별도 실행 시 음색/프롬프트 재생성. 기본값 false이며 검증된 캐시는 재사용.
6. 차량 이벤트·음성 문구·stream14/미디어 출력·5종 내비 목록·BSD 음성·오디오 실험실 기능 실행 코드는 이 수정에서 변경하지 않음.
7. 앱 버전 `0.17.21-nav-audio-lab-ci-voice-fix`, versionCode 47, 기존 `applicationId` 유지.

## 검증 상태

- 이전 v0.17.20 소스 검사 21/21, v0.17.19 회귀 검사 16/16, 신규 CI 음성 오프라인 계약 12/12 PASS.
- 신규 계약 시험의 사인파 파일은 TEMP 폴더에만 생성해 WAV PCM 변환·무음 거부를 검사한 것으로, APK 출하 음성이나 차량 재생 성공 근거가 아니다.
- 기존 v0.17.10/13/14/15/16/17 CI 전처리 정적 검사는 PASS.
- **GitHub Actions 재빌드 / 실제 Edge 및 gTTS 공급자 네트워크 성공 / Gradle Android 전체 컴파일 / 실차 설치·청취 모두 미실행**.
- 외부 TTS 2곳이 모두 응답하지 않으면 새로 오디오를 만들 수 없고 빌드가 실패한다. 오프라인 완전독립형을 원한다면 재사용 가능한 60개 실음성 WAV 아카이브를 릴리스 자산으로 보존해야 한다.

## 배포 원칙

수정안은 타 앱 오디오 강제 라우팅(DA-010) 구현을 추가하지 않는다. 해당 기능의 실차 성공을 표시하지 않으며, 외부 AVAS를 건드리지 않는다. Debug APK 업데이트는 기존 서명키 일치 확인 필수.

**상태:** `LOG_CONFIRMED / ROOT_CAUSE_CONFIRMED / CODE_CHANGED / LOCAL_CHECKS_PASS / CI_RERUN_REQUIRED / REALCAR_REVERIFY_REQUIRED`.
