# v0.17.17 통합 소스 수정 및 테스트

- 수정 대상: `SplitTaskReadback.kt`, 앱 Gradle 버전, 검증 스크립트 3개, Actions workflow.
- 신설: 레거시/현대 Android Task 덤프를 검사하는 실제 Kotlin 테스트 `tools/verify_v01717_split_task_ci.py`.
- 동작 방식: Task ID를 독립적으로 얻어야 하며, 동시 출현 패키지 또는 하나의 Task 공유 시 성공 불가. `verified`는 진단값이며 사용자 눈에 보이는 두 분할 화면의 정상 실행을 보증하지 않음.
- 최신 차량 로그의 분할 두 번째 앱 오류는 별개로 여전히 미해결.
- 오류 근거 및 재현 방법: `GITHUB_BUILD_FAILURE_V01716_TO_V01717_KO.md`.
- TBT 알림 권한·위치 권한 UI 등 v0.17.16의 기존 기능은 소스 보존, 새 검증 대상 아님.
- 실제 APK 컴파일/GitHub Actions 실행과 실차 승인·시각 확인 전까지 검증 결과를 VERIFIED로 승격하지 않음.
