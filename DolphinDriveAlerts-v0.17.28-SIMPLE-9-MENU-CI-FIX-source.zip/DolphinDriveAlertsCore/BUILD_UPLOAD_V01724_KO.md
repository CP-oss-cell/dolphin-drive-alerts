# v0.17.24 GitHub Actions 설치용

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 루트에 `DolphinDriveAlerts-v0.17.24-NORMAL-BSD-SPLIT-REFERENCE-REPAIR-source.zip` 업로드.
2. YML 파일 `build-v01724-from-source-zip.yml`을 `.github/workflows/build-v01724-from-source-zip.yml`로 업로드.
3. Actions 화면에서 **Build Dolphin Drive Alerts v0.17.24 Three Reference Repairs APK** 수동 실행.
4. 기본 `voice_mode=effects_only`는 잘못된 성별 음성을 만들지 않는 효과음 시험판. 남/여 원본이 필요하면 `neural_only` 사용하며 음성 서버 403이면 빌드가 중단될 수 있음.
5. 빌드 Artifact `app-debug.apk` 다운로드. 기존 APK와 서명이 다르면 삭제/재설치가 필요할 수 있으며 설정 백업 필요.
6. 설치 후 앱 메인 화면의 `주행모드 원본값 기록`에서 P 상태로 ECO/NORMAL/SPORT 각각 기록, 실차 별도 재검증.
7. 기존 2분할 프로필에서 20:80, 70:30 각각 재적용, 로그 ZIP 저장.

변경한 것은 차량 조회/음성 후보 판정, 로컬 ADB 분할창 명령이다. 미검증 안전장치/차량 신호 쓰기 없음. GitHub Gradle 전체 컴파일 및 실차 검증은 아직 실행되지 않았다.

BSD 클릭음 보조 판독은 기본 OFF입니다. 안전한 시험에서만 선택적으로 켜고 비상등 오인 여부를 확인하세요.
