# Dolphin Drive Alerts v0.17.20 — 한 번 설치하는 내비 오디오 통합 실험실

## 증거 우선 대조: Research → Issue → Gap → Patch → Test → Build → Real-car

| 구분 | 기존 실차 확인·참조 | v0.17.19 코드 차이 | v0.17.20 조치 | 완료 상태 |
|---|---|---|---|---|
| DA-009 자체 안내음 | Assistant v30.5 Route 5 raw14 / Route 6 legacy14 모두 사용자 운전석 전용 청취 성공(2026-09-16) | 앱 자체 AlertAudioPlayer stream14는 존재, 즉시 후보별 청취·위치 기록 화면 없음 | `NavRouteLabPlayer`에서 MEDIA/NAV/Route5/6/현재 Android 출력장치 개별 톤 재생과 실제 routedDevice·청취 위치 기록 | SOURCE_CHANGED/LOCAL_TEST_PASS; 새 버전 실차 미검증 |
| DA-010 순정 내비 비교 | 2602 `BydAutoTMap.apk` 및 `audio_policy_configuration.xml`; `BYDAutoAudioDevice`, `TmapNavigationAudio` 후보 | 수동 snapshot 버튼만 있고 실제 앱 실행 중 자동 수집·후보 비교·독립 내보내기 없음 | `NavRouteCaptureService`가 3,8,15초 자동 read-only AudioFlinger/Policy/Audio/UID 캡처, 순정/지정5종 파일 별도 구분, 요약 비교 | SOURCE_CHANGED/LOCAL_STATIC_PASS; OEM 물리 경로 미확정 |
| DA-010 타 앱 운전석 재라우팅 | 사용자 5종 길안내는 미디어 출력, 운전석 전용 선택은 미작동; 자체 stream14 성공과 분리 | `ExternalAppAudioRouter` 설정 저장만, OEM cross-UID 구현 없음 | `MODIFY_AUDIO_ROUTING` 권한 검사 + ADB 접근 검증 + 미구현 명시. UID 재라우팅/믹서 변경/권한 우회 구현 없음 | **실제 타사 내비 음성 라우팅 미해결** |
| DA-012 외부 AVAS | 2026-10-07 RAW AVAS 두 진단 ZIP, 재시동 이후 수집 누락/소리 출처 혼선 존재 | AVAS 미검증 상태 | AVAS ECU/MCU/write 호출 없음; 기존 연구·앱 안전 기능 그대로 | DA-012 OPEN, 변경 없음 |
| 회귀 (DA-003/005,007,015,016,027) | 기존 기어·회생제동·오토홀드·stream14·BSD 공통 음성 등 보존 | 변경 필요 없음 | 기존 파일 삭제 없이 새 Activity+Service+Player+순수 상태 검사만 별도 추가. versionCode 45→46 | 기존 SOURCE gating PASS, Android CI 미실행 |

## 실제 구현되는 일

1. 한 APK 내 `오디오 라우팅 실험실` 실행.
2. `순정 내비 15초 자동 스캔` → 사용자가 순정 내비 안내음을 재생. 샘플은 3,8,15초에 read-only `dumpsys audio`, `dumpsys media.audio_policy`, `dumpsys media.audio_flinger`, `pm list packages -U`를 캡처. 원본 출력·명령 exit/status 유지. 12개 명령 중 하나라도 실패하면 `PARTIAL_FAILED_COMMANDS.txt`를 쓰고 자동 비교 대상으로 승격하지 않음.
3. MEDIA/Android NAV/Route 5 raw14/Route 6 legacy14/Android 출력 장치 중 선택 → **우리 앱 자체 0.5초 음**을 해당 경로로 실제 요청, `AudioTrack` 세션과 Android routed device ID 기록. 사용자가 실제 청취 위치를 기록.
4. 5종 내비 하나 선택 → 앱 실행 및 3/8/15초 후 자동 스냅샷. 안내음이 재생된 순간이 아니면 그 샘플은 길안내 증거가 아닐 수 있음.
5. 순정과 선택 앱 데이터 비교 → 로그 내 사용자 지정 위치에 ZIP 저장. 빠른 재시도/후보 선택은 재빌드 불필요.
6. 테스트 종료 시 별도의 AudioTrack은 release; 타 앱·차량 정책에 쓰기 요청 없음. 별도 출력을 변경하지 않아 원복할 글로벌 상태도 없음.

## 지원 범위의 명백한 한계

- **Route 5/6 시험은 우리 앱 소리의 전용 출력 시험**이지 지정 내비의 안내음을 강제로 이동시키는 기능이 아님.
- Android `AudioDeviceInfo`의 ID가 운전석 스피커를 물리적으로 뜻한다고 단정하지 않음. 실제 청취가 필요.
- `MODIFY_AUDIO_ROUTING`가 없으면 Android 타 UID AudioPolicyMix/UID affinity를 일반 앱에서 사용할 수 없음. 권한이 있어도 현 빌드는 OEM 어댑터·실차 동작이 입증되지 않았으므로 `NOT_IMPLEMENTED`를 정확히 표시.
- Android AudioPlaybackCapture는 앱별 허용 정책과 usage 제한 때문에 NAVIGATION_GUIDANCE를 보편적으로 캡처하는 해법이 아님. 안전한 타 앱 전체 음성 강제 라우팅을 구현했다는 주장은 하지 않음.
- 단일 빌드에서 순정/제3자 A/B 시험을 이어갈 수 있지만, 타사 내비 음성 출력 *변경*을 한번에 완성했다는 뜻은 아님.
- Android 전체 Gradle 빌드는 GitHub Actions 실행 후 확인. 로컬 Kotlin/정적 검사 및 XML/YAML/ZIP 검사와 구별.

## 증거 라벨

`REFERENCE_USER_REPORTED_REALCAR_WORKS`: Assistant v30.5 own-stream14만.
`SOURCE_FOUND`: 순정 TMAP BYDAutoAudioDevice/navigation references, 그러나 동적 endpoint 미확정.
`CODE_CHANGED`: v0.17.20 경로 스캐너·실제 자체 출력 후보 테스트·사용자 관찰·비교·ZIP 내보내기.
`LOCAL_TEST_PASS`: Kotlin pure evidence evaluator + source gates, 기본 회귀. Android instrumentation 없음.
`ANDROID_CI_PASS`: 아직 미확인.
`REALCAR_REVERIFY_REQUIRED`: 모든 새 실험실 기능 및 DA-010 타 UID 라우팅.

## 안전 원칙

차량 정차(P) 상태에서만 시험. 순정 내비 설정/차량 오디오 믹서/AVAS/ADAS/ECU 전혀 쓰지 않음. 서명키가 다른 Debug APK는 기존 앱 위에 업데이트 불가 가능성 있음. 현재 소스의 기타 정상 기능과 사용자 설정을 보존.
