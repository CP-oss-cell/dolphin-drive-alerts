# Dolphin Drive Alerts v0.17.18 — 기존 성공 경로 대조 및 수정 후보 (2026-10-12)

대상 차량: 국내 BYD Dolphin Standard / 글로벌 2602 / Android 10.
기준: v0.17.17 전체 소스, 2026-10-12 근거 우선 정책, 기존 DA-003/005/007/016/027, 실차 기록.
실제 GitHub CI와 실차 설치/주행 테스트는 이 로컬 작업에서 실행하지 않았음.

## Research → Issue → Gap → Patch → Test → Build → Real-car

| DA | 실제 실패와 원인 근거 | 검증 레퍼런스 / 차이 | 이번 실제 변경 | 검증 현황 | 남은 과제 |
|---|---|---|---|---|---|
| DA-027 2분할 | 기존 앱에서 MConK+YouTube 선택해도 앱1+DriveAlerts 자기 화면 / 50:50. 기존 엔진 단순 am start mode 3/4, ghost-stack 및 기존 task 이동 누락. 비율도 `wm size` 4인자 호출 사용 | 과거 Dolphin Assistant v30 `SplitScreenManager`, `SplitGhostActivity`: 기존 primary Task를 Ghost split-primary stack으로 이동, mode 3/4 각각 확인. AutoSplit 1.2.0 static report: `SplitScreenController.moveExistingTaskToMode`, `SplitRatioController.apply/verify` | `LegacySplitTaskLocator`, `SplitGeometry`, `SplitGhostActivity` 추가. `VehicleSplitEngine.launch` Ghost/`am stack move-task`/각 모드 readback/서로 다른 Task 강제, `applyRatio` 실제 stack 두 창 bounds 및 8인자 resize, 이후 실제 비율 readback | SOURCE_FOUND, CODE_CHANGED, JVM split fixture PASS. 전체 Android CI 미실행 | 글로벌 2602 실제 Task 덤프/앱 두 칸/20:80/360 복귀 재검증 필수 |
| DA-016 시동 자동재생 | 사용자 실차: 자동 진입은 재생 실패, 수동 앱 실행 후 재생 정상. v0.17.17에서 Browser 미노출·세션 미존재 미디어는 무조건 continue | AutoStart 2.4.4 APK static report: `AutoStartSequenceService.runAppTrack`, `MediaSessionBootstrap` 앱 기동/세션 확인. 현 코드에서 앱을 기동하지 않은 것이 확정된 dead end | `AutoLaunchSequenceService`: 사용자 설정한 미디어만 active session / Browser 먼저 시도. 실패하면 ADB READY 대기 및 지정된 앱 1회 실행 → MediaSession 최대 3회 play/readback, 성공 시 HOME. 무조건 성공으로 기록 안 함. 화면 열림 가능성을 UI에 명시 | SOURCE_FOUND, CODE_CHANGED, source regression PASS. 차량 부팅 시 FGS/ADB 정책 적용 여부 미확인 | 시동→알림 서비스→미디어 Session/PLAYING 타임라인, 실제 소리 청취 검증 필요 |
| DA-003/005 NORMAL | 최신 2026-10-11 차량 로그 `ENERGY_OPERATION_MODE` 1/2, getter 동일한 1/2만 관찰. raw0/NORMAL 이벤트 없음. 에코·스포츠와 별도의 정상 모드 신호 미확정 | v30 소스 UI NORMAL 문구 편집은 존재하지만 실제 독립 NORMAL callback 도출 불가. AudioFeedback/SubAI은 정상 동작 사용자 보고이며 SubAI 1/2는 SPORT OFF/ON 분기 | 원시값/SDK getter 기준 보존, 추정 순환 카운트나 raw=1의 NORMAL 강제 매핑 금지. 기존 ECO/SPORT 음성 유지 | LOG_OBSERVED, RESEARCH_GAP_OPEN; **해결 코드 아님** | 레퍼런스 dex `handleOperationMode` 분기와 정상/ECO 입력 차이, 동일 시각 순정 상태 증명 없이는 정상 발화 미해결 |
| DA-007 BSD 깜빡이 | 로그: 0x41800008 raw2 유효, 즉시 일반 경고 실차 동작. `TurnSignalReadback` left/right null, `BSD_GATE_ACCEPTED=0`, 좌/우 위험 신호 불명 | LinkLock 805 raw2 위험 활성; AudioFeedback/OverDrive는 별도 타 앱. `INSTRUMENT_TURN_SIGNAL_SOUND` 단순 소리는 깜빡이 방향/활성 확인 아님 | 상시 일반 BSD 원래 경로/두 독립 설정 유지. null→ON 가공, 미확정 좌우 안내 또는 CAN/ADAS 쓰기 **추가하지 않음** | LOG_OBSERVED, RESEARCH_GAP_OPEN; **연동 해결 코드 아님** | 실차 실제 left/right active API/권한 또는 식별된 다른 원천 값을 검증 후 이식 |

## 기존 동작 보존
기어·SPORT/ECO·회생제동·오토홀드·후측방 즉시 모드·60개 음성·EQ 미세 강화/원복·앱 권한·회전·로그 ZIP·TBT/계기판 읽기 전용 구성은 삭제하지 않음. AS IS 333개 기준 신규 구현 3 Kotlin 파일/기존 Kotlin 3개/manifest 1/Gradle1/테스트 일부/문서. 

## 새 실패 재현과 통과 조건
- DA-027: 정상 ADB Ready. 앱 A·B 기존 Task 및 콜드 시작을 각각 시험. 12회 폴링 내 mode 3/4 독립 Task가 확인되어야 비율 적용. 실화면 양쪽에 선택한 서로 다른 앱, 요청 20:80의 실제 bounds ±4% 확인. 기존 DriveAlerts가 두 번째 칸이면 FAIL.
- DA-016: 미디어 앱 강제 종료 후(운행 전) 시동. `MEDIA_EXISTING_OR_BROWSER → MEDIA_COLD_ADB_LAUNCH → MEDIA_COLD_RETRY → MEDIA_COLD_HOME` 중 실제 통과 단계와 isPlaying 확인. `MEDIA_COLD_RETRY_EXHAUSTED`면 FAIL. 자동 브라우저 재생 성공이면 UI 없이 종료.
- DA-003/005: 순정에서 ECO→NORMAL→SPORT→ECO 순서 실제 전환. NORMAL 1회 정확 발화, ECO/SPORT 혼동 0회를 실차 청취+로그 동시 확인 전 FAIL.
- DA-007: 일반 BSD 경고 기존 즉시 ON 동작은 보존. 깜빡이만 ON + 실제 BSD 위험 미활성이면 음성 없어야 함. 반대로 위험 활성 + 한쪽 지시등 실제 활성 때 공통 경고 1회, 비상등 때는 추가 경고 없어야 함. 현재 readback null이면 FAIL(오보 방지).

## 정적/로컬 및 CI/실차 구분
- `tools/verify_v01718_reference_recovery.py`: **production Kotlin** `LegacySplitTaskLocator.kt` + `SplitGeometry.kt` 실제 JVM 컴파일/테스트. 사용자 차량의 Android TaskManager 실행이 아님.
- 기존 0.17.13~17 통합 검증 중 이전 함수명만 검사하던 세 곳은 새 생산 코드의 엄격한 비율 검사로 계약을 갱신. 매핑/안전 음성 기능 내용은 변경 없음.
- CI에서 `:app:compileDebugKotlin`, `:app:assembleDebug`, `apksigner verify`를 통과해야 설치 APK. 실차 설치 검증 이전 `REALCAR_REVERIFY_REQUIRED`.

## 원복
기존 v0.17.17 소스 ZIP은 그대로 보존. 업데이트 전에 기존 설치 APK와 디버그 서명키 일치 확인. 문제 발생 시 단순 앱 삭제보다 기존 서명으로 빌드한 마지막 정상 APK로 복원하고 기존 사용자 설정/로그를 백업. 차량 ECU/계기판/ADAS 송신을 변경하지 않음.
