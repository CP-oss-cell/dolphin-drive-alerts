# Dolphin Drive Alerts v0.17.20 — 1회 설치 오디오 통합 실험실 GitHub 수동 빌드

- 패키지: `com.byd.dolphin.drivealerts`
- versionCode: `46`; versionName: `0.17.20-nav-audio-lab`
- 기존 기준: v0.17.19 전체 소스; 기존 다른 기능 보존.
- 실행 목표: 순정 TMAP/5종 내비 음성 시점의 read-only 오디오 정책 수집 → Route 5/6 자체 음성 즉시 비교 → 실차 청취 입력 → 앱별 패키지 UID 비교 → ZIP 내보내기.

## GitHub에서 빌드

1. GitHub `CP-oss-cell/dolphin-drive-alerts` 저장소 root에 `DolphinDriveAlerts-v0.17.20-NAV-AUDIO-LAB-source.zip` 하나를 올립니다. 풀어서 여러 파일을 root에 흩뿌리지 않습니다.
2. `.github/workflows/build-v01720-from-source-zip.yml` 경로에 해당 YML을 올립니다.
3. GitHub → Actions → `Build Dolphin Drive Alerts v0.17.20 One-Install Nav Audio Lab APK` → `Run workflow`.
4. `verify_v01720_nav_audio_lab.py` 및 기존 회귀, Kotlin 컴파일, 60개 음성 리소스, `:app:compileDebugKotlin`, `:app:assembleDebug`, `apksigner verify` 통과 후 APK artifact를 받습니다.
5. 출력: `DolphinDriveAlerts-v0.17.20-NAV-AUDIO-LAB.apk`. 이전 앱과 서명키가 다르면 업데이트가 거절될 수 있습니다. 기존 설치/설정 백업을 먼저 준비하고 필요하면 기존 디버그 서명과 동일한 GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64`를 사용합니다.

## 차량 한 번 설치 후 반복 조작

1. 차량 안전하게 정차 P, 기존 설정·정상 기능 확인. 앱 실행 → `오디오 라우팅 실험실`.
2. 첫 화면에서 차량 ADB 연결/RSA 승인. **ADAS/AVAS 쓰기 권한 필요 없음**.
3. `순정 내비 15초 자동 스캔` 누르고 즉시 순정 내비 길안내 음성을 재생. 백그라운드 서비스가 3/8/15초 순정 오디오 정책을 자동 수집.
4. Route 5, Route 6 및 MEDIA를 선택해 본 앱의 짧은 톤을 재생. 실제 들린 위치(운전석/전체/무음)를 버튼으로 기록.
5. TMAP·네이버지도·카카오맵·아틀란3D·MCon K 가운데 선택 후 `선택한 내비 실행 + 자동 스캔`, 앱 길안내 음성을 실제 재생.
6. 다시 실험실로 돌아와 `최근 캡처 비교`, 필요하면 후보 변경 및 재시도, `ZIP 저장`으로 파일 생성.
7. `시험 종료`하면 자체 test AudioTrack 해제. 소스에서 시스템 mixer·AudioPolicy/ECU 값을 변경하지 않으므로 글로벌 원복 조작은 없음. 실차에서 UI가 이상하면 앱 종료 후 기본 순정 내비를 사용합니다.

## 정상·실패 판정

- **자체 경로 성공:** 녹음/샘플 재생 요청 결과 + 실제 사용자 청취 위치 일치. 오래된 v30.5 성공이 v0.17.20을 자동 검증하지 않음.
- **스캔 성공:** ADB 각 명령 exit=0 및 UID/AudioTrack 내용 존재, 안내음 순간 타임스탬프 일치. 단순 폴더 존재는 불충분. 명령 실패가 있으면 `PARTIAL_FAILED_COMMANDS.txt`로 표시되어 비교 성공으로 채택하지 않습니다.
- **5종 내비 UID 라우팅:** `CROSS_UID_ROUTING_BLOCKED_*` 또는 `CROSS_UID_ROUTING_NOT_IMPLEMENTED_*`는 미구현 판정이며 성공 아님. 앱 소리(stream14) 재생이 타 앱의 음성 출력 변경을 의미하지 않음.
- **차량 외부 AVAS:** 실험실은 내부 NAV 경로 전용. 외부 스피커 WAV/MCU 쓰기 기능 없음.
- **Android CI / 실차:** 소스 로컬 정적 검사 통과 ≠ APK 컴파일 성공 ≠ 실차 기능 성공.

## 오류 로그

APK Actions 빌드 실패면 Artifact `DolphinDriveAlerts-v0.17.20-build-failure-log`를 확인. 차량에서는 실험실의 `ZIP 저장` 기능으로 캡처의 명령 종료값/원문과 사용자 청취 결과 함께 내보내기.
