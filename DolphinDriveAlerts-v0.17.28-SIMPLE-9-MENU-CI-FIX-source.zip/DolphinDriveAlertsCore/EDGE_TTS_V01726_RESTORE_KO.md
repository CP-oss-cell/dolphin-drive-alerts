# v0.17.26 — Edge Neural 남녀 60개 필수 빌드

- 기준 소스: v0.17.25, 차량 주행·BSD·분할 관련 코드 변경 없음.
- 버전: `versionCode=52`, `versionName=0.17.26-edge-neural-voice-restore`.
- 정상 남성: `ko-KR-InJoonNeural`, 정상 여성: `ko-KR-SunHiNeural`, 각 30개, 총 60개 WAV.
- 빌드 Edge 라이브러리: `edge-tts==7.3.1` (2026-10-13 출시, 7.2.8 403 변경 대응).
- GitHub Actions의 `refresh_voice_assets=false`면 검증된 Edge 캐시가 있을 때 재활용하고, 없으면 새로 생성. `true`면 60개 Edge 새로 생성.
- **배포 제한:** 검증된 남녀 WAV 60개 없으면 빌드 실패. gTTS 변조 음성이나 효과음 전용 APK로 대체하지 않음.
- APK 생성 후 `assets/voice/male/` 30개, `assets/voice/female/` 30개, `assets/voice/voice_pack_manifest.generated.json`의 모든 SHA-256을 실제 APK 내부에서 재검증.
- 데이터 보존: 앱 패키지명 유지, versionCode 증가, **현재 설치된 APK와 동일한 개인 서명키** 요구. 기존 앱은 삭제하지 말 것. 필요한 Secrets/Variables: `DOLPHIN_DEBUG_KEYSTORE_B64`, `DOLPHIN_INSTALLED_CERT_SHA256`.
- Edge 서버에 실제 연결하는 단계는 GitHub Actions에서 수행. 여기서는 인터넷 연결이 제한돼 Edge 합성 60개 결과를 검증하지 못함.
- 빌드 성공과 실차 음성 청취 성공은 별개이며 실차 검증 필요.
