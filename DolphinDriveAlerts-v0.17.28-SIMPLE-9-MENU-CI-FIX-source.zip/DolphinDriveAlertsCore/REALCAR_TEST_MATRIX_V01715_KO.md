# v0.17.15 실차 2602 검증표

| 테스트 | 준비/조작 | 앱 내부 증거 | 성공 조건 | 현재 상태 |
|---|---|---|---|---|
| BSD-01 | BSD 위험 실제 감지 후 좌측 깜빡이 | `BSD_GATE_ACCEPTED`, `TurnSignalReadback` getter값 | 일반 음성 1회 | NOT_YET_TESTED |
| BSD-02 | BSD 위험 실제 감지 후 우측 깜빡이 | 위와 동일 | 일반 음성 1회 | NOT_YET_TESTED |
| BSD-03 | BSD만 감지/깜빡이 없음 | 상시 모드 OFF | 발화 없음 | NOT_YET_TESTED |
| BSD-04 | BSD + 비상등 양쪽 | 동시에 좌1 우1 | 깜빡이 게이트 발화 없음 | NOT_YET_TESTED |
| BSD-05 | BSD + 상시 모드 ON, 이후 깜빡이 | alert per-risk latch | 중복 재발화 없음 | NOT_YET_TESTED |
| BSD-06 | turn sound 1/2/3 vs 실차 좌우/비상등 ON/OFF | `TURN_SOUND_CORRELATION_ONLY` | 후보값 식별, 발화 트리거 자동 승격 금지 | CANDIDATE |
| MODE-01 | ECO→NORMAL→SPORT→ECO 실제 버튼 | `REFERENCE_OPERATION_MODE` readback 포함 | 각 모드 정확한 한 번 안내 | NORMAL_UNVERIFIED |
| SPLIT-01 | A앱+B앱, 20:80 등 요청 | `SPLIT_REQUEST/START_*/TASK_DUMPSYS` | 다른 taskId 두 개·모드 3/4·실제 비율 | NOT_YET_TESTED |
| SPLIT-02 | OEM 360/다른 앱 진입 후 복귀 | split recovery 증거 | 두 앱·비율 복구 | NOT_YET_TESTED |
| ADB-01 | 첫 설치 승인 창 요청, 시동 후 재연결 | AUTH/READY/PORT_CLOSED 등 | READY 기록, 쉘 ID 조회 성공 | NOT_YET_TESTED |
| LOG-01 | 30분 이상 로그 종료/공유 | session appVersion, ZIP CRC/EOCD | 전송받은 ZIP도 정상 열림 | NOT_YET_TESTED |
| LOG-02 | 센서/계기판 이벤트 과다 발생 | `HIGH_RATE_UNCHANGED_COLLAPSED`, nested array | 변화 이벤트 보존, 유효 원소값 | NOT_YET_TESTED |
| AUDIO-01 | 순정 내비·타사 내비·AVAS 각각 독립 테스트 | 오디오 정책/UID/물리 버스 동시 | 실제 스피커 출력만 성공 판정 | NOT_PROVEN |

안전: 실차 주행 시험은 동승자 또는 정차된 환경에서 자료 수집·사용자 인터랙션 수행. 차선이탈 유발·후측방 위험 유발 시험을 위해 고의로 위험 상황 만들지 말 것. 기존 순정 경고·ECU/AVAS 제어 기능 변경 금지.
