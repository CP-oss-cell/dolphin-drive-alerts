# v0.17.25 — 삭제 없는 업데이트 / 영구 서명키 빌드 안내

## 핵심
기존 설치 APK와 신규 APK가 (1) `applicationId=com.byd.dolphin.drivealerts`, (2) 동일 **서명 인증서**, (3) 새 `versionCode >=` 기존 버전일 때 삭제 없이 APK 덮어 설치가 가능합니다. 앱 내부 SharedPreferences/DB/files는 정상적인 업데이트로 유지됩니다. 단, 앱 내부 코드가 기록을 삭제/마이그레이션하면 별개 문제입니다.

v0.17.24 작업흐름은 `DOLPHIN_DEBUG_KEYSTORE_B64` GitHub Secret이 없으면 임시 GitHub runner의 디버그 서명키로 계속 빌드했습니다. 이번 v0.17.25에서는 이를 **빌드 즉시 실패**하도록 변경합니다. 기존 앱이 사용하던 비밀키 없이는 기존 설치 앱의 정상 업데이트가 불가능합니다.

## 반드시 먼저 할 일 — 앱 삭제하지 말 것
1. 현재 설치된 APK의 **서명 인증서 SHA-256** 을 확인하세요. 이전에 설치한 정확한 원본 APK를 가지고 있으면 Android SDK `apksigner verify --print-certs 기존앱.apk` 명령으로 확인할 수 있습니다. 차량에서 허가된 ADB가 가능하다면 `adb shell pm path com.byd.dolphin.drivealerts` 로 설치 경로를 확인하고 APK를 추출할 수도 있습니다. 권한이 거부되면 우회하지 마세요.
2. **해당 APK를 만든 기존 서명키 파일(debug.keystore)** 이 보관되어 있는지 확인하세요. GitHub Actions가 예전에 자동 생성하고 저장하지 않은 서명키는 APK에서 복원할 수 없습니다. Secret이 이미 설정돼 있고 당시에도 그 키로 빌드했다면 사용 가능합니다.
3. 일치하는 `debug.keystore`가 있을 때만 해당 파일의 base64 전체 내용을 저장소 `Settings → Secrets and variables → Actions → Secrets`에서 `DOLPHIN_DEBUG_KEYSTORE_B64`로 등록하세요. `debug.keystore`를 ZIP/저장소/대화방에 업로드하지 마세요. PC PowerShell 예제: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('C:\path\debug.keystore')) | Set-Clipboard` 후 Secret 칸에 붙여넣기. 개인키를 PC에도 별도 백업하세요.
4. 인증서 SHA-256을 `Settings → Secrets and variables → Actions → Variables`의 `DOLPHIN_INSTALLED_CERT_SHA256`에 입력하세요. 인증서 **지문**은 비밀키가 아니므로 Variable로 보관합니다.
5. v0.17.25 소스 ZIP과 YML을 GitHub에 업로드하고 수동 실행하세요. 서명키/지문 누락 또는 불일치 시 **APK를 만들지 않습니다.** 기존 데이터 보호를 위한 장치입니다.

## GitHub Actions 배치
- 저장소 루트: `DolphinDriveAlerts-v0.17.25-SIGNED-INPLACE-UPDATE-source.zip`
- `.github/workflows/build-v01725-signed-update.yml`
- Actions에서 **Build Dolphin Drive Alerts v0.17.25 Signed In-place Update APK** → Run workflow
- 결과 APK 이름: `DolphinDriveAlerts-v0.17.25-SIGNED-UPDATE.apk` (`versionCode 51`)
- 기본 음성 설정 `effects_only`이며 v0.17.24의 NORMAL/BSD/분할 실험 코드 자체는 변경하지 않았습니다.

## 설치
- 기존 앱 제거하지 말고, 먼저 데이터를 내보내기/백업하세요.
- APK를 실행하고 '업데이트/설치'를 선택하세요. 서명/패키지/버전이 맞으면 기존 데이터가 남습니다.
- ADB 접근 가능할 때는 `adb install -r DolphinDriveAlerts-v0.17.25-SIGNED-UPDATE.apk`로 기존 데이터 유지 설치를 시도할 수 있습니다. `INSTALL_FAILED_UPDATE_INCOMPATIBLE` 은 서명 불일치, `INSTALL_FAILED_VERSION_DOWNGRADE` 는 버전 문제입니다. 실패하더라도 `adb uninstall` 하지 마세요.
- 기존 설치 버전이 `versionCode > 51`이면 새 빌드의 versionCode부터 높여야 합니다.

## 정확한 한계
- GitHub의 임시 runner에서 이전에 만든 디버그 개인키가 별도로 저장되지 않았다면, **기존 앱 위에 즉시 업데이트해 주는 파일을 지금 만들 수 없습니다.** 이는 Android 서명 검증 규칙입니다. 새 고정 키로 서명하면 **그 이후** 업데이트는 가능하지만, 첫 전환에는 안전한 백업/데이터 이전이 필요할 수 있습니다.
- 이 작업은 Android 컴파일/실차/기존 설치 APK 서명지문을 확인하지 못했습니다. 기존 데이터가 실제로 보존됐다는 실차 보장은 하지 않습니다.
