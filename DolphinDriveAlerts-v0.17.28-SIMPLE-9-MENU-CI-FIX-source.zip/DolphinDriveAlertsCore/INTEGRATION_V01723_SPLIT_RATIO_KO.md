# DA-027 — v0.17.23 실차 2앱 정상, 비율 조정 실패 수정 후보

## 실차 상태(사용자 최신 보고, 2026-10-14)
- **USER_REPORTED_REALCAR_PARTIAL_SUCCESS:** 예전에는 두 번째 분할창에 Dolphin Drive가 남았으나 이제 앱 두 개가 실제로 실행됨. 앱 선택/작업 이동 로직은 절대 회귀시키지 않음.
- **USER_REPORTED_REALCAR_FAIL:** 20:80 등 프로필 비율이 실제 적용되지 않고 50:50으로 유지됨. 기능 완료/성공 표기 금지.

## 코드 분석과 실제 수정
1. v0.17.22 `SplitGeometry.parse()`는 `am stack list`로 얻은 bounds가 있어도 동일 블록 안의 `mActivityType=standard`와 모드 3/4가 함께 나와야 성공하는 과도한 조건. AOSP `am stack list`와 `dumpsys activity activities`는 서로 다른 필드 출력 가능. **각각의 스택 ID를 공통 키로 두 조회 결과를 결합**하고 mode3/4가 각각 1개임을 검증.
2. 실제 stack bounds가 아닌 Task/Activity 내부 bounds를 채택하지 않으며 겹침/불일치/동일창이면 아무 명령도 보내지 않음. 왼쪽/오른쪽, 위/아래 primary docked 위치 및 분할자 너비 제외 비율 계산.
3. 기존 UI 10~90 선택을 ADB command에서 20~80으로 자동 제한하는 누락을 바로잡아 **요청값 그대로** 실험. OEM 정책상 극단 비율이 제한되면 readback 차이를 정확히 보고.
4. 승인된 로컬 ADB로 Android 10 legacy `am stack resize-docked-stack`의 8-인수 명령을 먼저 시도하고 검증되지 않을 때 문서화된 4-인수 명령을 한 번 더 시험. 무조건 재시도/ADB RSA 우회/차량 CAN write 없음. 단순 exit0은 성공으로 간주하지 않음.
5. `am stack list`와 `dumpsys activity activities`를 전후로 기록해 실제 비율 확인. 2앱 서로 다른 Task/모드3,4 및 postratio 검사 유지.
6. 설정 화면에서 `비율 다시 적용` 시 **우리 설정 Activity를 먼저 닫고**, 별도 worker로 기존 분할창만 크기 변경. 닫기 전에 ADB 명령을 보내 분할창을 빼앗는 위험 완화.

## 기존 참조 근거
- 실차 정상 `BydAutoSplit_1.2.0-release(1).apk`: `SplitRatioController.apply/verify/parsePair`, `LocalAdbShell.executeSync`, `am stack list`, `resize-docked-stack` 경로가 DEX 정적 분석으로 확인됨. 원본 전체 제어경로를 완전 역컴파일했다는 주장은 하지 않음.
- Assistant v30 `SplitGhostActivity` 및 Task 이동 성공 경로 보존.
- Android 10 AOSP 명령 구현 참조: https://android.googlesource.com/platform/frameworks/base/+/9b490a16d9fcafff406f73c5fa64ed296402a9e9/services/core/java/com/android/server/am/ActivityManagerShellCommand.java

## 검증 범위
- **CODE_CHANGED:** `SplitGeometry.kt`, `VehicleSplitEngine.kt`, `SplitProfilesActivity.kt` 수정. `FeatureProfiles` 설정/2앱 Task 실행 로직 불변.
- **LOCAL_KOTLIN_PASS:** `tools/verify_v01723_split_ratio.py`에 실 Kotlin 구조 테스트와 source guards. 과거 레거시 20:80/80:20 회귀 fixture 통과.
- **ANDROID_FULL_GRADLE_PENDING / REALCAR_RATIO_REVERIFY_REQUIRED:** 기존 정상 2앱 실행 보존과 수정 실차 성공은 별개. OEM이 resize 명령을 무시할 경우 로그에서 실제 상태/오류를 확인할 수 있도록 함.
