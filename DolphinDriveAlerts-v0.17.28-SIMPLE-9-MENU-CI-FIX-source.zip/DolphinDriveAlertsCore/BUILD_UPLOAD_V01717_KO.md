# Dolphin Drive Alerts v0.17.17 — GitHub 업로드 및 빌드

1. [CP-oss-cell/dolphin-drive-alerts](https://github.com/CP-oss-cell/dolphin-drive-alerts) 저장소 루트에 `DolphinDriveAlerts-v0.17.17-SPLIT-TASK-CI-FIX-source.zip` 추가.
2. `.github/workflows/build-v01717-from-source-zip.yml`에 제공한 GitHub Actions YML 추가.
3. Actions → `Build Dolphin Drive Alerts v0.17.17 Split Task Readback CI Fix APK` → Run workflow.
4. `Verify actual EQ Kotlin source...` 단계에서 기존 `verify_v01713_policy_kotlin.py`가 통과하는지 확인.
5. **실제 Android 단계** `:app:compileDebugKotlin`, `:app:assembleDebug`, `apksigner verify` 모두 성공 시 Artifact에서 APK 다운로드.
6. 기존 설치 앱과 동일 디버그 서명이 필요. `DOLPHIN_DEBUG_KEYSTORE_B64`가 미설정이면 업데이트 설치 실패할 수 있음.

버전 0.17.17 / versionCode 43. 다른 프로젝트 Dolphin Cluster APK를 이 소스와 혼합하지 마세요. 로컬 소스 시험과 GitHub 실제 Android 컴파일은 별개입니다.
