# Dolphin Drive Alerts v0.17.23 — GitHub 직접 업로드 빌드

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 최상위에 `DolphinDriveAlerts-v0.17.23-SPLIT-RATIO-REALCAR-REPAIR-source.zip` 업로드.
2. `.github/workflows/build-v01723-from-source-zip.yml`에 함께 제공된 YML 업로드.
3. Actions → `Build Dolphin Drive Alerts v0.17.23 Split Ratio Readback Repair APK` → Run workflow.
4. `voice_mode=effects_only` 기본값을 사용하면 성별 음성이 아닌 효과음 시험 빌드입니다. **원래 남녀 Neural 음성에는 검증된 음성팩이 필요**하며, `neural_only`는 팩이 없고 Edge TTS가 막히면 실패할 수 있습니다.
5. APK Artifact를 내려받아 정차 상태에서 20:80/70:30을 확인하고, 실패하면 통합 로그 ZIP을 제출.

**실차 보고:** v0.17.22에서 2앱 실행 정상, 비율 미적용. 수정 결과는 사용자 새 버전 실차 검증 전까지 미확정.
**로컬:** 분할 Kotlin fixture PASS, 기존 참조 테스트 PASS, Android 전체 CI/실차 미실행.
**보존:** NORMAL, BSD, TTS 정책, NAV5 오디오 실험실, 분할 기존 2앱 실행, 시동·EQ 등.
