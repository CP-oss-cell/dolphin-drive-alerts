# GitHub v0.17.15 수동 APK 빌드

1. `CP-oss-cell/dolphin-drive-alerts` 저장소 루트에 `DolphinDriveAlerts-v0.17.15-REALCAR-EVIDENCE-REPAIR-source.zip` 업로드(삭제/이전 ZIP 덮어쓰기 금지).
2. `.github/workflows/build-v01715-from-source-zip.yml` 업로드.
3. GitHub → Actions → `Build Dolphin Drive Alerts v0.17.15 Realcar Evidence Repair APK` → `Run workflow`.
4. `:app:compileDebugKotlin` / `:app:assembleDebug` 성공 후 `DolphinDriveAlerts-v0.17.15-REALCAR-EVIDENCE-REPAIR` Artifact 다운로드. APK 서명/패키지/versionCode 확인.
5. 기존 실차 앱과 서명 인증서가 동일해야 업데이트 설치 가능. 설치 실패 시 서명 해시를 먼저 비교하고 차량 데이터 무단 초기화/기존 검증앱 제거 금지.
6. 2602 차량에서 먼저 **정차 상태**로 ADB와 2분할 검사, 자연 발생 BSD/모드/계기판 안전 알림 로그를 동승자가 수집. 주행 안전 위험을 유발하지 말 것.

결과 파일을 이 대화에 올려 주면 GitHub 컴파일 로그 및 실제 차량 로그를 대조해 다음 빌드를 수정합니다. GitHub 연결은 READ-ONLY라 이 채팅에서 직접 push/Actions 실행하지 못함.

**주의:** v0.17.15는 증거 품질·태스크 검증·안전 실패진단 개선판. NORMAL 발화 및 좌우 BSD 감지, 2분할 실차 해결을 보증하지 않음. 외부 AVAS 출력 기능 신규 구현 없음.
