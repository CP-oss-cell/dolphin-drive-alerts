package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/**
 * v0.17.53 Automotive Cockpit Design System for BYD Dolphin 10.1" (1280x720, DPI 160).
 * Supports Dark (default night cockpit) and Light (high-contrast daylight) modes,
 * custom vector icons, tactile ripple feedback, and clean panel cards across all activities.
 */
object DashboardUi {
    private const val THEME_PREFS = "dolphin_ui_theme"
    private const val KEY_LIGHT_MODE = "light_mode"
    private const val KEY_THEME_MODE = "theme_mode_v01761" // 0=다크, 1=라이트, 2=자동(07~19시 라이트)

    // Legacy constants kept for full backward compatibility
    const val BACKGROUND = 0xFF090F1A.toInt()
    const val PANEL = 0xFF131E30.toInt()
    const val PANEL_ALT = 0xFF1C2C44.toInt()
    const val TEXT = 0xFFF1F6FC.toInt()
    const val MUTED = 0xFF9BB0C9.toInt()
    const val ACCENT = 0xFF38D9E6.toInt()

    fun themeMode(context: Context): Int {
        val sp = context.getSharedPreferences(THEME_PREFS, Context.MODE_PRIVATE)
        if (!sp.contains(KEY_THEME_MODE)) {
            return if (sp.getBoolean(KEY_LIGHT_MODE, false)) 1 else 0
        }
        return sp.getInt(KEY_THEME_MODE, 0).coerceIn(0, 2)
    }

    fun setThemeMode(context: Context, mode: Int) {
        val m = mode.coerceIn(0, 2)
        context.getSharedPreferences(THEME_PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY_THEME_MODE, m).putBoolean(KEY_LIGHT_MODE, m == 1).apply()
    }

    fun isLightMode(context: Context): Boolean = when (themeMode(context)) {
        1 -> true
        2 -> {
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            hour in 7..18
        }
        else -> false
    }

    fun setLightMode(context: Context, light: Boolean) = setThemeMode(context, if (light) 1 else 0)

    fun bgColor(c: Context): Int = if (isLightMode(c)) 0xFFF1F5FA.toInt() else 0xFF090F1A.toInt()
    fun headerColor(c: Context): Int = if (isLightMode(c)) 0xFFFFFFFF.toInt() else 0xFF0D1626.toInt()
    fun surfaceColor(c: Context): Int = if (isLightMode(c)) 0xFFFFFFFF.toInt() else 0xFF131E30.toInt()
    fun surfaceAltColor(c: Context): Int = if (isLightMode(c)) 0xFFE8EFF7.toInt() else 0xFF1C2C44.toInt()
    fun borderColor(c: Context): Int = if (isLightMode(c)) 0xFFD0DCEB.toInt() else 0xFF253A57.toInt()
    fun textColor(c: Context): Int = if (isLightMode(c)) 0xFF0F1B2D.toInt() else 0xFFF1F6FC.toInt()
    fun mutedColor(c: Context): Int = if (isLightMode(c)) 0xFF52657D.toInt() else 0xFF9BB0C9.toInt()
    fun accentColor(c: Context): Int = if (isLightMode(c)) 0xFF00869B.toInt() else 0xFF38D9E6.toInt()
    fun okColor(c: Context): Int = if (isLightMode(c)) 0xFF0D9F6E.toInt() else 0xFF2EE59D.toInt()
    fun warnColor(c: Context): Int = if (isLightMode(c)) 0xFFC97A00.toInt() else 0xFFFFB84D.toInt()
    fun dangerColor(c: Context): Int = if (isLightMode(c)) 0xFFD93838.toInt() else 0xFFFF6B6B.toInt()
    fun rippleColor(c: Context): Int = if (isLightMode(c)) 0x2200869B else 0x3338D9E6

    fun alphaColor(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun dp(a: Context, n: Int): Int = (a.resources.displayMetrics.density * n + .5f).toInt()

    fun bg(a: Activity, color: Int = surfaceColor(a), radius: Int = 14): GradientDrawable =
        cardBg(a, color, borderColor(a), radius)

    fun cardBg(c: Context, fill: Int, stroke: Int = 0, radiusDp: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(c, radiusDp).toFloat()
            if (stroke != 0) setStroke(dp(c, 1).coerceAtLeast(1), stroke)
        }

    fun interactiveBg(c: Context, fill: Int, stroke: Int = borderColor(c), radiusDp: Int = 12): Drawable {
        val content = cardBg(c, fill, stroke, radiusDp)
        val mask = cardBg(c, Color.WHITE, 0, radiusDp)
        return RippleDrawable(ColorStateList.valueOf(rippleColor(c)), content, mask)
    }

    fun applyWindowChrome(a: Activity) {
        if (a.isFinishing || a.isDestroyed) return
        val bg = headerColor(a)
        a.window.statusBarColor = bg
        a.window.navigationBarColor = bgColor(a)
        @Suppress("DEPRECATION")
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            val decor = a.window.decorView
            val flags = decor.systemUiVisibility
            decor.systemUiVisibility = if (isLightMode(a)) {
                flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            } else {
                flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
        }
    }

    fun label(a: Activity, text: String, size: Float = 15f, bold: Boolean = false): TextView = TextView(a).apply {
        this.text = text
        this.textSize = size
        setTextColor(if (bold) textColor(a) else mutedColor(a))
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(a, 4), dp(a, 5), dp(a, 4), dp(a, 5))
    }

    fun pill(a: Activity, text: String, tint: Int): TextView = TextView(a).apply {
        this.text = text
        this.textSize = 11.5f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(tint)
        background = cardBg(a, alphaColor(tint, if (isLightMode(a)) 26 else 36), alphaColor(tint, 90), 99)
        setPadding(dp(a, 10), dp(a, 4), dp(a, 10), dp(a, 4))
        gravity = Gravity.CENTER
    }

    fun panel(
        a: Activity,
        title: String,
        description: String,
        icon: DashboardIcons.IconKind?,
        accent: Int = accentColor(a),
        build: (LinearLayout) -> Unit
    ): LinearLayout {
        return LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg(a, surfaceColor(a), borderColor(a), 16)
            setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14))
            val headerRow = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            if (icon != null) {
                val badge = DashboardIcons.badge(
                    a, icon, accent,
                    alphaColor(accent, if (isLightMode(a)) 26 else 36),
                    alphaColor(accent, 85),
                    boxDp = 36, iconDp = 19, radiusDp = 10
                )
                headerRow.addView(badge, LinearLayout.LayoutParams(dp(a, 36), dp(a, 36)).apply {
                    setMargins(0, 0, dp(a, 10), 0)
                })
            }
            val titleCol = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            titleCol.addView(label(a, title, 17f, true).apply { setPadding(0, 0, 0, dp(a, 2)) })
            if (description.isNotBlank()) {
                titleCol.addView(label(a, description, 12.5f).apply { setPadding(0, 0, 0, 0) })
            }
            headerRow.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
            addView(headerRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(a, 8)) })
            build(this)
        }
    }

    /** Overload preserving exact 3-arg/4-arg call compatibility. */
    fun panel(a: Activity, title: String, description: String = "", build: (LinearLayout) -> Unit): LinearLayout =
        panel(a, title, description, null, accentColor(a), build)

    fun action(
        a: Activity,
        text: String,
        icon: DashboardIcons.IconKind?,
        tint: Int = accentColor(a),
        onClick: () -> Unit
    ): Button = Button(a).apply {
        this.text = text
        isAllCaps = false
        textSize = 14.5f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(textColor(a))
        gravity = Gravity.CENTER_VERTICAL or if (icon != null) Gravity.START else Gravity.CENTER
        background = interactiveBg(a, surfaceAltColor(a), borderColor(a), 12)
        minHeight = dp(a, 48)
        setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10))
        if (icon != null) {
            val d = DashboardIcons.drawable(a, icon, tint, 20, 2.0f)
            setCompoundDrawablesWithIntrinsicBounds(d, null, null, null)
            compoundDrawablePadding = dp(a, 10)
        }
        setOnClickListener { onClick() }
    }

    /** Overload preserving exact 3-arg call compatibility. */
    fun action(a: Activity, text: String, onClick: () -> Unit): Button =
        action(a, text, null, accentColor(a), onClick)

    fun actionRow(
        a: Activity,
        title: String,
        subtitle: String = "",
        icon: DashboardIcons.IconKind,
        accent: Int = accentColor(a),
        badgeText: String = "",
        onClick: () -> Unit
    ): LinearLayout {
        return LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            background = interactiveBg(a, surfaceAltColor(a), borderColor(a), 12)
            setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
            minimumHeight = dp(a, 56)
            addView(
                DashboardIcons.badge(
                    a, icon, accent,
                    alphaColor(accent, if (isLightMode(a)) 24 else 32),
                    alphaColor(accent, 80),
                    boxDp = 38, iconDp = 20, radiusDp = 10
                ),
                LinearLayout.LayoutParams(dp(a, 38), dp(a, 38)).apply { setMargins(0, 0, dp(a, 12), 0) }
            )
            val copy = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            copy.addView(TextView(a).apply {
                text = title; textSize = 15f; setTypeface(typeface, Typeface.BOLD); setTextColor(textColor(a))
            })
            if (subtitle.isNotBlank()) {
                copy.addView(TextView(a).apply {
                    text = subtitle; textSize = 12f; setTextColor(mutedColor(a))
                    setPadding(0, dp(a, 2), 0, 0)
                })
            }
            addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            if (badgeText.isNotBlank()) {
                addView(pill(a, badgeText, accent), LinearLayout.LayoutParams(-2, -2).apply {
                    setMargins(dp(a, 6), 0, dp(a, 6), 0)
                })
            }
            addView(ImageView(a).apply {
                setImageDrawable(DashboardIcons.drawable(a, DashboardIcons.IconKind.CHEVRON_RIGHT, mutedColor(a), 18, 2.2f))
            }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
            setOnClickListener { onClick() }
        }
    }

    fun segmentedBar(
        a: Activity,
        options: List<String>,
        selectedIndex: Int,
        accent: Int = accentColor(a),
        onSelect: (Int) -> Unit
    ): LinearLayout {
        val bar = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            background = cardBg(a, bgColor(a), borderColor(a), 12)
            setPadding(dp(a, 4), dp(a, 4), dp(a, 4), dp(a, 4))
        }
        val buttons = mutableListOf<TextView>()
        fun paint(active: Int) {
            buttons.forEachIndexed { idx, tv ->
                val isSelected = idx == active
                tv.background = if (isSelected) {
                    cardBg(a, accent, 0, 9)
                } else {
                    cardBg(a, Color.TRANSPARENT, 0, 9)
                }
                tv.setTextColor(
                    if (isSelected) (if (isLightMode(a)) Color.WHITE else 0xFF06131C.toInt())
                    else mutedColor(a)
                )
                tv.setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
            }
        }
        options.forEachIndexed { idx, label ->
            val tv = TextView(a).apply {
                text = label
                textSize = 13.5f
                gravity = Gravity.CENTER
                minHeight = dp(a, 42)
                setPadding(dp(a, 6), dp(a, 8), dp(a, 6), dp(a, 8))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    paint(idx)
                    onSelect(idx)
                }
            }
            buttons.add(tv)
            bar.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(a, 2), 0, dp(a, 2), 0) })
        }
        paint(selectedIndex.coerceIn(0, (options.size - 1).coerceAtLeast(0)))
        return bar
    }

    fun spacing(a: Activity, heightDp: Int = 10) = View(a).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(a, heightDp))
    }

    fun addPanel(parent: LinearLayout, a: Activity, panel: View) {
        parent.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(a, 12)) })
    }

    fun toggle(a: Activity, text: String, initial: Boolean, onChange: (Boolean) -> Unit): Switch = Switch(a).apply {
        this.text = text
        isChecked = initial
        setTextColor(textColor(a))
        textSize = 15f
        minHeight = dp(a, 48)
        setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    fun themeToggleButton(a: Activity, onToggled: (() -> Unit)? = null): View {
        val mode = themeMode(a)
        val light = isLightMode(a)
        val iconKind = if (light) DashboardIcons.IconKind.SUN else DashboardIcons.IconKind.MOON
        val tint = if (light) 0xFFD97706.toInt() else 0xFFFFD166.toInt()
        val label = when (mode) { 1 -> "라이트"; 2 -> "자동"; else -> "다크" }
        return LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = interactiveBg(a, surfaceAltColor(a), borderColor(a), 12)
            setPadding(dp(a, 12), dp(a, 8), dp(a, 12), dp(a, 8))
            minimumHeight = dp(a, 44)
            addView(ImageView(a).apply {
                setImageDrawable(DashboardIcons.drawable(a, iconKind, tint, 18, 2.0f))
            }, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)).apply { setMargins(0, 0, dp(a, 6), 0) })
            addView(TextView(a).apply {
                text = label
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(textColor(a))
            })
            setOnClickListener {
                setThemeMode(a, (mode + 1) % 3)
                if (onToggled != null) onToggled() else a.recreate()
            }
        }
    }

    fun headerBar(
        a: Activity,
        title: String,
        subtitle: String,
        icon: DashboardIcons.IconKind,
        accent: Int = accentColor(a),
        onBack: (() -> Unit)? = null,
        onThemeToggled: (() -> Unit)? = null
    ): LinearLayout {
        return LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(headerColor(a))
            setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 10))
            if (onBack != null) {
                val backBtn = FrameLayout(a).apply {
                    isClickable = true
                    isFocusable = true
                    background = interactiveBg(a, surfaceAltColor(a), borderColor(a), 12)
                    addView(ImageView(a).apply {
                        setImageDrawable(DashboardIcons.drawable(a, DashboardIcons.IconKind.BACK, textColor(a), 22, 2.4f))
                    }, FrameLayout.LayoutParams(dp(a, 22), dp(a, 22), Gravity.CENTER))
                    setOnClickListener { onBack() }
                }
                addView(backBtn, LinearLayout.LayoutParams(dp(a, 46), dp(a, 46)).apply {
                    setMargins(0, 0, dp(a, 12), 0)
                })
            }
            addView(
                DashboardIcons.badge(
                    a, icon, accent,
                    alphaColor(accent, if (isLightMode(a)) 26 else 36),
                    alphaColor(accent, 90),
                    boxDp = 42, iconDp = 22, radiusDp = 12
                ),
                LinearLayout.LayoutParams(dp(a, 42), dp(a, 42)).apply { setMargins(0, 0, dp(a, 12), 0) }
            )
            val copy = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            copy.addView(TextView(a).apply {
                text = title; textSize = 19f; setTypeface(typeface, Typeface.BOLD); setTextColor(textColor(a))
            })
            if (subtitle.isNotBlank()) {
                copy.addView(TextView(a).apply {
                    text = subtitle; textSize = 12f; setTextColor(mutedColor(a))
                })
            }
            addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            addView(themeToggleButton(a, onThemeToggled), LinearLayout.LayoutParams(-2, -2))
        }
    }

    /**
     * Mount sub-activities into the unified cockpit shell with graphic header & theme toggle.
     */

    fun page(
        a: Activity,
        title: String,
        subtitle: String,
        icon: DashboardIcons.IconKind,
        accent: Int,
        onThemeToggled: () -> Unit
    ): LinearLayout {
        applyWindowChrome(a)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor(a))
        }
        root.addView(
            headerBar(a, title, subtitle, icon, accent, onBack = { a.finish() }, onThemeToggled = onThemeToggled),
            LinearLayout.LayoutParams(-1, -2)
        )
        root.addView(
            View(a).apply { setBackgroundColor(borderColor(a)) },
            LinearLayout.LayoutParams(-1, dp(a, 1).coerceAtLeast(1))
        )
        val scroller = ScrollView(a).apply {
            setFillViewport(true)
            setBackgroundColor(bgColor(a))
        }
        val content = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 78), dp(a, 14), dp(a, 78), dp(a, 24))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        a.setContentView(root)
        return content
    }

    fun mount(a: Activity, content: View, title: String, subtitle: String = "") {
        applyWindowChrome(a)
        val shell = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor(a))
        }
        val inferredIcon = DashboardIcons.inferForTitle(title)
        shell.addView(headerBar(a, title, subtitle.ifBlank { "DOLPHIN DRIVE  ·  상세 설정" }, inferredIcon, accentColor(a), onBack = { a.finish() }))
        shell.addView(View(a).apply { setBackgroundColor(borderColor(a)) }, LinearLayout.LayoutParams(-1, dp(a, 1).coerceAtLeast(1)))
        shell.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        a.setContentView(shell)
        content.post {
            if (!a.isFinishing && !a.isDestroyed) {
                sectionize(a, content)
                refresh(a, content)
            }
        }
    }

    /**
     * Group flat sub-activity layouts into bordered cockpit cards without detaching live listeners.
     */
    fun sectionize(a: Activity, content: View) {
        val body = when (content) {
            is ScrollView -> content.getChildAt(0) as? LinearLayout
            is LinearLayout -> content
            else -> null
        } ?: return
        body.setPadding(dp(a, 78), dp(a, 14), dp(a, 78), dp(a, 24))
        val original = (0 until body.childCount).map { body.getChildAt(it) }
        if (original.isEmpty()) return
        if (original.all { it.tag == "DOLPHIN_DASH_PANEL" }) return
        body.removeAllViews()
        var title = "기본 설정"
        var panelBody: LinearLayout? = null
        fun start(name: String) {
            val sectionPanel = panel(a, name, "", DashboardIcons.inferForTitle(name), accentColor(a)) { }
            sectionPanel.tag = "DOLPHIN_DASH_PANEL"
            addPanel(body, a, sectionPanel)
            panelBody = sectionPanel
        }
        original.forEachIndexed { index, child ->
            val t = child as? TextView
            val titleText = t?.text?.toString()?.trim().orEmpty()
            val size = t?.textSize?.div(a.resources.displayMetrics.scaledDensity) ?: 0f
            val profileHeading = titleText.matches(Regex("^[0-9]+\\. \\S.*")) ||
                (titleText.contains(": ") && titleText.contains(" / ") && size >= 16f)
            val isSection = t != null && t !is EditText && t !is Button &&
                (size >= 18f || profileHeading)
            if (index == 0 && isSection) {
                return@forEachIndexed
            }
            if (isSection) {
                title = titleText.take(72)
                start(title)
            } else {
                if (panelBody == null) start(title)
                (child.parent as? ViewGroup)?.removeView(child)
                panelBody?.addView(child)
            }
        }
    }

    /** Restyle dynamically redrawn controls to match current Dark/Light cockpit theme. */
    fun refresh(a: Activity, root: View) {
        val p = root.parent
        if (p is LinearLayout && p.parent is ScrollView) {
            val lp = root.layoutParams as? LinearLayout.LayoutParams
            lp?.setMargins(0, dp(a, 5), 0, dp(a, 5))
        }
        when (root) {
            is Spinner -> return
            is EditText -> {
                root.setTextColor(textColor(a))
                root.setHintTextColor(mutedColor(a))
                root.setPadding(dp(a, 12), dp(a, 12), dp(a, 12), dp(a, 12))
                root.background = cardBg(a, surfaceAltColor(a), borderColor(a), 10)
            }
            is Switch -> {
                root.setTextColor(textColor(a))
                root.textSize = 15f
                root.minHeight = dp(a, 48)
                root.setPadding(dp(a, 12), dp(a, 10), dp(a, 12), dp(a, 10))
                root.background = cardBg(a, surfaceAltColor(a), borderColor(a), 10)
            }
            is CheckBox -> {
                root.setTextColor(textColor(a))
                root.textSize = 14.5f
                root.minHeight = dp(a, 46)
                root.setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8))
                root.background = cardBg(a, surfaceColor(a), 0, 8)
            }
            is RadioButton -> root.setTextColor(textColor(a))
            is Button -> {
                root.isAllCaps = false
                root.setTextColor(textColor(a))
                root.textSize = 14.5f
                root.minHeight = dp(a, 48)
                root.background = interactiveBg(a, surfaceAltColor(a), borderColor(a), 11)
                (root.layoutParams as? LinearLayout.LayoutParams)?.let { lp ->
                    if (lp.topMargin == 0 && lp.bottomMargin == 0) lp.setMargins(lp.leftMargin, dp(a, 4), lp.rightMargin, dp(a, 4))
                }
            }
            is TextView -> {
                if (root.tag != "DOLPHIN_NO_RESTYLE") {
                    val sp = root.textSize / a.resources.displayMetrics.scaledDensity
                    root.setTextColor(if (sp >= 17f) textColor(a) else mutedColor(a))
                    if (sp >= 17f) root.setTypeface(root.typeface, Typeface.BOLD)
                }
            }
            is ScrollView -> root.setBackgroundColor(bgColor(a))
            is LinearLayout -> if (root.parent is ScrollView) root.setBackgroundColor(bgColor(a))
        }
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                val child = root.getChildAt(i)
                if (child.tag != "DOLPHIN_NO_RESTYLE") refresh(a, child)
            }
        }
    }
}
