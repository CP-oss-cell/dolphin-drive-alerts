package com.byd.dolphin.drivealerts.dock

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext
import java.lang.reflect.Method

/**
 * Clean-Room BYDAuto Comfort / HVAC / Seat / Steering / DRL / Defrost Controller (v0.17.82).
 *
 * Real-car verified on BYD Dolphin DiLink 5.0 (autoType=186):
 * - All BYDAuto*.getInstance() calls wrapped with BydPermissionContext.wrap(app).
 * - Temperature: Korean Dolphin range 17°C (LOW) ~ 27°C (HI); auto-detects 2x half-degree
 *   scale (34..54 = 17..27°C) vs 1x scale from getTemprature(1) so setAcTemperature never
 *   clamps down to LOW.
 * - Steering wheel heat: BYDAutoSettingDevice.getSteeringWheelHeatingState() / setSteeringWheelHeatingState(2=ON, 1=OFF).
 * - Driver/Passenger seat heat: BYDAutoSettingDevice.getSeatHeatingState(area) / setSeatHeatingState(area, 1=OFF, 2=LOW, 3=HIGH).
 * - Daytime Running Light (DRL): BYDAutoLightDevice.getDayTimeLightState() / setDayTimeLightState(1=ON, 2=OFF).
 * - Pure Ventilation (After-Blow): setAcVentilationState(1) + setAcControlMode(1, 1) + setAcCompressorMode(1, 0) + OUTLOOP.
 */
class BydComfortController(context: Context) {
    data class ComfortSnapshot(
        val acOn: Boolean = false,
        val acCompressorOn: Boolean = false,
        val heaterOn: Boolean = false,
        val acAuto: Boolean = false,
        val tempC: Float = 22.0f,              // 17.0f = LOW, 27.0f = HI
        val fanLevel: Int = 2,
        val windMode: Int = WIND_FACE,         // 0=FACE, 1=FACE_FOOT, 2=FOOT, 3=DEFROST_FOOT, 4=DEFROST, 5=ALL
        val recirculation: Boolean = false,
        val steeringHeat: Boolean = false,
        val driverSeatHeat: Int = 0,           // 0=OFF, 1=LOW, 2=HIGH
        val passengerSeatHeat: Int = 0,        // 0=OFF, 1=LOW, 2=HIGH
        val rearMirrorDefrost: Boolean = false,
        val frontDefrost: Boolean = false,
        val drlOn: Boolean = true
    )

    private val app = BydPermissionContext.wrap(context.applicationContext)
    @Volatile private var acDev: Any? = null
    @Volatile private var settingDev: Any? = null
    @Volatile private var lightDev: Any? = null
    @Volatile private var bodyDev: Any? = null
    @Volatile private var usesHalfDegreeScale = true // DiLink 5.0 real-car verified: getTemprature(1)=34 -> 17°C
    @Volatile private var snap = ComfortSnapshot()

    private fun getAcDevice(): Any? {
        acDev?.let { return it }
        return resolveDevice("android.hardware.bydauto.ac.BYDAutoAcDevice")?.also { acDev = it }
    }

    private fun getSettingDevice(): Any? {
        settingDev?.let { return it }
        return resolveDevice("android.hardware.bydauto.setting.BYDAutoSettingDevice")?.also { settingDev = it }
    }

    private fun getLightDevice(): Any? {
        lightDev?.let { return it }
        return resolveDevice("android.hardware.bydauto.light.BYDAutoLightDevice")?.also { lightDev = it }
    }

    private fun getBodyDevice(): Any? {
        bodyDev?.let { return it }
        return resolveDevice("android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice")?.also { bodyDev = it }
    }

    private fun resolveDevice(className: String): Any? = runCatching {
        val cls = Class.forName(className)
        cls.getMethod("getInstance", Context::class.java).invoke(null, app)
    }.getOrNull()

    fun refreshSnapshot(): ComfortSnapshot {
        var next = snap
        getAcDevice()?.let { ac ->
            val power = callInt(ac, listOf("getAcStartState", "getAcPowerState"))
            val auto = callInt(ac, listOf("getAcControlMode"))
            val comp = callInt(ac, listOf("getAcCompressorMode"))
            val rawTemp = callInt(ac, listOf("getTemprature", "getTemperature"), 1)
            val parsedTemp: Float? = when {
                rawTemp == null -> null
                rawTemp in 34..66 -> {
                    usesHalfDegreeScale = true
                    (rawTemp / 2.0f).coerceIn(MIN_TEMP_C, MAX_TEMP_C)
                }
                rawTemp in 15..33 -> {
                    usesHalfDegreeScale = false
                    rawTemp.toFloat().coerceIn(MIN_TEMP_C, MAX_TEMP_C)
                }
                else -> null
            }
            val fan = callInt(ac, listOf("getAcWindLevel"))
            val mode = callInt(ac, listOf("getAcWindMode"))
            val cycle = callInt(ac, listOf("getAcCycleMode"))
            val rearDef = callInt(ac, listOf("getAcDefrostState"), 2)
            val frontDef = callInt(ac, listOf("getAcDefrostState"), 1)
            next = next.copy(
                acOn = if (power != null) power == 1 else next.acOn,
                acCompressorOn = if (comp != null) comp == 1 else next.acCompressorOn,
                acAuto = if (auto != null) auto == 0 else next.acAuto,
                tempC = parsedTemp ?: next.tempC,
                fanLevel = if (fan != null && fan in 0..7) fan else next.fanLevel,
                windMode = mapBydWindToLocal(mode) ?: next.windMode,
                recirculation = if (cycle != null) cycle == 1 else next.recirculation,
                rearMirrorDefrost = if (rearDef != null) rearDef == 1 else next.rearMirrorDefrost,
                frontDefrost = if (frontDef != null) frontDef == 1 else next.frontDefrost
            )
        }
        getSettingDevice()?.let { st ->
            val steer = callInt(st, listOf("getSteeringWheelHeatingState"))
            val drv = callInt(st, listOf("getSeatHeatingState"), 1)
            val pas = callInt(st, listOf("getSeatHeatingState"), 2)
            next = next.copy(
                steeringHeat = if (steer != null && steer in 1..2) steer == 2 else next.steeringHeat,
                driverSeatHeat = mapBydSeatToLocal(drv) ?: next.driverSeatHeat,
                passengerSeatHeat = mapBydSeatToLocal(pas) ?: next.passengerSeatHeat
            )
        }
        getLightDevice()?.let { lt ->
            val drl = callInt(lt, listOf("getDayTimeLightState", "getDayRunningLightState"))
            if (drl != null && drl in 1..2) {
                next = next.copy(drlOn = drl == 1)
            }
        }
        snap = next
        return snap
    }

    fun snapshot(): ComfortSnapshot = snap

    fun formatTempLabel(tempC: Float = snap.tempC): String = when {
        tempC <= MIN_TEMP_C -> "LOW"
        tempC >= MAX_TEMP_C -> "HI"
        else -> "${tempC.toInt()}°"
    }

    fun setClimatePowerDirect(on: Boolean) {
        getAcDevice()?.let { ac ->
            if (on) callVoidOrInt(ac, listOf("start", "setAcStartState"), intArrayOf(1))
            else callVoidOrInt(ac, listOf("stop", "setAcStartState"), intArrayOf(0))
        }
        snap = snap.copy(acOn = on)
    }

    fun setAcCompressorDirect(on: Boolean) {
        val st = if (on) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), 1, st) ||
                callIntArgs(ac, listOf("setAcCompressorMode", "setAcCoolState", "setAcCompressorState"), st)
        }
        snap = snap.copy(acCompressorOn = on)
    }

    fun setHeaterDirect(on: Boolean) {
        val st = if (on) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), 1, st) ||
                callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState", "setAcHeatMode"), st)
        }
        snap = snap.copy(heaterOn = on)
    }

    /**
     * Pure fresh-air ventilation for After-Blow:
     * Explicitly forces Manual mode + A/C compressor OFF + Heater OFF + Ventilation ON + OUTLOOP.
     */
    fun startPureVentilation(fanLevel: Int) {
        val clamped = fanLevel.coerceIn(1, 7)
        getAcDevice()?.let { ac ->
            // 1. Ensure blower power is ON
            callVoidOrInt(ac, listOf("start", "setAcStartState"), intArrayOf(1))
            // 2. Switch to MANUAL so AUTO never re-engages A/C or PTC heater
            callIntArgs(ac, listOf("setAcControlMode"), 1, 1) || callIntArgs(ac, listOf("setAcControlMode"), 1)
            // 3. Explicitly turn OFF A/C compressor & heater
            callIntArgs(ac, listOf("setAcCompressorMode"), 1, 0) || callIntArgs(ac, listOf("setAcCompressorMode"), 0)
            callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState"), 1, 0) ||
                callIntArgs(ac, listOf("setAcHeaterState", "setAcWarmState", "setPtcState"), 0)
            // 4. Enable BYD pure ventilation mode (송풍 전용)
            callIntArgs(ac, listOf("setAcVentilationState"), 1, 1) || callIntArgs(ac, listOf("setAcVentilationState"), 1)
            // 5. Fresh air (OUTLOOP = 0) + fan speed
            callIntArgs(ac, listOf("setAcCycleMode"), 1, 0) || callIntArgs(ac, listOf("setAcCycleMode"), 0)
            callIntArgs(ac, listOf("setAcWindLevel"), 1, clamped) || callIntArgs(ac, listOf("setAcWindLevel"), clamped)
        }
        snap = snap.copy(acOn = true, acAuto = false, acCompressorOn = false, heaterOn = false, recirculation = false, fanLevel = clamped)
    }

    fun setTemperatureDirect(tempC: Float) {
        val clamped = tempC.coerceIn(MIN_TEMP_C, MAX_TEMP_C)
        getAcDevice()?.let { ac ->
            // Probe current scale before writing
            val curRaw = callInt(ac, listOf("getTemprature", "getTemperature"), 1)
            if (curRaw != null) {
                if (curRaw in 34..66) usesHalfDegreeScale = true
                else if (curRaw in 15..33) usesHalfDegreeScale = false
            }
            val intC = clamped.toInt()
            val sendVal = if (usesHalfDegreeScale) intC * 2 else intC
            // BYD DiLink 5.0 verified 3-arg (area, temp, 0) + 4-arg (area, temp, source, unit) + 2-arg
            val ok = callIntArgs(ac, listOf("setAcTemperature"), 1, sendVal, 0) ||
                callIntArgs(ac, listOf("setAcTemperature"), 1, sendVal, 1, 1) ||
                callIntArgs(ac, listOf("setAcTemperature", "setTemprature"), 1, sendVal)
            // Also sync passenger zone (area=2) if supported
            callIntArgs(ac, listOf("setAcTemperature"), 2, sendVal, 0) ||
                callIntArgs(ac, listOf("setAcTemperature"), 2, sendVal, 1, 1)
            CoreLog.i("COMFORT", "setTemperatureDirect target=${clamped}C sendVal=$sendVal halfScale=$usesHalfDegreeScale ok=$ok")
        }
        snap = snap.copy(tempC = clamped)
    }

    fun setFanLevelDirect(level: Int) {
        val clamped = level.coerceIn(0, 7)
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcWindLevel"), 1, clamped) ||
                callIntArgs(ac, listOf("setAcWindLevel"), clamped)
        }
        snap = snap.copy(fanLevel = clamped, acOn = clamped > 0)
    }

    fun setCycleModeDirect(recirc: Boolean) {
        val mode = if (recirc) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcCycleMode"), 1, mode) ||
                callIntArgs(ac, listOf("setAcCycleMode"), mode)
        }
        snap = snap.copy(recirculation = recirc)
    }

    fun setSteeringHeatDirect(on: Boolean) {
        val bydVal = if (on) 2 else 1 // Real-car verified: 2=ON, 1=OFF on BYDAutoSettingDevice
        val ok = getSettingDevice()?.let { st ->
            callIntArgs(st, listOf("setSteeringWheelHeatingState"), bydVal) ||
                callIntArgs(st, listOf("setSteeringWheelHeatingState"), 1, bydVal)
        } ?: false
        if (!ok) {
            getAcDevice()?.let { ac -> callIntArgs(ac, listOf("setSteeringWheelHeatingState", "setSteeringWheelHeatState"), bydVal) }
            getBodyDevice()?.let { bw -> callIntArgs(bw, listOf("setSteeringWheelHeatingState", "setSteeringWheelHeatState"), bydVal) }
        }
        CoreLog.i("COMFORT", "setSteeringHeatDirect on=$on bydVal=$bydVal ok=$ok")
        snap = snap.copy(steeringHeat = on)
    }

    fun setSeatHeatDirect(area: Int, level: Int) {
        val clamped = level.coerceIn(0, 2)
        setSeatHeat(area, clamped)
        snap = if (area == 1) snap.copy(driverSeatHeat = clamped) else snap.copy(passengerSeatHeat = clamped)
    }

    fun toggleAcPower(): ComfortSnapshot {
        val next = !snap.acOn
        setClimatePowerDirect(next)
        return snap
    }

    fun toggleAcCompressor(): ComfortSnapshot {
        val next = !snap.acCompressorOn
        setAcCompressorDirect(next)
        snap = snap.copy(acOn = if (next) true else snap.acOn)
        return snap
    }

    fun toggleHeater(): ComfortSnapshot {
        val next = !snap.heaterOn
        setHeaterDirect(next)
        snap = snap.copy(acOn = if (next) true else snap.acOn)
        return snap
    }

    fun toggleAcAuto(): ComfortSnapshot {
        val next = !snap.acAuto
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcControlMode"), 1, if (next) 0 else 1) ||
                callIntArgs(ac, listOf("setAcControlMode"), if (next) 0 else 1)
        }
        snap = snap.copy(acAuto = next, acOn = if (next) true else snap.acOn)
        return snap
    }

    fun adjustTemp(delta: Float): ComfortSnapshot {
        val next = (snap.tempC + delta).coerceIn(MIN_TEMP_C, MAX_TEMP_C)
        if (!snap.acOn) setClimatePowerDirect(true)
        setTemperatureDirect(next)
        snap = snap.copy(tempC = next, acOn = true)
        return snap
    }

    fun adjustFan(delta: Int): ComfortSnapshot {
        val next = (snap.fanLevel + delta).coerceIn(0, 7)
        setFanLevelDirect(next)
        return snap
    }

    /** Tap cycle: 정면(0) -> 정면+아래(1) -> 아래(2) -> 위+아래(3) -> 정면(0). */
    fun cycleWindModeTap(): ComfortSnapshot {
        val next = when (snap.windMode) {
            WIND_FACE -> WIND_FACE_FOOT
            WIND_FACE_FOOT -> WIND_FOOT
            WIND_FOOT -> WIND_DEFROST_FOOT
            else -> WIND_FACE
        }
        return setWindMode(next)
    }

    /** Long-press wind mode: ALL directions (정면+발+앞유리 전체 송풍). */
    fun setWindModeAll(): ComfortSnapshot {
        getAcDevice()?.let { ac ->
            // BYD AC_WINDMODE_FACEDEFROSTFOOT = 7 (fallback 6 or 4)
            callIntArgs(ac, listOf("setAcWindMode"), 1, 7) ||
                callIntArgs(ac, listOf("setAcWindMode"), 7) ||
                callIntArgs(ac, listOf("setAcWindMode"), 1, 6) ||
                callIntArgs(ac, listOf("setAcWindMode"), 1, 4)
        }
        snap = snap.copy(windMode = WIND_ALL, acOn = true)
        return snap
    }

    fun setWindMode(mode: Int): ComfortSnapshot {
        val bydVal = when (mode) {
            WIND_FACE -> 1
            WIND_FACE_FOOT -> 2
            WIND_FOOT -> 3
            WIND_DEFROST_FOOT -> 4
            WIND_DEFROST -> 5
            WIND_ALL -> 7
            else -> 1
        }
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcWindMode"), 1, bydVal) ||
                callIntArgs(ac, listOf("setAcWindMode"), bydVal)
        }
        snap = snap.copy(windMode = mode, acOn = true)
        return snap
    }

    fun toggleRecirculation(): ComfortSnapshot {
        val next = !snap.recirculation
        setCycleModeDirect(next)
        return snap
    }

    fun toggleSteeringHeat(): ComfortSnapshot {
        setSteeringHeatDirect(!snap.steeringHeat)
        return snap
    }

    fun cycleDriverSeatHeat(): ComfortSnapshot {
        val next = (snap.driverSeatHeat + 1) % 3 // 0 -> 1 -> 2 -> 0
        setSeatHeatDirect(area = 1, level = next)
        return snap
    }

    fun cyclePassengerSeatHeat(): ComfortSnapshot {
        val next = (snap.passengerSeatHeat + 1) % 3
        setSeatHeatDirect(area = 2, level = next)
        return snap
    }

    private fun setSeatHeat(area: Int, level: Int) {
        // Real-car verified on BYDAutoSettingDevice: 1=OFF, 2=LOW(1단), 3=HIGH(2단)
        val bydState = when (level) {
            1 -> 2
            2 -> 3
            else -> 1
        }
        val ok = getSettingDevice()?.let { st ->
            callIntArgs(st, listOf("setSeatHeatingState"), area, bydState)
        } ?: false
        if (!ok) {
            getAcDevice()?.let { ac ->
                callIntArgs(ac, listOf("setSeatHeatingState", "setSeatHeatLevel", "setAcSeatHeatLevel"), area, bydState) ||
                    callIntArgs(ac, listOf("setSeatHeatLevel", "setAcSeatHeatLevel"), area, level)
            }
        }
        CoreLog.i("COMFORT", "setSeatHeat area=$area level=$level bydState=$bydState ok=$ok")
    }

    /** Side-mirror + Rear windshield defrost toggle. */
    fun toggleRearMirrorDefrost(): ComfortSnapshot {
        val next = !snap.rearMirrorDefrost
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcDefrostState"), 1, 2, st) ||
                callIntArgs(ac, listOf("setAcDefrostState"), 2, st)
        }
        snap = snap.copy(rearMirrorDefrost = next)
        return snap
    }

    fun toggleFrontDefrost(): ComfortSnapshot {
        val next = !snap.frontDefrost
        val st = if (next) 1 else 0
        getAcDevice()?.let { ac ->
            callIntArgs(ac, listOf("setAcDefrostState"), 1, 1, st) ||
                callIntArgs(ac, listOf("setAcDefrostState"), 1, st)
        }
        snap = snap.copy(frontDefrost = next)
        return snap
    }

    /** Daytime Running Light (주간주행등 DRL) ON/OFF toggle via BYDAutoLightDevice.setDayTimeLightState. */
    fun toggleDrl(): ComfortSnapshot {
        val next = !snap.drlOn
        val bydVal = if (next) 1 else 2 // Real-car verified: 1=ON, 2=OFF
        val ok = getLightDevice()?.let { lt ->
            callIntArgs(lt, listOf("setDayTimeLightState", "setDayRunningLightState"), bydVal)
        } ?: false
        CoreLog.i("COMFORT", "toggleDrl next=$next bydVal=$bydVal ok=$ok")
        snap = snap.copy(drlOn = next)
        return snap
    }

    /** Crack all windows slightly (~15%) for cabin ventilation. */
    fun ventilateWindows() {
        getBodyDevice()?.let { bw ->
            if (!callIntArgs(bw, listOf("setAllWindowState"), 4)) {
                for (area in 1..4) callIntArgs(bw, listOf("setWindowOpenPercent"), area, 15)
            }
        }
    }

    fun closeAllWindows() {
        getBodyDevice()?.let { bw ->
            for (area in 1..4) callIntArgs(bw, listOf("setWindowOpenPercent"), area, 0)
        }
    }

    fun toggleSunshade(open: Boolean) {
        getBodyDevice()?.let { bw ->
            callIntArgs(bw, listOf("setSunshadePosition", "setSunroofCurtainPosition"), if (open) 100 else 0)
        }
    }

    private fun mapBydWindToLocal(bydMode: Int?): Int? = when (bydMode) {
        1 -> WIND_FACE
        2 -> WIND_FACE_FOOT
        3 -> WIND_FOOT
        4 -> WIND_DEFROST_FOOT
        5 -> WIND_DEFROST
        6, 7 -> WIND_ALL
        else -> null
    }

    private fun mapBydSeatToLocal(bydState: Int?): Int? = when (bydState) {
        1 -> 0
        2 -> 1
        3 -> 2
        else -> null
    }

    private fun callInt(target: Any, names: List<String>, vararg args: Int): Int? {
        val cls = target.javaClass
        val types = Array<Class<*>>(args.size) { Int::class.javaPrimitiveType!! }
        for (name in names) {
            val m: Method = runCatching { cls.getMethod(name, *types) }.getOrNull() ?: continue
            val boxed = args.map { it as Any }.toTypedArray()
            val v = runCatching { m.invoke(target, *boxed) }.getOrNull()
            if (v is Number) return v.toInt()
        }
        return null
    }

    private fun callIntArgs(target: Any, names: List<String>, vararg args: Int): Boolean {
        val cls = target.javaClass
        val types = Array<Class<*>>(args.size) { Int::class.javaPrimitiveType!! }
        for (name in names) {
            val m: Method = runCatching { cls.getMethod(name, *types) }.getOrNull() ?: continue
            val boxed = args.map { it as Any }.toTypedArray()
            val ok = runCatching {
                val r = m.invoke(target, *boxed)
                !(r is Int && r < 0)
            }.getOrDefault(false)
            if (ok) return true
        }
        return false
    }

    private fun callVoidOrInt(target: Any, names: List<String>, intArg: IntArray): Boolean {
        val cls = target.javaClass
        for (name in names) {
            runCatching { cls.getMethod(name, Int::class.javaPrimitiveType) }.getOrNull()?.let { m ->
                if (runCatching { m.invoke(target, intArg[0]); true }.getOrDefault(false)) return true
            }
            runCatching { cls.getMethod(name) }.getOrNull()?.let { m ->
                if (runCatching { m.invoke(target); true }.getOrDefault(false)) return true
            }
        }
        return false
    }

    companion object {
        const val MIN_TEMP_C = 17.0f
        const val MAX_TEMP_C = 27.0f // Korean BYD Dolphin HI = 27°C

        const val WIND_FACE = 0
        const val WIND_FACE_FOOT = 1
        const val WIND_FOOT = 2
        const val WIND_DEFROST_FOOT = 3
        const val WIND_DEFROST = 4
        const val WIND_ALL = 5

        fun windModeLabel(mode: Int): String = when (mode) {
            WIND_FACE -> "정면"
            WIND_FACE_FOOT -> "정면+발"
            WIND_FOOT -> "발"
            WIND_DEFROST_FOOT -> "유리+발"
            WIND_DEFROST -> "앞유리"
            WIND_ALL -> "전체"
            else -> "정면"
        }
    }
}
