#!/usr/bin/env python3
"""Static verification for v0.17.86 (Freeform 1/2/3/4 Multi-Window Test Engine)."""
import os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def read(rel): return open(os.path.join(ROOT, rel), "r", encoding="utf-8").read()

def check_balanced(rel):
    txt = read(rel)
    d = 0; s = False; lc = False; bc = False; i = 0; n = len(txt)
    while i < n:
        c = txt[i]; nx = txt[i+1] if i+1 < n else ""
        if lc:
            if c == "\n": lc = False
        elif bc:
            if c == "*" and nx == "/": bc = False; i += 1
        elif s:
            if c == "\\": i += 1
            elif c == '"': s = False
        else:
            if c == "/" and nx == "/": lc = True; i += 1
            elif c == "/" and nx == "*": bc = True; i += 1
            elif c == '"': s = True
            elif c == "{": d += 1
            elif c == "}": d -= 1; assert d >= 0
        i += 1
    assert not s and d == 0, f"Unbalanced braces/strings in {rel}"

for f in [
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockPreferences.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/FreeformLayoutController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt",
]:
    check_balanced(f)

ff = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/FreeformLayoutController.kt")
for kw in ["enable_freeform_support", "force_resizable_activities", "--windowingMode", "am task resize", "SPLIT_70_30", "TRIPLE_60_40", "QUAD_2X2"]:
    assert kw in ff, f"Missing {kw} in FreeformLayoutController.kt"

dbs = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt")
assert "FreeformLayoutController.launchPreset" in dbs
assert "FreeformLayoutController.enableAndDiagnose" in dbs

bg = read("app/build.gradle.kts")
assert "versionCode = 112" in bg and 'versionName = "0.17.86"' in bg
print("VERIFY_V01786_PASS: Freeform 1/2/3/4 test controller + UI panel + Gradle v0.17.86 (112) verified.")
