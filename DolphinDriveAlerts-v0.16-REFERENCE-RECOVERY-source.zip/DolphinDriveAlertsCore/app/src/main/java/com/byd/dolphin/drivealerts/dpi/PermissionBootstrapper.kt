package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** Restores the ADB bootstrap path used by earlier Dolphin Assistant builds. */
object PermissionBootstrapper {
    data class Result(val success: Boolean, val lines: List<String>)

    fun apply(context: Context): Result {
        val app = context.applicationContext
        val pkg = app.packageName
        val auth = NativeAdbClient.waitForAuthorization(app)
        val lines = mutableListOf("ADB: ${if (auth.success) "OK" else "FAILED"} ${auth.message}")
        if (!auth.success) return Result(false, lines)

        var hardFailure = false
        fun run(label: String, command: String, required: Boolean = false) {
            val r = NativeAdbClient.executeShell(app, command, timeoutMs = 8_000L)
            lines += "$label: ${if (r.success) "OK" else "FAILED"} ${r.output.trim().take(180).ifBlank { r.message }}"
            if (required && !r.success) hardFailure = true
        }

        run("WRITE_SECURE_SETTINGS", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        run("SYSTEM_ALERT_WINDOW", "appops set $pkg SYSTEM_ALERT_WINDOW allow")
        run("PACKAGE_USAGE_STATS", "appops set $pkg GET_USAGE_STATS allow")
        run("RUN_IN_BACKGROUND", "appops set $pkg RUN_IN_BACKGROUND allow")
        run("RUN_ANY_IN_BACKGROUND", "appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        run("배터리 최적화 예외", "dumpsys deviceidle whitelist +$pkg")

        // BYD COMMON permissions are requested in the manifest. Some firmware grants them via ADB,
        // some rejects them as signature/privileged. Failures here are logged but do not abort because
        // BydPermissionContext handles the framework's client-side permission checks separately.
        val bydCommon = listOf(
            "android.permission.BYDAUTO_SETTING_COMMON",
            "android.permission.BYDAUTO_AC_COMMON",
            "android.permission.BYDAUTO_BODYWORK_COMMON",
            "android.permission.BYDAUTO_LIGHT_COMMON",
            "android.permission.BYDAUTO_RADAR_COMMON",
            "android.permission.BYDAUTO_INSTRUMENT_COMMON"
        )
        for (permission in bydCommon) run(permission.substringAfterLast('.'), "pm grant $pkg $permission")

        val component = ComponentName(app, ForegroundPolicyAccessibilityService::class.java).flattenToString()
        val current = NativeAdbClient.executeShell(app, "settings get secure enabled_accessibility_services", timeoutMs = 5_000L)
        if (!current.success) {
            lines += "접근성 기존 목록 읽기: FAILED ${current.message}"
            hardFailure = true
        } else {
            val existing = current.output.trim().takeUnless { it.isBlank() || it == "null" }.orEmpty()
            val merged = existing.split(':').filter { it.isNotBlank() }.toMutableList().apply {
                if (component !in this) add(component)
            }.distinct().joinToString(":")
            run("접근성 서비스 목록", "settings put secure enabled_accessibility_services '${shellQuote(merged)}'", required = true)
            run("접근성 활성화", "settings put secure accessibility_enabled 1", required = true)
        }

        // Read back the settings so a button press can never silently report success.
        run("배터리 예외 readback", "dumpsys deviceidle whitelist")
        run("접근성 readback", "settings get secure enabled_accessibility_services | tr ':' '\\n' | grep -F '$component' || true")

        run("사용기록 readback", "appops get $pkg GET_USAGE_STATS")

        CoreLog.i("PERMISSION_BOOTSTRAP", lines.joinToString(" | "))
        return Result(!hardFailure, lines)
    }

    private fun shellQuote(value: String): String = value.replace("'", "'\\''")
}
