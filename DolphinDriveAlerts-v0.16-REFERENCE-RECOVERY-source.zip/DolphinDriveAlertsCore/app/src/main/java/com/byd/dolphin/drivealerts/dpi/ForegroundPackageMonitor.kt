package com.byd.dolphin.drivealerts.dpi

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * UsageStats fallback for per-app orientation rules. The accessibility service applies
 * the same rule immediately when available; this monitor keeps rotation working on
 * head units where accessibility event delivery is delayed or disabled.
 */
class ForegroundPackageMonitor(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val executor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "foreground-package-monitor").apply { isDaemon = true }
    }
    private var task: ScheduledFuture<*>? = null
    private var lastPackage: String? = null
    private var warnedEmpty = false
    private var lastRotationEnabled = true

    fun start() {
        if (task != null) return
        task = executor.scheduleAtFixedRate(::pollSafely, 0, 1, TimeUnit.SECONDS)
        CoreLog.i("ROTATION", "UsageStats foreground monitor started")
    }

    private fun pollSafely() {
        try {
            val pkg = latestForegroundPackage()
            if (pkg == null) {
                if (!warnedEmpty) {
                    warnedEmpty = true
                    CoreLog.w("ROTATION", "UsageStats returned no foreground package; grant GET_USAGE_STATS appop")
                }
                return
            }
            warnedEmpty = false
            if (pkg == lastPackage && RotationPolicy.enabled(app) == lastRotationEnabled) return
            lastRotationEnabled = RotationPolicy.enabled(app)
            lastPackage = pkg
            val policy = AppPolicyStore.all(app)[pkg]
            val mode = policy?.orientationMode ?: OrientationMode.STOCK
            OrientationOverlayController.apply(app, mode)
            CoreLog.i("ROTATION", "foreground=$pkg orientation=$mode source=usage-stats")
        } catch (t: Throwable) {
            CoreLog.w("ROTATION", "foreground monitor failed: ${t.message}", t)
        }
    }

    private fun latestForegroundPackage(): String? {
        val usm = app.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 10_000L, end)
        val event = UsageEvents.Event()
        var latestPackage: String? = null
        var latestTime = Long.MIN_VALUE
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND &&
                !event.packageName.isNullOrBlank() &&
                event.timeStamp >= latestTime
            ) {
                latestTime = event.timeStamp
                latestPackage = event.packageName
            }
        }
        return latestPackage
    }

    override fun close() {
        task?.cancel(true)
        task = null
        executor.shutdownNow()
        OrientationOverlayController.clear()
    }
}
