package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.util.CoreLog

/** Independent best-effort system split implementation. OEM stack commands require local ADB. */
object VehicleSplitEngine {
    data class Result(val success: Boolean, val message: String)
    private fun shell(c: Context, command: String) = NativeAdbClient.executeShell(c,command,timeoutMs=4_000)

    fun launch(c: Context, profile: SplitProfile): Result {
        val one = AppSelection.safeComponent(c,profile.firstPackage) ?: return Result(false,"첫 번째 앱을 찾을 수 없음")
        val two = AppSelection.safeComponent(c,profile.secondPackage) ?: return Result(false,"두 번째 앱을 찾을 수 없음")
        if (one == two) return Result(false,"서로 다른 앱 2개를 선택해야 합니다")
        if (!NativeAdbClient.isPortOpen()) return Result(false,"로컬 ADB 5555 비활성/미연결")
        // Matches the basic Android/DiLink windowing modes found in the reference investigation.
        // Fail rather than claim that an ordinary pair of fullscreen launches was a split.
        val first = shell(c,"am start --windowingMode 3 -n $one")
        if (!first.success) return Result(false,"PRIMARY: ${first.message}")
        val second = shell(c,"am start --windowingMode 4 -n $two")
        if (!second.success) return Result(false,"SECONDARY: ${second.message}")
        val state = shell(c,"am stack list")
        if (!state.success) return Result(false,"분할 상태 조회 불가: ${state.message}")
        // Do not resize if shell reports no docked stack (could resize unrelated foreground UI).
        if (!state.output.contains("docked",true) && !state.output.contains("split-screen",true)
            && !Regex("(?i)windowingMode[=:]\\s*3").containsMatchIn(state.output))
            return Result(false,"분할 스택 확인 실패 (am stack list 결과 필요)")
        val ratio = applyRatio(c,profile.primaryPercent)
        if (!ratio.success) return ratio
        FeatureProfiles.markSplit(c,profile.id)
        CoreLog.i("SPLIT", "profile=${profile.id} ratio=${profile.primaryPercent} state=launched")
        return Result(true,"분할 실행 및 비율 명령 전송; 화면 비율은 실차에서 최종 확인")
    }

    fun applyRatio(c: Context, pct: Int): Result {
        val size = shell(c,"wm size")
        if (!size.success) return Result(false,"화면 크기 조회 실패: ${size.message}")
        val match = Regex("(\\d+)x(\\d+)").findAll(size.output).lastOrNull()
            ?: return Result(false,"디스플레이 크기를 해석하지 못함")
        val w = match.groupValues[1].toIntOrNull() ?: return Result(false,"폭 파싱 실패")
        val h = match.groupValues[2].toIntOrNull() ?: return Result(false,"높이 파싱 실패")
        val split = pct.coerceIn(10,90)
        // Automotive head unit normally horizontal, but support portrait split too.
        val boundary = if (w >= h) (w*split/100) else (h*split/100)
        val rectangle = if (w >= h) "0 0 $boundary $h" else "0 0 $w $boundary"
        val command = "am stack resize-docked-stack $rectangle"
        val result = shell(c, command)
        if (!result.success) return Result(false,"비율 명령 거부: ${result.message}")
        val post = shell(c,"am stack list")
        if (!post.success) return Result(false,"비율 적용 후 상태 확인 실패")
        // AutoSplit reference: verify actual windowing mode after resize before reporting success.
        val splitPresent = post.output.contains("docked", true) || post.output.contains("split-screen", true) ||
            Regex("""(?i)windowingMode[=:]\s*[34]""").containsMatchIn(post.output)
        CoreLog.i("SPLIT", "requested=$split screen=${w}x$h boundary=$boundary " +
            "splitPresent=$splitPresent stack=${post.output.take(200)}")
        return if (splitPresent) Result(true,"${split}% 비율 요청 전송·분할 스택 재확인 (픽셀 비율 확인 필요)")
            else Result(false,"비율 적용 후 분할 스택 유실; 다시 분할 실행 필요")
    }

    fun screenToken(c: Context): String? {
        val s = shell(c,"dumpsys activity activities")
        if (!s.success) return null
        val top = s.output.lineSequence().filter {
            it.contains("topResumedActivity",true) || it.contains("mResumedActivity",true) || it.contains("ResumedActivity",true)
        }.lastOrNull() ?: return null
        return top.take(350)
    }
}
