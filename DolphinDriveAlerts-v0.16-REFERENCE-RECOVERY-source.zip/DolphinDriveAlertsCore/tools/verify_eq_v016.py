#!/usr/bin/env python3
"""v0.15 user scope regression: requested EQ only, no speed SVC/driving synth."""
from pathlib import Path
import sys, subprocess
root=Path(__file__).resolve().parents[1]
read=lambda path:(root/path).read_text('utf-8')
base='app/src/main/java/com/byd/dolphin/drivealerts/'
eq=read(base+'audio/GlobalEqualizerEngine.kt')
ui=read(base+'ui/AudioTuningActivity.kt')
settings=read(base+'audio/EqPreferences.kt')
config=read('app/build.gradle.kts')
manifest=read('app/src/main/AndroidManifest.xml')
checks={
 'v015-code-and-name':'versionCode = 16' in config and '0.16.0-reference-integration' in config,
 'bass-mid-treble-still-present':all(t in settings for t in ['K_BASS','K_MID','K_TREBLE']),
 'focus-reference-surround-cinema':all(t in eq for t in ['REFERENCE','SURROUND','CINEMA']),
 'spatial-effect-reused':'Virtualizer(' in eq and 'centerpoint360' in eq,
 'session-open-close-observation':'ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION' in eq and 'ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION' in eq,
 'effect-control-check':'hasControl()' in eq,
 'actual-eq-readback':'eq.getBandLevel(band) != target' in eq and 'eq.enabled && mismatched == 0' in eq,
 'reported-control-return-code':'code == AudioEffect.SUCCESS' in eq,
 'independent-effect-failure':'bass boost failed' in eq and 'virtualizer failed' in eq,
 'previous-band-levels-restored':'eqBands?.forEachIndexed' in eq,
 'previous-effect-states-restored':all(t in eq for t in ['eqEnabled','bassEnabled','virtEnabled','loudEnabled']),
 'status-not-falsely-acoustic-verified':'실제 청감 미확인' in eq,
 'eq-visible-state-without-extra-menus':'GlobalEqualizerEngine.readStatus(this@AudioTuningActivity)' in ui,
 'only-requested-features':'ScvController.kt' not in [p.name for p in (root/(base+'audio')).glob('*.kt')] and 'SynthEngine.kt' not in [p.name for p in (root/(base+'audio')).glob('*.kt')],
 'no-car-route-privilege-invented':'MODIFY_AUDIO_ROUTING' not in manifest,
 'no-third-party-reference-assets':not list((root/'app/src/main').rglob('evsound*')),
 'unified-log-retained':'UnifiedLogCapture' in read(base+'service/DrivingAlertService.kt'),
 'split-and-autostart-retained':'SplitRecoveryService' in manifest and 'AutoLaunchSequenceService' in manifest,
 'driver-route-limitation-honest':'DRIVER_ROUTE_PENDING_VENDOR_HOOK' in read(base+'dpi/ExternalAppAudioRouter.kt'),
}
for k,good in checks.items(): print(('PASS' if good else 'FAIL')+': '+k)
print(f'V015 EQ TARGET CHECKS: {sum(checks.values())}/{len(checks)}')
if not all(checks.values()):sys.exit(1)
run=subprocess.run([sys.executable,str(root/'tools/verify_unified_log_v016.py')],text=True,capture_output=True)
print(run.stdout[-2000:]); print(run.stderr[-800:])
if run.returncode:sys.exit(run.returncode)
