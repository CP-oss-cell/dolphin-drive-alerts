#!/usr/bin/env python3
"""v0.17.15 source-contract and actual Kotlin JVM checks. Does not replace Android/vehicle tests."""
import pathlib, subprocess, shutil, tempfile, textwrap, re, sys, zipfile
p=pathlib.Path(__file__).resolve().parents[1]
src=p/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda file:(src/file).read_text()
checks={
    'version_42_or_later': bool(re.search(r'versionCode\s*=\s*(4[2-9]|[5-9]\d|\d{3,})\b', (p/'app/build.gradle.kts').read_text())),
    'read_only_indicator': 'getLeftTurnLightState' in read('vehicle/TurnSignalReadback.kt') and 'hazardSide=UNKNOWN' in read('vehicle/TurnSignalReadback.kt') and 'getRightTurnState' in read('vehicle/TurnSignalReadback.kt'),
    'indicator_exception_reasons': 'noCallableGetter' in read('vehicle/TurnSignalReadback.kt') and 'nonNumeric=' in read('vehicle/TurnSignalReadback.kt'),
    'no_unverified_turn_sound_gate': ('NOT_USED_FOR_BSD_GATE' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'TURN_SOUND_CORRELATION_ONLY' in read('vehicle/ReferenceVehicleEventBridge.kt')) or ('UNVERIFIED_TURN_CLICK_CADENCE' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'linkLockBsdDecoder.isActive() && turnSoundCadence.probableActive' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'hazardsNotSeparatelyVerified' in read('vehicle/TurnSoundCadence.kt')),
    'normal_readback_without_cycle_guess': 'getOperationModeState' in read('vehicle/ReferenceVehicleEventBridge.kt') and 'noBlindCycleInference=true' in read('vehicle/ReferenceVehicleEventBridge.kt'),
    'bsd_generic_voice_preserved': 'announceGenericBsd("BLINKER_ANY_SIDE;' in read('vehicle/ReferenceVehicleEventBridge.kt'),
    'single_alert_latch_preserved': 'announced = true' in read('vehicle/BsdAlertDecision.kt'),
    'adb_first_run_preserved': 'waitForAuthorization(' in read('dpi/NativeAdbClient.kt'),
    'split_first_second_commands': (('SPLIT_START_PRIMARY' in read('automation/VehicleSplitEngine.kt') and 'SPLIT_START_SECONDARY' in read('automation/VehicleSplitEngine.kt')) or ('PRIMARY_COLD' in read('automation/VehicleSplitEngine.kt') and 'SECONDARY_START' in read('automation/VehicleSplitEngine.kt') and 'PRIMARY_MOVE' in read('automation/VehicleSplitEngine.kt'))),
    'split_task_verified': ('taskEvidence.verified' in read('automation/VehicleSplitEngine.kt') or ('taskEvidence.hasDefinitiveMismatch' in read('automation/VehicleSplitEngine.kt') and 'primaryTask.taskId==secondaryTask.taskId' in read('automation/VehicleSplitEngine.kt'))) and 'firstTaskIds=' in read('automation/SplitTaskReadback.kt'),
    'split_no_self_app': 'profile.secondPackage == c.packageName' in read('automation/VehicleSplitEngine.kt'),
    'split_bounds_readback': ('SplitBoundsReadback.primaryPercent' in read('automation/VehicleSplitEngine.kt') or ('SplitGeometry.parse' in read('automation/VehicleSplitEngine.kt') and 'SplitGeometry::percent' in read('automation/VehicleSplitEngine.kt'))),
    'zip_staging_and_verify': 'verifyCompleteZip(staged)' in read('log/UnifiedLogCapture.kt') and 'ZipInputStream' in read('log/UnifiedLogCapture.kt') and 'ZipFile(file)' in read('log/UnifiedLogCapture.kt'),
    'zip_pending_remains': 'MediaStore.MediaColumns.IS_PENDING' in read('log/UnifiedLogCapture.kt'),
    'log_version': 'appVersionName' in read('log/UnifiedLogCapture.kt'),
    'dedup_preserves_transitions': 'previous.first == value' in read('log/RawSignalLogger.kt') and 'isBuzzer || isTimestamp' in read('log/RawSignalLogger.kt'),
    'other_raw_not_dropped': 'source == "reference.setting" && eventType == 0x99000198.toInt()' in read('log/RawSignalLogger.kt'),
    'eq_preserved': 'EQ 미세 강화' in read('ui/AudioTuningActivity.kt'),
    'idas_readonly': 'eventMeaningUnverified=true;iccConfirmed' in read('vehicle/ReferenceVehicleEventBridge.kt'),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()),'static contract failure'
if '--static-only' in sys.argv:
 print(f'V01715_SOURCE={sum(checks.values())}/{len(checks)}')
 sys.exit(0)
if not shutil.which('kotlinc'):
 print('Kotlin compiler unavailable: Android Gradle gate required')
 sys.exit(0)
with tempfile.TemporaryDirectory(prefix='v01715-kotlin-') as t:
 t=pathlib.Path(t)
 def put(name,data):
  x=t/name;x.parent.mkdir(parents=True,exist_ok=True);x.write_text(textwrap.dedent(data));return str(x)
 def run(sources,main):
  jar=t/'run.jar'
  c=subprocess.run(['kotlinc',*sources,main,'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=100)
  assert c.returncode==0,c.stdout+c.stderr
  c=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
  assert c.returncode==0,c.stdout+c.stderr
  print(c.stdout.strip())
 # Verify exact production split task parser, not a rewrite.
 split=str(src/'automation/SplitTaskReadback.kt')
 runner=put('SplitTest.kt','''
   import com.byd.dolphin.drivealerts.automation.SplitTaskReadback
   fun main() {
     val good="Task{a #17 windowingMode=3 com.alpha/.Main}\\nTask{b #18 windowingMode=4 com.beta/.Main}"
     val x=SplitTaskReadback.inspect(good,"com.alpha","com.beta")
     check(x.verified && !x.hasDefinitiveMismatch) {x.toString()}
     check(!SplitTaskReadback.inspect("Task{a #17 windowingMode=3 com.alpha com.beta}","com.alpha","com.beta").verified)
     check(!SplitTaskReadback.inspect("Task{a #17 windowingMode=1 com.alpha}\\nTask{b #18 windowingMode=1 com.beta}","com.alpha","com.beta").verified)
     check(!SplitTaskReadback.inspect("Task{a #17 com.alpha}\\nTask{b #18 com.beta}","com.alpha","com.beta").verified)
     println("SPLIT_ACTUAL_KOTLIN=4/4 PASS")
   }
 ''')
 run([split],runner)
 # Exact turn signal probe with in-memory fake SDK device used only in test.
 mock=[put('android/content/Context.kt','''
 package android.content
 open class Context { val applicationContext:Context get()=this }
 '''),put('com/byd/dolphin/drivealerts/vehicle/BydPermissionContext.kt','''
 package com.byd.dolphin.drivealerts.vehicle
 import android.content.Context
 object BydPermissionContext { fun wrap(c:Context)=c }
 '''),put('com/byd/dolphin/drivealerts/model/Side.kt','''
 package com.byd.dolphin.drivealerts.model
 enum class Side { LEFT, RIGHT, UNKNOWN }
 '''),put('android/hardware/bydauto/light/BYDAutoLightDevice.kt','''
 package android.hardware.bydauto.light
 import android.content.Context
 class BYDAutoLightDevice {
   companion object { var left=0;var right=0; @JvmStatic fun getInstance(c:Context)=BYDAutoLightDevice() }
   fun getLeftTurnLightState():Int=left
   fun getRightTurnLightState():Int=right
 }
 ''')]
 runner=put('TurnTest.kt','''
 import android.content.Context
 import android.hardware.bydauto.light.BYDAutoLightDevice as D
 import com.byd.dolphin.drivealerts.vehicle.TurnSignalReadback
 fun main() {
   val p=TurnSignalReadback(Context())
   D.left=1;D.right=0;check(p.read().anyBlinkerActive)
   D.left=0;D.right=1;check(p.read().anyBlinkerActive)
   D.left=1;D.right=1;check(!p.read().anyBlinkerActive)
   D.left=0;D.right=0;check(!p.read().anyBlinkerActive)
   println("TURN_SIGNAL_ACTUAL_KOTLIN=4/4 PASS")
 }
 ''')
 run([str(src/'vehicle/TurnSignalReadback.kt'),*mock],runner)
 # Real production ZIP CRC/completeness routine exercised with v0.17.29 manifest contract.
 # Android org.json is not on the bare JVM classpath. Supply a minimal test adapter,
 # but compile and run the UNMODIFIED production verifyCompleteZip method.
 whole=read('log/UnifiedLogCapture.kt')
 a=whole.index('    private fun verifyCompleteZip(file: File) {')
 b=whole.index('    private fun export(',a)
 body=whole[a:b].replace('private fun verifyCompleteZip(', 'fun verifyCompleteZip(')
 testsrc='import java.io.*\nimport java.util.zip.*\nimport java.security.MessageDigest\nimport org.json.JSONObject\nobject CaptureContract {\n'+body+'\n}\n'
 zipfix=put('CaptureContract.kt',testsrc)
 jsonmock=put('org/json/JSONObject.kt',r'''
 package org.json
 class JSONObject(private val raw: String) {
   fun getJSONArray(key: String): JSONArray {
     require(key == "files")
     val found = Regex("\\\"files\\\"\\s*:\\s*\\[([^\\]]*)\\]").find(raw)
         ?: error("Missing files array")
     val value = found.groupValues[1]
     val objects = Regex("\\{[^{}]*\\}").findAll(value).map { JSONObject(it.value) }.toList()
     if (objects.isEmpty() && value.trim().isNotEmpty()) error("Malformed JSON array")
     return JSONArray(objects)
   }
   fun getString(key: String): String = Regex("\\\"" + Regex.escape(key) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"")
        .find(raw)?.groupValues?.get(1) ?: error("Missing string $key")
   fun getLong(key: String): Long = Regex("\\\"" + Regex.escape(key) + "\\\"\\s*:\\s*([0-9]+)")
        .find(raw)?.groupValues?.get(1)?.toLong() ?: error("Missing number $key")
 }
 class JSONArray(private val values: List<JSONObject>) {
   fun length(): Int = values.size
   fun getJSONObject(i:Int): JSONObject = values[i]
 }
 ''')
 runner=put('ZipTest.kt',r'''
 import java.io.File
 import java.security.MessageDigest
 import java.util.zip.ZipOutputStream
 import java.util.zip.ZipEntry
 fun main() {
   val entries = linkedMapOf(
      "session.json" to "active-session".toByteArray(),
      "lifecycle/capture_continuity.json" to "continuity".toByteArray(),
      "logs/vehicle_events.jsonl" to "vehicle event".toByteArray(),
      "diagnostics/2602_OEM_NAV_GUIDANCE/policy.txt" to "primary navi".toByteArray())
   fun create(input: Map<String,ByteArray>, corruptHash: Boolean=false, manifestPresent: Boolean=true): File {
     val f=File.createTempFile("test-recording-", ".zip")
     val items = input.map { (name,data) ->
       val hash = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
       "{\"path\":\"$name\",\"bytes\":${data.size},\"sha256\":\"${if(corruptHash) "0".repeat(64) else hash}\"}"
     }
     ZipOutputStream(f.outputStream()).use { z ->
       input.forEach { (name,data) ->
         z.putNextEntry(ZipEntry(name));z.write(data);z.closeEntry()
       }
       if (manifestPresent) {
         z.putNextEntry(ZipEntry("evidence_manifest.json"))
         z.write("{\"files\":[${items.joinToString(",")}]}".toByteArray())
         z.closeEntry()
       }
     }
     return f
   }
   val good=create(entries)
   CaptureContract.verifyCompleteZip(good)
   val corruptHash=create(entries, corruptHash=true)
   check(runCatching{CaptureContract.verifyCompleteZip(corruptHash)}.isFailure)
   val noManifest=create(entries, manifestPresent=false)
   check(runCatching{CaptureContract.verifyCompleteZip(noManifest)}.isFailure)
   val noRequired=create(entries.filterKeys{it!="logs/vehicle_events.jsonl"})
   check(runCatching{CaptureContract.verifyCompleteZip(noRequired)}.isFailure)
   val truncated=File.createTempFile("test-broken-", ".zip")
   truncated.writeBytes(good.readBytes().dropLast(22).toByteArray())
   check(runCatching{CaptureContract.verifyCompleteZip(truncated)}.isFailure)
   listOf(good,corruptHash,noManifest,noRequired,truncated).forEach{it.delete()}
   println("ZIP_ACTUAL_KOTLIN_V01729=5/5 PASS")
 }
 ''')
 run([zipfix,jsonmock],runner)
print(f'V01715_VALIDATION={len(checks)}/{len(checks)} static + Kotlin tests PASS; Android/full-car NOT RUN')
