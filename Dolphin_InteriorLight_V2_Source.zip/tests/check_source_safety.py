"""Lightweight CI-independent invariants. Not a replacement for Android build or real-car testing."""
from pathlib import Path
import sys
import zipfile
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/dolphin/insidelightprobe/MainActivity.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
gradle=(root/'app/build.gradle').read_text()
workflow=(root/'.github/workflows/build-apk.yml').read_text()
checks={
 'Manifest parses': lambda: ET.fromstring(manifest) is not None,
 'V2 code, state store': lambda: 'dolphin_wizard_v2' in s and 'restore()' in s and 'persist()' in s,
 'Four wizard stages': lambda: all(f'step=={n}' in s for n in (1,2,3)),
 'Dynamic method discovery': lambda: 'getMethods()' in s and 'methodCandidates.add(signature(m))' in s,
 'Dynamic SystemUI candidates': lambda: 'componentCandidates.add(' in s,
 'Guarded OEM control': lambda: 'permission(PERM_COMMON)' in s and 'preflightPassed' in s and 'confirmOem' in s,
 'Only interior-light setter named': lambda: 'turnOffInsideLight' in s and 'setInsideLightDoorState' not in s,
 'No arbitrary CAN control code': lambda: all(x not in s for x in ('CAN_RAW','sendBroadcast(', 'Runtime.getRuntime(', 'ProcessBuilder(', 'Socket(', 'setprop ', 'su -c')),
 'No auto control on launch': lambda: 'scan();\n        render();' in s and 'doOem(' not in s[s.index('@Override public void onCreate'):s.index('private int dp(')],
 'No network permission': lambda: 'INTERNET' not in manifest,
 'Permission declarations': lambda: all(k in manifest for k in ('BYDAUTO_SETTING_COMMON','BYDAUTO_SETTING_GET','BYDAUTO_SETTING_SET')),
 'No HOME override': lambda: 'android.intent.category.HOME' not in manifest,
 'Android 10 target': lambda: 'targetSdk 29' in gradle,
 'Upload artifact': lambda: 'upload-artifact@v4' in workflow and 'app-debug.apk' in workflow,
 'User physical confirmation': lambda: all(t in s for t in ('PHYSICAL_CHANGED','PHYSICAL_UNCHANGED','PHYSICAL_UNKNOWN')),
 'History export': lambda: 'obj.put("events",entries)' in s and 'Intent.ACTION_SEND' in s,
}
fail=[]
for label,test in checks.items():
    try: ok=bool(test())
    except Exception: ok=False
    print(('PASS' if ok else 'FAIL')+' '+label)
    if not ok:fail.append(label)
print(f'STATIC_GATE {len(checks)-len(fail)}/{len(checks)}; Android build NOT EXECUTED')
sys.exit(1 if fail else 0)
