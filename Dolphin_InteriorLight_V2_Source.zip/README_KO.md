# BYD Dolphin 실내등 일괄 ON/OFF · One-Install Wizard V2

## 무엇을 해결하나
- **한 번 설치**: 환경 조회 → 발견한 후보 선택 → 선택 경로 진단 → 결과 확인 → 다른 후보로 넘어가기.
- 한 화면에서 계속 선택하므로 한 후보당 신규 APK를 설치할 필요 없음.
- 이전 결과/선택/이력을 앱 SharedPreferences에 저장. 앱을 재실행해도 다시 볼 수 있음.
- JSON 리포트 복사·공유. 최대 160개 이벤트까지 누적 보존.

## 후보 분류
| 경로 | 하는 일 | 실제 명령 |
|---|---|---|
| OEM | BYDAutoSettingDevice.getInstance(Context), turnOffInsideLight(int) 메서드 존재 확인 | 사용자 승인 및 COMMON 권한 허용 때만 **2(점등),1(소등)** 각 1회 |
| CAR | CarSettings.Global insight_light_online 읽기 | 없음 |
| UI | 설치된 SystemUI와 exported 컴포넌트 개수 확인 | 없음 |
| PERM | 권한 COMMON/GET/SET 상태 확인 | 없음 |

`insight_light_online`은 기능 표시 조건 후보이지 조명의 실제 점등 상태가 아닙니다. OEM API 반환값은 조명의 실제 변화가 아닙니다. **육안으로 물리 변화 확인 후 수동 판정해야 VERIFIED로 분류할 수 있습니다.**

## 차량과 권한 제약
- 한국 BYD 돌핀 Standard, 글로벌 2602 기준. 2606 펌웨어는 정적 비교 전용.
- Permission 선언 포함. 권한을 자동 획득하거나 제조사 서명/시스템 특권을 우회하지 않습니다.
- BYDAUTO_SETTING_COMMON 미부여 시 OEM 쓰기 시험은 잠기며, 이유를 기록하고 다른 경로를 살펴볼 수 있습니다.
- 원본 시스템 APK 변경, root/ADB/SELinux/BCM 설정 변경, CAN RAW 및 임의 신호 송신, 안전 기능 변경 없음.
- 차량 P단·주차 브레이크 체결/수동 확인, 매 1회 확인 대화상자에서 별도 동의가 필요.
- 앱을 강제 종료하거나 다시 켜도 기록은 남지만, 임의 명령이나 신호를 추가하려면 **다음 버전 배포가 필요**. 플랫폼에 없는 API나 CAN 기능을 앱이 실행 중 코드로 생성하지는 못합니다.

## 실행 및 배포
1. ZIP 압축 해제 후 모든 파일과 숨긴 `.github` 폴더를 새 저장소 루트 또는 독립 테스트 브랜치에 업로드.
2. GitHub Actions의 `Build Dolphin Interior Light One-Install Wizard V2` → Run workflow.
3. Artifacts에서 `Dolphin-InteriorLight-OneInstall-V2-APK` 다운로드, 내부 `app-debug.apk` 설치.
4. V1과 같은 applicationId `com.dolphin.insidelightprobe`. 다르게 서명하면 V1을 제거하고 V2를 설치해야 할 수 있으며, V1 데이터는 삭제될 수 있음.
5. 설치 후 `1 환경 → 2 후보 → 3 경로 → 4 결과` 진행. 결과 4에서 다른 후보를 선택해 계속 테스트.

## 검증 근거
- 과거 정적 분석: `/product/priv-app/SystemUIWithLegacyRecents/SystemUIWithLegacyRecents.apk`, `InsightLightOnItem` / `InsightLightOffItem`, `turnOffInsideLight(2)` 점등 경로 및 `insight_light_online` 조건 코드.
- 과거 실차 로그: BYDAUTO_SETTING_COMMON SecurityException 및 실내등 점등/소등 실패.
- 구글 드라이브 50~69차 정적 분석: 내부 번호·호출 위치는 CAN ID 또는 권한 확보가 아니며, 차량 제어 기능은 실차 검증 전 추정 금지.
- 과거 issue #47: 이 환경에서 404로 접근되지 않아 내용 대조 실패. 관련 저장소 이슈 검색 결과 없음.

## 정적 검증과 현재 제한
- 소스·Manifest·빌드 YAML·JSON 경로 점검과 파일 구조 확인을 수행.
- 이 실행 환경에는 Android SDK가 없으므로 실제 `assembleDebug` 빌드는 GitHub Actions에서 수행해야 함. 빌드 완료/실차 동작 성공을 주장하지 않음.

## 동적으로 확장되는 후보 목록 / 동작 범위
- 1단계: 설치된 Android 및 펌웨어 정보, COMMON/GET/SET 권한, OEM API/CarSettings/SystemUI 식별.
- 2단계: *실제 기기에서 발견된* OEM / CarSettings / SystemUI / 권한 후보 중 하나 선택.
- 3단계 OEM: `getMethods()`에서 이름에 `inside`, `light`, `cabin`이 포함된 **실제 관찰된 공개 메서드 시그니처 목록** 표시 → 하나 선택 → 시그니처 읽기 검증 → 권한 있을 때 한정된 1·2 값 테스트.
- 3단계 SystemUI: **실제로 설치된 패키지의 exported Activity/Service/Receiver/Provider** 목록 표시 → 사용자가 경로 선택 및 메타데이터 기록. 호출·실행하지 않음.
- 3단계 CarSettings/권한: 검증된 사전 정의된 항목만 읽기.
- 4단계: 성공 API 반환값/권한 차단/오류/물리 반응을 구분하고 다음 후보 선택으로 복귀.
- 런타임 후보 탐색은 *코드·메서드 서명과 컴포넌트* 검색입니다. 임의 CAN ID나 새 보안 권한을 해독·생성하는 엔진은 아닙니다. 신규 기능을 실제 제어하려면 근거 확인 후 안전한 구현이 포함된 다음 버전이 필요할 수 있습니다.

## 검토한 최신 연구/기존 이슈
- `/Dolphin Drive Alerts/00_MASTER_ISSUES.md` 최신 2026-10-13 기록: **DA-004 권한, DA-013 빌드, DA-025 순정 안전, DA-029 증거 로그**를 재사용. 신규 중복 이슈 번호 없음.
- 2026-10-13 정본의 DA-002 순정 Good Lock 목표는 OEM Launcher3/SystemUI 유지이며 별도 런처 대체 금지. 본 APK는 HOME 카테고리를 선언하지 않고 순정 런처를 바꾸지 않는 연구 앱임.
- 최신 확인 연구: `STAGE101_DEEP_FINDINGS_KO.md` (내부 ID는 CAN ID 아님), `STAGE115_RESOURCE_DEEP_RESEARCH_KO.md` (순정 UI/독바 동작 미확정), `BYD_DOLPHIN_GOODLOCK_SPEC_20261013_KO.md`.
- 근거상 “실차 읽기/쓰기 권한 확보”, “실내등 전체 제어 성공”은 **아직 미검증**.


## ZIP 1개 + YAML 1개로 GitHub 빌드
1. 이 소스 ZIP (`Dolphin_InteriorLight_V2_Source.zip`)을 **압축하지 않고 그대로** 저장소 최상위에 업로드.
2. 별도 제공한 `build-apk.yml` 파일을 GitHub 경로 `.github/workflows/build-apk.yml`에 업로드/생성.
3. Actions → Build Dolphin Interior Light V2 APK → Run workflow. 업로드로 자동 실행될 수도 있음.
4. 성공 후 Actions 실행 화면 하단 Artifacts → `Dolphin-InteriorLight-V2-Test-APK`를 받아 압축을 풀고 `app-debug.apk`를 설치.
5. ZIP의 내부 파일은 Actions가 `.dolphin-build`에 자동 해제하므로 다른 Android 프로젝트가 저장소에 있어도 충돌을 피함.
6. 설치 테스트 후 앱 내부 JSON 리포트를 보내면 경로와 권한 결과를 대조 가능.
주의: 소스 정적 검사만 완료. Android APK 컴파일 및 실제 차량 제어 성공은 GitHub Actions/실차에서 확인 필요.
