# 실내등 One-Install Wizard V2 — 기존 연구/이슈 연결 기록 (2026-10-13)

## 정본 기준
- Library `/Dolphin Drive Alerts/00_MASTER_ISSUES.md` (2026-10-13 기록) 확인.
- **DA-004** 제조사 차량 권한/로컬 ADB 권한 차단: 이 빌드는 앱에 선언된 OEM 권한 상태만 검사하고 서명 우회나 ADB bootstrap을 하지 않음.
- **DA-013** GitHub Actions 빌드: `.github/workflows/build-apk.yml` 신규 독립 빌드 템플릿. 이 환경에서는 workflow 실행/컴파일 미수행.
- **DA-025** 순정 UI/안전: 펌웨어/순정 계기판/Home/AVAS/CAN 제어 불변; OEM 실내등 1회 제어 외 write 금지.
- **DA-029** 진단 증거: JSON 이벤트 이력, API 반환값과 실제 육안 확인 결과 분리.
- **DA-002** (참조, 독립): Good Lock 방식 순정 HOME 유지 목표. 이 연구 앱은 HOME 역할을 등록하지 않음.
- 신규 DA 번호를 임의 생성하지 않으며, 기존 파일을 덮어쓰지 않음.

## 확인한 최신 연구
- 50~69차: 통계적으로 많은 내부 data getter 상수 경로가 확인되어도 CAN ID나 권한 확보로 오인하지 않음.
- 101차: `GetDataItemWrapper` 내부 데이터 번호 24/25와 분기 매핑 확인 (차량 CAN ID 아님).
- 115차: 순정 Launcher3 CardBar/TPMS UI 구조 존재, OEM 실차 접근/쓰기 미검증.
- 2026-10-13 Good Lock 사양: 순정 Launcher3 및 SystemUI는 수정/대체하지 않고 합법적인 공개 인터페이스만 허용.
- 과거 실내등 SystemUI `InsightLightOnItem`가 `turnOffInsideLight(2)` 호출, `InsightLightOffItem` 메타데이터 존재, `insight_light_online` UI 기능 설정 조건 후보.
- 과거 Assistant 진단: `BYDAUTO_SETTING_COMMON` SecurityException, 실내등 명령 미성공.

## 알려진 접근 한계
- 현재 연결된 GitHub에서는 `heo1080/android-app` 조회 불가, `#47` 열람 불가.
- `s5c5wnnggr-stack/dolphin-drive-alerts`에 대한 create_branch 호출은 403 `Resource not accessible by integration`으로 거부됨.
- GitHub 원격 브랜치/PR/Issue/Actions에 이번 소스 **반영하지 못함**. 이슈 상태 변경이나 APK 빌드 완료로 주장하지 않음.
- 이 패키지는 정적 검사까지 완료. Android SDK 없는 로컬 환경에서 실제 APK 빌드 미실행. GitHub Actions에서 별도 수행 필요.
