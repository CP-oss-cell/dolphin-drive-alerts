package com.byd.dolphin.drivealerts.ui

import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentUris
import android.view.Gravity
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.config.AlertVolume
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.RotationPolicy
import com.byd.dolphin.drivealerts.dpi.SafeSettingsLauncher
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

/** v0.17.46 genuine dashboard. NO legacy menu, organizeUi(), view reparenting or duplicate links. */
class MainActivity : DensityAwareActivity() {
    private lateinit var unifiedCaptureStatus:TextView
    private val statusTiles=mutableMapOf<String,TextView>()
    private var adbCheckGeneration=0
    private var dashboardBack:(()->Unit)?={goHome()}
    private var detailVisible=false
    private lateinit var screen:LinearLayout
    private lateinit var scroller:ScrollView
    private val titles=listOf("주행 알림","시동 자동 실행","화면 · 분할 · DPI","오디오 · 내비","권한 · 로그 · 진단")
    private val summaries=listOf("기어 · 회생제동 · 노멀 · BSD · 음량","시동 감지 · 앱 실행 · 미디어 재생 · 종료","2앱 분할 · 비율 · 회전 · 선택 앱 DPI","운전석 스피커 · 내비 · 이퀄라이저","ADB · 앱 권한 · 로그 수집 · 안전 진단")

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        com.byd.dolphin.drivealerts.dpi.TemporaryAppDpiController.recoverOnStartup(this)
        if(AdbSetupActivity.shouldShowFirstRun(this)) {
            AdbSetupActivity.markFirstRunShown(this)
            AlertDialog.Builder(this).setTitle("최초 실행 · ADB 권한")
                .setMessage("분할 화면과 지정 앱 DPI에는 로컬 ADB 승인이 필요할 수 있습니다. 먼저 연결을 확인하시겠습니까?")
                .setPositiveButton("ADB 연결") { _,_->open(AdbSetupActivity::class.java) }
                .setNegativeButton("나중에",null).show()
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure { Toast.makeText(this,"주행 알림 서비스 시작 실패: ${it.message}",Toast.LENGTH_LONG).show() }
    }
    private fun open(type:Class<out android.app.Activity>) {
        runCatching { startActivity(Intent(this,type)) }
            .onFailure { Toast.makeText(this,"화면 열기 오류: ${it.javaClass.simpleName}",Toast.LENGTH_LONG).show() }
    }
    private fun dp(v:Int)=(resources.displayMetrics.density*v+.5f).toInt()
    private fun buildUi():View {
        scroller=ScrollView(this).apply{fillViewport=true;setBackgroundColor(DashboardUi.BACKGROUND)}
        screen=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(20))}
        scroller.addView(screen)
        showHome()
        return scroller
    }
    private fun addPanel(title:String,caption:String="",make:(LinearLayout)->Unit) {
        DashboardUi.addPanel(screen,this,DashboardUi.panel(this,title,caption,make))
    }
    private fun button(parent:LinearLayout,text:String,onClick:()->Unit) {
        parent.addView(DashboardUi.action(this,text,onClick), LinearLayout.LayoutParams(-1,dp(48)).apply { setMargins(0,dp(4),0,dp(4)) })
    }
    private fun toggle(parent:LinearLayout,text:String,on:Boolean,save:(Boolean)->Unit) {
        parent.addView(DashboardUi.toggle(this,text,on,save))
    }
    private fun hint(parent:LinearLayout,text:String) { parent.addView(DashboardUi.label(this,text,13f)) }
    private fun heading(text:String,sub:String="") {
        screen.addView(DashboardUi.label(this,text,26f,true))
        if(sub.isNotBlank())screen.addView(DashboardUi.label(this,sub,14f))
        screen.addView(DashboardUi.spacing(this))
    }
    private fun goHome() { detailVisible=false;showHome() }
    private fun resetScreen() { screen.removeAllViews();statusTiles.clear();++adbCheckGeneration }
    private fun showHome() {
        resetScreen();detailVisible=false
        heading("DOLPHIN DRIVE","주행보조 통합 대시보드 · v0.17.46")
        addPanel("차량 · 앱 상태","상태 표시는 기능별 실차 검증 여부를 뜻하지 않습니다."){panel ->
            val keys=listOf("서비스","자동실행","ADB","로그","회전","출력")
            keys.chunked(3).forEach { rowKeys ->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                rowKeys.forEach { key ->
                    val text=DashboardUi.label(this,"$key · 확인 중",13f).apply {
                        setTextColor(DashboardUi.TEXT);background=DashboardUi.bg(this@MainActivity,DashboardUi.PANEL_ALT)
                        gravity=Gravity.CENTER_VERTICAL
                    }
                    statusTiles[key]=text
                    row.addView(text,LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(2),dp(3),dp(2),dp(3))})
                }
                panel.addView(row)
            }
        }
        addPanel("빠른 실행","실차 진단에 필요한 버튼만 모았습니다."){p ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            listOf("수집 시작" to {performCapture(true)},"수집 종료" to {performCapture(false)},"ZIP 공유" to {shareLatestLogZip()}).forEach{(label,act)->
                row.addView(DashboardUi.action(this,label,act),LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(3),0,dp(3),0)})
            }
            p.addView(row)
        }
        heading("설정 메뉴","5개 영역으로 통합 · 예전 메뉴 화면 제거")
        // 10-inch 1280×720: 3 columns x 2 rows, all five menu cards at a glance.
        val columns=when {resources.configuration.screenWidthDp>=850->3
            resources.configuration.screenWidthDp>=500->2;else->1}
        titles.indices.chunked(columns).forEach { group ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            group.forEach{index->
                val tile=DashboardUi.panel(this,"0${index+1}    ${titles[index]}",summaries[index]) {p->
                    p.addView(DashboardUi.label(this,"설정 열기   ›",13f,true))
                }
                tile.isClickable=true;tile.isFocusable=true
                tile.setOnClickListener{showCategory(index+1)}
                row.addView(tile,LinearLayout.LayoutParams(0,dp(120),1f).apply {
                    setMargins(dp(4),dp(3),dp(4),dp(4))
                })
            }
            repeat(columns-group.size) { row.addView(View(this),LinearLayout.LayoutParams(0,1,1f)) }
            screen.addView(row)
        }
        hint(screen,"차량 안전 필수 표시와 순정 경고는 변경하지 않습니다. 일부 OEM 기능은 아직 실차 검증되지 않았습니다.")
        refreshDashboardStatus()
        scroller.post{scroller.scrollTo(0,0)}
    }
    private fun showCategory(id:Int) {
        resetScreen();detailVisible=true
        heading(titles[id-1],summaries[id-1])
        val back=DashboardUi.action(this,"‹  대시보드로 돌아가기"){goHome()}
        screen.addView(back)
        screen.addView(DashboardUi.spacing(this))
        when(id) {
            1->drivingCards()
            2->autostartCards()
            3->displayCards()
            4->audioCards()
            5->systemCards()
        }
        screen.addView(DashboardUi.action(this,"‹  메인으로"){goHome()})
        scroller.post{scroller.scrollTo(0,0)}
    }
    private fun drivingCards() {
        addPanel("주행 알림","기존 P/D/N/R·회생·오토홀드·주행모드·BSD 등 23종 기능 유지"){p->
            toggle(p,"주행보조 음성 알림",AlertPreferences.isEnabled(this)){AlertPreferences.setEnabled(this,it)}
            button(p,"23종 알림 개별 설정"){open(AlertEventSettingsActivity::class.java)}
        }
        addPanel("음성 출력 설정","차량 미디어와 순정 경고 음량은 바꾸지 않습니다."){p->
            val route=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
            val options=listOf("운전석" to OutputRoute.DRIVER_STREAM14,"운전석(raw)" to OutputRoute.DRIVER_RAW14,"미디어" to OutputRoute.MEDIA)
            options.forEach { (label,value)->
                route.addView(RadioButton(this).apply{
                    text=label;id=View.generateViewId();setTextColor(DashboardUi.TEXT)
                    isChecked=AlertPreferences.route(this@MainActivity)==value
                    setOnClickListener{AlertPreferences.setRoute(this@MainActivity,value)}
                })
            }
            p.addView(route)
            val styles=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
            listOf("여성" to AlertStyle.FEMALE,"남성" to AlertStyle.MALE,"효과음" to AlertStyle.EFFECT).forEach{(label,v)->
                styles.addView(RadioButton(this).apply{
                    text=label;id=View.generateViewId();setTextColor(DashboardUi.TEXT)
                    isChecked=AlertPreferences.style(this@MainActivity)==v
                    setOnClickListener{AlertPreferences.setStyle(this@MainActivity,v)}
                })
            }
            p.addView(styles)
        }
        addPanel("주행 알림 소리 크기","많이 작게 · 아주 작게 · 조금 작게 · 보통"){p->
            val radio=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
            AlertVolume.labels.forEachIndexed{index,label->
                radio.addView(RadioButton(this).apply{
                    text=label;id=View.generateViewId();setTextColor(DashboardUi.TEXT)
                    textSize=13f;isChecked=AlertVolume.tier(this@MainActivity)==index
                    setOnClickListener{AlertVolume.setTier(this@MainActivity,index)}
                })
            }
            p.addView(radio)
            hint(p,"보통도 기존 기준보다 크게 증폭하지 않습니다.")
        }
        addPanel("주행모드","NORMAL은 독립 확정 신호 미발견 · 기존 실험 옵션 유지"){p->
            toggle(p,"노멀 전환 후보 알림",AlertPreferences.normalNoticeCandidateEnabled(this)) {
                AlertPreferences.setNormalNoticeCandidateEnabled(this,it)
            }
            button(p,"에코 · 노멀 · 스포츠 신호 확인 (고급)"){open(DriveModeCalibrationActivity::class.java)}
        }
        addPanel("BSD 후측방","좌우 위험 방향은 아직 확정되지 않았습니다."){p->
            toggle(p,"BSD 감지 + 깜박이 알림",AlertPreferences.bsdBlinkerEnabled(this)){AlertPreferences.setBsdBlinkerEnabled(this,it)}
            toggle(p,"BSD 클릭음 보조 감지 · 실험",AlertPreferences.bsdTurnSoundExperimentalEnabled(this)){AlertPreferences.setBsdTurnSoundExperimentalEnabled(this,it)}
            toggle(p,"BSD 감지 즉시 알림",AlertPreferences.bsdInstantEnabled(this)){AlertPreferences.setBsdInstantEnabled(this,it)}
        }
        addPanel("핸들 · ADAS","순정 ADAS 경고 기능은 그대로 유지합니다."){p->
            toggle(p,"핸들 단발 음성 ON/OFF",SteeringTriggerPreferences.enabled(this)){SteeringTriggerPreferences.setEnabled(this,it)}
            hint(p,"차선이탈·앞차 출발·ICC 감지 로그는 기존 서비스에서 계속 수집합니다.")
        }
    }
    private fun autostartCards() {
        addPanel("주행보조 자동 시작","시동 상태에서 서비스 자동 실행"){p->
            toggle(p,"시동 시 주행보조 자동 실행",AlertPreferences.autoStartEnabled(this)){AlertPreferences.setAutoStartEnabled(this,it)}
        }
        addPanel("실행 앱 · 순서 · 음악 재생","시동 ON/OFF 규칙과 미디어 지연·백그라운드 실행을 한 곳에서 관리"){p->
            button(p,"자동 실행 앱 관리"){open(AutoLaunchSettingsActivity::class.java)}
        }
        addPanel("자동 실행 관련 권한"){p->
            button(p,"ADB·미디어 권한 확인"){open(AppPermissionManagerActivity::class.java)}
        }
    }
    private fun displayCards() {
        addPanel("2앱 화면 분할","프로필 · 실행 · 비율 · 바로가기 · 360 카메라 복원"){p->
            button(p,"화면 분할 설정"){open(SplitProfilesActivity::class.java)}
        }
        addPanel("DPI · 지정 앱","주행보조 자체 DPI는 앱별 적용. 지정 앱은 차량 전체 DPI를 임시 변경하므로 주의"){p->
            button(p,"앱 DPI 및 순정 앱 선택"){open(AppPolicyActivity::class.java)}
        }
        addPanel("화면 회전"){p->
            toggle(p,"화면 회전 기능 사용",RotationPolicy.enabled(this)){
                RotationPolicy.setEnabled(this,it)
            }
            button(p,"화면 위 표시 권한"){SafeSettingsLauncher.open(this,Settings.ACTION_MANAGE_OVERLAY_PERMISSION,true)}
        }
    }
    private fun audioCards() {
        addPanel("내비 음성 · 운전석 스피커","내비 UID 단독 출력과 미디어 음소거는 실차 미확정"){p->
            button(p,"내비 오디오 경로 진단"){open(NavAudioLabActivity::class.java)}
            com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.forEach{entry->
                toggle(p,entry.title,com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.enabled(this,entry.pkg)){
                    com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.setEnabled(this,entry.pkg,it)
                }
            }
            hint(p,"위 체크는 대상 저장만 수행합니다. 실제 단독 스피커 출력 성공을 뜻하지 않습니다.")
        }
        addPanel("이퀄라이저 · 음장"){p->
            button(p,"저음 · 중음 · 고음 · Sound Focus"){open(AudioTuningActivity::class.java)}
        }
    }
    private fun systemCards() {
        addPanel("ADB · 권한","기능별 권한 확인 및 복원"){p->
            button(p,"차량 로컬 ADB 연결"){open(AdbSetupActivity::class.java)}
            button(p,"앱 권한 관리"){open(AppPermissionManagerActivity::class.java)}
            button(p,"ADB 필수 권한 적용"){
                Thread {
                    val msg=runCatching{com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper.apply(applicationContext).lines.joinToString("\n")}
                        .getOrElse{"권한 검사 오류: ${it.message}"}
                    runOnUiThread{if(!isFinishing&&!isDestroyed)AlertDialog.Builder(this).setTitle("ADB 권한 검증").setMessage(msg).setPositiveButton("확인",null).show()}
                }.start()
            }
        }
        addPanel("통합 로그","수집은 두 버튼만 사용하고, 저장 결과는 Downloads에 ZIP으로 남습니다."){p->
            unifiedCaptureStatus=DashboardUi.label(this,"로그 상태 확인 중",14f)
            p.addView(unifiedCaptureStatus);updateCaptureStatus()
            button(p,"① 로그 수집 시작"){performCapture(true);updateCaptureStatus()}
            button(p,"② 로그 수집 종료 · ZIP 저장"){performCapture(false);updateCaptureStatus()}
            button(p,"최근 ZIP 공유"){shareLatestLogZip()}
            button(p,"자동 점검 (읽기 전용)"){runReadOnlyAutoCheck()}
        }
        addPanel("차량 오디오 · 외부 AVAS 연구","외부 스피커 송신 명령 없음. 순정 기능은 읽기만 합니다."){p->
            button(p,"순정 내비 음성 구간 기록"){DrivingAlertService.captureQuick(this,"2602_OEM_NAV_GUIDANCE")}
            button(p,"타사 내비 음성 구간 기록"){DrivingAlertService.captureQuick(this,"2602_THIRD_PARTY_NAV_GUIDANCE")}
            button(p,"순정 보행자 경고음 설정 구간 기록 (12초)"){DrivingAlertService.captureWindow(this,"2602_AVAS_STOCK_SETTING",12)}
        }
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() { if(detailVisible)dashboardBack?.invoke()?:goHome() else super.onBackPressed() }
    private fun performCapture(start: Boolean) {
        runCatching {
            if (start) DrivingAlertService.beginUnifiedCapture(this)
            else DrivingAlertService.endUnifiedCapture(this)
        }.onSuccess {
            Toast.makeText(this, if (start) "수집 시작 요청 전달" else "수집 종료 · ZIP 저장 요청 전달", Toast.LENGTH_SHORT).show()
            refreshDashboardStatus()
            // Service status is asynchronous. Never claim the request already succeeded.
        }.onFailure { Toast.makeText(this, "요청 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    private fun refreshDashboardStatus() {
        if (statusTiles.isEmpty()) return
        val alive = DrivingAlertService.activeLogger != null
        statusTiles["서비스"]?.text = if (alive) "서비스 · 프로세스 활성" else "서비스 · 확인 필요"
        statusTiles["자동실행"]?.text = "자동실행 · ${if (AlertPreferences.autoStartEnabled(this)) "ON" else "OFF"}"
        val record = UnifiedLogCapture.state(this)
        statusTiles["로그"]?.text = "로그 · ${when (record.status) {
            UnifiedLogCapture.RECORDING -> "수집 중"
            UnifiedLogCapture.SAVING -> "저장 중"
            UnifiedLogCapture.FAILED -> "저장 실패"
            else -> "대기"
        }}"
        statusTiles["회전"]?.text = "회전 · ${if (RotationPolicy.enabled(this)) "ON" else "OFF"}"
        statusTiles["출력"]?.text = "출력 · ${when (AlertPreferences.route(this)) {
            OutputRoute.MEDIA -> "미디어"
            OutputRoute.DRIVER_RAW14 -> "운전석 raw14"
            else -> "운전석 stream14"
        }}"
        statusTiles["ADB"]?.text = "ADB · 확인 중"
        val generation = ++adbCheckGeneration
        Thread({
            val result = runCatching { AuthorizedAdbRuntime.health(applicationContext).state }.getOrNull()
            runOnUiThread {
                if (isFinishing || isDestroyed || generation != adbCheckGeneration) return@runOnUiThread
                statusTiles["ADB"]?.text = "ADB · ${when (result) {
                    AuthorizedAdbRuntime.State.READY -> "인증 완료"
                    AuthorizedAdbRuntime.State.AUTH_REQUIRED -> "승인 필요"
                    AuthorizedAdbRuntime.State.PORT_CLOSED -> "연결 안 됨"
                    AuthorizedAdbRuntime.State.PERMISSION_DENIED -> "권한 부족"
                    else -> "확인 불가"
                }}"
            }
        }, "dashboard-adb-readonly").start()
    }

    private fun runReadOnlyAutoCheck() {
        val installed = com.byd.dolphin.drivealerts.dpi.ExternalAppAudioRouter.NAVIGATION_APPS.map { app ->
            val exists = runCatching {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(app.pkg, 0) != null
            }.getOrDefault(false)
            "${app.title}: ${if (exists) "설치 확인" else "미설치/조회 불가"}"
        }
        val audio = getSystemService(android.content.Context.AUDIO_SERVICE) as? android.media.AudioManager
        val devices = runCatching {
            audio?.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)?.joinToString(", ") {
                "${it.type}:${it.productName}"
            }.orEmpty()
        }.getOrDefault("")
        val message = buildString {
            val events = com.byd.dolphin.drivealerts.model.AlertEventCatalog.entries
            val active = events.count { AlertPreferences.eventEnabled(this@MainActivity, it.event) }
            appendLine("추가 음성 23종: 사용자 허용 $active / ${events.size} (발화 성공 의미 아님)")
            appendLine("내비 타사 UID 운전석 단독 출력: 구현 미확정 · 원본 미디어 출력 제어 불가")
            appendLine("분할 비율/복원: 실제 Task bounds readback 필요")
            appendLine("타사 앱 DPI: 임시 전역 변경 규칙(사용자 동의/ADB 필요) · 진짜 독립 앱 DPI는 미지원")
            appendLine("NORMAL: 보조 후보=${AlertPreferences.normalNoticeCandidateEnabled(this@MainActivity)} (364+에코/스포츠 교차확인, 실차 미확정)")
            appendLine("음성 볼륨: ${com.byd.dolphin.drivealerts.config.AlertVolume.labels[com.byd.dolphin.drivealerts.config.AlertVolume.tier(this@MainActivity)]}")
            appendLine("BSD 좌우/ADAS: 실차 신호 판정 미완료 · 순정 안전 기능 유지")
            appendLine("Android SDK: ${android.os.Build.VERSION.SDK_INT}")
            appendLine("부팅 자동 실행: ${AlertPreferences.autoStartEnabled(this@MainActivity)}")
            appendLine("전역 회전: ${RotationPolicy.enabled(this@MainActivity)}")
            appendLine("로그 상태: ${UnifiedLogCapture.state(this@MainActivity).status}")
            appendLine("후측방 1번: ${AlertPreferences.bsdBlinkerEnabled(this@MainActivity)}")
            appendLine("후측방 2번: ${AlertPreferences.bsdTurnSoundExperimentalEnabled(this@MainActivity)}")
            appendLine("후측방 3번: ${AlertPreferences.bsdInstantEnabled(this@MainActivity)}")
            appendLine("\n내비 5종 설치 확인\n${installed.joinToString("\n")}")
            appendLine("\n오디오 출력장치: ${devices.ifBlank { "조회 불가" }}")
            appendLine("\n이것은 읽기 전용 상태 점검입니다. 실제 차량 신호 발화/오디오 라우팅의 성공 여부는 판정하지 않습니다.")
        }
        AlertDialog.Builder(this).setTitle("자동 점검 결과")
            .setMessage(message).setPositiveButton("확인", null).show()
        // Add a corresponding snapshot only when capture is already enabled.
        if (UnifiedLogCapture.state(this).status == UnifiedLogCapture.RECORDING) {
            runCatching { DrivingAlertService.captureQuick(this, "USER_AUTOMATED_READONLY_CHECK") }
        }
    }

    private fun shareLatestLogZip() {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            AlertDialog.Builder(this).setTitle("로그 공유")
                .setMessage("Android 9 이하에서는 다운로드 폴더의 파일 관리자에서 DolphinDriveLogs_ ZIP을 선택해 공유하세요.")
                .setPositiveButton("확인", null).show()
            return
        }
        val uri = runCatching {
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("DolphinDriveLogs_%.zip")
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    ContentUris.withAppendedId(collection, cursor.getLong(0))
                } else null
            }
        }.getOrNull()
        if (uri == null) {
            AlertDialog.Builder(this).setTitle("로그 ZIP 없음")
                .setMessage("먼저 수집 시작 → 필요한 테스트 → 수집 종료를 완료하세요. ZIP 저장이 끝나면 다시 공유할 수 있습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(Intent.createChooser(intent, "실차 로그 ZIP 공유")) }
            .onFailure { Toast.makeText(this, "공유 앱 열기 실패: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
        refreshDashboardStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 재시동 후 같은 세션 복구 시도 (전원 OFF 구간은 누락 가능) · '수집 종료'로 ZIP 저장"
            UnifiedLogCapture.SAVING -> "저장 중 · 완료되면 상단 알림으로 안내"
            UnifiedLogCapture.FAILED -> "저장 실패 · '수집 종료'를 다시 눌러 재시도"
            else -> "대기 중 · '수집 시작'을 눌러주세요"
        }
    }

}
