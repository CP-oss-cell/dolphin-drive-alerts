# 믿음하나 브라우저 v2.1.2 — 최초 설치와 향후 업데이트

이번 버전은 기존 앱을 삭제한 뒤 새로 설치하는 서명 기준본입니다. Debug APK는 생성하지 않으며, 개인 Release 키스토어 설정이 필요합니다.

## 업데이트 가능한 Release APK 빌드 — 최초 1회 설정

1. 본인이 관리하는 PC에서 JDK의 `keytool`로 **개인 전용** 키스토어를 생성합니다.

```bash
keytool -genkeypair -v -keystore MideumHanaBrowser-release.jks -storetype PKCS12 -alias mideumhana -keyalg RSA -keysize 3072 -validity 10000
```

생성 과정에서 비밀번호를 정해 보관하고 키 비밀번호도 동일하게 둡니다. 키스토어 파일과 비밀번호는 **다른 사람에게 보내거나 GitHub 저장소에 올리지 마세요.**

2. 키스토어를 Base64로 변환합니다.

Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path '.\MideumHanaBrowser-release.jks')))
```

macOS/Linux:

```bash
base64 < MideumHanaBrowser-release.jks | tr -d '\n'
```

3. GitHub 저장소 `Settings → Secrets and variables → Actions → New repository secret`에서 아래 **두 항목 모두** 등록합니다.

- `MHB_KEYSTORE_BASE64` : 2단계 Base64 문자열
- `MHB_KEYSTORE_PASSWORD` : 키스토어 생성 시 비밀번호

4. Actions 워크플로를 실행하면 자동으로 **Release APK**를 빌드하고 Artifact 이름에 `Release`가 표시됩니다.

이후 버전에서도 **패키지 ID `com.mideumhana.browser`, 동일 서명키와 alias, 증가하는 versionCode**를 유지해야 삭제 없이 업데이트할 수 있습니다.
키스토어 원본과 비밀번호는 안전하게 별도 백업하세요. 키를 잃으면 기존 설치본의 업데이트가 불가능해질 수 있습니다.

## 중요한 구분

- Secret 두 개 모두 없음 → 빌드 중단 (v2.1.2는 정식 서명 APK만 생성)
- Secret 두 개 모두 있음 → `Release APK` 빌드 (이후 업데이트는 동일 인증서 필요)
- Secret 한 개만 있음 → 오류 메시지를 표시하고 중단

서명키를 소스 코드나 통합 ZIP에 동봉하지 않습니다.

## v2.1.2 설치 기준본 (중요)

- 기존 설치본을 **한 번 삭제하고**, 같은 GitHub Secrets에서 서명한 v2.1.2 **Release APK**를 설치하세요.
- GitHub Secrets와 개인 키스토어 파일은 **절대 삭제하지 말고** 백업하세요.
- v2.1.3 이상은 동일 키스토어+alias(`mideumhana`)+암호, 동일 `applicationId`, 더 높은 `versionCode`를 사용해야 업데이트할 수 있습니다.
- 이 패키지는 서명키를 포함하지 않습니다. 최초 빌드 전에 Secrets 두 항목을 반드시 등록해야 하며, 미등록 시 실패하는 것이 정상입니다.
