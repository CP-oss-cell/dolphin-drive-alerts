믿음하나 브라우저 v2.1.2: 링크 길게 누르기, 퀵 탭 1/2/3, 배경 탭 URL 복원. Release 전용. 로컬 Java 구문/XML 검사 통과. Android APK 컴파일/실기기 검증 미완료.
