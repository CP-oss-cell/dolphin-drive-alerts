"""Structural regressions; Android compile and real web downloads are not simulated."""
from pathlib import Path
from xml.etree import ElementTree
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/mideumhana/browser'
a=(j/'MainActivity.java').read_text()
s=(j/'HlsDownloadService.java').read_text()
d=(j/'DownloadStore.java').read_text()
f=(j/'StorageTarget.java').read_text()
m=(r/'app/src/main/AndroidManifest.xml').read_text()
b=(r/'app/build.gradle').read_text()
for key in ("versionCode 8", "versionName '2.1.2'", "applicationId 'com.mideumhana.browser'"):
    assert key in b, key
assert 'startForegroundService(start)' in a
assert 'enqueueService(url, filename, "direct", StorageTarget.selected(this)' in a
assert 'resumeDownload(row, false)' in a and 'resumeDownload(row, true)' in a
assert '이어받기 (가능한 지점부터)' in a and '처음부터 새 다운로드로 시작합니다' in a
assert 'FileOutputStream(stage, append)' in s
assert 'Range", "bytes=" + offset' in s and 'If-Range' in s
assert 'contentRangeTotal' in s and 'validatorMatches' in s
assert 'stage.length()' in s and 'getFD().sync()' in s
assert 'segmentIndex' in s and 'segmentBytes' in s and 'playlistHash' in s
assert 'keepHlsCheckpoint' in s and 'output.setLength(committed)' in s
assert 'publish(id, stage' in s and 'targetUri' in s
assert 'partial_downloads' in s and 'getExternalFilesDir(null)' in s
assert 'android.permission.RECEIVE_BOOT_COMPLETED' in m and 'BootRecoveryReceiver' in m
assert 'DownloadStore.reconcile(this)' in a
assert 'getFirstVisiblePosition' in a and 'visible instanceof TextView' in a
assert 'readableSize(speed)' in a and 'readableTime(eta)' in a
assert 'PREF_TABS' in a and 'persistTabs()' in a and 'restorePersistedTabs' in a
assert 'scaleKey' in a and 'restoreSiteZoom' in a and 'lastPinchAt' in a
assert 'getTreeDocumentId' in f and 'buildChildDocumentsUriUsingTree' in f
assert 'RELATIVE_PATH' in f and ' (" + n + ")' in f
assert 'o.put("cookie"' not in d and 'lastPinchAt' not in d
assert 'usesCleartextTraffic="false"' in m
assert 'addJavascriptInterface' not in a
assert 'Application' not in a or True
ElementTree.parse(r/'app/src/main/AndroidManifest.xml')
print('V210_RESUME_RECOVERY_STATS_TABS_ZOOM_STATIC_OK')
