from pathlib import Path
r=Path(__file__).resolve().parents[1]
b=(r/'app/build.gradle').read_text()
s=(r/'SIGNING_SETUP_KO.md').read_text()
assert "versionCode 8" in b and "versionName '2.1.2'" in b
assert "applicationId 'com.mideumhana.browser'" in b
assert "keyAlias 'mideumhana'" in b
assert 'MHB_KEYSTORE_BASE64' in s and 'MHB_KEYSTORE_PASSWORD' in s
assert 'Debug APK' in s and 'Release APK' in s
print('V202_SIGNING_MODE_REGRESSION_OK')
