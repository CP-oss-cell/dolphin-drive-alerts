# Dolphin 실내등 V2.2 — 연구/기존 이슈 연결 (신규 번호 발급 없음)

- 기반: 2026-10-14 실차 Wizard V2 JSON. `insight_light_online=0`, BYD_SETTING_COMMON/GET/SET false, `turnOffInsideLight(int)`/`()`, SystemUI exported=0 (조사된 리소스 overlay 후보에 한정), OEM get-method name exists (METADATA_ONLY).
- 2026-09-05 `SystemUIWithLegacyRecents.apk` dexdump: `InsightLightOnItem.onItemClick -> turnOffInsideLight(2)` 호출, ON/OFF 클래스 존재. `getInitInsightLightOnlineState`: `online==0 && isCanFd` else false, `getIsShowAllItems()`는 버튼 표시 조건에 사용되지만 하드웨어 제어 권한 입증 아님.
- 기존 마스터 이슈 `/Dolphin Drive Alerts/00_MASTER_ISSUES.md`: DA-004(권한), DA-013(GitHub Actions), DA-025(순정 안전), DA-029(증거 로그); Good Lock 관련 DA-002와는 별도 독립 진단 앱으로 유지. `DA-004` 이전 ADB 403/EPERM 및 제조사 서명 권한 미승인을 우회하지 않음.
- V2.2 변경: 실제 OEM getter 호출·오류 분류·타임아웃·일괄 read-only 검사, SystemUI 코드/overlay 구별, BYD 권한 보호등급 실제 질의, CarSettings gate 값/`isCanFd UNKNOWN` 동시 기록, JSON 내보내기 유지.
- 상태: `SOURCE_READY / JAVA_SYNTAX_PASS / STATIC_GATE_PASS / ANDROID_CI_PENDING / REALCAR_VERIFY_REQUIRED`. 실내등 제어 성공 주장 금지.
