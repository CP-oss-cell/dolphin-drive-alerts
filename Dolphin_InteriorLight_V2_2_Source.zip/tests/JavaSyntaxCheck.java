import java.util.Arrays;
import javax.tools.*;
import com.sun.source.util.JavacTask;
public final class JavaSyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null) throw new IllegalStateException("JavaCompiler missing");
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null);
        Iterable<? extends JavaFileObject> files=manager.getJavaFileObjectsFromStrings(Arrays.asList(args));
        JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,Arrays.asList("-proc:none"),null,files);
        task.parse();
        for(Diagnostic<? extends JavaFileObject> d:diagnostics.getDiagnostics()) System.out.println(d.toString());
        if(diagnostics.getDiagnostics().stream().anyMatch(d->d.getKind()==Diagnostic.Kind.ERROR)) System.exit(1);
        System.out.println("JAVA_PARSER_OK " + args.length + " source files");
    }
}
