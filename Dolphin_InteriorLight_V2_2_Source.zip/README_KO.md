# BYD Dolphin 실내등 One-Install Wizard V2.2 (2602 기준)

## 이번 실차 V2 로그의 정답
- `BYDAutoSettingDevice`, `turnOffInsideLight(int)`, `turnOffInsideLight()` 발견: **메서드 존재**. 실제 차량 제어 성공 아님.
- `insight_light_online=0` 읽기 성공. 순정 SystemUI `getInitInsightLightOnlineState()` 정적 역분석상 0과 `isCanFd=true`가 결합될 때 버튼 초기화 조건 충족. **isCanFd 값은 미확인**이며 외부 앱이 이를 읽을 수 있다는 증거 없음.
- `BYDAUTO_SETTING_COMMON / GET / SET` 모두 거부. 이전 실차 V30에서 SecurityException. 명령 요청을 반복해도 권한이 생기지 않음.
- `com.android.systemui.overlay.common`은 코드 구현과 구별해야 할 리소스 오버레이 후보이며 V2가 이 패키지를 대표 SystemUI로 잘못 선택한 문제를 보완.

## 개선: 한 번 설치하고 실제 읽기 검사
1. **1 환경**: '모든 핵심 항목 1회 연속 검사 (읽기 전용)'를 누르면 권한 보호등급→CarSettings 값→SystemUI 후보→OEM 조회 4개가 이어서 검사됨.
2. **2 후보**: 메서드를 하나 선택하면 메서드 이름뿐 아니라, 접근 허용되는 경우 실제 `get...()` 리턴값을 볼 수 있음. 별도로 4개 일괄 조회 가능.
3. **3 경로**: 정확한 읽기 화이트리스트인 무인수 int/boolean getter만 호출. 허용되지 않는 메서드/쓰기 메서드는 자동 호출 없음. 각 OEM getter는 최대 8초, 일괄 조회는 최대 12초까지 화면 기다림 (실제 Binder 호출 취소는 보장하지 못함).
4. **4 결과**: 반환값 / SecurityException / 기타 오류 / 타임아웃 및 시간 이력 분리. JSON 다운로드 저장/내부 백업/파일 공유/복사 유지.
5. 독립적으로 `turnOffInsideLight(int)`의 시그니처 확인 가능하나 쓰기 명령은 **BYDAUTO_SETTING_COMMON과 BYDAUTO_SETTING_SET가 모두 허용된 경우에만**, 사용자가 정차 후 1회 동의해야 호출 가능. *명령 반환값은 물리 실내등 ON/OFF 성공을 뜻하지 않음.*

## 사용자가 해야 하는 단계
- 차량 정차, P단 및 주차브레이크.
- 화면 `1 환경 → 모든 핵심 항목 1회 연속 검사 (읽기 전용)`.
- `4 결과 → 로그 저장` 또는 `로그 파일 공유`. 실패 시 '진단 리포트 복사'.
- JSON을 ChatGPT에 업로드. `isCanFd`가 UNKNOWN인 상태에서 순정 설정 `insight_light_online`을 임의로 쓰지 않음.

## GitHub 저장소 최상위 업로드 파일은 **2개**만
1. `Dolphin_InteriorLight_V2_2_Source.zip` — 압축을 풀지 말고 저장소 최상위에 업로드.
2. `build-apk.yml` — 저장소의 `.github/workflows/build-apk.yml`로 업로드/교체.

GitHub → Actions → `Build Dolphin Interior Light V2.2` → `Run workflow` 실행. 성공 시 `Dolphin-InteriorLight-V2-2-APK` Artifact에 `app-debug.apk` 및 SHA256 텍스트가 있음. 빌드 오류일 때 `Dolphin-InteriorLight-V2-2-Build-Diagnostics` artifact를 전달.

**주의: GitHub Actions의 기본 디버그 서명은 실행마다 달라질 수 있습니다.** 설치 시 서명이 일치하지 않으면 업그레이드 설치가 실패할 수 있습니다. V2.1 기록을 먼저 공유/복사하세요. 기존 앱 삭제 시 로컬 기록은 사라집니다.

## 검증 수준
소스 Java 파싱 및 정적 안전성 검사만 이 환경에서 완료 가능. Android SDK/Gradle의 실제 APK 빌드와 실차 정상 실행은 GitHub Actions 및 차량에서 확인해야 함.

기존 순정 SystemUI·Launcher3/계기판/차량 설정을 변경하지 않음. ADB 권한 우회·루트·CAN 송신·임의 셋터/인수 실행 없음. `getAirLight*`, `getInsBacklightCtl` 등의 이름이 실내등 전체 ON/OFF와 직접 연관되어 있다는 근거는 없으며, 로우 getter 값을 그 기능의 성공으로 해석하지 않음.
