package com.byd.dolphin.drivealerts.camera

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import com.byd.dolphin.drivealerts.util.CoreLog
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.atan
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Clean-Room OpenGL ES 3.0 (with ES 2.0 fallback) GPU LUT Dewarp, Sharpness & Color-Grading Pipeline.
 *
 * Key design principles:
 * - Zero-copy camera intake via GL_OES_EGL_image_external (SurfaceTexture -> samplerExternalOES).
 * - Precomputed 2D radial fisheye-dewarp + perspective tilt/pan/zoom/quadrant LUT texture so
 *   edge sharpness and wide FOV are preserved with near-zero per-frame math overhead.
 * - Single-pass GPU color grading (Brightness, Contrast, Saturation, Gamma) + 5-tap unsharp-mask
 *   sharpness filter directly on the external OES texture.
 * - Optional dual-output EGL_RECORDABLE_ANDROID encoder Surface so a single AVMCamera session can
 *   render to both a live BVM overlay and a hardware H.264 dashcam MediaRecorder simultaneously.
 */
class GlLutDewarpRenderer(private val tagName: String = "GL_LUT") {
    data class Params(
        val quadCrop: Int = 2,          // 0=full, 1=half-LR, 2=4-quadrant AVM
        val quadrantIndex: Int = 0,     // 0=front(TL), 1=right(TR), 2=rear(BL), 3=left(BR)
        val mirrorX: Boolean = false,
        val flipY: Boolean = false,
        val rotationDeg: Float = 0f,
        val tiltDeg: Float = 0f,
        val zoom: Float = 1.12f,        // 0.80 .. 2.20
        val panX: Float = 0f,           // -0.40 .. +0.40
        val panY: Float = 0f,           // -0.40 .. +0.40
        val fisheyeK: Float = 0.24f,    // 0.00 .. 0.65 radial barrel dewarp strength
        val brightness: Float = 0.04f,  // -0.40 .. +0.40
        val contrast: Float = 1.12f,    // 0.60 .. 1.80
        val saturation: Float = 1.10f,  // 0.00 .. 2.00
        val gamma: Float = 0.96f,       // 0.65 .. 1.50
        val sharpness: Float = 0.35f    // 0.00 .. 1.00 unsharp-mask strength
    )

    private var glThread: HandlerThread? = null
    private var glHandler: Handler? = null

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglConfig: EGLConfig? = null
    private var pbufferSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var displaySurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encoderSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var analysisSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    @Volatile private var analysisGate: () -> Boolean = { false }
    @Volatile private var analysisConsumer: ((Bitmap) -> Unit)? = null
    @Volatile private var lastAnalysisMs: Long = 0L
    private val analysisPixels: ByteBuffer = ByteBuffer.allocateDirect(320 * 240 * 4).order(ByteOrder.nativeOrder())
    private var isEs3 = false

    private var oesTexId = 0
    private var lutTexId = 0
    private var frontLutTexId = 0
    private var fullLutTexId = 0
    private var programId = 0
    private var cameraTexture: SurfaceTexture? = null
    private var cameraInputSurface: Surface? = null

    private var dispW = 640
    private var dispH = 360
    private var encW = 1280
    private var encH = 720
    private val stMatrix = FloatArray(16)

    @Volatile private var params = Params()
    @Volatile private var lutDirty = true
    @Volatile private var released = false

    private val quadVertices: FloatBuffer = ByteBuffer.allocateDirect(16 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            // x, y, u, v
            put(floatArrayOf(
                -1f, -1f, 0f, 0f,
                 1f, -1f, 1f, 0f,
                -1f,  1f, 0f, 1f,
                 1f,  1f, 1f, 1f
            ))
            position(0)
        }

    fun updateParams(newParams: Params) {
        if (newParams != params) {
            val geomChanged = newParams.quadCrop != params.quadCrop ||
                newParams.quadrantIndex != params.quadrantIndex ||
                newParams.mirrorX != params.mirrorX ||
                newParams.flipY != params.flipY ||
                newParams.rotationDeg != params.rotationDeg ||
                newParams.tiltDeg != params.tiltDeg ||
                newParams.zoom != params.zoom ||
                newParams.panX != params.panX ||
                newParams.panY != params.panY ||
                newParams.fisheyeK != params.fisheyeK
            params = newParams
            if (geomChanged) lutDirty = true
        }
    }

    /**
     * Initialize EGL context and create the camera input Surface.
     * Callback receives the ready input Surface on the GL thread.
     */
    fun start(
        outputWindowSurface: Surface?,
        outputWidth: Int,
        outputHeight: Int,
        onInputSurfaceReady: (Surface) -> Unit,
        onError: (String) -> Unit
    ) {
        released = false
        dispW = outputWidth.coerceAtLeast(64)
        dispH = outputHeight.coerceAtLeast(64)
        glThread = HandlerThread("gl-lut-$tagName").apply { start() }
        glHandler = Handler(glThread!!.looper)
        glHandler?.post {
            runCatching {
                initEgl(outputWindowSurface)
                initProgram()
                initTextures()
                rebuildLutIfNeeded()
                val st = SurfaceTexture(oesTexId).apply {
                    setDefaultBufferSize(5120, 960)
                    setOnFrameAvailableListener({ renderFrame() }, glHandler)
                }
                cameraTexture = st
                val surf = Surface(st)
                cameraInputSurface = surf
                onInputSurfaceReady(surf)
            }.onFailure { e ->
                CoreLog.w(tagName, "GL init failed: ${e.message}", e)
                onError("${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** Attach a hardware MediaRecorder/MediaCodec Surface for Zero-Copy GPU dashcam encoding. */
    fun attachEncoderSurface(surface: Surface, width: Int, height: Int) {
        glHandler?.post {
            if (released || eglDisplay == EGL14.EGL_NO_DISPLAY || eglConfig == null) return@post
            detachEncoderSurfaceInternal()
            encW = width.coerceAtLeast(320)
            encH = height.coerceAtLeast(240)
            encoderSurface = EGL14.eglCreateWindowSurface(
                eglDisplay, eglConfig, surface, intArrayOf(EGL14.EGL_NONE), 0
            )
        }
    }

    fun detachEncoderSurface() {
        glHandler?.post { detachEncoderSurfaceInternal() }
    }

    fun attachDisplaySurface(surface: Surface, width: Int, height: Int) {
        glHandler?.post {
            if (released || eglDisplay == EGL14.EGL_NO_DISPLAY || eglConfig == null) return@post
            detachDisplaySurfaceInternal()
            dispW = width.coerceAtLeast(64)
            dispH = height.coerceAtLeast(64)
            if (surface.isValid) {
                displaySurface = EGL14.eglCreateWindowSurface(eglDisplay, eglConfig, surface, intArrayOf(EGL14.EGL_NONE), 0)
            }
        }
    }

    fun detachDisplaySurface() {
        glHandler?.post { detachDisplaySurfaceInternal() }
    }

    fun setAnalysisConsumer(gate: () -> Boolean, consumer: ((Bitmap) -> Unit)?) {
        analysisGate = gate
        analysisConsumer = consumer
    }

    private fun detachDisplaySurfaceInternal() {
        if (displaySurface != EGL14.EGL_NO_SURFACE && displaySurface != pbufferSurface && eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglDestroySurface(eglDisplay, displaySurface)
        }
        displaySurface = EGL14.EGL_NO_SURFACE
    }

    fun release() {
        released = true
        val h = glHandler
        val t = glThread
        glHandler = null
        glThread = null
        h?.post {
            runCatching {
                cameraTexture?.setOnFrameAvailableListener(null)
                cameraInputSurface?.release(); cameraInputSurface = null
                cameraTexture?.release(); cameraTexture = null
                detachEncoderSurfaceInternal()
                detachDisplaySurfaceInternal()
                if (analysisSurface != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglDestroySurface(eglDisplay, analysisSurface)
                    analysisSurface = EGL14.EGL_NO_SURFACE
                }
                if (pbufferSurface != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglDestroySurface(eglDisplay, pbufferSurface)
                    pbufferSurface = EGL14.EGL_NO_SURFACE
                }
                if (programId != 0) { GLES20.glDeleteProgram(programId); programId = 0 }
                if (oesTexId != 0) { GLES20.glDeleteTextures(1, intArrayOf(oesTexId), 0); oesTexId = 0 }
                if (lutTexId != 0) { GLES20.glDeleteTextures(1, intArrayOf(lutTexId), 0); lutTexId = 0 }
                if (frontLutTexId != 0) { GLES20.glDeleteTextures(1, intArrayOf(frontLutTexId), 0); frontLutTexId = 0 }
                if (fullLutTexId != 0) { GLES20.glDeleteTextures(1, intArrayOf(fullLutTexId), 0); fullLutTexId = 0 }
                if (eglContext != EGL14.EGL_NO_CONTEXT) {
                    EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                    EGL14.eglDestroyContext(eglDisplay, eglContext)
                    eglContext = EGL14.EGL_NO_CONTEXT
                }
                if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                    EGL14.eglTerminate(eglDisplay)
                    eglDisplay = EGL14.EGL_NO_DISPLAY
                }
            }
            runCatching { t?.quitSafely() }
        }
    }

    private fun detachEncoderSurfaceInternal() {
        if (encoderSurface != EGL14.EGL_NO_SURFACE && eglDisplay != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglDestroySurface(eglDisplay, encoderSurface)
            encoderSurface = EGL14.EGL_NO_SURFACE
        }
    }

    private fun initEgl(windowSurface: Surface?) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(eglDisplay, ver, 0, ver, 1)) error("eglInitialize failed")

        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR or EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(eglDisplay, attrs, 0, configs, 0, 1, num, 0) || num[0] <= 0) {
            error("eglChooseConfig failed")
        }
        eglConfig = configs[0]

        // Prefer OpenGL ES 3.0, fallback cleanly to ES 2.0
        val ctx3 = EGL14.eglCreateContext(
            eglDisplay, eglConfig, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        if (ctx3 != null && ctx3 != EGL14.EGL_NO_CONTEXT) {
            eglContext = ctx3
            isEs3 = true
        } else {
            eglContext = EGL14.eglCreateContext(
                eglDisplay, eglConfig, EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            isEs3 = false
        }

        pbufferSurface = EGL14.eglCreatePbufferSurface(
            eglDisplay, eglConfig,
            intArrayOf(EGL14.EGL_WIDTH, 16, EGL14.EGL_HEIGHT, 16, EGL14.EGL_NONE), 0
        )
        analysisSurface = EGL14.eglCreatePbufferSurface(
            eglDisplay, eglConfig,
            intArrayOf(EGL14.EGL_WIDTH, 320, EGL14.EGL_HEIGHT, 240, EGL14.EGL_NONE), 0
        )
        displaySurface = if (windowSurface != null && windowSurface.isValid) {
            EGL14.eglCreateWindowSurface(eglDisplay, eglConfig, windowSurface, intArrayOf(EGL14.EGL_NONE), 0)
        } else {
            EGL14.EGL_NO_SURFACE
        }
        val initialSurf = if (displaySurface != EGL14.EGL_NO_SURFACE) displaySurface else pbufferSurface
        if (!EGL14.eglMakeCurrent(eglDisplay, initialSurf, initialSurf, eglContext)) {
            error("eglMakeCurrent failed")
        }
    }

    private fun initProgram() {
        val vsSrc = if (isEs3) VS_ES3 else VS_ES2
        val fsSrc = if (isEs3) FS_ES3 else FS_ES2
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vsSrc)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fsSrc)
        programId = GLES20.glCreateProgram().also { p ->
            GLES20.glAttachShader(p, vs)
            GLES20.glAttachShader(p, fs)
            GLES20.glLinkProgram(p)
            val status = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(p)
                GLES20.glDeleteProgram(p)
                error("GL link failed: $log")
            }
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
    }

    private fun compileShader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val status = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            error("GL shader compile failed: $log")
        }
        return s
    }

    private fun initTextures() {
        val ids = IntArray(4)
        GLES20.glGenTextures(4, ids, 0)
        oesTexId = ids[0]
        lutTexId = ids[1]
        frontLutTexId = ids[2]
        fullLutTexId = ids[3]

        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        for (tid in listOf(lutTexId, frontLutTexId, fullLutTexId)) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tid)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }
        // Build dedicated upright Front-Camera LUT for Dashcam H.264 encoder (slot 0 of 5120x960 strip)
        uploadLutToTexture(frontLutTexId, Params(quadCrop = 2, quadrantIndex = 0, mirrorX = false, flipY = false, rotationDeg = 0f, zoom = 1.08f, fisheyeK = 0.28f))
        // Build full 4x1 strip LUT for 320x240 AI/BSD/Sentry analysis surface
        uploadLutToTexture(fullLutTexId, Params(quadCrop = 0, quadrantIndex = 0, mirrorX = false, flipY = false, rotationDeg = 0f, zoom = 1.0f, fisheyeK = 0.0f))
    }

    /**
     * Build 128x72 RGBA8 high-precision 16-bit packed UV LUT (RG = U hi/lo, BA = V hi/lo)
     * encoding radial fisheye dewarp + zoom + pan + mirror/flip + AVM quadrant crop.
     */
    private fun rebuildLutIfNeeded() {
        if (!lutDirty || lutTexId == 0) return
        lutDirty = false
        uploadLutToTexture(lutTexId, params)
    }

    private fun uploadLutToTexture(targetTexId: Int, p: Params) {
        val w = LUT_W
        val h = LUT_H
        val buf = ByteBuffer.allocateDirect(w * h * 4)

        // BYD DiLink 5.0 5120x960 4x1 horizontal strip:
        // slot 0 = Front (0.00..0.25), slot 1 = Rear (0.25..0.50), slot 2 = Right (0.50..0.75), slot 3 = Left (0.75..1.00)
        val (u0, v0, uSpan, vSpan) = when (p.quadCrop) {
            1 -> if (p.quadrantIndex == 1) QuadRect(0.5f, 0f, 0.5f, 1f) else QuadRect(0f, 0f, 0.5f, 1f)
            2 -> when (p.quadrantIndex) {
                0 -> QuadRect(0.00f, 0f, 0.25f, 1f)     // Front
                1 -> QuadRect(0.50f, 0f, 0.25f, 1f)     // Right (BVM Right)
                2 -> QuadRect(0.25f, 0f, 0.25f, 1f)     // Rear
                else -> QuadRect(0.75f, 0f, 0.25f, 1f)  // Left (BVM Left)
            }
            else -> QuadRect(0f, 0f, 1f, 1f)
        }

        val k = p.fisheyeK.coerceIn(0f, 0.65f)
        val invZoom = 1f / p.zoom.coerceIn(0.75f, 2.5f)
        val normScale = if (k > 0.001f) atan(tan(1.0 * k)).toFloat() / k else 1f
        val rad = Math.toRadians(p.rotationDeg.toDouble())
        val cosR = kotlin.math.cos(rad).toFloat()
        val sinR = kotlin.math.sin(rad).toFloat()

        for (y in 0 until h) {
            val ny0 = (y.toFloat() / (h - 1)) * 2f - 1f
            for (x in 0 until w) {
                val nx0 = (x.toFloat() / (w - 1)) * 2f - 1f
                var rx = nx0
                var ry = ny0
                if (p.mirrorX) rx = -rx
                if (p.flipY) ry = -ry
                // Rotate into upright vehicle-horizon orientation (e.g. +-90 deg for side mirror cameras)
                var sx = (rx * cosR - ry * sinR) * invZoom + p.panX
                var sy = (rx * sinR + ry * cosR) * invZoom + p.panY

                // LinkLock-grade 3D Rectilinear Fisheye Dewarp (equidistant 163° fisheye -> flat BVM view)
                if (k > 0.001f) {
                    val fovInRad = Math.toRadians(163.0)
                    val fovOutRad = Math.toRadians((112.0 / p.zoom.coerceIn(0.85f, 2.2f)).coerceIn(55.0, 125.0))
                    val tanHalfOut = tan(fovOutRad * 0.5)
                    // 3D ray in rectilinear output space
                    var vx = (nx0 * invZoom + p.panX) * tanHalfOut
                    var vy = (ny0 * invZoom + p.panY) * tanHalfOut * 0.72
                    var vz = 1.0
                    // Apply vertical tilt (pitch) so horizon & side lane sit level
                    val tiltRad = Math.toRadians(p.tiltDeg.toDouble())
                    if (kotlin.math.abs(tiltRad) > 0.001) {
                        val ct = kotlin.math.cos(tiltRad); val st = kotlin.math.sin(tiltRad)
                        val ny3 = vy * ct - vz * st
                        val nz3 = vy * st + vz * ct
                        vy = ny3; vz = nz3
                    }
                    // Apply upright camera rotation (+-90 deg for side-mirror sensors)
                    if (kotlin.math.abs(rad) > 0.001) {
                        val rx3 = vx * cosR - vy * sinR
                        val ry3 = vx * sinR + vy * cosR
                        vx = rx3; vy = ry3
                    }
                    if (p.mirrorX) vx = -vx
                    if (p.flipY) vy = -vy
                    val norm = sqrt(vx * vx + vy * vy + vz * vz).coerceAtLeast(1e-6)
                    val theta = kotlin.math.acos((vz / norm).coerceIn(-1.0, 1.0))
                    val rFish = (theta / (fovInRad * 0.5)) * (0.65 + k * 0.85)
                    val xyLen = sqrt(vx * vx + vy * vy)
                    if (xyLen > 1e-6) {
                        sx = ((vx / xyLen) * rFish).toFloat()
                        sy = ((vy / xyLen) * rFish).toFloat()
                    } else {
                        sx = 0f; sy = 0f
                    }
                }

                val lu = (sx * 0.5f + 0.5f).coerceIn(0.002f, 0.998f)
                val lv = (sy * 0.5f + 0.5f).coerceIn(0.002f, 0.998f)
                val u = (u0 + lu * uSpan).coerceIn(0.001f, 0.999f)
                val v = (v0 + lv * vSpan).coerceIn(0.001f, 0.999f)

                val u16 = (u * 65535f + 0.5f).toInt().coerceIn(0, 65535)
                val v16 = (v * 65535f + 0.5f).toInt().coerceIn(0, 65535)
                buf.put(((u16 shr 8) and 0xFF).toByte())
                buf.put((u16 and 0xFF).toByte())
                buf.put(((v16 shr 8) and 0xFF).toByte())
                buf.put((v16 and 0xFF).toByte())
            }
        }
        buf.position(0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, targetTexId)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf
        )
    }

    private fun renderFrame() {
        if (released) return
        val st = cameraTexture ?: return
        runCatching {
            val baseSurf = if (displaySurface != EGL14.EGL_NO_SURFACE) displaySurface else pbufferSurface
            EGL14.eglMakeCurrent(eglDisplay, baseSurf, baseSurf, eglContext)
            st.updateTexImage()
            st.getTransformMatrix(stMatrix)
            rebuildLutIfNeeded()

            if (displaySurface != EGL14.EGL_NO_SURFACE) {
                drawToSurface(displaySurface, dispW, dispH, st.timestamp, lutTexId)
            }
            if (encoderSurface != EGL14.EGL_NO_SURFACE) {
                drawToSurface(encoderSurface, encW, encH, if (st.timestamp > 0L) st.timestamp else System.nanoTime(), frontLutTexId)
            }
            val consumer = analysisConsumer
            val nowMs = System.currentTimeMillis()
            if (consumer != null && analysisSurface != EGL14.EGL_NO_SURFACE && nowMs - lastAnalysisMs >= 240L && analysisGate()) {
                lastAnalysisMs = nowMs
                drawToSurface(analysisSurface, 320, 240, st.timestamp, fullLutTexId)
                analysisPixels.rewind()
                GLES20.glReadPixels(0, 0, 320, 240, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, analysisPixels)
                analysisPixels.rewind()
                val bmp = Bitmap.createBitmap(320, 240, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(analysisPixels)
                runCatching { consumer(bmp) }
                bmp.recycle()
            }
        }.onFailure { CoreLog.w(tagName, "renderFrame error: ${it.message}") }
    }

    private fun drawToSurface(target: EGLSurface, w: Int, h: Int, timestampNs: Long, activeLutTexId: Int = lutTexId) {
        if (!EGL14.eglMakeCurrent(eglDisplay, target, target, eglContext)) return
        GLES20.glViewport(0, 0, w, h)
        GLES20.glUseProgram(programId)

        val p = params
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTexId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(programId, "uCamTex"), 0)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, activeLutTexId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(programId, "uLutTex"), 1)

        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(programId, "uStMatrix"), 1, false, stMatrix, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uBrightness"), p.brightness)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uContrast"), p.contrast)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uSaturation"), p.saturation)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uGamma"), p.gamma)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(programId, "uSharpness"), p.sharpness)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(programId, "uTexel"), 1f / w.toFloat(), 1f / h.toFloat())

        val posLoc = GLES20.glGetAttribLocation(programId, "aPos")
        val uvLoc = GLES20.glGetAttribLocation(programId, "aUv")
        quadVertices.position(0)
        GLES20.glEnableVertexAttribArray(posLoc)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, quadVertices)
        quadVertices.position(2)
        GLES20.glEnableVertexAttribArray(uvLoc)
        GLES20.glVertexAttribPointer(uvLoc, 2, GLES20.GL_FLOAT, false, 16, quadVertices)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        if (target == encoderSurface) {
            EGLExt.eglPresentationTimeANDROID(eglDisplay, target, timestampNs)
        }
        EGL14.eglSwapBuffers(eglDisplay, target)
    }

    private data class QuadRect(val u0: Float, val v0: Float, val uSpan: Float, val vSpan: Float)

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142
        private const val LUT_W = 128
        private const val LUT_H = 72

        private const val VS_ES3 = """#version 300 es
            in vec2 aPos;
            in vec2 aUv;
            out vec2 vUv;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vUv = aUv;
            }
        """

        private const val FS_ES3 = """#version 300 es
            #extension GL_OES_EGL_image_external_essl3 : require
            precision highp float;
            in vec2 vUv;
            uniform samplerExternalOES uCamTex;
            uniform sampler2D uLutTex;
            uniform mat4 uStMatrix;
            uniform float uBrightness;
            uniform float uContrast;
            uniform float uSaturation;
            uniform float uGamma;
            uniform float uSharpness;
            uniform vec2 uTexel;
            out vec4 outColor;

            vec2 decodeLut(vec2 uv) {
                vec4 p = texture(uLutTex, uv);
                float u = (p.r * 255.0 * 256.0 + p.g * 255.0) / 65535.0;
                float v = (p.b * 255.0 * 256.0 + p.a * 255.0) / 65535.0;
                return (uStMatrix * vec4(u, 1.0 - v, 0.0, 1.0)).xy;
            }

            void main() {
                vec2 cUv = decodeLut(vUv);
                vec3 c = texture(uCamTex, cUv).rgb;
                if (uSharpness > 0.01) {
                    vec3 n = texture(uCamTex, decodeLut(vUv + vec2(0.0, -uTexel.y))).rgb;
                    vec3 s = texture(uCamTex, decodeLut(vUv + vec2(0.0,  uTexel.y))).rgb;
                    vec3 e = texture(uCamTex, decodeLut(vUv + vec2( uTexel.x, 0.0))).rgb;
                    vec3 w = texture(uCamTex, decodeLut(vUv + vec2(-uTexel.x, 0.0))).rgb;
                    vec3 blur = 0.25 * (n + s + e + w);
                    c = clamp(c + (c - blur) * (uSharpness * 1.35), 0.0, 1.0);
                }
                c = clamp((c - 0.5) * uContrast + 0.5 + uBrightness, 0.0, 1.0);
                float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
                c = clamp(mix(vec3(luma), c, uSaturation), 0.0, 1.0);
                c = pow(max(c, vec3(0.0001)), vec3(uGamma));
                outColor = vec4(c, 1.0);
            }
        """

        private const val VS_ES2 = """
            attribute vec2 aPos;
            attribute vec2 aUv;
            varying vec2 vUv;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vUv = aUv;
            }
        """

        private const val FS_ES2 = """
            #extension GL_OES_EGL_image_external : require
            precision highp float;
            varying vec2 vUv;
            uniform samplerExternalOES uCamTex;
            uniform sampler2D uLutTex;
            uniform mat4 uStMatrix;
            uniform float uBrightness;
            uniform float uContrast;
            uniform float uSaturation;
            uniform float uGamma;
            uniform float uSharpness;
            uniform vec2 uTexel;

            vec2 decodeLut(vec2 uv) {
                vec4 p = texture2D(uLutTex, uv);
                float u = (p.r * 255.0 * 256.0 + p.g * 255.0) / 65535.0;
                float v = (p.b * 255.0 * 256.0 + p.a * 255.0) / 65535.0;
                return (uStMatrix * vec4(u, 1.0 - v, 0.0, 1.0)).xy;
            }

            void main() {
                vec2 cUv = decodeLut(vUv);
                vec3 c = texture2D(uCamTex, cUv).rgb;
                if (uSharpness > 0.01) {
                    vec3 n = texture2D(uCamTex, decodeLut(vUv + vec2(0.0, -uTexel.y))).rgb;
                    vec3 s = texture2D(uCamTex, decodeLut(vUv + vec2(0.0,  uTexel.y))).rgb;
                    vec3 e = texture2D(uCamTex, decodeLut(vUv + vec2( uTexel.x, 0.0))).rgb;
                    vec3 w = texture2D(uCamTex, decodeLut(vUv + vec2(-uTexel.x, 0.0))).rgb;
                    vec3 blur = 0.25 * (n + s + e + w);
                    c = clamp(c + (c - blur) * (uSharpness * 1.35), 0.0, 1.0);
                }
                c = clamp((c - 0.5) * uContrast + 0.5 + uBrightness, 0.0, 1.0);
                float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
                c = clamp(mix(vec3(luma), c, uSaturation), 0.0, 1.0);
                c = pow(max(c, vec3(0.0001)), vec3(uGamma));
                gl_FragColor = vec4(c, 1.0);
            }
        """
    }
}
