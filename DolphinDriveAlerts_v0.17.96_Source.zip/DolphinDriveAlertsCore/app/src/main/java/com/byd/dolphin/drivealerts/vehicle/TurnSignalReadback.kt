package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/**
 * BYD DiLink 3/5 Turn Signal Readback (v0.17.94):
 * - NEVER reads getLightStatus(1/2) (those are Headlight/HighBeam on BYD Dolphin and caused false LEFT lock).
 * - Uses BYDAutoLightDevice.getTurnLightState() / getTurnLightFlashState() with reflected
 *   LIGHT_LEFT_TURN_SIGNAL / LIGHT_RIGHT_TURN_SIGNAL constants (1=LEFT, 2=RIGHT) and hazard guard.
 */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    data class Result(val side: Side, val detail: String, val anyBlinkerActive: Boolean = false)

    internal fun classify(left: Int?, right: Int?): Boolean =
        (left == 1 && right == 0) || (right == 1 && left == 0)

    private data class Sample(val method: String, val value: Int?)
    private val classes = listOf(
        "android.hardware.bydauto.light.BYDAutoLightDevice",
        "android.hardware.bydauto.BYDAutoLightDevice",
        "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
        "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice"
    )
    private val leftMethods = listOf(
        "getLeftTurnLightState", "getLeftTurnSignalState",
        "getLeftTurnLampState", "getLeftTurnState", "getLeftTurnSignalLightState"
    )
    private val rightMethods = listOf(
        "getRightTurnLightState", "getRightTurnSignalState",
        "getRightTurnLampState", "getRightTurnState", "getRightTurnSignalLightState"
    )

    private fun readIntField(cls: Class<*>, name: String, fallback: Int): Int = runCatching {
        (cls.getField(name).get(null) as? Number)?.toInt() ?: fallback
    }.getOrDefault(fallback)

    fun read(): Result {
        val notes = mutableListOf<String>()
        var left: Sample? = null
        var right: Sample? = null

        for (className in classes) {
            val cls = try { Class.forName(className) } catch (t: Throwable) {
                notes += "class:${className.substringAfterLast('.')}=${t.javaClass.simpleName}"
                continue
            }
            val device = try {
                val factory = cls.methods.firstOrNull {
                    it.name == "getInstance" && it.parameterCount == 1 &&
                        it.parameterTypes[0].isAssignableFrom(Context::class.java)
                } ?: cls.methods.firstOrNull { it.name == "getInstance" && it.parameterCount == 0 }
                if (factory == null) { notes += "factory:${cls.simpleName}=MISSING"; continue }
                if (factory.parameterCount == 1) factory.invoke(null, app) else factory.invoke(null)
            } catch (t: Throwable) {
                notes += "instance:${cls.simpleName}=${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                continue
            }
            if (device == null) { notes += "instance:${cls.simpleName}=NULL"; continue }

            // Check hazard / double-flash state first so emergency flashers never trigger Left/Right BVM
            val hazard = runCatching {
                val hm = cls.methods.firstOrNull { it.name == "getDoubleFlashLightState" && it.parameterCount == 0 }
                (hm?.invoke(device) as? Number)?.toInt() == 1
            }.getOrDefault(false)
            if (hazard) {
                return Result(Side.UNKNOWN, "hazardActive=true", anyBlinkerActive = false)
            }

            // 1. BYD DiLink 5.0 Turn Signal API: getTurnLightState() / getTurnLightFlashState()
            val leftCode = readIntField(cls, "LIGHT_LEFT_TURN_SIGNAL", 1)
            val rightCode = readIntField(cls, "LIGHT_RIGHT_TURN_SIGNAL", 2)
            for (mName in listOf("getTurnLightState", "getTurnLightFlashState")) {
                val m = cls.methods.firstOrNull { it.name == mName && it.parameterCount == 0 } ?: continue
                val raw = runCatching { (m.invoke(device) as? Number)?.toInt() }.getOrNull() ?: continue
                when (raw) {
                    leftCode -> {
                        left = Sample("${cls.simpleName}.$mName", 1)
                        right = Sample("${cls.simpleName}.$mName", 0)
                    }
                    rightCode -> {
                        left = Sample("${cls.simpleName}.$mName", 0)
                        right = Sample("${cls.simpleName}.$mName", 1)
                    }
                    0 -> {
                        if (left == null) left = Sample("${cls.simpleName}.$mName", 0)
                        if (right == null) right = Sample("${cls.simpleName}.$mName", 0)
                    }
                    else -> notes += "$mName=$raw"
                }
                if (raw == leftCode || raw == rightCode) break
            }
            if (left?.value == 1 || right?.value == 1) break

            // 2. Legacy individual getters fallback
            fun readSide(names: List<String>, tag: String): Sample? {
                for (name in names) {
                    val method = cls.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
                    val raw = try { method.invoke(device) } catch (t: Throwable) {
                        notes += "$tag.$name:${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                        continue
                    }
                    if (raw is Number) return Sample("${cls.simpleName}.$name", raw.toInt())
                }
                return null
            }
            val candidateLeft = readSide(leftMethods, "LEFT")
            val candidateRight = readSide(rightMethods, "RIGHT")
            if (candidateLeft != null && candidateRight != null &&
                candidateLeft.value in 0..1 && candidateRight.value in 0..1
            ) {
                left = candidateLeft
                right = candidateRight
                if (candidateLeft.value == 1 || candidateRight.value == 1) break
            }
        }

        val l = left?.value
        val r = right?.value
        val side = when {
            l == 1 && r == 0 -> Side.LEFT
            r == 1 && l == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        val detail = "left=$l right=$r;leftMethod=${left?.method ?: "MISSING"};" +
            "rightMethod=${right?.method ?: "MISSING"};reason=${notes.take(10).joinToString("|")}"
        return Result(side, detail, anyBlinkerActive = classify(l, r))
    }
}
