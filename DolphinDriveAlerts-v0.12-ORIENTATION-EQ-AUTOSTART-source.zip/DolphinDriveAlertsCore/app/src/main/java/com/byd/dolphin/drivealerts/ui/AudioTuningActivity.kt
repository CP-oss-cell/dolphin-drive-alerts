package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.audio.EqPreferences
import com.byd.dolphin.drivealerts.audio.SoundFocusMode
import com.byd.dolphin.drivealerts.service.DrivingAlertService

/** Simple car-style sound tuning surface backed by Android AudioEffect. */
class AudioTuningActivity : Activity() {
    private lateinit var bassValue: TextView
    private lateinit var midValue: TextView
    private lateinit var trebleValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val current = EqPreferences.read(this)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 30)
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "이퀄라이저 · 음향 효과"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "표준 Android AudioEffect 기반 자체 튜닝입니다. Centerpoint 360 / Sound Focus 명칭은 조작 개념을 쉽게 구분하기 위한 UI 이름이며 Bose·현대·기아의 순정 DSP 알고리즘을 복제한 기능은 아닙니다."
            textSize = 13f
            setPadding(0, 8, 0, 18)
        })

        root.addView(CheckBox(this).apply {
            text = "이퀄라이저 사용"
            isChecked = current.enabled
            setOnCheckedChangeListener { _, checked ->
                EqPreferences.setEnabled(this@AudioTuningActivity, checked)
                refreshEngine()
            }
        })

        fun addBand(title: String, initial: Int, setter: (Int) -> Unit, valueHolder: (TextView) -> Unit) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(TextView(this).apply {
                text = title
                textSize = 17f
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val value = TextView(this).apply {
                text = formatGain(initial)
                textSize = 15f
            }
            valueHolder(value)
            line.addView(value)
            root.addView(line)
            root.addView(SeekBar(this).apply {
                max = 20
                progress = initial + 10
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val v = progress - 10
                        value.text = formatGain(v)
                        if (fromUser) setter(v)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { refreshEngine() }
                })
            })
        }

        addBand("저음 (Bass)", current.bass, { EqPreferences.setBass(this, it) }) { bassValue = it }
        addBand("중음 (Mid)", current.mid, { EqPreferences.setMid(this, it) }) { midValue = it }
        addBand("고음 (Treble)", current.treble, { EqPreferences.setTreble(this, it) }) { trebleValue = it }

        root.addView(TextView(this).apply {
            text = "Centerpoint 360"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 4)
        })
        root.addView(CheckBox(this).apply {
            text = "공간 확장 사용"
            isChecked = current.centerpoint360
            setOnCheckedChangeListener { _, checked ->
                EqPreferences.setCenterpoint360(this@AudioTuningActivity, checked)
                refreshEngine()
            }
        })
        root.addView(TextView(this).apply {
            text = "스테레오 음원을 넓게 들리도록 표준 Virtualizer를 사용합니다. 실제 360도 멀티채널 디코더가 아닙니다."
            textSize = 13f
        })

        root.addView(TextView(this).apply {
            text = "Sound Focus"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 22, 0, 4)
        })
        val focusGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val reference = RadioButton(this).apply { text = "Reference · 원음 중심"; id = View.generateViewId() }
        val surround = RadioButton(this).apply { text = "Surround · 공간감 확대"; id = View.generateViewId() }
        val cinema = RadioButton(this).apply { text = "Cinema · 저음/공간감 강조"; id = View.generateViewId() }
        focusGroup.addView(reference)
        focusGroup.addView(surround)
        focusGroup.addView(cinema)
        when (current.soundFocus) {
            SoundFocusMode.REFERENCE -> reference.isChecked = true
            SoundFocusMode.SURROUND -> surround.isChecked = true
            SoundFocusMode.CINEMA -> cinema.isChecked = true
        }
        focusGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                surround.id -> SoundFocusMode.SURROUND
                cinema.id -> SoundFocusMode.CINEMA
                else -> SoundFocusMode.REFERENCE
            }
            EqPreferences.setSoundFocus(this, mode)
            refreshEngine()
        }
        root.addView(focusGroup)

        root.addView(Button(this).apply {
            text = "모두 기본값으로 복원"
            setOnClickListener {
                EqPreferences.setBass(this@AudioTuningActivity, 0)
                EqPreferences.setMid(this@AudioTuningActivity, 0)
                EqPreferences.setTreble(this@AudioTuningActivity, 0)
                EqPreferences.setCenterpoint360(this@AudioTuningActivity, false)
                EqPreferences.setSoundFocus(this@AudioTuningActivity, SoundFocusMode.REFERENCE)
                recreate()
                refreshEngine()
            }
        })

        return scroll
    }

    private fun refreshEngine() {
        DrivingAlertService.refreshEqualizer(this)
    }

    private fun formatGain(value: Int): String = if (value > 0) "+$value" else value.toString()
}
