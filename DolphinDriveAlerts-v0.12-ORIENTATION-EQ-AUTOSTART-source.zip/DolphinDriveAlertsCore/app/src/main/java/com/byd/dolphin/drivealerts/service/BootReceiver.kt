package com.byd.dolphin.drivealerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Starts the always-on foreground monitor after Android/BYD boot and vehicle wake signals.
 * OverDrive v48.18 showed BYD ACC/IGN broadcasts in addition to Quick Boot, so v0.12 listens
 * to those read-only lifecycle hints as well. ACC_OFF / power-disconnect are intentionally
 * observation-only and never start a fresh service.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "<null>"
        val enabled = AlertPreferences.isEnabled(context)
        val autoStart = AlertPreferences.autoStartEnabled(context)
        CoreLog.i("BOOT", "received $action enabled=$enabled autoStart=$autoStart")

        if (action in STOP_SIDE_ACTIONS) {
            CoreLog.i("BOOT", "vehicle/power stop-side signal observed; no service start: $action")
            return
        }
        if (!enabled || !autoStart) return

        runCatching { DrivingAlertService.start(context.applicationContext) }
            .onSuccess { CoreLog.i("BOOT", "foreground service start requested: $action") }
            .onFailure { CoreLog.w("BOOT", "start failed for $action: ${it.message}", it) }
    }

    companion object {
        private val STOP_SIDE_ACTIONS = setOf(
            Intent.ACTION_POWER_DISCONNECTED,
            "com.byd.action.ACC_OFF",
        )
    }
}
