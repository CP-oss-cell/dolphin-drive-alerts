package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Reimplementation of the proven Screen Orientation Control pattern:
 * a zero-size TYPE_APPLICATION_OVERLAY requests screenOrientation without ADB/root.
 *
 * This controls the physical display orientation. It does not rotate an individual
 * embedded virtual display/task independently.
 */
enum class OrientationMode {
    STOCK,
    LANDSCAPE,
    PORTRAIT,
    REVERSE_LANDSCAPE,
    REVERSE_PORTRAIT,
    SENSOR_LANDSCAPE,
    FULL_SENSOR;

    fun screenOrientation(): Int = when (this) {
        STOCK -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        REVERSE_PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        SENSOR_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        FULL_SENSOR -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    }
}

object OrientationOverlayController {
    private val lock = Any()
    private var windowManager: WindowManager? = null
    private var view: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var activeMode: OrientationMode = OrientationMode.STOCK

    fun apply(context: Context, mode: OrientationMode): Boolean = synchronized(lock) {
        if (mode == OrientationMode.STOCK) return@synchronized clearLocked()
        val app = context.applicationContext
        if (!Settings.canDrawOverlays(app)) {
            CoreLog.w("ROTATION", "overlay permission unavailable; mode=$mode")
            return@synchronized false
        }
        return@synchronized runCatching {
            val wm = windowManager ?: (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).also {
                windowManager = it
            }
            val lp = params ?: WindowManager.LayoutParams(
                0,
                0,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).also {
                it.x = 0
                it.y = 0
                it.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                params = it
            }
            val v = view ?: View(app).also { view = it }
            val requested = mode.screenOrientation()
            if (lp.screenOrientation != requested) lp.screenOrientation = requested
            if (v.isAttachedToWindow) wm.updateViewLayout(v, lp) else wm.addView(v, lp)
            activeMode = mode
            CoreLog.i("ROTATION", "overlay orientation applied mode=$mode value=$requested")
            true
        }.getOrElse {
            CoreLog.w("ROTATION", "overlay orientation failed mode=$mode: ${it.message}", it)
            false
        }
    }

    fun clear(): Boolean = synchronized(lock) { clearLocked() }

    fun currentMode(): OrientationMode = synchronized(lock) { activeMode }

    private fun clearLocked(): Boolean {
        val wm = windowManager
        val v = view
        return runCatching {
            params?.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            if (wm != null && v != null && v.isAttachedToWindow) wm.removeViewImmediate(v)
            activeMode = OrientationMode.STOCK
            CoreLog.i("ROTATION", "overlay orientation restored to stock")
            true
        }.getOrElse {
            CoreLog.w("ROTATION", "overlay restore failed: ${it.message}", it)
            false
        }
    }
}
