package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import android.hardware.bydauto.BYDAutoEventValue
import android.hardware.bydauto.adas.AbsBYDAutoADASListener
import android.hardware.bydauto.energy.AbsBYDAutoEnergyListener
import android.hardware.bydauto.instrument.AbsBYDAutoInstrumentListener
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.util.CoreLog
import java.lang.reflect.Modifier
import java.util.ArrayDeque

/**
 * Normal-runtime event bridge reconstructed from Byd_SubAI_Beta_v13, which the user reports
 * working on the same Dolphin. Only semantics explicitly present in that source are promoted
 * to speech. Unverified AVH/BSD-danger/lane/DOW/lead-car candidates remain log-only elsewhere.
 */
class ReferenceVehicleEventBridge(
    context: Context,
    private val logger: RawSignalLogger,
    private val gate: AlertGate,
    private val onSteeringTripleTap: Runnable
) {
    private val app = context.applicationContext
    private data class Binding(val device: Any, val listener: Any)
    private data class StateTime(val value: Int, val timestamp: Long)
    private val bindings = mutableListOf<Binding>()
    private val featureIds = linkedMapOf<String, Int>()
    private val menuHistory = ArrayDeque<StateTime>()
    private var lastAccValue = Int.MIN_VALUE
    private var accActive = false
    private var lastRecycle = Int.MIN_VALUE
    private var lastRoadSurface = Int.MIN_VALUE
    private var lastOperationMode = Int.MIN_VALUE

    fun start() {
        if (bindings.isNotEmpty()) return
        loadFeatureIds()
        val wrapped = BydPermissionContext.wrap(app)

        setup(
            "instrument",
            "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
            wrapped,
            object : AbsBYDAutoInstrumentListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("instrument", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("instrument", errCode, errMessage)
            }
        )
        setup(
            "adas",
            "android.hardware.bydauto.adas.BYDAutoADASDevice",
            wrapped,
            object : AbsBYDAutoADASListener() {
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("adas", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("adas", errCode, errMessage)
            }
        )
        setup(
            "energy",
            "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
            wrapped,
            object : AbsBYDAutoEnergyListener() {
                override fun onOperationModeChanged(type: Int) = handleOperationMode(type, "callback")
                override fun onEnergyRecycleChanged(state: Int) = handleRecycle(state, "callback")
                override fun onDataEventChanged(eventType: Int, eventValue: BYDAutoEventValue) = processEvent("energy", eventType, eventValue)
                override fun onError(errCode: Int, errMessage: String?) = listenerError("energy", errCode, errMessage)
            }
        )

        logger.diagnostic(
            "REFERENCE_EVENT_BRIDGE_STARTED",
            "subai-v13;bindings=${bindings.size};menu=${featureIds["INSTRUMENT_2IN1_MENU_STATE"]};acc=${featureIds["ADAS_ACC_MODE"]}"
        )
    }

    fun close() {
        bindings.forEach { b ->
            runCatching {
                val method = b.device.javaClass.methods.firstOrNull {
                    it.name == "unregisterListener" && it.parameterCount == 1 && it.parameterTypes[0].isAssignableFrom(b.listener.javaClass)
                } ?: b.device.javaClass.methods.firstOrNull { it.name == "unregisterListener" && it.parameterCount == 1 }
                method?.invoke(b.device, b.listener)
            }
        }
        bindings.clear()
        menuHistory.clear()
    }

    private fun loadFeatureIds() {
        val classes = listOf(
            "android.hardware.bydauto.BYDAutoFeatureIds",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Instrument",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Adas",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Energy",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Radar",
            "android.hardware.bydauto.BYDAutoFeatureIds\$Setting"
        )
        for (className in classes) {
            runCatching {
                val c = Class.forName(className)
                for (field in c.declaredFields) {
                    if (Modifier.isStatic(field.modifiers) && field.type == Int::class.javaPrimitiveType) {
                        runCatching { featureIds[field.name] = field.getInt(null) }
                    }
                }
            }
        }
        logger.diagnostic("REFERENCE_FEATURE_IDS_LOADED", "count=${featureIds.size}")
    }

    private fun setup(source: String, className: String, wrapped: Context, listener: Any) {
        runCatching {
            val c = Class.forName(className)
            val device = c.getMethod("getInstance", Context::class.java).invoke(null, wrapped) ?: error("getInstance returned null")
            val register = c.methods.firstOrNull {
                it.name == "registerListener" && it.parameterCount == 1 && it.parameterTypes[0].isAssignableFrom(listener.javaClass)
            } ?: c.methods.firstOrNull { it.name == "registerListener" && it.parameterCount == 1 }
            ?: error("registerListener missing")
            register.invoke(device, listener)
            bindings += Binding(device, listener)
            logger.diagnostic("REFERENCE_LISTENER_REGISTERED", source)
        }.onFailure {
            logger.diagnostic("REFERENCE_LISTENER_FAILED", "$source:${it.javaClass.simpleName}:${it.cause?.message ?: it.message}")
            CoreLog.w("REF_BRIDGE", "$source listener failed: ${it.cause?.message ?: it.message}", it)
        }
    }

    private fun processEvent(source: String, eventType: Int, eventValue: BYDAutoEventValue?) {
        val value = intValue(eventValue) ?: return
        val names = featureIds.filterValues { it == eventType }.keys.toList()
        logger.bydEvent("reference.$source", eventType, value.toString(), names, "SubAI-v13 compatible listener")

        featureIds["INSTRUMENT_2IN1_MENU_STATE"]?.takeIf { it == eventType }?.let { handleMenuState(value) }
        featureIds["ADAS_ACC_MODE"]?.takeIf { it == eventType }?.let { handleAccMode(value) }

        // Exact constants used in SubAI v13.
        if (eventType == ENERGY_ROAD_SURFACE) handleRoadSurface(value)

        val recycleId = featureIds["ENERGY_RECYCLE"]
        val energyFbId = featureIds["SET_DR_ENERGY_FB"]
        if (eventType == recycleId || eventType == energyFbId) handleRecycle(value, "event")

        // SubAI maps ADAS_BLIND_SPOT_ASSIST to assist ON/OFF, not a live hazard direction.
        // We log it but deliberately DO NOT emit BSD_WARNING.
        val bsdAssistId = featureIds["ADAS_BLIND_SPOT_ASSIST"]
        if (eventType == bsdAssistId || eventType == BSD_ASSIST) {
            logger.diagnostic("REFERENCE_BSD_ASSIST_STATE", value.toString())
        }
    }

    private fun intValue(eventValue: Any?): Int? {
        if (eventValue == null) return null
        return runCatching { eventValue.javaClass.getField("intValue").getInt(eventValue) }
            .recoverCatching {
                eventValue.javaClass.getDeclaredField("intValue").apply { isAccessible = true }.getInt(eventValue)
            }.getOrNull()
    }

    private fun handleAccMode(value: Int) {
        if (value == lastAccValue) return
        lastAccValue = value
        when (value) {
            3 -> if (!accActive) {
                accActive = true
                emit(AlertEvent.ICC_ON, "ADAS_ACC_MODE=3")
            }
            0, 1, 2, 4 -> if (accActive) {
                accActive = false
                emit(AlertEvent.ICC_OFF, "ADAS_ACC_MODE=$value")
            }
        }
    }

    private fun handleOperationMode(type: Int, source: String) {
        if (type == lastOperationMode) return
        lastOperationMode = type
        logger.diagnostic("REFERENCE_OPERATION_MODE", "$source:$type")
        // SubAI proves 2=SPORT ON and 1=SPORT OFF, but 1 cannot distinguish ECO from NORMAL.
        if (type == 2) emit(AlertEvent.DRIVE_SPORT, "operationMode=2")
    }

    private fun handleRecycle(state: Int, source: String) {
        if (state == lastRecycle) return
        lastRecycle = state
        logger.diagnostic("REFERENCE_RECYCLE", "$source:$state")
        when (state) {
            2 -> emit(AlertEvent.REGEN_STANDARD, "energyRecycle=2")
            3 -> emit(AlertEvent.REGEN_HIGH, "energyRecycle=3")
        }
    }

    private fun handleRoadSurface(value: Int) {
        if (value == lastRoadSurface) return
        lastRoadSurface = value
        when (value) {
            1 -> emit(AlertEvent.SNOW_OFF, "roadSurface=1")
            2 -> emit(AlertEvent.SNOW_ON, "roadSurface=2")
        }
    }

    /** SubAI v13's proven three-press signal appears as six alternating 1/2 state transitions. */
    private fun handleMenuState(value: Int) {
        val now = System.currentTimeMillis()
        while (menuHistory.isNotEmpty() && now - menuHistory.first().timestamp > MENU_WINDOW_MS) menuHistory.removeFirst()
        if (menuHistory.isEmpty() || menuHistory.last().value != value) menuHistory.addLast(StateTime(value, now))
        if (menuHistory.size < 6) return
        val last6 = menuHistory.toList().takeLast(6)
        val a = listOf(1, 2, 1, 2, 1, 2)
        val b = listOf(2, 1, 2, 1, 2, 1)
        if (last6.map { it.value } != a && last6.map { it.value } != b) return
        val duration = last6.last().timestamp - last6.first().timestamp
        if (duration <= MENU_WINDOW_MS) {
            menuHistory.clear()
            logger.marker("STEERING_TRIPLE_TAP_REFERENCE", "INSTRUMENT_2IN1_MENU_STATE duration=${duration}ms")
            runCatching { onSteeringTripleTap.run() }
                .onFailure { logger.diagnostic("STEERING_TRIPLE_TAP_PLAY_FAILED", it.message) }
        }
    }

    private fun emit(event: AlertEvent, detail: String) {
        logger.diagnostic("REFERENCE_ALERT_EMIT", "${event.name}:$detail")
        gate.submit(AlertRequest(event))
    }

    private fun listenerError(source: String, code: Int, message: String?) {
        logger.diagnostic("REFERENCE_LISTENER_ERROR", "$source:$code:${message ?: ""}")
    }

    companion object {
        private const val ENERGY_ROAD_SURFACE = 0x24000033
        private const val BSD_ASSIST = 0x41800008
        private const val MENU_WINDOW_MS = 1000L
    }
}
