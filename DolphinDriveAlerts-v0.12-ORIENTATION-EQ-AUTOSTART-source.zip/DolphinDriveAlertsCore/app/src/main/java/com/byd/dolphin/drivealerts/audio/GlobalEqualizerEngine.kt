package com.byd.dolphin.drivealerts.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/**
 * Android-standard global audio effect engine reconstructed from the reference EQ app.
 *
 * Primary path: session 0 (Global Mix). Compatibility path: attach the same tuning to
 * audio sessions announced through OPEN_AUDIO_EFFECT_CONTROL_SESSION.
 *
 * "Centerpoint 360" and Sound Focus are user-facing presets implemented with standard
 * Android effects. They are not Bose/Hyundai/Kia proprietary DSP algorithms.
 */
class GlobalEqualizerEngine(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val sessions = ConcurrentHashMap<Int, SessionFx>()
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            val session = intent.getIntExtra(EXTRA_AUDIO_SESSION, -1)
            val pkg = intent.getStringExtra(EXTRA_PACKAGE_NAME).orEmpty()
            if (session < 0) return
            when (action) {
                ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "audio session open id=$session pkg=$pkg")
                    attach(session)
                }
                ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "audio session close id=$session pkg=$pkg")
                    sessions.remove(session)?.close()
                }
            }
        }
    }

    fun start() {
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                addAction(ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
            }
            runCatching { app.registerReceiver(receiver, filter) }
                .onSuccess { receiverRegistered = true }
                .onFailure { CoreLog.w("EQ", "session receiver registration failed: ${it.message}", it) }
        }
        // Global Mix fallback from the reference app. Failure is isolated and logged.
        attach(0)
        refresh()
    }

    fun refresh() {
        val settings = EqPreferences.read(app)
        if (sessions.isEmpty()) attach(0)
        sessions.values.forEach { fx ->
            runCatching { fx.apply(settings) }
                .onFailure { CoreLog.w("EQ", "apply failed session=${fx.sessionId}: ${it.message}", it) }
        }
        CoreLog.i(
            "EQ",
            "refresh enabled=${settings.enabled} bass=${settings.bass} mid=${settings.mid} treble=${settings.treble} " +
                "centerpoint=${settings.centerpoint360} focus=${settings.soundFocus} sessions=${sessions.keys.sorted()}"
        )
    }

    private fun attach(sessionId: Int) {
        if (sessions.containsKey(sessionId)) return
        val fx = SessionFx(sessionId)
        sessions[sessionId] = fx
        runCatching { fx.apply(EqPreferences.read(app)) }
            .onFailure { CoreLog.w("EQ", "initial apply failed session=$sessionId: ${it.message}", it) }
    }

    override fun close() {
        if (receiverRegistered) {
            runCatching { app.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
        sessions.values.forEach { runCatching { it.close() } }
        sessions.clear()
    }

    private class SessionFx(val sessionId: Int) : Closeable {
        private val equalizer: Equalizer? = runCatching { Equalizer(0, sessionId) }.getOrNull()
        private val bassBoost: BassBoost? = runCatching { BassBoost(0, sessionId) }.getOrNull()
        private val virtualizer: Virtualizer? = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        private val loudness: LoudnessEnhancer? = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()

        fun apply(s: EqSettings) {
            val enabled = s.enabled
            equalizer?.let { eq ->
                if (enabled) {
                    val range = eq.bandLevelRange
                    val min = range[0].toInt()
                    val max = range[1].toInt()
                    for (b in 0 until eq.numberOfBands.toInt()) {
                        val band = b.toShort()
                        val hz = eq.getCenterFreq(band) / 1000
                        val user = when {
                            hz < 250 -> s.bass
                            hz < 4000 -> s.mid
                            else -> s.treble
                        }
                        val modeOffset = when (s.soundFocus) {
                            SoundFocusMode.REFERENCE -> 0
                            SoundFocusMode.SURROUND -> when {
                                hz < 250 -> 0
                                hz < 4000 -> 1
                                else -> 2
                            }
                            SoundFocusMode.CINEMA -> when {
                                hz < 250 -> 3
                                hz < 4000 -> 1
                                else -> 1
                            }
                        }
                        val effective = (user + modeOffset).coerceIn(-10, 10)
                        val level = if (effective >= 0) {
                            (max * (effective / 10.0)).roundToInt()
                        } else {
                            ((-min) * (effective / 10.0)).roundToInt()
                        }.coerceIn(min, max)
                        eq.setBandLevel(band, level.toShort())
                    }
                }
                eq.enabled = enabled
            }

            bassBoost?.let { bb ->
                val strength = if (!enabled) 0 else {
                    val base = (s.bass.coerceAtLeast(0) * 65)
                    val cinema = if (s.soundFocus == SoundFocusMode.CINEMA) 250 else 0
                    (base + cinema).coerceIn(0, 1000)
                }
                if (bb.strengthSupported) bb.setStrength(strength.toShort())
                bb.enabled = enabled && strength > 0
            }

            virtualizer?.let { v ->
                val strength = if (!enabled) 0 else when {
                    s.centerpoint360 -> 850
                    s.soundFocus == SoundFocusMode.SURROUND -> 650
                    s.soundFocus == SoundFocusMode.CINEMA -> 350
                    else -> 0
                }
                if (v.strengthSupported) v.setStrength(strength.toShort())
                v.enabled = enabled && strength > 0
            }

            loudness?.let { le ->
                val gainMb = if (enabled && s.soundFocus == SoundFocusMode.CINEMA) 450 else 0
                le.setTargetGain(gainMb)
                le.enabled = enabled && gainMb > 0
            }
        }

        override fun close() {
            runCatching { equalizer?.enabled = false }
            runCatching { bassBoost?.enabled = false }
            runCatching { virtualizer?.enabled = false }
            runCatching { loudness?.enabled = false }
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
            runCatching { virtualizer?.release() }
            runCatching { loudness?.release() }
        }
    }

    companion object {
        // Standard AudioEffect control-session broadcast strings. Kept as literal strings so
        // the engine remains source-compatible across the Android versions used by BYD DiLink.
        private const val ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION"
        private const val ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION"
        private const val EXTRA_AUDIO_SESSION = "android.media.extra.AUDIO_SESSION"
        private const val EXTRA_PACKAGE_NAME = "android.media.extra.PACKAGE_NAME"
    }
}
