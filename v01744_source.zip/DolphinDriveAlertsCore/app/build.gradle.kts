plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.byd.dolphin.drivealerts"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.byd.dolphin.drivealerts"
        minSdk = 29
        targetSdk = 29
        versionCode = 70
        versionName = "0.17.44"
    }
    // The Actions runner may have its own default debug keystore. Never rely on it.
    // Explicitly sign the debug APK with the exact keystore validated in CI.
    val ciSigningFile = System.getenv("DOLPHIN_SIGNING_KEYSTORE_PATH")?.takeIf { it.isNotBlank() }
    if (ciSigningFile != null) {
        signingConfigs {
            getByName("debug") {
                storeFile = file(ciSigningFile)
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (ciSigningFile != null) signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging.resources.excludes += setOf("META-INF/LICENSE.md", "META-INF/LICENSE-notice.md")
}

dependencies {
    implementation("dev.mobile:dadb:1.2.8")
}
