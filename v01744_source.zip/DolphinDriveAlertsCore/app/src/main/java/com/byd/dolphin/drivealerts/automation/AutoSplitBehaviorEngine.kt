package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog
import kotlin.math.abs

/**
 * Built-in Android 10 split stack integration from externally observable platform behavior.
 * It NEVER launches the AutoSplit APK. Our previous VehicleSplitEngine is retired from callers.
 * Calls system shell APIs directly using our own user-authorized local ADB transport.
 */
object AutoSplitBehaviorEngine {
    data class Result(val success: Boolean, val message: String)
    private fun read(c: Context, command: String) = AuthorizedAdbRuntime.read(c,command,timeoutMs=5_000L).result
    private fun write(c: Context, command: String): Boolean {
        val r=AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=10_000L)
        CoreLog.i("SPLIT_NATIVE","cmd=$command status=${r.state} code=${r.result.exitCode} msg=${r.result.message.take(180)}")
        return r.state==AuthorizedAdbRuntime.State.READY &&
            !r.result.output.contains("Error:",ignoreCase=true) &&
            !r.result.output.contains("invalid input bounds",ignoreCase=true)
    }
    private fun snapshot(c: Context): String {
        val activities=read(c,"dumpsys activity activities")
        val stacks=read(c,"am stack list")
        return activities.output+"\n"+stacks.output
    }
    private fun task(c: Context,pkg: String) = LegacySplitTaskLocator.findTask(snapshot(c),pkg)
    private fun waitTask(c: Context, pkg:String, mode:Int): LegacySplitTaskLocator.State? {
        repeat(12) {
            Thread.sleep(300L)
            val state=task(c,pkg)
            if (state.found && state.mode==mode) return state
        }
        return null
    }
    private fun camera(raw:String): Boolean = Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(raw)
    fun screenToken(c: Context): String? = read(c,"dumpsys activity activities").output.lineSequence()
        .filter { it.contains("topResumedActivity",true) || it.contains("mResumedActivity",true) || it.contains("ResumedActivity",true) }
        .lastOrNull()?.take(500)
    fun capabilities(c: Context): String {
        val adb=AuthorizedAdbRuntime.health(c)
        if(adb.state!=AuthorizedAdbRuntime.State.READY)return "ADB=${adb.state}, 실제 분할 접근 미검증"
        val help=read(c,"am help").output
        val stack=read(c,"am stack list")
        return "ADB=READY; am windowing=${help.contains("windowingMode",true)};"+
            " stack list=${stack.success}; split bounds=${stack.output.contains("bounds",true)};"+
            " 3/4분할/팝업=별도 근거 없음"
    }
    fun launch(c:Context,profile:SplitProfile):Result {
        val a=AppSelection.safeComponent(c,profile.firstPackage)?:return Result(false,"첫 앱 실행 대상을 찾지 못했습니다")
        val b=AppSelection.safeComponent(c,profile.secondPackage)?:return Result(false,"둘째 앱 실행 대상을 찾지 못했습니다")
        if(profile.firstPackage==profile.secondPackage)return Result(false,"서로 다른 앱을 선택하세요")
        if(profile.firstPackage==c.packageName || profile.secondPackage==c.packageName)
            return Result(false,"설정 앱 자신은 분할 대상으로 사용할 수 없습니다")
        if(camera(screenToken(c).orEmpty()))return Result(false,"360/카메라 화면에서는 분할을 시작하지 않습니다")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)return Result(false,"로컬 ADB 승인 필요")
        val first=task(c,profile.firstPackage)
        if(first.mode!=3) {
            // Existing launched task: adopt into primary stack instead of creating a duplicate instance.
            var moved=false
            if(first.found) {
                val ghost="${c.packageName}/.automation.SplitGhostActivity"
                if(write(c,"am start --user 0 --windowingMode 3 -n '$ghost'")) {
                    val primaryStack=LegacySplitTaskLocator.findStack(snapshot(c),3)
                    if(primaryStack>=0) moved=write(c,"am stack move-task ${first.taskId} $primaryStack true")
                }
            }
            if(!moved || waitTask(c,profile.firstPackage,3)==null) {
                if(!write(c,"am start --user 0 --windowingMode 3 -n '$a'"))
                    return Result(false,"첫 앱의 split-primary 실행이 거부됐습니다")
            }
        }
        // AutoSplit starts BOTH stages before final verification. Do not silently skip app #2
        // just because Android 10 omitted a stack mode in its first `am stack list` snapshot.
        val firstReady=waitTask(c,profile.firstPackage,3)!=null
        if(!firstReady) CoreLog.w("SPLIT_NATIVE","first start requested, primary state not yet visible; continuing secondary")
        var second=task(c,profile.secondPackage)
        if(second.mode!=4) {
            if(!write(c,"am start --user 0 --windowingMode 4 -n '$b'"))
                return Result(false,"둘째 앱의 split-secondary 실행이 거부됐습니다")
        }
        second=waitTask(c,profile.secondPackage,4) ?: run {
            val pending=task(c,profile.secondPackage)
            val target=LegacySplitTaskLocator.findStack(snapshot(c),4)
            if(pending.found && target>=0 && write(c,"am stack move-task ${pending.taskId} $target true"))
                waitTask(c,profile.secondPackage,4) else null
        } ?: return Result(false,"두 앱 시작은 시도했으나 두 번째 split-secondary 확인 실패: ${task(c,profile.secondPackage)}")
        val primary=task(c,profile.firstPackage)
        if(!primary.found || primary.mode!=3 || second.mode!=4 || primary.taskId==second.taskId || primary.stackId==second.stackId)
            return Result(false,"분할 Task 소유권 검증 실패: $primary / $second")
        FeatureProfiles.markSplit(c,profile.id)
        val ratio=applyRatio(c,profile.primaryPercent)
        if(!ratio.success)return Result(true,"두 앱 분할은 확인됐지만 비율 미적용: ${ratio.message}")
        // Distinct ownership must survive divider resize.
        val afterA=task(c,profile.firstPackage); val afterB=task(c,profile.secondPackage)
        if(afterA.mode!=3 || afterB.mode!=4 || afterA.taskId==afterB.taskId)
            return Result(false,"비율 변경 이후 분할 앱 소유권이 달라졌습니다")
        return Result(true,"앱 2개 및 비율 적용 확인: ${ratio.message}")
    }
    fun applyRatio(c:Context, percentage:Int):Result {
        if(percentage !in 10..90)return Result(false,"허용 비율은 10~90%입니다")
        if(camera(screenToken(c).orEmpty()))return Result(false,"360/카메라가 표시되어 비율 변경을 보류합니다")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)return Result(false,"로컬 ADB 승인 필요")
        fun measure(): SplitGeometry.PairBounds? {
            val stacks=read(c,"am stack list");val activities=read(c,"dumpsys activity activities")
            return ReferenceAutoSplitRatio.parse(stacks.output) ?: SplitGeometry.parse(stacks.output,activities.output)
        }
        val bounds=measure()?:return Result(false,"기존 분할 스택 좌표를 확인할 수 없습니다")
        val before=SplitGeometry.percent(bounds)?:return Result(false,"분할 방향을 확인할 수 없습니다")
        if(abs(before-percentage)<=2)return Result(true,"$before:${100-before} (이미 적용)")
        val resize=SplitGeometry.resize(bounds,percentage)?:return Result(false,"화면 분할 좌표가 잘못됐습니다")
        // Legacy Android 10 docked stack command accepts docked Rect and task Rect.
        if(!write(c,resize.command))return Result(false,"비율 조절 명령 거부: ${resize.command}")
        repeat(6) {
            Thread.sleep(300L)
            val updated=measure()?.let(SplitGeometry::percent)
            if(updated!=null && abs(updated-percentage)<=3)return Result(true,"$updated:${100-updated} readback")
        }
        return Result(false,"비율 적용 후 읽기값 불일치 (요청=$percentage)")
    }
}
