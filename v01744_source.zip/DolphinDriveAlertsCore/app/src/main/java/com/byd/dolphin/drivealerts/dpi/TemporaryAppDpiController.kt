package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors

/** Temporary global density on external app foreground; restore original exact override on leave.
 * NEVER claim isolated per-app density. Changes entire display while target app is visible.
 */
object TemporaryAppDpiController {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r,"temporary-app-dpi") }
    private const val PREF = "temporary_app_dpi_session"
    @Volatile private var launchGraceUntil:Long=0L
    private fun prefs(c:Context) = c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
    fun onForeground(context: Context, pkg: String) {
        val app=context.applicationContext
        worker.execute { process(app,pkg) }
    }
    /** User pressed 'Apply and open'. Apply BEFORE starting MCONK/OEM app; verify wm readback.
     * Requires an actual standalone launchable component for the target package.
     */
    fun applyForLaunch(context:Context,pkg:String,dpi:Int,onResult:(DisplaySettingsController.Result)->Unit) {
        val app=context.applicationContext
        worker.execute {
            if (!ThirdPartyDpiRules.allowed(app,pkg) || dpi !in 120..320) {
                onResult(DisplaySettingsController.Result(false,"선택 앱 또는 DPI 값 확인 실패"))
                return@execute
            }
            if (!ThirdPartyDpiRules.save(app,pkg,dpi)) {
                onResult(DisplaySettingsController.Result(false,"DPI 규칙 저장 실패"));return@execute
            }
            ThirdPartyDpiRules.setEnabled(app,true)
            launchGraceUntil=android.os.SystemClock.elapsedRealtime()+8_000L
            process(app,pkg)
            val ok=prefs(app).getString("target",null)==pkg &&
                DisplaySettingsController.readDensity(app)?.override==dpi
            onResult(DisplaySettingsController.Result(ok,
                if(ok) "$pkg · ${dpi} DPI 적용 확인. 앱을 실행합니다"
                else "$pkg · ${dpi} DPI 실제 적용 실패. ADB 권한·wm density 로그를 확인하세요"))
        }
    }
    fun disableAndRestore(context: Context) {
        val app=context.applicationContext
        worker.execute { restore(app) }
    }
    fun recoverOnStartup(context: Context) {
        val app=context.applicationContext
        worker.execute { restore(app) }
    }
    /** Same executor as foreground changes, so a manual global choice cannot race restoration. */
    fun applyExplicitGlobal(context: Context, dpi: Int?, onResult: (DisplaySettingsController.Result) -> Unit) {
        val app=context.applicationContext
        worker.execute {
            restore(app)
            val result=if (prefs(app).contains("target"))
                DisplaySettingsController.Result(false,"임시 DPI 복원이 완료되지 않아 수동 변경을 중단했습니다")
                else DisplaySettingsController.applyDensity(app,dpi)
            onResult(result)
        }
    }
    private fun process(c: Context, pkg: String) {
        if (!ThirdPartyDpiRules.enabled(c)) { restore(c); return }
        val dpi=ThirdPartyDpiRules.rule(c,pkg)
        if (dpi == 0) {
            // During app switching, transient SystemUI/launcher events must not undo
            // an explicit density setting before the newly opened app is foreground.
            val temporary=prefs(c)
            if(temporary.contains("target") && android.os.SystemClock.elapsedRealtime()<launchGraceUntil) return
            restore(c);return
        }
        val existing=prefs(c)
        if (existing.getString("target",null)==pkg && existing.getInt("value",0)==dpi) {
            launchGraceUntil=0L
            return
        }
        restore(c)
        // Never apply a second override if the previous one could not be restored.
        if (prefs(c).contains("target")) return
        if (AuthorizedAdbRuntime.health(c).state != AuthorizedAdbRuntime.State.READY) {
            CoreLog.w("DPI","ADB not ready; temporary rule skipped: $pkg");return
        }
        val before=DisplaySettingsController.readDensity(c) ?: return
        if (!prefs(c).edit().putString("target",pkg).putInt("value",dpi)
                .putInt("beforeOverride",before.override ?: -1).commit()) return
        val run=AuthorizedAdbRuntime.writeOnce(c,"wm density $dpi")
        val after=DisplaySettingsController.readDensity(c)
        if (!run.result.success || after?.override != dpi) {
            CoreLog.w("DPI","temporary apply failed target=$pkg state=${run.state} actual=$after")
            restore(c)
        } else CoreLog.i("DPI","temporary global $dpi target=$pkg, ALL OEM UI also affected")
    }
    private fun restore(c: Context) {
        val pref=prefs(c)
        if (!pref.contains("target")) return
        val assigned=pref.getInt("value",0)
        val before=pref.getInt("beforeOverride",-1)
        val now=DisplaySettingsController.readDensity(c)
        // Do not overwrite unrelated user/system changes that occurred while our rule was active.
        if (now?.override == assigned) {
            val cmd=if (before < 0) "wm density reset" else "wm density $before"
            val result=AuthorizedAdbRuntime.writeOnce(c,cmd)
            val after=DisplaySettingsController.readDensity(c)
            if (!result.result.success || after?.override != before.takeIf { it >= 0 }) {
                CoreLog.w("DPI","temporary restore failed; will retry on next foreground event")
                return
            }
        } else if (now == null) return
        pref.edit().clear().commit()
        CoreLog.i("DPI","temporary global override restoration completed")
    }
}
