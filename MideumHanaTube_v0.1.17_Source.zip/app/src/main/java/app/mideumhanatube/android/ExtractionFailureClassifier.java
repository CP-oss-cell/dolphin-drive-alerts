package app.mideumhanatube.android;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Locale;

/** Privacy-safe exception grouping for native media extraction.
 * No URL, signed token, video title, request headers or raw error message is logged.
 */
final class ExtractionFailureClassifier {
    private ExtractionFailureClassifier() {}

    /** Implemented by a network adapter without exposing sensitive requests. */
    interface HttpStatusHint { int statusCode(); }

    static String classify(Throwable error) {
        Throwable next = error;
        for (int depth = 0; next != null && depth < 8; depth++, next = next.getCause()) {
            if (next instanceof HttpStatusHint) {
                int code = ((HttpStatusHint) next).statusCode();
                if (code == 401) return "HTTP_401";
                if (code == 403) return "HTTP_403";
                if (code == 429) return "HTTP_429";
                if (code >= 500) return "HTTP_5XX";
                if (code >= 400) return "HTTP_4XX";
            }
            if (next instanceof SocketTimeoutException) return "NETWORK_TIMEOUT";
            if (next instanceof UnknownHostException) return "NETWORK_DNS";
            if (next instanceof ConnectException) return "NETWORK_CONNECT";
            String simple = next.getClass().getSimpleName().toLowerCase(Locale.ROOT);
            if (simple.contains("age") && simple.contains("restrict")) return "VIDEO_AGE_RESTRICTED";
            if (simple.contains("geo") && simple.contains("restrict")) return "VIDEO_GEO_RESTRICTED";
            if (simple.contains("login") || simple.contains("captcha") || simple.contains("bot")) return "VIDEO_ACCESS_RESTRICTED";
            if (simple.contains("notavailable") || simple.contains("unavailable")) return "VIDEO_UNAVAILABLE";
            if (simple.contains("parsing") || simple.contains("parse")) return "EXTRACTOR_PARSE";
            if (simple.contains("reCaptcha".toLowerCase(Locale.ROOT))) return "VIDEO_ACCESS_RESTRICTED";
            if (simple.contains("extract")) return "EXTRACTOR_EXCEPTION";
        }
        if (error instanceof IllegalArgumentException) return "INVALID_INPUT";
        if (error instanceof IllegalStateException) return "EXTRACTOR_STATE";
        if (error instanceof java.io.IOException) return "NETWORK_OR_EXTRACTOR_IO";
        return "EXTRACTOR_OTHER";
    }

    static String safeClassName(Throwable error) {
        if (error == null) return "Unknown";
        String value = error.getClass().getSimpleName();
        return value.matches("[A-Za-z0-9_]{1,48}") ? value : "Unknown";
    }
}
