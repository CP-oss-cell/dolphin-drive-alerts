package app.mideumhanatube.android;

import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Separate stream lookup from the Activity/WebView. Only URLs from the approved
 * YouTube website are accepted. This is an optional best-effort extractor: a
 * stream can be missing or expire at any time. GPL-3.0-or-later dependency.
 */
public final class YouTubeStreamResolver {
    private static volatile boolean initialized;
    // The extractor may turn an HTTP denial into a generic parsing exception.
    // Capture *only the status code* on its worker thread; never persist URLs,
    // cookies or signed request tokens in diagnostics.
    private static final ThreadLocal<Integer> LAST_HTTP_ERROR = ThreadLocal.withInitial(() -> 0);
    private static final class HttpFailure extends IOException
            implements ExtractionFailureClassifier.HttpStatusHint {
        private final int status;
        HttpFailure(int status, Throwable cause) { super("MEDIA_HTTP_" + status, cause); this.status = status; }
        @Override public int statusCode() { return status; }
    }
    private YouTubeStreamResolver() { }

    public static final class Result {
        public final String streamUrl;
        public final String title;
        public final String streamKind;
        public final String auxiliaryAudioUrl;
        Result(String streamUrl, String title, String streamKind) {
            this(streamUrl, null, title, streamKind);
        }
        Result(String streamUrl, String auxiliaryAudioUrl, String title, String streamKind) {
            this.streamUrl = streamUrl;
            this.auxiliaryAudioUrl = auxiliaryAudioUrl;
            this.title = title;
            this.streamKind = streamKind;
        }
    }

    public static Result resolve(String youtubeUrl) throws Exception {
        return resolveInternal(youtubeUrl, false);
    }
    /** Best-effort video stream for the native video / PiP surface. */
    public static Result resolveVideo(String youtubeUrl) throws Exception {
        return resolveInternal(youtubeUrl, true);
    }
    private static Result resolveInternal(String youtubeUrl, boolean preferVideo) throws Exception {
        if (!isSupportedVideoUrl(youtubeUrl))
            throw new IOException("유튜브 영상 페이지 주소가 아닙니다.");
        synchronized (YouTubeStreamResolver.class) {
            if (!initialized) {
                NewPipe.init(new SecureHttpDownloader());
                initialized = true;
            }
        }
        LAST_HTTP_ERROR.set(0);
        try {
        StreamInfo info = StreamInfo.getInfo(youtubeUrl);
        if (preferVideo) {
            VideoStream muxedVideo = info.getVideoStreams().stream()
                    .filter(v -> v.isUrl() && v.getContent() != null && v.getContent().startsWith("https://"))
                    .filter(v -> v.getWidth() > 0 && v.getHeight() > 0)
                    .min(Comparator.comparingInt(v ->
                            Math.abs(v.getWidth() * v.getHeight() - 640 * 360)))
                    .orElse(null);
            if (muxedVideo != null) return new Result(muxedVideo.getContent(), info.getName(), "video");
            // Most modern YouTube videos offer separate video-only and audio tracks.
            // Merge the tracks in Media3 instead of falling back to an empty PiP surface.
            VideoStream picture = info.getVideoOnlyStreams().stream()
                    .filter(v -> v.isUrl() && v.getContent() != null && v.getContent().startsWith("https://"))
                    .filter(v -> v.getWidth() > 0 && v.getHeight() > 0)
                    .min(Comparator.comparingInt(v -> Math.abs(v.getWidth()*v.getHeight()-854*480)))
                    .orElse(null);
            AudioStream sound = info.getAudioStreams().stream()
                    .filter(a -> a.isUrl() && a.getContent() != null && a.getContent().startsWith("https://"))
                    .max(Comparator.comparingInt(a -> Math.max(a.getAverageBitrate(),a.getBitrate())))
                    .orElse(null);
            if (picture != null && sound != null)
                return new Result(picture.getContent(),sound.getContent(),info.getName(),"video_split");
            throw new IOException("재생 가능한 영상·음악 스트림을 얻지 못했습니다.");
        }
        AudioStream audio = info.getAudioStreams().stream()
                .filter(s -> s.isUrl() && s.getContent() != null && s.getContent().startsWith("https://"))
                .max(Comparator.comparingInt(s -> Math.max(s.getAverageBitrate(), s.getBitrate())))
                .orElse(null);
        if (audio != null) return new Result(audio.getContent(), info.getName(), "audio");
        // Some YouTube sessions expose muxed A/V only. Playback with no video
        // surface is still possible, albeit at a higher network cost.
        VideoStream muxed = info.getVideoStreams().stream()
                .filter(s -> s.isUrl() && s.getContent() != null && s.getContent().startsWith("https://"))
                .min(Comparator.comparingInt(s -> s.getWidth() * s.getHeight()))
                .orElse(null);
        if (muxed != null) return new Result(muxed.getContent(), info.getName(), "muxed");
        if (info.getHlsUrl() != null && info.getHlsUrl().startsWith("https://"))
            return new Result(info.getHlsUrl(), info.getName(), "hls");
        throw new IOException("재생 가능한 오디오 스트림을 찾지 못했습니다.");
        } catch (Exception error) {
            int status = LAST_HTTP_ERROR.get();
            if (status >= 400) throw new HttpFailure(status, error);
            throw error;
        } finally {
            LAST_HTTP_ERROR.remove();
        }
    }

    static boolean isSupportedVideoUrl(String value) { return NativeVideoUrlRule.isVideoPage(value); }

    /** No cookies, credentials, or arbitrary HTTP endpoints are passed here. */
    private static final class SecureHttpDownloader extends Downloader {
        private static final int MAX_BODY_BYTES = 16 * 1024 * 1024;
        @Override public Response execute(Request request) throws IOException {
            URL url = new URL(request.url());
            if (!"https".equalsIgnoreCase(url.getProtocol()))
                throw new IOException("HTTPS 요청만 지원합니다.");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(16000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestMethod(request.httpMethod());
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            if (request.headers() != null) {
                for (Map.Entry<String, List<String>> entry : request.headers().entrySet()) {
                    if (entry.getKey() == null || entry.getValue() == null) continue;
                    for (String v : entry.getValue()) if (v != null) connection.addRequestProperty(entry.getKey(), v);
                }
            }
            byte[] payload = request.dataToSend();
            if (payload != null && payload.length > 0) {
                connection.setDoOutput(true);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
            }
            try {
                int status = connection.getResponseCode();
                if (status >= 400) {
                    int previous = LAST_HTTP_ERROR.get();
                    // Preserve the first denial, except a later 403 or 429 is
                    // more actionable than an earlier unrelated missing resource.
                    if (previous == 0 || status == 403 || status == 429) LAST_HTTP_ERROR.set(status);
                }
                String body = "";
                if (!"HEAD".equalsIgnoreCase(request.httpMethod())) {
                    InputStream in = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    if (in != null) {
                        try (InputStream stream = in; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] bytes = new byte[8192]; int n; int total=0;
                            while ((n = stream.read(bytes)) != -1) {
                                total += n;
                                if (total > MAX_BODY_BYTES) throw new IOException("스트림 정보 응답 크기 초과");
                                buffer.write(bytes, 0, n);
                            }
                            body = buffer.toString(StandardCharsets.UTF_8.name());
                        }
                    }
                }
                String finalUrl = connection.getURL().toString();
                if (!finalUrl.startsWith("https://")) throw new IOException("HTTPS 리디렉션 실패");
                return new Response(status, connection.getResponseMessage(),
                        connection.getHeaderFields(), body, finalUrl);
            } finally { connection.disconnect(); }
        }
    }
}
