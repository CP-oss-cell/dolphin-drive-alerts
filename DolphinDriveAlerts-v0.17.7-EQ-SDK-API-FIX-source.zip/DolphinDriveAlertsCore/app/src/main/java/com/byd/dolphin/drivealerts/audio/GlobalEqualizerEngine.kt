package com.byd.dolphin.drivealerts.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Build
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Real audio-effect attach, readback and restoration.
 * Sources: user-provided Equalizer 6.3.5.8 / BYD 4.2 analysis and EVSound SVC lifecycle.
 * Only EQ and standard spatial Virtualizer. No SVC, engine noise, stream14, UID routing, or OEM DSP claims.
 * Global Mix is deprecated on newer Android and may be unsupported by the car firmware.
 */
class GlobalEqualizerEngine(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val sessions = ConcurrentHashMap<Int, SessionFx>()
    private val lock = Any()
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val i = intent ?: return
            val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            val pkg = i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME).orEmpty()
            if (id <= 0 || pkg.isBlank() || pkg == app.packageName) return
            synchronized(lock) {
                when (i.action) {
                    AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                        CoreLog.i("EQ", "SESSION_OPEN id=$id source=$pkg")
                        sessions.remove(0)?.close()
                        sessions.getOrPut(id) { SessionFx(id, pkg) }
                    }
                    AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                        CoreLog.i("EQ", "SESSION_CLOSE id=$id source=$pkg")
                        sessions.remove(id)?.close()
                    }
                }
                refreshLocked()
            }
        }
    }

    fun start() {
        synchronized(lock) {
            if (!registered) {
                val f = IntentFilter().apply {
                    addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                    addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
                }
                runCatching { app.registerReceiver(receiver, f) }
                    .onSuccess { registered = true }
                    .onFailure { CoreLog.w("EQ", "SESSION_RECEIVER_FAILED: ${it.message}", it) }
            }
            refreshLocked()
        }
    }

    fun refresh() = synchronized(lock) { refreshLocked() }

    private fun refreshLocked() {
        val s = EqPreferences.read(app)
        if (!s.enabled) {
            // Preserve known OPEN session IDs while the user toggles EQ off/on.
            // Otherwise re-enabling mid-song has no session until the player reopens it.
            sessions.values.forEach { it.close() }
            sessions.remove(0)?.close()
            status("EQ 꺼짐 · 변경된 오디오 효과 해제/원복")
            return
        }
        // Individual audio sessions take precedence. Otherwise opt-in Global Mix covers media
        // players that do not send OPEN_AUDIO_EFFECT_CONTROL_SESSION (the common BYD case).
        if (sessions.keys.none { it > 0 } && s.globalMix) {
            sessions.getOrPut(0) { SessionFx(0, "Global Mix / 호환모드") }
        } else if (!s.globalMix) {
            sessions.remove(0)?.close()
        }
        val values = sessions.values.sortedBy { it.sessionId }
            .map { fx -> "${fx.sessionId}/${fx.owner}: ${fx.apply(s)}" }
        val operational = values.any { it.contains("EQ=APPLIED") }
        status(when {
            values.isEmpty() -> "EQ 미적용 · 오디오 세션 수신 없음. Global Mix 호환모드를 켜세요."
            operational -> "EQ 밴드 readback 성공(실제 음악 청감은 별도 확인): ${values.joinToString(" | ")}"
            else -> "EQ 적용 실패/미지원: ${values.joinToString(" | ")}"
        })
    }

    private fun status(value: String) {
        app.getSharedPreferences(STATUS_PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS_KEY, value).apply()
        CoreLog.i("EQ", value)
    }

    override fun close() = synchronized(lock) {
        if (registered) runCatching { app.unregisterReceiver(receiver) }
        registered = false
        sessions.values.forEach { it.close() }
        sessions.clear()
    }

    private class SessionFx(val sessionId: Int, val owner: String) : Closeable {
        // Do not stack two EQ engines on the same session. DP first, classic Equalizer as fallback.
        private var dp: DynamicsProcessing? = null
        private var initialDp: DynamicsProcessing.Config? = null
        private var classic: Equalizer? = null
        private var initialBands: List<Short>? = null
        private var initialEnabled: Boolean? = null
        private var virtualizer: Virtualizer? = null
        private var initialVirtualEnabled: Boolean? = null
        private var initialVirtualStrength: Short? = null
        private val priority = 0

        private fun prepare(): String {
            if (dp != null || classic != null) return "ready"
            if (Build.VERSION.SDK_INT >= 28) {
                val r = runCatching {
                    val cfg = DynamicsProcessing.Config.Builder(
                        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        2, true, 10, false, 0, false, 0, false
                    ).setPreferredFrameDuration(10f).build()
                    val created = DynamicsProcessing(priority, sessionId, cfg)
                    if (!created.hasControl()) {
                        created.release()
                        error("DP_NO_CONTROL")
                    }
                    initialDp = created.config
                    dp = created
                }
                if (r.isSuccess) return "DP10"
                CoreLog.w("EQ", "DP unavailable session=$sessionId reason=${r.exceptionOrNull()?.message}")
            }
            return prepareLegacy()
        }

        private fun prepareLegacy(): String {
            val r = runCatching {
                val eq = Equalizer(priority, sessionId)
                if (!eq.hasControl()) { eq.release(); error("EQ_NO_CONTROL") }
                initialBands = (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()) }
                initialEnabled = eq.enabled
                classic = eq
            }
            return if (r.isSuccess) "LEGACY" else "NO_ENGINE:${r.exceptionOrNull()?.javaClass?.simpleName}"
        }

        fun apply(s: EqSettings): String {
            val prepared = prepare()
            if (dp == null && classic == null) return "EQ=UNAVAILABLE ($prepared)"
            var result = if (dp != null) applyDynamics(s) else applyClassic(s)
            if (dp != null && !result.startsWith("EQ=APPLIED")) {
                // Restore before fallback. Never leave a partially configured DP
                // effect on the same session as the legacy Equalizer.
                releaseDynamics()
                // Repeated DP readback failures should not leave EQ unusable when legacy works.
                val fallback = prepareLegacy()
                result = if (classic != null) applyClassic(s) else "$result; fallback=$fallback"
            }
            val spatial = applyVirtualizer(EqToneCurve.virtualizerStrength(s))
            return "$result; SPATIAL=$spatial; OEM_360=UNSUPPORTED_OEM_DSP"
        }

        private fun applyDynamics(s: EqSettings): String = runCatching {
            val e = requireNotNull(dp)
            if (!e.hasControl()) return@runCatching "EQ=NO_CONTROL(DP)"
            val cfg = e.config
            if (!cfg.isPreEqInUse || cfg.preEqBandCount <= 0) return@runCatching "EQ=NO_BANDS(DP)"
            val count = cfg.preEqBandCount
            val hz = IntArray(count) { i -> cfg.getPreEqBandByChannelIndex(0, i).cutoffFrequency.roundToInt() }
            for (i in 0 until count) {
                val gain = EqToneCurve.gainDb(s, hz[i])
                val band = DynamicsProcessing.EqBand(true, hz[i].toFloat(), gain)
                e.setPreEqBandAllChannelsTo(i, band)
            }
            val headroom = EqToneCurve.headroomDb(s, hz)
            e.setInputGainAllChannelsTo(headroom)
            val code = e.setEnabled(true)
            val mismatch = (0 until e.getChannelCount()).sumOf { c ->
                (0 until count).count { i ->
                    abs(e.getPreEqBandByChannelIndex(c, i).gain - EqToneCurve.gainDb(s, hz[i])) > 0.21f
                }
            }
            val gainMismatch = (0 until e.getChannelCount()).any { c ->
                abs(e.getInputGainByChannelIndex(c) - headroom) > 0.21f
            }
            if (code == AudioEffect.SUCCESS && e.enabled && mismatch == 0 && !gainMismatch)
                "EQ=APPLIED(DP-${count}band,-${-headroom}dB headroom)"
            else "EQ=READBACK_FAIL(DP code=$code mismatch=$mismatch headroomMismatch=$gainMismatch)"
        }.getOrElse { "EQ=ERROR(DP:${it.javaClass.simpleName})" }

        private fun applyClassic(s: EqSettings): String = runCatching {
            val eq = requireNotNull(classic)
            if (!eq.hasControl()) return@runCatching "EQ=NO_CONTROL(LEGACY)"
            val r = eq.bandLevelRange
            val count = eq.numberOfBands.toInt()
            val frequencies = IntArray(count) { i -> eq.getCenterFreq(i.toShort()) / 1000 }
            // Classic EQ has no input gain stage. Trim all bands equally when
            // boosting to preserve the intended relative tone without clipping.
            val safeTrim = EqToneCurve.headroomDb(s, frequencies)
            var mismatch = 0
            for (i in 0 until count) {
                val band = i.toShort()
                val hz = frequencies[i]
                val mb = ((EqToneCurve.gainDb(s, hz) + safeTrim) * 100f).roundToInt()
                    .coerceIn(r[0].toInt(), r[1].toInt()).toShort()
                eq.setBandLevel(band, mb)
                if (abs(eq.getBandLevel(band).toInt() - mb.toInt()) > 20) mismatch++
            }
            val code = eq.setEnabled(true)
            if (code == AudioEffect.SUCCESS && eq.enabled && mismatch == 0) "EQ=APPLIED(LEGACY-${count}band, safe-trim=${safeTrim}dB)"
            else "EQ=READBACK_FAIL(LEGACY code=$code mismatch=$mismatch)"
        }.getOrElse { "EQ=ERROR(LEGACY:${it.javaClass.simpleName})" }

        // Standard Android Virtualizer is only a 2ch spatial approximation.
        // Car speaker support varies: hasControl + strength/readback cannot prove physical surround.
        private fun applyVirtualizer(strength: Short): String {
            if (strength <= 0) {
                releaseVirtualizer()
                return "OFF"
            }
            if (virtualizer == null) {
                val v = runCatching { Virtualizer(priority, sessionId) }.getOrNull()
                    ?: return "UNSUPPORTED_CREATE"
                if (!v.hasControl() || !v.strengthSupported) {
                    v.release()
                    return "UNSUPPORTED_ROUTE_OR_CONTROL"
                }
                initialVirtualEnabled = v.enabled
                initialVirtualStrength = v.roundedStrength
                virtualizer = v
            }
            val v = virtualizer ?: return "UNAVAILABLE"
            val result = runCatching {
                // Android Virtualizer.setStrength(Short) returns Unit (Java void),
                // not an AudioEffect status code. Exceptions are handled by runCatching,
                // and the applied strength / route are verified by readback instead.
                v.setStrength(strength)
                val ec = v.setEnabled(true)
                val routeMode = v.virtualizationMode
                if (ec == AudioEffect.SUCCESS && v.enabled &&
                    abs(v.roundedStrength.toInt() - strength.toInt()) <= 60 &&
                    routeMode != Virtualizer.VIRTUALIZATION_MODE_OFF)
                    "API_ON(${v.roundedStrength}/1000,routeMode=$routeMode)"
                else if (routeMode == Virtualizer.VIRTUALIZATION_MODE_OFF) "ROUTE_NOT_VIRTUALIZED"
                else "READBACK_FAIL(enabled=$ec readStrength=${v.roundedStrength} routeMode=$routeMode)"
            }.getOrElse { "ERROR:${it.javaClass.simpleName}" }
            // Fail closed if route-mode or strength readback does not establish
            // control. Do not leave an incompletely configured effect attached.
            if (!result.startsWith("API_ON")) releaseVirtualizer()
            return result
        }

        private fun releaseVirtualizer() {
            virtualizer?.let { v -> runCatching {
                if (v.hasControl()) {
                    initialVirtualStrength?.let { v.setStrength(it) }
                    initialVirtualEnabled?.let { v.enabled = it }
                }
                v.release()
            } }
            virtualizer = null
            initialVirtualStrength = null
            initialVirtualEnabled = null
        }

        override fun close() {
            releaseVirtualizer()
            releaseDynamics()
            classic?.let { eq -> runCatching {
                if (eq.hasControl()) {
                    initialBands?.forEachIndexed { i, value -> eq.setBandLevel(i.toShort(), value) }
                    initialEnabled?.let { eq.enabled = it }
                }
                eq.release()
            } }
            classic = null
        }

        private fun releaseDynamics() {
            dp?.let { e -> runCatching {
                if (e.hasControl()) {
                    initialDp?.let { cfg ->
                        // The engine, not DynamicsProcessing.Config, exposes the
                        // public Android getChannelCount() API (API 28+).
                        for (c in 0 until e.getChannelCount()) {
                            e.setChannelTo(c, cfg.getChannelByChannelIndex(c))
                        }
                    }
                    e.enabled = false // engine created by us: disable before release
                }
                e.release()
            } }
            dp = null
            initialDp = null
        }
    }

    companion object {
        private const val STATUS_PREF = "audio_tuning_runtime"
        private const val STATUS_KEY = "eq_last_state"
        fun readStatus(context: Context): String = context.getSharedPreferences(
            STATUS_PREF, Context.MODE_PRIVATE).getString(STATUS_KEY, "EQ 엔진 준비 전").orEmpty()
    }
}
