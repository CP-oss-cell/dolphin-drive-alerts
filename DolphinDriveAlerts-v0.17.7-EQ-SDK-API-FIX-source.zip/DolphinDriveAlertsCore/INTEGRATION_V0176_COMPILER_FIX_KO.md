# v0.17.6 Kotlin compiler fix / GitHub run 37897031229

- Source baseline: verified v0.17.5 ZIP SHA-256 f1ecccb5322489189e7f67ff433978e3bfdb3c79ec6d7a468754c7a9508d79fb
- GitHub repository: CP-oss-cell/dolphin-drive-alerts, main HEAD 4d334789ab00524ba9d4324eb03cf924d0f7ab46 as shown in user log.
- Failure: :app:compileDebugKotlin, GlobalEqualizerEngine.kt:245:21 `Unit == Int`, :288:69 unresolved `channelCount`.
- Root cause: Virtualizer.setStrength(Short) returns void/Unit, not status Int. DynamicsProcessing exposes getChannelCount() method.
- Minimal production changes: GlobalEqualizerEngine.kt only (API usage), app/build.gradle.kts only (versionCode 32 / versionName 0.17.6-compiler-fix).
- Fix: check setEnabled return and roundedStrength/virtualizationMode/hasControl readback. Use e.getChannelCount() explicitly for each DP channel loop.
- Retained: v0.17.5 session capture resume, retry after ignition, AVAS sound pulse correlation, ADAS alerts, EQ presets, safety requirements; no new car writes.
- Verified using local static regression gates, Kotlin curve fixture, API contract. Android Gradle build and real-car installation remain unconfirmed until GitHub Actions succeeds.
