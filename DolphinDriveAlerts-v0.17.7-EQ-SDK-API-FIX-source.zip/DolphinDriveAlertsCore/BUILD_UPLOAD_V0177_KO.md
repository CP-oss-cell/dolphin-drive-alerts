# Dolphin Drive Alerts v0.17.7 GitHub 빌드 방법

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` 루트에 **`DolphinDriveAlerts-v0.17.7-EQ-SDK-API-FIX-source.zip`** 업로드.
2. `.github/workflows/build-v0177-from-source-zip.yml` 업로드. 이전 v0.17.6 ZIP/YML은 보존해도 되지만 이번에는 v0.17.7 Actions로 실행.
3. GitHub Actions에서 `Build Dolphin Drive Alerts v0.17.7 SDK API Channel Fix APK` 실행.
4. `Compile real Android Kotlin with API 34` 및 `Build installable debug APK` 모두 성공했을 때만 APK Artifact 다운로드.
5. 실패 시 `build-failure-log` Artifact 또는 Actions 전체 로그 업로드. APK 빌드 완료/실차 성공으로 임의 표기 금지.
