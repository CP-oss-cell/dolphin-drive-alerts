# v0.17.5 GitHub Actions Kotlin 컴파일 실패 분석 및 v0.17.6 패치

- GitHub: CP-oss-cell/dolphin-drive-alerts, Actions run 37897031229; 2026-10-09 07:08 UTC.
- 업로드 로그에서 SOURCE_ZIP = DolphinDriveAlerts-v0.17.5-CAPTURE-RECONNECT-source.zip, SHA-256 `f1ecccb5322489189e7f67ff433978e3bfdb3c79ec6d7a468754c7a9508d79fb`. 라이브러리 원본 ZIP SHA와 일치.
- 실패 단계: `:app:compileDebugKotlin`. Android SDK 설치/리소스 준비는 통과, APK 미생성.
- 확정 오류 A: `GlobalEqualizerEngine.kt:245:21` — Unit인 `Virtualizer.setStrength(short)` 반환을 Int인 `AudioEffect.SUCCESS`와 비교함.
- 확정 오류 B: `GlobalEqualizerEngine.kt:288:69` — 잘못된 `channelCount` 접근. Android `DynamicsProcessing.getChannelCount()`를 명시 호출해 3개 사용 위치 통일.
- 수정: `GlobalEqualizerEngine.kt`의 Android API 타입 계약만 교정. `setStrength()` 예외 처리는 runCatching, readback은 `roundedStrength`/`virtualizationMode`/`enabled`, DP 채널 수는 명시 getter 사용. 다른 차량/주행/로그 코드 변경 없음.
- Version: v0.17.6 (versionCode 32)로 이전 빌드와 구분. 새 소스 ZIP과 대응 YML 제공. 기존 v0.17.5 원본은 롤백용 보존.
- 범위 외: 순정 외부 AVAS 출력 구현·차량 360/DSP/운전석 타 앱 UID 라우팅 성공 주장 불가. v0.17.5 실차 로그 세션 복구 역시 검증 전 상태 유지.
- 검증: 기존 차량/EQ/AVAS/로그 수집 회귀 검사, 실제 EQ Kotlin 파일의 strict Android API stub 컴파일; full Android SDK Gradle 빌드 및 실차 검증은 GitHub Actions 재실행 필요.
