# Dolphin Drive Alerts v0.17.7 — v0.17.6 실제 GitHub Kotlin 컴파일 실패 수정

- 실측: `붙여넣은 마크다운(6).md`, CP-oss-cell/dolphin-drive-alerts, Actions run 37898447468, checkout main `5b394c775b1e45c5f9de662fef9cd270bdfc8e13`, v0.17.6 원본 ZIP SHA256 `73d2c7bded6e8595f8132b4bd27b07f502b837334fc7e36555573c97826e04fd`.
- 오류: `:app:compileDebugKotlin` FAILED, `GlobalEqualizerEngine.kt:291:74 Unresolved reference: channelCount`. 실제 APK 생성 실패.
- 원인: `DynamicsProcessing`에는 공개 `getChannelCount()` API가 있지만 `DynamicsProcessing.Config`에는 공개 `channelCount` 속성이 없다. 기존 v0.17.6 테스트 스텁이 `Config.channelCount` 가상 속성을 제공하여 가짜 통과를 허용했다.
- 수정: DP 이전 상태 복원 루프 `0 until minOf(e.getChannelCount(), cfg.channelCount)` → `0 until e.getChannelCount()`로 바꾸고 `cfg.getChannelByChannelIndex(c)`를 사용한 기존 restore 및 예외·권한 방어 로직은 유지한다.
- 검사 강화: v0.17.7 엄격 테스트 스텁의 Config에서 가짜 `channelCount` 제거, 실제 Production `GlobalEqualizerEngine.kt`, `EqPreferences.kt`, `EqToneCurve.kt` Kotlin 컴파일 및 별도 API 계약 검사. GitHub Actions에서 Android SDK 34 실제 `:app:compileDebugKotlin` 선행 후 `:app:assembleDebug` 단계(캐시 재사용, clean 재실행 없음)로 변경.
- 변경 범위(패키징 보고 생성 이전): 변경 2파일 build.gradle.kts, GlobalEqualizerEngine.kt, 동일 235, 신규 12, 삭제 0. 이전 정상 차량 기능, 자동 로그 재시작·세션 유지, AVAS 로그 관찰, EQ 화면/3밴드/공간감, 운전석 오디오 미해결 상태 모두 보존.
- 로컬 검증: 실제 EQ Kotlin 독립 컴파일 PASS, 신규 API 계약 8/8, 차량 32/32, EQ 17/17+37/37, 수집 복구 26/26, AVAS 후보 추적 Kotlin 재현 PASS, workflow 구문 및 ZIP 무결성 점검. 한 차례 반복 Kotlin 재검사는 실행 제한으로 중단돼 전체 Android SDK 컴파일 성공으로 주장하지 않는다.
- 미확인: Android Gradle APK 전체 빌드 및 실제 차량 v0.17.7 재검증은 미실시. DA-013/DA-015 빌드 이슈는 `CI_V0176_FAILED / SOURCE_PATCH_V0177 / CI_REBUILD_REQUIRED`; DA-029/DA-012 실차 상태는 변경하지 않음.
