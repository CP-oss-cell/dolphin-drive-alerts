#!/usr/bin/env python3
"""Guard against the two confirmed GitHub Actions v0.17.5 Kotlin compilation errors.
This test checks source API contracts; Android Gradle is the authoritative full build.
"""
from pathlib import Path
import re,sys
p=Path(__file__).resolve().parents[1]
s=(p/'app/src/main/java/com/byd/dolphin/drivealerts/audio/GlobalEqualizerEngine.kt').read_text()
g=(p/'app/build.gradle.kts').read_text()
checks={
 'Virtualizer_setStrength_is_Unit_not_Int': 'v.setStrength(strength)' in s and 'sc == AudioEffect.SUCCESS' not in s and 'val sc = v.setStrength' not in s,
 'Virtualizer_readback_kept': 'v.roundedStrength' in s and 'v.virtualizationMode' in s and 'v.enabled' in s,
 'Virtualizer_exception_cleanup_kept': 'if (!result.startsWith("API_ON")) releaseVirtualizer()' in s,
 'DP_count_explicit_api': s.count('e.getChannelCount()')==3 and 'e.channelCount' not in s and 'cfg.channelCount' not in s,
 'DP_original_config_restore': 'cfg.getChannelByChannelIndex(c)' in s and 'e.setChannelTo(c,' in s,
 'SDK_Config_stub_does_not_fake_channelCount': 'val channelCount' not in (p/'tools/tests/eq_v0177/AudioFx.kt').read_text(),
 'EQ_ON_OFF_restore_retained': 'if (!s.enabled)' in s and 'sessions.values.forEach { it.close() }' in s,
 'correct_app_release': 'versionCode = 33' in g and '0.17.7-eq-sdk-api-fix' in g,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
print('v0177-contract-check',sum(checks.values()),'/',len(checks))
if not all(checks.values()):sys.exit(1)
