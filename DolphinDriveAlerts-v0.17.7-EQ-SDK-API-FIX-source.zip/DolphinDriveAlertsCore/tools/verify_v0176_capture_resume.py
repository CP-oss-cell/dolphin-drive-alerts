from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=root/'app/src/main/java/com/byd/dolphin/drivealerts'
def read(p):return (main/p).read_text()
s=read('service/DrivingAlertService.kt'); boot=read('service/BootReceiver.kt')
capture=read('log/UnifiedLogCapture.kt'); lifecycle=read('log/CaptureContinuity.kt')
ui=read('ui/MainActivity.kt'); gradle=(root/'app/build.gradle.kts').read_text()
checks={
 'version-0176': 'versionCode = 32' in gradle and '0.17.6-compiler-fix' in gradle,
 'persisted-same-session': 'CaptureContinuity.serviceRestored(this, recovering.id)' in s and 'putString(SESSION, id)' in capture,
 'initial-recovery-only-when-recording': 'if (recovering.status == UnifiedLogCapture.RECORDING && recovering.id.isNotBlank())' in s,
 'reflective-oem-loader-retained': 'Class.forName("com.byd.dolphin.drivealerts.log.BydEventTap")' in s,
 'service-start-foreground-first': s.index('startForeground(NOTIFICATION_ID')<s.index('RawSignalLogger(this)'),
 'sticky-service': 'return START_STICKY' in s,
 'manual-start-not-regressed': 'ACTION_CAPTURE_BEGIN' in s and 'UnifiedLogCapture.begin(this, rawLogger, diagnostics)' in s,
 'manual-end-not-regressed': 'ACTION_CAPTURE_END' in s and 'UnifiedLogCapture.finish(this, rawLogger, diagnostics)' in s,
 'resume-source-kept': 'ACTION_CAPTURE_WAKE' in s and 'EXTRA_WAKE_SOURCE' in s,
 'wake-aware-rebind': 'rebindCaptureTap("ignition:$source", force = hardWake)' in s,
 'rebind-on-hard-wake': all(x in s for x in ['com.byd.action.ACC_ON','com.byd.action.IGN_ON','ACTION_BOOT_COMPLETED']),
 'no-poweroff-writes': boot.index('if (action in STOP_SIDE_ACTIONS)') < boot.index('DrivingAlertService.wakeRecording'),
 'boot-rearms-on-capture': 'recording != null && action in CAPTURE_WAKE_ACTIONS' in boot,
 'explicit-end-no-active-retry': 'state.status != UnifiedLogCapture.RECORDING' in s,
 'retry-bounded': 'nextTapRetryMs = if (ok) 0L else now + 30_000L' in s,
 'retry-deduplicated': 'tapRetryQueued.compareAndSet(false, true)' in s,
 'listener-readonly': 'setSoundType(' not in s and 'setSoundFreq(' not in s,
 'periodic-heartbeat': 'CaptureContinuity.heartbeat(this, capture.id)' in s,
 'persistent-journal': 'getSharedPreferences(PREF' in lifecycle and 'MAX_EVENTS = 128' in lifecycle,
 'gap-report': 'POSSIBLE_CAPTURE_GAP' in lifecycle and 'SERVICE_RESTORED' in lifecycle,
 'export-continuity-json': 'ZipEntry("lifecycle/capture_continuity.json")' in capture,
 'session-export-raw': 'ZipEntry("logs/vehicle_events.jsonl")' in capture,
 'clear-journal-only-after-success': 'CaptureContinuity.clear(context, state.id)' in capture,
 'failed-save-recovery-unchanged': 'putString(STATUS, FAILED)' in capture,
 'restarted-UI-honest': '전원 OFF 구간은 누락 가능' in ui,
 'no-new-permissions': '<uses-permission android:name="android.permission.WRITE_SECURE_SETTINGS"' in (root/'app/src/main/AndroidManifest.xml').read_text(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' '+k)
print('CHECKS',sum(checks.values()),'/',len(checks))
if not all(checks.values()):raise SystemExit(2)
