#!/usr/bin/env python3
"""Compile the ACTUAL EQ engine against deliberately strict Android API stubs.
Never substitute this for a full Gradle/Android SDK build, which GitHub Actions performs.
"""
from pathlib import Path
import shutil, subprocess, tempfile, sys
p = Path(__file__).resolve().parents[1]
comp = shutil.which('kotlinc')
if not comp:
    print('SKIP: kotlinc unavailable; full Gradle Android compile is required in CI')
    sys.exit(0)
sources = sorted((p/'tools/tests/eq_v0177').glob('*.kt'))
sources += [p/'app/src/main/java/com/byd/dolphin/drivealerts/audio'/x for x in ('GlobalEqualizerEngine.kt','EqPreferences.kt','EqToneCurve.kt')]
with tempfile.TemporaryDirectory(prefix='eq_android_api_contract_') as d:
    cp=subprocess.run([comp,*map(str,sources),'-d',str(Path(d)/'compiled.jar')],capture_output=True,text=True,timeout=90)
    if cp.returncode != 0:
        print('FAIL: actual EQ engine Kotlin compilation against strict Android API stubs')
        print((cp.stdout+cp.stderr)[-7000:])
        sys.exit(cp.returncode)
print('PASS: ACTUAL GlobalEqualizerEngine.kt + EqPreferences.kt + EqToneCurve.kt compile with Virtualizer.setStrength=Unit and DynamicsProcessing.getChannelCount()')
