package android.content

open class BroadcastReceiver { open fun onReceive(context: Context?, intent: Intent?) {} }
open class Intent(val action: String? = null) {
    fun getIntExtra(name: String, defaultValue: Int) = defaultValue
    fun getStringExtra(name: String): String? = "third.party"
}
class IntentFilter { fun addAction(action: String) {} }
class SharedPreferences {
    fun getBoolean(key: String, defaultValue: Boolean) = defaultValue
    fun getInt(key: String, defaultValue: Int) = defaultValue
    fun getString(key: String, defaultValue: String?): String? = defaultValue
    fun edit() = Editor()
    class Editor {
        fun putString(key: String, value: String) = this
        fun putBoolean(key: String, value: Boolean) = this
        fun putInt(key: String, value: Int) = this
        fun apply() {}
    }
}
open class Context {
    companion object { const val MODE_PRIVATE = 0 }
    open val applicationContext: Context get() = this
    open val packageName: String get() = "com.byd.dolphin.drivealerts"
    fun registerReceiver(receiver: BroadcastReceiver, filter: IntentFilter): Intent? = null
    fun unregisterReceiver(receiver: BroadcastReceiver) {}
    fun getSharedPreferences(name: String, mode: Int) = SharedPreferences()
}
