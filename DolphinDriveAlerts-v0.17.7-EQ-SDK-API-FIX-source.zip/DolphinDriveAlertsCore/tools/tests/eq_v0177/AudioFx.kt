package android.media.audiofx

open class AudioEffect {
    companion object {
        const val SUCCESS: Int = 0
        const val ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION = "open"
        const val ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION = "close"
        const val EXTRA_AUDIO_SESSION = "session"
        const val EXTRA_PACKAGE_NAME = "package"
    }
    @set:JvmName("setEnabledProperty") var enabled: Boolean = false
    fun setEnabled(enabled: Boolean): Int { this.enabled = enabled; return SUCCESS }
    fun hasControl(): Boolean = true
    fun release() {}
}
class Equalizer(priority: Int, sessionId: Int): AudioEffect() {
    val numberOfBands: Short = 5
    val bandLevelRange: ShortArray = shortArrayOf(-1500, 1500)
    fun getBandLevel(band: Short): Short = 0
    fun getCenterFreq(band: Short) = 1000
    fun setBandLevel(band: Short, level: Short) {}
}
class Virtualizer(priority: Int, sessionId: Int): AudioEffect() {
    companion object { const val VIRTUALIZATION_MODE_OFF = 0 }
    val strengthSupported: Boolean = true
    val roundedStrength: Short = 100
    val virtualizationMode: Int = 1
    // Android API contract: Unit / void, NOT Int
    fun setStrength(strength: Short): Unit = Unit
}
class DynamicsProcessing(priority: Int, sessionId: Int, cfg: Config): AudioEffect() {
    companion object { const val VARIANT_FAVOR_FREQUENCY_RESOLUTION = 0 }
    class EqBand(val enabled: Boolean, val cutoffFrequency: Float, val gain: Float)
    class Channel
    class Config {
        val isPreEqInUse = true
        val preEqBandCount = 10
        fun getPreEqBandByChannelIndex(channel: Int, band: Int) = EqBand(true, 1000f, 0f)
        fun getChannelByChannelIndex(channel: Int) = Channel()
        class Builder(variant: Int, channelCount: Int, preEqInUse: Boolean, preEqBands: Int,
                      mbcInUse: Boolean, mbcBands: Int, postEqInUse: Boolean, postEqBands: Int,
                      limiterInUse: Boolean) {
            fun setPreferredFrameDuration(ms: Float) = this
            fun build() = Config()
        }
    }
    val config: Config = cfg
    // Android class defines an explicit method, not a Kotlin property
    fun getChannelCount(): Int = 2 // Config has no channel count public API
    fun getPreEqBandByChannelIndex(c: Int, i: Int) = EqBand(true, 1000f, 0f)
    fun getInputGainByChannelIndex(c: Int): Float = 0f
    fun setPreEqBandAllChannelsTo(band: Int, eqBand: EqBand) {}
    fun setInputGainAllChannelsTo(value: Float) {}
    fun setChannelTo(channel: Int, state: Channel) {}
}
