# v0.17.6 GitHub Actions build procedure (compile fix)
1. In repository `CP-oss-cell/dolphin-drive-alerts` upload `DolphinDriveAlerts-v0.17.6-COMPILER-FIX-source.zip` at root. Keep older ZIPs for rollback.
2. Upload `build-v0176-from-source-zip.yml` to `.github/workflows/`.
3. Actions > `Build Dolphin Drive Alerts v0.17.6 ...` > `Run workflow` (main).
4. If success, download artifact `DolphinDriveAlerts-v0.17.6-COMPILER-FIX`, extract and install the APK (do not install while driving).
5. If failure, share exact Kotlin diagnostics from uploaded failure log. Do not assume a full APK was compiled until GitHub run succeeds.
