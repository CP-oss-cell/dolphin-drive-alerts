package app.mideumhanatube.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import androidx.media3.common.MediaItem;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hosts an independent Media3 ExoPlayer for background audio. The WebView is
 * used only while on-screen; on Home, we request a separate stream and seek
 * to the last known video time. Stream availability is not guaranteed.
 */
public final class BackgroundAudioService extends Service {
    public static final String ACTION_NATIVE_START = "app.mideumhanatube.android.native.START";
    public static final String ACTION_NATIVE_READY = "app.mideumhanatube.android.native.READY";
    public static final String ACTION_NATIVE_FAILURE = "app.mideumhanatube.android.native.FAIL";
    public static final String ACTION_NATIVE_RETURN = "app.mideumhanatube.android.native.RETURN";
    public static final String ACTION_NATIVE_POSITION = "app.mideumhanatube.android.native.POSITION";
    public static final String ACTION_NATIVE_STOP = "app.mideumhanatube.android.native.STOP";
    public static final String ACTION_NATIVE_QUERY = "app.mideumhanatube.android.native.QUERY";
    public static final String EXTRA_MEDIA_URL = "media_url";
    public static final String EXTRA_POSITION_MS = "position_ms";
    public static final String EXTRA_KIND = "stream_kind";
    public static final String ACTION_UPDATE = "app.mideumhanatube.android.media.UPDATE";
    public static final String ACTION_PLAY = "app.mideumhanatube.android.media.PLAY";
    // Native notification controls and PiP/WebView controls must not be conflated.
    public static final String ACTION_WEB_PLAY = "app.mideumhanatube.android.media.WEB_PLAY";
    public static final String ACTION_WEB_PAUSE = "app.mideumhanatube.android.media.WEB_PAUSE";
    public static final String ACTION_PAUSE = "app.mideumhanatube.android.media.PAUSE";
    public static final String ACTION_STOP = "app.mideumhanatube.android.media.STOP";
    public static final String ACTION_CONTROL = "app.mideumhanatube.android.media.CONTROL";
    public static final String ACTION_FEEDBACK = "app.mideumhanatube.android.media.FEEDBACK";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_PLAYING = "playing";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_CONTROL = "control";
    private static final String CHANNEL_ID = "mht_background_audio";
    private static final int NOTIFICATION_ID = 1002;
    private static final long PAUSED_TIMEOUT_MS = 120_000L;

    // Java field initializers run in declaration order. State referenced from
    // stopWhenPaused must be declared before its lambda initializer.
    private boolean playing;
    private static volatile boolean nativeSessionExists;
    public static boolean hasNativeAudioSession() { return nativeSessionExists; }
    private boolean nativePreparing;
    private boolean nativeMode;
    // UI intention is independent of actual audio output and buffering state.
    private boolean nativePlayRequested;
    private boolean reportedNativeReady;
    private long traceSession;
    private boolean foregroundActive;
    private ExoPlayer nativePlayer;
    private long firstAudioPlayingAt = -1L;
    private long firstAudioPositionMs = -1L;
    private final Runnable confirmStableAudio = () -> {
        if (!nativeMode || nativePreparing || reportedNativeReady || nativePlayer == null) return;
        long duration = firstAudioPlayingAt < 0 ? 0 :
                android.os.SystemClock.elapsedRealtime() - firstAudioPlayingAt;
        long progress = firstAudioPositionMs < 0 ? 0 :
                nativePlayer.getCurrentPosition() - firstAudioPositionMs;
        if (nativePlayer.isPlaying() && duration >= 1200L && progress >= 350L) {
            reportedNativeReady = true;
            nativeSessionExists = true;
            cancelNativeBufferTimeout();
            PlaybackDiagnostics.event(this, traceSession, "PLAY_STABLE_CONFIRMED", "POSITION_ADVANCING", nativePlayer);
            noteAudioStage("재생 성공", "독립 오디오 재생 위치가 1초 이상 증가함");
            sendNativeState(ACTION_NATIVE_READY, null, nativePlayer.getCurrentPosition());
        } else if (nativePlayer.isPlaying()) {
            PlaybackDiagnostics.event(this, traceSession, "POSITION_NOT_ADVANCING", "RECHECK", nativePlayer);
            scheduleConfirmation();
        }
    };
    private static final long BUFFERING_TIMEOUT_MS = 35_000L;
    private final Runnable nativeBufferTimeout = () -> {
        if (!nativeMode || nativePreparing || nativePlayer == null) return;
        PlaybackStatePolicy.Phase phase = nativePhase();
        if (phase == PlaybackStatePolicy.Phase.BUFFERING || phase == PlaybackStatePolicy.Phase.READY_WAIT ||
                phase == PlaybackStatePolicy.Phase.SUPPRESSED ||
                (phase == PlaybackStatePolicy.Phase.PLAYING && !reportedNativeReady)) {
            PlaybackDiagnostics.event(this, traceSession, "BUFFERING_TIMEOUT", phase.name(), nativePlayer);
            failNative("독립 오디오 준비 시간 초과: 실제 재생이 시작되지 않았습니다.");
        }
    };
    // Prepare the same stream while the Activity is still foreground and playing;
    // on Home the player can start without waiting for a new extractor request.
    private String lastWebVideoUrl;
    private long lastWebVideoPositionMs;
    private String prefetchedUrl;
    private YouTubeStreamResolver.Result prefetchedStream;
    private boolean prefetchRunning;
    private int prefetchGeneration;
    private long prefetchedAtMs;
    private String activeNativeUrl;
    private long activeNativeStartMs;
    private String prefetchError = "";
    private final Runnable nativeTransitionTimeout = () -> {
        if (nativeMode && nativePreparing) failNative("오디오 전환 시간 초과 (40초). 음악 설정의 재생 진단을 확인하세요.");
    };
    private static final long PREFETCH_TTL_MS = 180_000L;
    private int nativeGeneration;
    private final ExecutorService extractionWorker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stopWhenPaused = () -> {
        if (!playing && !nativePreparing && (!nativeMode || !PlaybackStatePolicy.keepForeground(nativePhase())))
            stopSelf();
    };
    private MediaSession session;
    private PowerManager.WakeLock wakeLock;
    private String title = "믿음하나튜브";
    private String playbackMessage = "재생 상태 확인 중";
    private boolean awaitingPlaybackConfirmation;
    private final Runnable noPlayerResponse = () -> {
        if (awaitingPlaybackConfirmation) {
            awaitingPlaybackConfirmation = false;
            playbackMessage = "웹 플레이어의 재생 응답 없음. 앱 화면을 확인하세요.";
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "백그라운드 음악 재생",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("믿음하나튜브가 음악을 재생할 때 표시합니다.");
            channel.setSound(null, null);
            nm.createNotificationChannel(channel);
        }
        PlaybackDiagnostics.event(this, 0, "SERVICE_CREATED", "FGS_MEDIA", null);
        session = new MediaSession(this, "MideumHanaTubeBackgroundAudio");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { requestPlayerControl(ACTION_PLAY); }
            @Override public void onPause() { requestPlayerControl(ACTION_PAUSE); }
            @Override public void onStop() { relay(ACTION_STOP); stopSelf(); }
        });
        session.setActive(true);
        // Media URLs extracted from YouTube may reject ExoPlayer's default UA.
        // Browser-like User-Agent and origin headers improve compatibility;
        // they do not bypass the server's access checks or guarantee playback.
        DefaultHttpDataSource.Factory mediaHttp = new DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(Collections.singletonMap("Referer", "https://www.youtube.com/"));
        nativePlayer = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(mediaHttp))
                .build();
        // The native player, not the WebView, owns playback once the stream starts.
        nativePlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(), true);
        nativePlayer.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (!nativeMode || nativePreparing) return;
                PlaybackStatePolicy.Phase phase = nativePhase();
                PlaybackDiagnostics.event(BackgroundAudioService.this, traceSession, "PLAYER_STATE", phase.name(), nativePlayer);
                updateNativeMessage(phase);
                updateSessionAndNotification();
            }
            @Override public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                if (!nativeMode) return;
                nativePlayRequested = playWhenReady;
                PlaybackDiagnostics.event(BackgroundAudioService.this, traceSession,
                        "PLAY_INTENT", playWhenReady ? "WANTS_PLAY" : "WANTS_PAUSE", nativePlayer);
                updateSessionAndNotification();
            }
            @Override public void onIsPlayingChanged(boolean isPlaying) {
                if (!nativeMode || nativePreparing) return;
                playing = isPlaying;
                PlaybackStatePolicy.Phase phase = nativePhase();
                PlaybackDiagnostics.event(BackgroundAudioService.this, traceSession,
                        "ACTUAL_PLAYING", phase.name(), nativePlayer);
                updateNativeMessage(phase);
                if (isPlaying) {
                    if (!reportedNativeReady) {
                        firstAudioPlayingAt = android.os.SystemClock.elapsedRealtime();
                        firstAudioPositionMs = nativePlayer.getCurrentPosition();
                        scheduleConfirmation();
                    }
                } else {
                    handler.removeCallbacks(confirmStableAudio);
                    if (!reportedNativeReady && firstAudioPlayingAt > 0 && nativePlayRequested &&
                            android.os.SystemClock.elapsedRealtime() - firstAudioPlayingAt < 1500L) {
                        PlaybackDiagnostics.event(BackgroundAudioService.this, traceSession,
                                "PLAY_INTERRUPTED_EARLY", phase.name(), nativePlayer);
                    }
                    firstAudioPlayingAt = -1L;
                    firstAudioPositionMs = -1L;
                }
                if (!isPlaying && phase == PlaybackStatePolicy.Phase.BUFFERING) {
                    noteAudioStage("독립 재생 중단", "스트림 버퍼링 중");
                } else if (phase == PlaybackStatePolicy.Phase.SUPPRESSED) {
                    noteAudioStage("독립 재생 중단", "오디오 포커스/시스템 재생 억제");
                } else if (phase == PlaybackStatePolicy.Phase.ENDED) {
                    noteAudioStage("독립 재생 중단", "스트림 재생 종료");
                }
                updateSessionAndNotification();
            }
            @Override public void onPlayerError(PlaybackException error) {
                if (!nativeMode) return;
                PlaybackDiagnostics.event(BackgroundAudioService.this, traceSession,
                        "PLAYER_ERROR", PlaybackDiagnostics.categorize(error), nativePlayer);
                failNative(describePlaybackFailure(error));
            }
        });
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MideumHanaTube:BackgroundAudio");
            wakeLock.setReferenceCounted(false);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();
        PlaybackDiagnostics.event(this, traceSession, "SERVICE_ACTION",
                classifyAction(action), nativeMode ? nativePlayer : null);
        if (ACTION_STOP.equals(action)) {
            relay(ACTION_STOP);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_NATIVE_START.equals(action)) {
            beginNativeAudio(intent);
        } else if (ACTION_NATIVE_RETURN.equals(action) || ACTION_NATIVE_QUERY.equals(action)) {
            if (nativeMode && !nativePreparing && nativePlayer != null)
                sendNativeState(ACTION_NATIVE_POSITION, null, nativePlayer.getCurrentPosition());
        } else if (ACTION_NATIVE_STOP.equals(action)) {
            stopNativeAudio();
        } else if (ACTION_PLAY.equals(action) || ACTION_PAUSE.equals(action)) {
            requestPlayerControl(action);
        } else if (ACTION_WEB_PLAY.equals(action) || ACTION_WEB_PAUSE.equals(action)) {
            // PiP controls operate on the visible HTML video, not a new audio player.
            relay(ACTION_WEB_PLAY.equals(action) ? ACTION_PLAY : ACTION_PAUSE);
        } else if (ACTION_UPDATE.equals(action)) {
            if (nativeMode || nativePreparing) return START_NOT_STICKY;
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            playing = intent.getBooleanExtra(EXTRA_PLAYING, false);
            String nextTitle = intent.getStringExtra(EXTRA_TITLE);
            if (nextTitle != null && !nextTitle.trim().isEmpty()) title = nextTitle;
            playbackMessage = playing ? "영상 재생 중 (음악 전환 준비)" : "재생 일시중지";
            String visiblePageUrl = intent.getStringExtra(EXTRA_MEDIA_URL);
            if (YouTubeStreamResolver.isSupportedVideoUrl(visiblePageUrl)) {
                lastWebVideoUrl = visiblePageUrl;
                lastWebVideoPositionMs = Math.max(0L, intent.getLongExtra(
                        EXTRA_POSITION_MS, lastWebVideoPositionMs));
                if (playing) prefetchStream(visiblePageUrl, false);
            }
        } else if (ACTION_FEEDBACK.equals(action)) {
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            String error = intent.getStringExtra(EXTRA_ERROR);
            if (error != null && !error.trim().isEmpty()) {
                playing = false;
                playbackMessage = error;
            }
        } else {
            stopSelf();
            return START_NOT_STICKY;
        }
        updateSessionAndNotification();
        return START_NOT_STICKY;
    }

    private void beginNativeAudio(Intent input) {
        String url = input.getStringExtra(EXTRA_MEDIA_URL);
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) {
            failNative("유튜브 영상 주소를 확인하지 못했습니다.");
            return;
        }
        if (nativeMode && (nativePreparing || nativePlayer != null && nativePlayer.isPlaying())) {
            PlaybackDiagnostics.event(this, traceSession,
                    "HANDOFF_DUPLICATE_SKIPPED", "ALREADY_ACTIVE", nativePlayer);
            return;
        }
        activeNativeUrl = url;
        lastWebVideoUrl = url;
        activeNativeStartMs = Math.max(0L, input.getLongExtra(EXTRA_POSITION_MS, 0L));
        lastWebVideoPositionMs = activeNativeStartMs;
        String proposedTitle = input.getStringExtra(EXTRA_TITLE);
        if (proposedTitle != null && !proposedTitle.trim().isEmpty()) title = proposedTitle;
        traceSession = input.getLongExtra("trace_session", 0L);
        if (traceSession <= 0) traceSession = PlaybackDiagnostics.nextSession(this);
        nativePreparing = true;
        nativeMode = true;
        nativePlayRequested = true;
        reportedNativeReady = false;
        firstAudioPlayingAt = -1L;
        firstAudioPositionMs = -1L;
        handler.removeCallbacks(confirmStableAudio);
        PlaybackDiagnostics.event(this, traceSession, "HANDOFF_ACCEPTED", "PREFETCH_CHECK", nativePlayer);
        awaitingPlaybackConfirmation = false;
        handler.removeCallbacks(noPlayerResponse);
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.postDelayed(nativeTransitionTimeout, 40_000L);
        playing = false; // never claim audio output before the actual player reports it
        playbackMessage = "독립 오디오 전환 중…";
        noteAudioStage("오디오 전환 요청", "영상 주소 확인 완료, 독립 오디오 시작 대기");
        updateSessionAndNotification();
        if (isValidPrefetchedStream(url)) {
            startResolvedAudio(prefetchedStream);
        } else if (!prefetchRunning || !url.equals(prefetchedUrl)) {
            // Cached lookup failed earlier, or the page changed: retry once on Home.
            prefetchStream(url, true);
        }
        // If the exact URL is already being prefetched, its completion callback
        // will call startResolvedAudio, avoiding two network requests.
    }

    private boolean isValidPrefetchedStream(String url) {
        return url != null && url.equals(prefetchedUrl) && prefetchedStream != null &&
                android.os.SystemClock.elapsedRealtime() - prefetchedAtMs < PREFETCH_TTL_MS;
    }

    /** Prepares the stream address asynchronously WHILE viewing the video.
     * Does not pause, restart, or seek the current WebView player.
     */
    private void prefetchStream(String url, boolean force) {
        if (!YouTubeStreamResolver.isSupportedVideoUrl(url)) return;
        if (!force && (isValidPrefetchedStream(url) ||
                (prefetchRunning && url.equals(prefetchedUrl)))) return;
        final int generation = ++prefetchGeneration;
        prefetchedUrl = url;
        prefetchedStream = null;
        prefetchRunning = true;
        prefetchError = "";
        noteAudioStage("스트림 미리 준비 중", "재생 중 연결 주소를 확인하는 중");
        PlaybackDiagnostics.event(this, traceSession, "EXTRACT_BEGIN", "HTTPS_MEDIA_INFO", null);
        extractionWorker.execute(() -> {
            try {
                YouTubeStreamResolver.Result info = YouTubeStreamResolver.resolve(url);
                handler.post(() -> {
                    if (generation != prefetchGeneration) return;
                    prefetchRunning = false;
                    prefetchedStream = info;
                    prefetchedAtMs = android.os.SystemClock.elapsedRealtime();
                    prefetchError = "";
                    noteAudioStage("스트림 준비 완료", "오디오: " + info.streamKind);
                    PlaybackDiagnostics.event(this, traceSession, "EXTRACT_OK", "KIND_" + info.streamKind.toUpperCase(java.util.Locale.ROOT), null);
                    if (nativeMode && nativePreparing && url.equals(activeNativeUrl))
                        startResolvedAudio(info);
                });
            } catch (Exception | LinkageError error) {
                handler.post(() -> {
                    if (generation != prefetchGeneration) return;
                    prefetchRunning = false;
                    prefetchedStream = null;
                    String reason = error.getMessage();
                    prefetchError = reason == null ? error.getClass().getSimpleName() : reason;
                    noteAudioStage("스트림 연결 실패", prefetchError);
                    PlaybackDiagnostics.event(this, traceSession, "EXTRACT_ERROR", "EXTRACTION_FAILED", null);
                    if (nativeMode && nativePreparing && url.equals(activeNativeUrl))
                        failNative("오디오 주소를 얻지 못했습니다: " + prefetchError);
                });
            }
        });
    }

    private void startResolvedAudio(YouTubeStreamResolver.Result result) {
        if (!nativeMode || !nativePreparing || nativePlayer == null) return;
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.removeCallbacks(nativeBufferTimeout);
        nativePreparing = false;
        handler.postDelayed(nativeBufferTimeout, BUFFERING_TIMEOUT_MS);
        title = result.title == null || result.title.isEmpty() ? title : result.title;
        playbackMessage = "독립 오디오 버퍼링 중… (" + result.streamKind + ")";
        noteAudioStage("오디오 버퍼링 중", "스트림 주소 확인 성공");
        PlaybackDiagnostics.event(this, traceSession, "PLAYER_PREPARING",
                "hls".equalsIgnoreCase(result.streamKind) ? "HLS" : "PROGRESSIVE", nativePlayer);
        try {
            // Some HLS URLs do not end in .m3u8: supply the MIME type explicitly.
            MediaItem item = "hls".equalsIgnoreCase(result.streamKind)
                    ? new MediaItem.Builder().setUri(result.streamUrl)
                        .setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8).build()
                    : MediaItem.fromUri(result.streamUrl);
            nativePlayer.setMediaItem(item);
            nativePlayer.seekTo(activeNativeStartMs);
            nativePlayer.prepare();
            if (nativePlayRequested) nativePlayer.play();
            else nativePlayer.pause();
            updateSessionAndNotification();
        } catch (RuntimeException error) {
            failNative("오디오 플레이어 시작 실패: " + error.getClass().getSimpleName());
        }
    }

    // Keep failure diagnostics concise and never disclose signed stream URLs.
    private static String describePlaybackFailure(PlaybackException error) {
        Throwable cause = error;
        for (int i = 0; i < 8 && cause != null; i++, cause = cause.getCause()) {
            if (cause instanceof HttpDataSource.InvalidResponseCodeException) {
                int status = ((HttpDataSource.InvalidResponseCodeException) cause).responseCode;
                return status == 403 ? "오디오 스트림 HTTP 403: 유튜브 서버가 접근을 거부했습니다."
                        : status == 401 ? "오디오 스트림 HTTP 401: 인증이 필요합니다."
                        : "오디오 스트림 HTTP " + status + ": 서버 응답 오류";
            }
        }
        return "오디오 스트림 오류: " + error.getErrorCodeName();
    }

    private void noteAudioStage(String stage, String reason) {
        String code = stage.contains("실패") ? "FAILURE" :
                stage.contains("버퍼링") ? "BUFFERING" :
                stage.contains("성공") ? "SUCCESS" :
                stage.contains("중단") ? "INTERRUPTION" : "PROGRESS";
        PlaybackDiagnostics.event(this, traceSession, "LEGACY_STAGE", code, nativeMode ? nativePlayer : null);
        getSharedPreferences("mht_audio_diagnostics", MODE_PRIVATE).edit()
                .putString("stage", stage)
                .putString("reason", reason)
                .putLong("timestamp", System.currentTimeMillis())
                .apply();
    }

    private void failNative(String message) {
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.removeCallbacks(nativeBufferTimeout);
        handler.removeCallbacks(confirmStableAudio);
        PlaybackDiagnostics.event(this, traceSession, "HANDOFF_FAILED", "NATIVE_FAILURE", nativePlayer);
        noteAudioStage("전환 실패", message);
        ++nativeGeneration;
        nativeMode = false;
        nativePreparing = false;
        nativePlayRequested = false;
        reportedNativeReady = false;
        nativeSessionExists = false;
        playing = false;
        if (nativePlayer != null) nativePlayer.stop();
        playbackMessage = message;
        updateSessionAndNotification();
        sendNativeState(ACTION_NATIVE_FAILURE, message, 0L);
    }

    private void stopNativeAudio() {
        PlaybackDiagnostics.event(this, traceSession, "HANDOFF_STOP", "VIDEO_RETURN", nativePlayer);
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.removeCallbacks(nativeBufferTimeout);
        handler.removeCallbacks(confirmStableAudio);
        ++nativeGeneration;
        nativeMode = false;
        nativePreparing = false;
        nativePlayRequested = false;
        reportedNativeReady = false;
        nativeSessionExists = false;
        if (nativePlayer != null) { nativePlayer.stop(); nativePlayer.clearMediaItems(); }
        playing = false;
        playbackMessage = "영상 플레이어로 전환됨";
        updateSessionAndNotification();
    }

    private void sendNativeState(String action, String message, long position) {
        Intent result = new Intent(action);
        result.setPackage(getPackageName());
        result.putExtra(EXTRA_POSITION_MS, Math.max(0L, position));
        if (message != null) result.putExtra(EXTRA_ERROR, message);
        sendBroadcast(result);
    }

    private void requestPlayerControl(String action) {
        // While in native mode, controls operate on the real ExoPlayer, not WebView.
        if (nativeMode && nativePlayer != null) {
            nativePlayRequested = ACTION_PLAY.equals(action);
            PlaybackDiagnostics.event(this, traceSession, "NOTIFICATION_CONTROL",
                    nativePlayRequested ? "PLAY" : "PAUSE", nativePlayer);
            if (nativePlayRequested) nativePlayer.play();
            else nativePlayer.pause();
            updateSessionAndNotification();
            return;
        }
        // v0.1.15: a missing native session is NOT an invitation to call
        // WebView video.play() in the background (the reported 0.1s failure).
        if (ACTION_PAUSE.equals(action)) {
            playing = false;
            playbackMessage = "일시정지";
            PlaybackDiagnostics.event(this, traceSession,
                    "NOTIFICATION_PAUSED", "NO_NATIVE_PLAYER", null);
            updateSessionAndNotification();
            return;
        }
        if (YouTubeStreamResolver.isSupportedVideoUrl(lastWebVideoUrl)) {
            PlaybackDiagnostics.event(this, traceSession,
                    "NOTIFICATION_NATIVE_START", "RESOLVE_AND_PLAY", null);
            Intent nativeIntent = new Intent(this, BackgroundAudioService.class)
                    .setAction(ACTION_NATIVE_START)
                    .putExtra(EXTRA_MEDIA_URL, lastWebVideoUrl)
                    .putExtra(EXTRA_POSITION_MS, lastWebVideoPositionMs)
                    .putExtra(EXTRA_TITLE, title);
            beginNativeAudio(nativeIntent);
        } else {
            PlaybackDiagnostics.event(this, traceSession,
                    "NOTIFICATION_NO_MEDIA", "OPEN_VIDEO_FIRST", null);
            playing = false;
            playbackMessage = "재생할 영상이 없습니다. 앱에서 영상을 열어 주세요.";
            updateSessionAndNotification();
        }
    }

    private void relay(String action) {
        Intent message = new Intent(ACTION_CONTROL);
        message.setPackage(getPackageName());
        message.putExtra(EXTRA_CONTROL, action);
        sendBroadcast(message);
    }

    private void scheduleConfirmation() {
        handler.removeCallbacks(confirmStableAudio);
        handler.postDelayed(confirmStableAudio, 1200L);
    }
    private void cancelNativeBufferTimeout() { handler.removeCallbacks(nativeBufferTimeout); }

    private PlaybackStatePolicy.Phase nativePhase() {
        return PlaybackStatePolicy.classify(nativePreparing, nativePlayRequested,
                nativePlayer == null ? Player.STATE_IDLE : nativePlayer.getPlaybackState(),
                nativePlayer != null && nativePlayer.isPlaying(),
                nativePlayer == null ? Player.PLAYBACK_SUPPRESSION_REASON_NONE : nativePlayer.getPlaybackSuppressionReason());
    }

    private void updateNativeMessage(PlaybackStatePolicy.Phase phase) {
        switch (phase) {
            case RESOLVING: playbackMessage = "독립 오디오 주소 확인 중"; break;
            case BUFFERING: playbackMessage = "독립 오디오 버퍼링 중 (재생 준비)"; break;
            case READY_WAIT: playbackMessage = "독립 오디오 준비 완료 · 출력 대기"; break;
            case PLAYING: playbackMessage = "독립 오디오 재생 중"; break;
            case SUPPRESSED: playbackMessage = "Android 오디오 포커스/출력 억제"; break;
            case PAUSED: playbackMessage = "사용자가 일시정지함"; break;
            case ENDED: playbackMessage = "독립 오디오 스트림 종료"; break;
            default: playbackMessage = "독립 오디오 상태 확인 중";
        }
    }

    private static String classifyAction(String action) {
        if (ACTION_NATIVE_START.equals(action)) return "NATIVE_START";
        if (ACTION_WEB_PLAY.equals(action)) return "PIP_WEB_PLAY";
        if (ACTION_WEB_PAUSE.equals(action)) return "PIP_WEB_PAUSE";
        if (ACTION_NATIVE_STOP.equals(action)) return "NATIVE_STOP";
        if (ACTION_NATIVE_RETURN.equals(action)) return "VIDEO_RETURN";
        if (ACTION_UPDATE.equals(action)) return "WEB_UPDATE";
        if (ACTION_PLAY.equals(action)) return "PLAY";
        if (ACTION_PAUSE.equals(action)) return "PAUSE";
        if (ACTION_STOP.equals(action)) return "STOP";
        return "OTHER";
    }

    private void updateSessionAndNotification() {
        PlaybackStatePolicy.Phase phase = nativeMode ? nativePhase() : null;
        boolean actuallyPlaying = nativeMode ? nativePlayer != null && nativePlayer.isPlaying() : playing;
        boolean buffering = nativeMode && (phase == PlaybackStatePolicy.Phase.RESOLVING ||
                phase == PlaybackStatePolicy.Phase.BUFFERING || phase == PlaybackStatePolicy.Phase.READY_WAIT);
        boolean keepForeground = nativeMode ? PlaybackStatePolicy.keepForeground(phase) : playing;
        long available = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_PLAY_PAUSE;
        int state = buffering ? PlaybackState.STATE_BUFFERING :
                (actuallyPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED);
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(available)
                .setState(state,
                        nativeMode && nativePlayer != null ? Math.max(0L, nativePlayer.getCurrentPosition()) :
                                PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                        actuallyPlaying ? 1f : 0f)
                .build());
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "믿음하나튜브")
                .build());
        Notification notification = buildNotification();
        if (keepForeground) {
            handler.removeCallbacks(stopWhenPaused);
            try {
                startForeground(NOTIFICATION_ID, notification);
                if (!foregroundActive) {
                    foregroundActive = true;
                    PlaybackDiagnostics.event(this, traceSession, "FGS_STARTED", "MEDIA_PLAYBACK",
                            nativeMode ? nativePlayer : null);
                }
            } catch (RuntimeException e) {
                PlaybackDiagnostics.event(this, traceSession, "FGS_DENIED", "ANDROID_RESTRICTION", nativePlayer);
                if (nativeMode) failNative("Android가 백그라운드 서비스 시작을 제한했습니다.");
                else stopSelf();
                return;
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        } else {
            releaseWakeLock();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, notification);
            handler.removeCallbacks(stopWhenPaused);
            handler.postDelayed(stopWhenPaused, PAUSED_TIMEOUT_MS);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 100, openIntent, flags());
        boolean wantsPlay = nativeMode ? nativePlayRequested : playing;
        String controlAction = wantsPlay ? ACTION_PAUSE : ACTION_PLAY;
        int controlIcon = wantsPlay ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String controlLabel = wantsPlay ? "일시중지" : "재생";
        Notification.Action toggle = new Notification.Action.Builder(
                controlIcon, controlLabel, servicePending(controlAction, 101)).build();
        Notification.Action stop = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "종료", servicePending(ACTION_STOP, 102)).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(playbackMessage)
                .setContentIntent(openPending)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(nativeMode ? PlaybackStatePolicy.keepForeground(nativePhase()) : playing)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(toggle)
                .addAction(stop)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0))
                .build();
    }

    private PendingIntent servicePending(String action, int id) {
        return PendingIntent.getService(this, id,
                new Intent(this, BackgroundAudioService.class).setAction(action), flags());
    }

    private static int flags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    @Override public void onDestroy() {
        nativeSessionExists = false;
        ++nativeGeneration;
        extractionWorker.shutdownNow();
        if (nativePlayer != null) { nativePlayer.release(); nativePlayer = null; }
        handler.removeCallbacks(stopWhenPaused);
        handler.removeCallbacks(noPlayerResponse);
        handler.removeCallbacks(nativeTransitionTimeout);
        handler.removeCallbacks(nativeBufferTimeout);
        handler.removeCallbacks(confirmStableAudio);
        PlaybackDiagnostics.event(this, traceSession, "SERVICE_DESTROYED", "CLEANUP", null);
        releaseWakeLock();
        if (session != null) { session.setActive(false); session.release(); session = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
