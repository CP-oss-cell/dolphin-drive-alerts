/* MideumHanaTube on-page promotional UI filter (best effort; no promise to remove in-stream ads). */
(function () {
  "use strict";
  if (!/(^|\.)youtube\.com$/i.test(location.hostname)) return;
  const styleId = "mideumhanatube-sponsored-style-v015";
  const selectors = [
    "ytm-promoted-sparkles-web-renderer", "ytm-promoted-video-renderer",
    "ytm-ad-slot-renderer", "ytm-companion-ad-renderer", "ytm-display-ad-renderer",
    "ytm-promoted-sparkles-text-search-renderer", "ytm-promoted-sparkles-text-search-renderer",
    "ytd-promoted-video-renderer", "ytd-promoted-sparkles-web-renderer",
    "ytd-display-ad-renderer", "ytd-ad-slot-renderer",
    "ytd-companion-slot-renderer", "ytd-in-feed-ad-layout-renderer",
    "ytd-banner-promo-renderer", "ytd-statement-banner-renderer",
    "ytd-rich-item-renderer[is-ad]", ".ytp-ad-overlay-container",
    ".ytp-ad-image-overlay", "#player-ads", "#masthead-ad"
  ];
  const existing = document.getElementById(styleId);
  if (window.__CS_HIDE) {
    if (!existing) {
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = selectors.join(",") + "{display:none !important;visibility:hidden !important;}";
      (document.head || document.documentElement).appendChild(style);
    }
  } else if (existing) existing.remove();
  function skipVisibleAd() {
    if (!window.__CS_SKIP) return;
    const selectors = [
      ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern", ".ytp-skip-ad-button",
      "button.ytp-ad-skip-button-modern", "button[aria-label*=\"Skip Ads\"]",
      "button[aria-label*=\"Skip ad\"]", "button[aria-label*=\"광고 건너뛰기\"]"
    ];
    for (const css of selectors) {
      const button = document.querySelector(css);
      if (button && button.getClientRects().length && !button.disabled) {
        button.click();
        break;
      }
    }
  }
  if (!window.__MHT_SKIP_TIMER) {
    window.__MHT_SKIP_TIMER = setInterval(skipVisibleAd, 350);
    document.addEventListener("visibilitychange", skipVisibleAd);
  }
})();
