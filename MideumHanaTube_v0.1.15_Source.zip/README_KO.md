# 믿음하나튜브 v0.1.15 — 실기기 83개 재생 로그 기반 수정

## 실제 로그 원인
- 실기기: Samsung Android API 37, v0.1.13. 사용자 설정 `background_enabled=true`, `auto_pip=true`.
- 기록된 83개 이벤트에서 `EXTRACT_OK`가 있었지만 `NATIVE_START`/`PLAYER_PREPARING`/`ACTUAL_PLAYING`은 없었습니다.
- 알림에서 `NOTIFICATION_WEB_FALLBACK` 반복. 이전 코드의 `!autoPip` 조건이 홈에서 네이티브 재생 전환을 차단했습니다.

## v0.1.15 수정
1. 홈 이동 시 백그라운드 오디오가 켜져 있고 재생 중이면 **PIP가 켜져 있어도 네이티브 오디오 시작을 우선**합니다. '작은 화면' 메뉴는 계속 지원합니다. 자동 PIP는 백그라운드 오디오가 꺼진 경우에만 작동합니다.
2. onPause() 예비 전환에서도 `!autoPip` 조건을 제거했습니다. 로그에는 `HOME_NATIVE_PRIORITY`, `HANDOFF_REQUESTED`, `HANDOFF_ACCEPTED`, `PLAYER_PREPARING`, `ACTUAL_PLAYING` 또는 실패 이유가 기록됩니다.
3. 알림창 Play는 WebView에 0.1초 재생 명령을 보내지 않고, 마지막으로 확인된 YouTube 주소에서 네이티브 오디오를 요청합니다. PIP 버튼은 별도의 WEB_* 명령으로 유지됩니다.
4. 모바일/데스크톱 광고 표시 요소 필터와 보이는 건너뛰기 버튼 처리를 개선했습니다. **광고를 100% 제거하는 기능으로 검증된 것은 아닙니다.**
5. 네이티브 플레이어가 추출한 오디오 스트림이 HTTP 403 등으로 거부되면 진단 ZIP에 남습니다. 서버 제한은 앱에서 해결된다고 보장하지 않습니다.
6. 캐시 삭제, 즐겨찾기, 음성검색, 종료확인, PIP 수동 실행을 유지합니다.

## 수동 서명키 설정 없는 자동 Debug APK 빌드 (이번 재발행본)

이번 패키지는 동일한 **믿음하나튜브 v0.1.15**의 **자동 서명 디버그 빌드용 재발행본**입니다. 기능이나 버전 코드는 변경하지 않았습니다.

- GitHub Actions에서 `:app:assembleDebug`를 실행합니다.
- Android Gradle Plugin이 Debug APK를 자동 서명하므로 **키 파일 생성, 암호 입력, GitHub Secrets 등록이 모두 필요 없습니다.**
- 빌드 성공 후 Actions Artifacts에서 `MideumHanaTube_v0.1.15_Debug_APK`를 받으면 됩니다.
- **중요:** GitHub의 새 러너는 서명키가 달라질 수 있으므로 기존 설치본과 덮어쓰기 업데이트가 되지 않을 수 있습니다. 지금처럼 **기존 믿음하나튜브 삭제 → 새 APK 설치**가 필요할 수 있습니다.
- 앱을 삭제하면 즐겨찾기, 방문 기록, 앱 설정 및 로그인이 초기화될 수 있습니다. 백업 없이 삭제하지 마세요.
- Debug 서명은 개발·개인 테스트 배포용으로만 사용하세요. 공개 배포나 업데이트 보존이 목적이면 별도의 고정 서명체계가 필요합니다.
- `applicationId=app.mideumhanatube.android`, `versionName=0.1.15`, `versionCode=16`은 기존과 같습니다.

이번 통합 ZIP 내부의 YAML을 **반드시 이전 GitHub Workflow 파일에 덮어쓰기** 해야 합니다. 예전 Release 전용 workflow가 같이 남아 있다면 Secrets를 요구하는 이전 workflow는 실행하지 마세요.

## 검증 한계
이 컨테이너에는 Android SDK 빌드 환경이 없어서 APK 전체 컴파일 및 기기 오디오 재생을 검증하지 못했습니다. Java/JS/정적 회귀/ZIP 검사와 로그 원인 분석은 수행했습니다. 실제 YouTube 스트림 접근 가능 여부와 광고 차단률은 별도 검증이 필요합니다.

## ZIP 배포
바깥 통합 ZIP 내부에는 `MideumHanaTube_v0.1.15_Source.zip`과 `MideumHanaTube_v0.1.15_Source.yml` 두 파일만 있습니다. 소스 ZIP을 GitHub 저장소 루트에, YML은 `.github/workflows/`로 넣어 빌드하세요. 별도 저장소 사용을 권장합니다.
