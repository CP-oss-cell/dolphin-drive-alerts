#!/usr/bin/env python3
"""Source/package preflight, not a replacement for Android assembleDebug."""
from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
checks=[]
def check(name,condition):
    checks.append((name,bool(condition)))
    print(('PASS' if condition else 'FAIL')+' PREFLIGHT '+name)
manifest=root/'app/src/main/AndroidManifest.xml'
xml=ET.parse(manifest).getroot()
ns='{http://schemas.android.com/apk/res/android}'
pkg='com.dolphin.oemhud'
base=root/'app/src/main/java/com/dolphin/oemhud'
code=lambda n:(base/n).read_text(encoding='utf-8')
check('Manifest XML parse',xml.tag=='manifest')
permissions={x.attrib.get(ns+'name') for x in xml.findall('uses-permission')}
for permission in ['android.permission.INTERNET','android.permission.FOREGROUND_SERVICE','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.BLUETOOTH','android.permission.BLUETOOTH_ADMIN','android.permission.ACCESS_FINE_LOCATION','android.permission.WRITE_SECURE_SETTINGS']:
    check('Manifest permission '+permission,permission in permissions)
for tag,klass in [('activity','.MainActivity'),('service','.BridgeService'),('service','.NavAccessibilityService'),('service','.NavNotificationService'),('receiver','.BootReceiver')]:
    present=any(x.attrib.get(ns+'name')==klass for x in xml.findall('.//'+tag))
    check('Manifest component '+klass,present)
check('Android minSDK 29',"minSdk 29" in (root/'app/build.gradle').read_text())
check('Android targetSDK 29',"targetSdk 29" in (root/'app/build.gradle').read_text())
check('App version 0.10.2',"versionCode 22" in (root/'app/build.gradle').read_text() and "versionName '0.10.2-oem-tbt-boundary'" in (root/'app/build.gradle').read_text())
check('Legacy AutoNavi compatibility isolated from OEM','AUTONAVI_STANDARD_BROADCAST_SEND' in code('BridgeService.java') and 'autonavi_ignored_for_oem' in code('BridgeService.java'))
check('TBT accepted only while enabled','getBoolean("enabled",false)' in code('BridgeService.java'))
check('Off state blocks TBT history','getBoolean("enabled",false)' in code('BridgeLog.java'))
check('MCon known packet prefix','0x19' in code('MconHudQProtocol.java') and '0x4d' in code('MconHudQProtocol.java'))
check('BLE FFF2 characteristic','0000fff2-0000-1000-8000-00805f9b34fb' in code('HudConnector.java'))
check('Monotonic BLE TTL','android.os.SystemClock.elapsedRealtime()' in code('HudConnector.java'))
check('CCCD serialization gate','descriptorPending' in code('HudConnector.java') and 'FFF1 알림 설정 응답 시간 초과' in code('HudConnector.java'))
check('Old GATT discarded on ACK timeout','GATT ACK 없음 → 새 연결에서 재전송' in code('HudConnector.java'))
check('ADB CAS gate','compareAndSet(false,true)' in code('adb/HudAdbPermissions.kt'))
check('ADB connection keeps persistent RSA files','adbkey.pub' in code('adb/NativeAdbClient.kt'))
check('No root request in runtime','su -c' not in '\n'.join(p.read_text(errors='ignore') for p in base.rglob('*') if p.is_file()))
check('CI workflow exists',(root/'.github/workflows/build-oem-hud-bridge.yml').is_file())
check('HUD setting validated protocol', 'isSettingsFrame' in code('HudSettingsProtocol.java'))
check('Camera buzzer / brightness controls', 'ACTION_BUZZER' in code('MainActivity.java') and 'ACTION_BRIGHTNESS' in code('MainActivity.java'))

# v0.9 dashboard contract: one owner for each feature, no legacy duplicate action menus.
ui=code('MainActivity.java')
check('Dashboard single owner for buzzer + brightness',ui.count('경보음·밝기 함께 저장 및 전송')==1)
check('Dashboard ADB single setup action',ui.count('ADB 연결·권한 적용')>=1 and 'HudAdbPermissions.connect' in ui and 'HudAdbPermissions.apply(this,true' in ui)
check('Dashboard operational start/stop single toggle','toggleRunning()' in ui and '운행 연동' in ui)
check('Dashboard advanced diagnostics collapsed by default','advancedContent.setVisibility(View.GONE)' in ui)
check('Navigation package fallback', 'NavPackageMatcher.likely' in code('BridgeLog.java'))
check('BLE duplicate connection suppression','desired.getAddress().equalsIgnoreCase' in code('HudConnector.java'))
check('Accessibility diagnostics','nav_accessibility_count' in code('NavAccessibilityService.java'))
check('Picker registered not exported',any(x.attrib.get(ns+'name')=='.NavAppPickerActivity' and x.attrib.get(ns+'exported')=='false' for x in xml.findall('.//activity')))
check('Picker clearly visible once at top',ui.count('① 설치된 내비 앱 목록 열기')>=1 and 'button(hero' in ui and 'new Intent(this,NavAppPickerActivity.class)' in ui and 'button(operation,"설치된' not in ui)
check('No duplicate manual package edit','packageInput' not in ui and '내비 앱 지정 저장' not in ui)
check('App picker stores exact existing preference key','putString("nav_package",packageName)' in code('NavAppPickerActivity.java'))
check('App picker explicitly supports automatic detection','자동 감지 사용 (앱 지정 해제)' in code('NavAppPickerActivity.java'))
check('Picker defaults to all apps including OEM','includeSystem.setChecked(true)' in code('NavAppPickerActivity.java') and 'getInstalledApplications(0)' in code('NavAppPickerActivity.java'))
check('App picker shows icons and labels','getApplicationIcon' in code('NavAppPickerActivity.java') and 'getApplicationLabel' in code('NavAppPickerActivity.java'))
check('App search and dedup support','NavAppCatalog.visible' in code('NavAppPickerActivity.java') and 'HashSet<String> seen' in code('NavAppCatalog.java'))
check('Dashboard v0.9 branding','순정 내비 HUD 대시보드' in ui)
check('Runtime APK version shown and saved','installedVersion()' in ui and '실행 APK 버전' in ui and 'String report="Dolphin OEM HUD Bridge "+installedVersion()' in ui)
check('Version code in build and picker diagnostic','versionCode 22' in (root/'app/build.gradle').read_text() and '내비 앱 목록 화면 열기' in ui)
check('OEM TMAP manifest-confirmed package recognized', 'com.tmap.auto.byd' in code('NavPackageMatcher.java'))
check('Accessibility reads only navigator labelled nodes', 'pkg.contentEquals(owner)' in code('NavAccessibilityService.java'))
check('Accessibility event-independent polling', 'periodicGuideScan' in code('NavAccessibilityService.java'))
check('Accessibility multiple window fallback', 'getWindows()' in code('NavAccessibilityService.java'))
nav_checker=root/'tools/run_nav_receiver_typecheck.sh'
nav_checker_content=nav_checker.read_text(encoding='utf-8') if nav_checker.exists() else ''
check('Navigation receiver type-check implementation exists', nav_checker.is_file() and 'javac -encoding UTF-8' in nav_checker_content and 'NavAccessibilityService.java' in nav_checker_content and 'NavNotificationService.java' in nav_checker_content and 'BridgeLog.java' in nav_checker_content)
check('Navigation receiver type-check step in bundled CI', 'bash tools/run_nav_receiver_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8'))
check('OEM Binder probe is metadata and descriptor only',
    'getInterfaceDescriptor()' in code('OemTmapBinderProbe.java')
    and 'INaviService' in code('OemTmapBinderProbe.java')
    and 'transact(' not in code('OemTmapBinderProbe.java')
    and 'bindService(' in code('OemTmapBinderProbe.java'))
check('OEM Binder probe starts in dashboard', 'OemTmapBinderProbe.start(this)' in ui)
check('OEM service probe failure and success explicitly separated',
    'BIND_DENIED' in code('OemTmapBinderProbe.java') and 'AIDL_BOUND_NO_TBT' in code('OemTmapBinderProbe.java'))
check('OEM Binder diagnosis in exported report', 'oem_binder_state' in ui and 'oem_binder_permission' in ui)
check('MCon model-aware transport retained', 'MconBleProfiles.fromService' in code('HudConnector.java'))
check('HUD-RE-005 verification in CI', 'bash tools/run_oem_binder_probe_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text())
check('No hidden TMAP Binder calls', 'transact(' not in '\n'.join(code(n) for n in ('BridgeService.java','NavAccessibilityService.java')))
check('Accessibility windows requested', 'flagRetrieveInteractiveWindows' in (root/'app/src/main/res/xml/nav_accessibility.xml').read_text())
check('Missing foreground bridge restarted on cue', 'pending_direction' in code('BridgeLog.java') and 'deliverPending()' in code('BridgeService.java'))
check('TBT stages separately counted', 'nav_parsed_count' in ui and 'nav_tbt_hud_attempts' in ui)
# v0.9.7: release metadata is authoritative; raw YML bytes must never gate the build.
check('Dark theme applied to both activities', 'Theme.Material.NoActionBar' in (root/'app/src/main/AndroidManifest.xml').read_text() and 'SURFACE=Color.rgb(11,16,24)' in ui and 'root.setBackgroundColor(Color.rgb(11,16,24))' in code('NavAppPickerActivity.java'))
check('HUD incoming FFF1 notification diagnostics', 'onCharacteristicChanged' in code('HudConnector.java') and 'hud_notify_count' in ui)
check('User-initiated parked HUD output check', 'HUD 연결 진단' in ui and 'ACTION_DEMO' in ui)
check('Selected FFF1+FFF2 same service', 'notifyCandidate' in code('HudConnector.java') and 'chosenService' in code('HudConnector.java'))
check('Navigation exposed text marker diagnostics', 'nav_distance_token_seen' in code('NavAccessibilityService.java') and 'nav_direction_token_seen' in ui)
check('MCon device BLE profile table based on actual APK', '0000ffea-0000-1000-8000-00805f9b34fb' in code('MconBleProfiles.java') and 'f7d72c3c02a3' in code('MconBleProfiles.java'))
check('Actual MCon GATT model-aware characteristic selection', 'MconBleProfiles.fromDeviceName' in code('HudConnector.java') and 'MconBleProfiles.fromService' in code('HudConnector.java') and 'hud_services_found' in code('HudConnector.java'))
check('Device identity and discovered GATT services included in user diagnostics', 'hud_device_name' in ui and 'hud_services_found' in ui)
check('CI release gate uses version metadata not byte comparison', 'tools/verify_release_bundle.py' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8') and 'cmp -s' not in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text(encoding='utf-8'))
check('App-managed automatic brightness uses light sensor or clock',
    'Sensor.TYPE_LIGHT' in code('HudAutoBrightness.java')
    and 'clockIsNight()' in code('HudAutoBrightness.java')
    and 'updateForNight' in code('HudAutoBrightness.java')
    and 'autoBrightness.refresh()' in code('BridgeService.java'))
check('Auto brightness replays actual level rather than HUD-only profile',
    'hud_auto_night_active' in code('HudConnector.java')
    and 'HudSettingsProtocol.brightness(level,level)' in code('HudAutoBrightness.java'))
check('OEM drawable NEVER inferred from accessibility view ID',
    'append(out,NavCue.maneuverFromResourceId' not in code('NavAccessibilityService.java')
    and 'oem_direction_access' in code('NavAccessibilityService.java'))
check('OEM NAVIGATION_STATE_CHANGED status is not TBT',
    'OemTmapStateSignal.NAVIGATION_STATE' in code('BridgeService.java')
    and 'OemTmapStateSignal.MAP_ACTIVITY_STATE' in code('BridgeService.java')
    and 'NavCue' not in code('OemTmapStateSignal.java')
    and 'oem_state_observed_count' in ui)
check('OEM status parser strict package and state checks',
    'PACKAGE.equals(reportedPackage)' in code('OemTmapStateSignal.java')
    and 'state==null' in code('OemTmapStateSignal.java'))
check('OEM image and TBT distance view diagnostics preserved',
    'oem_tbt_distance_widgets_last' in code('NavAccessibilityService.java')
    and 'oem_unlabeled_images_last' in ui)
check('BYD DiCar manifest-only probe, never execute query', 'PackageManager.GET_PROVIDERS' in code('OemVehicleIpcProbe.java') and 'getActivityInfo(' in code('OemVehicleIpcProbe.java') and 'contentResolver' not in code('OemVehicleIpcProbe.java') and 'transact(' not in code('OemVehicleIpcProbe.java'))
check('BYD DiCar read-only probe shown in report', 'OemVehicleIpcProbe.inspect(this)' in ui and 'oem_vehicle_provider_probe' in ui and 'oem_cluster_activity_probe' in ui)
check('HUD-RE-012 evidence audit in CI', 'tools/validate_re012_evidence.py' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text() and (root/'research/HUD-RE-012/TECHNICAL_REPORT_KO.md').is_file())
check('OEM state tests wired into JVM suite', 'OemTmapStateSignalTest.java' in (root/'tools/run_jvm_tests.sh').read_text())
check('Auto brightness tests in CI',
    'bash tools/run_auto_brightness_typecheck.sh' in (root/'.github/workflows/build-oem-hud-bridge.yml').read_text())
fail=[n for n,good in checks if not good]
print('DASHBOARD PREFLIGHT SUMMARY', len(checks)-len(fail),'/',len(checks),'PASS')
if fail:sys.exit(1)
