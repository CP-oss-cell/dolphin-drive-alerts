package com.dolphin.oemhud;
import android.content.*;import android.content.pm.*;
public final class VehicleProbeRuntimeTest{
 static int pass=0;
 static void ok(boolean x,String s){if(!x)throw new AssertionError(s);pass++;System.out.println("PASS VEHICLE PROBE "+s);}
 public static void main(String[] args){
  OemBinderRuntimeTest.Ctx ctx=new OemBinderRuntimeTest.Ctx();
  ctx.pm=new PackageManager(){
   public PackageInfo getPackageInfo(String id,int flags){
    PackageInfo i=new PackageInfo();i.providers=new ProviderInfo[2];
    i.providers[0]=new ProviderInfo();i.providers[0].name="com.byd.car.server.provider.CarServiceProvider";i.providers[0].exported=true;
    i.providers[1]=new ProviderInfo();i.providers[1].name="com.gpack.service.provider.VehicleServiceProvider";i.providers[1].exported=true;return i;}
   public ActivityInfo getActivityInfo(ComponentName c,int f){ActivityInfo a=new ActivityInfo();a.exported=true;return a;}
  };
  OemVehicleIpcProbe.inspect(ctx);
  ok(String.valueOf(ctx.prefs.v.get("oem_vehicle_provider_probe")).contains("2/2 providers"),"two known manifests discovered");
  ok(String.valueOf(ctx.prefs.v.get("oem_cluster_activity_probe")).contains("EXPORTED"),"cluster activity metadata found");
  ok(ctx.commands==0,"no OEM Binder commands issued");
  ok(ctx.bindCount==0,"no Binder session opened");
  OemBinderRuntimeTest.Ctx missing=new OemBinderRuntimeTest.Ctx();
  missing.pm=new PackageManager(){
   public PackageInfo getPackageInfo(String p,int f)throws NameNotFoundException{throw new NameNotFoundException();}
   public ActivityInfo getActivityInfo(ComponentName c,int f)throws NameNotFoundException{throw new NameNotFoundException();}
  };
  OemVehicleIpcProbe.inspect(missing);
  ok(String.valueOf(missing.prefs.v.get("oem_vehicle_provider_probe")).contains("NOT_INSTALLED"),"missing package not assumed usable");
  ok(String.valueOf(missing.prefs.v.get("oem_cluster_activity_probe")).contains("NOT_FOUND"),"missing renderer not assumed usable");
  System.out.println("OEM VEHICLE MANIFEST "+pass+" PASS");
 }
}
