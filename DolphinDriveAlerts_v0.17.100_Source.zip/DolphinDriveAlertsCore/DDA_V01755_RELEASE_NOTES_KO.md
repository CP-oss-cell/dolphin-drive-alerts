# Dolphin Drive Alerts v0.17.55 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.54` (`versionCode = 80`) → **신규 버전**: `v0.17.55` (`versionCode = 81`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## v0.17.55 신규 기능: 깜박이 연동 후측방 카메라 (순수 Android Camera2 독자 구현)
- **타사 바이너리 미사용**: 외부 APK의 비공개 `.so`/`.dex`를 복제하지 않고, 순수 Android 표준 `Camera2` + `TextureView` + `SYSTEM_ALERT_WINDOW` + 기존 `TurnSignalReadback`으로 안전하게 독자 구현했습니다.
- **신규 모듈**:
  - `camera/BsdCameraPreferences.kt`: ON/OFF, 좌/우 카메라 ID, 크롭 모드(전체 / 좌·우 절반 / 4분할 사분면 BYD AVM 대응), 오버레이 크기, 깜박이 유지 시간 저장
  - `camera/BsdCameraOverlayController.kt`: 좌/우 방향지시등 감지 시 플로팅 카메라 창 자동 표시, 깜박이 종료 후 자동 닫힘, **후진 기어(R) 진입 시 즉시 카메라 하드웨어 반납·숨김(순정 후진/360 카메라 보호)**
  - `ui/BsdCameraSettingsActivity.kt`: `[화면 · 분할 · DPI]` → `깜박이 후측방 카메라` 진입, 권한 요청, 읽기 전용 Camera2 장치 자동 탐색, 좌/우 5초 실시간 미리보기 지원
- **후진 시 비상등(물리적 차량 라이트 제어) 미포함 사유**:
  - 차량의 물리적 비상등을 강제로 켜고 끄려면 라이트/바디 ECU에 쓰기(setter/CAN) 명령을 전송해야 하며, 이는 프로젝트 필수 안전 규칙(**차량 ECU 및 CAN 명령 전송 금지 / 순정 차량 제어 간섭 금지**)에 위배되므로 포함하지 않았습니다.
  - 대신 후진 기어 진입 시 기존 후진 음성 알림과 순정 후진 카메라 즉시 양보 인터록을 안전하게 유지합니다.

## 검증 결과 및 한계
- `python3 tools/verify_v01755_bsd_camera.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.55_Source.yml`)에서 진행해야 하며, 실차 BYD 펌웨어에서 `Camera2` 장치 노출 여부는 `[깜박이 후측방 카메라]` 화면의 자동 탐색 결과로 확인해야 합니다.
