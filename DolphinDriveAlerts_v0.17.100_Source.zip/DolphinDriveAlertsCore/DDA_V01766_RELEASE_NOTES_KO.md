# Dolphin Drive Alerts v0.17.66 실차 로그 기반 긴급 수정 릴리즈 노트 (2026-11-25)

- **기준 버전**: `v0.17.65` (`versionCode = 91`) → **신규 버전**: `v0.17.66` (`versionCode = 92`)
- **근거 로그**: `DolphinDriveLogs_20261125_191902_746_e7de3c39.zip` (BYD Dolphin 펌웨어 2608 실차 11분 주행 로그)

## 실차 피드백 5대 핵심 수정
1. **주행모드 "에코 → 에코 → 스포츠" 중복 오발화 수정 (`VehicleEventDetector.kt`, `DrivingAlertService.kt`)**
   - `ReferenceVehicleEventBridge`와 `VehicleEventDetector`가 동시에 `energy.operationMode=1`을 중복 발화해 노멀 전환 직전 "에코 모드"가 두 번 나오던 문제를 제거하고, 동일 주행모드 2.5초 중복 차단 가드를 추가했습니다.
2. **화면 회전(APKPure 세로 고정 및 원복 불가) 버그 완전 수정 (`DrivingAlertService.kt`, `MainActivity.kt`)**
   - 세로 전용 앱(APKPure 등)이 실행될 때 발생하는 `onConfigurationChanged(PORTRAIT)`을 차량 회전으로 오인해 전체 UI를 세로로 잠그던 코드를 제거했습니다.
   - 이제 `가로 화면 강제 고정 (세로 앱도 가로로)` ON 시 항상 `LANDSCAPE`를 유지해 세로 앱도 가로로 강제 표시되며, OFF 시 즉시 순정(`STOCK`)으로 원복됩니다.
3. **카메라 자동 감지 (`Camera2` + 레거시 `Camera1` 이중 폴백 + 지원 해상도 자동 선택) & 원터치 자동 보정 (`BsdCameraOverlayController.kt`, `BsdCameraSettingsActivity.kt`, `VehicleCameraHub.kt`)**
   - 고정 `1280×720` 요청으로 영상이 안 나오던 문제를 해결하기 위해 카메라가 실제 지원하는 출력 해상도를 자동 선택하고, `Camera2` 미노출/실패 시 레거시 `Camera1` (`android.hardware.Camera`) 폴백을 지원합니다.
   - `카메라 ID 자동 감지 · 전방/좌/우/후방 자동 배정` 및 `원터치 자동 보정(각도·어안 완화·채도·밝기·화질·선명도)` 버튼을 추가했습니다.
4. **블랙박스 USB/SD카드 자동 감지 & 포맷 전 쓰기 권한 확인 (`VehicleCameraHub.kt`, `DashcamActivity.kt`)**
   - `StorageManager.storageVolumes` + `getExternalFilesDirs()` + `/storage/` 경로를 통합 스캔해 외장 USB/SD카드를 자동 감지하고, 포맷 실행 전 실제 쓰기 권한(`canWrite()`)을 검사하며 필요 시 `ACTION_OPEN_DOCUMENT_TREE`로 USB/SD 권한을 직접 승인받을 수 있습니다.
5. **방향지시등 감지 보강 (`DrivingAlertService.kt`, `IccLeadCarDepartureDetector.kt`)**
   - 2608 펌웨어에 없는 `BYDAutoDiPilotDevice` 호출 오류를 정리하고, 실차 로그에서 확인된 `BYDAutoADASDevice` 중심으로 최적화했습니다.
