# Dolphin Drive Alerts v0.17.59 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.58` (`versionCode = 84`) → **신규 버전**: `v0.17.59` (`versionCode = 85`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## v0.17.59 신규 기능: 단일 Camera2 공유 허브 기반 주행 녹화 (블랙박스)
- **무충돌 · 무추가리소스 단일 카메라 파이프라인 (`camera/VehicleCameraHub.kt`)**:
  - 기존 기능(일반 주행 앞차 출발, 후측방 좌/우 카메라 분석, 깜박이 후측방 카메라)과 카메라 하드웨어 충돌을 원천 차단하기 위해 **단일 `CameraDevice` 공유 허브**로 통합했습니다.
  - 하나의 `CameraCaptureSession`에 **① 하드웨어 H.264 `MediaRecorder` Surface(MP4 순환 녹화)**와 **② `320×240 YUV_420_888 ImageReader`(공유 분석 버스)**를 동시 연결해 추가 카메라 오픈·중복 CPU 점유 없이 동시 작동합니다.
  - 주행 녹화가 켜져 있을 때는 `LeadCarDepartureFusionDetector`와 `BsdSideFusionClassifier`가 별도로 `openCamera()`를 호출하지 않고 `VehicleCameraHub`의 공유 프레임을 그대로 받아 분석합니다.
  - **안전 자동 양보 인터록**: `P`(파킹) 또는 `R`(후진) 기어 진입, 또는 깜박이 후측방 카메라 오버레이가 활성화되는 즉시 현재 MP4 세그먼트를 정상 마감하고 카메라를 양보한 뒤, 조건 해제 시 자동 재개합니다.
- **순환 저장 및 설정 화면 (`camera/DashcamPreferences.kt`, `ui/DashcamActivity.kt`)**:
  - `[화면 · 분할 · DPI]` → `주행 녹화 (블랙박스)`에서 ON/OFF, 카메라 ID, 화질(`720p 4Mbps 저발열 권장` / `1080p 8Mbps`), 분할 길이(`1/3/5분`), 순환 용량 상한(`2/4/8/16GB`, 초과 시 오래된 MP4 자동 삭제) 및 수동 녹화 테스트를 지원합니다.

## 검증 결과 및 한계
- `python3 tools/verify_v01759_dashcam_hub.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.59_Source.yml`)에서 진행해야 합니다.
