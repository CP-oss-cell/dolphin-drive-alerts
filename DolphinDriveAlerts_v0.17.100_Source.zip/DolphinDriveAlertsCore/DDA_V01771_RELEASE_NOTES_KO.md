# Dolphin Drive Alerts v0.17.71 (versionCode 97) 릴리스 노트
- **컨트롤러 텔레그램 실시간 알림 봇 이식 (`TelegramNotifier.kt`, `TelegramSettingsActivity.kt`)**:
  - 외부 라이브러리 추가 없이 표준 `HttpURLConnection` 백그라운드 단일 스레드로 동작해 APK/RAM 증가 0.
  - Bot Token 입력 후 봇에게 메시지 1회 전송 → **Chat ID 자동 찾기(`/getUpdates`)** 및 **연결 테스트** 지원.
  - **센트리 감지 + 4방향 현장 스냅샷 JPEG 사진(`sendPhoto`)** 실시간 전송, 12V/HV 배터리 보호 차단 알림, 블랙박스 G-센서/급제동 잠금 알림 선택 가능.
- **누락 점검 보완 (`SettingsBackupManager.kt`)**:
  - JSON 설정 백업/복원 대상에 하단 플로팅 독바(`dolphin_floating_dock_prefs`), 센트리 모드(`dolphin_sentry_prefs`), 텔레그램 봇(`dolphin_telegram_prefs`) 설정을 모두 포함.
