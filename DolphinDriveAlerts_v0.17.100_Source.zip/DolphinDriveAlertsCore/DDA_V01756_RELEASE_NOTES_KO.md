# Dolphin Drive Alerts v0.17.56 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.55` (`versionCode = 81`) → **신규 버전**: `v0.17.56` (`versionCode = 82`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## v0.17.56 신규 기능: 전방 카메라 · 전방 센서 융합 앞차 출발 감지
- **정차 무장 인터록 (`vehicle/LeadCarDepartureFusionDetector.kt`)**:
  - 오직 `D` 기어(`gearRaw == 2`)에서 차량이 정차(`speedKmH <= 0.8 km/h`) 상태로 1.5초 이상 유지될 때만 자동 무장합니다.
  - 출발하거나 `P/N/R`로 기어를 바꾸는 즉시 무장을 해제하고 전방 카메라 하드웨어를 반납해 발열·순정 후진/360 카메라 충돌을 원천 차단합니다.
- **전방 센서(레이더/초음파) 감지**:
  - `BYDAutoRadarDevice.getAllRadarObstacleDistances()`의 전방 4채널을 감시해 기준 거리(`<= 185cm`) 포착 후 민감도 기준(+18~35cm 증가 또는 감지 소실)으로 0.45초 이상 지속 시 `FRONT_SENSOR` 출발 판정.
- **전방 카메라 YUV ROI 분석 (`camera/FrontCameraDepartureAnalyzer.kt`)**:
  - 순수 Android `Camera2` + `ImageReader(320×240 YUV_420_888)`로 중앙 전방 ROI(또는 BYD 4분할 AVM 좌상단 전방 사분면)의 조도 정규화 8×6 블록 SAD를 초당 ~5프레임으로 경량 분석해 3연속 프레임 임계치 초과 시 `FRONT_CAMERA` 출발 판정.
- **4가지 감지 모드 및 설정 UI (`ui/LeadCarDepartureActivity.kt`)**:
  - `[주행 알림]` → `앞차 출발 감지 (전방 카메라 · 전방 센서)`에서 **융합 / 전방 카메라 전용 / 전방 센서 전용 / 교차 확인** 4종 모드, 민감도 3단계, 전방 카메라 ID, 4분할 AVM 전방 크롭, 카메라 상태 확인 및 `'앞차 출발'` 음성 테스트를 지원합니다.

## 검증 결과 및 한계
- `python3 tools/verify_v01756_lead_departure.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.56_Source.yml`)에서 진행해야 합니다.
