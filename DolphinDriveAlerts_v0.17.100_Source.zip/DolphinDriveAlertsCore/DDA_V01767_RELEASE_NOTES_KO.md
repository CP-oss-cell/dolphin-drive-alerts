# Dolphin Drive Alerts v0.17.67 (versionCode 93) 릴리스 노트

## 1. BYD 전용 AVMCamera + OpenGL ES 3.0 LUT 화질·어안 보정 & Zero-Copy 블랙박스
- **BYD DiLink 3 `bmmcamera.jar` / `AVMCamera` 백엔드 (`BydAvmCameraBackend.kt`)**:
  - 매니페스트에 `bmmcamera`, `com.byd.camera`, `AVMCamera` `<uses-library>` 3종 선언 및 `/system/framework/bmmcamera.jar` 등 동적 로드 지원.
  - 표준 `Camera2`가 미노출되는 BYD 2608 펌웨어에서도 4분할 AVM 스트림을 직접 오픈하고, 미지원 기기에서는 `Camera2` → `Camera1`으로 자동 폴백.
- **OpenGL ES 3.0 사전 계산 LUT 어안 보정·선명도·색보정 (`GlLutDewarpRenderer.kt`)**:
  - `GL_OES_EGL_image_external_essl3` 제로카피 텍스처 + 16비트 정밀 2D UV LUT로 어안 렌즈 왜곡·시야각·각도를 GPU에서 실시간 보정.
  - 단일 프래그먼트 셰이더 패스에서 5-tap 언샤프 마스크 선명도, 밝기, 명암, 채도, 감마를 동시 처리.
- **Zero-Copy `EGL_RECORDABLE_ANDROID` 블랙박스 (`VehicleCameraHub.kt`)**:
  - `BydAvmCameraBackend` + `GlLutDewarpRenderer`를 통해 하드웨어 H.264 `MediaRecorder` Surface로 직결 녹화(후진 기어 진입 시 즉시 순정 360에 양보).

## 2. 순정 UI 상·하단바 숨김 & 고정형 하단 플로팅 독바
- **순정 상단바·하단바 숨김 / 완전 숨김 (`SystemBarController.kt`)**:
  - 순정 표시 / 상단바만 숨김 / 하단바만 숨김 / 상·하단바 완전 숨김(`immersive.full=*`) 지원 (`WRITE_SECURE_SETTINGS` 직접 적용 + 로컬 ADB 폴백).
- **고정형 하단 플로팅 독바 (`FloatingDockController.kt`, `DockBarSettingsActivity.kt`)**:
  - 순정 하단바 위치·크기(기본 58dp, 조절 가능)에 고정, 접기/펴기(접힘 시 반투명 복원 아이콘), 자동접기 ON/OFF 및 대기 시간 설정 지원.
  - 고시인성 Canvas 벡터 아이콘(`DockIcons.kt`): 접기, 홈, 이전, 에어컨 ON/OFF, 온도(+/−), 풍량(+/−), 바람 방향(짧게 탭 순환: 정면→정면+아래→아래→위+아래 / 길게 눌러 직접 선택), 외기↔내기, 핸들 열선, 운전석·동승석 열선, 사이드미러+후방 열선, 순정 설정, 앱서랍.
  - **추가 설치 앱 & 팝업 폴더 + 가로 스와이프**: 독바 오른쪽 스와이프 영역에 설치 앱(실제 앱 아이콘), 커스텀 팝업 폴더(2×2 미니 아이콘 미리보기 → 탭 시 팝업 폴더), 추가 선택 순정 기능(AUTO 공조, 앞유리 성에제거, 환기, 전체 창문 닫기, 썬셰이드, 블랙박스 이벤트 잠금, 화면 분할 실행) 배치 가능.
