# Dolphin Drive Alerts v0.17.69 (versionCode 95) 릴리스 노트
- **단일 공용 `SharedAvmSession`**: 블랙박스·후측방 BVM·앞차 출발·좌/우 BSD 분석이 단 1개의 BYD `AVMCamera` 세션을 공유해 녹화 중 깜박이 진입 시 끊김 0프레임, 후진 기어 시 즉시 순정 360에 양보.
- **정차 전용 4fps TFLite AI 앞차 출발 + 야간 후미등 추적 (`TfliteLeadCarDetector.kt`)**:
  - `arm64-v8a` 단독 ABI + `noCompress("tflite")` 메모리 매핑 + XNNPACK 2스레드.
  - D단 정차 중에만 작동(주행 중 인터프리터 해제·CPU 0%), 주간 `car/bus/truck` 락온으로 보행자·와이퍼 오탐 차단, 야간엔 후미등 2점 간격 추적이 자동 보조.
- **녹화 ON/OFF 자동 연동 후측방 좌/우 융합 (`BsdSideFusionClassifier.kt`)**:
  - 녹화 OFF 시 카메라 콜드오픈 없이 깜박이+센서 0ms 즉시 판별, 녹화 ON 시 공용 AVM 좌/우 사분면 에너지·헤드라이트 비교 동시 융합.
- **권한 승인 및 CI 워크플로우 누락 보강**:
  - `WRITE/READ_EXTERNAL_STORAGE` 및 BYD 세부 `_GET/_SET` 권한을 `PermissionBootstrapper.kt`에 추가 + 앱 내 원터치 권한 승인 팝업 버튼 추가.
  - CI 워크플로우 검증 스크립트명(`verify_v01769_full_suite.py`) 일치 및 공식 TFLite 모델 자동 포함 단계 추가.
