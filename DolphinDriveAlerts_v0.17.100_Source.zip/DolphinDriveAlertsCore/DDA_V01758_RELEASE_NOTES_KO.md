# Dolphin Drive Alerts v0.17.58 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.57` (`versionCode = 83`) → **신규 버전**: `v0.17.58` (`versionCode = 84`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## v0.17.58 신규 기능: 자율주행(ICC/ACC) 전용 앞차 출발 감지 (읽기 전용)
- **신규 모듈 (`vehicle/IccLeadCarDepartureDetector.kt`)**:
  - 일반 주행용 전방 카메라·전방 센서 융합 감지와 별도로, BYD 차량 SDK의 **자율주행(ICC/ACC) 앞차 출발 신호**를 읽기 전용으로 수신합니다.
  - `AbsBYDAutoDiPilotListener.onFrontCarStartStateChange(int)` 콜백 + `getFrontCarStartState()` / `getCruiseCtrlIndicatorState()` 읽기 전용 폴링을 함께 지원합니다.
  - D 기어(`gearRaw == 2`) 정차 상태 및 상승 에지(`0 -> >0`) 조건과 6초 쿨다운으로 오작동을 방지하며, `ICC/ACC 활성 시에만 발화` 옵션(기본 ON)을 제공합니다.
- **UI 통합 (`ui/LeadCarDepartureActivity.kt`)**:
  - `[주행 알림] → 앞차 출발 감지` 화면 상단에 **자율주행(ICC/ACC) 앞차 출발 감지** 전용 패널을 추가해 일반 주행 감지와 독립적으로 ON/OFF 설정할 수 있습니다.

## 후진 시 비상등 ON / 파킹 시 비상등 OFF 미포함 사유
- 차량의 물리적 비상등을 켜고 끄는 동작은 라이트/바디 ECU에 쓰기(setter/CAN) 명령을 전송해야 합니다.
- 프로젝트 필수 안전 규칙(**차량 ECU 및 CAN에 임의 명령 전송 금지**, **순정 안전 기능·차량 제어 간섭 금지**)과 실차 주행 안전상(비상등/라이트 고착 및 순정 방향지시등 충돌 위험) 물리적 비상등 ECU 쓰기 코드는 포함하지 않았습니다.

## 검증 결과 및 한계
- `python3 tools/verify_v01758_icc_lead_departure.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.58_Source.yml`)에서 진행해야 합니다.
