# Dolphin Drive Alerts v0.17.61 릴리즈 노트 (2026-11-25)

- **기준 버전**: `v0.17.60` (`versionCode = 86`) → **신규 버전**: `v0.17.61` (`versionCode = 87`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## 1. 불필요·중복·위험 기능 정리 (사용자 요청 반영)
- **삭제**: `[주행 알림]`의 `BSD 클릭음 보조 감지 · 실험` 토글 제거 (신규 후방 센서·사이드 카메라 좌/우 판별과 중복 정리).
- **삭제**: `[오디오 · 내비]`의 `내비 5종 대상 저장 전용 토글` 제거 (단독 출력 미동작 혼란 제거; `내비 오디오 경로 진단`은 유지).
- **삭제**: `AppPolicyActivity`의 **차량 전체 전역 DPI 강제 적용** UI 제거 (앱 자체 DPI·선택 앱 규칙·기존 전역 DPI 순정 복구만 안전하게 유지).
- **미구현 유지**: 주행 중 설정 자동 잠금 기능은 사용자 요청에 따라 도입하지 않았습니다.

## 2. 안정성·편의성 보완 6대 항목 반영
1. **시동 급단전 시 MP4 손상 방지 + 미완성 파일 자동 정리 (`VehicleCameraHub.kt`, `DrivingAlertService.kt`, `BootReceiver.kt`)**:
   - `ACC_OFF` 감지 시 즉시 `ACTION_POWER_OFF_FLUSH`로 현재 MP4 세그먼트의 `moov atom`을 정상 마감.
   - 시작 시 8KB 미만 손상/빈 MP4 및 고아 사이드카(`.jsonl`/`.srt`/`.gpx`) 자동 정리.
2. **블랙박스 4단계 영상 화질 선택 (`DashcamPreferences.kt`, `VehicleCameraHub.kt`)**:
   - `480p 2Mbps(초저용량)` / `720p 4Mbps(균형 권장)` / `1080p 7Mbps(고화질)` / `1080p 12Mbps(초고화질)` 4단계 선택 지원.
3. **Camera2 3회 연속 실패 서킷 브레이커 + OS 저장소 512MB 안전 방어선 (`VehicleCameraHub.kt`)**:
   - Camera2 HAL 오류 3회 연속 발생 시 무한 재시도·발열을 막기 위해 자동 중지(수동 시작 시 리셋).
   - 차량 여유 저장공간이 512MB 미만이면 긴급 정리 후 그래도 부족할 시 DiLink OS 보호를 위해 자동 중지.
4. **전체 설정 원터치 백업 · 복원 (JSON) (`config/SettingsBackupManager.kt`, `MainActivity.kt`)**:
   - 알림 23종, 10밴드 EQ, 블랙박스, BVM 카메라, 앞차 출발, 후측방, 테마 설정을 `Downloads/DolphinDriveSettings_backup.json`으로 원터치 백업·복원.
5. **BYD 보조 유저(`user 999`) 중복 설치 자가진단 (`MainActivity.kt`)**:
   - 메인 유저(`user 0`)가 아닌 보조 유저에서 실행될 경우 홈 상단에 안내 배너 표시.
6. **시간대 기반 주간/야간 자동 테마 전환 (`DashboardUi.kt`)**:
   - 상단 테마 버튼이 `다크 → 라이트 → 자동(07~19시 라이트 / 야간 다크)` 3단계로 순환 전환.

## 검증 결과 및 한계
- `python3 tools/verify_v01761_polished_release.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.61_Source.yml`)에서 진행해야 합니다.
