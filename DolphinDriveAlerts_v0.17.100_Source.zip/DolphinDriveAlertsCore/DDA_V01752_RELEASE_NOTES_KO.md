# v0.17.52 통합 소스 변경·검증 한계 (2026-11-11)

원본: DolphinDriveAlerts_v0.17.51_DDC-R028_Integrated.zip SHA256 19238b3c666da89dd3f77c01ef391ecf3992a7538324e614f7a936f03bf3d358.
R051_candidate.patch + R052_incremental.patch 실제 적용. 자동실행 서비스 요청별 ACK, 알람 실패시 요청 무효화/호출자 재무장. 버전코드 77→78, 버전명 0.17.51→0.17.52.
R125는 중복 패치라 제외. R087/R100 UnifiedLogCapture 대체 후보는 R028에 직접 적용 실패 및 병합 검증 미완으로 제외. 기존 R028 로그 수집 구현 유지.
중요: Android SDK/Gradle 의존성 없이 APK 컴파일 검증 불가. gradlew 실행은 wrapper JAR 다운로드 DNS 실패로 종료. GitHub Actions CI 및 차량 실검증 미실시. 설치 전 Actions APK 빌드 성공 여부 확인 필요.
ACK는 서비스 전달만 의미하며 실제 지정앱 실행·미디어 재생 성공은 아님. 재생 성공을 주장하지 않음. 차량 ECU/CAN 명령 코드 추가 없음.
