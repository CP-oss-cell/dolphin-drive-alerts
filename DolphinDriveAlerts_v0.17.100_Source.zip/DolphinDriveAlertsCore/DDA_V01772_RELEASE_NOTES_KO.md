# Dolphin Drive Alerts v0.17.72 (versionCode 98) 릴리스 노트
- **시동 OFF(ACC_OFF) 상태 센트리 · 텔레그램 유지 엔진 (`SentryWakeKeeper.kt`)**:
  - 센트리 모드 무장 시 `PARTIAL_WAKE_LOCK` + `WifiManager.WIFI_MODE_FULL_HIGH_PERF` 락을 유지해 시동 OFF 후에도 모션 감지와 텔레그램 사진 전송이 끊기지 않도록 보강.
  - `ACC_OFF` 수신 시 `BYDAutoPowerDevice.wakeUpMcu()` 펄스 및 Doze 회피 `setExactAndAllowWhileIdle` 60초 심박 알람 예약, 12V/HV 배터리 보호 차단 또는 제외 구역 진입 시 즉시 모든 락 해제.
- **권한 승인 보강 (`AndroidManifest.xml`, `PermissionBootstrapper.kt`)**:
  - `ACCESS_WIFI_STATE`, `SCHEDULE_EXACT_ALARM`, `BYDAUTO_POWER_COMMON/GET/SET` 및 `appops WAKE_LOCK / SCHEDULE_EXACT_ALARM allow` 추가.
