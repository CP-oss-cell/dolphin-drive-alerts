# Dolphin Drive Alerts v0.17.68 (versionCode 94) 릴리스 노트
- **분할화면 Anchor-First + 자동 복구(Verify & Heal) 안정화 (`AutoSplitBehaviorEngine.kt`)**:
  - `SplitGhostActivity`로 `windowingMode 3` Primary 스택을 먼저 확보한 뒤 두 앱을 배치.
  - 콜드 스타트 대기 시간을 최대 2.8초(280ms 폴링)로 늘리고, 풀스크린으로 열린 태스크는 `am stack move-task`로 강제 편입.
  - 실행 1초 뒤 한쪽 앱이 탈락("외로운 분할")했는지 검증하고 자동 재부착.
- **시동 앱 자동 실행 폴백 + 부팅 후 런처 덮어쓰기 방어 (`AutoLaunchSequenceService.kt`)**:
  - 시동 직후 로컬 ADB(`:5555`)가 아직 준비되지 않았어도 일반 앱은 안드로이드 런처 Intent로 즉시 실행.
  - 요청 ID 거절 대신 15초 중복 방지 창(`DUP_WINDOW_MS`) 적용.
  - 시퀀스 완료 3초 뒤 BYD 순정 런처가 화면을 덮어씌웠다면 최종 대상 앱·분할 프로필을 자동 재복구(`verifyAndHealFinalForeground`).
