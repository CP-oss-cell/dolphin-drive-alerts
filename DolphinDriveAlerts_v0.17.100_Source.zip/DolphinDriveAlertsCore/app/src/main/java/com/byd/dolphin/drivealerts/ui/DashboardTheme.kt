package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Conservative one-shot theme helper aligned with DashboardUi Dark/Light cockpit palettes. */
object DashboardTheme {
    private fun dp(activity: Activity, n: Int) = (n * activity.resources.displayMetrics.density).toInt()

    fun decorate(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        DashboardUi.applyWindowChrome(activity)
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        visit(activity, content, 0)
    }

    private fun visit(activity: Activity, v: View, depth: Int) {
        when (v) {
            is Spinner -> return
            is EditText -> {
                v.setTextColor(DashboardUi.textColor(activity))
                v.setHintTextColor(DashboardUi.mutedColor(activity))
            }
            is Button -> {
                v.isAllCaps = false
                v.setTextColor(DashboardUi.textColor(activity))
                v.background = DashboardUi.interactiveBg(activity, DashboardUi.surfaceAltColor(activity))
                v.minHeight = dp(activity, 46)
            }
            is CheckBox -> v.setTextColor(DashboardUi.textColor(activity))
            is RadioButton -> v.setTextColor(DashboardUi.textColor(activity))
            is TextView -> v.setTextColor(
                if (v.textSize / activity.resources.displayMetrics.scaledDensity >= 18f)
                    DashboardUi.accentColor(activity)
                else DashboardUi.mutedColor(activity)
            )
            is ScrollView -> v.setBackgroundColor(DashboardUi.bgColor(activity))
            is LinearLayout -> if (depth <= 2) v.setBackgroundColor(DashboardUi.bgColor(activity))
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) visit(activity, v.getChildAt(i), depth + 1)
    }
}
