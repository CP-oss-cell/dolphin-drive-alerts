package com.byd.dolphin.drivealerts.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.sentry.SentryPreferences
import com.byd.dolphin.drivealerts.sentry.SentryWarningActivity

/**
 * Sentry Mode (Parking Guard) configuration UI:
 * ON/OFF, motion sensitivity, IMU impact detection, Tesla-style warning screen + preview,
 * boarding event count announcement, 12V/HV battery protection cutoffs, max duration, and GPS Safe Zones.
 */
class SentrySettingsActivity : DensityAwareActivity() {
    private lateinit var screen: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = DashboardUi.dp(this@SentrySettingsActivity, v)

    private fun render() {
        val accent = DashboardUi.dangerColor(this)
        screen = DashboardUi.page(
            this,
            "센트리 모드 (주차 감시)",
            "P단 주차 시 4방향 모션·충격 감시 · 경고 화면 · 12V/HV 배터리 보호 · 제외 구역",
            DashboardIcons.IconKind.RECORD_DOT,
            accent
        ) { render() }

        // 1. 기본 동작 설정
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "센트리 감시 동작",
            "주차(P) 8초 후 공용 AVM 4분할(2fps 초저부하)과 IMU 충격 센서로 주변을 감시합니다.",
            DashboardIcons.IconKind.RECORD_DOT,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "센트리 모드 켜기 (주차 시 자동 무장)", SentryPreferences.enabled(this)) {
                SentryPreferences.setEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "IMU 충격(문콕·접촉) 감지 사용", SentryPreferences.impactEnabled(this)) {
                SentryPreferences.setImpactEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "감지 시 테슬라 스타일 경고 화면 표시", SentryPreferences.warningScreenEnabled(this)) {
                SentryPreferences.setWarningScreenEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "탑승 시 '주차 중 센트리 녹화 N건' 음성 안내", SentryPreferences.boardingVoiceEnabled(this)) {
                SentryPreferences.setBoardingVoiceEnabled(this, it)
            })
            p.addView(DashboardUi.toggle(this, "시동 OFF(ACC_OFF) 시 절전 깨우기 유지 (WakeLock · Wi-Fi · MCU Wake)", SentryPreferences.keepAwakeOnOff(this)) {
                SentryPreferences.setKeepAwakeOnOff(this, it)
            })

            val sensSp = Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@SentrySettingsActivity, SentryPreferences.sensitivityLabels)
                setSelection(SentryPreferences.sensitivity(this@SentrySettingsActivity))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        SentryPreferences.setSensitivity(this@SentrySettingsActivity, pos)
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            p.addView(sensSp, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(
                DashboardUi.action(this, "경고 화면 미리보기", DashboardIcons.IconKind.PLAY, accent) {
                    SentryWarningActivity.launch(this, "미리보기 테스트", 6_000L)
                },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, dp(2), dp(4), dp(2)) }
            )
            row.addView(
                DashboardUi.action(this, "녹화 영상 뷰어 열기", DashboardIcons.IconKind.RECORD_DOT, DashboardUi.accentColor(this)) {
                    runCatching { startActivity(Intent(this, DashcamViewerActivity::class.java)) }
                },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(4), dp(2), 0, dp(2)) }
            )
            p.addView(row)
        })

        // 2. 12V / HV 배터리 보호 및 최대 감시 시간
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "12V · 고전압 배터리 보호 차단",
            "배터리 방전을 막기 위해 기준 이하로 떨어지거나 최대 시간이 지나면 센트리를 자동 종료합니다.",
            DashboardIcons.IconKind.SHIELD_ADB,
            DashboardUi.okColor(this)
        ) { p ->
            val vOpts = listOf(118, 120, 122)
            val vLabels = vOpts.map { "12V 저전압 차단 기준: ${it / 10}.${it % 10}V 미만" }
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@SentrySettingsActivity, vLabels)
                setSelection(vOpts.indexOf(SentryPreferences.min12vDeciVolts(this@SentrySettingsActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        SentryPreferences.setMin12vDeciVolts(this@SentrySettingsActivity, vOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })

            val hvOpts = listOf(15, 20, 30)
            val hvLabels = hvOpts.map { "고전압(HV) 배터리 보호 하한: ${it}% 미만" }
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@SentrySettingsActivity, hvLabels)
                setSelection(hvOpts.indexOf(SentryPreferences.minHvPercent(this@SentrySettingsActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        SentryPreferences.setMinHvPercent(this@SentrySettingsActivity, hvOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(6)) })

            val hOpts = listOf(2, 4, 8, 12, 24)
            val hLabels = hOpts.map { "최대 주차 감시 유지 시간: ${it}시간" }
            p.addView(Spinner(this).apply {
                adapter = DarkSpinnerAdapter.labels(this@SentrySettingsActivity, hLabels)
                setSelection(hOpts.indexOf(SentryPreferences.maxHours(this@SentrySettingsActivity)).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                        SentryPreferences.setMaxHours(this@SentrySettingsActivity, hOpts[pos])
                    }
                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }, LinearLayout.LayoutParams(-1, -2))
        })

        // 3. GPS 제외 구역 (집 / 직장)
        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "센트리 제외 구역 (집 · 직장 GPS)",
            "등록한 위치 반경 150m 이내에서는 주차해도 센트리가 자동으로 꺼져 배터리를 아낍니다.",
            DashboardIcons.IconKind.NAV_ARROW,
            DashboardUi.accentColor(this)
        ) { p ->
            val zones = SentryPreferences.safeZones(this)
            p.addView(DashboardUi.label(this, "등록된 제외 구역: ${zones.size}곳 (미확인 이벤트 ${SentryPreferences.unseenEventCount(this)}건)", 13f, true))
            for (z in zones) {
                p.addView(DashboardUi.actionRow(
                    this,
                    "${z.name} (반경 ${z.radiusM}m)",
                    "위도 ${"%.4f".format(z.lat)}, 경도 ${"%.4f".format(z.lon)} · 탭하여 삭제",
                    DashboardIcons.IconKind.STOP,
                    accent,
                    "삭제"
                ) {
                    SentryPreferences.removeSafeZone(this, z.id)
                    render()
                })
            }
            p.addView(DashboardUi.action(this, "+ 현재 GPS 위치를 제외 구역으로 등록", DashboardIcons.IconKind.PLAY, DashboardUi.okColor(this)) {
                addCurrentLocationSafeZone()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(6) })
        })
    }

    private fun addCurrentLocationSafeZone() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "위치 권한이 필요합니다. [권한 · ADB]에서 먼저 승인해 주세요.", Toast.LENGTH_LONG).show()
            return
        }
        val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val loc = runCatching {
            lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }.getOrNull()
        if (loc == null) {
            Toast.makeText(this, "현재 GPS 좌표를 아직 수신하지 못했습니다. 잠시 후 다시 시도하세요.", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply { hint = "예: 우리집, 회사 주차장" }
        AlertDialog.Builder(this)
            .setTitle("제외 구역 이름 입력")
            .setView(input)
            .setPositiveButton("등록") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "제외 구역" }
                SentryPreferences.addSafeZone(
                    this,
                    SentryPreferences.SafeZone("z_${System.currentTimeMillis()}", name, loc.latitude, loc.longitude, 150)
                )
                render()
            }
            .setNegativeButton("취소", null)
            .show()
    }
}
