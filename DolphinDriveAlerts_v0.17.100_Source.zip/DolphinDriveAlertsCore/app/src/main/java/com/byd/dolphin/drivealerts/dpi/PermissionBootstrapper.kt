package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import android.os.Build
import com.byd.dolphin.drivealerts.automation.MediaPlaybackObserver
import com.byd.dolphin.drivealerts.util.CoreLog

/** Explicit, user-invoked authorized ADB bootstrap for restricted BYD Settings UI.
 * ADB is not root: signature/OEM grants can still be rejected by the device.
 */
object PermissionBootstrapper {
    data class Result(val success: Boolean, val lines: List<String>)
    private data class Check(val ok: Boolean, val details: String)

    fun apply(context: Context): Result = perform(context, configure = true)
    fun audit(context: Context): Result = perform(context, configure = false)

    private fun perform(context: Context, configure: Boolean): Result {
        val app = context.applicationContext
        val pkg = app.packageName
        val lines = mutableListOf<String>()
        val adb = AuthorizedAdbRuntime.awaitReady(app, maxWaitMs = if (configure) 30_000L else 6_000L)
        val auth = adb.result
        lines += "로컬 ADB: ${if (auth.success) "연결됨" else "실패"} / ${adb.state} / ${auth.message}"
        if (!auth.success) {
            lines += "ADB RSA 승인 및 127.0.0.1:5555 접근 불가. 이 앱이 단독으로 ADB 서버를 열거나 권한을 우회할 수 없습니다."
            lines += "차량에서 승인된 외부 ADB 연결이 가능하면 동봉된 PC 설정 스크립트를 실행하세요."
            return Result(false, lines)
        }
        val a11y = ComponentName(app, ForegroundPolicyAccessibilityService::class.java).flattenToString()
        val notification = ComponentName(app, MediaPlaybackObserver::class.java).flattenToString()
        fun shell(command: String) = NativeAdbClient.executeShell(app, command, timeoutMs = 7_000L)
        fun change(label: String, command: String) {
            if (!configure) return
            val result = shell(command)
            lines += "$label 적용: ${if (result.success) "명령 OK" else "명령 거부"} ${result.output.trim().ifEmpty { result.message }.take(140)}"
        }
        fun read(label: String, command: String, test: (String)->Boolean): Check {
            val result = shell(command)
            val ok = result.success && test(result.output)
            val msg = if (!result.success) result.message else result.output.trim().replace('\n',' ').take(160)
            lines += "$label 검증: ${if (ok) "확인" else "미확인/거부"} [$msg]"
            return Check(ok, msg)
        }
        // WRITE_SECURE_SETTINGS must be declared. An authorized ADB shell might grant it;
        // whether the user settings change is accepted still requires readback.
        change("WRITE_SECURE_SETTINGS", "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS")
        val secure = read("secure 설정 권한", "dumpsys package $pkg | grep -F 'android.permission.WRITE_SECURE_SETTINGS:'") {
            it.contains("granted=true")
        }
        // Grant overlay (BVM blind-spot camera & screen orientation sync) + camera + GPS location via authorized ADB
        change("화면 위 표시(오버레이)", "appops set $pkg SYSTEM_ALERT_WINDOW allow")
        val overlay = read("화면 위 표시 권한", "appops get $pkg SYSTEM_ALERT_WINDOW") {
            Regex("(?i)\\b(SYSTEM_ALERT_WINDOW|android:system_alert_window):\\s*allow").containsMatchIn(it)
        }
        change("카메라(블랙박스·BVM·앞차출발)", "pm grant $pkg android.permission.CAMERA")
        change("BYD 360 카메라(BYD_CAMERA)", "pm grant $pkg android.permission.BYD_CAMERA")
        change("시스템 설정 쓰기(WRITE_SETTINGS)", "appops set $pkg WRITE_SETTINGS allow")
        val camPerm = read("카메라 권한", "dumpsys package $pkg | grep -F 'android.permission.CAMERA:'") {
            it.contains("granted=true")
        }
        change("정밀 위치(GPS 주행궤적)", "pm grant $pkg android.permission.ACCESS_FINE_LOCATION")
        change("대략 위치(GPS 보조)", "pm grant $pkg android.permission.ACCESS_COARSE_LOCATION")
        change("외부 저장소 읽기(블랙박스 USB/SD)", "pm grant $pkg android.permission.READ_EXTERNAL_STORAGE")
        change("외부 저장소 쓰기(블랙박스 USB/SD)", "pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE")
        change("백그라운드 위치(센트리 제외구역)", "pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION")
        change("오디오 녹음(내비 라우트)", "pm grant $pkg android.permission.RECORD_AUDIO")
        val locPerm = read("위치(GPS) 권한", "dumpsys package $pkg | grep -F 'android.permission.ACCESS_FINE_LOCATION:'") {
            it.contains("granted=true")
        }
        change("사용기록", "appops set $pkg GET_USAGE_STATS allow")
        val usage = read("사용기록 권한", "appops get $pkg GET_USAGE_STATS") {
            Regex("(?i)\\b(GET_USAGE_STATS|android:get_usage_stats):\\s*allow").containsMatchIn(it)
        }
        change("백그라운드 실행", "appops set $pkg RUN_IN_BACKGROUND allow")
        change("백그라운드 제한 완화", "appops set $pkg RUN_ANY_IN_BACKGROUND allow")
        change("시동 OFF 절전 깨우기(WAKE_LOCK)", "appops set $pkg WAKE_LOCK allow")
        change("정확한 알람(주차 센트리 심박)", "appops set $pkg SCHEDULE_EXACT_ALARM allow")
        change("배터리 예외", "dumpsys deviceidle whitelist +$pkg")
        val battery = read("배터리 최적화 예외", "dumpsys deviceidle whitelist") { it.contains(pkg) }

        // The authenticated ADB shell may write secure settings even when this app cannot
        // itself receive WRITE_SECURE_SETTINGS. Treat pm grant as optional, not a blocker.
        if (configure) {
            val existing = shell("settings get secure enabled_accessibility_services")
            if (existing.success) {
                val merged = existing.output.trim().takeUnless { it.isEmpty() || it == "null" }.orEmpty()
                    .split(':').filter { it.isNotBlank() }.toMutableList().apply { if (a11y !in this) add(a11y) }
                    .distinct().joinToString(":")
                change("접근성 목록", "settings put secure enabled_accessibility_services '${quote(merged)}'")
                change("접근성 활성화", "settings put secure accessibility_enabled 1")
            } else lines += "기존 접근성 목록 조회 실패: 타 서비스 보호를 위해 변경 생략"
        }
        val enabledList = read("접근성 서비스", "settings get secure enabled_accessibility_services") {
            it.split(':').map(String::trim).contains(a11y)
        }
        val a11yEnabled = read("접근성 전체 활성화", "settings get secure accessibility_enabled") { it.trim() == "1" }

        // Authorized shell command available on Android framework. It is not POST_NOTIFICATIONS.
        if (configure) {
            val changeListener = shell("cmd notification allow_listener $notification")
            lines += "미디어 알림 리스너 적용: ${if(changeListener.success) "명령 OK" else "명령 거부/미지원"} ${changeListener.message.take(140)}"
            if (!changeListener.success) {
                val previous = shell("settings get secure enabled_notification_listeners")
                if (previous.success) {
                    val merged = previous.output.trim().takeUnless { it.isBlank() || it == "null" }.orEmpty()
                        .split(':').filter { it.isNotBlank() }.toMutableList().apply {
                            if (notification !in this) add(notification)
                        }.distinct().joinToString(":")
                    change("미디어 알림 리스너 목록 보존 병합", "settings put secure enabled_notification_listeners '${quote(merged)}'")
                } else lines += "기존 알림 리스너 목록 읽기 실패: 다른 리스너를 지우지 않기 위해 변경 생략"
            }
        }
        val listener = read("미디어 알림 리스너", "settings get secure enabled_notification_listeners") {
            it.split(':').map(String::trim).contains(notification)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            change("알림 게시", "pm grant $pkg android.permission.POST_NOTIFICATIONS")
        }
        val posting = if (Build.VERSION.SDK_INT >= 33) read("알림 게시 권한", "dumpsys package $pkg | grep -F 'android.permission.POST_NOTIFICATIONS:'") {
            it.contains("granted=true")
        } else Check(true,"API < 33")

        // BYD OEM permissions are not runtime permissions on all ROMs. Do not claim success.
        val byo = listOf("SETTING","AC","BODYWORK","DOOR_LOCK","LIGHT","PANORAMA","RADAR","INSTRUMENT")
        if (configure) {
            for (domain in byo) change("BYD $domain", "pm grant $pkg android.permission.BYDAUTO_${domain}_COMMON")
            for (extra in listOf("BYDAUTO_AC_GET", "BYDAUTO_AC_SET", "BYDAUTO_BODYWORK_GET", "BYDAUTO_BODYWORK_SET", "BYDAUTO_PANORAMA_GET", "BYDAUTO_PANORAMA_SET", "BYDAUTO_SETTING_GET", "BYDAUTO_SETTING_SET", "BYDAUTO_LIGHT_GET", "BYDAUTO_LIGHT_SET", "BYDAUTO_RADAR_GET", "BYDAUTO_INSTRUMENT_GET", "BYDAUTO_DOOR_LOCK_GET", "BYDAUTO_POWER_COMMON", "BYDAUTO_POWER_GET", "BYDAUTO_POWER_SET", "BYDAUTO_STATISTIC_COMMON", "BYDAUTO_STATISTIC_GET", "BYDAUTO_GEARBOX_COMMON", "BYDAUTO_GEARBOX_GET", "BYDAUTO_SPEED_COMMON", "BYDAUTO_SPEED_GET", "BYDAUTO_ADAS_COMMON", "BYDAUTO_ADAS_GET", "BYDAUTO_ENERGY_COMMON", "BYDAUTO_ENERGY_GET")) {
                change("BYD $extra", "pm grant $pkg android.permission.$extra")
            }
        }
        lines += "BYD 차량 제어 권한은 제조사 서명/privileged 제한일 수 있으므로 ADB에서도 실패할 수 있음"
        val ok = usage.ok && enabledList.ok && a11yEnabled.ok && listener.ok && posting.ok
        lines += "권한 종합: ${if(ok) "일반 자동화 권한 readback 확인" else "권한 누락 / 기능 일부 동작 불가"} (overlay=${overlay.ok}, cam=${camPerm.ok}, gps=${locPerm.ok}, battery=${battery.ok}, secure=${secure.ok})"
        CoreLog.i("PERMISSION_BOOTSTRAP", lines.joinToString(" | ").take(3000))
        return Result(ok, lines)
    }
    private fun quote(v: String): String = v.replace("'", "'\\''")
}
