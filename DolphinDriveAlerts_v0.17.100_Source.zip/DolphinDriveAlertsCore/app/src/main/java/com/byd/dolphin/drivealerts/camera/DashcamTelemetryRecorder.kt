package com.byd.dolphin.drivealerts.camera

import android.content.Context
import android.location.Location
import android.location.LocationManager
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ultra-lightweight 1 Hz driving telemetry sidecar recorder.
 * Saves synchronized .jsonl (speed/gear/brake/blinker/GPS), .srt (video subtitles),
 * and .gpx (GPS track) alongside every recorded MP4 segment with near-zero CPU cost.
 */
class DashcamTelemetryRecorder(context: Context) {
    private val app = context.applicationContext
    private var basePath: File? = null
    private var segmentStartMs: Long = 0L
    private var lastSampleMs: Long = 0L
    private var srtIndex: Int = 0
    private val jsonlLines = StringBuilder()
    private val srtLines = StringBuilder()
    private val gpxPoints = StringBuilder()

    @Synchronized
    fun beginSegment(mp4File: File) {
        flushAndClose()
        if (!DashcamPreferences.telemetryEnabled(app)) return
        basePath = File(mp4File.parentFile, mp4File.nameWithoutExtension)
        segmentStartMs = System.currentTimeMillis()
        lastSampleMs = 0L
        srtIndex = 0
        jsonlLines.setLength(0)
        srtLines.setLength(0)
        gpxPoints.setLength(0)
    }

    @Synchronized
    fun recordSample(frame: RawVehicleFrame, blinker: Side) {
        if (basePath == null) return
        val now = System.currentTimeMillis()
        if (now - lastSampleMs < 950L) return // 1 Hz ultra-low overhead
        lastSampleMs = now

        val elapsedMs = (now - segmentStartMs).coerceAtLeast(0L)
        val gearStr = when (frame.gearRaw) { 0 -> "N"; 1 -> "R"; 2 -> "D"; 3 -> "P"; else -> "?" }
        val speed = frame.speedKmH?.let { "%.1f".format(Locale.US, it) } ?: "0.0"
        val brake = if ((frame.brakePedalRaw ?: 0) > 0) 1 else 0
        val loc = readLastLocation()
        val lat = loc?.latitude
        val lon = loc?.longitude
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date(now))

        jsonlLines.append("{\"t\":$elapsedMs,\"gear\":\"$gearStr\",\"spd\":$speed,\"brk\":$brake,\"turn\":\"${blinker.name}\"")
        if (lat != null && lon != null) {
            jsonlLines.append(",\"lat\":${"%.6f".format(Locale.US, lat)},\"lon\":${"%.6f".format(Locale.US, lon)}")
            gpxPoints.append("      <trkpt lat=\"${"%.6f".format(Locale.US, lat)}\" lon=\"${"%.6f".format(Locale.US, lon)}\"><time>$iso</time></trkpt>\n")
        }
        jsonlLines.append("}\n")

        srtIndex++
        val startSrt = formatSrtTime(elapsedMs)
        val endSrt = formatSrtTime(elapsedMs + 950L)
        val gpsText = if (lat != null && lon != null) "GPS ${"%.5f".format(Locale.US, lat)},${"%.5f".format(Locale.US, lon)}" else "GPS 대기"
        val brkText = if (brake == 1) "BRK:ON" else "BRK:OFF"
        srtLines.append("$srtIndex\n$startSrt --> $endSrt\n$gearStr | ${speed}km/h | $brkText | ${blinker.name} | $gpsText\n\n")
    }

    @Synchronized
    fun flushAndClose() {
        val base = basePath ?: return
        basePath = null
        if (jsonlLines.isNotEmpty()) {
            runCatching { File("${base.absolutePath}.jsonl").writeText(jsonlLines.toString(), Charsets.UTF_8) }
        }
        if (srtLines.isNotEmpty()) {
            runCatching { File("${base.absolutePath}.srt").writeText(srtLines.toString(), Charsets.UTF_8) }
        }
        if (gpxPoints.isNotEmpty()) {
            val gpx = buildString {
                appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
                appendLine("<gpx version=\"1.1\" creator=\"DolphinDriveAlerts\">")
                appendLine("  <trk><name>${base.name}</name><trkseg>")
                append(gpxPoints.toString())
                appendLine("  </trkseg></trk>")
                appendLine("</gpx>")
            }
            runCatching { File("${base.absolutePath}.gpx").writeText(gpx, Charsets.UTF_8) }
        }
        jsonlLines.setLength(0)
        srtLines.setLength(0)
        gpxPoints.setLength(0)
    }

    private fun readLastLocation(): Location? = runCatching {
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val gps = runCatching { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) }.getOrNull()
        val net = runCatching { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
        when {
            gps != null && net != null -> if (gps.time >= net.time) gps else net
            else -> gps ?: net
        }
    }.getOrNull()

    private fun formatSrtTime(ms: Long): String {
        val h = ms / 3_600_000L
        val m = (ms % 3_600_000L) / 60_000L
        val s = (ms % 60_000L) / 1_000L
        val rem = ms % 1_000L
        return "%02d:%02d:%02d,%03d".format(Locale.US, h, m, s, rem)
    }
}
