package com.byd.dolphin.drivealerts.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/** Premium automotive cockpit dropdown styling (52dp touch height, crisp pill & divider feel). */
object DarkSpinnerAdapter {
    fun labels(context: Context, data: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, data) {
            private fun style(v: View, dropdown: Boolean): View {
                if (v is TextView) {
                    val d = context.resources.displayMetrics.density
                    val padH = (16 * d).toInt()
                    val padV = (13 * d).toInt()
                    v.setTextColor(DashboardUi.textColor(context))
                    v.textSize = if (dropdown) 15f else 14.5f
                    v.setTypeface(v.typeface, if (dropdown) Typeface.NORMAL else Typeface.BOLD)
                    v.gravity = Gravity.CENTER_VERTICAL
                    v.setPadding(padH, padV, padH, padV)
                    v.minimumHeight = (52 * d).toInt()
                    v.background = if (dropdown) {
                        DashboardUi.cardBg(context, DashboardUi.surfaceColor(context), DashboardUi.borderColor(context), 0)
                    } else {
                        DashboardUi.cardBg(context, DashboardUi.surfaceAltColor(context), DashboardUi.borderColor(context), 12)
                    }
                }
                return v
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent), true)
        }
}
