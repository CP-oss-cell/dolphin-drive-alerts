package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.config.AlertVolume
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertEventCatalog
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.AlertStyle

/** 23 live audio preference toggles grouped by function with per-alert voice/volume overrides and preview. */
class AlertEventSettingsActivity : DensityAwareActivity() {
    private var previewPlayer: AlertAudioPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        previewPlayer = AlertAudioPlayer(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@AlertEventSettingsActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                DashboardUi.dp(this@AlertEventSettingsActivity, 18),
                DashboardUi.dp(this@AlertEventSettingsActivity, 14),
                DashboardUi.dp(this@AlertEventSettingsActivity, 18),
                DashboardUi.dp(this@AlertEventSettingsActivity, 24)
            )
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "주행 알림 23종", "개별 ON/OFF · 개별 음성/볼륨 · 미리듣기")

        val introPanel = DashboardUi.panel(
            this,
            "알림별 개별 설정 및 테스트",
            "각 알림의 ON/OFF, 개별 음성·볼륨 지정(칩 탭), 원터치 미리듣기(▶)를 지원합니다.",
            DashboardIcons.IconKind.SPEAKER,
            DashboardUi.accentColor(this)
        ) { p ->
            p.addView(DashboardUi.label(
                this,
                "개별 설정을 '공통'으로 두면 메인 주행 알림의 기본 음성·볼륨을 따릅니다. 꺼도 BYD 순정 경고와 신호 기록은 유지됩니다.",
                12.5f
            ))
        }
        introPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, introPanel)

        val groups = AlertEventCatalog.entries.groupBy { it.group }
        for ((group, entries) in groups) {
            val activeCount = entries.count { AlertPreferences.eventEnabled(this, it.event) }
            val groupIcon = when {
                group.contains("기어") || group.contains("주행") -> DashboardIcons.IconKind.GAUGE
                group.contains("브레이크") || group.contains("홀드") || group.contains("회생") -> DashboardIcons.IconKind.CAR_ALERT
                group.contains("후측방") || group.contains("BSD") || group.contains("차선") || group.contains("자율") || group.contains("ADAS") -> DashboardIcons.IconKind.RADAR_BSD
                else -> DashboardIcons.IconKind.CHECKLIST
            }
            val groupPanel = DashboardUi.panel(
                this,
                "$group  ($activeCount/${entries.size})",
                "",
                groupIcon,
                DashboardUi.accentColor(this)
            ) { card ->
                for (entry in entries) {
                    val row = LinearLayout(this@AlertEventSettingsActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        background = DashboardUi.cardBg(
                            this@AlertEventSettingsActivity,
                            DashboardUi.surfaceAltColor(this@AlertEventSettingsActivity),
                            DashboardUi.borderColor(this@AlertEventSettingsActivity),
                            11
                        )
                        setPadding(
                            DashboardUi.dp(this@AlertEventSettingsActivity, 10),
                            DashboardUi.dp(this@AlertEventSettingsActivity, 6),
                            DashboardUi.dp(this@AlertEventSettingsActivity, 10),
                            DashboardUi.dp(this@AlertEventSettingsActivity, 6)
                        )
                    }
                    val cb = CheckBox(this@AlertEventSettingsActivity).apply {
                        text = "${entry.event.phrase}\n${AlertEventCatalog.evidenceKorean(entry.evidence)}"
                        textSize = 13.5f
                        setTextColor(DashboardUi.textColor(this@AlertEventSettingsActivity))
                        isChecked = AlertPreferences.eventEnabled(this@AlertEventSettingsActivity, entry.event)
                        setOnCheckedChangeListener { button, enabled ->
                            if (!AlertPreferences.setEventEnabled(this@AlertEventSettingsActivity, entry.event, enabled)) {
                                button.setOnCheckedChangeListener(null)
                                button.isChecked = !enabled
                                Toast.makeText(this@AlertEventSettingsActivity, "설정 저장 실패. 화면을 다시 열어주세요.", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                    row.addView(cb, LinearLayout.LayoutParams(0, -2, 1f))

                    val overrideChip = DashboardUi.pill(
                        this@AlertEventSettingsActivity,
                        overrideSummary(entry.event),
                        if (hasOverride(entry.event)) DashboardUi.okColor(this@AlertEventSettingsActivity)
                        else DashboardUi.mutedColor(this@AlertEventSettingsActivity)
                    ).apply {
                        isClickable = true
                        isFocusable = true
                        minHeight = DashboardUi.dp(this@AlertEventSettingsActivity, 38)
                        setOnClickListener { openOverrideDialog(entry.event, this) }
                    }
                    row.addView(
                        overrideChip,
                        LinearLayout.LayoutParams(-2, -2).apply {
                            setMargins(DashboardUi.dp(this@AlertEventSettingsActivity, 6), 0, 0, 0)
                        }
                    )

                    val playBtn = FrameLayout(this@AlertEventSettingsActivity).apply {
                        isClickable = true
                        isFocusable = true
                        contentDescription = "${entry.event.phrase} 음성 테스트"
                        background = DashboardUi.interactiveBg(
                            this@AlertEventSettingsActivity,
                            DashboardUi.alphaColor(DashboardUi.accentColor(this@AlertEventSettingsActivity), 34),
                            DashboardUi.alphaColor(DashboardUi.accentColor(this@AlertEventSettingsActivity), 95),
                            10
                        )
                        addView(ImageView(this@AlertEventSettingsActivity).apply {
                            setImageDrawable(
                                DashboardIcons.drawable(
                                    this@AlertEventSettingsActivity,
                                    DashboardIcons.IconKind.PLAY,
                                    DashboardUi.accentColor(this@AlertEventSettingsActivity),
                                    18,
                                    2.0f
                                )
                            )
                        }, FrameLayout.LayoutParams(
                            DashboardUi.dp(this@AlertEventSettingsActivity, 18),
                            DashboardUi.dp(this@AlertEventSettingsActivity, 18),
                            Gravity.CENTER
                        ))
                        setOnClickListener {
                            runCatching { previewPlayer?.play(AlertRequest(entry.event)) }
                                .onFailure { Toast.makeText(this@AlertEventSettingsActivity, "음성 테스트 실패: ${it.message}", Toast.LENGTH_SHORT).show() }
                        }
                    }
                    row.addView(
                        playBtn,
                        LinearLayout.LayoutParams(
                            DashboardUi.dp(this@AlertEventSettingsActivity, 44),
                            DashboardUi.dp(this@AlertEventSettingsActivity, 44)
                        ).apply { setMargins(DashboardUi.dp(this@AlertEventSettingsActivity, 8), 0, 0, 0) }
                    )
                    card.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                        setMargins(0, DashboardUi.dp(this@AlertEventSettingsActivity, 4), 0, DashboardUi.dp(this@AlertEventSettingsActivity, 4))
                    })
                }
            }
            groupPanel.tag = "DOLPHIN_DASH_PANEL"
            DashboardUi.addPanel(root, this, groupPanel)
        }

        val resetPanel = DashboardUi.panel(
            this,
            "설정 복원",
            "표시 근거는 과거 실차 보고와 소스/로그 분석 기준이며, 당일 차량 연결 상태의 실시간 판정이 아닙니다.",
            DashboardIcons.IconKind.RESCUE,
            DashboardUi.warnColor(this)
        ) { card ->
            card.addView(DashboardUi.action(
                this,
                "23종 알림 설정 초기값으로 복원 (모두 ON · 공통 음성/볼륨)",
                DashboardIcons.IconKind.RESCUE,
                DashboardUi.warnColor(this)
            ) {
                AlertDialog.Builder(this@AlertEventSettingsActivity)
                    .setTitle("사용자 알림 설정 복원")
                    .setMessage("추가 음성 23종의 개별 ON/OFF 및 개별 음성/볼륨 설정을 기본값으로 되돌립니다. 차량 시스템 설정은 건드리지 않습니다.")
                    .setPositiveButton("복원") { _, _ ->
                        val ok = AlertEventCatalog.entries.all { entry ->
                            AlertPreferences.setEventEnabled(this@AlertEventSettingsActivity, entry.event, true) &&
                                AlertPreferences.setEventStyleOverride(this@AlertEventSettingsActivity, entry.event, null) &&
                                AlertPreferences.setEventVolumeTierOverride(this@AlertEventSettingsActivity, entry.event, -1)
                        }
                        if (ok) recreate() else Toast.makeText(this@AlertEventSettingsActivity, "일부 설정 저장 실패", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("취소", null).show()
            }, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, DashboardUi.dp(this@AlertEventSettingsActivity, 4), 0, 0)
            })
        }
        resetPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, resetPanel)
    }

    private fun hasOverride(event: AlertEvent): Boolean =
        AlertPreferences.eventStyleOverride(this, event) != null ||
            AlertPreferences.eventVolumeTierOverride(this, event) in 0..3

    private fun overrideSummary(event: AlertEvent): String {
        val style = AlertPreferences.eventStyleOverride(this, event)
        val vol = AlertPreferences.eventVolumeTierOverride(this, event)
        if (style == null && vol !in 0..3) return "공통"
        val sText = when (style) {
            AlertStyle.FEMALE -> "여성"
            AlertStyle.MALE -> "남성"
            AlertStyle.EFFECT -> "효과음"
            null -> "공통"
        }
        val vText = if (vol in 0..3) AlertVolume.labels[vol] else "공통"
        return "$sText · $vText"
    }

    private fun openOverrideDialog(event: AlertEvent, chip: TextView) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@AlertEventSettingsActivity, 20), DashboardUi.dp(this@AlertEventSettingsActivity, 12),
                DashboardUi.dp(this@AlertEventSettingsActivity, 20), DashboardUi.dp(this@AlertEventSettingsActivity, 8))
        }
        val styleChoices = listOf(null, AlertStyle.FEMALE, AlertStyle.MALE, AlertStyle.EFFECT)
        val styleLabels = listOf("공통 설정 따름", "여성 음성", "남성 음성", "효과음")
        val styleSpinner = Spinner(this).apply {
            adapter = DarkSpinnerAdapter.labels(this@AlertEventSettingsActivity, styleLabels)
            setSelection(styleChoices.indexOf(AlertPreferences.eventStyleOverride(this@AlertEventSettingsActivity, event)).coerceAtLeast(0))
        }
        val volChoices = listOf(-1, 0, 1, 2, 3)
        val volLabels = listOf("공통 볼륨 따름") + AlertVolume.labels
        val volSpinner = Spinner(this).apply {
            adapter = DarkSpinnerAdapter.labels(this@AlertEventSettingsActivity, volLabels)
            setSelection(volChoices.indexOf(AlertPreferences.eventVolumeTierOverride(this@AlertEventSettingsActivity, event)).coerceAtLeast(0))
        }
        box.addView(TextView(this).apply { text = "음성 스타일"; textSize = 14f; setPadding(0, 4, 0, 6) })
        box.addView(styleSpinner)
        box.addView(TextView(this).apply { text = "소리 크기"; textSize = 14f; setPadding(0, 14, 0, 6) })
        box.addView(volSpinner)

        AlertDialog.Builder(this)
            .setTitle("${event.phrase} · 개별 음성/볼륨")
            .setView(box)
            .setPositiveButton("저장") { _, _ ->
                AlertPreferences.setEventStyleOverride(this, event, styleChoices[styleSpinner.selectedItemPosition])
                AlertPreferences.setEventVolumeTierOverride(this, event, volChoices[volSpinner.selectedItemPosition])
                val tint = if (hasOverride(event)) DashboardUi.okColor(this) else DashboardUi.mutedColor(this)
                chip.text = overrideSummary(event)
                chip.setTextColor(tint)
                chip.background = DashboardUi.cardBg(this, DashboardUi.alphaColor(tint, 32), DashboardUi.alphaColor(tint, 90), 99)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    override fun onDestroy() {
        runCatching { previewPlayer?.shutdown() }
        previewPlayer = null
        super.onDestroy()
    }
}
