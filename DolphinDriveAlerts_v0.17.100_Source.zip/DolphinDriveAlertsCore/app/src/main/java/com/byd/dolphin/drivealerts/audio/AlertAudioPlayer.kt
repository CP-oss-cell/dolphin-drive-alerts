package com.byd.dolphin.drivealerts.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.config.AlertVolume
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.OutputRoute
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.PI
import kotlin.math.sin

class AlertAudioPlayer(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "drive-alert-audio") }
    private val sequence = AtomicLong()
    private val wavCache = HashMap<String, PcmWav>()
    @Volatile private var activePriority: Int = -1
    @Volatile private var activeUntilMs: Long = 0L

    fun play(request: AlertRequest) {
        val now = System.currentTimeMillis()
        // Protect active higher-priority safety alerts (e.g. door/BSD/LDW) from being preempted by lower-priority notices.
        if (now < activeUntilMs && request.event.priority < activePriority) {
            CoreLog.i("AUDIO", "AUDIO_PREEMPT_BLOCKED incoming=${request.event.name}(p=${request.event.priority}) activePriority=$activePriority")
            return
        }
        val token = sequence.incrementAndGet()
        activePriority = request.event.priority
        activeUntilMs = now + 4_500L
        worker.execute {
            val style = AlertPreferences.effectiveStyle(context, request.event)
            val route = AlertPreferences.route(context)
            val volTier = AlertPreferences.effectiveVolumeTier(context, request.event)
            val gain = AlertVolume.trackGain(volTier)
            withTransientMediaDucking("alert:${request.event.name}") {
                try {
                    val voicePath = VoiceAssetCatalog.path(request, style)
                    if (voicePath != null) {
                        val wav = loadVoice(voicePath)
                        if (wav != null) {
                            playPcm(wav, route, token, "voice:$voicePath", gain)
                            return@withTransientMediaDucking
                        }
                        CoreLog.w("AUDIO", "voice asset missing: $voicePath; effect fallback phrase=${request.phrase}")
                    }
                    runCatching { playEffect(request, route, token, gain) }
                        .onFailure { CoreLog.w("AUDIO", "effect playback failed: ${it.message}", it) }
                } finally {
                    if (sequence.get() == token) {
                        activePriority = -1
                        activeUntilMs = 0L
                    }
                }
            }
        }
    }

    fun playOneShot(customFile: File?, source: String) {
        val token = sequence.incrementAndGet()
        activePriority = 50
        activeUntilMs = System.currentTimeMillis() + 6_000L
        worker.execute {
            val route = AlertPreferences.route(context)
            val gain = AlertVolume.trackGain(AlertVolume.tier(context))
            withTransientMediaDucking("one-shot:$source") {
                try {
                    if (customFile != null && customFile.isFile) {
                        val wav = runCatching { customFile.inputStream().use(PcmWavReader::read) }.getOrNull()
                        if (wav != null) {
                            playPcm(wav, route, token, "one-shot-file:${customFile.name}:$source", gain)
                            return@withTransientMediaDucking
                        }
                        if (playEncodedFile(customFile, route, token, "one-shot-file:${customFile.name}:$source", gain)) {
                            return@withTransientMediaDucking
                        }
                        CoreLog.w("AUDIO", "custom one-shot decode/play failed; using built-in fallback file=${customFile.absolutePath}")
                    }

                    val style = AlertPreferences.style(context)
                    val voiceDir = if (style == AlertStyle.MALE) "male" else "female"
                    val fallback = "voice/$voiceDir/one_shot_pass.wav"
                    val wav = loadVoice(fallback)
                    if (wav != null) {
                        playPcm(wav, route, token, "one-shot-fallback:$fallback:$source", gain)
                    } else {
                        CoreLog.w("AUDIO", "one-shot fallback asset missing: $fallback")
                    }
                } finally {
                    if (sequence.get() == token) {
                        activePriority = -1
                        activeUntilMs = 0L
                    }
                }
            }
        }
    }

    fun shutdown() { worker.shutdownNow() }

    /**
     * Request Android standard transient ducking focus (AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
     * during alert speech and abandon immediately on completion. Never touches OEM warning
     * channels or starts paused media.
     */
    private inline fun withTransientMediaDucking(tag: String, block: () -> Unit) {
        if (!AlertPreferences.mediaDuckingEnabled(context)) {
            block()
            return
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am == null || Build.VERSION.SDK_INT < 26) {
            block()
            return
        }
        val focusAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(focusAttrs)
            .setAcceptsDelayedFocusGain(false)
            .setWillPauseWhenDucked(false)
            .build()
        val granted = runCatching { am.requestAudioFocus(focusRequest) }
            .onFailure { CoreLog.w("AUDIO", "duck focus request failed ($tag): ${it.message}") }
            .getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
        CoreLog.i("AUDIO", "DUCK_FOCUS_REQUEST tag=$tag result=$granted")
        try {
            block()
        } finally {
            if (granted == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                val abandoned = runCatching { am.abandonAudioFocusRequest(focusRequest) }
                    .onFailure { CoreLog.w("AUDIO", "duck focus abandon failed ($tag): ${it.message}") }
                    .getOrDefault(AudioManager.AUDIOFOCUS_REQUEST_FAILED)
                CoreLog.i("AUDIO", "DUCK_FOCUS_ABANDON tag=$tag result=$abandoned")
            }
        }
    }

    private fun loadVoice(path: String): PcmWav? = synchronized(wavCache) {
        wavCache[path]?.let { return it }
        val parsed = runCatching { PcmWavReader.read(context.assets.open(path)) }
            .onFailure { CoreLog.w("AUDIO", "failed to load $path: ${it.message}") }
            .getOrNull() ?: return null
        wavCache[path] = parsed
        parsed
    }

    private fun playEffect(request: AlertRequest, route: OutputRoute, token: Long, gain: Float) {
        val (freq, repeats, duration) = when {
            request.event.priority >= 90 -> Triple(1120.0, 3, 130)
            request.event.priority >= 70 -> Triple(930.0, 2, 150)
            request.event.name == "LEAD_CAR_DEPARTURE" -> Triple(660.0, 2, 110)
            else -> Triple(760.0, 1, 120)
        }
        repeat(repeats) { index ->
            if (sequence.get() != token) return
            val samples = tone(44_100, freq + index * 55.0, duration)
            playPcm(PcmWav(44_100, 1, 16, samples), route, token, "effect:${request.event}", gain)
            if (index < repeats - 1) Thread.sleep(70)
        }
    }

    private fun tone(sampleRate: Int, hz: Double, ms: Int): ShortArray {
        val n = sampleRate * ms / 1000
        return ShortArray(n) { i ->
            val fade = minOf(1.0, i / 400.0, (n - i) / 400.0).coerceAtLeast(0.0)
            (sin(2.0 * PI * hz * i / sampleRate) * 0.28 * fade * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun playPcm(wav: PcmWav, route: OutputRoute, token: Long, label: String, gain: Float) {
        val base = if (wav.channels == 1) wav.pcm16 else downmix(wav.pcm16, wav.channels)
        val mono = base
        val rate = wav.sampleRate.coerceIn(8_000, 96_000)
        if (sequence.get() != token) return
        if (route == OutputRoute.DRIVER_RAW14) {
            if (runCatching { playRawStream14(mono, rate, token, label, gain); true }
                    .onFailure { CoreLog.w("AUDIO", "raw14 failed: ${it.message}", it) }.getOrDefault(false)) return
            CoreLog.w("AUDIO", "raw14 failed; attempting legacy attributes then media")
        }
        try {
            val attrs = when (route) {
                OutputRoute.DRIVER_STREAM14, OutputRoute.DRIVER_RAW14 -> buildDriverStream14Attributes()
                OutputRoute.MEDIA -> AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            }
            playWithAttributes(mono, rate, attrs, token, "$label/$route", gain)
        } catch (t: Throwable) {
            CoreLog.w("AUDIO", "attributes playback failed: ${t.message}", t)
            val rawOk = route != OutputRoute.MEDIA && runCatching { playRawStream14(mono, rate, token, label, gain); true }
                .onFailure { CoreLog.w("AUDIO", "raw14 fallback failed: ${it.message}", it) }.getOrDefault(false)
            if (!rawOk && route != OutputRoute.MEDIA) {
                val mediaAttrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                runCatching { playWithAttributes(mono, rate, mediaAttrs, token, "$label/MEDIA_FALLBACK", gain) }
                    .onFailure { CoreLog.w("AUDIO", "media fallback failed: ${it.message}", it) }
            }
        }
    }

    private fun playEncodedFile(file: File, route: OutputRoute, token: Long, label: String, gain: Float): Boolean {
        fun attempt(attrs: AudioAttributes, attemptLabel: String): Boolean {
            var player: MediaPlayer? = null
            return try {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    setDataSource(file.absolutePath)
                    prepare()
                    setVolume(gain, gain)
                    start()
                }
                CoreLog.i("AUDIO", "play encoded $attemptLabel duration=${player.duration}ms")
                while (sequence.get() == token && player.isPlaying) Thread.sleep(30)
                if (sequence.get() != token) runCatching { player.stop() }
                true
            } catch (t: Throwable) {
                CoreLog.w("AUDIO", "encoded playback failed $attemptLabel: ${t.message}", t)
                false
            } finally {
                runCatching { player?.release() }
            }
        }

        val primary = when (route) {
            OutputRoute.DRIVER_STREAM14, OutputRoute.DRIVER_RAW14 -> runCatching { buildDriverStream14Attributes() }.getOrNull()
            OutputRoute.MEDIA -> AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        }
        if (primary != null && attempt(primary, "$label/$route")) return true
        if (route != OutputRoute.MEDIA) {
            val media = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            return attempt(media, "$label/MEDIA_FALLBACK")
        }
        return false
    }

    private fun playWithAttributes(samples: ShortArray, rate: Int, attrs: AudioAttributes, token: Long, label: String, gain: Float) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
        val track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(maxOf(samples.size * 2, min))
            .build()
        try {
            val written = track.write(samples, 0, samples.size)
            require(written > 0) { "AudioTrack write=$written" }
            track.setVolume(gain)
            CoreLog.i("AUDIO", "play $label samples=$written rate=$rate gain=$gain session=${track.audioSessionId}")
            track.play()
            waitFor(samples.size, rate, token)
            runCatching { track.stop() }
        } finally { track.release() }
    }

    @Suppress("DEPRECATION")
    private fun playRawStream14(samples: ShortArray, rate: Int, token: Long, label: String, gain: Float) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
        val track = AudioTrack(14, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(samples.size * 2, min), AudioTrack.MODE_STATIC)
        try {
            val written = track.write(samples, 0, samples.size)
            require(track.state == AudioTrack.STATE_INITIALIZED) { "raw stream14 state=${track.state} write=$written" }
            track.setVolume(gain)
            CoreLog.i("AUDIO", "play raw stream14 $label samples=$written gain=$gain")
            track.play()
            waitFor(samples.size, rate, token)
            runCatching { track.stop() }
        } finally { track.release() }
    }

    private fun waitFor(samples: Int, rate: Int, token: Long) {
        val end = System.currentTimeMillis() + samples * 1000L / rate + 80L
        while (System.currentTimeMillis() < end && sequence.get() == token) Thread.sleep(20)
    }

    private fun buildDriverStream14Attributes(): AudioAttributes {
        val builder = AudioAttributes.Builder()
        val method = builder.javaClass.methods.firstOrNull { it.name == "setLegacyStreamType" && it.parameterTypes.size == 1 }
            ?: builder.javaClass.declaredMethods.firstOrNull { it.name == "setLegacyStreamType" && it.parameterTypes.size == 1 }
            ?: throw NoSuchMethodException("setLegacyStreamType")
        runCatching { method.isAccessible = true }
        method.invoke(builder, 14)
        return builder.build()
    }

    private fun downmix(input: ShortArray, channels: Int): ShortArray {
        if (channels <= 1) return input
        val frames = input.size / channels
        return ShortArray(frames) { f ->
            var sum = 0
            for (c in 0 until channels) sum += input[f * channels + c].toInt()
            (sum / channels).toShort()
        }
    }
}
