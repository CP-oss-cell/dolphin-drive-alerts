package com.byd.dolphin.drivealerts.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.automation.AutoLaunchSequenceService
import com.byd.dolphin.drivealerts.automation.IgnitionSequenceAlarmReceiver
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import com.byd.dolphin.drivealerts.automation.IgnitionOffAppStopper
import com.byd.dolphin.drivealerts.automation.IgnitionOffStopService
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.log.CaptureContinuity
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal
import com.byd.dolphin.drivealerts.automation.IgnitionWakePolicy
import com.byd.dolphin.drivealerts.vehicle.BydPermissionContext

/**
 * Starts the always-on foreground monitor after Android/BYD boot and vehicle wake signals.
 * v0.17.97 (Real-Car Log Verified):
 * BYD Dolphin DiLink 5.0 emits ACTION_BOOT_COMPLETED / QUICKBOOT_POWERON on ignition ON
 * (often without com.byd.action.ACC_ON). We now trigger AutoLaunchSequenceService on
 * ACC_ON, IGN_ON, QUICKBOOT_POWERON, and BOOT_COMPLETED unless BYDAutoBodyworkDevice
 * explicitly reports powerLevel == 0 (parked OFF).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: "<null>"
        val enabled = AlertPreferences.isEnabled(context)
        val autoStart = AlertPreferences.autoStartEnabled(context)
        CoreLog.i("BOOT", "BOOT_RX_TIME action=$action elapsedRealtimeMs=${android.os.SystemClock.elapsedRealtime()} enabled=$enabled autoStart=$autoStart")
        val bootGuard = context.getSharedPreferences("ignition_sequence_guard", Context.MODE_PRIVATE)
        IgnitionAuditJournal.record(context, "BOOT_RX", "action=$action monitor=$enabled auto=$autoStart sequence=${FeatureProfiles.sequenceEnabled(context)} armed=${bootGuard.getBoolean("armed", true)}")
        if (action in QUICKBOOT_ACTIONS) {
            bootGuard.edit().putLong("last_quickboot_elapsed", android.os.SystemClock.elapsedRealtime()).commit()
            IgnitionAuditJournal.record(context, "VENDOR_WAKE_HINT", "action=$action")
        }

        val recording = UnifiedLogCapture.state(context).takeIf {
            it.status == UnifiedLogCapture.RECORDING && it.id.isNotBlank()
        }
        if (action == com.byd.dolphin.drivealerts.sentry.SentryWakeKeeper.ACTION_SENTRY_HEARTBEAT) {
            if (com.byd.dolphin.drivealerts.sentry.SentryPreferences.enabled(context) &&
                com.byd.dolphin.drivealerts.sentry.SentryPreferences.keepAwakeOnOff(context)) {
                DrivingAlertService.pulseSentryWake(context.applicationContext)
            }
            return
        }
        if (action == Intent.ACTION_POWER_DISCONNECTED) {
            CoreLog.i("BOOT", "ANDROID_POWER_DISCONNECTED observation-only; ignition state unchanged")
            return
        }
        if (action in STOP_SIDE_ACTIONS) {
            if (recording != null) runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            context.getSharedPreferences("ignition_sequence_guard", Context.MODE_PRIVATE)
                .edit().putBoolean("armed", true).putLong("last_quickboot_elapsed", -1L).commit()
            IgnitionSequenceAlarmReceiver.cancel(context)
            context.stopService(Intent(context, AutoLaunchSequenceService::class.java))
            CoreLog.i("BOOT", "vehicle/power stop-side signal observed; auto sequence cancelled: $action")
            DrivingAlertService.flushDashcamForPowerOff(context)
            if (com.byd.dolphin.drivealerts.notify.TelegramPreferences.notifyIgnition(context)) {
                com.byd.dolphin.drivealerts.notify.TelegramNotifier.sendTextAsync(context, "🔌 시동 OFF", "차량 시동이 꺼졌습니다 ($action).")
            }
            if (com.byd.dolphin.drivealerts.sentry.SentryPreferences.enabled(context) && com.byd.dolphin.drivealerts.sentry.SentryPreferences.keepAwakeOnOff(context)) {
                com.byd.dolphin.drivealerts.sentry.SentryWakeKeeper.scheduleHeartbeat(context.applicationContext)
            }
            IgnitionAuditJournal.record(context, "IGNITION_OFF", "action=$action rearmed=true")
            if (action == "com.byd.action.ACC_OFF" && IgnitionOffAppStopper.enabled(context)) {
                IgnitionOffStopService.start(context.applicationContext)
            }
            return
        }

        if (recording != null && action in CAPTURE_WAKE_ACTIONS) {
            runCatching { CaptureContinuity.ignitionHint(context, recording.id, action) }
            runCatching { DrivingAlertService.wakeRecording(context.applicationContext, action) }
                .onFailure {
                    CoreLog.w("BOOT", "capture wake request failed: $action ${it.message}", it)
                    IgnitionAuditJournal.record(context, "CAPTURE_WAKE_REJECTED", "action=$action type=${it.javaClass.simpleName}")
                }
        } else if (enabled && autoStart) {
            runCatching { DrivingAlertService.start(context.applicationContext) }
                .onSuccess {
                    CoreLog.i("BOOT", "foreground service start requested: $action")
                    IgnitionAuditJournal.record(context, "MONITOR_START_REQUEST", "action=$action notVerified=true")
                }
                .onFailure {
                    CoreLog.w("BOOT", "start failed for $action: ${it.message}", it)
                    IgnitionAuditJournal.record(context, "MONITOR_START_REJECTED", "action=$action type=${it.javaClass.simpleName}")
                }
        }

        if (action in AUTO_SEQUENCE_ACTIONS) {
            // For cold BOOT_COMPLETED, re-arm automatically because elapsedRealtime restarted after power-off
            if (action == Intent.ACTION_BOOT_COMPLETED) {
                val pwr = readPowerLevelSafe(context)
                if (pwr == 0) {
                    CoreLog.i("BOOT", "AUTO_SEQUENCE_BOOT_SKIPPED powerLevel=0 (vehicle OFF)")
                    IgnitionAuditJournal.record(context, "SEQUENCE_BOOT_SKIPPED", "powerLevel=0")
                    return
                }
                bootGuard.edit().putBoolean("armed", true).commit()
                CoreLog.i("BOOT", "AUTO_SEQUENCE_BOOT_ARMED powerLevel=$pwr")
            }

            val seqEnabled = FeatureProfiles.sequenceEnabled(context)
            val steps = FeatureProfiles.steps(context).count { it.enabled }
            val guard = bootGuard
            val now = android.os.SystemClock.elapsedRealtime()
            val previous = guard.getLong("last_started_elapsed", -1L)
            val armed = guard.getBoolean("armed", true)
            val decision = IgnitionWakePolicy.decide(armed, now, previous,
                guard.getLong("last_quickboot_elapsed", -1L))
            CoreLog.i("BOOT", "AUTO_SEQUENCE_TRIGGER action=$action enabled=$seqEnabled steps=$steps armed=$armed reason=${decision.reason} elapsed=$now lastElapsed=$previous")
            IgnitionAuditJournal.record(context, "SEQUENCE_TRIGGER", "action=$action enabled=$seqEnabled steps=$steps armed=$armed reason=${decision.reason}")
            if (!seqEnabled) {
                CoreLog.i("BOOT", "AUTO_SEQUENCE_DISABLED action=$action")
            } else if (steps == 0) {
                CoreLog.w("BOOT", "AUTO_SEQUENCE_NO_ENABLED_STEPS action=$action")
            } else if (decision.allowed) {
                val stored = guard.edit().putBoolean("armed", false)
                    .putLong("last_started_elapsed", now).commit()
                if (!stored) {
                    CoreLog.w("BOOT", "AUTO_SEQUENCE_GUARD_PERSIST_FAILED action=$action")
                } else {
                    val requestId = IgnitionSequenceAlarmReceiver.schedule(context.applicationContext)
                    if (requestId == null) {
                        val rearmed = guard.edit().putBoolean("armed", true)
                            .putLong("last_started_elapsed", previous).commit()
                        IgnitionAuditJournal.record(context, "SEQUENCE_GUARD_REJECTED", "action=$action reason=persist_failed rearmed=$rearmed")
                        CoreLog.w("BOOT", "AUTO_SEQUENCE_REQUEST_NOT_PERSISTED action=$action rearmed=$rearmed")
                        return
                    }
                    IgnitionAuditJournal.record(context, "SEQUENCE_DISPATCH", "action=$action reason=${decision.reason}")
                    val accepted = AutoLaunchSequenceService.start(context.applicationContext, requestId = requestId)
                    if (!accepted) {
                        IgnitionSequenceAlarmReceiver.cancel(context.applicationContext)
                        guard.edit().putBoolean("armed", true).putLong("last_started_elapsed", previous).commit()
                        CoreLog.w("BOOT", "AUTO_SEQUENCE_DELIVERY_REJECTED action=$action;rearmed=true")
                        IgnitionAuditJournal.record(context, "SEQUENCE_REJECTED", "action=$action rearmed=true")
                    } else {
                        CoreLog.i("BOOT", "AUTO_SEQUENCE_DELIVERY_REQUESTED action=$action")
                        IgnitionAuditJournal.record(context, "SEQUENCE_REQUESTED", "action=$action")
                    }
                }
            } else {
                CoreLog.i("BOOT", "AUTO_SEQUENCE_DUPLICATE_SUPPRESSED action=$action armed=$armed reason=${decision.reason}")
                IgnitionAuditJournal.record(context, "SEQUENCE_SUPPRESSED", "action=$action reason=${decision.reason}")
            }
        }
    }

    private fun readPowerLevelSafe(context: Context): Int? = runCatching {
        val wrapped = BydPermissionContext.wrap(context.applicationContext)
        val cls = Class.forName("android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice")
        val getInst = cls.methods.firstOrNull { it.name == "getInstance" && it.parameterCount == 1 } ?: return@runCatching null
        val dev = getInst.invoke(null, wrapped) ?: return@runCatching null
        val m = cls.methods.firstOrNull { it.name == "getPowerLevel" && it.parameterCount == 0 } ?: return@runCatching null
        (m.invoke(dev) as? Number)?.toInt()
    }.getOrNull()

    companion object {
        private val QUICKBOOT_ACTIONS = setOf(
            "android.intent.action.QUICKBOOT_POWERON", "com.htc.intent.action.QUICKBOOT_POWERON",
            "com.byd.intent.action.QUICKBOOT_POWERON", "com.qualcomm.action.QUICKBOOT_POWERON"
        )
        private val CAPTURE_WAKE_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_USER_PRESENT, Intent.ACTION_USER_UNLOCKED,
            Intent.ACTION_SCREEN_ON, Intent.ACTION_POWER_CONNECTED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON", "com.byd.intent.action.QUICKBOOT_POWERON",
            "com.qualcomm.action.QUICKBOOT_POWERON", "com.byd.action.ACC_ON", "com.byd.action.IGN_ON",
            "com.byd.accmode.ACC_MODE_CHANGED"
        )
        private val AUTO_SEQUENCE_ACTIONS = setOf(
            "com.byd.action.ACC_ON",
            "com.byd.action.IGN_ON",
            "com.byd.accmode.ACC_MODE_CHANGED",
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            "com.byd.intent.action.QUICKBOOT_POWERON",
            "com.qualcomm.action.QUICKBOOT_POWERON"
        )
        private val STOP_SIDE_ACTIONS = setOf("com.byd.action.ACC_OFF")
    }
}
