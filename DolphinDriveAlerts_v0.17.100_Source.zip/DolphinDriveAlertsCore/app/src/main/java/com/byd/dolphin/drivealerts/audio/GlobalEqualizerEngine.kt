package com.byd.dolphin.drivealerts.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Build
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * v0.17.60 High-Resolution Automotive Audio Engine:
 * - DynamicsProcessing with 10-band Pre-EQ + 3-band Multi-Band Compressor (MBC) + Soft Limiter
 * - Loudness-preserving makeup gain (eliminates EQ-ON volume drop)
 * - Per-channel Left/Right soundstage balance + acoustic spatial contours (works on all car speakers)
 */
class GlobalEqualizerEngine(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val sessions = ConcurrentHashMap<Int, SessionFx>()
    private val lock = Any()
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val i = intent ?: return
            val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            val pkg = i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME).orEmpty()
            if (id <= 0 || pkg.isBlank() || pkg == app.packageName) return
            synchronized(lock) {
                when (i.action) {
                    AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                        CoreLog.i("EQ", "SESSION_OPEN id=$id source=$pkg")
                        sessions.remove(0)?.close()
                        sessions.getOrPut(id) { SessionFx(id, pkg) }
                    }
                    AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                        CoreLog.i("EQ", "SESSION_CLOSE id=$id source=$pkg")
                        sessions.remove(id)?.close()
                    }
                }
                refreshLocked()
            }
        }
    }

    fun start() {
        synchronized(lock) {
            if (!registered) {
                val f = IntentFilter().apply {
                    addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                    addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
                }
                runCatching { app.registerReceiver(receiver, f) }
                    .onSuccess { registered = true }
                    .onFailure { CoreLog.w("EQ", "SESSION_RECEIVER_FAILED: ${it.message}", it) }
            }
            refreshLocked()
        }
    }

    fun refresh() = synchronized(lock) { refreshLocked() }

    private fun refreshLocked() {
        val s = EqPreferences.read(app)
        if (!s.enabled) {
            sessions.values.forEach { it.close() }
            sessions.remove(0)?.close()
            status("EQ 꺼짐 · 순정 오디오 상태")
            return
        }
        if (sessions.keys.none { it > 0 } && s.globalMix) {
            sessions.getOrPut(0) { SessionFx(0, "Global Mix") }
        } else if (!s.globalMix) {
            sessions.remove(0)?.close()
        }
        val values = sessions.values.sortedBy { it.sessionId }
            .map { fx -> "${fx.sessionId}/${fx.owner}: ${fx.apply(s)}" }
        val operational = values.any { it.contains("EQ=APPLIED") }
        status(when {
            values.isEmpty() -> "EQ 대기 중 · Global Mix 호환모드를 켜거나 음악을 재생하세요."
            operational -> "프리미엄 EQ 적용됨: ${values.joinToString(" | ")}"
            else -> "EQ 적용 실패/미지원: ${values.joinToString(" | ")}"
        })
    }

    private fun status(value: String) {
        app.getSharedPreferences(STATUS_PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS_KEY, value).apply()
        CoreLog.i("EQ", value)
    }

    override fun close() = synchronized(lock) {
        if (registered) runCatching { app.unregisterReceiver(receiver) }
        registered = false
        sessions.values.forEach { it.close() }
        sessions.clear()
    }

    private class SessionFx(val sessionId: Int, val owner: String) : Closeable {
        private var dp: DynamicsProcessing? = null
        private var initialDp: DynamicsProcessing.Config? = null
        private var classic: Equalizer? = null
        private var initialBands: List<Short>? = null
        private var initialEnabled: Boolean? = null
        private var virtualizer: Virtualizer? = null
        private var initialVirtualEnabled: Boolean? = null
        private var initialVirtualStrength: Short? = null
        private val priority = 0

        private fun prepare(): String {
            if (dp != null || classic != null) return "ready"
            if (Build.VERSION.SDK_INT >= 28) {
                val r = runCatching {
                    // Enable 10-band Pre-EQ + 3-band MBC + Soft Limiter for studio-grade dynamic clarity
                    val cfg = DynamicsProcessing.Config.Builder(
                        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        2,
                        true, 10,
                        true, 3,
                        false, 0,
                        true
                    ).setPreferredFrameDuration(10f).build()
                    val created = DynamicsProcessing(priority, sessionId, cfg)
                    if (!created.hasControl()) {
                        created.release()
                        error("DP_NO_CONTROL")
                    }
                    initialDp = created.config
                    dp = created
                }
                if (r.isSuccess) return "DP10_MBC_LIM"
                CoreLog.w("EQ", "DP unavailable session=$sessionId reason=${r.exceptionOrNull()?.message}")
            }
            return prepareLegacy()
        }

        private fun prepareLegacy(): String {
            val r = runCatching {
                val eq = Equalizer(priority, sessionId)
                if (!eq.hasControl()) { eq.release(); error("EQ_NO_CONTROL") }
                initialBands = (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()) }
                initialEnabled = eq.enabled
                classic = eq
            }
            return if (r.isSuccess) "LEGACY" else "NO_ENGINE:${r.exceptionOrNull()?.javaClass?.simpleName}"
        }

        fun apply(s: EqSettings): String {
            val prepared = prepare()
            if (dp == null && classic == null) return "EQ=UNAVAILABLE ($prepared)"
            var result = if (dp != null) applyDynamics(s) else applyClassic(s)
            if (dp != null && !result.startsWith("EQ=APPLIED")) {
                releaseDynamics()
                val fallback = prepareLegacy()
                result = if (classic != null) applyClassic(s) else "$result; fallback=$fallback"
            }
            val spatial = applyVirtualizer(EqToneCurve.virtualizerStrength(s))
            return "$result; SPATIAL=$spatial"
        }

        private fun applyDynamics(s: EqSettings): String = runCatching {
            val e = requireNotNull(dp)
            if (!e.hasControl()) return@runCatching "EQ=NO_CONTROL(DP)"
            val cfg = e.config
            if (!cfg.isPreEqInUse || cfg.preEqBandCount <= 0) return@runCatching "EQ=NO_BANDS(DP)"
            val count = cfg.preEqBandCount
            val hz = IntArray(count) { i -> cfg.getPreEqBandByChannelIndex(0, i).cutoffFrequency.roundToInt() }
            for (i in 0 until count) {
                val gain = EqToneCurve.gainDb(s, hz[i])
                val band = DynamicsProcessing.EqBand(true, hz[i].toFloat(), gain)
                e.setPreEqBandAllChannelsTo(i, band)
            }

            // 3-Band Multi-Band Compressor (Sub/Bass, Vocal/Mid, Air/Treble) for rich presence at all volumes
            if (cfg.isMbcInUse && cfg.mbcBandCount >= 3) {
                val mbcOn = s.dynamicMbcEnabled
                val cutoffs = floatArrayOf(220f, 3200f, 20000f)
                val postGains = when (s.soundFocus) {
                    SoundFocusMode.SURROUND -> floatArrayOf(1.2f, 0.8f, 1.8f)
                    SoundFocusMode.CINEMA -> floatArrayOf(2.4f, 1.0f, 1.0f)
                    SoundFocusMode.REFERENCE -> floatArrayOf(0.5f, 0.5f, 0.5f)
                }
                for (b in 0 until 3) {
                    val mbcBand = DynamicsProcessing.MbcBand(
                        mbcOn,
                        cutoffs[b],
                        8f,    // attack ms
                        80f,   // release ms
                        1.8f,  // gentle compression ratio
                        -18f,  // threshold dB
                        6f,    // soft knee width dB
                        -75f,  // noise gate threshold
                        1.0f,  // expander ratio
                        0f,    // preGain
                        if (mbcOn) postGains[b] else 0f
                    )
                    e.setMbcBandAllChannelsTo(b, mbcBand)
                }
            }

            // Transparent Soft Limiter: allows makeup gain without clipping or volume drop
            if (cfg.isLimiterInUse) {
                val lim = DynamicsProcessing.Limiter(
                    true,
                    s.limiterEnabled,
                    0,
                    1.0f,   // attack ms
                    60.0f,  // release ms
                    6.0f,   // ratio
                    -1.0f,  // threshold dBFS
                    if (s.limiterEnabled) 0.5f else 0f // postGain
                )
                e.setLimiterAllChannelsTo(lim)
            }

            // Per-channel input gain = loudness-preserving headroom + L/R driver stage balance
            val baseGain = EqToneCurve.headroomDb(s, hz)
            val chCount = e.getChannelCount()
            for (c in 0 until chCount) {
                val chGain = (baseGain + EqToneCurve.channelBalanceDb(s, c)).coerceIn(-12f, 6f)
                e.setInputGainbyChannel(c, chGain)
            }

            val code = e.setEnabled(true)
            if (code == AudioEffect.SUCCESS && e.enabled)
                "EQ=APPLIED(DP-${count}band,gain=${"%+.1f".format(baseGain)}dB,MBC=${s.dynamicMbcEnabled},LIM=${s.limiterEnabled})"
            else "EQ=READBACK_FAIL(DP code=$code)"
        }.getOrElse { "EQ=ERROR(DP:${it.javaClass.simpleName})" }

        private fun applyClassic(s: EqSettings): String = runCatching {
            val eq = requireNotNull(classic)
            if (!eq.hasControl()) return@runCatching "EQ=NO_CONTROL(LEGACY)"
            val r = eq.bandLevelRange
            val count = eq.numberOfBands.toInt()
            val frequencies = IntArray(count) { i -> eq.getCenterFreq(i.toShort()) / 1000 }
            val trim = EqToneCurve.headroomDb(s, frequencies)
            for (i in 0 until count) {
                val band = i.toShort()
                val hz = frequencies[i]
                val mb = ((EqToneCurve.gainDb(s, hz) + trim) * 100f).roundToInt()
                    .coerceIn(r[0].toInt(), r[1].toInt()).toShort()
                eq.setBandLevel(band, mb)
            }
            val code = eq.setEnabled(true)
            if (code == AudioEffect.SUCCESS && eq.enabled) "EQ=APPLIED(LEGACY-${count}band,gain=${"%+.1f".format(trim)}dB)"
            else "EQ=READBACK_FAIL(LEGACY code=$code)"
        }.getOrElse { "EQ=ERROR(LEGACY:${it.javaClass.simpleName})" }

        private fun applyVirtualizer(strength: Short): String {
            if (strength <= 0) {
                releaseVirtualizer()
                return "ACOUSTIC_ONLY"
            }
            if (virtualizer == null) {
                val v = runCatching { Virtualizer(priority, sessionId) }.getOrNull()
                    ?: return "ACOUSTIC_EQ_ACTIVE"
                if (!v.hasControl() || !v.strengthSupported) {
                    v.release()
                    return "ACOUSTIC_EQ_ACTIVE"
                }
                initialVirtualEnabled = v.enabled
                initialVirtualStrength = v.roundedStrength
                virtualizer = v
            }
            val v = virtualizer ?: return "ACOUSTIC_EQ_ACTIVE"
            val result = runCatching {
                v.setStrength(strength)
                val ec = v.setEnabled(true)
                val routeMode = v.virtualizationMode
                if (ec == AudioEffect.SUCCESS && v.enabled && routeMode != Virtualizer.VIRTUALIZATION_MODE_OFF)
                    "VIRTUALIZER+ACOUSTIC(${v.roundedStrength}/1000)"
                else "ACOUSTIC_EQ_ACTIVE(hwRoute=$routeMode)"
            }.getOrElse { "ACOUSTIC_EQ_ACTIVE" }
            if (!result.startsWith("VIRTUALIZER")) releaseVirtualizer()
            return result
        }

        private fun releaseVirtualizer() {
            virtualizer?.let { v -> runCatching {
                if (v.hasControl()) {
                    initialVirtualStrength?.let { v.setStrength(it) }
                    initialVirtualEnabled?.let { v.enabled = it }
                }
                v.release()
            } }
            virtualizer = null
            initialVirtualStrength = null
            initialVirtualEnabled = null
        }

        override fun close() {
            releaseVirtualizer()
            releaseDynamics()
            classic?.let { eq -> runCatching {
                if (eq.hasControl()) {
                    initialBands?.forEachIndexed { i, value -> eq.setBandLevel(i.toShort(), value) }
                    initialEnabled?.let { eq.enabled = it }
                }
                eq.release()
            } }
            classic = null
        }

        private fun releaseDynamics() {
            dp?.let { e -> runCatching {
                if (e.hasControl()) {
                    initialDp?.let { cfg ->
                        for (c in 0 until e.getChannelCount()) {
                            e.setChannelTo(c, cfg.getChannelByChannelIndex(c))
                        }
                    }
                    e.enabled = false
                }
                e.release()
            } }
            dp = null
            initialDp = null
        }
    }

    companion object {
        private const val STATUS_PREF = "audio_tuning_runtime"
        private const val STATUS_KEY = "eq_last_state"
        fun readStatus(context: Context): String = context.getSharedPreferences(
            STATUS_PREF, Context.MODE_PRIVATE).getString(STATUS_KEY, "EQ 엔진 준비 전").orEmpty()
    }
}
