package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.dpi.SelectedAppPermissionManager

/** Unified per-app permission manager (v0.17.82: adds overlay/camera/storage + select-all + one-tap grant). */
class AppPermissionManagerActivity : DensityAwareActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 20, 28, 28) }
        root.addView(box)
        DashboardUi.mount(this, root, "선택 앱 권한 관리", "ADB 기반 앱별 권한 조회 · 일괄 부여")

        fun label(text: String) = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(DashboardUi.textColor(this@AppPermissionManagerActivity))
            setPadding(0, 6, 0, 6)
        }

        box.addView(label("원하는 앱을 선택하고 필요한 권한을 한 번에 부여하거나 상태를 점검합니다. (로컬 ADB 연결 필요)"))

        val pm = packageManager
        val apps = pm.getInstalledApplications(0).filter { it.enabled }
            .sortedWith(
                compareByDescending<android.content.pm.ApplicationInfo> { it.packageName == packageName }
                    .thenBy { pm.getApplicationLabel(it).toString().lowercase() }
            )
        val names = apps.map {
            if (it.packageName == packageName) "Dolphin Drive (본 앱 · 권장) (${it.packageName})"
            else "${pm.getApplicationLabel(it)} (${it.packageName})"
        }
        if (apps.isEmpty()) {
            box.addView(label("설치된 앱이 조회되지 않습니다"))
            return
        }

        val appPicker = Spinner(this).apply { adapter = DarkSpinnerAdapter.labels(this@AppPermissionManagerActivity, names) }
        box.addView(appPicker)

        val selected = linkedMapOf(
            SelectedAppPermissionManager.Action.BATTERY to "배터리 최적화 예외 + 백그라운드 실행 허용",
            SelectedAppPermissionManager.Action.OVERLAY to "화면 위 표시 (독바 · BVM 오버레이)",
            SelectedAppPermissionManager.Action.CAMERA to "카메라 + BYD 360 카메라 권한",
            SelectedAppPermissionManager.Action.STORAGE to "외부 저장소 읽기/쓰기 (USB/SD 블랙박스)",
            SelectedAppPermissionManager.Action.NOTIFICATION_ACCESS to "알림 수신 접근 (TBT · 미디어 연동)",
            SelectedAppPermissionManager.Action.ACCESSIBILITY to "접근성 서비스 활성화 (홈/뒤로가기·분할)",
            SelectedAppPermissionManager.Action.USAGE_STATS to "사용기록 접근 (포그라운드 앱 감지)",
            SelectedAppPermissionManager.Action.LOCATION_FOREGROUND to "위치 권한 (정밀/대략 GPS)",
            SelectedAppPermissionManager.Action.LOCATION_BACKGROUND to "백그라운드 위치 (항상 허용)",
            SelectedAppPermissionManager.Action.LOCATION_SERVICE to "차량 전체 위치 서비스 ON (전역 설정)"
        )
        val checkboxes = selected.map { (action, title) ->
            action to CheckBox(this).apply {
                text = title
                setTextColor(DashboardUi.textColor(this@AppPermissionManagerActivity))
                isChecked = action != SelectedAppPermissionManager.Action.LOCATION_SERVICE
                box.addView(this)
            }
        }.toMap()

        val status = label("앱을 선택한 뒤 [권한 일괄 적용] 또는 [상태 조회]를 누르세요.")
        box.addView(status)

        fun run(configure: Boolean) {
            val idx = appPicker.selectedItemPosition
            if (idx !in apps.indices) return
            val pkg = apps[idx].packageName
            val actions = checkboxes.filterValues { it.isChecked }.keys
            status.text = "$pkg 권한 ${if (configure) "적용" else "조회"} 중…"
            Thread {
                val result = runCatching { SelectedAppPermissionManager.process(applicationContext, pkg, actions, configure) }
                    .getOrElse { SelectedAppPermissionManager.Result(listOf("권한 실행 오류: ${it.message}"), 0, actions.size) }
                runOnUiThread { status.text = "$pkg\n${result.lines.joinToString("\n")}" }
            }.start()
        }

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(
            DashboardUi.action(this, "전체 선택", null, DashboardUi.accentColor(this)) {
                checkboxes.values.forEach { it.isChecked = true }
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 6, 6, 6) }
        )
        btnRow.addView(
            DashboardUi.action(this, "전체 해제", null, DashboardUi.mutedColor(this)) {
                checkboxes.values.forEach { it.isChecked = false }
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(6, 6, 0, 6) }
        )
        box.addView(btnRow)

        box.addView(DashboardUi.action(this, "선택한 권한 ADB 일괄 적용 및 검증", DashboardIcons.IconKind.SHIELD_ADB, DashboardUi.okColor(this)) {
            val idx = appPicker.selectedItemPosition
            if (idx !in apps.indices) return@action
            AlertDialog.Builder(this)
                .setTitle("선택 앱 권한 적용")
                .setMessage("${names[idx]}에 체크된 권한을 로컬 ADB로 일괄 적용할까요?")
                .setPositiveButton("적용") { _, _ -> run(true) }
                .setNegativeButton("취소", null)
                .show()
        })

        box.addView(DashboardUi.action(this, "선택한 앱의 현재 권한 상태 조회", DashboardIcons.IconKind.KEY_PERM, DashboardUi.accentColor(this)) {
            run(false)
        })

        box.addView(DashboardUi.action(this, "Android 오버레이(다른 앱 위에 표시) 설정 열기", null, DashboardUi.mutedColor(this)) {
            runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }.onFailure { status.text = "오버레이 설정 화면 미지원: ${it.message}" }
        })

        box.addView(DashboardUi.action(this, "Android 알림 접근 설정 열기", null, DashboardUi.mutedColor(this)) {
            runCatching { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                .onFailure { status.text = "알림 접근 설정 화면 미지원: ${it.message}" }
        })

        box.addView(DashboardUi.action(this, "Android 접근성 설정 열기", null, DashboardUi.mutedColor(this)) {
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .onFailure { status.text = "접근성 설정 화면 미지원: ${it.message}" }
        })
    }
}
