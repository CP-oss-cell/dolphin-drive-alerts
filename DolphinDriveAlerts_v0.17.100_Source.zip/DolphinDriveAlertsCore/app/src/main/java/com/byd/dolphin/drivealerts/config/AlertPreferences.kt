package com.byd.dolphin.drivealerts.config

import android.content.Context
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.OutputRoute

object AlertPreferences {
    private const val PREF = "drive_alert_core"
    private const val KEY_ROUTE = "route"
    private const val KEY_STYLE = "style"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_AUTOSTART = "auto_start"
    private const val KEY_MEDIA_DUCKING = "media_ducking_enabled"
    private const val KEY_BSD_INDICATOR = "bsd_blinker_enabled"
    private const val KEY_BSD_INSTANT = "bsd_instant_enabled"
    private const val KEY_BSD_TURN_SOUND_EXPERIMENTAL = "bsd_turn_click_candidate_opt_in"
    private const val KEY_LAST_SEEN_VERSION_CODE = "last_seen_version_code"

    fun route(context: Context): OutputRoute = runCatching {
        OutputRoute.valueOf(prefs(context).getString(KEY_ROUTE, OutputRoute.DRIVER_STREAM14.name)!!)
    }.getOrDefault(OutputRoute.DRIVER_STREAM14)

    fun setRoute(context: Context, route: OutputRoute) =
        prefs(context).edit().putString(KEY_ROUTE, route.name).apply()

    fun style(context: Context): AlertStyle {
        val requested = runCatching {
            AlertStyle.valueOf(prefs(context).getString(KEY_STYLE, AlertStyle.FEMALE.name)!!)
        }.getOrDefault(AlertStyle.FEMALE)
        if (requested == AlertStyle.EFFECT) return requested
        return if (neuralVoicePackPresent(context)) requested else AlertStyle.EFFECT
    }

    fun neuralVoicePackPresent(context: Context): Boolean = runCatching {
        context.assets.open("voice/voice_pack_manifest.generated.json").use { input ->
            val text = input.bufferedReader().readText()
            text.contains("ko-KR-InJoonNeural") && text.contains("ko-KR-SunHiNeural") &&
                !text.contains("gtts-fallback")
        }
    }.getOrDefault(false)

    fun setStyle(context: Context, style: AlertStyle) =
        prefs(context).edit().putString(KEY_STYLE, style.name).apply()

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()

    /** Request transient AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK during alert playback and abandon immediately after. */
    fun mediaDuckingEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_MEDIA_DUCKING, true)
    fun setMediaDuckingEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_MEDIA_DUCKING, enabled).apply()

    /** Enabled by default: after first install/open, vehicle boot/quick-boot starts the service automatically. */
    fun autoStartEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTOSTART, true)
    fun setAutoStartEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_AUTOSTART, enabled).apply()

    /** Left/right *blinker* presence only; does NOT identify BSD hazard side. */
    fun bsdBlinkerEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INDICATOR, true)
    fun setBsdBlinkerEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INDICATOR, enabled).apply()

    /** The turn-click candidate also fires under some hazard-lamp conditions; explicit opt-in only. */
    fun bsdTurnSoundExperimentalEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BSD_TURN_SOUND_EXPERIMENTAL, false)
    fun setBsdTurnSoundExperimentalEnabled(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_TURN_SOUND_EXPERIMENTAL, value).apply()

    /** Optional generic immediate voice, OFF by default until each car's BSD raw is verified. */
    fun bsdInstantEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_BSD_INSTANT, false)
    fun setBsdInstantEnabled(context: Context, enabled: Boolean) =
        prefs(context).edit().putBoolean(KEY_BSD_INSTANT, enabled).apply()

    /** Default ON per owner's request: a recent 363+ECO(1) match followed by 364
     * enables NORMAL; opt-out is kept. Not an OEM-verified raw mode code. */
    fun normalNoticeCandidateEnabled(context: Context): Boolean =
        prefs(context).getBoolean("normal_notice_candidate_opt_in", true)
    fun setNormalNoticeCandidateEnabled(context: Context, value: Boolean) =
        prefs(context).edit().putBoolean("normal_notice_candidate_opt_in", value).apply()

    /** Each known alert can be muted without altering OEM monitoring or event decoding.
     * Defaults to ON so existing real-car-verified outputs are unchanged on upgrade. */
    fun eventEnabled(context: Context, event: AlertEvent): Boolean =
        prefs(context).getBoolean("alert_event_" + event.name, true)

    /** commit for immediate consistent preference after user taps. */
    fun setEventEnabled(context: Context, event: AlertEvent, enabled: Boolean): Boolean =
        prefs(context).edit().putBoolean("alert_event_" + event.name, enabled).commit()

    /** Per-event voice style override; null means inherit global style(). */
    fun eventStyleOverride(context: Context, event: AlertEvent): AlertStyle? {
        val raw = prefs(context).getString("alert_event_style_" + event.name, null) ?: return null
        return runCatching { AlertStyle.valueOf(raw) }.getOrNull()
    }

    fun setEventStyleOverride(context: Context, event: AlertEvent, style: AlertStyle?): Boolean {
        val ed = prefs(context).edit()
        if (style == null) ed.remove("alert_event_style_" + event.name)
        else ed.putString("alert_event_style_" + event.name, style.name)
        return ed.commit()
    }

    fun effectiveStyle(context: Context, event: AlertEvent): AlertStyle {
        val override = eventStyleOverride(context, event) ?: return style(context)
        if (override == AlertStyle.EFFECT) return override
        return if (neuralVoicePackPresent(context)) override else AlertStyle.EFFECT
    }

    /** Per-event volume tier override (-1 means inherit global AlertVolume.tier). */
    fun eventVolumeTierOverride(context: Context, event: AlertEvent): Int =
        prefs(context).getInt("alert_event_vol_" + event.name, -1).let { if (it in 0..3) it else -1 }

    fun setEventVolumeTierOverride(context: Context, event: AlertEvent, tier: Int): Boolean {
        val ed = prefs(context).edit()
        if (tier !in 0..3) ed.remove("alert_event_vol_" + event.name)
        else ed.putInt("alert_event_vol_" + event.name, tier)
        return ed.commit()
    }

    fun effectiveVolumeTier(context: Context, event: AlertEvent): Int {
        val override = eventVolumeTierOverride(context, event)
        return if (override in 0..3) override else AlertVolume.tier(context)
    }

    fun lastSeenVersionCode(context: Context): Int = prefs(context).getInt(KEY_LAST_SEEN_VERSION_CODE, -1)
    fun setLastSeenVersionCode(context: Context, code: Int) =
        prefs(context).edit().putInt(KEY_LAST_SEEN_VERSION_CODE, code).apply()

    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
