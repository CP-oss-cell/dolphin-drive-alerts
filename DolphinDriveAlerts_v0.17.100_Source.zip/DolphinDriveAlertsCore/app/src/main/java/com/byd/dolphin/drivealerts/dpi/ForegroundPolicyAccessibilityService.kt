package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.util.CoreLog
import java.lang.ref.WeakReference

/** Accessibility is used for steering-key monitoring and Home/Back dock actions, NEVER for per-app display rules. */
class ForegroundPolicyAccessibilityService : AccessibilityService() {
    private val foregroundHandler = Handler(Looper.getMainLooper())
    private var pendingForeground: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        TemporaryAppDpiController.recoverOnStartup(this)
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        }.onFailure { CoreLog.w("ACCESSIBILITY", "Key events unavailable: ${it.message}") }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        pendingForeground?.let { foregroundHandler.removeCallbacks(it) }
        val task = Runnable { TemporaryAppDpiController.onForeground(applicationContext, pkg) }
        pendingForeground = task
        foregroundHandler.postDelayed(task, 350L)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        runCatching { SteeringTripleTapDetector.onKeyEvent(this, event) }
            .onFailure { CoreLog.w("ACCESSIBILITY", "key error=${it.message}") }
        return false
    }

    override fun onInterrupt() {
        pendingForeground?.let { foregroundHandler.removeCallbacks(it) }
        pendingForeground = null
    }

    override fun onDestroy() {
        if (instanceRef?.get() === this) instanceRef = null
        onInterrupt()
        super.onDestroy()
    }

    companion object {
        @Volatile private var instanceRef: WeakReference<ForegroundPolicyAccessibilityService>? = null

        fun performGlobal(action: Int): Boolean {
            val svc = instanceRef?.get() ?: return false
            return runCatching { svc.performGlobalAction(action) }.getOrDefault(false)
        }
    }
}
