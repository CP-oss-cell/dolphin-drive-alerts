package com.byd.dolphin.drivealerts.dock

import android.content.Context

/**
 * Persistent settings for:
 * 1. After-Blow (post-drive evaporator drying)
 * 2. Cold-weather auto heating (independent toggles for steering heat, driver/passenger seat heat, HI heater + fan)
 * 3. Hot-weather auto cooling (LOW A/C + fan)
 * 4. Reverse-gear automatic hazard lights
 */
object ClimateAutomationPreferences {
    private const val PREF = "dolphin_climate_auto_prefs"

    private const val KEY_AFTERBLOW_ON = "ab_enabled"
    private const val KEY_AFTERBLOW_MIN = "ab_minutes"
    private const val KEY_AFTERBLOW_FAN = "ab_fan"

    private const val KEY_COLD_ON = "cold_enabled"
    private const val KEY_COLD_TEMP = "cold_thresh_c"
    private const val KEY_COLD_STEER = "cold_steer"
    private const val KEY_COLD_DRV_SEAT = "cold_drv_seat" // 0=off, 1=low, 2=high
    private const val KEY_COLD_PAS_SEAT = "cold_pas_seat" // 0=off, 1=low, 2=high
    private const val KEY_COLD_HEATER = "cold_heater_hi"
    private const val KEY_COLD_FAN = "cold_fan"

    private const val KEY_HOT_ON = "hot_enabled"
    private const val KEY_HOT_TEMP = "hot_thresh_c"
    private const val KEY_HOT_AC_LOW = "hot_ac_low"
    private const val KEY_HOT_FAN = "hot_fan"

    private const val KEY_REV_HAZARD = "rev_hazard_enabled"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    // After-Blow
    fun afterBlowEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_AFTERBLOW_ON, false)
    fun setAfterBlowEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_AFTERBLOW_ON, v).apply() }

    fun afterBlowMinutes(c: Context): Int = sp(c).getInt(KEY_AFTERBLOW_MIN, 3).coerceIn(1, 10)
    fun setAfterBlowMinutes(c: Context, m: Int) { sp(c).edit().putInt(KEY_AFTERBLOW_MIN, m.coerceIn(1, 10)).apply() }

    fun afterBlowFanLevel(c: Context): Int = sp(c).getInt(KEY_AFTERBLOW_FAN, 3).coerceIn(1, 7)
    fun setAfterBlowFanLevel(c: Context, f: Int) { sp(c).edit().putInt(KEY_AFTERBLOW_FAN, f.coerceIn(1, 7)).apply() }

    // Cold Weather
    fun coldAutoEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_COLD_ON, false)
    fun setColdAutoEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_COLD_ON, v).apply() }

    fun coldThresholdC(c: Context): Int = sp(c).getInt(KEY_COLD_TEMP, 10).coerceIn(0, 18)
    fun setColdThresholdC(c: Context, t: Int) { sp(c).edit().putInt(KEY_COLD_TEMP, t.coerceIn(0, 18)).apply() }

    fun coldSteeringHeat(c: Context): Boolean = sp(c).getBoolean(KEY_COLD_STEER, true)
    fun setColdSteeringHeat(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_COLD_STEER, v).apply() }

    fun coldDriverSeat(c: Context): Int = sp(c).getInt(KEY_COLD_DRV_SEAT, 2).coerceIn(0, 2)
    fun setColdDriverSeat(c: Context, lv: Int) { sp(c).edit().putInt(KEY_COLD_DRV_SEAT, lv.coerceIn(0, 2)).apply() }

    fun coldPassengerSeat(c: Context): Int = sp(c).getInt(KEY_COLD_PAS_SEAT, 0).coerceIn(0, 2)
    fun setColdPassengerSeat(c: Context, lv: Int) { sp(c).edit().putInt(KEY_COLD_PAS_SEAT, lv.coerceIn(0, 2)).apply() }

    fun coldHeaterHi(c: Context): Boolean = sp(c).getBoolean(KEY_COLD_HEATER, true)
    fun setColdHeaterHi(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_COLD_HEATER, v).apply() }

    fun coldHeaterFan(c: Context): Int = sp(c).getInt(KEY_COLD_FAN, 4).coerceIn(1, 7)
    fun setColdHeaterFan(c: Context, f: Int) { sp(c).edit().putInt(KEY_COLD_FAN, f.coerceIn(1, 7)).apply() }

    // Hot Weather
    fun hotAutoEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_HOT_ON, false)
    fun setHotAutoEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_HOT_ON, v).apply() }

    fun hotThresholdC(c: Context): Int = sp(c).getInt(KEY_HOT_TEMP, 26).coerceIn(20, 35)
    fun setHotThresholdC(c: Context, t: Int) { sp(c).edit().putInt(KEY_HOT_TEMP, t.coerceIn(20, 35)).apply() }

    fun hotAcLow(c: Context): Boolean = sp(c).getBoolean(KEY_HOT_AC_LOW, true)
    fun setHotAcLow(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_HOT_AC_LOW, v).apply() }

    fun hotAcFan(c: Context): Int = sp(c).getInt(KEY_HOT_FAN, 4).coerceIn(1, 7)
    fun setHotAcFan(c: Context, f: Int) { sp(c).edit().putInt(KEY_HOT_FAN, f.coerceIn(1, 7)).apply() }

    // Reverse Hazard
    fun reverseHazardEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_REV_HAZARD, false)
    fun setReverseHazardEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_REV_HAZARD, v).apply() }
}
