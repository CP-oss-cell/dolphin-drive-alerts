package com.byd.dolphin.drivealerts.ui

import android.os.Bundle
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.notify.TelegramNotifier
import com.byd.dolphin.drivealerts.notify.TelegramPreferences

/**
 * Telegram Bot Real-Time Notification Settings UI:
 * Bot Token, auto-discover Chat ID (/getUpdates), connection test,
 * and per-event notification toggles (Sentry + Photo, Battery Guard, Dashcam Event, Ignition).
 */
class TelegramSettingsActivity : DensityAwareActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = DashboardUi.dp(this@TelegramSettingsActivity, v)

    private fun render() {
        val accent = DashboardUi.accentColor(this)
        val screen = DashboardUi.page(
            this,
            "텔레그램 실시간 알림 봇",
            "센트리 감지·현장 사진·배터리 보호 차단·블랙박스 충격 실시간 전송",
            DashboardIcons.IconKind.SHARE,
            accent
        ) { render() }

        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "텔레그램 봇 연결 설정",
            "BotFather로 발급받은 토큰을 넣고, 봇에게 채팅을 한 번 보낸 뒤 'Chat ID 자동 찾기'를 누르세요.",
            DashboardIcons.IconKind.SHARE,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "텔레그램 실시간 알림 켜기 (ON/OFF)", TelegramPreferences.enabled(this)) {
                TelegramPreferences.setEnabled(this, it)
            })

            p.addView(DashboardUi.label(this, "Bot Token (예: 123456789:AAH...)", 13f, true))
            val tokenEdit = EditText(this).apply {
                setText(TelegramPreferences.botToken(this@TelegramSettingsActivity))
                hint = "여기에 Bot Token 붙여넣기"
                setTextColor(DashboardUi.textColor(this@TelegramSettingsActivity))
                setHintTextColor(DashboardUi.mutedColor(this@TelegramSettingsActivity))
                setSingleLine(true)
            }
            p.addView(tokenEdit, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(8)) })

            p.addView(DashboardUi.label(this, "Chat ID (숫자)", 13f, true))
            val chatEdit = EditText(this).apply {
                setText(TelegramPreferences.chatId(this@TelegramSettingsActivity))
                hint = "예: 1234567890"
                setTextColor(DashboardUi.textColor(this@TelegramSettingsActivity))
                setHintTextColor(DashboardUi.mutedColor(this@TelegramSettingsActivity))
                setSingleLine(true)
            }
            p.addView(chatEdit, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(8)) })

            val statusTv = DashboardUi.label(this, "최근 전송 상태: ${TelegramNotifier.lastResultText}", 12.5f)
            p.addView(statusTv)

            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(
                DashboardUi.action(this, "설정 저장", DashboardIcons.IconKind.CHECKLIST, DashboardUi.okColor(this)) {
                    TelegramPreferences.setBotToken(this, tokenEdit.text.toString())
                    TelegramPreferences.setChatId(this, chatEdit.text.toString())
                    Toast.makeText(this, "텔레그램 설정이 저장되었습니다.", Toast.LENGTH_SHORT).show()
                },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, dp(4), dp(4), dp(4)) }
            )
            row.addView(
                DashboardUi.action(this, "Chat ID 자동 찾기", DashboardIcons.IconKind.SEARCH_CHECK, accent) {
                    TelegramPreferences.setBotToken(this, tokenEdit.text.toString())
                    statusTv.text = "텔레그램 서버에서 최근 메시지 확인 중…"
                    TelegramNotifier.findLatestChatId(this) { ok, msg, foundId ->
                        runOnUiThread {
                            statusTv.text = msg
                            if (ok && foundId != null) {
                                chatEdit.setText(foundId)
                                TelegramPreferences.setChatId(this, foundId)
                            }
                            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(4), dp(4), 0, dp(4)) }
            )
            p.addView(row)

            p.addView(DashboardUi.action(this, "연결 테스트 메시지 보내기", DashboardIcons.IconKind.PLAY, accent) {
                TelegramPreferences.setBotToken(this, tokenEdit.text.toString())
                TelegramPreferences.setChatId(this, chatEdit.text.toString())
                statusTv.text = "테스트 메시지 전송 중…"
                TelegramNotifier.testConnection(this) { _, msg ->
                    runOnUiThread {
                        statusTv.text = msg
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    }
                }
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4) })
        })

        DashboardUi.addPanel(screen, this, DashboardUi.panel(
            this,
            "실시간 알림 항목 선택",
            "필요한 이벤트만 골라 스마트폰 텔레그램으로 즉시 받아볼 수 있습니다.",
            DashboardIcons.IconKind.CAR_ALERT,
            accent
        ) { p ->
            p.addView(DashboardUi.toggle(this, "센트리 모드 움직임 · 충격 감지 알림", TelegramPreferences.notifySentry(this)) {
                TelegramPreferences.setNotifySentry(this, it)
            })
            p.addView(DashboardUi.toggle(this, "센트리 감지 시 4방향 현장 스냅샷 사진 첨부", TelegramPreferences.notifySentryPhoto(this)) {
                TelegramPreferences.setNotifySentryPhoto(this, it)
            })
            p.addView(DashboardUi.toggle(this, "12V · 고전압 배터리 보호 차단 알림", TelegramPreferences.notifyBatteryGuard(this)) {
                TelegramPreferences.setNotifyBatteryGuard(this, it)
            })
            p.addView(DashboardUi.toggle(this, "블랙박스 충격(G-센서) · 급제동 잠금 알림", TelegramPreferences.notifyDashcamEvent(this)) {
                TelegramPreferences.setNotifyDashcamEvent(this, it)
            })
            p.addView(DashboardUi.toggle(this, "시동 ON · 주차 P 전환 상태 알림", TelegramPreferences.notifyIgnition(this)) {
                TelegramPreferences.setNotifyIgnition(this, it)
            })
        })
    }
}
