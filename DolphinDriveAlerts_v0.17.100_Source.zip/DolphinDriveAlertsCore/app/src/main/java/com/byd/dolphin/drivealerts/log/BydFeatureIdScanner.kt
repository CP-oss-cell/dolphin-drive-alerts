package com.byd.dolphin.drivealerts.log

import android.content.Context
import android.content.pm.PackageManager
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.File
import java.lang.reflect.Modifier
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 100% Read-Only BYD DiLink permission & BYDAutoFeatureIds diagnostic scanner.
 * Never invokes any setter or ECU/CAN write method. Helps pinpoint trim-specific
 * featureIds (e.g. drive mode NORMAL, BSD left/right, LDW, lead-car departure) on real cars.
 */
object BydFeatureIdScanner {
    private val BYDAUTO_PERMISSIONS = listOf(
        "android.permission.BYDAUTO_SETTING_COMMON",
        "android.permission.BYDAUTO_AC_COMMON",
        "android.permission.BYDAUTO_BODYWORK_COMMON",
        "android.permission.BYDAUTO_DOOR_LOCK_COMMON",
        "android.permission.BYDAUTO_INSTRUMENT_COMMON",
        "android.permission.BYDAUTO_LIGHT_COMMON",
        "android.permission.BYDAUTO_PANORAMA_COMMON",
        "android.permission.BYDAUTO_RADAR_COMMON"
    )

    private val DEVICE_CLASS_BY_CATEGORY = mapOf(
        "Adas" to "android.hardware.bydauto.adas.BYDAutoADASDevice",
        "ADAS" to "android.hardware.bydauto.adas.BYDAutoADASDevice",
        "DiPilot" to "android.hardware.bydauto.dipilot.BYDAutoDiPilotDevice",
        "Instrument" to "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice",
        "Setting" to "android.hardware.bydauto.setting.BYDAutoSettingDevice",
        "Gearbox" to "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
        "Energy" to "android.hardware.bydauto.energy.BYDAutoEnergyDevice",
        "Radar" to "android.hardware.bydauto.radar.BYDAutoRadarDevice",
        "Bodywork" to "android.hardware.bydauto.bodywork.BYDAutoBodyworkDevice",
        "DoorLock" to "android.hardware.bydauto.doorlock.BYDAutoDoorLockDevice",
        "Light" to "android.hardware.bydauto.light.BYDAutoLightDevice",
        "Safety" to "android.hardware.bydauto.safety.BYDAutoSafetyDevice"
    )

    data class ScanReport(
        val summary: String,
        val fullText: String,
        val savedPath: String
    )

    fun runReadOnlyScan(context: Context): ScanReport {
        val sb = StringBuilder()
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        sb.appendLine("=== BYD DiLink Read-Only Permission & FeatureId Scan ($stamp) ===")
        sb.appendLine("Policy: READ-ONLY (zero setters, zero ECU/CAN writes)")
        sb.appendLine()

        // 1. Check all 8 BYDAUTO_*_COMMON permissions
        sb.appendLine("[1] BYDAUTO_*_COMMON 권한 상태")
        var grantedCount = 0
        for (perm in BYDAUTO_PERMISSIONS) {
            val granted = runCatching {
                context.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
            }.getOrDefault(false)
            if (granted) grantedCount++
            sb.appendLine("  ${if (granted) "GRANTED" else "DENIED "} | $perm")
        }
        sb.appendLine("  -> 허용 $grantedCount / ${BYDAUTO_PERMISSIONS.size}")
        sb.appendLine()

        // 2. Reflect over android.hardware.bydauto.BYDAutoFeatureIds nested classes
        sb.appendLine("[2] BYDAutoFeatureIds 읽기 전용 전수 스캔")
        var categoriesFound = 0
        var totalIds = 0
        var readableIds = 0
        val cls = runCatching { Class.forName("android.hardware.bydauto.BYDAutoFeatureIds") }.getOrNull()
        if (cls == null) {
            sb.appendLine("  BYDAutoFeatureIds 클래스를 찾을 수 없습니다 (비-BYD 환경 또는 SDK 미탑재).")
        } else {
            val nested = cls.declaredClasses.sortedBy { it.simpleName }
            for (catClass in nested) {
                val catName = catClass.simpleName
                val fields = catClass.declaredFields.filter { f ->
                    Modifier.isStatic(f.modifiers) && f.type == Int::class.javaPrimitiveType
                }.sortedBy { it.name }
                if (fields.isEmpty()) continue
                categoriesFound++
                val devClassName = DEVICE_CLASS_BY_CATEGORY[catName]
                val device = devClassName?.let { obtainDevice(context, it) }
                val getMethod = device?.javaClass?.methods?.firstOrNull { m ->
                    (m.name == "get" || m.name == "getValue") &&
                        m.parameterTypes.size == 1 &&
                        m.parameterTypes[0] == Int::class.javaPrimitiveType
                }
                sb.appendLine("  -- Category: $catName (${fields.size} IDs, device=${device != null}, getMethod=${getMethod?.name ?: "none"}) --")
                for (f in fields) {
                    totalIds++
                    val idVal = runCatching { f.isAccessible = true; f.getInt(null) }.getOrNull() ?: continue
                    if (device != null && getMethod != null) {
                        val readRes = runCatching {
                            getMethod.invoke(device, idVal)
                        }.fold(
                            onSuccess = { v ->
                                val s = v?.toString() ?: "null"
                                if (s != "-1" && s != "null" && s != "-2147483648") readableIds++
                                s
                            },
                            onFailure = { e -> "ERR:${(e.cause ?: e).javaClass.simpleName}" }
                        )
                        sb.appendLine("    ${f.name} ($idVal) = $readRes")
                    } else {
                        sb.appendLine("    ${f.name} ($idVal) = [NO_READER]")
                    }
                }
            }
        }

        val full = sb.toString()
        val outFile = File(context.filesDir, "byd_feature_scan_latest.txt")
        val saved = runCatching {
            outFile.writeText(full, Charsets.UTF_8)
            outFile.absolutePath
        }.getOrDefault("SAVE_FAILED")

        val summary = "권한 $grantedCount/${BYDAUTO_PERMISSIONS.size} · 카테고리 ${categoriesFound}개 · ID ${totalIds}개 중 유효 응답 ${readableIds}개"
        CoreLog.i("BYD_SCAN", "$summary | saved=$saved")
        return ScanReport(summary = summary, fullText = full, savedPath = saved)
    }

    private fun obtainDevice(context: Context, className: String): Any? = runCatching {
        val c = Class.forName(className)
        val m = c.methods.firstOrNull { it.name == "getInstance" && it.parameterTypes.size == 1 }
            ?: return@runCatching null
        m.invoke(null, context.applicationContext)
    }.getOrNull()
}
