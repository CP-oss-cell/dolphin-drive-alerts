package com.byd.dolphin.drivealerts.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal

/** Launcher V1 AlarmManager fallback: only if the initial sequence service was NEVER delivered.
 *  Does not launch vehicle controllers, send CAN writes, or replay an acknowledged batch.
 */
class IgnitionSequenceAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_CHECK) return
        val prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE)
        val request=intent.getLongExtra(EXTRA_REQUEST,-1L)
        val stored=prefs.getLong("requested",-2L)
        val acknowledged=prefs.getString("acknowledged_id",null)
        val requestId=prefs.getString("request_id",null)
        val armed=context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
            .getBoolean("armed",true)
        if (request<0L || stored!=request || armed || !FeatureProfiles.sequenceEnabled(context)) {
            CoreLog.i("BOOT","AUTO_SEQUENCE_ALARM_SUPPRESSED id=$request current=$stored armed=$armed")
            return
        }
        if (requestId != null && acknowledged == requestId) {
            CoreLog.i("BOOT","AUTO_SEQUENCE_SERVICE_ACK_ALREADY_DELIVERED requested=$request ack=$acknowledged")
            return
        }
        // Keep request until matching service ACK; a dispatch acceptance is not delivery.
        if (requestId == null) {
            IgnitionAuditJournal.record(context,"ALARM_RETRY_BLOCKED","missingRequestId=true")
            return
        }
        CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_MISSING requested=$request;retry=one")
        val accepted=AutoLaunchSequenceService.start(context.applicationContext,requestId=requestId)
        IgnitionAuditJournal.record(context,"ALARM_RETRY", "accepted=$accepted ack=$acknowledged request=$request")
        if (!accepted) {
            // Delivery has definitively failed, unlike a service that was ACKed but
            // later could not launch a user app. Retain eligibility for the next ON.
            context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
                .edit().putBoolean("armed",true).commit()
            CoreLog.w("BOOT","AUTO_SEQUENCE_RETRY_REJECTED rearmed=true")
        }
    }
    companion object {
        private const val PREF="ignition_sequence_delivery_v01719"
        private const val ACTION_CHECK="com.byd.dolphin.drivealerts.IGNITION_SEQUENCE_DELIVERY_CHECK"
        private const val EXTRA_REQUEST="request_elapsed"
        private fun pending(c:Context,request:Long):PendingIntent {
            val i=Intent(c,IgnitionSequenceAlarmReceiver::class.java).setAction(ACTION_CHECK)
                .putExtra(EXTRA_REQUEST,request)
            return PendingIntent.getBroadcast(c,1719,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        fun schedule(c:Context):String? {
            val elapsed=SystemClock.elapsedRealtime()
            val id=java.util.UUID.randomUUID().toString()
            val prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            if (!prefs.edit().putLong("requested",elapsed).putString("request_id",id).remove("acknowledged_id").commit()) {
                CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_GUARD_PERSIST_FAILED")
                return null
            }
            runCatching {
                val alarm=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,elapsed+12_000L,pending(c,elapsed))
            }.onSuccess { CoreLog.i("BOOT","AUTO_SEQUENCE_DELIVERY_CHECK_SCHEDULED request=$elapsed") }
                .onFailure {
                    CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_CHECK_FAILED ${it.message}")
                    // Fail closed: no durable retry alarm means no confirmed delivery guard.
                    // The caller must re-arm rather than silently lose this ON cycle.
                    prefs.edit().putLong("requested",-1L).remove("request_id").commit()
                    return null
                }
            return id
        }
        fun acknowledge(c:Context,requestId:String?):Boolean {
            if (requestId.isNullOrBlank()) return false
            val prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            if (prefs.getString("request_id",null)!=requestId || prefs.getLong("requested",-1L)<0L) return false
            return prefs.edit().putString("acknowledged_id",requestId).putLong("requested",-1L).commit()
        }
        fun cancel(c:Context) {
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putLong("requested",-1L).remove("request_id").commit()
            val alarm=c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            alarm?.cancel(pending(c,0L))
        }
    }
}
