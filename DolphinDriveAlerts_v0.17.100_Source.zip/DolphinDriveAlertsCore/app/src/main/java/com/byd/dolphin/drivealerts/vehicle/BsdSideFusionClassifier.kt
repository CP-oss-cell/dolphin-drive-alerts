package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import com.byd.dolphin.drivealerts.camera.SharedAvmSession
import com.byd.dolphin.drivealerts.camera.BsdCameraPreferences
import com.byd.dolphin.drivealerts.camera.DashcamPreferences
import com.byd.dolphin.drivealerts.camera.BsdSideInferencePreferences
import com.byd.dolphin.drivealerts.camera.SideCameraBsdAnalyzer
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Resolves Left vs Right side for BSD_WARNING using rear/corner radar channels and/or
 * event-triggered side-camera ROI motion comparison.
 * Falls back safely to Side.UNKNOWN ("후측방 조심") whenever left/right evidence is ambiguous.
 */
class BsdSideFusionClassifier(context: Context) {
    private val app = context.applicationContext
    private val sideCam = SideCameraBsdAnalyzer(app)

    @Volatile private var lastRadarSide: Side = Side.UNKNOWN
    @Volatile private var lastRadarMs: Long = 0L
    @Volatile private var lastRadarDetail: String = "none"
    @Volatile private var lastBlinkerSide: Side = Side.UNKNOWN
    @Volatile private var lastBlinkerMs: Long = 0L
    @Volatile private var lastAvmSide: Side = Side.UNKNOWN
    @Volatile private var lastAvmMs: Long = 0L
    @Volatile private var lastAvmDetail: String = "none"

    fun accept(frame: RawVehicleFrame, blinkerSide: Side) {
        if (!BsdSideInferencePreferences.enabled(app)) {
            sideCam.stop()
            return
        }
        val isReverse = frame.gearRaw == 1
        if (isReverse) {
            sideCam.stop()
            return
        }

        val now = frame.timestampMs
        val mode = BsdSideInferencePreferences.mode(app)

        // 1. Always update rear-left vs rear-right radar evidence (zero camera overhead)
        if (mode != 2) {
            updateRearRadar(frame.radarDistances, now)
        }

        // 2. Trigger short side-camera analysis burst ONLY when BSD or blinker is active
        //    and the floating BSD camera overlay is NOT already holding Camera2.
        val blinkerActive = blinkerSide == Side.LEFT || blinkerSide == Side.RIGHT
        if (blinkerActive) {
            lastBlinkerSide = blinkerSide
            lastBlinkerMs = now
        }
        // Ultra-low-resource policy: when Dashcam is OFF, NEVER cold-open camera for BSD (use 0ms blinker + radar).
        // When Dashcam is ON, acceptSharedQuadBitmap() piggybacks on SharedAvmSession with 0 extra overhead.
    }

    private fun updateRearRadar(distances: IntArray?, now: Long) {
        if (distances == null || distances.size < 6) return
        // Standard BYD radar array: [0..3] front, [4..7] rear (or [4..5] rear L/R on 6-sensor trims)
        val (leftMin, rightMin) = if (distances.size >= 8) {
            minValid(distances[4], distances[5]) to minValid(distances[6], distances[7])
        } else {
            minValid(distances[4]) to minValid(distances[5])
        }
        val leftValid = leftMin <= 220
        val rightValid = rightMin <= 220

        val side = when {
            leftValid && !rightValid -> Side.LEFT
            rightValid && !leftValid -> Side.RIGHT
            leftValid && rightValid && (rightMin - leftMin >= 25) -> Side.LEFT
            leftValid && rightValid && (leftMin - rightMin >= 25) -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        if (side != Side.UNKNOWN) {
            lastRadarSide = side
            lastRadarMs = now
            lastRadarDetail = "rearL=${if (leftValid) "${leftMin}cm" else "-"} rearR=${if (rightValid) "${rightMin}cm" else "-"}"
        }
    }

    private fun minValid(vararg vals: Int): Int {
        var best = Int.MAX_VALUE
        for (v in vals) {
            if (v in 1..250 && v < best) best = v
        }
        return best
    }

    /** Resolve final side for an incoming BSD_WARNING alert. */
    fun resolveSide(incoming: Side): Pair<Side, String> {
        if (incoming != Side.UNKNOWN) return incoming to "oem_direct"
        if (!BsdSideInferencePreferences.enabled(app)) return Side.UNKNOWN to "disabled"

        val now = System.currentTimeMillis()
        val mode = BsdSideInferencePreferences.mode(app)
        val blinkerFresh = (now - lastBlinkerMs <= 2_500L) && lastBlinkerSide != Side.UNKNOWN
        val radarFresh = (now - lastRadarMs <= 1_800L) && lastRadarSide != Side.UNKNOWN
        val avmFresh = (now - lastAvmMs <= 1_800L) && lastAvmSide != Side.UNKNOWN
        val (legacyCamSide, legacyCamDetail) = sideCam.recentSide(now, 2_500L)
        val camSide = if (avmFresh) lastAvmSide else legacyCamSide
        val camDetail = if (avmFresh) "AVM($lastAvmDetail)" else legacyCamDetail
        val camFresh = camSide != Side.UNKNOWN
        if (blinkerFresh) {
            val res = lastBlinkerSide to "BLINKER_DIRECT(${if (camFresh && camSide == lastBlinkerSide) "CAM_AGREE" else "0ms"})"
            CoreLog.i("BSD_SIDE", "resolved=${res.first} detail=${res.second}")
            return res
        }

        val result: Pair<Side, String> = when (mode) {
            1 -> if (radarFresh) lastRadarSide to "REAR_SENSOR($lastRadarDetail)" else Side.UNKNOWN to "REAR_SENSOR_NONE"
            2 -> if (camFresh) camSide to "SIDE_CAMERA($camDetail)" else Side.UNKNOWN to "SIDE_CAMERA_NONE"
            else -> when {
                radarFresh && camFresh && lastRadarSide == camSide ->
                    lastRadarSide to "FUSION_AGREE($lastRadarDetail;$camDetail)"
                radarFresh ->
                    lastRadarSide to "REAR_SENSOR($lastRadarDetail)"
                camFresh ->
                    camSide to "SIDE_CAMERA($camDetail)"
                else ->
                    Side.UNKNOWN to "UNKNOWN_FALLBACK"
            }
        }
        CoreLog.i("BSD_SIDE", "resolved=${result.first} detail=${result.second}")
        return result
    }

    /** Receive shared YUV frame from VehicleCameraHub when dashcam is active (zero extra camera open). */
    /** Receive shared 320x240 quad bitmap from SharedAvmSession when Dashcam is ON (0ms overhead). */
    fun acceptSharedQuadBitmap(bmp: Bitmap) {
        if (!BsdSideInferencePreferences.enabled(app) || BsdSideInferencePreferences.mode(app) == 1) return
        val (side, detail) = SharedAvmSession.compareLeftRightEnergy(bmp)
        if (side != Side.UNKNOWN) {
            lastAvmSide = side
            lastAvmMs = System.currentTimeMillis()
            lastAvmDetail = detail
        }
    }

    fun acceptSharedFrame(img: Image) {
        if (!BsdSideInferencePreferences.enabled(app)) return
        if (BsdSideInferencePreferences.mode(app) == 1) return
        sideCam.acceptExternalImage(img)
    }

    fun shutdown() {
        sideCam.stop()
    }
}
