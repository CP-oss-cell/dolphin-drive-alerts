package com.byd.dolphin.drivealerts.config

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.File

/**
 * One-tap full app settings backup & restore (JSON) across all preference domains.
 * Saves to Downloads/DolphinDriveSettings_backup.json (and app-private fallback).
 */
object SettingsBackupManager {
    private val PREF_NAMES = listOf(
        "drive_alert_core",
        "audio_tuning",
        "dolphin_dashcam",
        "bsd_camera_overlay",
        "lead_car_departure_fusion",
        "bsd_side_fusion",
        "dolphin_ui_theme",
        "dolphin_floating_dock_prefs",
        "dolphin_sentry_prefs",
        "dolphin_telegram_prefs",
        "dolphin_climate_auto_prefs",
        "dolphin_split_sequence_v013",
        "ignition_off_user_apps_v1",
        "global_orientation_mode_v0169",
        "steering_one_shot"
    )
    private const val FILE_NAME = "DolphinDriveSettings_backup.json"

    fun exportToJson(context: Context): Result<String> = runCatching {
        val root = JSONObject()
        root.put("schema", "dolphin_drive_settings_v1")
        root.put("exportedAtMs", System.currentTimeMillis())
        val prefsObj = JSONObject()
        for (name in PREF_NAMES) {
            val sp = context.getSharedPreferences(name, Context.MODE_PRIVATE)
            val entries = JSONObject()
            for ((k, v) in sp.all) {
                val item = JSONObject()
                when (v) {
                    is Boolean -> { item.put("t", "b"); item.put("v", v) }
                    is Int -> { item.put("t", "i"); item.put("v", v) }
                    is Long -> { item.put("t", "l"); item.put("v", v) }
                    is Float -> { item.put("t", "f"); item.put("v", v.toDouble()) }
                    is String -> { item.put("t", "s"); item.put("v", v) }
                }
                if (item.has("t")) entries.put(k, item)
            }
            prefsObj.put(name, entries)
        }
        root.put("prefs", prefsObj)
        val payload = root.toString(2)

        // Always keep an app-private copy for instant restore
        val local = File(context.filesDir, FILE_NAME)
        local.writeText(payload, Charsets.UTF_8)

        // Also export to public Downloads on Android 10+
        var location = local.absolutePath
        if (Build.VERSION.SDK_INT >= 29) {
            runCatching {
                val resolver = context.contentResolver
                val cv = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, FILE_NAME)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    location = "Downloads/$FILE_NAME"
                }
            }
        }
        CoreLog.i("BACKUP", "Settings exported -> $location")
        location
    }

    fun importFromLatestBackup(context: Context): Result<Int> = runCatching {
        val local = File(context.filesDir, FILE_NAME)
        val text = when {
            Build.VERSION.SDK_INT >= 29 -> readLatestDownload(context) ?: if (local.isFile) local.readText(Charsets.UTF_8) else null
            local.isFile -> local.readText(Charsets.UTF_8)
            else -> null
        } ?: error("백업 파일($FILE_NAME)을 찾을 수 없습니다. 먼저 '설정 백업'을 실행하세요.")

        val root = JSONObject(text)
        val prefsObj = root.getJSONObject("prefs")
        var restoredCount = 0
        for (name in PREF_NAMES) {
            if (!prefsObj.has(name)) continue
            val entries = prefsObj.getJSONObject(name)
            val ed = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit()
            val keys = entries.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val item = entries.getJSONObject(k)
                when (item.optString("t")) {
                    "b" -> { ed.putBoolean(k, item.getBoolean("v")); restoredCount++ }
                    "i" -> { ed.putInt(k, item.getInt("v")); restoredCount++ }
                    "l" -> { ed.putLong(k, item.getLong("v")); restoredCount++ }
                    "f" -> { ed.putFloat(k, item.getDouble("v").toFloat()); restoredCount++ }
                    "s" -> { ed.putString(k, item.getString("v")); restoredCount++ }
                }
            }
            ed.commit()
        }
        CoreLog.i("BACKUP", "Settings restored entries=$restoredCount")
        restoredCount
    }

    private fun readLatestDownload(context: Context): String? {
        if (Build.VERSION.SDK_INT < 29) return null
        return runCatching {
            val col = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.MediaColumns._ID)
            val sel = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            val args = arrayOf("DolphinDriveSettings_backup%.json")
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            context.contentResolver.query(col, proj, sel, args, sort)?.use { c ->
                if (c.moveToFirst()) {
                    val uri = android.content.ContentUris.withAppendedId(col, c.getLong(0))
                    context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText()
                } else null
            }
        }.getOrNull()
    }
}
