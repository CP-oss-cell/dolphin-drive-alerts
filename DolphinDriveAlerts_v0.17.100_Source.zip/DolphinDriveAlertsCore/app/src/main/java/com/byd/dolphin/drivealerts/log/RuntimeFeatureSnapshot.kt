package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.config.AlertVolume
import com.byd.dolphin.drivealerts.dpi.ThirdPartyDpiRules
import com.byd.dolphin.drivealerts.dpi.SelfAppDensity
import com.byd.dolphin.drivealerts.model.AlertEventCatalog
import com.byd.dolphin.drivealerts.automation.FeatureProfiles
import org.json.JSONArray
import org.json.JSONObject

/** Evidence-safe settings inventory stored inside the user's session ZIP.
 * No OEM binder, CAN, audio routing, ADB write, or privileged setting changes.
 * An enabled preference is NEVER interpreted as a functioning vehicle feature.
 */
object RuntimeFeatureSnapshot {
    fun collect(context: Context): JSONObject {
        val alerts = JSONArray()
        for (item in AlertEventCatalog.entries) {
            alerts.put(JSONObject()
                .put("event", item.event.name)
                .put("label", item.event.phrase)
                .put("audioEnabledByUser", AlertPreferences.eventEnabled(context, item.event))
                .put("evidence", item.evidence.name))
        }
        return JSONObject()
            .put("schema", "dolphin-feature-runtime-v1")
            .put("capturedAtMs", System.currentTimeMillis())
            .put("readOnly", true)
            .put("carSignalOrAudioRouteVerified", false)
            .put("alertMasterEnabled", AlertPreferences.isEnabled(context))
            .put("autoStartEnabled", AlertPreferences.autoStartEnabled(context))
            .put("sequenceEnabled", FeatureProfiles.sequenceEnabled(context))
            .put("sequenceEnabledStepCount", FeatureProfiles.steps(context).count { it.enabled })
            .put("ignitionSequenceArmed", context.getSharedPreferences("ignition_sequence_guard", Context.MODE_PRIVATE).getBoolean("armed",true))
            .put("selfAppDpi", SelfAppDensity.selected(context))
            .put("normalNoticeExperimentalEnabled", AlertPreferences.normalNoticeCandidateEnabled(context))
            .put("alertVolumeTier", AlertVolume.tier(context))
            .put("alertVolumeLabel", AlertVolume.labels[AlertVolume.tier(context)])
            .put("thirdPartyDpiAutoEnabled", ThirdPartyDpiRules.enabled(context))
            .put("thirdPartyDpiRules", ThirdPartyDpiRules.summary(context))
            .put("alertEvents", alerts)
            .put("knownLimitations", JSONArray(listOf(
                "NORMAL_STANDALONE_RAW_UNVERIFIED",
                "BSD_HAZARD_LEFT_RIGHT_NOT_CORROBORATED",
                "NAV_THIRD_PARTY_ORIGINAL_MEDIA_NOT_MUTED",
                "SPLIT_RATIO_REALCAR_NOT_VERIFIED",
                "THIRD_PARTY_TRUE_ISOLATED_DPI_NOT_AVAILABLE_TEMPORARY_GLOBAL_RULES_ONLY",
                "ADAS_LEAD_LANE_DOOR_NOT_VERIFIED",
                "AVAS_CUSTOM_PCM_NOT_IMPLEMENTED"
            )))
            .put("note", "This is preference and developer evidence metadata, NOT a live vehicle feature verification.")
    }
}
