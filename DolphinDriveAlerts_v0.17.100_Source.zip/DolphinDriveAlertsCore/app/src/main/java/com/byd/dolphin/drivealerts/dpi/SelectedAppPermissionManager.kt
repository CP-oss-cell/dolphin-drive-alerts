package com.byd.dolphin.drivealerts.dpi

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** User-requested ADB permissions for an explicitly selected installed app (v0.17.82 fixed & expanded). */
object SelectedAppPermissionManager {
    enum class Action {
        BATTERY, OVERLAY, CAMERA, STORAGE, NOTIFICATION_POST, NOTIFICATION_ACCESS,
        ACCESSIBILITY, USAGE_STATS, LOCATION_FOREGROUND, LOCATION_BACKGROUND, LOCATION_SERVICE
    }
    data class Result(val lines: List<String>, val okCount: Int, val attempted: Int)

    fun process(context: Context, packageName: String, actions: Set<Action>, configure: Boolean): Result {
        val app = context.applicationContext
        val lines = mutableListOf<String>()
        if (!AppPermissionRules.packageAllowed(packageName)) return Result(listOf("잘못된 앱 패키지"), 0, 0)
        if (runCatching { app.packageManager.getApplicationInfo(packageName, 0) }.isFailure)
            return Result(listOf("설치되지 않은 앱: $packageName"), 0, 0)
        if (actions.isEmpty()) return Result(listOf("권한 항목을 하나 이상 선택하세요"), 0, 0)

        var connection = AuthorizedAdbRuntime.awaitReady(app, maxWaitMs = if (configure) 12_000L else 5_000L)
        if (!connection.result.success) {
            // One retry after explicit handshake refresh
            runCatching { AuthorizedAdbRuntime.health(app) }
            connection = AuthorizedAdbRuntime.awaitReady(app, maxWaitMs = 6_000L)
        }
        if (!connection.result.success) {
            return Result(
                listOf(
                    "로컬 ADB 연결 실패 (${connection.state}): ${connection.result.message}",
                    "권한·ADB 메뉴에서 [차량 로컬 ADB 연결 및 RSA 승인]을 먼저 완료한 뒤 다시 시도하세요."
                ),
                0,
                actions.size
            )
        }

        fun exec(cmd: String) = NativeAdbClient.executeShell(app, cmd, timeoutMs = 6_500L)
        var ok = 0
        fun check(action: Action, write: String?, read: String, verify: (String) -> Boolean, suffix: String = "") {
            if (configure && write != null) {
                val r = exec(write)
                if (!r.success) {
                    lines += "✗ ${action.name}: 적용 거부 (${r.output.trim().ifEmpty { r.message }.take(80)})"
                    return
                }
            }
            val r = exec(read)
            val pass = r.success && verify(r.output)
            if (pass) ok++
            lines += "${if (pass) "✓" else "✗"} ${action.name}: ${if (pass) "허용 확인됨" else "미허용/거부"} $suffix"
        }

        val pm = app.packageManager
        val requested = runCatching {
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet().orEmpty()
        }.getOrDefault(emptySet())

        fun services(actionName: String): List<String> = pm.queryIntentServices(Intent(actionName).setPackage(packageName), 0)
            .mapNotNull { it.serviceInfo?.let { info -> ComponentName(info.packageName, info.name).flattenToString() } }
            .filter { AppPermissionRules.serviceAllowed(it) }.distinct().sorted()

        for (action in Action.entries) {
            if (action !in actions) continue
            when (action) {
                Action.BATTERY -> {
                    if (configure) {
                        exec("appops set $packageName RUN_IN_BACKGROUND allow")
                        exec("appops set $packageName RUN_ANY_IN_BACKGROUND allow")
                    }
                    check(action, AppPermissionRules.batteryCommand(packageName), "dumpsys deviceidle whitelist", { it.contains(packageName) })
                }
                Action.OVERLAY -> {
                    check(action, AppPermissionRules.overlayCommand(packageName), "appops get $packageName SYSTEM_ALERT_WINDOW", {
                        it.contains("allow", true) && !it.contains("ignore", true)
                    })
                }
                Action.CAMERA -> {
                    if ("android.permission.CAMERA" !in requested) {
                        lines += "- CAMERA: 앱에 CAMERA 권한 선언 없음"
                    } else {
                        if (configure) exec("pm grant $packageName android.permission.BYD_CAMERA")
                        check(action, AppPermissionRules.cameraGrantCommand(packageName), "dumpsys package $packageName", {
                            AppPermissionRules.hasGrantedPermission(it, "android.permission.CAMERA")
                        })
                    }
                }
                Action.STORAGE -> {
                    val perms = listOf("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE")
                        .filter { it in requested }
                    if (perms.isEmpty()) {
                        lines += "- STORAGE: 앱에 저장소 권한 선언 없음"
                    } else {
                        if (configure) perms.forEach { exec(AppPermissionRules.storageGrantCommand(packageName, it)) }
                        val rb = exec("dumpsys package $packageName")
                        val granted = rb.success && perms.all { AppPermissionRules.hasGrantedPermission(rb.output, it) }
                        if (granted) ok++
                        lines += "${if (granted) "✓" else "✗"} STORAGE: ${if (granted) "저장소 읽기/쓰기 확인" else "미허용/거부"}"
                    }
                }
                Action.NOTIFICATION_POST -> {
                    if (Build.VERSION.SDK_INT < 33 || "android.permission.POST_NOTIFICATIONS" !in requested) {
                        ok++
                        lines += "✓ NOTIFICATION_POST: Android 10에서는 별도 부여 불필요(기본 허용)"
                    } else check(action, AppPermissionRules.grantNotificationCommand(packageName), "dumpsys package $packageName", {
                        AppPermissionRules.hasGrantedPermission(it, "android.permission.POST_NOTIFICATIONS")
                    })
                }
                Action.NOTIFICATION_ACCESS -> {
                    val list = services("android.service.notification.NotificationListenerService")
                    if (list.isEmpty()) {
                        lines += "- NOTIFICATION_ACCESS: 앱에 알림 리스너 서비스 없음"
                    } else {
                        val component = list.first()
                        if (configure) {
                            val r1 = exec(AppPermissionRules.notificationListenerCommand(component))
                            if (!r1.success) {
                                val cur = exec("settings get secure enabled_notification_listeners")
                                if (cur.success) {
                                    val merged = AppPermissionRules.addColonService(cur.output, component)
                                    exec(AppPermissionRules.notificationListenerMergedCommand(merged))
                                }
                            }
                        }
                        check(action, null, "settings get secure enabled_notification_listeners", {
                            it.split(':').map(String::trim).contains(component)
                        }, "($component)")
                    }
                }
                Action.ACCESSIBILITY -> {
                    val list = services("android.accessibilityservice.AccessibilityService")
                    if (list.isEmpty()) {
                        lines += "- ACCESSIBILITY: 앱에 접근성 서비스 없음"
                    } else {
                        val component = list.first()
                        val current = exec("settings get secure enabled_accessibility_services")
                        if (!current.success) {
                            lines += "✗ ACCESSIBILITY: 기존 서비스 목록 조회 실패"
                            continue
                        }
                        val merged = AppPermissionRules.addAccessibilityService(current.output, component)
                        if (configure) {
                            val r = exec(AppPermissionRules.accessibilityCommand(merged))
                            if (r.success) exec("settings put secure accessibility_enabled 1")
                            else {
                                lines += "✗ ACCESSIBILITY: 적용 거부 (${r.message})"
                                continue
                            }
                        }
                        check(action, null, "settings get secure enabled_accessibility_services", {
                            it.split(':').map(String::trim).contains(component)
                        }, "($component)")
                    }
                }
                Action.USAGE_STATS -> check(action, AppPermissionRules.usageStatsCommand(packageName), "appops get $packageName GET_USAGE_STATS", {
                    it.contains("allow", true) && !it.contains("ignore", true)
                })
                Action.LOCATION_FOREGROUND -> {
                    val permissions = listOf("android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION")
                        .filter { it in requested }
                    if (permissions.isEmpty()) {
                        lines += "- LOCATION_FOREGROUND: 앱에 위치 권한 선언 없음"
                    } else {
                        if (configure) permissions.forEach { exec(AppPermissionRules.locationGrantCommand(packageName, it)) }
                        val rb = exec("dumpsys package $packageName")
                        val granted = rb.success && permissions.all { AppPermissionRules.hasGrantedPermission(rb.output, it) }
                        if (granted) ok++
                        lines += "${if (granted) "✓" else "✗"} LOCATION_FOREGROUND: ${if (granted) "허용 확인됨" else "미허용/거부"}"
                    }
                }
                Action.LOCATION_BACKGROUND -> {
                    val permission = "android.permission.ACCESS_BACKGROUND_LOCATION"
                    if (permission !in requested) {
                        lines += "- LOCATION_BACKGROUND: 앱에 백그라운드 위치 선언 없음"
                    } else {
                        if (configure) {
                            listOf("android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION")
                                .filter { it in requested }
                                .forEach { exec(AppPermissionRules.locationGrantCommand(packageName, it)) }
                            exec(AppPermissionRules.locationGrantCommand(packageName, permission))
                        }
                        val rb = exec("dumpsys package $packageName")
                        val granted = rb.success && AppPermissionRules.hasGrantedPermission(rb.output, permission)
                        if (granted) ok++
                        lines += "${if (granted) "✓" else "✗"} LOCATION_BACKGROUND: ${if (granted) "항상 허용 확인됨" else "미허용/거부"}"
                    }
                }
                Action.LOCATION_SERVICE -> {
                    val before = exec(AppPermissionRules.locationReadCommand())
                    val beforeOn = if (before.success) AppPermissionRules.locationEnabledReadback(before.output) else null
                    if (configure && beforeOn != true) {
                        exec(AppPermissionRules.locationEnableCommand())
                    }
                    val rb = exec(AppPermissionRules.locationReadCommand())
                    val res = if (rb.success) AppPermissionRules.locationEnabledReadback(rb.output) else null
                    if (res == true) ok++
                    lines += "${if (res == true) "✓" else "✗"} LOCATION_SERVICE: ${if (res == true) "차량 전체 위치 ON 확인" else "OFF 또는 확인 불가"}"
                }
            }
        }
        lines += "완료: $ok / ${actions.size}개 권한 확인됨"
        return Result(lines, ok, actions.size)
    }
}
