package com.byd.dolphin.drivealerts.audio

import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Precision 10-band + 3-band + acoustic spatial/sound-focus tone curve.
 * Fixes EQ loudness drop via smart limiter-backed headroom compensation.
 */
object EqToneCurve {
    fun userBandDb(s: EqSettings, steps: Int): Float {
        val dbPerStep = when (s.impactLevel.coerceIn(0, 2)) { 1 -> 0.8f; 2 -> 1.0f; else -> 0.6f }
        val multiplier = if (s.subtleBoost) 1.12f else 1f
        return (steps.coerceIn(-10, 10) * dbPerStep * multiplier).coerceIn(-10f, 10f)
    }

    fun gainDb(s: EqSettings, hz: Int): Float {
        val bass = userBandDb(s, s.bass)
        val mid = userBandDb(s, s.mid)
        val treble = userBandDb(s, s.treble)
        val basic = when {
            hz <= 125 -> bass
            hz < 500 -> crossfade(bass, mid, hz, 125, 500)
            hz <= 2000 -> mid
            hz < 8000 -> crossfade(mid, treble, hz, 2000, 8000)
            else -> treble
        }
        val fine10 = interpolateBand10(s.band10, hz)
        // Audible, studio-grade acoustic contours that work even on car speakers without Virtualizer support
        val focusContour = when (s.soundFocus) {
            SoundFocusMode.REFERENCE -> 0f
            SoundFocusMode.SURROUND -> surroundContour(hz)
            SoundFocusMode.CINEMA -> cinemaContour(hz)
        }
        val spatialContour = if (s.centerpoint360 && s.spatialStrength > 0) {
            val amt = s.spatialStrength.coerceIn(0, 100) / 100f
            // Clear cabin muddiness at 250Hz, lift vocal presence (2.5-4kHz) and air (10-16kHz)
            when {
                hz <= 100 -> 1.4f * amt
                hz < 350 -> crossfade(1.4f * amt, -1.6f * amt, hz, 100, 350)
                hz < 2500 -> crossfade(-1.6f * amt, 2.2f * amt, hz, 350, 2500)
                hz < 8000 -> crossfade(2.2f * amt, 2.8f * amt, hz, 2500, 8000)
                else -> 3.0f * amt
            }
        } else 0f

        return (basic + fine10 + focusContour + spatialContour).coerceIn(-12.0f, 12.0f)
    }

    private fun surroundContour(hz: Int): Float = when {
        hz <= 80 -> 2.2f
        hz < 280 -> crossfade(2.2f, -1.8f, hz, 80, 280)
        hz < 1800 -> crossfade(-1.8f, 1.5f, hz, 280, 1800)
        hz < 6000 -> crossfade(1.5f, 3.0f, hz, 1800, 6000)
        else -> 3.2f
    }

    private fun cinemaContour(hz: Int): Float = when {
        hz <= 90 -> 4.2f
        hz < 320 -> crossfade(4.2f, -1.4f, hz, 90, 320)
        hz < 2200 -> crossfade(-1.4f, 2.2f, hz, 320, 2200)
        hz < 7000 -> crossfade(2.2f, 1.4f, hz, 2200, 7000)
        else -> 1.6f
    }

    private fun interpolateBand10(bands: List<Int>, hz: Int): Float {
        if (bands.size < 10) return 0f
        val freqs = EqPreferences.BAND10_HZ
        if (hz <= freqs.first()) return bands.first().toFloat()
        if (hz >= freqs.last()) return bands.last().toFloat()
        for (i in 0 until freqs.size - 1) {
            if (hz in freqs[i]..freqs[i + 1]) {
                return crossfade(bands[i].toFloat(), bands[i + 1].toFloat(), hz, freqs[i], freqs[i + 1])
            }
        }
        return 0f
    }

    private fun crossfade(a: Float, b: Float, hz: Int, lo: Int, hi: Int): Float {
        val x = ((ln(hz.toDouble()) - ln(lo.toDouble())) /
            (ln(hi.toDouble()) - ln(lo.toDouble()))).toFloat().coerceIn(0f, 1f)
        val smooth = x * x * (3f - 2f * x)
        return a + (b - a) * smooth
    }

    /**
     * Smart loudness-preserving input gain:
     * When Limiter is ON, applies gentle 35% peak trim + user Makeup Gain (default +2.0 dB)
     * so turning EQ ON never drops perceived volume while Limiter prevents digital clipping.
     */
    fun headroomDb(s: EqSettings, frequencies: IntArray): Float {
        val peak = (frequencies.maxOfOrNull { gainDb(s, it) } ?: 0f).coerceAtLeast(0f)
        return if (s.limiterEnabled) {
            (-peak * 0.35f + s.makeupGainDb).coerceIn(-6.0f, 4.5f)
        } else {
            (-peak * 0.80f + s.makeupGainDb * 0.5f).coerceIn(-10.0f, 2.0f)
        }
    }

    /** Per-channel L/R stage balance offset in dB (channel 0 = Left, channel 1 = Right). */
    fun channelBalanceDb(s: EqSettings, channelIndex: Int): Float {
        val b = s.balanceLr.coerceIn(-10, 10)
        if (b == 0) return 0f
        // Attenuate opposite channel up to -6.0 dB for crisp driver/passenger soundstage focus
        return when {
            b < 0 && channelIndex == 1 -> b * 0.6f // Shift toward Left (Driver)
            b > 0 && channelIndex == 0 -> -b * 0.6f // Shift toward Right
            else -> 0f
        }
    }

    fun virtualizerStrength(s: EqSettings): Short {
        val multiplier = when {
            s.centerpoint360 && s.soundFocus == SoundFocusMode.CINEMA -> 1.3f
            s.centerpoint360 && s.soundFocus == SoundFocusMode.SURROUND -> 1.15f
            s.centerpoint360 -> 1.0f
            s.soundFocus == SoundFocusMode.CINEMA -> 0.9f
            s.soundFocus == SoundFocusMode.SURROUND -> 0.7f
            else -> 0f
        }
        return (s.spatialStrength.coerceIn(0, 100) * 10f * multiplier)
            .roundToInt().coerceIn(0, 1000).toShort()
    }
}
