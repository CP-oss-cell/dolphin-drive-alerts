package com.byd.dolphin.drivealerts.sentry

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import kotlin.math.sin

/**
 * Pure Android Canvas Tesla/LinkLock-style Fullscreen Sentry Warning Screen (0 KB GIF overhead).
 * Displays a pulsing crimson optical iris ring + "SENTRY MODE · 녹화 중" deterrence visual
 * for 12 seconds (or until tapped).
 */
class SentryWarningActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val autoDismiss = Runnable { finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        val reason = intent.getStringExtra(EXTRA_REASON) ?: "주변 움직임 감지"
        val durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 12_000L).coerceIn(3_000L, 30_000L)
        val view = SentryIrisView(this, reason).apply {
            setOnClickListener { finish() }
        }
        setContentView(view)
        handler.postDelayed(autoDismiss, durationMs)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoDismiss)
        super.onDestroy()
    }

    private class SentryIrisView(context: Context, private val reason: String) : View(context) {
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFF6B6B.toInt()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF94A3B8.toInt()
            textAlign = Paint.Align.CENTER
        }
        private val startMs = System.currentTimeMillis()

        override fun onDraw(canvas: Canvas) {
            canvas.drawColor(0xFF04070D.toInt())
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val cx = w * 0.5f
            val cy = h * 0.44f
            val t = (System.currentTimeMillis() - startMs) / 1000.0
            val pulse = (0.5 + 0.5 * sin(t * 4.2)).toFloat()
            val baseR = minOf(w, h) * 0.22f

            // Outer pulsing crimson glow
            corePaint.shader = RadialGradient(
                cx, cy, baseR * (1.55f + 0.2f * pulse),
                intArrayOf(0xAAFF1E3C.toInt(), 0x33FF1E3C.toInt(), 0x00000000),
                floatArrayOf(0.25f, 0.65f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, baseR * (1.55f + 0.2f * pulse), corePaint)
            corePaint.shader = null

            // Outer dark metallic housing
            corePaint.color = 0xFF0D1422.toInt()
            canvas.drawCircle(cx, cy, baseR, corePaint)

            // Crisp pulsing outer ring
            ringPaint.color = 0xFFFF2442.toInt()
            ringPaint.strokeWidth = baseR * 0.08f
            canvas.drawCircle(cx, cy, baseR * 0.96f, ringPaint)

            // Inner lens ring
            ringPaint.color = 0xCC38D9E6.toInt()
            ringPaint.strokeWidth = baseR * 0.035f
            canvas.drawCircle(cx, cy, baseR * 0.58f, ringPaint)

            // Crimson optical iris core
            corePaint.color = 0xFFFF2442.toInt()
            canvas.drawCircle(cx, cy, baseR * (0.28f + 0.05f * pulse), corePaint)
            corePaint.color = Color.WHITE
            canvas.drawCircle(cx - baseR * 0.1f, cy - baseR * 0.1f, baseR * 0.07f, corePaint)

            // Text readouts
            titlePaint.textSize = h * 0.068f
            canvas.drawText("SENTRY MODE · 녹화 중", cx, cy + baseR * 1.48f, titlePaint)
            subPaint.textSize = h * 0.042f
            canvas.drawText("● REC  $reason · 4방향 감시 작동 중", cx, cy + baseR * 1.88f, subPaint)
            hintPaint.textSize = h * 0.028f
            canvas.drawText("화면을 터치하면 경고 화면이 닫힙니다", cx, h * 0.94f, hintPaint)

            postInvalidateDelayed(45L)
        }
    }

    companion object {
        const val EXTRA_REASON = "reason"
        const val EXTRA_DURATION_MS = "duration_ms"

        fun launch(context: Context, reason: String, durationMs: Long = 12_000L) {
            runCatching {
                context.startActivity(
                    Intent(context, SentryWarningActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra(EXTRA_REASON, reason)
                        putExtra(EXTRA_DURATION_MS, durationMs)
                    }
                )
            }
        }
    }
}
