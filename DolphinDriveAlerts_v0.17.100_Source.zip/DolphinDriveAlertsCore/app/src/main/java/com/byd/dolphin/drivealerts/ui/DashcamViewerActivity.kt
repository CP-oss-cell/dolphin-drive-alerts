package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import com.byd.dolphin.drivealerts.camera.VehicleCameraHub
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/** In-app Dashcam Video Player + Synchronized Telemetry + WebView Street Map + Kakao/Naver Map Links. */
class DashcamViewerActivity : DensityAwareActivity() {
    private lateinit var hub: VehicleCameraHub
    private lateinit var videoView: VideoView
    private lateinit var telemetryInfo: TextView
    private lateinit var mapWebView: WebView
    private lateinit var listContainer: LinearLayout
    private var showingEvents = false
    private var currentPts: List<Pair<Double, Double>> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hub = VehicleCameraHub(applicationContext)

        val scroll = ScrollView(this).apply { setBackgroundColor(DashboardUi.bgColor(this@DashcamViewerActivity)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(DashboardUi.dp(this@DashcamViewerActivity, 16), DashboardUi.dp(this@DashcamViewerActivity, 12),
                DashboardUi.dp(this@DashcamViewerActivity, 16), DashboardUi.dp(this@DashcamViewerActivity, 24))
        }
        scroll.addView(root)
        DashboardUi.mount(this, scroll, "녹화 영상 · 주행 궤적 뷰어", "일반 / 이벤트 보호 · 실시간 지도 · 카카오맵/네이버지도 연동")

        val accent = DashboardUi.accentColor(this)

        val playerPanel = DashboardUi.panel(
            this,
            "영상 재생 · GPS 주행 궤적 지도",
            "MP4를 선택하면 영상과 동기화된 속도·기어·브레이크 정보 및 실제 도로 지도에 주행 경로가 표시됩니다.",
            DashboardIcons.IconKind.PLAY,
            accent
        ) { p ->
            val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            videoView = VideoView(this).apply {
                setMediaController(MediaController(this@DashcamViewerActivity))
            }
            mapWebView = WebView(this).apply {
                setBackgroundColor(0xFF0D1626.toInt())
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = WebViewClient()
            }
            topRow.addView(videoView, LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 260), 1.35f).apply {
                setMargins(0, 0, DashboardUi.dp(this@DashcamViewerActivity, 8), 0)
            })
            topRow.addView(mapWebView, LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 260), 1f))
            p.addView(topRow)

            telemetryInfo = DashboardUi.label(this, "재생할 녹화 파일을 선택하세요.", 13f, true)
            p.addView(telemetryInfo)

            val mapBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            mapBtns.addView(
                DashboardUi.action(this, "카카오맵에서 위치 열기", DashboardIcons.IconKind.NAV_ARROW, 0xFFFEE500.toInt()) {
                    openExternalMap(kakao = true)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 46), 1f).apply {
                    rightMargin = DashboardUi.dp(this@DashcamViewerActivity, 6)
                }
            )
            mapBtns.addView(
                DashboardUi.action(this, "네이버 지도에서 위치 열기", DashboardIcons.IconKind.NAV_ARROW, 0xFF03C75A.toInt()) {
                    openExternalMap(kakao = false)
                },
                LinearLayout.LayoutParams(0, DashboardUi.dp(this@DashcamViewerActivity, 46), 1f)
            )
            p.addView(mapBtns, LinearLayout.LayoutParams(-1, -2).apply { topMargin = DashboardUi.dp(this@DashcamViewerActivity, 6) })
            renderLeafletMap(emptyList())
        }
        playerPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, playerPanel)

        val listPanel = DashboardUi.panel(
            this,
            "녹화 파일 목록",
            "이벤트 보호 폴더의 파일은 일반 순환 삭제에서 보호됩니다.",
            DashboardIcons.IconKind.DIAG_LOG,
            DashboardUi.okColor(this)
        ) { p ->
            p.addView(DashboardUi.segmentedBar(this, listOf("일반 녹화 (normal)", "이벤트 보호 (event)"), 0, accent) { idx ->
                showingEvents = (idx == 1)
                reloadList()
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, DashboardUi.dp(this@DashcamViewerActivity, 4), 0, DashboardUi.dp(this@DashcamViewerActivity, 8)) })
            listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            p.addView(listContainer)
        }
        listPanel.tag = "DOLPHIN_DASH_PANEL"
        DashboardUi.addPanel(root, this, listPanel)

        reloadList()
    }

    private fun openExternalMap(kakao: Boolean) {
        val pt = currentPts.lastOrNull()
        if (pt == null) {
            Toast.makeText(this, "선택한 영상에 GPS 좌표가 없습니다.", Toast.LENGTH_SHORT).show()
            return
        }
        val (lat, lon) = pt
        val appUri = if (kakao) {
            Uri.parse("kakaomap://look?p=$lat,$lon")
        } else {
            Uri.parse("nmap://place?lat=$lat&lng=$lon&name=주행기록&appname=$packageName")
        }
        val webUri = if (kakao) {
            Uri.parse("https://map.kakao.com/link/map/주행위치,$lat,$lon")
        } else {
            Uri.parse("https://map.naver.com/v5/?c=$lon,$lat,15,0,0,0,dh")
        }
        val launched = runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, appUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.getOrDefault(false)
        if (!launched) {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, webUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private fun renderLeafletMap(pts: List<Pair<Double, Double>>) {
        currentPts = pts
        val coordsJson = JSONArray().apply {
            pts.forEach { (la, lo) -> put(JSONArray().apply { put(la); put(lo) }) }
        }.toString()
        val centerLat = pts.lastOrNull()?.first ?: 37.5665
        val centerLon = pts.lastOrNull()?.second ?: 126.9780
        val html = """
            <!DOCTYPE html>
            <html><head><meta name="viewport" content="width=device-width,initial-scale=1.0">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <style>html,body,#map{margin:0;padding:0;width:100%;height:100%;background:#0D1626;color:#9BB0C9;font-family:sans-serif;}
            .msg{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;font-size:13px;z-index:999;pointer-events:none;}</style>
            </head><body><div id="map"></div>
            <script>
            var pts = $coordsJson;
            if (typeof L !== 'undefined') {
              var map = L.map('map', {zoomControl:true}).setView([$centerLat, $centerLon], pts.length ? 15 : 12);
              L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom:19}).addTo(map);
              if (pts.length >= 2) {
                var poly = L.polyline(pts, {color:'#38D9E6', weight:5}).addTo(map);
                L.circleMarker(pts[0], {radius:6, color:'#2EE59D', fillOpacity:1}).addTo(map).bindPopup('출발');
                L.circleMarker(pts[pts.length-1], {radius:6, color:'#FF6B6B', fillOpacity:1}).addTo(map).bindPopup('도착');
                map.fitBounds(poly.getBounds(), {padding:[18,18]});
              } else if (pts.length === 1) {
                L.marker(pts[0]).addTo(map).bindPopup('주행 위치').openPopup();
              }
            } else {
              document.getElementById('map').innerHTML = '<div class="msg">GPS 좌표 ' + pts.length + '점<br>(인터넷 연결 시 도로 지도 표시 · 아래 카카오/네이버 지도 버튼 지원)</div>';
            }
            </script></body></html>
        """.trimIndent()
        mapWebView.loadDataWithBaseURL("https://unpkg.com", html, "text/html", "UTF-8", null)
    }

    private fun reloadList() {
        listContainer.removeAllViews()
        val dir = if (showingEvents) hub.eventDir() else hub.normalDir()
        val files = hub.listMp4(dir)
        if (files.isEmpty()) {
            listContainer.addView(DashboardUi.label(this, "저장된 녹화 파일이 없습니다.", 13.5f))
            return
        }
        val accent = if (showingEvents) DashboardUi.dangerColor(this) else DashboardUi.accentColor(this)
        files.take(30).forEach { file ->
            val sizeMb = "%.1f MB".format(file.length() / (1024.0 * 1024.0))
            val hasTele = File(file.parentFile, file.nameWithoutExtension + ".jsonl").isFile
            val row = DashboardUi.actionRow(
                this,
                file.name,
                "$sizeMb · ${if (hasTele) "주행정보/GPS 포함" else "영상 전용"}",
                if (showingEvents) DashboardIcons.IconKind.SHIELD_ADB else DashboardIcons.IconKind.PLAY,
                accent,
                if (showingEvents) "보호됨" else "재생"
            ) {
                playFile(file)
            }
            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(file.name)
                    .setItems(arrayOf("영상 재생", "파일 삭제")) { _, which ->
                        if (which == 0) playFile(file)
                        else {
                            hub.deleteWithSidecars(file)
                            Toast.makeText(this, "삭제 완료", Toast.LENGTH_SHORT).show()
                            reloadList()
                        }
                    }.show()
                true
            }
            listContainer.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, DashboardUi.dp(this@DashcamViewerActivity, 3), 0, DashboardUi.dp(this@DashcamViewerActivity, 3))
            })
        }
    }

    private fun playFile(mp4: File) {
        runCatching {
            videoView.setVideoURI(Uri.fromFile(mp4))
            videoView.start()
        }.onFailure {
            Toast.makeText(this, "재생 오류: ${it.message}", Toast.LENGTH_SHORT).show()
        }
        val jsonl = File(mp4.parentFile, mp4.nameWithoutExtension + ".jsonl")
        if (!jsonl.isFile) {
            telemetryInfo.text = "${mp4.name} · 동기화된 주행 정보(.jsonl) 없음"
            renderLeafletMap(emptyList())
            return
        }
        val pts = mutableListOf<Pair<Double, Double>>()
        var maxSpd = 0.0
        var brakeSamples = 0
        val gears = linkedSetOf<String>()
        runCatching {
            jsonl.forEachLine(Charsets.UTF_8) { line ->
                if (line.isBlank()) return@forEachLine
                val o = JSONObject(line)
                val s = o.optDouble("spd", 0.0)
                if (s > maxSpd) maxSpd = s
                if (o.optInt("brk", 0) == 1) brakeSamples++
                gears.add(o.optString("gear", "?"))
                if (o.has("lat") && o.has("lon")) {
                    pts.add(o.getDouble("lat") to o.getDouble("lon"))
                }
            }
        }
        telemetryInfo.text = "${mp4.name} · 최고속도 ${"%.1f".format(maxSpd)} km/h · 기어[${gears.joinToString(",")}] · 브레이크 ${brakeSamples}초 · GPS ${pts.size}점"
        renderLeafletMap(pts)
    }
}
