package com.byd.dolphin.drivealerts.camera

import android.content.Context
import android.view.Surface
import com.byd.dolphin.drivealerts.util.CoreLog
import dalvik.system.PathClassLoader
import java.io.File
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/**
 * Clean-Room BYD DiLink 3 / DiLink 5 BmmCamera / AVMCamera Vendor Framework Backend (v0.17.82).
 *
 * Real-car verified discovery & binding sequence:
 * 1. Load android.hardware.AVMCamera & android.hardware.BmmCameraInfo from default classloader
 *    or /system/framework/bmmcamera.jar (/vendor/framework/bmmcamera.jar, AVMCamera.jar, etc.).
 * 2. Discover real camera IDs via BmmCameraInfo.getValidCameraTag() + getCameraId(tag)
 *    checking tags ("pano_h", "pano_l", "apa", "byd_apa") and sweeping fallback IDs 0..5.
 * 3. Open via static AVMCamera.open(camId), falling back to constructor AVMCamera(camId) + open().
 * 4. Attach optional IEventCallback proxy, bind Surface via 2-arg addPreviewSurface(Surface, 0)
 *    (falling back to 1-arg setPreviewSurface / addPreviewSurface), then startPreview().
 */
class BydAvmCameraBackend(context: Context) {
    data class ProbeInfo(
        val available: Boolean,
        val jarPath: String?,
        val avmClassName: String?,
        val hasBmmInfo: Boolean,
        val discoveredCamIds: List<Int>,
        val detail: String
    )

    private val app = context.applicationContext
    @Volatile private var cachedLoader: ClassLoader? = null
    @Volatile private var activeCameraObj: Any? = null
    @Volatile private var activeSurface: Surface? = null
    @Volatile private var activeSurfaceSlot: Int = 0
    @Volatile private var activeCamId: Int = -1
    @Volatile private var activeOpen = false
    @Volatile var lastDiagnostic: String = "(미시도)"
        private set

    val isOpen: Boolean get() = activeOpen && activeCameraObj != null

    private val candidateJars = listOf(
        "/system/framework/bmmcamera.jar",
        "/vendor/framework/bmmcamera.jar",
        "/system/framework/AVMCamera.jar",
        "/vendor/framework/AVMCamera.jar",
        "/system/framework/byd_avm.jar",
        "/system/framework/com.byd.camera.jar",
        "/system/framework/bydcamera.jar"
    )

    private val candidateClasses = listOf(
        "android.hardware.AVMCamera",
        "android.hardware.avm.AVMCamera"
    )

    private val preferredTags = listOf("pano_h", "pano_l", "apa", "byd_apa")

    private fun resolveClassLoader(): Pair<ClassLoader, String?> {
        cachedLoader?.let { return it to candidateJars.firstOrNull { p -> File(p).exists() } }
        // First check if already on boot/app classloader
        for (c in candidateClasses) {
            if (runCatching { Class.forName(c) }.isSuccess) {
                cachedLoader = app.classLoader
                return app.classLoader to "boot-classpath"
            }
        }
        val existingJars = candidateJars.filter { File(it).exists() && File(it).canRead() }
        if (existingJars.isEmpty()) {
            return app.classLoader to null
        }
        val joined = existingJars.joinToString(File.pathSeparator)
        val loader = runCatching { PathClassLoader(joined, app.classLoader) }.getOrDefault(app.classLoader)
        cachedLoader = loader
        return loader to existingJars.first()
    }

    private fun loadClassOrNull(loader: ClassLoader, name: String): Class<*>? =
        runCatching { Class.forName(name, false, loader) }.getOrNull()
            ?: runCatching { loader.loadClass(name) }.getOrNull()
            ?: runCatching { Class.forName(name) }.getOrNull()

    fun discoverCandidateCamIds(loader: ClassLoader): List<Int> {
        val ids = linkedSetOf<Int>()
        val bmmCls = loadClassOrNull(loader, "android.hardware.BmmCameraInfo")
        if (bmmCls != null) {
            val tags = linkedSetOf<String>()
            runCatching {
                val mTags = bmmCls.getMethod("getValidCameraTag")
                val raw = mTags.invoke(null)?.toString().orEmpty()
                raw.split(Regex("[,;|\\s\\[\\]{}()\"']+")).filter { it.isNotBlank() }.forEach { tags.add(it) }
            }
            preferredTags.forEach { tags.add(it) }
            val mGetId = runCatching { bmmCls.getMethod("getCameraId", String::class.java) }.getOrNull()
            if (mGetId != null) {
                for (tag in tags) {
                    val id = runCatching { (mGetId.invoke(null, tag) as? Number)?.toInt() }.getOrNull()
                    if (id != null && id >= 0) ids.add(id)
                }
            }
        }
        // Always include standard sweep 0..5 as fallback
        for (i in 0..5) ids.add(i)
        return ids.toList()
    }

    fun probe(): ProbeInfo {
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { name -> loadClassOrNull(loader, name)?.let { name to it } }
        val bmmInfo = loadClassOrNull(loader, "android.hardware.BmmCameraInfo") != null
        val camIds = if (avmCls != null) discoverCandidateCamIds(loader) else emptyList()
        val available = avmCls != null
        val detail = if (available) {
            "BYD 360 AVM 감지됨 (${avmCls!!.first} · ${jar?.let { File(it).name } ?: "system"} · IDs=${camIds.take(6).joinToString(",")}${if (bmmInfo) " · BmmInfo OK" else ""})"
        } else {
            val readable = candidateJars.filter { File(it).exists() && File(it).canRead() }.map { File(it).name }
            "BYD AVM 미감지 (JAR=${if (readable.isEmpty()) "없음" else readable.joinToString(",")})"
        }
        lastDiagnostic = detail
        return ProbeInfo(available, jar, avmCls?.first, bmmInfo, camIds, detail)
    }

    /**
     * Open BYD AVM 4-channel surround camera onto the provided Surface.
     */
    fun openAvm(surface: Surface, viewMode: Int = 0): Pair<Boolean, String> {
        close()
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { loadClassOrNull(loader, it) }
            ?: return (false to "AVMCamera 클래스를 찾을 수 없음").also { lastDiagnostic = it.second }

        val candidates = discoverCandidateCamIds(loader)
        val errors = mutableListOf<String>()

        for (camId in candidates) {
            val res = runCatching {
                val camObj = openInstanceById(avmCls, camId)
                    ?: throw IllegalStateException("open($camId)=null")
                activeCameraObj = camObj
                activeCamId = camId

                attachOptionalEventCallback(loader, avmCls, camObj)

                val bound = bindSurface(avmCls, camObj, surface, 0)
                if (!bound) {
                    close()
                    throw IllegalStateException("addPreviewSurface/setPreviewSurface 실패")
                }
                activeSurface = surface
                activeSurfaceSlot = 0

                if (viewMode > 0) {
                    invokeOptionalInt(avmCls, camObj, listOf("setViewMode", "setCameraMode", "setDisplayMode"), viewMode)
                }
                val started = invokeOptionalNoArg(avmCls, camObj, listOf("startPreview", "start", "openPreview"))
                activeOpen = true
                val msg = "AVMCamera(id=$camId) 오픈 성공 (${jar?.let { File(it).name } ?: "system"}, start=$started)"
                CoreLog.i("BYD_AVM", msg)
                lastDiagnostic = msg
                true to msg
            }.getOrElse { e ->
                close()
                val root = e.cause ?: e
                errors += "id=$camId:${root.javaClass.simpleName}(${root.message?.take(40)})"
                null
            }
            if (res != null) return res
        }

        val failMsg = "AVMCamera 오픈 실패 (시도=${candidates.joinToString(",")} · ${errors.take(3).joinToString(" / ")})"
        CoreLog.w("BYD_AVM", failMsg)
        lastDiagnostic = failMsg
        return false to failMsg
    }

    /**
     * Open normal single-channel BYD camera by ID.
     */
    fun openNormal(camId: Int, surface: Surface): Pair<Boolean, String> {
        close()
        val (loader, jar) = resolveClassLoader()
        val avmCls = candidateClasses.firstNotNullOfOrNull { loadClassOrNull(loader, it) }
            ?: return false to "AVMCamera 클래스 없음"

        return runCatching {
            val camObj = openInstanceById(avmCls, camId)
                ?: return false to "일반 채널(ID=$camId) 오픈 실패"
            activeCameraObj = camObj
            activeCamId = camId
            attachOptionalEventCallback(loader, avmCls, camObj)
            if (!bindSurface(avmCls, camObj, surface, 0)) {
                close()
                return false to "일반 채널 Surface 바인딩 실패"
            }
            activeSurface = surface
            activeSurfaceSlot = 0
            invokeOptionalNoArg(avmCls, camObj, listOf("startPreview", "start"))
            activeOpen = true
            val msg = "BYD 일반 채널(ID=$camId) 오픈 성공 (${jar?.let { File(it).name } ?: "system"})"
            CoreLog.i("BYD_AVM", msg)
            lastDiagnostic = msg
            true to msg
        }.getOrElse { e ->
            close()
            val root = e.cause ?: e
            val msg = "BYD 일반 채널 예외: ${root.javaClass.simpleName}: ${root.message}"
            lastDiagnostic = msg
            false to msg
        }
    }

    fun close() {
        val obj = activeCameraObj
        val surf = activeSurface
        val slot = activeSurfaceSlot
        activeCameraObj = null
        activeSurface = null
        activeOpen = false
        if (obj == null) return
        val cls = obj.javaClass
        if (surf != null) {
            runCatching {
                cls.getMethod("rmPreviewSurface", Surface::class.java, Int::class.javaPrimitiveType)
                    .invoke(obj, surf, slot)
            }
            runCatching {
                cls.getMethod("rmPreviewSurface", Int::class.javaPrimitiveType, Surface::class.java)
                    .invoke(obj, slot, surf)
            }
        }
        invokeOptionalNoArg(cls, obj, listOf("stopPreview", "stop"))
        invokeOptionalNoArg(cls, obj, listOf("close", "release"))
        CoreLog.i("BYD_AVM", "AVMCamera(id=$activeCamId) closed")
        activeCamId = -1
    }

    private fun openInstanceById(cls: Class<*>, camId: Int): Any? {
        // 1. Static AVMCamera.open(int)
        for (name in listOf("open", "openCamera")) {
            val m = runCatching { cls.getMethod(name, Int::class.javaPrimitiveType) }.getOrNull() ?: continue
            val obj = runCatching { m.invoke(null, camId) }.getOrNull()
            if (obj != null) return obj
        }
        // 2. Constructor AVMCamera(int) + instance open()
        runCatching {
            val ctor = cls.getDeclaredConstructor(Int::class.javaPrimitiveType).apply { isAccessible = true }
            val obj = ctor.newInstance(camId)
            val instOpen = runCatching { cls.getDeclaredMethod("open").apply { isAccessible = true } }.getOrNull()
            if (instOpen != null) {
                val r = instOpen.invoke(obj)
                if (r is Boolean && !r) {
                    runCatching { cls.getMethod("close").invoke(obj) }
                    return@runCatching null
                }
            }
            obj
        }.getOrNull()?.let { return it }

        // 3. No-arg static open() / getInstance() only when camId == 0
        if (camId == 0) {
            for (name in listOf("open", "openAvm", "getInstance")) {
                val m = runCatching { cls.getMethod(name) }.getOrNull() ?: continue
                val obj = runCatching { m.invoke(null) }.getOrNull()
                if (obj != null) return obj
            }
            runCatching { cls.getDeclaredConstructor().apply { isAccessible = true }.newInstance() }
                .getOrNull()?.let { return it }
        }
        return null
    }

    private fun attachOptionalEventCallback(loader: ClassLoader, avmCls: Class<*>, camObj: Any) {
        runCatching {
            val cbCls = loadClassOrNull(loader, "android.hardware.AVMCamera\$IEventCallback") ?: return
            val setCb = runCatching { avmCls.getMethod("setEventCallback", cbCls) }.getOrNull() ?: return
            val proxy = Proxy.newProxyInstance(cbCls.classLoader, arrayOf(cbCls)) { _, method, args ->
                when (method.name) {
                    "hashCode" -> System.identityHashCode(camObj)
                    "equals" -> false
                    "toString" -> "DolphinAvmEventCallback"
                    else -> {
                        if (method.returnType == Boolean::class.javaPrimitiveType) false
                        else if (method.returnType == Int::class.javaPrimitiveType) 0
                        else null
                    }
                }
            }
            setCb.invoke(camObj, proxy)
        }
    }

    private fun bindSurface(cls: Class<*>, obj: Any, surface: Surface, slot: Int): Boolean {
        // 1. Primary BYD DiLink 3/5 API: addPreviewSurface(Surface, int)
        runCatching {
            val m = cls.getMethod("addPreviewSurface", Surface::class.java, Int::class.javaPrimitiveType)
            val r = m.invoke(obj, surface, slot)
            if (r is Int && r < 0) return@runCatching false
            if (r is Boolean && !r) return@runCatching false
            true
        }.getOrDefault(false).let { if (it) return true }

        // 2. Alternate order: addPreviewSurface(int, Surface)
        runCatching {
            val m = cls.getMethod("addPreviewSurface", Int::class.javaPrimitiveType, Surface::class.java)
            val r = m.invoke(obj, slot, surface)
            if (r is Int && r < 0) return@runCatching false
            if (r is Boolean && !r) return@runCatching false
            true
        }.getOrDefault(false).let { if (it) return true }

        // 3. Single-arg fallbacks
        for (name in listOf("setPreviewSurface", "addPreviewSurface", "setSurface", "setPreviewTarget")) {
            val m = runCatching { cls.getMethod(name, Surface::class.java) }.getOrNull() ?: continue
            val ok = runCatching {
                val r = m.invoke(obj, surface)
                !(r is Boolean && !r) && !(r is Int && r < 0)
            }.getOrDefault(false)
            if (ok) return true
        }
        return false
    }

    private fun invokeOptionalNoArg(cls: Class<*>, obj: Any, names: List<String>): Boolean {
        for (n in names) {
            val m = runCatching { cls.getMethod(n) }.getOrNull() ?: continue
            if (runCatching { m.invoke(obj); true }.getOrDefault(false)) return true
        }
        return false
    }

    private fun invokeOptionalInt(cls: Class<*>, obj: Any, names: List<String>, value: Int): Boolean {
        for (n in names) {
            val m = runCatching { cls.getMethod(n, Int::class.javaPrimitiveType) }.getOrNull() ?: continue
            if (runCatching { m.invoke(obj, value); true }.getOrDefault(false)) return true
        }
        return false
    }
}
