package com.byd.dolphin.drivealerts.camera

import android.content.Context

/** Preferences for front-camera + front-radar sensor-fused lead-car departure detection. */
object LeadCarDeparturePreferences {
    private const val PREF = "lead_car_departure_fusion"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_MODE = "fusion_mode"
    private const val KEY_SENSITIVITY = "sensitivity"
    private const val KEY_CAM_ID = "front_cam_id"
    private const val KEY_AVM_QUADRANT = "avm_front_quadrant"
    private const val KEY_ICC_ENABLED = "icc_lead_enabled"
    private const val KEY_ICC_REQUIRE_ACTIVE = "icc_require_active"

    /**
     * 0 = 융합 (카메라 또는 전방 센서 중 감지 시 알림)
     * 1 = 전방 카메라 전용 (일반 신호대기 거리 대응)
     * 2 = 전방 센서 전용 (카메라 미사용)
     * 3 = 교차 확인 (센서 + 카메라 동시 일치 시만 알림)
     */
    val modeLabels = listOf(
        "융합 (전방 카메라 + 전방 센서)",
        "전방 카메라 전용 (일반 신호대기 권장)",
        "전방 센서 전용 (초음파/레이더)",
        "교차 확인 (센서 + 카메라 동시 일치)"
    )
    val sensitivityLabels = listOf("둔감 (오경보 최소)", "보통 (권장)", "민감 (빠른 반응)")

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = prefs(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun mode(c: Context): Int = prefs(c).getInt(KEY_MODE, 0).coerceIn(0, 3)
    fun setMode(c: Context, v: Int) = prefs(c).edit().putInt(KEY_MODE, v.coerceIn(0, 3)).apply()

    fun sensitivity(c: Context): Int = prefs(c).getInt(KEY_SENSITIVITY, 1).coerceIn(0, 2)
    fun setSensitivity(c: Context, v: Int) = prefs(c).edit().putInt(KEY_SENSITIVITY, v.coerceIn(0, 2)).apply()

    fun frontCameraId(c: Context): String = prefs(c).getString(KEY_CAM_ID, "0") ?: "0"
    fun setFrontCameraId(c: Context, id: String) = prefs(c).edit().putString(KEY_CAM_ID, id.trim().ifBlank { "0" }).apply()

    fun avmFrontQuadrant(c: Context): Boolean = prefs(c).getBoolean(KEY_AVM_QUADRANT, false)
    fun setAvmFrontQuadrant(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_AVM_QUADRANT, v).apply()

    fun iccEnabled(c: Context): Boolean = prefs(c).getBoolean(KEY_ICC_ENABLED, true)
    fun setIccEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ICC_ENABLED, v).apply()

    fun iccRequireActive(c: Context): Boolean = prefs(c).getBoolean(KEY_ICC_REQUIRE_ACTIVE, true)
    fun setIccRequireActive(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ICC_REQUIRE_ACTIVE, v).apply()
}
