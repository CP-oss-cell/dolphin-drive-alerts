package com.byd.dolphin.drivealerts.camera

import android.content.Context

/** Preferences for ultra-low-resource shared Camera2 dashcam, storage, event protection & telemetry. */
object DashcamPreferences {
    private const val PREF = "dolphin_dashcam"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_CAM_ID = "cam_id"
    private const val KEY_SEGMENT_MIN = "segment_min"
    private const val KEY_MAX_GB = "max_gb"
    private const val KEY_QUALITY = "quality"
    private const val KEY_STORAGE_IDX = "storage_volume_idx"
    private const val KEY_EVENT_MAX = "event_max_count"
    private const val KEY_GSENSOR = "gsensor_level"
    private const val KEY_TELEMETRY = "telemetry_enabled"
    private const val KEY_THERMAL = "thermal_guard"

    val segmentOptions = listOf(1, 3, 5)
    val segmentLabels = listOf("1분 단위 분할 (손상 최소화 권장)", "3분 단위 분할", "5분 단위 분할")
    val storageOptions = listOf(2, 4, 8, 16, 32)
    val storageLabels = listOf("최대 2 GB 순환", "최대 4 GB 순환 (권장)", "최대 8 GB 순환", "최대 16 GB 순환", "최대 32 GB 순환")
    val qualityLabels = listOf(
        "480p · 2 Mbps (초저용량 · 최저발열)",
        "720p · 4 Mbps (균형 · 저발열)",
        "카메라 원본 해상도 자동 (최고 화질 · 권장)"
    )
    val eventMaxOptions = listOf(10, 20, 30, 50)
    val eventMaxLabels = listOf("이벤트 최대 10개 보호 (초과 시 순차 삭제)", "이벤트 최대 20개 보호 (권장)", "이벤트 최대 30개 보호", "이벤트 최대 50개 보호")
    val gsensorLabels = listOf("충격 감지 끄기", "둔감 (강한 충격만)", "보통 (권장)", "민감 (급제동·충격)")

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = prefs(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun cameraId(c: Context): String = prefs(c).getString(KEY_CAM_ID, "0") ?: "0"
    fun setCameraId(c: Context, id: String) = prefs(c).edit().putString(KEY_CAM_ID, id.trim().ifBlank { "0" }).apply()

    fun segmentMinutes(c: Context): Int = prefs(c).getInt(KEY_SEGMENT_MIN, 1).let { if (it in segmentOptions) it else 1 }
    fun setSegmentMinutes(c: Context, m: Int) = prefs(c).edit().putInt(KEY_SEGMENT_MIN, m).apply()

    fun maxStorageGb(c: Context): Int = prefs(c).getInt(KEY_MAX_GB, 4).let { if (it in storageOptions) it else 4 }
    fun setMaxStorageGb(c: Context, gb: Int) = prefs(c).edit().putInt(KEY_MAX_GB, gb).apply()

    fun qualityTier(c: Context): Int = prefs(c).getInt(KEY_QUALITY, 2).coerceIn(0, 2)
    fun setQualityTier(c: Context, q: Int) = prefs(c).edit().putInt(KEY_QUALITY, q.coerceIn(0, 2)).apply()

    fun storageVolumeIndex(c: Context): Int = prefs(c).getInt(KEY_STORAGE_IDX, 0).coerceAtLeast(0)
    fun setStorageVolumeIndex(c: Context, idx: Int) = prefs(c).edit().putInt(KEY_STORAGE_IDX, idx.coerceAtLeast(0)).apply()

    fun eventMaxCount(c: Context): Int = prefs(c).getInt(KEY_EVENT_MAX, 20).let { if (it in eventMaxOptions) it else 20 }
    fun setEventMaxCount(c: Context, cnt: Int) = prefs(c).edit().putInt(KEY_EVENT_MAX, cnt).apply()

    fun gsensorLevel(c: Context): Int = prefs(c).getInt(KEY_GSENSOR, 2).coerceIn(0, 3)
    fun setGsensorLevel(c: Context, lv: Int) = prefs(c).edit().putInt(KEY_GSENSOR, lv.coerceIn(0, 3)).apply()

    fun telemetryEnabled(c: Context): Boolean = prefs(c).getBoolean(KEY_TELEMETRY, true)
    fun setTelemetryEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_TELEMETRY, v).apply()

    fun thermalGuardEnabled(c: Context): Boolean = prefs(c).getBoolean(KEY_THERMAL, true)
    fun setThermalGuardEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_THERMAL, v).apply()
}
