package com.byd.dolphin.drivealerts.audio

import android.content.Context

enum class SoundFocusMode { REFERENCE, SURROUND, CINEMA }

data class EqSettings(
    val enabled: Boolean = false,
    val globalMix: Boolean = true,
    val bass: Int = 0,
    val mid: Int = 0,
    val treble: Int = 0,
    val centerpoint360: Boolean = false,
    val spatialStrength: Int = 50,
    val soundFocus: SoundFocusMode = SoundFocusMode.REFERENCE,
    val impactLevel: Int = 0,
    val subtleBoost: Boolean = false,
    // v0.17.60 Hyundai/Kia-grade precision audio controls
    val makeupGainDb: Float = 2.0f, // Compensates headroom cut so enabling EQ never drops loudness
    val limiterEnabled: Boolean = true,
    val dynamicMbcEnabled: Boolean = true,
    val balanceLr: Int = 0, // -10 (Left/Driver focus) .. 0 (Center) .. +10 (Right)
    val band10: List<Int> = List(10) { 0 } // Fine 10-band EQ offsets (-10..+10 dB): 31,62,125,250,500,1k,2k,4k,8k,16k
)

object EqPreferences {
    val BAND10_HZ = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val BAND10_LABELS = listOf("31Hz", "62Hz", "125Hz", "250Hz", "500Hz", "1kHz", "2kHz", "4kHz", "8kHz", "16kHz")

    private const val PREF = "audio_tuning"
    private const val K_ENABLED = "enabled"
    private const val K_GLOBAL_MIX = "global_mix"
    private const val K_BASS = "bass"
    private const val K_MID = "mid"
    private const val K_TREBLE = "treble"
    private const val K_CENTERPOINT = "centerpoint360"
    private const val K_SPATIAL_STRENGTH = "spatial_strength"
    private const val K_FOCUS = "sound_focus"
    private const val K_IMPACT = "eq_impact_v0178"
    private const val K_SUBTLE_BOOST = "eq_subtle_boost_v01712"
    private const val K_MAKEUP_GAIN = "eq_makeup_gain_db_v01760"
    private const val K_LIMITER = "eq_limiter_v01760"
    private const val K_MBC = "eq_mbc_v01760"
    private const val K_BALANCE = "eq_balance_lr_v01760"
    private const val K_BAND10_PREFIX = "eq_band10_"

    fun read(context: Context): EqSettings {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val focus = runCatching {
            SoundFocusMode.valueOf(p.getString(K_FOCUS, SoundFocusMode.REFERENCE.name)!!)
        }.getOrDefault(SoundFocusMode.REFERENCE)
        val b10 = (0 until 10).map { idx -> p.getInt("$K_BAND10_PREFIX$idx", 0).coerceIn(-10, 10) }
        return EqSettings(
            enabled = p.getBoolean(K_ENABLED, false),
            globalMix = p.getBoolean(K_GLOBAL_MIX, true),
            bass = p.getInt(K_BASS, 0).coerceIn(-10, 10),
            mid = p.getInt(K_MID, 0).coerceIn(-10, 10),
            treble = p.getInt(K_TREBLE, 0).coerceIn(-10, 10),
            centerpoint360 = p.getBoolean(K_CENTERPOINT, false),
            spatialStrength = p.getInt(K_SPATIAL_STRENGTH, 50).coerceIn(0, 100),
            soundFocus = focus,
            impactLevel = p.getInt(K_IMPACT, 0).coerceIn(0, 2),
            subtleBoost = p.getBoolean(K_SUBTLE_BOOST, false),
            makeupGainDb = p.getFloat(K_MAKEUP_GAIN, 2.0f).coerceIn(0f, 6.0f),
            limiterEnabled = p.getBoolean(K_LIMITER, true),
            dynamicMbcEnabled = p.getBoolean(K_MBC, true),
            balanceLr = p.getInt(K_BALANCE, 0).coerceIn(-10, 10),
            band10 = b10
        )
    }

    fun setEnabled(context: Context, value: Boolean) = edit(context).putBoolean(K_ENABLED, value).apply()
    fun setGlobalMix(context: Context, value: Boolean) = edit(context).putBoolean(K_GLOBAL_MIX, value).apply()
    fun setBass(context: Context, value: Int) = edit(context).putInt(K_BASS, value.coerceIn(-10, 10)).apply()
    fun setMid(context: Context, value: Int) = edit(context).putInt(K_MID, value.coerceIn(-10, 10)).apply()
    fun setTreble(context: Context, value: Int) = edit(context).putInt(K_TREBLE, value.coerceIn(-10, 10)).apply()
    fun setCenterpoint360(context: Context, value: Boolean) = edit(context).putBoolean(K_CENTERPOINT, value).apply()
    fun setSpatialStrength(context: Context, value: Int) = edit(context).putInt(K_SPATIAL_STRENGTH, value.coerceIn(0, 100)).apply()
    fun setSoundFocus(context: Context, value: SoundFocusMode) = edit(context).putString(K_FOCUS, value.name).apply()
    fun setImpactLevel(context: Context, value: Int) = edit(context).putInt(K_IMPACT, value.coerceIn(0, 2)).apply()
    fun setSubtleBoost(context: Context, value: Boolean) = edit(context).putBoolean(K_SUBTLE_BOOST, value).apply()
    fun setMakeupGainDb(context: Context, db: Float) = edit(context).putFloat(K_MAKEUP_GAIN, db.coerceIn(0f, 6.0f)).apply()
    fun setLimiterEnabled(context: Context, v: Boolean) = edit(context).putBoolean(K_LIMITER, v).apply()
    fun setDynamicMbcEnabled(context: Context, v: Boolean) = edit(context).putBoolean(K_MBC, v).apply()
    fun setBalanceLr(context: Context, v: Int) = edit(context).putInt(K_BALANCE, v.coerceIn(-10, 10)).apply()
    fun setBand10(context: Context, index: Int, db: Int) {
        if (index in 0..9) edit(context).putInt("$K_BAND10_PREFIX$index", db.coerceIn(-10, 10)).apply()
    }
    fun setAllBand10(context: Context, values: List<Int>) {
        val e = edit(context)
        for (i in 0 until minOf(10, values.size)) e.putInt("$K_BAND10_PREFIX$i", values[i].coerceIn(-10, 10))
        e.apply()
    }

    private fun edit(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .edit()
}
