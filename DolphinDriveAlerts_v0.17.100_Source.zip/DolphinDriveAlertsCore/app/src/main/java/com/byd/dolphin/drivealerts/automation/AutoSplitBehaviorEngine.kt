package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.TemporaryAppDpiController
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Stabilized Anchor-First Split-Screen Engine for BYD DiLink 3 (v0.17.68):
 * 1. Seeds a guaranteed split-screen-primary stack (windowingMode 3) via SplitGhostActivity
 *    when none exists, preventing fullscreen-task hijack on cold-started apps.
 * 2. Polls task arrival up to 2.8s (300ms steps) instead of failing after 250ms, and moves
 *    fullscreen tasks explicitly into the primary (3) / secondary (4) stacks via move-task.
 * 3. Runs a post-launch Verify & Auto-Heal pass ("fixLonely") 1.2s later so a slow cold-start
 *    app (e.g. TMAP / YouTube) cannot drop out of split-screen.
 * 4. Supports both 8-arg and 4-arg am stack resize-docked-stack with readback confirmation.
 */
object AutoSplitBehaviorEngine {
    data class Result(val success: Boolean, val message: String)

    private fun read(c: Context, cmd: String) = AuthorizedAdbRuntime.read(c, cmd, timeoutMs = 4_500L).result

    private fun write(c: Context, cmd: String): Boolean {
        val r = AuthorizedAdbRuntime.writeOnce(c, cmd, timeoutMs = 12_000L)
        val out = r.result.output
        val ok = r.state == AuthorizedAdbRuntime.State.READY && r.result.success &&
            r.result.exitCode == 0 &&
            !Regex("(?i)(Error:|Exception|Permission Denial|Unknown option|not supported|invalid input bounds)").containsMatchIn(out)
        CoreLog.i("SPLIT_NATIVE", "command=$cmd;state=${r.state};exit=${r.result.exitCode};ok=$ok;output=${out.take(450)}")
        return ok
    }

    private fun snap(c: Context): String =
        read(c, "am stack list").output + "\n" + read(c, "dumpsys activity activities").output

    private fun state(c: Context, pkg: String): LegacySplitTaskLocator.State =
        LegacySplitTaskLocator.findTask(snap(c), pkg)

    private fun camera(s: String) = ForegroundResolver.camera(s)

    fun screenToken(c: Context): String? = ForegroundResolver.topToken(read(c, "dumpsys activity activities").output)

    fun capabilities(c: Context): String {
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY) return "ADB=${adb.state}: 차량 분할 명령 사용 불가"
        val help = read(c, "am start --help").output
        val stacks = read(c, "am stack list")
        return "ADB=READY; windowingMode=${help.contains("windowingMode", true)};" +
            " stackList=${stacks.success};split=${stacks.output.contains("split-screen", true)};" +
            " Anchor-First + 자동 복구(Verify&Heal) 엔진 활성"
    }

    private fun waitForStack(c: Context, mode: Int, maxWaitMs: Long = 1_800L): Int {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (System.currentTimeMillis() < deadline) {
            val id = LegacySplitTaskLocator.findStack(snap(c), mode)
            if (id >= 0) return id
            try { Thread.sleep(220L) } catch (_: InterruptedException) { break }
        }
        return LegacySplitTaskLocator.findStack(snap(c), mode)
    }

    private fun waitForTask(c: Context, pkg: String, expectedMode: Int, maxWaitMs: Long = 2_800L): LegacySplitTaskLocator.State {
        val deadline = System.currentTimeMillis() + maxWaitMs
        var last = state(c, pkg)
        while (System.currentTimeMillis() < deadline) {
            if (last.found && last.mode == expectedMode) return last
            try { Thread.sleep(280L) } catch (_: InterruptedException) { break }
            last = state(c, pkg)
        }
        return last
    }

    fun launch(c: Context, profile: SplitProfile): Result {
        val firstComp = AppSelection.safeComponent(c, profile.firstPackage)
            ?: return Result(false, "첫 번째 앱 실행 Activity가 없습니다")
        val secondComp = AppSelection.safeComponent(c, profile.secondPackage)
            ?: return Result(false, "두 번째 앱 실행 Activity가 없습니다")
        if (profile.firstPackage == profile.secondPackage ||
            profile.firstPackage == c.packageName || profile.secondPackage == c.packageName
        ) {
            return Result(false, "서로 다른 외부 앱 2개를 선택하세요")
        }
        if (camera(screenToken(c).orEmpty())) return Result(false, "360 카메라 동작 중에는 분할을 시작하지 않습니다")
        if (AuthorizedAdbRuntime.awaitReady(c, maxWaitMs = 8_000L).state != AuthorizedAdbRuntime.State.READY) {
            return Result(false, "로컬 ADB 승인 필요")
        }
        if (TemporaryAppDpiController.hasActiveSession(c)) {
            return Result(false, "임시 전역 DPI 복원 대기 중입니다. 먼저 복원 후 분할하세요")
        }

        CoreLog.i("SPLIT_NATIVE", "BEGIN_ANCHOR_FIRST profile=${profile.id} first=${profile.firstPackage} second=${profile.secondPackage}")

        // Stage 1: Guarantee a split-screen-primary stack (windowingMode 3) via Anchor/Ghost first
        var primaryStack = LegacySplitTaskLocator.findStack(snap(c), 3)
        if (primaryStack < 0) {
            val ghost = "${c.packageName}/.automation.SplitGhostActivity"
            val seeded = write(c, "am start --user 0 --windowingMode 3 -n '$ghost'")
            if (seeded) primaryStack = waitForStack(c, 3, maxWaitMs = 1_600L)
            CoreLog.i("SPLIT_NATIVE", "ANCHOR_SEEDED accepted=$seeded primaryStack=$primaryStack")
        }

        // Stage 2: Launch primary app into mode 3 & poll for cold-start arrival
        if (camera(screenToken(c).orEmpty())) return Result(false, "360 카메라 감지로 분할 중단")
        if (!write(c, "am start --user 0 --windowingMode 3 -n '$firstComp'")) {
            return Result(false, "1단계: 첫 번째 앱 분할 실행 거부")
        }
        var a = waitForTask(c, profile.firstPackage, expectedMode = 3, maxWaitMs = 2_800L)
        if (a.found && a.mode != 3) {
            val stack3 = if (primaryStack >= 0) primaryStack else LegacySplitTaskLocator.findStack(snap(c), 3)
            if (stack3 >= 0 && !camera(screenToken(c).orEmpty())) {
                write(c, "am stack move-task ${a.taskId} $stack3 true")
                a = waitForTask(c, profile.firstPackage, expectedMode = 3, maxWaitMs = 1_200L)
            }
        }

        // Stage 3: Launch secondary app into mode 4 & poll for cold-start arrival
        if (camera(screenToken(c).orEmpty())) return Result(false, "360 카메라 감지로 두 번째 앱 실행 취소")
        if (!write(c, "am start --user 0 --windowingMode 4 -n '$secondComp'")) {
            return Result(false, "2단계: 두 번째 앱 분할 실행 거부")
        }
        var b = waitForTask(c, profile.secondPackage, expectedMode = 4, maxWaitMs = 2_800L)
        if (b.found && b.mode != 4) {
            val stack4 = LegacySplitTaskLocator.findStack(snap(c), 4)
            if (stack4 >= 0 && !camera(screenToken(c).orEmpty())) {
                write(c, "am stack move-task ${b.taskId} $stack4 true")
                b = waitForTask(c, profile.secondPackage, expectedMode = 4, maxWaitMs = 1_200L)
            }
        }

        // Stage 4: Post-Launch Verify & Auto-Heal ("fixLonely" pass for slow BYD cold starts)
        if (!isSeparated(c, a, b)) {
            CoreLog.w("SPLIT_NATIVE", "HEAL_PASS_TRIGGERED first=$a second=$b")
            try { Thread.sleep(1_000L) } catch (_: InterruptedException) {}
            if (!camera(screenToken(c).orEmpty())) {
                a = state(c, profile.firstPackage)
                b = state(c, profile.secondPackage)
                if (a.mode != 3) {
                    val s3 = LegacySplitTaskLocator.findStack(snap(c), 3)
                    if (a.found && s3 >= 0) write(c, "am stack move-task ${a.taskId} $s3 true")
                    else write(c, "am start --user 0 --windowingMode 3 -n '$firstComp'")
                }
                if (b.mode != 4) {
                    val s4 = LegacySplitTaskLocator.findStack(snap(c), 4)
                    if (b.found && s4 >= 0) write(c, "am stack move-task ${b.taskId} $s4 true")
                    else write(c, "am start --user 0 --windowingMode 4 -n '$secondComp'")
                }
                a = waitForTask(c, profile.firstPackage, expectedMode = 3, maxWaitMs = 1_800L)
                b = waitForTask(c, profile.secondPackage, expectedMode = 4, maxWaitMs = 1_800L)
            }
        }

        if (!isSeparated(c, a, b)) {
            val raw = read(c, "am stack list").output
            val modes = raw.lineSequence().filter {
                it.contains("Stack id=", true) || it.contains("windowingMode", true)
            }.take(8).joinToString(" | ").take(340)
            CoreLog.w("SPLIT_NATIVE", "SPLIT_NOT_CONFIRMED first=$a second=$b stack=$modes")
            return Result(false, "분할 실패: 첫 앱=${a.mode}/${a.stackId}, 둘째 앱=${b.mode}/${b.stackId}")
        }

        FeatureProfiles.markSplit(c, profile.id)
        val ratio = applyRatio(c, profile.primaryPercent, profile)
        if (!ratio.success) return Result(true, "두 앱 분할 확인 (비율 보류: ${ratio.message})")
        return Result(true, "두 앱 분할 확인: ${ratio.message}")
    }

    private fun isSeparated(c: Context, a: LegacySplitTaskLocator.State, b: LegacySplitTaskLocator.State): Boolean =
        !camera(screenToken(c).orEmpty()) &&
            a.found && b.found && a.mode == 3 && b.mode == 4 &&
            a.taskId != b.taskId && a.stackId != b.stackId

    fun applyRatio(c: Context, percentage: Int, expected: SplitProfile? = null): Result {
        if (percentage !in 10..90) return Result(false, "비율은 10~90%입니다")
        if (camera(screenToken(c).orEmpty())) return Result(false, "카메라 화면에서 비율 변경 보류")
        if (AuthorizedAdbRuntime.health(c).state != AuthorizedAdbRuntime.State.READY) return Result(false, "ADB 승인 필요")
        if (TemporaryAppDpiController.hasActiveSession(c)) return Result(false, "임시 전역 DPI 복원 대기 중")
        if (expected != null) {
            val snapshot = snap(c)
            val a = LegacySplitTaskLocator.findTask(snapshot, expected.firstPackage)
            val b = LegacySplitTaskLocator.findTask(snapshot, expected.secondPackage)
            if (!a.found || !b.found || a.mode != 3 || b.mode != 4 || a.stackId == b.stackId) {
                CoreLog.w("SPLIT_RATIO", "OWNERSHIP_MISMATCH expected=${expected.id} first=$a second=$b")
                return Result(false, "저장된 두 앱의 실제 분할(모드 3/4)이 확인되지 않습니다")
            }
        }
        fun measure(): SplitGeometry.PairBounds? {
            val stack = read(c, "am stack list")
            val activities = read(c, "dumpsys activity activities")
            return ReferenceAutoSplitRatio.parse(stack.output)
                ?: SplitGeometry.parse(stack.output, activities.output)
        }
        val bounds = measure() ?: return Result(false, "분할 창 좌표를 읽을 수 없어 비율 변경을 보류했습니다")
        val before = SplitGeometry.percent(bounds) ?: return Result(false, "분할 방향 확인 실패")
        if (before == percentage) return Result(true, "실제 비율 확인: $before:${100 - before}")
        val resize = SplitGeometry.resize(bounds, percentage) ?: return Result(false, "비율 좌표 계산 실패")
        fun confirmed(): Int? {
            repeat(3) {
                try { Thread.sleep(350L) } catch (_: InterruptedException) { return null }
                val value = measure()?.let(SplitGeometry::percent)
                if (value == percentage) return value
            }
            return measure()?.let(SplitGeometry::percent)
        }
        val eightAccepted = write(c, resize.command)
        var actual = if (eightAccepted) confirmed() else measure()?.let(SplitGeometry::percent)
        if (actual != percentage && !camera(screenToken(c).orEmpty())) {
            val fourAccepted = write(c, resize.fourArgCommand)
            actual = if (fourAccepted) confirmed() else measure()?.let(SplitGeometry::percent)
            if (actual == percentage) return Result(true, "실제 비율 $actual:${100 - actual} 확인 (4좌표)")
        } else if (actual == percentage) {
            return Result(true, "실제 비율 $actual:${100 - actual} 확인 (8좌표)")
        }
        return Result(false, "요청 $percentage:${100 - percentage}, 실제 ${actual?.let { "$it:${100 - it}" } ?: "측정 불가"}")
    }
}
