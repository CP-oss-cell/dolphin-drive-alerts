package com.byd.dolphin.drivealerts.sentry

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent settings for Clean-Room LinkLock-style Sentry Mode (Parking Guard):
 * motion sensitivity, IMU impact detection, Tesla-style warning screen, boarding event count voice,
 * 12V/HV battery protection cutoffs, max duration, GPS Safe Zones (home/work exclusion), and unseen count.
 */
object SentryPreferences {
    private const val PREF = "dolphin_sentry_prefs"
    private const val KEY_ENABLED = "sentry_enabled"
    private const val KEY_SENSITIVITY = "sentry_sensitivity" // 0=low, 1=normal, 2=high
    private const val KEY_IMPACT = "sentry_impact_enabled"
    private const val KEY_WARN_SCREEN = "sentry_warn_screen"
    private const val KEY_BOARDING_VOICE = "sentry_boarding_voice"
    private const val KEY_MIN_12V_DECI = "sentry_min_12v_deci" // 118=11.8V, 120=12.0V, 122=12.2V
    private const val KEY_MIN_HV_PCT = "sentry_min_hv_pct"     // 15, 20, 30
    private const val KEY_MAX_HOURS = "sentry_max_hours"       // 2, 4, 8, 12, 24
    private const val KEY_SAFE_ZONES = "sentry_safe_zones_json"
    private const val KEY_UNSEEN_COUNT = "sentry_unseen_count"
    private const val KEY_KEEP_AWAKE_OFF = "sentry_keep_awake_off"

    data class SafeZone(val id: String, val name: String, val lat: Double, val lon: Double, val radiusM: Int = 150)

    val sensitivityLabels = listOf("둔감 (강한 접근만)", "보통 (권장)", "민감 (가벼운 움직임)")

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_ENABLED, v).apply() }

    fun sensitivity(c: Context): Int = sp(c).getInt(KEY_SENSITIVITY, 1).coerceIn(0, 2)
    fun setSensitivity(c: Context, v: Int) { sp(c).edit().putInt(KEY_SENSITIVITY, v.coerceIn(0, 2)).apply() }

    fun impactEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_IMPACT, true)
    fun setImpactEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_IMPACT, v).apply() }

    fun warningScreenEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_WARN_SCREEN, true)
    fun setWarningScreenEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_WARN_SCREEN, v).apply() }

    fun boardingVoiceEnabled(c: Context): Boolean = sp(c).getBoolean(KEY_BOARDING_VOICE, true)
    fun keepAwakeOnOff(c: Context): Boolean = sp(c).getBoolean(KEY_KEEP_AWAKE_OFF, true)
    fun setKeepAwakeOnOff(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_KEEP_AWAKE_OFF, v).apply() }
    fun setBoardingVoiceEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean(KEY_BOARDING_VOICE, v).apply() }

    fun min12vDeciVolts(c: Context): Int = sp(c).getInt(KEY_MIN_12V_DECI, 120).coerceIn(114, 126)
    fun setMin12vDeciVolts(c: Context, v: Int) { sp(c).edit().putInt(KEY_MIN_12V_DECI, v.coerceIn(114, 126)).apply() }

    fun minHvPercent(c: Context): Int = sp(c).getInt(KEY_MIN_HV_PCT, 20).coerceIn(10, 50)
    fun setMinHvPercent(c: Context, v: Int) { sp(c).edit().putInt(KEY_MIN_HV_PCT, v.coerceIn(10, 50)).apply() }

    fun maxHours(c: Context): Int = sp(c).getInt(KEY_MAX_HOURS, 8).coerceIn(1, 24)
    fun setMaxHours(c: Context, v: Int) { sp(c).edit().putInt(KEY_MAX_HOURS, v.coerceIn(1, 24)).apply() }

    fun unseenEventCount(c: Context): Int = sp(c).getInt(KEY_UNSEEN_COUNT, 0).coerceAtLeast(0)
    fun incrementUnseenEvents(c: Context): Int {
        val next = unseenEventCount(c) + 1
        sp(c).edit().putInt(KEY_UNSEEN_COUNT, next).apply()
        return next
    }
    fun clearUnseenEvents(c: Context) { sp(c).edit().putInt(KEY_UNSEEN_COUNT, 0).apply() }

    fun safeZones(c: Context): List<SafeZone> {
        val raw = sp(c).getString(KEY_SAFE_ZONES, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                SafeZone(
                    id = o.optString("id").ifBlank { return@mapNotNull null },
                    name = o.optString("name").ifBlank { "제외 구역" },
                    lat = o.optDouble("lat", 0.0),
                    lon = o.optDouble("lon", 0.0),
                    radiusM = o.optInt("radiusM", 150).coerceIn(50, 1000)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun addSafeZone(c: Context, zone: SafeZone) {
        val list = safeZones(c).toMutableList().apply { add(zone) }
        saveSafeZones(c, list)
    }

    fun removeSafeZone(c: Context, id: String) {
        saveSafeZones(c, safeZones(c).filterNot { it.id == id })
    }

    private fun saveSafeZones(c: Context, list: List<SafeZone>) {
        val arr = JSONArray()
        for (z in list) {
            arr.put(JSONObject().apply {
                put("id", z.id)
                put("name", z.name)
                put("lat", z.lat)
                put("lon", z.lon)
                put("radiusM", z.radiusM)
            })
        }
        sp(c).edit().putString(KEY_SAFE_ZONES, arr.toString()).apply()
    }
}
