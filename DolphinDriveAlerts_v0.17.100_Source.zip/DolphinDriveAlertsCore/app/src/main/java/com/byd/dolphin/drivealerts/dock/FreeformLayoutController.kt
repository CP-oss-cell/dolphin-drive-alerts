package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Experimental Android 10 (API 29) Freeform Multi-Window Test Engine (v0.17.86).
 * Launches 1, 2 (7:3 / 5:5), 3 (60% + 40% top/bottom), or 4 (2x2) apps into exact pixel bounds
 * inside the usable display area excluding the active Floating Dock Bar, using local ADB
 * (`enable_freeform_support`, `am start --windowingMode 5`, and `am task resize`).
 */
object FreeformLayoutController {

    enum class LayoutPreset(val label: String, val requiredApps: Int) {
        SINGLE_100("1분할 (빈공간 100%)", 1),
        SPLIT_70_30("2분할 (7:3 비율)", 2),
        SPLIT_50_50("2분할 (5:5 비율)", 2),
        TRIPLE_60_40("3분할 (좌60% + 우 상/하)", 3),
        QUAD_2X2("4분할 (2×2 격자)", 4)
    }

    /** Compute usable screen rectangle excluding the active dock bar edge. */
    fun usableBounds(context: Context): Rect {
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels.coerceAtLeast(800)
        val h = dm.heightPixels.coerceAtLeast(480)
        val barPx = if (DockPreferences.enabled(context)) {
            (dm.density * DockPreferences.heightDp(context) + 0.5f).toInt()
        } else 0
        return when (DockPreferences.edgePosition(context)) {
            DockPreferences.EDGE_TOP -> Rect(0, barPx, w, h)
            DockPreferences.EDGE_LEFT -> Rect(barPx, 0, w, h)
            DockPreferences.EDGE_RIGHT -> Rect(0, 0, w - barPx, h)
            else -> Rect(0, 0, w, h - barPx)
        }
    }

    /** Compute exact pixel Rects for each app slot in the chosen preset. */
    fun computeSlotRects(context: Context, preset: LayoutPreset): List<Rect> {
        val u = usableBounds(context)
        val w = u.width()
        val h = u.height()
        val gap = 4
        return when (preset) {
            LayoutPreset.SINGLE_100 -> listOf(Rect(u.left, u.top, u.right, u.bottom))
            LayoutPreset.SPLIT_70_30 -> {
                val splitX = u.left + (w * 70) / 100
                listOf(
                    Rect(u.left, u.top, splitX - gap / 2, u.bottom),
                    Rect(splitX + gap / 2, u.top, u.right, u.bottom)
                )
            }
            LayoutPreset.SPLIT_50_50 -> {
                val midX = u.left + w / 2
                listOf(
                    Rect(u.left, u.top, midX - gap / 2, u.bottom),
                    Rect(midX + gap / 2, u.top, u.right, u.bottom)
                )
            }
            LayoutPreset.TRIPLE_60_40 -> {
                val splitX = u.left + (w * 60) / 100
                val midY = u.top + h / 2
                listOf(
                    Rect(u.left, u.top, splitX - gap / 2, u.bottom),
                    Rect(splitX + gap / 2, u.top, u.right, midY - gap / 2),
                    Rect(splitX + gap / 2, midY + gap / 2, u.right, u.bottom)
                )
            }
            LayoutPreset.QUAD_2X2 -> {
                val midX = u.left + w / 2
                val midY = u.top + h / 2
                listOf(
                    Rect(u.left, u.top, midX - gap / 2, midY - gap / 2),
                    Rect(midX + gap / 2, u.top, u.right, midY - gap / 2),
                    Rect(u.left, midY + gap / 2, midX - gap / 2, u.bottom),
                    Rect(midX + gap / 2, midY + gap / 2, u.right, u.bottom)
                )
            }
        }
    }

    /** Enable Android 10 Freeform flags via local ADB and diagnose device support. */
    fun enableAndDiagnose(context: Context, onDone: (Boolean, String) -> Unit) {
        val app = context.applicationContext
        Thread {
            val cmd = "settings put global enable_freeform_support 1 && " +
                "settings put global force_resizable_activities 1 && " +
                "echo FREEFORM=\$(settings get global enable_freeform_support) && " +
                "echo RESIZABLE=\$(settings get global force_resizable_activities) && " +
                "pm list features | grep -i freeform || echo NO_FEATURE_FLAG"
            val r = AuthorizedAdbRuntime.writeOnce(app, cmd)
            val ok = r.result.success
            val out = r.result.output.trim().ifBlank { r.state.name }
            CoreLog.i("FREEFORM", "enableAndDiagnose ok=$ok out=$out")
            val msg = if (ok) {
                "Freeform 활성화 완료\n$out"
            } else {
                "로컬 ADB 연결 필요 (${r.state}): [권한 · ADB]에서 연결 후 다시 시도하세요."
            }
            onDone(ok, msg)
        }.start()
    }

    /** Safely revert global Freeform flag back to 0. */
    fun disableAndRevert(context: Context, onDone: (Boolean, String) -> Unit) {
        val app = context.applicationContext
        Thread {
            val r = AuthorizedAdbRuntime.writeOnce(app, "settings put global enable_freeform_support 0")
            val msg = if (r.result.success) "Freeform 설정 원복 완료 (enable_freeform_support=0)" else "원복 실패 (${r.state})"
            CoreLog.i("FREEFORM", msg)
            onDone(r.result.success, msg)
        }.start()
    }

    /** Launch the selected apps in Freeform mode (windowingMode 5) and resize each task to exact bounds. */
    fun launchPreset(
        context: Context,
        preset: LayoutPreset,
        packages: List<String>,
        onDone: (Boolean, String) -> Unit
    ) {
        val app = context.applicationContext
        val targets = packages.take(preset.requiredApps)
        if (targets.size < preset.requiredApps || targets.any { it.isBlank() }) {
            onDone(false, "${preset.label} 테스트에는 앱 ${preset.requiredApps}개를 모두 선택해야 합니다.")
            return
        }
        val rects = computeSlotRects(app, preset)
        val pm = app.packageManager

        Thread {
            // Ensure Freeform flags are enabled first
            val initR = AuthorizedAdbRuntime.writeOnce(
                app,
                "settings put global enable_freeform_support 1 && settings put global force_resizable_activities 1"
            )
            if (!initR.result.success) {
                onDone(false, "로컬 ADB 연결 필요 (${initR.state})")
                return@Thread
            }

            val logLines = mutableListOf<String>()
            val mode = if (preset == LayoutPreset.SINGLE_100) 1 else 5 // 1=FULLSCREEN, 5=FREEFORM

            for (i in targets.indices) {
                val pkg = targets[i]
                val rect = rects[i]
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                val comp = launchIntent?.component?.flattenToShortString()
                val startCmd = if (comp != null) {
                    "am start --windowingMode $mode -n '$comp'"
                } else {
                    "am start --windowingMode $mode -a android.intent.action.MAIN -c android.intent.category.LAUNCHER '$pkg'"
                }
                val sr = AuthorizedAdbRuntime.writeOnce(app, startCmd)
                CoreLog.i("FREEFORM", "slot#$i pkg=$pkg mode=$mode startOk=${sr.result.success} out=${sr.result.output.take(120)}")
                try { Thread.sleep(420L) } catch (_: InterruptedException) {}

                if (mode == 5) {
                    val tid = findTaskIdForPackage(app, pkg)
                    if (tid != null) {
                        val resizeCmd = "am task resize $tid ${rect.left} ${rect.top} ${rect.right} ${rect.bottom}"
                        val rr = AuthorizedAdbRuntime.writeOnce(app, resizeCmd)
                        CoreLog.i("FREEFORM", "slot#$i resize task=$tid rect=${rect.flattenToString()} ok=${rr.result.success}")
                        logLines += "앱${i + 1}($pkg): task#$tid -> [${rect.left},${rect.top},${rect.right},${rect.bottom}] (${if (rr.result.success) "OK" else "FAIL"})"
                    } else {
                        logLines += "앱${i + 1}($pkg): 실행됨 (taskId 미탐지)"
                    }
                } else {
                    logLines += "앱1($pkg): 빈공간 100% 전체화면 실행"
                }
            }
            onDone(true, "${preset.label} 실행 완료\n" + logLines.joinToString("\n"))
        }.start()
    }

    private fun findTaskIdForPackage(app: Context, pkg: String): Int? {
        val cmd = "am stack list | grep -i '$pkg' | head -n 3"
        val r = AuthorizedAdbRuntime.writeOnce(app, cmd)
        val out = r.result.output
        // Android 10 am stack list format: "taskId=123: com.pkg/... bounds=..."
        val m = Regex("""taskId=(\d+)""").find(out)
        if (m != null) return m.groupValues[1].toIntOrNull()
        // Fallback: dumpsys activity recents
        val r2 = AuthorizedAdbRuntime.writeOnce(app, "dumpsys activity activities | grep -i 'TaskRecord' | grep -i '$pkg' | head -n 2")
        val m2 = Regex("""#(\d+)\s""").find(r2.result.output)
        return m2?.groupValues?.get(1)?.toIntOrNull()
    }
}
