package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import android.hardware.bydauto.dipilot.AbsBYDAutoDiPilotListener
import com.byd.dolphin.drivealerts.camera.LeadCarDeparturePreferences
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.RawVehicleFrame
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * 100% Read-Only ICC/ACC (Autonomous Driving) Lead Car Departure Detector.
 * Uses BYD DiPilot/ADAS/Instrument read-only signals:
 *  - AbsBYDAutoDiPilotListener.onFrontCarStartStateChange(int)
 *  - Read-only polling of getFrontCarStartState() and getCruiseCtrlIndicatorState()
 * Strictly separated from general-driving camera/radar fusion and zero ECU/CAN writes.
 */
class IccLeadCarDepartureDetector(
    context: Context,
    private val onDepartureDetected: (request: AlertRequest, detail: String) -> Unit
) {
    private val app = context.applicationContext
    private val deviceCandidates = listOf(
        "android.hardware.bydauto.dipilot.BYDAutoDiPilotDevice",
        "android.hardware.bydauto.dipilot.BYDAutoDipilotDevice",
        "android.hardware.bydauto.adas.BYDAutoADASDevice",
        "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice"
    )

    private var registeredDevice: Any? = null
    private var registeredListener: AbsBYDAutoDiPilotListener? = null

    @Volatile private var lastGearRaw: Int? = null
    @Volatile private var lastSpeedKmH: Float? = null
    @Volatile private var lastTjaRaw: Int? = null
    @Volatile private var lastPollState: Int = 0
    @Volatile private var lastCallbackState: Int = 0
    @Volatile private var lastFiredMs: Long = 0L

    init {
        registerDiPilotListener()
    }

    private fun registerDiPilotListener() {
        val listener = object : AbsBYDAutoDiPilotListener() {
            override fun onFrontCarStartStateChange(state: Int) {
                val prev = lastCallbackState
                lastCallbackState = state
                CoreLog.i("ICC_LEAD", "CALLBACK onFrontCarStartStateChange prev=$prev -> $state")
                if (prev <= 0 && state > 0) {
                    evaluateTrigger("DIPILOT_CALLBACK", state)
                }
            }
        }
        for (clsName in listOf(
            "android.hardware.bydauto.dipilot.BYDAutoDiPilotDevice",
            "android.hardware.bydauto.dipilot.BYDAutoDipilotDevice"
        )) {
            val dev = obtainDevice(clsName) ?: continue
            val ok = runCatching {
                val m = dev.javaClass.methods.firstOrNull {
                    it.name == "registerListener" && it.parameterTypes.size == 1
                } ?: return@runCatching false
                m.invoke(dev, listener)
                true
            }.getOrDefault(false)
            if (ok) {
                registeredDevice = dev
                registeredListener = listener
                CoreLog.i("ICC_LEAD", "DiPilot listener registered on $clsName")
                break
            }
        }
    }

    fun accept(frame: RawVehicleFrame) {
        lastGearRaw = frame.gearRaw
        lastSpeedKmH = frame.speedKmH
        lastTjaRaw = frame.tjaRaw

        if (!LeadCarDeparturePreferences.iccEnabled(app)) return
        if (frame.gearRaw != 2) {
            lastPollState = 0
            return
        }
        val speed = frame.speedKmH
        if (speed != null && speed > 1.5f) {
            lastPollState = 0
            return
        }

        val polled = readFrontCarStartState()
        if (polled != null) {
            val prev = lastPollState
            lastPollState = polled
            if (prev <= 0 && polled > 0) {
                CoreLog.i("ICC_LEAD", "POLL getFrontCarStartState prev=$prev -> $polled")
                evaluateTrigger("SDK_POLL", polled)
            }
        }
    }

    private fun evaluateTrigger(source: String, state: Int) {
        if (!LeadCarDeparturePreferences.iccEnabled(app)) return
        if (lastGearRaw != 2) return
        val speed = lastSpeedKmH
        if (speed != null && speed > 1.5f) return

        val cruiseIndicator = readCruiseCtrlIndicatorState()
        val iccActive = (cruiseIndicator != null && cruiseIndicator > 0) || (lastTjaRaw != null && lastTjaRaw!! > 0)
        if (LeadCarDeparturePreferences.iccRequireActive(app) && !iccActive) {
            CoreLog.i("ICC_LEAD", "SUPPRESSED_ICC_INACTIVE source=$source state=$state cruise=$cruiseIndicator tja=$lastTjaRaw")
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastFiredMs < 6_000L) return
        lastFiredMs = now
        val detail = "source=$source;state=$state;iccActive=$iccActive;cruise=$cruiseIndicator;tja=$lastTjaRaw"
        CoreLog.i("ICC_LEAD", "EMIT_ICC_LEAD_CAR_DEPARTURE $detail")
        onDepartureDetected(AlertRequest(AlertEvent.LEAD_CAR_DEPARTURE), detail)
    }

    private fun readFrontCarStartState(): Int? {
        for (clsName in deviceCandidates) {
            val dev = obtainDevice(clsName) ?: continue
            val v = invokeIntGetter(dev, "getFrontCarStartState")
            if (v != null && v >= 0) return v
        }
        return null
    }

    private fun readCruiseCtrlIndicatorState(): Int? {
        val inst = obtainDevice("android.hardware.bydauto.instrument.BYDAutoInstrumentDevice") ?: return null
        return invokeIntGetter(inst, "getCruiseCtrlIndicatorState")
    }

    private fun invokeIntGetter(dev: Any, methodName: String): Int? = runCatching {
        val m = dev.javaClass.methods.firstOrNull { it.name == methodName && it.parameterTypes.isEmpty() }
            ?: return@runCatching null
        (m.invoke(dev) as? Number)?.toInt()
    }.getOrNull()

    private fun obtainDevice(className: String): Any? = runCatching {
        val c = Class.forName(className)
        val m = c.methods.firstOrNull { it.name == "getInstance" && it.parameterTypes.size == 1 }
            ?: return@runCatching null
        m.invoke(null, app)
    }.getOrNull()

    fun shutdown() {
        val dev = registeredDevice
        val listener = registeredListener
        registeredDevice = null
        registeredListener = null
        if (dev != null && listener != null) {
            runCatching {
                val m = dev.javaClass.methods.firstOrNull {
                    it.name == "unregisterListener" && it.parameterTypes.size == 1
                }
                m?.invoke(dev, listener)
            }
        }
    }
}
