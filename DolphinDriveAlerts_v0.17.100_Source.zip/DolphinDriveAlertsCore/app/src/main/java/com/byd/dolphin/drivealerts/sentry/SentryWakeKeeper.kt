package com.byd.dolphin.drivealerts.sentry

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import com.byd.dolphin.drivealerts.service.BootReceiver
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Clean-Room Parked Wake-Keep Manager for Sentry Mode & Telegram Alerts (v0.17.72):
 * - Holds PARTIAL_WAKE_LOCK + WifiManager.WIFI_MODE_FULL_HIGH_PERF ONLY while Sentry is armed
 *   and outside GPS Safe Zones, releasing immediately on disarm or 12V/HV battery cutoff.
 * - On BYD ACC_OFF: optionally invokes BYDAutoPowerDevice.wakeUpMcu() via reflection and
 *   schedules a Doze-proof setExactAndAllowWhileIdle() keep-alive heartbeat every 60s so
 *   Sentry motion detection and Telegram photo alerts continue working with ignition OFF.
 */
class SentryWakeKeeper(context: Context) {
    private val app = context.applicationContext
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var active = false
    @Volatile private var lastMcuWakeMs = 0L

    fun isKeepingAwake(): Boolean = active

    fun acquire(reason: String) {
        if (!SentryPreferences.keepAwakeOnOff(app)) return
        if (active) {
            maybeWakeMcu()
            return
        }
        active = true
        runCatching {
            val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (wakeLock == null && pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Dolphin:SentryWake")
                    .apply { setReferenceCounted(false) }
            }
            wakeLock?.let { if (!it.isHeld) it.acquire(4 * 3_600_000L) }
        }.onFailure { CoreLog.w("SENTRY_WAKE", "WakeLock failed: ${it.message}") }

        runCatching {
            val wm = app.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifiLock == null && wm != null) {
                @Suppress("DEPRECATION")
                val mode = WifiManager.WIFI_MODE_FULL_HIGH_PERF
                wifiLock = wm.createWifiLock(mode, "Dolphin:SentryWifi")
                    .apply { setReferenceCounted(false) }
            }
            wifiLock?.let { if (!it.isHeld) it.acquire() }
        }.onFailure { CoreLog.w("SENTRY_WAKE", "WifiLock failed: ${it.message}") }

        maybeWakeMcu()
        scheduleHeartbeat(app)
        CoreLog.i("SENTRY_WAKE", "ACQUIRED reason=$reason (WakeLock+WifiLock+Heartbeat)")
    }

    fun release(reason: String) {
        if (!active && wakeLock == null && wifiLock == null) return
        active = false
        cancelHeartbeat(app)
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        wakeLock = null
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
        wifiLock = null
        CoreLog.i("SENTRY_WAKE", "RELEASED reason=$reason")
    }

    /** Pulse BYDAutoPowerDevice.wakeUpMcu() at most once every 25s while Sentry is armed. */
    fun maybeWakeMcu(): Boolean {
        if (!SentryPreferences.keepAwakeOnOff(app)) return false
        val now = System.currentTimeMillis()
        if (now - lastMcuWakeMs < 25_000L) return true
        lastMcuWakeMs = now
        val ok = runCatching {
            val cls = Class.forName("android.hardware.bydauto.power.BYDAutoPowerDevice")
            val inst = cls.getMethod("getInstance", Context::class.java).invoke(null, app) ?: return@runCatching false
            val m = cls.getMethod("wakeUpMcu")
            val ret = m.invoke(inst)
            CoreLog.i("SENTRY_WAKE", "wakeUpMcu() invoked ret=$ret")
            true
        }.getOrDefault(false)
        return ok
    }

    companion object {
        const val ACTION_SENTRY_HEARTBEAT = "com.byd.dolphin.drivealerts.SENTRY_HEARTBEAT"

        fun scheduleHeartbeat(context: Context) {
            val app = context.applicationContext
            if (!SentryPreferences.enabled(app) || !SentryPreferences.keepAwakeOnOff(app)) return
            val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val pi = heartbeatIntent(app)
            val triggerAt = System.currentTimeMillis() + 60_000L
            runCatching {
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
                }
            }.onFailure {
                runCatching { am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi) }
            }
        }

        fun cancelHeartbeat(context: Context) {
            val app = context.applicationContext
            val am = app.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            runCatching { am.cancel(heartbeatIntent(app)) }
        }

        private fun heartbeatIntent(context: Context): PendingIntent {
            val intent = Intent(context, BootReceiver::class.java).setAction(ACTION_SENTRY_HEARTBEAT)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            return PendingIntent.getBroadcast(context, 7702, intent, flags)
        }
    }
}
