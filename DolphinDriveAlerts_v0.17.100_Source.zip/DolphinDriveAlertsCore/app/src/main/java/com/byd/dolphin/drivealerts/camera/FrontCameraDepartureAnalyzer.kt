package com.byd.dolphin.drivealerts.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import com.byd.dolphin.drivealerts.util.CoreLog
import kotlin.math.abs

/**
 * Lightweight pure-Android Camera2 YUV luma ROI motion analyzer for lead-car departure.
 * - Opens Camera2 ONLY while the vehicle is armed (stopped in GEAR_D), never while driving or in GEAR_R.
 * - Normalizes global illumination shifts before computing 8x6 block SAD inside the center-front ROI.
 * - Rejects side-crossing artifacts when outer-margin motion exceeds center-front motion.
 */
class FrontCameraDepartureAnalyzer(
    context: Context,
    private val onCameraDeparture: (score: Float, detail: String) -> Unit
) {
    private val app = context.applicationContext
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var imageReader: ImageReader? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null

    @Volatile private var running = false
    @Volatile private var lastProcessedMs = 0L
    @Volatile var lastStatus: String = "대기 중 (정차 무장 시 자동 시작)"
        private set

    private var baselineCenter: FloatArray? = null
    private var baselineFrames = 0
    private var consecutiveHits = 0

    /** Consume a shared YUV frame from VehicleCameraHub without opening a second Camera2 device. */
    fun acceptExternalImage(img: Image) {
        processImage(img)
    }

    fun resetBaseline() {
        baselineCenter = null
        baselineFrames = 0
        consecutiveHits = 0
    }

    fun startIfPermitted() {
        if (running) return
        if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            lastStatus = "CAMERA 권한 없음"
            return
        }
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        val ids = runCatching { cm.cameraIdList.toList() }.getOrDefault(emptyList())
        val requested = LeadCarDeparturePreferences.frontCameraId(app)
        val camId = if (requested in ids) requested else ids.firstOrNull()
        if (camId == null) {
            lastStatus = "노출된 Camera2 장치 없음"
            return
        }
        running = true
        baselineCenter = null
        baselineFrames = 0
        consecutiveHits = 0
        lastStatus = "전방 카메라 감시 시작 (ID=$camId)"

        val ht = HandlerThread("lead-dep-cam").apply { start() }
        val h = Handler(ht.looper)
        thread = ht
        handler = h

        val reader = ImageReader.newInstance(320, 240, ImageFormat.YUV_420_888, 2)
        reader.setOnImageAvailableListener({ r ->
            val img = runCatching { r.acquireLatestImage() }.getOrNull() ?: return@setOnImageAvailableListener
            try {
                if (running) processImage(img)
            } catch (t: Throwable) {
                CoreLog.w("LEAD_CAM", "frame analyze error: ${t.message}")
            } finally {
                runCatching { img.close() }
            }
        }, h)
        imageReader = reader

        runCatching {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (!running) {
                        runCatching { camera.close() }
                        return
                    }
                    cameraDevice = camera
                    startSession(camera, reader, h)
                }
                override fun onDisconnected(camera: CameraDevice) {
                    lastStatus = "카메라 연결 해제 (순정 앱 양보)"
                    stop()
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    lastStatus = "카메라 오류 (code=$error)"
                    stop()
                }
            }, h)
        }.onFailure {
            lastStatus = "카메라 열기 실패: ${it.javaClass.simpleName}"
            stop()
        }
    }

    @Suppress("DEPRECATION")
    private fun startSession(camera: CameraDevice, reader: ImageReader, h: Handler) {
        runCatching {
            val surface = reader.surface
            val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(surface)
            }
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (!running) {
                        runCatching { session.close() }
                        return
                    }
                    captureSession = session
                    runCatching { session.setRepeatingRequest(req.build(), null, h) }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    lastStatus = "카메라 세션 구성 실패"
                    stop()
                }
            }, h)
        }.onFailure {
            lastStatus = "세션 시작 실패: ${it.javaClass.simpleName}"
            stop()
        }
    }

    fun stop() {
        running = false
        baselineCenter = null
        baselineFrames = 0
        consecutiveHits = 0
        runCatching { captureSession?.stopRepeating() }
        runCatching { captureSession?.close() }
        captureSession = null
        runCatching { cameraDevice?.close() }
        cameraDevice = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { thread?.quitSafely() }
        thread = null
        handler = null
    }

    private fun processImage(img: Image) {
        val now = System.currentTimeMillis()
        if (now - lastProcessedMs < 190L) return // ~5 fps lightweight cadence
        lastProcessedMs = now

        val yPlane = img.planes.firstOrNull() ?: return
        val buf = yPlane.buffer
        val rowStride = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val fullW = img.width
        val fullH = img.height

        // If BYD AVM 4-quadrant stream is enabled, restrict to top-left front quadrant
        val quad = LeadCarDeparturePreferences.avmFrontQuadrant(app)
        val regionW = if (quad) fullW / 2 else fullW
        val regionH = if (quad) fullH / 2 else fullH

        // Center-front ROI: 28%..72% X, 32%..76% Y (where lead car bumper/rear sits)
        val x0 = (regionW * 0.28f).toInt()
        val x1 = (regionW * 0.72f).toInt()
        val y0 = (regionH * 0.32f).toInt()
        val y1 = (regionH * 0.76f).toInt()

        val gridCols = 8
        val gridRows = 6
        val blocks = FloatArray(gridCols * gridRows)
        val cellW = ((x1 - x0) / gridCols).coerceAtLeast(1)
        val cellH = ((y1 - y0) / gridRows).coerceAtLeast(1)

        var roiMean = 0f
        var idx = 0
        for (gr in 0 until gridRows) {
            val py0 = y0 + gr * cellH
            for (gc in 0 until gridCols) {
                val px0 = x0 + gc * cellW
                var sum = 0
                var cnt = 0
                var y = py0
                while (y < py0 + cellH && y < fullH) {
                    var x = px0
                    while (x < px0 + cellW && x < fullW) {
                        val pos = y * rowStride + x * pixelStride
                        if (pos in 0 until buf.limit()) {
                            sum += buf.get(pos).toInt() and 0xFF
                            cnt++
                        }
                        x += 2
                    }
                    y += 2
                }
                val avg = if (cnt > 0) sum.toFloat() / cnt else 0f
                blocks[idx++] = avg
                roiMean += avg
            }
        }
        roiMean /= blocks.size

        // Normalize out global lighting shift (clouds/headlights/traffic light flicker)
        for (i in blocks.indices) blocks[i] -= roiMean

        val base = baselineCenter
        if (base == null) {
            baselineCenter = blocks
            baselineFrames = 1
            lastStatus = "전방 기준 프레임 학습 중…"
            return
        }
        if (baselineFrames < 4) {
            for (i in base.indices) base[i] = (base[i] * baselineFrames + blocks[i]) / (baselineFrames + 1)
            baselineFrames++
            return
        }

        // Compute normalized block SAD against settled stopped baseline
        var diffSum = 0f
        var changedCells = 0
        for (i in blocks.indices) {
            val d = abs(blocks[i] - base[i])
            diffSum += d
            if (d > 10f) changedCells++
        }
        val meanDiff = diffSum / blocks.size
        val changedRatio = changedCells.toFloat() / blocks.size

        val (diffThresh, ratioThresh) = when (LeadCarDeparturePreferences.sensitivity(app)) {
            0 -> 14.5f to 0.34f // 둔감
            2 -> 8.5f to 0.22f  // 민감
            else -> 11.2f to 0.28f // 보통
        }

        lastStatus = "감시 중 · 변화=${"%.1f".format(meanDiff)} / 활성셀=${(changedRatio * 100).toInt()}%"

        if (meanDiff >= diffThresh && changedRatio >= ratioThresh) {
            consecutiveHits++
            if (consecutiveHits >= 3) {
                consecutiveHits = 0
                // Refresh baseline so we don't fire repeatedly on the same departure
                baselineCenter = blocks
                val detail = "meanDiff=${"%.1f".format(meanDiff)} ratio=${"%.2f".format(changedRatio)} avmQuad=$quad"
                CoreLog.i("LEAD_CAM", "CAMERA_DEPARTURE_DETECTED $detail")
                onCameraDeparture(meanDiff, detail)
            }
        } else {
            consecutiveHits = 0
            // Slow exponential drift adaptation when stationary
            for (i in base.indices) base[i] = base[i] * 0.94f + blocks[i] * 0.06f
        }
    }
}
