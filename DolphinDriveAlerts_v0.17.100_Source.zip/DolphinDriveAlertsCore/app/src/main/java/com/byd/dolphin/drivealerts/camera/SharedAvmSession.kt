package com.byd.dolphin.drivealerts.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.view.Surface
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Single Shared BYD AVMCamera Session Hub (v0.17.97):
 * Guarantees that ONLY ONE BydAvmCameraBackend + GlLutDewarpRenderer is open app-wide so:
 * 1. Dashcam recording NEVER drops a frame when the turn-signal BSD BVM overlay appears (0ms attach).
 * 2. Encoder EGL surface is bound BEFORE MediaRecorder.start() is invoked inside onReady(true).
 * 3. Reverse gear immediately yields the hardware session to BYD stock 360 surround view.
 */
object SharedAvmSession {
    enum class Client { DASHCAM, BSD_OVERLAY, LEAD_ONDEMAND, SENTRY }

    private val lock = Any()
    private var backend: BydAvmCameraBackend? = null
    private var renderer: GlLutDewarpRenderer? = null
    private val activeClients = mutableSetOf<Client>()
    @Volatile private var reverseYielded = false
    @Volatile private var sessionOpen = false

    private var encoderSurface: Surface? = null
    private var encW = 1280
    private var encH = 720

    private var displaySurface: Surface? = null
    private var dispW = 480
    private var dispH = 290
    private var dispParams: GlLutDewarpRenderer.Params = GlLutDewarpRenderer.Params()

    private var analysisGate: () -> Boolean = { false }
    private var onAnalysisBitmap: ((Bitmap) -> Unit)? = null

    fun isAvailable(context: Context): Boolean = ensureBackend(context).probe().available
    fun probeDetail(context: Context): String = ensureBackend(context).probe().detail
    fun isSessionOpen(): Boolean = sessionOpen && !reverseYielded
    fun encoderFramesWritten(): Long = renderer?.encoderFramesWritten ?: 0L

    fun setAnalysisConsumer(gate: () -> Boolean, consumer: (Bitmap) -> Unit) {
        synchronized(lock) {
            analysisGate = gate
            onAnalysisBitmap = consumer
            renderer?.setAnalysisConsumer(gate, consumer)
        }
    }

    /** Immediately release BYD AVMCamera when Reverse gear engages so stock 360 view never conflicts. */
    fun setReverseYield(reverse: Boolean) {
        synchronized(lock) {
            if (reverseYielded == reverse) return
            reverseYielded = reverse
            if (reverse) {
                closeInternal("reverse_gear_yield")
            }
        }
    }

    fun attachDashcam(context: Context, surface: Surface, width: Int, height: Int, onReady: (Boolean, String) -> Unit) {
        synchronized(lock) {
            if (reverseYielded) { onReady(false, "후진 기어 양보 중"); return }
            encoderSurface = surface
            encW = width
            encH = height
            activeClients.add(Client.DASHCAM)
            val existingRenderer = renderer
            if (sessionOpen && existingRenderer != null) {
                existingRenderer.attachEncoderSurface(surface, width, height) { ok ->
                    onReady(ok, if (ok) "공용 AVM 세션에 블랙박스 인코더 연결됨 (무끊김)" else "EGL 인코더 서피스 바인딩 실패")
                }
                return
            }
            openInternal(context, onReady)
        }
    }

    fun detachDashcam() {
        synchronized(lock) {
            activeClients.remove(Client.DASHCAM)
            encoderSurface = null
            renderer?.detachEncoderSurface()
            if (activeClients.isEmpty()) closeInternal("dashcam_detached")
        }
    }

    fun attachBsdDisplay(
        context: Context,
        surface: Surface,
        width: Int,
        height: Int,
        params: GlLutDewarpRenderer.Params,
        onReady: (Boolean, String) -> Unit
    ) {
        synchronized(lock) {
            if (reverseYielded) { onReady(false, "후진 기어 양보 중"); return }
            displaySurface = surface
            dispW = width
            dispH = height
            dispParams = params
            activeClients.add(Client.BSD_OVERLAY)
            if (sessionOpen && renderer != null) {
                renderer?.updateParams(params)
                renderer?.attachDisplaySurface(surface, width, height)
                onReady(true, "공용 AVM 세션에 후측방 BVM 0ms 연결됨 (블랙박스 유지)")
                return
            }
            openInternal(context, onReady)
        }
    }

    fun detachBsdDisplay() {
        synchronized(lock) {
            activeClients.remove(Client.BSD_OVERLAY)
            displaySurface = null
            renderer?.detachDisplaySurface()
            if (activeClients.isEmpty()) closeInternal("bsd_detached")
        }
    }

    fun acquireLeadOnDemand(context: Context) {
        synchronized(lock) {
            if (reverseYielded || !isAvailable(context)) return
            activeClients.add(Client.LEAD_ONDEMAND)
            if (!sessionOpen) openInternal(context) { _, _ -> }
        }
    }

    fun releaseLeadOnDemand() {
        synchronized(lock) {
            activeClients.remove(Client.LEAD_ONDEMAND)
            if (activeClients.isEmpty()) closeInternal("lead_ondemand_released")
        }
    }

    fun acquireSentry(context: Context) {
        synchronized(lock) {
            if (reverseYielded || !isAvailable(context)) return
            activeClients.add(Client.SENTRY)
            if (!sessionOpen) openInternal(context) { _, _ -> }
        }
    }

    fun releaseSentry() {
        synchronized(lock) {
            activeClients.remove(Client.SENTRY)
            if (activeClients.isEmpty()) closeInternal("sentry_released")
        }
    }

    fun shutdown() {
        synchronized(lock) {
            activeClients.clear()
            encoderSurface = null
            displaySurface = null
            closeInternal("shutdown")
        }
    }

    /** Lightweight L/R quadrant headlight/motion energy comparison on a 320x240 quad bitmap. */
    fun compareLeftRightEnergy(quadBmp: Bitmap): Pair<Side, String> {
        val w = quadBmp.width
        val h = quadBmp.height
        if (w < 64 || h < 48) return Side.UNKNOWN to "small"
        // BYD 5120x960 4x1 strip: Front=0..w/4, Rear=w/4..w/2, Right=w/2..3w/4, Left=3w/4..w
        val rightEnergy = regionEnergy(quadBmp, w / 2 + 6, 12, (w * 3) / 4 - 6, h - 12)
        val leftEnergy = regionEnergy(quadBmp, (w * 3) / 4 + 6, 12, w - 6, h - 12)
        val diff = leftEnergy - rightEnergy
        val side = when {
            diff > 14f -> Side.LEFT
            diff < -14f -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        return side to "L=${"%.1f".format(leftEnergy)} R=${"%.1f".format(rightEnergy)}"
    }

    private fun regionEnergy(bmp: Bitmap, x0: Int, y0: Int, x1: Int, y1: Int): Float {
        var acc = 0f
        var cnt = 0
        var prev = -1
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val px = bmp.getPixel(x, y)
                val luma = (Color.red(px) * 3 + Color.green(px) * 6 + Color.blue(px)) / 10
                if (prev >= 0) acc += kotlin.math.abs(luma - prev)
                if (luma > 215) acc += 18f
                prev = luma
                cnt++
                x += 4
            }
            y += 4
        }
        return if (cnt > 0) acc / cnt else 0f
    }

    private fun ensureBackend(context: Context): BydAvmCameraBackend {
        backend?.let { return it }
        return BydAvmCameraBackend(context.applicationContext).also { backend = it }
    }

    private fun openInternal(context: Context, onReady: (Boolean, String) -> Unit) {
        val b = ensureBackend(context)
        val r = GlLutDewarpRenderer("SHARED_AVM").apply {
            updateParams(dispParams)
            setAnalysisConsumer(analysisGate, onAnalysisBitmap)
        }
        renderer = r
        r.start(
            outputWindowSurface = displaySurface,
            outputWidth = dispW,
            outputHeight = dispH,
            onInputSurfaceReady = { inputSurf ->
                val encSurf = synchronized(lock) { encoderSurface }
                val proceedOpen: () -> Unit = {
                    val (ok, msg) = b.openAvm(inputSurf)
                    synchronized(lock) {
                        sessionOpen = ok
                        if (!ok) closeInternal("open_failed")
                    }
                    onReady(ok, msg)
                }
                if (encSurf != null) {
                    r.attachEncoderSurface(encSurf, encW, encH) { _ -> proceedOpen() }
                } else {
                    proceedOpen()
                }
            },
            onError = { err ->
                synchronized(lock) { closeInternal("gl_error") }
                onReady(false, err)
            }
        )
    }

    private fun closeInternal(reason: String) {
        sessionOpen = false
        runCatching { backend?.close() }
        runCatching { renderer?.release() }
        renderer = null
        CoreLog.i("SHARED_AVM", "closed reason=$reason")
    }
}
