package com.byd.dolphin.drivealerts.dock

import android.content.Context
import android.provider.Settings
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Controls BYD DiLink 3 stock system bars (status bar / navigation bottom bar) via
 * Settings.Global policy_control (direct WRITE_SECURE_SETTINGS or authorized local ADB fallback).
 */
object SystemBarController {
    const val MODE_STOCK = 0
    const val MODE_HIDE_STATUS = 1
    const val MODE_HIDE_NAV = 2
    const val MODE_HIDE_BOTH = 3

    val modeLabels = listOf(
        "순정 표시 (상단바 + 하단바 모두 표시)",
        "상단바만 숨김 (immersive.status=*)",
        "하단바만 숨김 (immersive.navigation=*)",
        "상·하단바 완전 숨김 (immersive.full=*)"
    )

    private fun policyValueFor(mode: Int): String = when (mode) {
        MODE_HIDE_STATUS -> "immersive.status=*"
        MODE_HIDE_NAV -> "immersive.navigation=*"
        MODE_HIDE_BOTH -> "immersive.full=*"
        else -> "null*"
    }

    /** Apply mode on a worker thread (or immediately if direct WRITE_SECURE_SETTINGS succeeds). */
    fun apply(context: Context, mode: Int, onDone: ((Boolean, String) -> Unit)? = null) {
        val app = context.applicationContext
        val policy = policyValueFor(mode)
        DockPreferences.setSystemBarMode(app, mode)

        // 1. Direct Settings.Global attempt (instant when WRITE_SECURE_SETTINGS is granted)
        val directOk = runCatching {
            if (mode == MODE_STOCK) {
                Settings.Global.putString(app.contentResolver, "policy_control", null)
            } else {
                Settings.Global.putString(app.contentResolver, "policy_control", policy)
            }
            true
        }.getOrDefault(false)

        if (directOk) {
            val msg = "시스템바 적용됨 (직접 설정): ${modeLabels.getOrElse(mode) { "" }}"
            CoreLog.i("SYS_BAR", msg)
            onDone?.invoke(true, msg)
            return
        }

        // 2. Authorized local ADB shell fallback
        Thread {
            val cmd = if (mode == MODE_STOCK) {
                "settings delete global policy_control"
            } else {
                "settings put global policy_control '$policy'"
            }
            val report = AuthorizedAdbRuntime.writeOnce(app, cmd)
            val ok = report.result.success
            val msg = if (ok) {
                "시스템바 적용됨 (로컬 ADB): ${modeLabels.getOrElse(mode) { "" }}"
            } else {
                "적용 실패 (${report.state}): [권한 · ADB]에서 로컬 ADB 연결을 확인해 주세요."
            }
            CoreLog.i("SYS_BAR", msg)
            onDone?.invoke(ok, msg)
        }.start()
    }
}
