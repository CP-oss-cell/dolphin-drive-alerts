package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Stabilized Ignition Auto-Launch Sequence Engine (v0.17.68):
 * - 15s duplicate-trigger cooldown instead of dropping valid ACC_ON/BOOT triggers on requestId mismatch.
 * - ADB-independent Android Launcher fallback for regular apps so boot auto-launch works even if
 *   local ADB (:5555) is still warming up after ignition.
 * - Post-sequence Verify & Heal pass (3.5s after finish): if BYD stock launcher hijacked foreground
 *   during late boot settle, re-brings the final target app or split profile automatically once.
 */
class AutoLaunchSequenceService : Service() {
    @Volatile private var generation = 0
    @Volatile private var lastAutoStartMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val m = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            m.createNotificationChannel(
                NotificationChannel("app_sequence", "차량 앱 자동 실행", NotificationManager.IMPORTANCE_LOW)
            )
        }
        startForeground(
            763,
            Notification.Builder(this, "app_sequence")
                .setContentTitle("시동 앱 실행 시퀀스")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            generation++
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_RUN) return START_NOT_STICKY

        val manual = intent.getBooleanExtra("manual", false)
        val enabled = FeatureProfiles.sequenceEnabled(this)
        val stepList = FeatureProfiles.steps(this).filter { it.enabled }
        CoreLog.i("AUTO_SEQUENCE", "REQUEST_RECEIVED source=${if (manual) "MANUAL" else "IGNITION"} enabled=$enabled stepCount=${stepList.size}")
        IgnitionAuditJournal.record(this, "SEQUENCE_SERVICE_RECEIVED", "manual=$manual enabled=$enabled steps=${stepList.size}")

        if (!manual) {
            val now = System.currentTimeMillis()
            if (now - lastAutoStartMs < DUP_WINDOW_MS) {
                CoreLog.i("AUTO_SEQUENCE", "DEDUP_SKIPPED within=${DUP_WINDOW_MS}ms")
                return START_NOT_STICKY
            }
            // Acknowledge alarm request if present, but never silently drop a valid ignition trigger
            runCatching { IgnitionSequenceAlarmReceiver.acknowledge(this, intent.getStringExtra("request_id")) }
            lastAutoStartMs = now
        }

        if (!manual && !enabled) {
            IgnitionAuditJournal.record(this, "SEQUENCE_SERVICE_INELIGIBLE", "disabled")
            getSharedPreferences("ignition_sequence_guard", MODE_PRIVATE).edit().putBoolean("armed", true).commit()
            stopSelf()
            return START_NOT_STICKY
        }
        if (stepList.isEmpty()) {
            IgnitionAuditJournal.record(this, "SEQUENCE_SERVICE_INELIGIBLE", "noEnabledSteps")
            if (!manual) getSharedPreferences("ignition_sequence_guard", MODE_PRIVATE).edit().putBoolean("armed", true).commit()
            stopSelf()
            return START_NOT_STICKY
        }

        val seq = ++generation
        Thread({ runSteps(stepList, seq, manual) }, "dolphin-autostart-sequence").start()
        return START_NOT_STICKY
    }

    private fun runSteps(steps: List<LaunchStep>, seq: Int, manual: Boolean) {
        val power = getSystemService(PowerManager::class.java)
        val lock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DriveAlerts:LaunchSequence")
        var lastForegroundTargetPkg: String? = null
        var lastSplitProfile: SplitProfile? = null

        try {
            lock.acquire(600_000L)
            val launchStart = System.currentTimeMillis()
            CoreLog.i("AUTO_SEQUENCE", "SEQUENCE_START source=${if (manual) "MANUAL" else "IGNITION"} steps=${steps.size}")
            IgnitionAuditJournal.record(this, "SEQUENCE_WORK_STARTED", "manual=$manual steps=${steps.size}")

            for ((stepIndex, step) in steps.withIndex()) {
                if (seq != generation || System.currentTimeMillis() - launchStart > 600_000L) break
                IgnitionAuditJournal.record(this, "STEP_ATTEMPT", "index=${stepIndex + 1} pkg=${step.packageName}")
                if (!pause(step.delaySeconds, seq)) break

                // Background-only media step
                if (step.isMedia && step.restoreBackground) {
                    var playing = MediaPlaybackObserver.playWithoutUi(this, step.packageName)
                    if (!playing) {
                        launchAppWithFallback(step.packageName, seq, waitAdbMs = 8_000L)
                        if (!pause(step.playDelaySeconds.coerceAtLeast(2), seq)) break
                        repeat(3) {
                            if (!playing && seq == generation) {
                                playing = MediaPlaybackObserver.play(this, step.packageName)
                                if (!playing) try { Thread.sleep(750L) } catch (_: InterruptedException) {}
                            }
                        }
                    }
                    if (!playing && seq == generation) {
                        playing = playFocusedMediaKey(step.packageName, manual)
                    }
                    if (playing) {
                        val adb = AuthorizedAdbRuntime.health(this)
                        if (adb.state == AuthorizedAdbRuntime.State.READY) {
                            AuthorizedAdbRuntime.writeOnce(this, "input keyevent 3")
                        }
                    }
                    continue
                }

                // Split-screen step (requires ADB)
                if (step.packageName.startsWith("split:")) {
                    val auth = AuthorizedAdbRuntime.awaitReady(this, 18_000L) { seq != generation }
                    if (auth.state != AuthorizedAdbRuntime.State.READY) {
                        CoreLog.w("AUTO_SEQUENCE", "SPLIT_STEP_BLOCKED_ADB state=${auth.state}")
                        continue
                    }
                    val foreground = AutoSplitBehaviorEngine.screenToken(this).orEmpty()
                    if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground)) {
                        CoreLog.w("AUTO_SEQUENCE", "SPLIT_SKIPPED_CAMERA_FOREGROUND")
                        continue
                    }
                    val profileId = step.packageName.removePrefix("split:")
                    val profile = FeatureProfiles.splits(this).firstOrNull { it.id == profileId } ?: continue
                    val result = AutoSplitBehaviorEngine.launch(this, profile)
                    CoreLog.i("AUTO_SEQUENCE", "split=${profile.title} success=${result.success} result=${result.message}")
                    if (result.success) {
                        lastSplitProfile = profile
                        lastForegroundTargetPkg = null
                        SplitRecoveryService.start(this, profile.id)
                    }
                    continue
                }

                // Existing media session reuse
                if (step.isMedia && MediaPlaybackObserver.playExisting(this, step.packageName)) {
                    CoreLog.i("AUTO_SEQUENCE", "MEDIA_BACKGROUND_REUSED pkg=${step.packageName}")
                    continue
                }

                // Regular app launch: ADB preferred, Android Launcher Intent automatic fallback!
                val launched = launchAppWithFallback(step.packageName, seq, waitAdbMs = 6_000L)
                if (!launched) continue

                if (!step.restoreBackground) {
                    lastForegroundTargetPkg = step.packageName
                    lastSplitProfile = null
                }

                var mediaPlaying = !step.isMedia
                if (step.isMedia) {
                    if (!pause(step.playDelaySeconds, seq)) break
                    mediaPlaying = MediaPlaybackObserver.play(this, step.packageName)
                    if (!mediaPlaying) mediaPlaying = playFocusedMediaKey(step.packageName, manual)
                }
                if (step.restoreBackground && mediaPlaying) {
                    if (AuthorizedAdbRuntime.health(this).state == AuthorizedAdbRuntime.State.READY) {
                        AuthorizedAdbRuntime.writeOnce(this, "input keyevent 3")
                    }
                }
            }

            // Post-Launch Verify & Heal pass: defend against late BYD stock launcher hijack after boot
            if (seq == generation && (lastForegroundTargetPkg != null || lastSplitProfile != null)) {
                if (pause(3, seq)) {
                    verifyAndHealFinalForeground(lastForegroundTargetPkg, lastSplitProfile, seq)
                }
            }
        } catch (t: Throwable) {
            CoreLog.w("AUTO_SEQUENCE", "sequence failure: ${t.message}")
            IgnitionAuditJournal.record(this, "SEQUENCE_WORK_FAILED", "type=${t.javaClass.simpleName}")
        } finally {
            IgnitionAuditJournal.record(this, "SEQUENCE_WORK_FINISHED", "manual=$manual")
            if (lock.isHeld) lock.release()
            if (seq == generation) stopSelf()
        }
    }

    /** Launch via ADB am start if READY, otherwise immediately fall back to Android Launcher Intent. */
    private fun launchAppWithFallback(pkg: String, seq: Int, waitAdbMs: Long): Boolean {
        val component = AppSelection.safeComponent(this, pkg)
        val adb = AuthorizedAdbRuntime.awaitReady(this, waitAdbMs) { seq != generation }
        if (adb.state == AuthorizedAdbRuntime.State.READY && component != null) {
            val fg = AutoSplitBehaviorEngine.screenToken(this).orEmpty()
            if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(fg)) {
                CoreLog.w("AUTO_SEQUENCE", "OEM camera foreground; skipped $pkg")
                return false
            }
            val r = AuthorizedAdbRuntime.writeOnce(this, "am start --user 0 -n '$component'", timeoutMs = 9_000L).result
            if (r.success) {
                CoreLog.i("AUTO_SEQUENCE", "ADB_LAUNCH_OK pkg=$pkg")
                return true
            }
        }
        // Fallback: direct Android Launcher Intent (works even without ADB :5555!)
        return runCatching {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: error("no launch intent")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(intent)
            CoreLog.i("AUTO_SEQUENCE", "ANDROID_INTENT_LAUNCH_OK pkg=$pkg (adb=${adb.state})")
            true
        }.onFailure {
            CoreLog.w("AUTO_SEQUENCE", "LAUNCH_FAILED pkg=$pkg err=${it.message}")
        }.getOrDefault(false)
    }

    /** If BYD stock launcher took over foreground after boot settle, re-bring final target once. */
    private fun verifyAndHealFinalForeground(targetPkg: String?, splitProfile: SplitProfile?, seq: Int) {
        if (seq != generation) return
        if (AuthorizedAdbRuntime.health(this).state != AuthorizedAdbRuntime.State.READY) return
        val top = AutoSplitBehaviorEngine.screenToken(this).orEmpty()
        if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(top)) return

        if (splitProfile != null) {
            val hasFirst = top.contains(splitProfile.firstPackage)
            val hasSecond = top.contains(splitProfile.secondPackage)
            if (!hasFirst && !hasSecond) {
                CoreLog.w("AUTO_SEQUENCE", "VERIFY_HEAL_SPLIT re-launching ${splitProfile.title} (top=${top.take(120)})")
                AutoSplitBehaviorEngine.launch(this, splitProfile)
            }
            return
        }
        if (targetPkg != null && !top.contains(targetPkg)) {
            val isLauncher = Regex("(?i)(launcher|byd\\.home|systemui)").containsMatchIn(top)
            if (isLauncher || top.isBlank()) {
                CoreLog.w("AUTO_SEQUENCE", "VERIFY_HEAL_APP re-bringing $targetPkg (top=${top.take(120)})")
                launchAppWithFallback(targetPkg, seq, waitAdbMs = 2_000L)
            }
        }
    }

    private fun playFocusedMediaKey(pkg: String, manual: Boolean): Boolean {
        val top = AutoSplitBehaviorEngine.screenToken(this).orEmpty()
        if (!top.contains("$pkg/")) return false
        if (AuthorizedAdbRuntime.health(this).state != AuthorizedAdbRuntime.State.READY) return false
        val sent = AuthorizedAdbRuntime.writeOnce(this, "input keyevent 126", timeoutMs = 5_000L).result
        if (!sent.success) return false
        try { Thread.sleep(1_100L) } catch (_: InterruptedException) {}
        return MediaPlaybackObserver.isPlaybackActive(this, pkg)
    }

    private fun pause(seconds: Int, seq: Int): Boolean {
        repeat(seconds.coerceIn(0, 600)) {
            if (generation != seq) return false
            try { Thread.sleep(1000) } catch (_: InterruptedException) { return false }
        }
        return generation == seq
    }

    override fun onDestroy() {
        generation++
        super.onDestroy()
    }

    companion object {
        private const val DUP_WINDOW_MS = 15_000L
        const val ACTION_RUN = "com.byd.dolphin.drivealerts.AUTO_SEQUENCE_RUN"
        const val ACTION_CANCEL = "com.byd.dolphin.drivealerts.AUTO_SEQUENCE_CANCEL"

        fun start(context: Context, manual: Boolean = false, requestId: String? = null): Boolean {
            return try {
                context.startForegroundService(
                    Intent(context, AutoLaunchSequenceService::class.java)
                        .setAction(ACTION_RUN)
                        .putExtra("manual", manual)
                        .putExtra("request_id", requestId)
                )
                true
            } catch (t: Throwable) {
                CoreLog.w("AUTO_SEQUENCE", "START_REQUEST_REJECTED ${t.javaClass.simpleName}: ${t.message}")
                false
            }
        }
    }
}
