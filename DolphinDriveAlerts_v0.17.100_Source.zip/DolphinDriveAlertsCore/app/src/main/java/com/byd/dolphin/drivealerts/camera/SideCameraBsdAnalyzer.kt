package com.byd.dolphin.drivealerts.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.util.CoreLog
import kotlin.math.abs

/**
 * Event-triggered Camera2 side-ROI analyzer for BSD Left vs Right disambiguation.
 * - Does NOT stay open continuously during normal driving; arms briefly on BSD/blinker activity
 *   and auto-releases after a short burst window (4s) or immediately on reverse gear.
 * - Compares frame-to-frame normalized motion + edge energy between Left and Right side ROIs.
 */
class SideCameraBsdAnalyzer(context: Context) {
    private val app = context.applicationContext
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var imageReader: ImageReader? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null

    @Volatile private var running = false
    @Volatile private var stopAtMs = 0L
    @Volatile private var lastProcessedMs = 0L

    private var prevLeft: FloatArray? = null
    private var prevRight: FloatArray? = null

    @Volatile var lastInferredSide: Side = Side.UNKNOWN
        private set
    @Volatile var lastInferredMs: Long = 0L
        private set
    @Volatile var lastDetail: String = "idle"
        private set

    /** Consume a shared YUV frame from VehicleCameraHub without opening a second Camera2 device. */
    fun acceptExternalImage(img: Image) {
        analyzePair(img)
    }

    fun triggerWindow(durationMs: Long = 4_000L) {
        stopAtMs = System.currentTimeMillis() + durationMs
        if (running) return
        if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            lastDetail = "no_camera_permission"
            return
        }
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
        val ids = runCatching { cm.cameraIdList.toList() }.getOrDefault(emptyList())
        val req = BsdSideInferencePreferences.cameraId(app)
        val camId = if (req in ids) req else ids.firstOrNull() ?: return

        running = true
        prevLeft = null
        prevRight = null

        val ht = HandlerThread("bsd-side-cam").apply { start() }
        val h = Handler(ht.looper)
        thread = ht
        handler = h

        val reader = ImageReader.newInstance(320, 240, ImageFormat.YUV_420_888, 2)
        reader.setOnImageAvailableListener({ r ->
            val img = runCatching { r.acquireLatestImage() }.getOrNull() ?: return@setOnImageAvailableListener
            try {
                if (!running || System.currentTimeMillis() > stopAtMs) {
                    stop()
                } else {
                    analyzePair(img)
                }
            } catch (t: Throwable) {
                CoreLog.w("BSD_SIDE_CAM", "analyze error: ${t.message}")
            } finally {
                runCatching { img.close() }
            }
        }, h)
        imageReader = reader

        runCatching {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    if (!running) { runCatching { camera.close() }; return }
                    cameraDevice = camera
                    startSession(camera, reader, h)
                }
                override fun onDisconnected(camera: CameraDevice) { stop() }
                override fun onError(camera: CameraDevice, error: Int) { stop() }
            }, h)
        }.onFailure {
            lastDetail = "open_failed:${it.javaClass.simpleName}"
            stop()
        }
    }

    @Suppress("DEPRECATION")
    private fun startSession(camera: CameraDevice, reader: ImageReader, h: Handler) {
        runCatching {
            val surface = reader.surface
            val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(surface) }
            camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    if (!running) { runCatching { session.close() }; return }
                    captureSession = session
                    runCatching { session.setRepeatingRequest(req.build(), null, h) }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) { stop() }
            }, h)
        }.onFailure { stop() }
    }

    fun stop() {
        running = false
        prevLeft = null
        prevRight = null
        runCatching { captureSession?.stopRepeating() }
        runCatching { captureSession?.close() }
        captureSession = null
        runCatching { cameraDevice?.close() }
        cameraDevice = null
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { thread?.quitSafely() }
        thread = null
        handler = null
    }

    fun recentSide(nowMs: Long = System.currentTimeMillis(), maxAgeMs: Long = 2_500L): Pair<Side, String> {
        return if (nowMs - lastInferredMs <= maxAgeMs && lastInferredSide != Side.UNKNOWN) {
            lastInferredSide to lastDetail
        } else {
            Side.UNKNOWN to "stale_or_none"
        }
    }

    private fun analyzePair(img: Image) {
        val now = System.currentTimeMillis()
        if (now - lastProcessedMs < 160L) return
        lastProcessedMs = now

        val yPlane = img.planes.firstOrNull() ?: return
        val buf = yPlane.buffer
        val rowStride = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val w = img.width
        val h = img.height

        val isAvmQuad = BsdSideInferencePreferences.layout(app) == 0
        // BYD 4-quadrant AVM: bottom-left = left side cam, bottom-right = right side cam
        // Half-split layout: left half = left side cam, right half = right side cam
        val yStart = if (isAvmQuad) (h * 0.56f).toInt() else (h * 0.25f).toInt()
        val yEnd = if (isAvmQuad) (h * 0.94f).toInt() else (h * 0.85f).toInt()

        val leftBlocks = sampleNormalizedGrid(buf, rowStride, pixelStride, w, h, (w * 0.06f).toInt(), (w * 0.44f).toInt(), yStart, yEnd)
        val rightBlocks = sampleNormalizedGrid(buf, rowStride, pixelStride, w, h, (w * 0.56f).toInt(), (w * 0.94f).toInt(), yStart, yEnd)

        val pL = prevLeft
        val pR = prevRight
        prevLeft = leftBlocks
        prevRight = rightBlocks
        if (pL == null || pR == null) return

        val leftEnergy = meanAbsDiff(leftBlocks, pL)
        val rightEnergy = meanAbsDiff(rightBlocks, pR)

        val minEnergy = 6.5f
        val side = when {
            leftEnergy >= minEnergy && leftEnergy >= rightEnergy * 1.35f -> Side.LEFT
            rightEnergy >= minEnergy && rightEnergy >= leftEnergy * 1.35f -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        if (side != Side.UNKNOWN) {
            lastInferredSide = side
            lastInferredMs = now
            lastDetail = "camL=${"%.1f".format(leftEnergy)} camR=${"%.1f".format(rightEnergy)}"
        }
    }

    private fun sampleNormalizedGrid(
        buf: java.nio.ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        fullW: Int,
        fullH: Int,
        x0: Int,
        x1: Int,
        y0: Int,
        y1: Int
    ): FloatArray {
        val cols = 6
        val rows = 4
        val out = FloatArray(cols * rows)
        val cw = ((x1 - x0) / cols).coerceAtLeast(1)
        val ch = ((y1 - y0) / rows).coerceAtLeast(1)
        var mean = 0f
        var idx = 0
        for (r in 0 until rows) {
            val py0 = y0 + r * ch
            for (c in 0 until cols) {
                val px0 = x0 + c * cw
                var sum = 0
                var cnt = 0
                var y = py0
                while (y < py0 + ch && y < fullH) {
                    var x = px0
                    while (x < px0 + cw && x < fullW) {
                        val pos = y * rowStride + x * pixelStride
                        if (pos in 0 until buf.limit()) {
                            sum += buf.get(pos).toInt() and 0xFF
                            cnt++
                        }
                        x += 2
                    }
                    y += 2
                }
                val v = if (cnt > 0) sum.toFloat() / cnt else 0f
                out[idx++] = v
                mean += v
            }
        }
        mean /= out.size
        for (i in out.indices) out[i] -= mean
        return out
    }

    private fun meanAbsDiff(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += abs(a[i] - b[i])
        return s / a.size
    }
}
