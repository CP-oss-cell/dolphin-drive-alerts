package com.byd.dolphin.drivealerts.notify

import android.content.Context
import android.graphics.Bitmap
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Zero-dependency Telegram Bot API Client (v0.17.71):
 * - Uses standard HttpURLConnection on a single background executor (zero APK/RAM bloat).
 * - Supports sendMessage, sendPhoto (JPEG multipart upload for Sentry 4-quadrant snapshots),
 *   and findLatestChatId() via getUpdates so users don't have to look up numeric Chat IDs manually.
 */
object TelegramNotifier {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "dolphin-telegram") }
    @Volatile var lastResultText: String = "대기 중"
        private set

    private fun stamp(): String = SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(Date())

    fun sendTextAsync(context: Context, title: String, body: String) {
        val app = context.applicationContext
        if (!TelegramPreferences.isConfigured(app)) return
        val token = TelegramPreferences.botToken(app)
        val chatId = TelegramPreferences.chatId(app)
        executor.execute {
            val msg = "[$title · ${stamp()}]\n$body"
            val (ok, res) = sendMessageSync(token, chatId, msg)
            lastResultText = if (ok) "전송 완료 (${stamp()})" else "전송 실패: $res"
        }
    }

    fun sendPhotoAsync(context: Context, caption: String, jpegBytes: ByteArray?) {
        val app = context.applicationContext
        if (!TelegramPreferences.isConfigured(app)) return
        val token = TelegramPreferences.botToken(app)
        val chatId = TelegramPreferences.chatId(app)
        executor.execute {
            val fullCaption = "[${stamp()}] $caption"
            val (ok, res) = if (jpegBytes != null && jpegBytes.isNotEmpty()) {
                sendPhotoSync(token, chatId, fullCaption, jpegBytes)
            } else {
                sendMessageSync(token, chatId, fullCaption)
            }
            lastResultText = if (ok) "사진 알림 전송 완료 (${stamp()})" else "사진 전송 실패: $res"
        }
    }

    fun compressBitmapToJpeg(bmp: Bitmap?, quality: Int = 82): ByteArray? {
        if (bmp == null || bmp.isRecycled) return null
        return runCatching {
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(40, 95), baos)
            baos.toByteArray()
        }.getOrNull()
    }

    fun testConnection(context: Context, onResult: (Boolean, String) -> Unit) {
        val app = context.applicationContext
        val token = TelegramPreferences.botToken(app)
        val chatId = TelegramPreferences.chatId(app)
        if (token.isBlank() || chatId.isBlank()) {
            onResult(false, "봇 토큰과 Chat ID를 먼저 입력해 주세요.")
            return
        }
        executor.execute {
            val (ok, msg) = sendMessageSync(
                token,
                chatId,
                "[돌핀 주행보조 알림 테스트 · ${stamp()}]\n텔레그램 실시간 알림이 정상 연결되었습니다."
            )
            lastResultText = if (ok) "테스트 성공 (${stamp()})" else "테스트 실패: $msg"
            onResult(ok, if (ok) "텔레그램 테스트 메시지 전송 성공!" else "전송 실패: $msg")
        }
    }

    /** Auto-discover numeric Chat ID from recent bot messages via /getUpdates. */
    fun findLatestChatId(context: Context, onResult: (Boolean, String, String?) -> Unit) {
        val app = context.applicationContext
        val token = TelegramPreferences.botToken(app)
        if (token.isBlank()) {
            onResult(false, "먼저 봇 토큰(Bot Token)을 입력해 주세요.", null)
            return
        }
        executor.execute {
            val res = runCatching {
                val url = URL("https://api.telegram.org/bot$token/getUpdates?limit=10")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    requestMethod = "GET"
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                if (code !in 200..299) return@runCatching Triple(false, "HTTP $code: 토큰 확인 필요", null)
                val json = JSONObject(body)
                val arr = json.optJSONArray("result")
                if (arr == null || arr.length() == 0) {
                    return@runCatching Triple(false, "최근 메시지가 없습니다. 텔레그램에서 내 봇에게 '안녕'을 한 번 보낸 뒤 다시 눌러주세요.", null)
                }
                var foundId: String? = null
                var senderName = ""
                for (i in arr.length() - 1 downTo 0) {
                    val item = arr.optJSONObject(i) ?: continue
                    val msg = item.optJSONObject("message") ?: item.optJSONObject("channel_post") ?: continue
                    val chat = msg.optJSONObject("chat") ?: continue
                    val id = chat.optLong("id", 0L)
                    if (id != 0L) {
                        foundId = id.toString()
                        senderName = chat.optString("first_name").ifBlank { chat.optString("title") }
                        break
                    }
                }
                if (foundId != null) {
                    Triple(true, "Chat ID 찾음: $foundId ${if (senderName.isNotBlank()) "($senderName)" else ""}", foundId)
                } else {
                    Triple(false, "Chat ID를 찾지 못했습니다. 봇에게 메시지를 한 번 보내고 다시 시도하세요.", null)
                }
            }.getOrElse {
                Triple(false, "네트워크 오류: ${it.javaClass.simpleName}", null)
            }
            onResult(res.first, res.second, res.third)
        }
    }

    private fun sendMessageSync(token: String, chatId: String, text: String): Pair<Boolean, String> = runCatching {
        val url = URL("https://api.telegram.org/bot$token/sendMessage")
        val payload = "chat_id=${URLEncoder.encode(chatId, "UTF-8")}&text=${URLEncoder.encode(text, "UTF-8")}"
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 8_000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        }
        conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code in 200..299) {
            true to "OK"
        } else {
            CoreLog.w("TELEGRAM", "sendMessage failed code=$code body=${resp.take(180)}")
            false to "HTTP $code"
        }
    }.getOrElse {
        CoreLog.w("TELEGRAM", "sendMessage error=${it.message}")
        false to (it.javaClass.simpleName ?: "error")
    }

    private fun sendPhotoSync(token: String, chatId: String, caption: String, jpeg: ByteArray): Pair<Boolean, String> = runCatching {
        val boundary = "----DolphinBoundary${System.currentTimeMillis()}"
        val url = URL("https://api.telegram.org/bot$token/sendPhoto")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 12_000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        DataOutputStream(conn.outputStream).use { out ->
            out.writeBytes("--$boundary\r\n")
            out.writeBytes("Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n")
            out.write(chatId.toByteArray(Charsets.UTF_8))
            out.writeBytes("\r\n--$boundary\r\n")
            out.writeBytes("Content-Disposition: form-data; name=\"caption\"\r\n\r\n")
            out.write(caption.toByteArray(Charsets.UTF_8))
            out.writeBytes("\r\n--$boundary\r\n")
            out.writeBytes("Content-Disposition: form-data; name=\"photo\"; filename=\"sentry.jpg\"\r\n")
            out.writeBytes("Content-Type: image/jpeg\r\n\r\n")
            out.write(jpeg)
            out.writeBytes("\r\n--$boundary--\r\n")
            out.flush()
        }
        val code = conn.responseCode
        val resp = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code in 200..299) {
            true to "OK"
        } else {
            CoreLog.w("TELEGRAM", "sendPhoto failed code=$code body=${resp.take(180)}")
            false to "HTTP $code"
        }
    }.getOrElse {
        CoreLog.w("TELEGRAM", "sendPhoto error=${it.message}")
        false to (it.javaClass.simpleName ?: "error")
    }
}
