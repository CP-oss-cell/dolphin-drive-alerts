package com.byd.dolphin.drivealerts.camera

import android.content.Context

/** Preferences for sensor/camera-assisted BSD Left/Right side classification. */
object BsdSideInferencePreferences {
    private const val PREF = "bsd_side_fusion"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_MODE = "mode"
    private const val KEY_CAM_ID = "cam_id"
    private const val KEY_LAYOUT = "layout"

    val modeLabels = listOf(
        "융합 (후방 센서 + 사이드 카메라)",
        "후방 센서 전용 (카메라 미사용)",
        "사이드 카메라 전용 (AVM 좌/우 비교)"
    )
    val layoutLabels = listOf(
        "BYD 4분할 AVM (좌하=좌측 / 우하=우측)",
        "좌/우 절반 분할 (좌반=좌측 / 우반=우측)"
    )

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = prefs(c).getBoolean(KEY_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(KEY_ENABLED, v).apply()

    fun mode(c: Context): Int = prefs(c).getInt(KEY_MODE, 0).coerceIn(0, 2)
    fun setMode(c: Context, v: Int) = prefs(c).edit().putInt(KEY_MODE, v.coerceIn(0, 2)).apply()

    fun cameraId(c: Context): String = prefs(c).getString(KEY_CAM_ID, "0") ?: "0"
    fun setCameraId(c: Context, id: String) = prefs(c).edit().putString(KEY_CAM_ID, id.trim().ifBlank { "0" }).apply()

    fun layout(c: Context): Int = prefs(c).getInt(KEY_LAYOUT, 0).coerceIn(0, 1)
    fun setLayout(c: Context, v: Int) = prefs(c).edit().putInt(KEY_LAYOUT, v.coerceIn(0, 1)).apply()
}
