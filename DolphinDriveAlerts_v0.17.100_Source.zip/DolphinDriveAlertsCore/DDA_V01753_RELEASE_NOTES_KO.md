# Dolphin Drive Alerts v0.17.53 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.52` (`versionCode = 78`) → **신규 버전**: `v0.17.53` (`versionCode = 79`)
- **패키지명**: `com.byd.dolphin.drivealerts` (기존 설치 호환성 및 사용자 설정 100% 유지)
- **대상 환경**: 한국형 BYD Dolphin 스탠다드 / Android 10 (DiLink 3) / 10.1인치 1280×720 (DPI 160) / 펌웨어 2602·2606·2608

## 1. 전체 메뉴 UI · 하위 메뉴 · 그래픽 아이콘 전면 재설계
1. **커스텀 벡터 그래픽 아이콘 엔진 신설 (`ui/DashboardIcons.kt`)**
   - 외부 라이브러리 의존성 없이 순수 Android `Canvas`/`Path` 기반 28종 안티앨리어싱 벡터 아이콘 및 라운드 배지 구현.
   - 메인 6개 카테고리, 실시간 상태 칩, 빠른 진단 제어, 하위 메뉴 액션 행, 헤더 바, 다크/라이트 전환 버튼 전체에 적용.
2. **10.1인치 콕핏 디자인 시스템 및 다크/라이트 모드 지원 (`ui/DashboardUi.kt`, `ui/DashboardTheme.kt`, `ui/DarkSpinnerAdapter.kt`)**
   - 상단 고정 콕핏 헤더 바(뒤로가기 아이콘 + 화면별 그래픽 아이콘 + 제목/부제 + 다크/라이트 전환 토글)를 메인 및 모든 하위 Activity에 통일 적용.
   - 야간 주행용 다크 콕핏 테마(기본)와 주간 고대비 라이트 테마를 즉시 전환 및 `SharedPreferences` 저장 지원.
   - 모든 카드·버튼에 48dp 이상 터치 영역과 `RippleDrawable` 터치 피드백, 세그먼트 필 선택기 적용.
3. **전체 메뉴 파악 · 중복 메뉴 삭제 · 6대 기능별 세분화 (`ui/MainActivity.kt`, `ui/AppPolicyActivity.kt`, `ui/AdbSetupActivity.kt`)**
   - 기존 5개 영역(3열 2행 비대칭)을 **6개 대칭 기능 영역(3×2 그리드)**으로 재구성:
     1. **주행 알림**: 전체 ON/OFF, 23종 개별 설정(+개별 음성 테스트), 출력/스타일/볼륨 세그먼트 제어 + 즉시 음성 테스트, 주행모드, BSD 후측방, 핸들·ADAS
     2. **시동 · 자동 실행**: 시동 시 주행보조 자동 시작, 등록 앱 실행 순서·미디어 재생·시동 OFF 종료 관리
     3. **화면 · 분할 · DPI**: 2앱 화면 분할, 앱별 DPI·순정 복구, **화면 회전 통합 제어(ON/OFF·12종 방향·적용·오버레이 권한)**
     4. **오디오 · 내비**: 내비 오디오 경로 진단, **내비 5종 대상 선택(단일화)**, 이퀄라이저·음장
     5. **권한 · ADB**: 차량 로컬 ADB 연결, 선택 앱 권한 관리, ADB 필수 권한 일괄 검증
     6. **진단 · 로그**: 통합 로그 세션 상태, 시동 기록 구조 ZIP, 읽기 전용 자동 점검, 차량 오디오·외부 AVAS 연구
   - **제거된 중복 메뉴**:
     - `AppPolicyActivity` 하단의 중복 **화면 회전** 섹션 제거 → `[화면 · 분할 · DPI]`로 통합
     - `AppPolicyActivity` 하단의 중복 **내비게이션 운전석 스피커 5종 체크박스** 제거 → `[오디오 · 내비]`로 단일화
     - `MainActivity` 시동 자동 실행 내 중복 **권한** 카드 제거 → `[권한 · ADB]`로 일원화
     - `MainActivity` 카테고리 상·하단 중복 뒤로가기 버튼 제거 → 고정 상단 콕핏 헤더로 통일
     - `AdbSetupActivity`의 고정 "분할 프로필로 돌아가기" 버튼을 범용 "이전 화면으로 돌아가기(`finish()`)"로 개선
     - `MainActivity`에 남아 있던 `v0.17.51` 하드코딩 표기를 패키지 버전 동적 조회(`v0.17.53`)로 수정
4. **23종 알림 개별 음성 테스트 추가 (`ui/AlertEventSettingsActivity.kt`)**
   - 기능 그룹별 카드 + 활성 개수 표시 + 각 알림 우측 원터치 재생(`▶`) 버튼으로 주행 전 개별 음성 테스트 가능.

## 2. 기존 정상 기능 보호 및 검증 결과
- **보존 핵심 모듈 SHA-256 일치 확인**: `ReferenceVehicleEventBridge.kt`, `ModeNoticeCorrelator.kt`, `AlertAudioPlayer.kt`, `MediaPlaybackObserver.kt`, `SplitRecoveryService.kt`, `AlertEventCatalog.kt` 무변경 보존.
- **R027/R028/R051/R052 계약 보존**: 시동 자동 실행 요청별 ACK, 알람 실패 재무장, R028 통합 로그 수집 및 시동 기록 구조 ZIP 유지.
- **정적 검사 통과**: `python3 tools/verify_v01753_ui_and_core.py` 통과 (`V01753_UI_DEDUP_AND_CORE_STATIC_GATES_PASS`).
- **GitHub Actions CI 갱신**: `DolphinDriveAlerts_v0.17.53_Source.yml`이 `verify_v01753_ui_and_core.py` 및 `v0.17.53` 소스 ZIP을 기준으로 빌드하도록 정합성 수정.

## 3. 검증 한계 및 미해결 항목 (실차 확인 필요)
- **APK 컴파일 미실시**: 현재 작업 환경에 Android SDK, Gradle 캐시, 외부 네트워크가 없어 `:app:assembleDebug` 실제 APK 컴파일은 수행하지 못했습니다. 동봉된 `DolphinDriveAlerts_v0.17.53_Source.yml`로 GitHub Actions에서 APK를 빌드한 뒤 설치하세요.
- **실차 미확정 기능 유지 정책**: 주행모드 NORMAL 독립 확정 신호, BSD 좌우 방향 구분, 일반 주행 중 차선이탈/앞차 출발, 타사 내비 UID 단독 운전석 스피커 라우팅, 원본 미디어 덕킹/음소거 자동 복원은 실차 신호 확정 전까지 임의 추측 발화나 ECU/CAN 명령을 추가하지 않고 기존 안전·진단 분리 구조를 유지합니다.
