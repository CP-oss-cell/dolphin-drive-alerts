import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 98" in gr and 'versionName = "0.17.72"' in gr
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)
for req in ["ACCESS_WIFI_STATE", "SCHEDULE_EXACT_ALARM", "BYDAUTO_POWER_COMMON", "BYDAUTO_POWER_SET"]:
    assert req in mf, f"Missing in manifest: {req}"

for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        clean = strip_kt(read(rel))
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

wk = read("app/src/main/java/com/byd/dolphin/drivealerts/sentry/SentryWakeKeeper.kt")
assert "PARTIAL_WAKE_LOCK" in wk and "WIFI_MODE_FULL_HIGH_PERF" in wk and "wakeUpMcu" in wk and "setExactAndAllowWhileIdle" in wk
assert "onWakePulse" in read("app/src/main/java/com/byd/dolphin/drivealerts/sentry/SentryMonitorController.kt")
assert "ACTION_SENTRY_HEARTBEAT" in read("app/src/main/java/com/byd/dolphin/drivealerts/service/BootReceiver.kt")
assert "BYDAUTO_POWER_SET" in read("app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt")
print("V01772_SENTRY_WAKE_AND_PERMS_ALL_STATIC_GATES_PASS")
