import os, xml.etree.ElementTree as ET

def read(rel):
    with open(rel, encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

gr = read("app/build.gradle.kts")
assert "versionCode = 96" in gr and 'versionName = "0.17.70"' in gr
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)
assert "SentrySettingsActivity" in mf and "SentryWarningActivity" in mf

for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        clean = strip_kt(read(rel))
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

assert "acquireSentry" in read("app/src/main/java/com/byd/dolphin/drivealerts/camera/SharedAvmSession.kt")
assert "triggerSentryEventClip" in read("app/src/main/java/com/byd/dolphin/drivealerts/camera/VehicleCameraHub.kt")
assert "SentryMonitorController" in read("app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt")
assert "SentrySettingsActivity::class.java" in read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
print("V01770_SENTRY_AND_FULL_SUITE_STATIC_GATES_PASS")
