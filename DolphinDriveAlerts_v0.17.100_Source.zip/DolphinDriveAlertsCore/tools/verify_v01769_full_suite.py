import os, re, xml.etree.ElementTree as ET

ROOT = os.getcwd()

def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()

def strip_kt(src):
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"': i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'": i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    return ''.join(out)

# 1. Gradle check
gr = read("app/build.gradle.kts")
assert "versionCode = 95" in gr and 'versionName = "0.17.69"' in gr
assert 'abiFilters += listOf("arm64-v8a")' in gr
assert 'noCompress += "tflite"' in gr
assert 'org.tensorflow:tensorflow-lite:2.14.0' in gr

# 2. Manifest check
mf = read("app/src/main/AndroidManifest.xml")
ET.fromstring(mf)
for req in ['bmmcamera', 'com.byd.camera', 'AVMCamera', 'READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE', 'DockBarSettingsActivity', 'BYDAUTO_AC_SET']:
    assert req in mf, f"Missing in manifest: {req}"

# 3. Check ALL Kotlin files under camera/, dock/, automation/, vehicle/, service/, dpi/, ui/ for balanced braces/parens
for dirpath, _, filenames in os.walk("app/src/main/java/com/byd/dolphin/drivealerts"):
    for fn in filenames:
        if not fn.endswith(".kt"): continue
        rel = os.path.join(dirpath, fn)
        clean = strip_kt(read(rel))
        assert clean.count('{') == clean.count('}'), f"Brace mismatch in {rel}"
        assert clean.count('(') == clean.count(')'), f"Paren mismatch in {rel}"

# 4. Feature & permission completeness checks
assert "SharedAvmSession.attachDashcam" in read("app/src/main/java/com/byd/dolphin/drivealerts/camera/VehicleCameraHub.kt")
assert "SharedAvmSession.attachBsdDisplay" in read("app/src/main/java/com/byd/dolphin/drivealerts/camera/BsdCameraOverlayController.kt")
assert "TfliteLeadCarDetector" in read("app/src/main/java/com/byd/dolphin/drivealerts/vehicle/LeadCarDepartureFusionDetector.kt")
assert "BLINKER_DIRECT" in read("app/src/main/java/com/byd/dolphin/drivealerts/vehicle/BsdSideFusionClassifier.kt")
assert "SharedAvmSession.setAnalysisConsumer" in read("app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt")
pb = read("app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt")
assert "WRITE_EXTERNAL_STORAGE" in pb and "READ_EXTERNAL_STORAGE" in pb and "BYDAUTO_SETTING_SET" in pb
main = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
assert "requestPermissions(req, 6901)" in main
assert "AppPolicyActivity::class.java" not in main
assert "NavAudioLabActivity::class.java" not in main

print("V01769_FULL_SUITE_STATIC_GATES_PASS")
