#!/usr/bin/env python3
"""v0.17.53 UI redesign, menu deduplication, preserved core SHA256, and R028/R051/R052 static verification."""
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
src = root / "app/src/main/java/com/byd/dolphin/drivealerts"
read = lambda rel: (src / rel).read_text(encoding="utf-8")

# 1. Version & package integrity
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
assert 'applicationId = "com.byd.dolphin.drivealerts"' in gradle
assert 'versionName = "0.17.53"' in gradle, "versionName must be 0.17.53"
assert "versionCode = 79" in gradle, "versionCode must be 79"

# 2. Manifest XML integrity & SplitGhostActivity contract
manifest_path = root / "app/src/main/AndroidManifest.xml"
ns = "{http://schemas.android.com/apk/res/android}"
tree = ET.parse(manifest_path)
activities = tree.findall(".//activity")
ghost = next(x for x in activities if x.get(ns + "name") == ".automation.SplitGhostActivity")
assert ghost.get(ns + "exported") == "true"
assert ghost.get(ns + "permission") == "android.permission.DUMP"
assert ghost.get(ns + "resizeableActivity") == "true"

# Verify all res XML files parse cleanly
for xml_file in (root / "app/src/main/res").rglob("*.xml"):
    ET.parse(xml_file)

# 3. Preserved core vehicle/audio/split/media/catalog modules MUST remain byte-for-byte identical
expected = json.loads((root / "tools/R027_PRESERVED_CORE_SHA256.json").read_text(encoding="utf-8"))
allowed_modified = {
    "service/DrivingAlertService.kt",
    "service/BootReceiver.kt",
    "ui/MainActivity.kt",
    "automation/AutoLaunchSequenceService.kt",
}
for rel_path, digest in expected.items():
    if rel_path.split("/drivealerts/")[-1] in allowed_modified:
        continue
    actual = hashlib.sha256((root / rel_path).read_bytes()).hexdigest()
    assert actual == digest, f"Preserved core modified unexpectedly: {rel_path}"

# 4. Existing R027/R028/R051/R052 critical feature contracts
engine = read("automation/AutoSplitBehaviorEngine.kt")
dpi = read("dpi/TemporaryAppDpiController.kt")
app_policy = read("ui/AppPolicyActivity.kt")
catalog = read("dpi/DpiAppCatalog.kt")
autolaunch_ui = read("automation/AutoLaunchSettingsActivity.kt")
split_ui = read("automation/SplitProfilesActivity.kt")
main_ui = read("ui/MainActivity.kt")
icons = read("ui/DashboardIcons.kt")
dash_ui = read("ui/DashboardUi.kt")
alert_ui = read("ui/AlertEventSettingsActivity.kt")

assert "TRY_8_ARGS" in engine and "TRY_4_ARGS" in engine
assert "actual==percentage" in engine and "abs(before-percentage)<=2" not in engine
assert "OWNERSHIP_MISMATCH" in engine
assert "TemporaryAppDpiController.hasActiveSession(c)" in engine
assert "DpiAppCatalog.navigationCandidates(allEntries)" in app_policy
assert "순정 내비 후보 바로 선택" in app_policy
assert "limit:Int=200" in catalog and "fun count(" in catalog
assert "RESTORED_PREVIOUS_DENSITY" in dpi and "AUTO_SKIP_OEM_FOREGROUND" in dpi
assert "APP_STARTED_THEN_DPI" in dpi and "beforeOverride" in dpi
assert "ADB 연결/승인" in autolaunch_ui
assert 'button("-1%")' in split_ui and 'button("+1%")' in split_ui

# R028 ignition & capture contracts
ignition = read("automation/IgnitionWakePolicy.kt")
boot = read("service/BootReceiver.kt")
service = read("service/DrivingAlertService.kt")
capture = read("log/UnifiedLogCapture.kt")
journal = read("log/IgnitionAuditJournal.kt")
alarm = read("automation/IgnitionSequenceAlarmReceiver.kt")
for token in ("VENDOR_QUICKBOOT_AND_BYD_IGNITION_PAIR", "WAIT_OFF_OR_VERIFIED_WAKE_PAIR", "120_000L"):
    assert token in ignition, token
for token in ("QUICKBOOT_ACTIONS", "SEQUENCE_SUPPRESSED", "IgnitionWakePolicy.decide", "IGNITION_OFF"):
    assert token in boot, token
for token in ("CAPTURE_BEGIN_RECEIVED", "CAPTURE_END_RECEIVED", "MONITOR_SERVICE_CREATED"):
    assert token in service, token
for token in ("CAPTURE_SAVE_INTERRUPTED", "CAPTURE_SAVE_FAILED", "lifecycle/ignition_audit.jsonl", "lastResult"):
    assert token in capture, token
assert "stream.fd.sync()" in journal and "MAX_BYTES = 262_144L" in journal
assert "fun exportRecent(context: Context)" in journal and "DolphinIgnitionAudit_" in journal
assert "시동 기록만 ZIP 저장 (수집 실패 시)" in main_ui
assert "updateCaptureStatus(); refreshDashboardStatus()" in main_ui
assert "AUTO_SEQUENCE_RETRY_REJECTED" in alarm
assert "guardRearmedForNextIgnition" in read("automation/FeatureProfiles.kt")

# 5. v0.17.53 UI redesign, vector icon engine, theme toggle & menu deduplication checks
assert "enum class IconKind" in icons
assert "VectorIconDrawable" in icons
assert "fun isLightMode(" in dash_ui and "fun themeToggleButton(" in dash_ui
assert "fun segmentedBar(" in dash_ui and "fun actionRow(" in dash_ui
assert "6개 영역 · 중복 제거" in main_ui
assert "권한 · ADB" in main_ui and "진단 · 로그" in main_ui
assert "v0.17.51" not in main_ui, "Stale v0.17.51 label must not remain in MainActivity"
assert "화면 회전 · Orientation Control 방식" not in app_policy, "Duplicate rotation section must be removed from AppPolicyActivity"
assert "내비게이션 운전석 스피커 · 대상 5종 고정" not in app_policy, "Duplicate nav speaker section must be removed from AppPolicyActivity"
assert "AlertAudioPlayer(applicationContext)" in alert_ui, "Per-alert voice preview must exist in AlertEventSettingsActivity"

# 6. Zero forbidden AndroidX/Material dependencies & balanced braces in all modified UI files
ui_files = [
    "ui/DashboardIcons.kt",
    "ui/DashboardUi.kt",
    "ui/DashboardTheme.kt",
    "ui/DarkSpinnerAdapter.kt",
    "ui/MainActivity.kt",
    "ui/AlertEventSettingsActivity.kt",
    "ui/AppPolicyActivity.kt",
    "ui/AdbSetupActivity.kt",
]
for rel in ui_files:
    code = read(rel)
    assert "import androidx." not in code, f"Unexpected androidx import in {rel}"
    assert "import com.google.android.material." not in code, f"Unexpected material import in {rel}"
    # Proper Kotlin lexical brace/paren balance check (respects //, /* */, strings, and ${...})
    stack = []
    i = 0
    n = len(code)
    in_line = False
    in_block = False
    in_str = False
    in_char = False
    while i < n:
        c = code[i]
        nxt = code[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n": in_line = False
            i += 1; continue
        if in_block:
            if c == "*" and nxt == "/": in_block = False; i += 2
            else: i += 1
            continue
        if in_str:
            if c == "\\": i += 2; continue
            if c == '"': in_str = False
            i += 1; continue
        if in_char:
            if c == "\\": i += 2; continue
            if c == "'": in_char = False
            i += 1; continue
        if c == "/" and nxt == "/": in_line = True; i += 2; continue
        if c == "/" and nxt == "*": in_block = True; i += 2; continue
        if c == '"': in_str = True; i += 1; continue
        if c == "'": in_char = True; i += 1; continue
        if c in "{(": stack.append(c)
        elif c in "})":
            assert stack, f"Extra closing {c} in {rel}"
            top = stack.pop()
            assert (top == "{" and c == "}") or (top == "(" and c == ")"), f"Mismatched {top}..{c} in {rel}"
        i += 1
    assert not stack, f"Unclosed delimiters in {rel}: {stack}"

print("V01753_UI_DEDUP_AND_CORE_STATIC_GATES_PASS")
