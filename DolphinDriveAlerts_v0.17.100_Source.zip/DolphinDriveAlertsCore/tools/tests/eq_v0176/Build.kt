package android.os
object Build { object VERSION { const val SDK_INT: Int = 34 } }
