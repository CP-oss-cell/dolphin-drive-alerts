#!/usr/bin/env python3
"""v0.17.54 full static, regression, preserved-core, UI deduplication, and 6-feature verification."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
src = root / "app/src/main/java/com/byd/dolphin/drivealerts"
read = lambda rel: (src / rel).read_text(encoding="utf-8")

# 1. Version & package integrity
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
assert 'applicationId = "com.byd.dolphin.drivealerts"' in gradle
assert 'versionName = "0.17.59"' in gradle, "versionName must be 0.17.59"
assert "versionCode = 85" in gradle, "versionCode must be 85"

# 2. Manifest XML integrity, SplitGhostActivity contract, and 8 BYDAUTO_*_COMMON permissions
manifest_path = root / "app/src/main/AndroidManifest.xml"
ns = "{http://schemas.android.com/apk/res/android}"
tree = ET.parse(manifest_path)
activities = tree.findall(".//activity")
ghost = next(x for x in activities if x.get(ns + "name") == ".automation.SplitGhostActivity")
assert ghost.get(ns + "exported") == "true"
assert ghost.get(ns + "permission") == "android.permission.DUMP"
assert ghost.get(ns + "resizeableActivity") == "true"

perms = {p.get(ns + "name") for p in tree.findall(".//uses-permission")}
for p in (
    "android.permission.BYDAUTO_SETTING_COMMON",
    "android.permission.BYDAUTO_AC_COMMON",
    "android.permission.BYDAUTO_BODYWORK_COMMON",
    "android.permission.BYDAUTO_DOOR_LOCK_COMMON",
    "android.permission.BYDAUTO_INSTRUMENT_COMMON",
    "android.permission.BYDAUTO_LIGHT_COMMON",
    "android.permission.BYDAUTO_PANORAMA_COMMON",
    "android.permission.BYDAUTO_RADAR_COMMON",
    "android.permission.CAMERA",
):
    assert p in perms, f"Missing permission: {p}"

for xml_file in (root / "app/src/main/res").rglob("*.xml"):
    ET.parse(xml_file)

# 3. Unmodified preserved core modules remain byte-for-byte identical to R027 baseline
expected = json.loads((root / "tools/R027_PRESERVED_CORE_SHA256.json").read_text(encoding="utf-8"))
allowed_modified = {
    "service/DrivingAlertService.kt",
    "service/BootReceiver.kt",
    "ui/MainActivity.kt",
    "automation/AutoLaunchSequenceService.kt",
    "audio/AlertAudioPlayer.kt",  # v0.17.54: transient ducking, priority guard, per-event style/volume
}
for rel_path, digest in expected.items():
    if rel_path.split("/drivealerts/")[-1] in allowed_modified:
        continue
    actual = hashlib.sha256((root / rel_path).read_bytes()).hexdigest()
    assert actual == digest, f"Preserved core modified unexpectedly: {rel_path}"

# 4. 6 new feature checks (v0.17.54)
audio_player = read("audio/AlertAudioPlayer.kt")
prefs = read("config/AlertPreferences.kt")
autolaunch = read("automation/AutoLaunchSequenceService.kt")
scanner = read("log/BydFeatureIdScanner.kt")
alert_ui = read("ui/AlertEventSettingsActivity.kt")
main_ui = read("ui/MainActivity.kt")

# (1) Media ducking AudioFocusRequest
assert "AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK" in audio_player
assert "abandonAudioFocusRequest" in audio_player
assert "mediaDuckingEnabled" in prefs and "mediaDuckingEnabled" in main_ui

# (2) Priority preemption guard
assert "AUDIO_PREEMPT_BLOCKED" in audio_player and "activePriority" in audio_player

# (3) Auto-launch foreground verification via ForegroundResolver
assert "verifyForegroundLaunch" in autolaunch
assert "ForegroundResolver.topToken" in autolaunch
assert "STEP_FOREGROUND_READBACK" in autolaunch

# (4) Per-alert voice style & volume overrides
assert "eventStyleOverride" in prefs and "effectiveStyle" in prefs
assert "eventVolumeTierOverride" in prefs and "effectiveVolumeTier" in prefs
assert "openOverrideDialog" in alert_ui

# (5) Read-only BYD permission & FeatureIds scanner (zero setter/ECU writes)
assert "BYDAutoFeatureIds" in scanner and "runReadOnlyScan" in scanner
assert "set(" not in scanner and "setValue" not in scanner
assert "runBydFeatureIdScan" in main_ui

# (6) Post-update BYD background-block reset notice banner
assert "lastSeenVersionCode" in prefs and "lastSeenVersionCode" in main_ui
assert "업데이트 후 필수 확인" in main_ui

# 5. R028 & v0.17.53 UI deduplication regression checks
app_policy = read("ui/AppPolicyActivity.kt")
assert "시동 기록만 ZIP 저장 (수집 실패 시)" in main_ui
assert "updateCaptureStatus(); refreshDashboardStatus()" in main_ui
assert "화면 회전 · Orientation Control 방식" not in app_policy
assert "내비게이션 운전석 스피커 · 대상 5종 고정" not in app_policy

# 6. Kotlin lexical brace/paren balance & zero forbidden imports across all modified files
checked_files = [
    "audio/AlertAudioPlayer.kt",
    "config/AlertPreferences.kt",
    "automation/AutoLaunchSequenceService.kt",
    "log/BydFeatureIdScanner.kt",
    "ui/DashboardIcons.kt",
    "ui/DashboardUi.kt",
    "ui/DashboardTheme.kt",
    "ui/DarkSpinnerAdapter.kt",
    "ui/MainActivity.kt",
    "ui/AlertEventSettingsActivity.kt",
    "ui/AppPolicyActivity.kt",
    "ui/AdbSetupActivity.kt",
    "camera/BsdCameraPreferences.kt",
    "camera/BsdCameraOverlayController.kt",
    "ui/BsdCameraSettingsActivity.kt",
    "service/DrivingAlertService.kt",
    "camera/LeadCarDeparturePreferences.kt",
    "camera/FrontCameraDepartureAnalyzer.kt",
    "vehicle/LeadCarDepartureFusionDetector.kt",
    "ui/LeadCarDepartureActivity.kt",
    "camera/BsdSideInferencePreferences.kt",
    "camera/SideCameraBsdAnalyzer.kt",
    "vehicle/BsdSideFusionClassifier.kt",
    "vehicle/IccLeadCarDepartureDetector.kt",
    "camera/DashcamPreferences.kt",
    "camera/VehicleCameraHub.kt",
    "ui/DashcamActivity.kt",
]
for rel in checked_files:
    code = read(rel)
    assert "import androidx." not in code, f"Unexpected androidx import in {rel}"
    assert "import com.google.android.material." not in code, f"Unexpected material import in {rel}"
    stack = []
    i = 0
    n = len(code)
    in_line = in_block = in_str = in_char = False
    while i < n:
        c = code[i]
        nxt = code[i + 1] if i + 1 < n else ""
        if in_line:
            if c == "\n": in_line = False
            i += 1; continue
        if in_block:
            if c == "*" and nxt == "/": in_block = False; i += 2
            else: i += 1
            continue
        if in_str:
            if c == "\\": i += 2; continue
            if c == '"': in_str = False
            i += 1; continue
        if in_char:
            if c == "\\": i += 2; continue
            if c == "'": in_char = False
            i += 1; continue
        if c == "/" and nxt == "/": in_line = True; i += 2; continue
        if c == "/" and nxt == "*": in_block = True; i += 2; continue
        if c == '"': in_str = True; i += 1; continue
        if c == "'": in_char = True; i += 1; continue
        if c in "{(": stack.append(c)
        elif c in "})":
            assert stack, f"Extra closing {c} in {rel}"
            top = stack.pop()
            assert (top == "{" and c == "}") or (top == "(" and c == ")"), f"Mismatched {top}..{c} in {rel}"
        i += 1
    assert not stack, f"Unclosed delimiters in {rel}: {stack}"

assert "BsdCameraOverlayController" in read("service/DrivingAlertService.kt")
assert "frame.gearRaw == 1" in read("service/DrivingAlertService.kt")
assert "reverse_gear_yield" in read("camera/BsdCameraOverlayController.kt")
assert "BsdCameraSettingsActivity" in read("ui/MainActivity.kt")
assert "LeadCarDepartureFusionDetector" in read("service/DrivingAlertService.kt")
assert "FrontCameraDepartureAnalyzer" in read("vehicle/LeadCarDepartureFusionDetector.kt")
assert "LeadCarDepartureActivity" in read("ui/MainActivity.kt")
assert "BsdSideFusionClassifier" in read("service/DrivingAlertService.kt")
assert "BSD_SIDE_FUSION" in read("service/DrivingAlertService.kt")
assert "BsdSideInferencePreferences" in read("ui/MainActivity.kt")
assert "IccLeadCarDepartureDetector" in read("service/DrivingAlertService.kt")
assert "onFrontCarStartStateChange" in read("vehicle/IccLeadCarDepartureDetector.kt")
assert "getFrontCarStartState" in read("vehicle/IccLeadCarDepartureDetector.kt")
assert "VehicleCameraHub" in read("service/DrivingAlertService.kt")
assert "acceptSharedFrame" in read("vehicle/LeadCarDepartureFusionDetector.kt")
assert "acceptSharedFrame" in read("vehicle/BsdSideFusionClassifier.kt")
assert "DashcamActivity" in read("ui/MainActivity.kt")
print("V01759_DASHCAM_SHARED_HUB_AND_ALL_STATIC_GATES_PASS")
