import os, re, xml.etree.ElementTree as ET

ROOT = os.getcwd()

def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()

# 1. Gradle version check
gradle = read("app/build.gradle.kts")
assert "versionCode = 93" in gradle, "versionCode must be 93"
assert 'versionName = "0.17.67"' in gradle, "versionName must be 0.17.67"

# 2. Manifest XML & required declarations
manifest_text = read("app/src/main/AndroidManifest.xml")
ET.fromstring(manifest_text)
for needle in [
    'android:name="bmmcamera"',
    'android:name="com.byd.camera"',
    'android:name="AVMCamera"',
    'android:name=".ui.DockBarSettingsActivity"',
    'android.permission.BYDAUTO_AC_SET',
    'android.permission.BYDAUTO_BODYWORK_SET',
    'android.permission.BYDAUTO_PANORAMA_SET',
]:
    assert needle in manifest_text, f"Missing in manifest: {needle}"

# 3. Required new & upgraded Kotlin files exist and pass structural checks
new_and_mod = [
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/BydAvmCameraBackend.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/GlLutDewarpRenderer.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/BsdCameraOverlayController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/camera/VehicleCameraHub.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/SystemBarController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/BydComfortController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockPreferences.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/DockIcons.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/DockBarSettingsActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dpi/ForegroundPolicyAccessibilityService.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/service/DrivingAlertService.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt",
    "app/src/main/java/com/byd/dolphin/drivealerts/dpi/PermissionBootstrapper.kt",
]

for rel in new_and_mod:
    src = read(rel)
    # Proper single-pass Kotlin comment/string stripper
    out = []; i = 0; n = len(src)
    while i < n:
        if src[i:i+3] == '"""':
            j = src.find('"""', i + 3); i = n if j == -1 else j + 3
        elif src[i] == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i] == "'":
            i += 1
            while i < n and src[i] != "'":
                i += 2 if src[i] == '\\' else 1
            i += 1
        elif src[i:i+2] == '//':
            j = src.find('\n', i); i = n if j == -1 else j + 1
        elif src[i:i+2] == '/*':
            j = src.find('*/', i + 2); i = n if j == -1 else j + 2
        else:
            out.append(src[i]); i += 1
    no_str = ''.join(out)
    assert no_str.count('{') == no_str.count('}'), f"Unbalanced braces in {rel}: {{={no_str.count('{')} }}={no_str.count('}')}"
    assert no_str.count('(') == no_str.count(')'), f"Unbalanced parens in {rel}: (={no_str.count('(')} )={no_str.count(')')}"
    # Guard against DashboardUi.dp(this, ...) inside LayoutParams.apply
    assert not re.search(r'LayoutParams\([^)]*\)\.apply\s*\{[^}]*DashboardUi\.dp\(this,', src), f"Ambiguous this in LayoutParams.apply in {rel}"

# 4. Feature-specific assertions
avm = read("app/src/main/java/com/byd/dolphin/drivealerts/camera/BydAvmCameraBackend.kt")
assert "bmmcamera.jar" in avm and "android.hardware.AVMCamera" in avm and "setPreviewSurface" in avm

gl = read("app/src/main/java/com/byd/dolphin/drivealerts/camera/GlLutDewarpRenderer.kt")
assert "#version 300 es" in gl and "GL_OES_EGL_image_external_essl3" in gl and "EGL_RECORDABLE_ANDROID" in gl and "uSharpness" in gl

dock = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/FloatingDockController.kt")
for tok in ["collapse()", "expand()", "autoCollapseRunnable", "showWindPickerPopup()", "showFolderPopup(", "showAppDrawerPopup()", "HorizontalScrollView", "cycleWindModeTap()", "toggleRecirculation()", "toggleSteeringHeat()", "cycleDriverSeatHeat()", "cyclePassengerSeatHeat()", "toggleRearMirrorDefrost()"]:
    assert tok in dock, f"Missing dock capability: {tok}"

sysbar = read("app/src/main/java/com/byd/dolphin/drivealerts/dock/SystemBarController.kt")
assert "immersive.full=*" in sysbar and "immersive.status=*" in sysbar and "immersive.navigation=*" in sysbar

# 5. Zero regression on removed menus in MainActivity
main = read("app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt")
assert "DockBarSettingsActivity::class.java" in main
assert "AppPolicyActivity::class.java" not in main
assert "NavAudioLabActivity::class.java" not in main

# 6. Check workflow exists and references v0.17.67
wf = read(".github/workflows/DolphinDriveAlerts_v0.17.67_Source.yml")
assert "0.17.67" in wf

print("V01767_AVM_GL_LUT_AND_FLOATING_DOCK_ALL_STATIC_GATES_PASS")
