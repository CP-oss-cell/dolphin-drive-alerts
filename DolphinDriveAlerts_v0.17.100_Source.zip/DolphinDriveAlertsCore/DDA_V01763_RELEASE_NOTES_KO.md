# Dolphin Drive Alerts v0.17.63 릴리즈 노트 (2026-11-25)

- **기준 버전**: `v0.17.62` (`versionCode = 88`) → **신규 버전**: `v0.17.63` (`versionCode = 89`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## 1. 핸들 버튼 연타 → 지정 앱(또는 분할 프로필) 빠른 실행으로 전환
- **변경 내용 (`steering/SteeringTriggerPreferences.kt`, `service/DrivingAlertService.kt`, `ui/MainActivity.kt`)**:
  - 기존 `"빵빵, 차 좀 지나갈게요"` 음성 발화 동작을 제거하고, **핸들 버튼 연타 시 사용자가 선택한 앱 또는 저장된 2앱 분할 프로필을 즉시 실행**하도록 전환했습니다.
  - 백그라운드 액티비티 실행 제한 환경에서도 안정적으로 열리도록 Android 표준 `startActivity(FLAG_ACTIVITY_NEW_TASK)` 시도 후 필요 시 승인된 로컬 ADB(`am start --user 0 -n`) 폴백을 지원합니다.
  - `[주행 알림] → 핸들 버튼 연타 · 지정 앱 빠른 실행`에서 ON/OFF, 실행할 앱/분할 프로필 선택, 바로 실행 테스트를 할 수 있습니다.

## 2. 내비 5종 및 외부 스피커(AVAS) 관련 메뉴 전면 폐기
- **삭제**: `[오디오 · 이퀄라이저]`에서 `내비 오디오 경로 진단(NavAudioLabActivity)` 및 내비 5종 관련 UI를 전부 제거하고 프리미엄 10밴드 이퀄라이저·음장 중심으로 단순화했습니다.
- **삭제**: `[진단 · 로그]`에서 `차량 오디오 · 외부 AVAS 연구` 패널(순정/타사 내비 음성 구간 기록, 외부 보행자 경고음 구간 기록) 전체를 폐기했습니다.
  - 외부 보행자 경고음(AVAS) 스피커에 임의 음원을 송출하는 기능은 법정 보행자 안전 장치 및 차량 오디오 DSP/ECU 제어 금지 원칙에 위배될 소지가 크고 일반 앱에서 실차 보장도 불가하므로 완전 폐기했습니다.

## 검증 결과 및 한계
- `python3 tools/verify_v01763_steering_launch.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.63_Source.yml`)에서 진행해야 합니다.
