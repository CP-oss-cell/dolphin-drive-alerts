# Dolphin Drive Alerts v0.17.57 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.56` (`versionCode = 82`) → **신규 버전**: `v0.17.57` (`versionCode = 83`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## v0.17.57 신규 기능: 후방 센서 · 사이드 카메라 융합 후측방(BSD) 좌/우 방향 판별
- **기존 보존 핵심 유지**: `ReferenceVehicleEventBridge.kt`를 수정하지 않고, `DrivingAlertService`의 `AlertGate` 단계에서 `BSD_WARNING(Side.UNKNOWN)` 알림을 가로채 좌/우 근거가 확보된 경우에만 `Side.LEFT`("왼쪽 후측방 조심") / `Side.RIGHT`("오른쪽 후측방 조심")로 안전하게 보강합니다.
- **신규 모듈**:
  - `vehicle/BsdSideFusionClassifier.kt`: 후방 레이더/초음파 센서(`BYDAutoRadarDevice` 좌/우 후방 채널)와 사이드 카메라 분석 결과를 융합해 좌/우 판별. 근거가 불충분하면 기존 `"후측방 조심"`(`Side.UNKNOWN`)으로 안전 폴백.
  - `camera/SideCameraBsdAnalyzer.kt`: 주행 중 카메라를 상시 켜지 않고, BSD 활성 또는 방향지시등 작동 시에만 최대 4초간 `320×240` YUV 프레임의 좌/우 사이드 ROI(BYD 4분할 AVM 좌하/우하 또는 좌/우 절반) 모션 에너지를 비교한 뒤 자동 반납(후진 기어·후측방 카메라 오버레이 활성 시 자동 양보).
  - `camera/BsdSideInferencePreferences.kt`: ON/OFF, 판별 모드(융합 / 후방 센서 전용 / 사이드 카메라 전용), 카메라 레이아웃 설정 저장.
- **UI 통합 (`MainActivity.kt` → `[주행 알림] → BSD 후측방 감지`)**:
  - `후측방 좌/우 구분 (후방 센서 · 사이드 카메라)` 토글, 판별 모드/레이아웃 선택 Spinner, `◀ 왼쪽 후측방 테스트` / `오른쪽 후측방 테스트 ▶` 즉시 음성 테스트 버튼 추가.

## 검증 결과 및 한계
- `python3 tools/verify_v01757_bsd_side_fusion.py` 정적·회귀·렉서 검증 통과.
- 현재 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions(`DolphinDriveAlerts_v0.17.57_Source.yml`)에서 진행해야 합니다.
