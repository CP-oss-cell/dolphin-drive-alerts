# Dolphin Drive Alerts v0.17.62 릴리즈 노트 (2026-11-25)

- **기준 버전**: `v0.17.61` (`versionCode = 87`) → **신규 버전**: `v0.17.62` (`versionCode = 88`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## 변경 사항
- **DPI 관련 메뉴 전부 삭제 (`ui/MainActivity.kt`)**:
  - `[화면 · 분할 · 카메라]`에서 `"앱별 DPI · 순정 앱 복구"` 카드 및 `AppPolicyActivity` 메뉴 진입점을 완전히 제거했습니다.
  - 카테고리 요약 및 최초 실행 안내 문구에서 DPI 항목을 모두 정리했습니다.
  - 단, 과거 버전에서 임시 DPI가 남아 있던 차량을 위해 앱 시작 시 안전 복구(`TemporaryAppDpiController.recoverOnStartup`)만 내부적으로 유지합니다.
- **12.8인치 디스플레이 인식 관련 기술 검토 결과**:
  - BYD DiLink의 10.1인치/12.8인치 판별은 커널 DTB 및 읽기 전용 시스템 속성에 고정되어 있어 일반 앱·로컬 ADB(`wm size 1920x1080`)로는 12.8인치 하드웨어로 위장할 수 없으며, 논리 해상도 강제 변경 시 터치 오차·글자 뭉개짐·순정 360/공조 화면 깨짐 위험이 있어 기능을 추가하지 않았습니다.
