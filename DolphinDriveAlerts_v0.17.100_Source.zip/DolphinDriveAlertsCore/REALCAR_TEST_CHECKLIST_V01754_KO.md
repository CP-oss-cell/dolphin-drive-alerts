# Dolphin Drive Alerts v0.17.54 실차 테스트 체크리스트

## 1. GitHub Actions 빌드 및 설치
- [ ] `DolphinDriveAlerts_v0.17.54_Source.zip`과 `DolphinDriveAlerts_v0.17.54_Source.yml`로 Actions 빌드 실행
- [ ] `verify_v01754_all_features.py`, `:app:compileDebugKotlin`, `:app:assembleDebug` 성공 확인
- [ ] APK 설치 후 홈 상단의 **업데이트 후 필수 확인 · BYD 자동 실행 허용** 배너 표시 확인 → 차량 설정에서 '백그라운드 앱 차단' 해제 후 배너 닫기

## 2. v0.17.54 신규 6대 기능 실차 검증
- [ ] **미디어 덕킹·복원**: 음악 재생 중 `[주행 알림]` 음성 테스트 실행 → 음악 볼륨이 일시적으로 낮아졌다가 음성 종료 후 자동 복원되는지 확인 (음악 정지 상태에서는 자동 재생되지 않아야 함)
- [ ] **알림별 개별 음성·볼륨**: `[23종 알림 개별 설정]`에서 특정 알림(예: 후측방 조심)의 칩을 눌러 개별 음성/볼륨 지정 후 `▶` 미리듣기 확인
- [ ] **우선순위 보호**: 긴급 경고 재생 직후 낮은 우선순위 알림이 긴급 경고를 끊지 않는지 로그(`AUDIO_PREEMPT_BLOCKED`) 확인
- [ ] **시동 자동 실행 전면 검증**: 시동 자동 실행 후 로그에서 `STEP_LAUNCH_REQUEST`와 `STEP_FOREGROUND_READBACK`이 분리 기록되는지 확인
- [ ] **BYD 권한 · FeatureIds 전수 스캔**: `[진단 · 로그]` → `BYD 권한 · FeatureIds 전수 스캔 (읽기 전용)` 실행 → 8종 권한 허용 여부 및 `Adas`/`Instrument`/`Setting` 응답값 확인 (주행모드 ECO→NORMAL→SPORT 전환 전후 2회 비교 시 NORMAL 확정 ID 식별 가능)

## 3. UI · 아이콘 · 기존 기능 회귀 확인
- [ ] 10.1인치 6개 기능 카드(3×2), 다크/라이트 모드 전환, 화면 회전 통합 패널, 중복 제거 상태 확인
- [ ] 오토홀드, 회생제동, BSD+깜박이, 시동 자동 실행, 분할화면 복원 정상 유지 확인
