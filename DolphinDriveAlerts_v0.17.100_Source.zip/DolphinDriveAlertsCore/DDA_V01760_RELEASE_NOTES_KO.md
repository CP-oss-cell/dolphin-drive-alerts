# Dolphin Drive Alerts v0.17.60 통합 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.59` (`versionCode = 85`) → **신규 버전**: `v0.17.60` (`versionCode = 86`)
- **패키지명**: `com.byd.dolphin.drivealerts`

## 1. 초저리소스 · 고효율 주행 녹화 (블랙박스) 전면 완성
- **Zero-Copy 하드웨어 H.264 + 조건부 분석 게이트 (`camera/VehicleCameraHub.kt`)**:
  - `Camera2 → MediaRecorder.surface` 직접 하드웨어 인코딩(24fps 저발열)과 단일 카메라 공유 허브 구조.
  - 일반 정속 주행 중에는 앞차 출발·후측방 분석을 `0ms` 조기 반환(early-return)해 CPU·발열·지연을 최소화.
- **저장 매체(내장/USB/SD) · 자동 폴백 · 소프트 포맷 (`camera/VehicleCameraHub.kt`, `ui/DashcamActivity.kt`)**:
  - `getExternalFilesDirs()`로 내장·외장 USB/SD 저장소를 자동 탐색·선택하며, 외장 분리 시 내장으로 자동 폴백.
  - 녹화 폴더만 안전하게 비우는 소프트 포맷(일반만 / 이벤트 포함 전체 선택) 지원.
- **이벤트 보호 녹화 + 프리롤(직전 구간 보존) + 상한 순차 삭제**:
  - `normal/`과 `event/` 폴더 분리. G-센서 충격, 급감속(1.2초 내 18km/h 이상 급감), 원터치 수동 잠금 시 **현재 구간 + 직전 완료 구간(프리롤)**을 `event/` 보호 폴더로 잠금 복사.
  - 이벤트 파일은 일반 순환 삭제에서 보호되며, 설정 개수 상한(10/20/30/50개) 초과 시에만 가장 오래된 이벤트부터 순차 삭제.
- **주행 정보·GPS·SRT 자막 동기화 저장 및 오프라인 뷰어 (`camera/DashcamTelemetryRecorder.kt`, `ui/DashcamViewerActivity.kt`)**:
  - 모든 MP4와 동기화된 `.jsonl`(기어·속도·브레이크·깜박이·GPS), `.gpx`(표준 GPS 트랙), `.srt`(영상 자막) 동시 저장.
  - 앱 내 `녹화 영상 · GPS 주행 궤적 뷰어`에서 일반/이벤트 영상 재생 + 기어/속도/브레이크 요약 + 오프라인 Canvas GPS 주행 경로 지도 표시.
- **고온 발열 보호**: 헤드유닛 온도 60°C 이상 시 안전 일시중지, 53°C 이하 복귀 시 자동 재개.

## 2. 현대·기아 프리미엄 사운드급 이퀄라이저 · 음장 전면 개편
- **EQ 켜면 볼륨 작아지는 문제 근본 해결 (`audio/GlobalEqualizerEngine.kt`, `audio/EqToneCurve.kt`)**:
  - 기존 무조건 `-maxGain` 전체 감쇠를 제거하고, `DynamicsProcessing`에 **10밴드 Pre-EQ + 3밴드 멀티밴드 컴프레서(MBC) + 소프트 리미터(-1dBFS) + 출력 게인 보상(기본 +2.0dB, 최대 +6.0dB)**을 결합해 볼륨 저하 없이 클리핑을 방지.
- **체감되는 음장(Reference / Surround / Cinema) · 공간감 · 운전석 정위감 (`ui/AudioTuningActivity.kt`)**:
  - 차량 스피커에서 `Virtualizer`가 미지원이어도 확실히 체감되는 음향 커브 + 3밴드 MBC 확장 + 좌/우 채널 스테이지 밸런스(-10~+10) + 10밴드(31Hz~16kHz) 정밀 조절 + 원터치 6종 프리셋(원음 / Meridian 스타일 / 딥 베이스 / 보컬 선명 / 콘서트홀 / 야간 드라이브) 제공.

## 3. 현대·기아 BVM 스타일 후측방 카메라 정밀 보정
- `camera/BsdCameraOverlayController.kt`, `camera/BsdCameraPreferences.kt`, `ui/BsdCameraSettingsActivity.kt`:
  - **현대·기아 BVM 추천 보정 원터치 프리셋** + 좌/우 반전(미러링), 상/하 반전, 시야각 확대(100~220%), 좌/우·상/하 각도 미세 이동(-40~+40%), 실시간 하드웨어 `ColorMatrix` 밝기·대비·채도 보정, Camera2 AE 노출 보정, 작동 속도 조건(전체 / 5~80 / 10~110 km/h) 적용.

## 4. 전체 메뉴 · UI · 아이콘 최종 정리 (중복 0건)
- 6대 기능 영역(`주행 알림`, `시동 · 자동 실행`, `화면 · 분할 · 카메라`, `오디오 · 내비`, `권한 · ADB`, `진단 · 로그`)과 28종 벡터 아이콘, 다크/라이트 모드 통일.
- `python3 tools/verify_v01760_final_suite.py` 정적·회귀·렉서 검증 통과. (로컬 환경에 Android SDK/네트워크가 없어 APK 컴파일은 GitHub Actions `DolphinDriveAlerts_v0.17.60_Source.yml`로 진행)
