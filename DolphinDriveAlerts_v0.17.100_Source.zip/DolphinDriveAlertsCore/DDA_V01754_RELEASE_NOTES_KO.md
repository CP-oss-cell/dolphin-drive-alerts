# Dolphin Drive Alerts v0.17.54 릴리즈 노트 (2026-11-24)

- **기준 버전**: `v0.17.53` (`versionCode = 79`) → **신규 버전**: `v0.17.54` (`versionCode = 80`)
- **패키지명**: `com.byd.dolphin.drivealerts` (기존 설치 호환성 및 사용자 설정 유지)
- **기반 포함**: v0.17.53의 전체 메뉴 UI·하위 메뉴·28종 커스텀 벡터 그래픽 아이콘 재설계 및 중복 메뉴 제거 전체 포함

## v0.17.54 신규 개선 6대 항목
1. **음성 출력 시 기존 미디어 자동 볼륨 낮춤(덕킹) 및 복원 (`audio/AlertAudioPlayer.kt`, `config/AlertPreferences.kt`, `ui/MainActivity.kt`)**
   - Android 공식 `AudioFocusRequest.Builder(AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)` 요청 후 재생 종료 `finally`에서 `abandonAudioFocusRequest()` 즉시 반납.
   - 순정 안전 경고음이나 정지 상태 미디어는 건드리지 않으며, `[주행 알림]` 메뉴에서 ON/OFF 전환 가능(기본 ON).
2. **알림 우선순위 보호 및 중복 끊김 방지 (`audio/AlertAudioPlayer.kt`)**
   - 현재 재생 중인 고우선순위 경고(도어 열림 `100`, BSD `80`, 차선이탈 `70`)가 재생 중일 때 낮은 우선순위 알림(기어·주행모드 등)이 이를 끊지 못하도록 보호(`AUDIO_PREEMPT_BLOCKED` 기록).
3. **시동 자동 실행의 '요청 전달(ACK)' vs '실제 전면 실행' 검증 분리 (`automation/AutoLaunchSequenceService.kt`)**
   - `am start -n $component` 요청 전달(`STEP_LAUNCH_REQUEST`) 직후 `ForegroundResolver.topToken()` / `packageName()`으로 실제 전면 진입 여부를 확인해 `STEP_FOREGROUND_READBACK`으로 별도 기록.
4. **알림별 개별 음성(여성/남성/효과음) 및 개별 볼륨 설정 (`config/AlertPreferences.kt`, `audio/AlertAudioPlayer.kt`, `ui/AlertEventSettingsActivity.kt`)**
   - 23종 각 알림 행에 개별 설정 칩 추가: 공통 따름 또는 알림별 음성 스타일·볼륨 단계를 독립 지정 가능하며 우측 `▶` 버튼으로 즉시 미리듣기 지원.
5. **BYD `BYDAUTO_*_COMMON` 8종 권한 점검 및 `BYDAutoFeatureIds` 전수 읽기 전용 스캐너 (`log/BydFeatureIdScanner.kt`, `AndroidManifest.xml`, `ui/MainActivity.kt`)**
   - `BYDAUTO_DOOR_LOCK_COMMON`, `BYDAUTO_PANORAMA_COMMON` 권한 선언 보강.
   - `[진단 · 로그]` → `BYD 권한 · FeatureIds 전수 스캔 (읽기 전용)`으로 8종 권한 상태와 `BYDAutoFeatureIds` 전체 상수의 읽기 응답을 수집·저장(ECU/CAN 쓰기 및 setter 호출 일체 없음).
6. **앱 업데이트 후 BYD '백그라운드 앱 차단' 재설정 1회 안내 배너 (`ui/MainActivity.kt`, `config/AlertPreferences.kt`)**
   - APK 설치/업데이트로 `versionCode`가 변경되면 홈 상단에 BYD 차량 설정의 백그라운드 차단 해제 안내 배너를 1회 표시(닫기 시 저장).

## 검증 결과 및 환경 한계
- **정적·회귀 검증 통과**: `python3 tools/verify_v01754_all_features.py` 통과 (`V01754_ALL_6_FEATURES_AND_REGRESSION_STATIC_GATES_PASS`).
- **보존 핵심 모듈 무결성**: `ReferenceVehicleEventBridge.kt`, `ModeNoticeCorrelator.kt`, `MediaPlaybackObserver.kt`, `SplitRecoveryService.kt`, `AlertEventCatalog.kt` SHA-256 무변경 유지 (`AlertAudioPlayer.kt`는 1·2·4번 기능 구현을 위해 의도적 갱신).
- **APK 컴파일 미실시**: 현재 작업 환경에 Android SDK·Gradle 캐시·외부 네트워크가 없어 실제 APK 컴파일은 수행하지 못했습니다. 동봉된 `DolphinDriveAlerts_v0.17.54_Source.yml`로 GitHub Actions에서 빌드하세요.
