# Dolphin Cluster V1.3 — 차량 내 진단 ZIP 공유·저장 + 테마 시안 표시 수정

## 이전 버전과의 관계
- V1.2를 삭제하지 않도록 **V1.3 별도 앱(`com.dolphin.clusterprobe.v13`)**으로 빌드합니다.
- V1.2의 `APK 선택·업데이트` 메뉴에서는 V1.3을 고를 수 없습니다(다른 패키지이므로 정상적으로 차단).
- 최초 V1.3은 USB/차량 다운로드의 APK를 차량 파일 관리자에서 실행해 설치하세요. PC는 필요 없습니다.
- V1.3 이후 업데이트는 앱 내 `APK 선택·업데이트`로 가능하지만, 동일한 앱 서명키가 필요합니다. 임시 debug 서명은 CI 실행마다 달라질 수 있어 안정적 업데이트를 보장하지 않습니다.

## 차량 앱의 기능
1. **테마 시연:** 센터 디스플레이 HTML WebView에서 고정 비율을 CSS padding 방식으로 렌더링. 블루·민트·앰버/미수신·경고 시연. 실제 계기판/차량 값 아님.
2. **차량 정보:** Android Build, 앱에서 볼 수 있는 DisplayManager 화면 목록, 설치 요청 허용 상태, 이전 로컬 ADB 결과.
3. **로컬 ADB 연결·승인:** 127.0.0.1:5555에 사용자 직접 승인으로 연결하고 읽기 전용 3종 조회. 연결 성공은 순정 RCC 수정 권한이 아닙니다.
4. **진단 ZIP 공유:** 앱이 진단 ZIP 생성 → 공유 앱 선택(파일 타입 application/zip). `diagnostics.txt`, `status.json`, `README_KO.txt` 포함. 사용자가 공유 전에 확인할 수 있도록 안내 팝업.
5. **진단 ZIP 저장:** Android 파일 저장기에서 USB/다운로드 폴더를 골라 저장. 공유 앱이 ZIP을 지원하지 않으면 이 기능 이용.
6. **진단 텍스트 공유:** 기존 텍스트 공유 유지.
7. **APK 선택·업데이트:** 동일 V1.3 패키지 APK만 수동 검증 후 Android Installer로 설치 요청. 자동/무인 설치 불가.

## 안전 제한
- 원본 OEM RCC 교체/서명우회, 루트/SELinux 변경, CAN 쓰기, 차량 주행 제어 없음.
- 공유 ZIP에 APK·RCC 펌웨어·ADB RSA 개인키/VIN을 추가 수집하지 않습니다. 단, 기존 진단 본문에 빌드 지문과 디스플레이 정보가 있어 공유 전 확인해야 합니다.
- `ro.build.system.fission_single_os` 앱 프로세스 조회에서는 UNAVAILABLE일 수 있고 ADB 셸 결과 `1`과는 권한/호출 경로가 다릅니다.
- `cat /sys/module/max96745/parameters/clu_size: Permission denied`는 정상적인 실패 정보이며 임의 권한 우회 금지.

## 빌드
- `DolphinClusterReadOnlyTrial-v1.3-source.zip`을 GitHub 저장소 루트에 올립니다.
- `.github/workflows/build-cluster-v13-zip-share.yml`을 별도로 생성합니다.
- Actions -> Build Dolphin Cluster V1.3 -> Run workflow.
- Artifact `DolphinCluster-V1.3-VEHICLE-APK`에서 APK 다운로드.
- 실제 GitHub Actions 빌드 및 실차 설치는 사용자 확인 전까지 **미검증**입니다.
