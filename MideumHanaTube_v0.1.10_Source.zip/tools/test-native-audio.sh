#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac -encoding UTF-8 -d "$TEMP" \
  "$ROOT/app/src/main/java/app/mideumhanatube/android/NativeVideoUrlRule.java" \
  "$ROOT/tools/TestNativeVideoUrlRule.java"
java -cp "$TEMP" app.mideumhanatube.android.TestNativeVideoUrlRule
python3 - "$ROOT" <<'PY'
import pathlib,sys
p=pathlib.Path(sys.argv[1]); base=p/'app/src/main/java/app/mideumhanatube/android'
main=(base/'MainActivity.java').read_text();svc=(base/'BackgroundAudioService.java').read_text();res=(base/'YouTubeStreamResolver.java').read_text()
build=(p/'app/build.gradle').read_text(); settings=(p/'settings.gradle').read_text()
for s in ["nativeAudioActive", "beginNativeHandoff()", "onUserLeaveHint", "onPause()", "lastKnownPositionMs", "ACTION_NATIVE_READY", "resumeVideoFromNative", "returnToVideoButton"]:assert s in main,s
for s in ["ExoPlayer.Builder", "ACTION_NATIVE_START", "nativePlayer.play()", "nativePlayer.pause()", "StreamInfo", "onIsPlayingChanged", "ACTION_NATIVE_FAILURE"]: assert s in svc+res,s
for s in ["com.github.teamnewpipe:NewPipeExtractor:v0.26.5", "androidx.media3:media3-exoplayer:1.11.1", "desugar_jdk_libs_nio:2.1.5"]:assert s in build,s
assert "https://jitpack.io" in settings
assert "getAudioStreams()" in res and "getVideoStreams()" in res
assert "setMediaItem(MediaItem.fromUri(result.streamUrl))" in svc
print('Native playback structural regression: 20 checks PASS')
PY
