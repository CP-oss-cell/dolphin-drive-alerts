package com.byd.dolphin.drivealerts.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.util.CoreLog

/** Ignition-scheduled, cancellable ordered launches. Manual and ignition triggers share one engine. */
class AutoLaunchSequenceService : Service() {
    @Volatile private var generation=0
    override fun onBind(intent:Intent?): IBinder?=null
    override fun onCreate(){
        super.onCreate()
        val m=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26)m.createNotificationChannel(NotificationChannel("app_sequence","차량 앱 자동 실행",NotificationManager.IMPORTANCE_LOW))
        startForeground(763,Notification.Builder(this,"app_sequence")
            .setContentTitle("시동 앱 실행 시퀀스").setSmallIcon(android.R.drawable.ic_media_play).build())
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_CANCEL){generation++;stopSelf();return START_NOT_STICKY}
        if(intent?.action!=ACTION_RUN) return START_NOT_STICKY
        val manual=intent.getBooleanExtra("manual",false)
        if(!manual && !FeatureProfiles.sequenceEnabled(this)) {stopSelf();return START_NOT_STICKY}
        val stepList=FeatureProfiles.steps(this).filter{it.enabled}
        if(stepList.isEmpty()){stopSelf();return START_NOT_STICKY}
        val seq=++generation
        Thread({runSteps(stepList,seq)},"dolphin-autostart-sequence").start()
        return START_NOT_STICKY
    }
    private fun runSteps(steps:List<LaunchStep>,seq:Int) {
        val power=getSystemService(PowerManager::class.java)
        val lock=power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"DriveAlerts:LaunchSequence")
        try {
            // Limit wake time and ignore app sequences longer than ten minutes.
            lock.acquire(600_000L)
            val launchStart=System.currentTimeMillis()
            for(step in steps) {
                if(seq!=generation || System.currentTimeMillis()-launchStart>600_000L) break
                if(!pause(step.delaySeconds,seq))break
                if(step.packageName.startsWith("split:")) {
                    val profileId=step.packageName.removePrefix("split:")
                    val profile=FeatureProfiles.splits(this).firstOrNull{it.id==profileId}
                    if(profile==null){CoreLog.w("AUTO_SEQUENCE","Missing split profile: $profileId");continue}
                    val result=VehicleSplitEngine.launch(this,profile)
                    CoreLog.i("AUTO_SEQUENCE","split=${profile.title} result=${result.message}")
                    if(result.success)SplitRecoveryService.start(this,profile.id)
                    continue
                }
                val component=AppSelection.safeComponent(this,step.packageName)
                if(component==null){CoreLog.w("AUTO_SEQUENCE","No installed launcher: ${step.packageName}");continue}
                // Never override a running OEM reverse/360 camera view.
                val foreground=VehicleSplitEngine.screenToken(this).orEmpty()
                if(Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground)) {
                    CoreLog.w("AUTO_SEQUENCE","OEM camera foreground; skipped ${step.packageName}")
                    continue
                }
                val launched=NativeAdbClient.executeShell(this,"am start -n $component")
                CoreLog.i("AUTO_SEQUENCE","pkg=${step.packageName} delay=${step.delaySeconds} result=${launched.success} msg=${launched.message}")
                if(!launched.success)continue
                if(step.isMedia){
                    if(!pause(step.playDelaySeconds,seq))break
                    val played=MediaPlaybackObserver.play(this,step.packageName)
                    CoreLog.i("AUTO_SEQUENCE","media=${step.packageName} playDelay=${step.playDelaySeconds} requested=$played")
                }
                if(step.restoreBackground){
                    // Do not kill the media process: restore launcher task after requesting playback.
                    val home=NativeAdbClient.executeShell(this,"input keyevent 3")
                    CoreLog.i("AUTO_SEQUENCE","background=${step.packageName} home=${home.success}")
                }
            }
        }catch(t:Throwable){CoreLog.w("AUTO_SEQUENCE","sequence failure: ${t.message}")}
        finally {if(lock.isHeld)lock.release();if(seq==generation)stopSelf()}
    }
    private fun pause(seconds:Int,seq:Int):Boolean {
        repeat(seconds.coerceIn(0,600)) {if(generation!=seq)return false;try{Thread.sleep(1000)}catch(_ : InterruptedException){return false}}
        return generation==seq
    }
    override fun onDestroy(){generation++;super.onDestroy()}
    companion object {
        const val ACTION_RUN="com.byd.dolphin.drivealerts.AUTO_SEQUENCE_RUN"
        const val ACTION_CANCEL="com.byd.dolphin.drivealerts.AUTO_SEQUENCE_CANCEL"
        fun start(context:Context, manual:Boolean=false) {
            try {context.startForegroundService(Intent(context,AutoLaunchSequenceService::class.java)
                .setAction(ACTION_RUN).putExtra("manual",manual))}
            catch(t:Throwable){CoreLog.w("AUTO_SEQUENCE","start blocked: ${t.message}")}
        }
    }
}
