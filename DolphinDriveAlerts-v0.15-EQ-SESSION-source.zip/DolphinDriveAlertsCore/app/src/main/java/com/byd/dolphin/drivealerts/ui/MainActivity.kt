package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.KeyEvent
import android.widget.AdapterView
import android.widget.*
import com.byd.dolphin.drivealerts.audio.VoiceAssetCatalog
import com.byd.dolphin.drivealerts.log.UnifiedLogCapture
import com.byd.dolphin.drivealerts.automation.SplitProfilesActivity
import com.byd.dolphin.drivealerts.automation.AutoLaunchSettingsActivity
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.steering.SteeringTriggerMode
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

class MainActivity : Activity() {
    private lateinit var eventSpinner: Spinner
    private lateinit var sideSpinner: Spinner
    private lateinit var oneShotStatus: TextView
    private lateinit var unifiedCaptureStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(buildUi())
        } catch (t: Throwable) {
            setContentView(TextView(this).apply {
                text = "Dolphin Drive Alerts SAFE START\n\nUI 초기화 오류: ${t.javaClass.simpleName}: ${t.message}\n\n이 화면이 보이면 앱 자체 실행은 정상입니다."
                textSize = 18f
                setPadding(32, 32, 32, 32)
            })
        }
        runCatching { DrivingAlertService.start(this) }
            .onFailure {
                Toast.makeText(this, "차량 감시 서비스 시작 실패: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 24, 30, 30)
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "주행 보조 알림 · CORE 0.14 통합 후보 · 회전 + EQ + 분할 + 시동 앱 실행"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "v0.13 화면 분할·시동 순차 실행 기능을 보존하고, 로그 수집을 시작/종료 두 버튼으로 통합한 미검증 후보입니다. Android Gradle/실차 동작 검증이 완료된 정식 버전이 아닙니다."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val raw14 = RadioButton(this).apply { text = "운전석(raw14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(raw14); route.addView(media); box.addView(route)
        when (AlertPreferences.route(this)) {
            OutputRoute.DRIVER_STREAM14 -> driver.isChecked = true
            OutputRoute.DRIVER_RAW14 -> raw14.isChecked = true
            OutputRoute.MEDIA -> media.isChecked = true
        }
        route.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setRoute(this, when (id) {
                driver.id -> OutputRoute.DRIVER_STREAM14
                raw14.id -> OutputRoute.DRIVER_RAW14
                else -> OutputRoute.MEDIA
            })
        }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개 + 단발 기본음 남/여 2개(총 60개)를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        box.addView(section("알림 테스트"))
        eventSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, AlertEvent.entries.map { "${it.name} · ${it.phrase}" }) }
        sideSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Side.entries.map { it.name }) }
        box.addView(eventSpinner); box.addView(sideSpinner)
        box.addView(Button(this).apply {
            text = "선택 알림 즉시 재생"
            setOnClickListener {
                DrivingAlertService.test(this@MainActivity, AlertEvent.entries[eventSpinner.selectedItemPosition], Side.entries[sideSpinner.selectedItemPosition])
            }
        })

        box.addView(section("핸들 메뉴/이전 3연타 · 단발 음성"))
        box.addView(TextView(this).apply {
            text = "메뉴/모드 또는 이전 버튼을 빠르게 3번(첫 입력부터 1.2초 이내) 누르면 단발 음성을 한 번 재생합니다. OverDrive v48.18 정적 근거의 BYD 후보값 289=Mode/Menu, 88=Previous를 기본 사용하고 Android MENU/BACK은 호환 fallback으로만 남깁니다. BYD 롱키 302/303/306/312는 별도 OEM keyCode로 기록하며 3연타로 오인하지 않습니다. 키 입력은 감시만 하고 소비하지 않아 순정 단일/이중 클릭 동작은 그대로 둡니다. 현재는 운전석 stream 14 또는 미디어 경로로 재생합니다. Dolphin의 외부 AVAS 스피커는 순정/MCU 테스트톤은 확인됐지만 Android WAV/PCM 직접 라우팅은 현재 근거상 실패했으므로 임의 음성 출력 기능으로 연결하지 않습니다."
            textSize = 13f
        })
        box.addView(CheckBox(this).apply {
            text = "핸들 3연타 단발 음성 사용"
            isChecked = SteeringTriggerPreferences.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> SteeringTriggerPreferences.setEnabled(this@MainActivity, checked) }
        })
        val triggerModes = SteeringTriggerMode.entries
        val triggerLabels = mapOf(
            SteeringTriggerMode.BYD_MODE to "메뉴/모드 버튼 (BYD keyCode 289 · Android MENU fallback)",
            SteeringTriggerMode.BYD_PREVIOUS to "이전 버튼 (BYD keyCode 88 · Android BACK fallback)",
            SteeringTriggerMode.EITHER to "메뉴/모드 289 또는 이전 88 (fallback 포함)",
            SteeringTriggerMode.LEARNED to "실차에서 학습한 버튼"
        )
        box.addView(TextView(this).apply { text = "3연타 감지 버튼"; textSize = 14f })
        box.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, triggerModes.map { triggerLabels[it] ?: it.name })
            setSelection(triggerModes.indexOf(SteeringTriggerPreferences.mode(this@MainActivity)).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    SteeringTriggerPreferences.setMode(this@MainActivity, triggerModes[position])
                    refreshOneShotStatus()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        })
        oneShotStatus = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 8) }
        box.addView(oneShotStatus)
        refreshOneShotStatus()
        box.addView(Button(this).apply {
            text = "내 단발 음성파일 선택 (WAV 권장 · MP3/M4A/OGG 가능)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(i, REQ_ONE_SHOT_AUDIO)
            }
        })
        box.addView(Button(this).apply {
            text = "선택 음성 삭제 · 기본 '빵빵, 차 좀 지나갈게요' 사용"
            setOnClickListener {
                SteeringTriggerPreferences.clearSound(this@MainActivity)
                refreshOneShotStatus()
                Toast.makeText(this@MainActivity, "기본 단발 음성으로 복원했습니다.", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "단발 음성 즉시 테스트"
            setOnClickListener { DrivingAlertService.playOneShot(this@MainActivity, "manual_test") }
        })
        box.addView(Button(this).apply {
            text = "실차 핸들 버튼 학습 시작 · 15초 안에 원하는 버튼 1회 누르기"
            setOnClickListener {
                SteeringTriggerPreferences.armLearning(this@MainActivity)
                SteeringTriggerPreferences.setMode(this@MainActivity, SteeringTriggerMode.LEARNED)
                DrivingAlertService.marker(this@MainActivity, "STEERING_LEARN_ARMED", "15s")
                refreshOneShotStatus("학습 대기 중: 15초 안에 핸들 메뉴/이전 버튼을 1번 누르세요.")
                Toast.makeText(this@MainActivity, "15초 안에 사용할 핸들 버튼을 한 번 누르세요.", Toast.LENGTH_LONG).show()
            }
        })
        box.addView(Button(this).apply {
            text = "핸들 버튼 학습 상태 새로고침"
            setOnClickListener { refreshOneShotStatus() }
        })
        box.addView(TextView(this).apply {
            text = "0.11부터는 SubAI에서 실차 검증된 INSTRUMENT_2IN1_MENU_STATE를 우선 감지합니다. 메뉴/이전 버튼 3회는 1초 안의 1↔2 상태 변화 6회 패턴으로 단발 음성을 재생합니다. 접근성 KeyEvent 방식은 보조 경로로만 유지합니다."
            textSize = 13f
        })

        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(CheckBox(this).apply {
            text = "시동 시 자동 백그라운드 실행"
            isChecked = AlertPreferences.autoStartEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> AlertPreferences.setAutoStartEnabled(this@MainActivity, checked) }
        })
        box.addView(TextView(this).apply {
            text = "기본값 ON. 최초 설치 후 앱을 1회 실행하면 이후 BOOT_COMPLETED, Android/BYD/Qualcomm Quick Boot, USER_PRESENT/USER_UNLOCKED, SCREEN_ON, ACTION_POWER_CONNECTED, 앱 업데이트와 BYD ACC_ON/IGN_ON/ACC_MODE_CHANGED 신호에서 foreground 서비스 시작을 재요청합니다. ACC_OFF/ACTION_POWER_DISCONNECTED는 종료측 상태로 기록만 하고 서비스를 새로 시작하지 않습니다. 서비스는 START_STICKY + stopWithTask=false라 최근 앱에서 지워도 계속 유지됩니다. 사용자가 Android 설정에서 강제 종료(force-stop)한 경우만 정책상 앱을 다시 한 번 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(Button(this).apply {
            text = "시동 앱 자동실행 · 여러 앱 순서/초 단위/미디어 재생 관리"
            setOnClickListener { startActivity(Intent(this@MainActivity,AutoLaunchSettingsActivity::class.java)) }
        })
        box.addView(section("화면 분할 · AutoSplit 방식 프로필"))
        box.addView(Button(this).apply {
            text = "2앱 분할 프로필 · 비율 % · 이름/바로가기 · 카메라 복원"
            setOnClickListener { startActivity(Intent(this@MainActivity,SplitProfilesActivity::class.java)) }
        })
        box.addView(section("통합 로그 수집"))
        box.addView(TextView(this).apply {
            text = "수집 시작을 누른 뒤 기능을 시험하고, 수집 종료를 누르면 해당 구간의 차량 RAW·음성·앱·오류 기록과 시스템 진단을 ZIP 하나로 Download 폴더에 저장합니다. 시동 주행알림 서비스는 수집 종료 후에도 정상 유지됩니다."
            textSize = 13f
        })
        unifiedCaptureStatus = TextView(this).apply { textSize = 14f; setPadding(0, 8, 0, 8) }
        box.addView(unifiedCaptureStatus)
        updateCaptureStatus()
        box.addView(Button(this).apply {
            text = "수집 시작"
            setOnClickListener {
                runCatching { DrivingAlertService.beginUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "수집 시작 요청 중… (서비스 알림에 결과 표시)" }
                    .onFailure { unifiedCaptureStatus.text = "시작 요청 실패: ${it.message}" }
            }
        })
        box.addView(Button(this).apply {
            text = "수집 종료"
            setOnClickListener {
                runCatching { DrivingAlertService.endUnifiedCapture(this@MainActivity) }
                    .onSuccess { unifiedCaptureStatus.text = "로그 저장 요청 중… (완료 시 상단 알림 및 Download 폴더 확인)" }
                    .onFailure { unifiedCaptureStatus.text = "저장 요청 실패: ${it.message}" }
            }
        })

        box.addView(section("실차 ADB / DPI 개별 작동 시험"))
        box.addView(TextView(this).apply {
            text = "정차 상태에서만 140 테스트 후 반드시 원복을 확인하세요. ADB 승인창이 차량에 뜨면 허용해야 합니다."
            textSize = 13f
        })
        fun runAdbTest(cmd: String) {
            Thread {
                val result = com.byd.dolphin.drivealerts.dpi.NativeAdbClient.executeShell(this@MainActivity, cmd)
                runOnUiThread {
                    Toast.makeText(this@MainActivity,
                        "$cmd: ${if(result.success) "OK" else "FAILED"} ${result.output.take(160)} ${result.message.take(160)}",
                        Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        box.addView(Button(this).apply {
            text = "ADB 필수 권한 자동 적용 · 접근성/배터리 예외"
            setOnClickListener {
                isEnabled = false
                Thread {
                    val result = com.byd.dolphin.drivealerts.dpi.PermissionBootstrapper.apply(this@MainActivity)
                    runOnUiThread {
                        isEnabled = true
                        Toast.makeText(this@MainActivity, result.lines.joinToString("\n").take(1800), Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
        })
        box.addView(Button(this).apply { text = "ADB 연결/현재 DPI 조회"; setOnClickListener { runAdbTest("wm density") } })
        box.addView(Button(this).apply { text = "DPI 140 직접 시험"; setOnClickListener { runAdbTest("wm density 140") } })
        box.addView(Button(this).apply { text = "DPI 순정 원복"; setOnClickListener { runAdbTest("wm density reset") } })

        box.addView(section("화면 회전 / 지정 앱 정책"))
        box.addView(Button(this).apply { text = "지정 앱 선택 · 회전 / DPI / 출력 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(TextView(this).apply {
            text = "화면 회전은 Screen Orientation Control 7.10.1에서 확인한 0×0 투명 overlay 방식으로 구현했습니다. 앱별 가로/세로/반전/센서 규칙을 저장하며 UsageStats 1초 감시 + 접근성 이벤트를 함께 사용합니다."
            textSize = 13f
        })
        box.addView(Button(this).apply { text = "접근성 서비스 설정 열기"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        box.addView(Button(this).apply {
            text = "화면 위 표시 권한 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        })
        box.addView(Button(this).apply {
            text = "사용기록 접근 권한 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        box.addView(TextView(this).apply {
            text = "DPI: 선택 앱이 전면에 있을 때 140/120/수동값 적용. UI 차단 방지를 위해 ADB를 백그라운드에서 실행합니다.\n지정 앱 음성 선택은 이 앱 자체 안내음에 반영됩니다. 다른 앱이 재생하는 소리의 운전석 강제 이동은 별도 BYD 훅이 필요합니다."
            textSize = 13f
        })

        box.addView(section("이퀄라이저 / 음향 효과"))
        box.addView(Button(this).apply {
            text = "저음 · 중음 · 고음 / Centerpoint 360 / Sound Focus"
            setOnClickListener { startActivity(Intent(this@MainActivity, AudioTuningActivity::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "표준 Android AudioEffect 기반입니다. Reference / Surround / Cinema 3모드와 공간 확장 효과를 단순 UI로 제공합니다. Bose·현대·기아의 순정 DSP 알고리즘 자체를 복제한 것은 아닙니다."
            textSize = 13f
        })

        val required = VoiceAssetCatalog.requiredAssetNames().size
        box.addView(section("상태"))
        box.addView(TextView(this).apply {
            text = "주행 알림 음성 슬롯: $required 개 + 단발 기본음 2개(총 60개)\nv0.12 추가: 앱별 overlay 화면 회전 + Global Mix/세션 EQ + 기본 ON 자동 백그라운드 실행 + DA-017 저빈도 read-only 신호 discovery\nv0.11 복구 유지: SubAI 기반 ACC/회생/Snow/SPORT/핸들 3연타 + 기어/EPB\nADB: RSA 승인 대기/재시도 + WRITE_SECURE_SETTINGS + overlay + UsageStats + 접근성 + 배터리 예외\nAVH/BSD 위험좌우/차선/앞차/DOW: 근거 확정 전 자동 발화 금지, RAW 로그 유지"
            textSize = 13f
        })
        return root
    }

    override fun onResume() {
        super.onResume()
        updateCaptureStatus()
    }

    private fun updateCaptureStatus() {
        if (!::unifiedCaptureStatus.isInitialized) return
        val state = UnifiedLogCapture.state(this)
        unifiedCaptureStatus.text = when (state.status) {
            UnifiedLogCapture.RECORDING -> "수집 중 · 저장은 '수집 종료' 버튼으로 완료"
            UnifiedLogCapture.SAVING -> "저장 중 · 완료되면 상단 알림으로 안내"
            UnifiedLogCapture.FAILED -> "저장 실패 · '수집 종료'를 다시 눌러 재시도"
            else -> "대기 중 · '수집 시작'을 눌러주세요"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ONE_SHOT_AUDIO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            Thread {
                val result = SteeringTriggerPreferences.importSound(this, uri)
                runOnUiThread {
                    result.fold(
                        onSuccess = {
                            refreshOneShotStatus()
                            Toast.makeText(this, "단발 음성 등록 완료: $it", Toast.LENGTH_LONG).show()
                        },
                        onFailure = { Toast.makeText(this, "음성 등록 실패: ${it.message}", Toast.LENGTH_LONG).show() }
                    )
                }
            }.start()
        }
    }

    private fun refreshOneShotStatus(extra: String? = null) {
        if (!::oneShotStatus.isInitialized) return
        val keyCode = SteeringTriggerPreferences.learnedKeyCode(this)
        val scanCode = SteeringTriggerPreferences.learnedScanCode(this)
        val learned = if (keyCode >= 0) "${KeyEvent.keyCodeToString(keyCode)} / keyCode=$keyCode / scanCode=$scanCode" else "아직 없음"
        val learning = if (SteeringTriggerPreferences.isLearning(this)) " · 현재 학습 대기 중" else ""
        oneShotStatus.text = buildString {
            append("현재 음성: ${SteeringTriggerPreferences.soundName(this@MainActivity)}\n")
            append("감지 모드: ${SteeringTriggerPreferences.mode(this@MainActivity)}$learning\n")
            append("학습된 버튼: $learned")
            if (!extra.isNullOrBlank()) append("\n$extra")
        }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }

    companion object {
        private const val REQ_ONE_SHOT_AUDIO = 6106
    }
}
