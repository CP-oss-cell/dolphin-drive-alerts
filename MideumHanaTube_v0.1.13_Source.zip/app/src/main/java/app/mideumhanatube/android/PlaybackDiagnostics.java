package app.mideumhanatube.android;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import androidx.media3.common.Player;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * App-private, bounded event trace (no URLs, cookies, tokens, search terms or titles).
 * Only explicit event codes and numeric player status are recorded. User can save
 * a diagnostic ZIP; there is no network upload and no runtime storage permission.
 */
public final class PlaybackDiagnostics {
    private static final String TRACE = "playback_events.jsonl";
    private static final String PREF = "mht_diag_sequences";
    private static final int KEEP_LINES = 300;
    private static final long MAX_BYTES = 128 * 1024;
    private static int eventCount = -1;
    private PlaybackDiagnostics() { }

    public static synchronized long nextSession(Context c) {
        long next = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong("next", 0) + 1;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putLong("next", next).apply();
        return next;
    }

    public static synchronized void event(Context c, long session, String event, String category, Player player) {
        try {
            JSONObject data = new JSONObject();
            data.put("wall_ms", System.currentTimeMillis());
            data.put("elapsed_ms", SystemClock.elapsedRealtime());
            data.put("session", session);
            data.put("event", safeCode(event));
            data.put("category", safeCode(category));
            if (player != null) {
                data.put("state", player.getPlaybackState());
                data.put("play_when_ready", player.getPlayWhenReady());
                data.put("is_playing", player.isPlaying());
                data.put("suppression", player.getPlaybackSuppressionReason());
                data.put("position_ms", Math.max(0, player.getCurrentPosition()));
            }
            File target = new File(c.getFilesDir(), TRACE);
            if (eventCount < 0) eventCount = count(c);
            try (BufferedWriter out = new BufferedWriter(new FileWriter(target, true))) {
                out.write(data.toString()); out.newLine();
            }
            eventCount++;
            if (eventCount > KEEP_LINES || target.length() >= MAX_BYTES) {
                trim(target);
                eventCount = count(c);
            }
        } catch (Exception ignored) {
            // Diagnostics must never break playback.
        }
    }

    /** An allowlist of characters; never pass URL or exception.toString here. */
    private static String safeCode(String raw) {
        if (raw == null) return "none";
        if (!raw.matches("[a-zA-Z0-9_\\-]{1,64}")) return "redacted";
        return raw;
    }

    public static String categorize(Throwable error) {
        Throwable cause = error;
        for (int depth = 0; cause != null && depth < 8; depth++, cause = cause.getCause()) {
            if (cause instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                int code = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException)cause).responseCode;
                if (code == 401) return "HTTP_401";
                if (code == 403) return "HTTP_403";
                if (code >= 500) return "HTTP_5XX";
                return "HTTP_OTHER";
            }
            if (cause instanceof java.net.SocketTimeoutException) return "NETWORK_TIMEOUT";
            if (cause instanceof java.net.UnknownHostException) return "DNS_FAILURE";
            if (cause instanceof java.net.ConnectException) return "NETWORK_CONNECT";
        }
        return "PLAYER_OR_STREAM_ERROR";
    }

    private static void trim(File path) throws IOException {
        ArrayDeque<String> lines = new ArrayDeque<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.addLast(line);
                if (lines.size() > KEEP_LINES) lines.removeFirst();
            }
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path, false))) {
            for (String line : lines) { writer.write(line); writer.newLine(); }
        }
    }

    public static synchronized int count(Context c) {
        File trace = new File(c.getFilesDir(), TRACE);
        if (!trace.isFile()) return 0;
        int n = 0;
        try (BufferedReader in = new BufferedReader(new FileReader(trace))) {
            while (in.readLine() != null) n++;
        } catch (IOException ignored) { }
        return n;
    }

    /** Latest-session categorization. Never infer a server denial from mere buffering. */
    public static synchronized String diagnose(Context c) {
        File trace = new File(c.getFilesDir(), TRACE);
        if (!trace.isFile()) return "아직 자동 진단 기록이 없습니다.";
        long latest = 0;
        java.util.ArrayList<JSONObject> events = new java.util.ArrayList<>();
        try (BufferedReader in = new BufferedReader(new FileReader(trace))) {
            String line;
            while ((line = in.readLine()) != null) {
                JSONObject item = new JSONObject(line);
                long session = item.optLong("session", 0L);
                if (session > latest) { latest = session; events.clear(); }
                if (session == latest) events.add(item);
            }
        } catch (Exception ignored) { return "진단 기록을 읽을 수 없습니다."; }
        if (events.isEmpty()) return "아직 백그라운드 재생 요청이 없습니다.";
        boolean request = false, extracted = false, playing = false;
        boolean buffer = false, pip = false, failed = false, suppressed = false;
        boolean earlyStop = false;
        String failure = "";
        for (JSONObject item : events) {
            String ev = item.optString("event", "");
            String category = item.optString("category", "");
            if ("HANDOFF_REQUESTED".equals(ev)) request = true;
            if ("EXTRACT_OK".equals(ev)) extracted = true;
            if ("ACTUAL_PLAYING".equals(ev) && item.optBoolean("is_playing")) playing = true;
            if ("USER_LEAVE_HINT".equals(ev) && "AUTO_PIP_ON".equals(category)) pip = true;
            if ("PLAY_INTERRUPTED_EARLY".equals(ev)) earlyStop = true;
            if ("PLAYER_STATE".equals(ev) && "BUFFERING".equals(category)) buffer = true;
            if (("PLAYER_STATE".equals(ev) || "ACTUAL_PLAYING".equals(ev)) &&
                    "SUPPRESSED".equals(category)) suppressed = true;
            if ("PLAYER_ERROR".equals(ev) || "EXTRACT_ERROR".equals(ev) ||
                    "HANDOFF_FAILED".equals(ev) || "START_FOREGROUND_SERVICE_FAILED".equals(ev) ||
                    "FGS_DENIED".equals(ev) || "BUFFERING_TIMEOUT".equals(ev)) {
                failed = true;
                if ("HTTP_403".equals(category)) failure = "HTTP_403";
                else if ("HTTP_401".equals(category)) failure = "HTTP_401";
                else if (failure.isEmpty()) failure = ev;
            }
        }
        if ("HTTP_403".equals(failure)) return "미디어 서버 HTTP 403 접근 거부. Android 서비스 문제가 아닌 서버 접근 제한 가능성이 큽니다.";
        if ("HTTP_401".equals(failure)) return "미디어 서버 HTTP 401 인증 요구. 오디오 주소를 사용할 수 없습니다.";
        if ("FGS_DENIED".equals(failure) || "START_FOREGROUND_SERVICE_FAILED".equals(failure))
            return "Android가 백그라운드 미디어 서비스 시작을 제한했습니다.";
        if ("EXTRACT_ERROR".equals(failure)) return "영상의 독립 오디오 주소 추출 실패. 사이트/서버 지원 제약 가능성이 있습니다.";
        if (suppressed) return "Android 오디오 포커스 또는 시스템 재생 억제 상태가 기록됐습니다.";
        if (earlyStop) return "독립 플레이어가 잠깐 시작된 뒤 1.5초 이내 중단된 이벤트를 발견했습니다. 전후 상태는 진단 ZIP에 기록돼 있습니다.";
        if ("BUFFERING_TIMEOUT".equals(failure)) return "오디오 주소를 얻었으나 실제 재생 준비가 시간 초과됐습니다.";
        if ("PLAYER_ERROR".equals(failure)) return "Media3 재생 엔진 오류 발생. 진단 ZIP의 PLAYER_ERROR 이벤트를 확인해 주세요.";
        if (playing && !failed) return "독립 재생 엔진이 실제 재생 상태를 보고했습니다. 소리 출력 여부는 기기에서 확인이 필요합니다.";
        if (pip && !request) return "홈 이동 시 자동 PIP가 선택되어 독립 오디오 전환이 실행되지 않았습니다.";
        if (!request) return "홈 전환 요청이 없거나 재생 중인 영상으로 인식되지 않았습니다.";
        if (!extracted) return "스트림 주소 확인 중 또는 실패. 아직 실제 재생은 확인되지 않았습니다.";
        if (buffer) return "스트림은 조회됐으나 버퍼링이 지속 중입니다. 실제 출력은 아직 확인되지 않았습니다.";
        if (failed) return "전환 실패 기록이 있습니다. 진단 ZIP의 순차 이벤트를 확인해 주세요.";
        return "독립 재생을 준비 중이며 실제 재생 성공 신호는 아직 없습니다.";
    }

    private static String filename() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        return "MideumHanaTube_PlaybackDiagnostics_" + f.format(new Date()) + ".zip";
    }

    public static String suggestedFilename() { return filename(); }

    public static synchronized void writeZip(Context c, OutputStream output) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(output)) {
            JSONObject summary = new JSONObject();
            try {
                summary.put("schema", "mht-playback-trace-v1");
                summary.put("generated_at_ms", System.currentTimeMillis());
                summary.put("android_sdk", Build.VERSION.SDK_INT);
                summary.put("manufacturer", Build.MANUFACTURER);
                summary.put("model", Build.MODEL);
                summary.put("app_version", "0.1.13");
                summary.put("events", count(c));
                summary.put("automatic_diagnosis", diagnose(c));
                summary.put("raw_urls_cookies_titles_recorded", false);
                summary.put("background_enabled", c.getSharedPreferences("mideumhanatube_settings", Context.MODE_PRIVATE)
                        .getBoolean("background_audio", true));
                summary.put("auto_pip", c.getSharedPreferences("mideumhanatube_settings", Context.MODE_PRIVATE)
                        .getBoolean("auto_pip_on_home", false));
                summary.put("note", "Use event/sequence/state/play_when_ready/is_playing/suppression to identify root cause; no stream URL is stored.");
            } catch (Exception ex) { throw new IOException("diagnostic summary", ex); }
            zip.putNextEntry(new ZipEntry("summary.json"));
            zip.write(summary.toString(2).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.putNextEntry(new ZipEntry("playback_events.jsonl"));
            File trace = new File(c.getFilesDir(), TRACE);
            if (trace.isFile()) {
                try (InputStream in = new FileInputStream(trace)) {
                    byte[] buffer = new byte[4096]; int read;
                    while ((read = in.read(buffer)) != -1) zip.write(buffer, 0, read);
                }
            }
            zip.closeEntry();
        } catch (org.json.JSONException impossible) { throw new IOException(impossible); }
    }

    /** Android 10+: save to public Downloads via MediaStore (scoped storage). */
    public static Uri saveToDownloads(Context c) throws IOException {
        if (Build.VERSION.SDK_INT < 29) throw new IOException("Use document picker below Android 10");
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename());
        values.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("Download folder unavailable");
        boolean ok = false;
        try {
            try (OutputStream out = c.getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("Cannot open output stream");
                writeZip(c, out);
            }
            ContentValues completed = new ContentValues();
            completed.put(MediaStore.MediaColumns.IS_PENDING, 0);
            c.getContentResolver().update(uri, completed, null, null);
            ok = true;
            return uri;
        } finally {
            if (!ok) c.getContentResolver().delete(uri, null, null);
        }
    }
}
