package app.mideumhanatube.android;

import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * Separate stream lookup from the Activity/WebView. Only URLs from the approved
 * YouTube website are accepted. This is an optional best-effort extractor: a
 * stream can be missing or expire at any time. GPL-3.0-or-later dependency.
 */
public final class YouTubeStreamResolver {
    private static volatile boolean initialized;
    private YouTubeStreamResolver() { }

    public static final class Result {
        public final String streamUrl;
        public final String title;
        public final String streamKind;
        Result(String streamUrl, String title, String streamKind) {
            this.streamUrl = streamUrl;
            this.title = title;
            this.streamKind = streamKind;
        }
    }

    public static Result resolve(String youtubeUrl) throws Exception {
        if (!isSupportedVideoUrl(youtubeUrl))
            throw new IOException("유튜브 영상 페이지 주소가 아닙니다.");
        synchronized (YouTubeStreamResolver.class) {
            if (!initialized) {
                NewPipe.init(new SecureHttpDownloader());
                initialized = true;
            }
        }
        StreamInfo info = StreamInfo.getInfo(youtubeUrl);
        AudioStream audio = info.getAudioStreams().stream()
                .filter(s -> s.isUrl() && s.getContent() != null && s.getContent().startsWith("https://"))
                .max(Comparator.comparingInt(s -> Math.max(s.getAverageBitrate(), s.getBitrate())))
                .orElse(null);
        if (audio != null) return new Result(audio.getContent(), info.getName(), "audio");
        // Some YouTube sessions expose muxed A/V only. Playback with no video
        // surface is still possible, albeit at a higher network cost.
        VideoStream muxed = info.getVideoStreams().stream()
                .filter(s -> s.isUrl() && s.getContent() != null && s.getContent().startsWith("https://"))
                .min(Comparator.comparingInt(s -> s.getWidth() * s.getHeight()))
                .orElse(null);
        if (muxed != null) return new Result(muxed.getContent(), info.getName(), "muxed");
        if (info.getHlsUrl() != null && info.getHlsUrl().startsWith("https://"))
            return new Result(info.getHlsUrl(), info.getName(), "hls");
        throw new IOException("재생 가능한 오디오 스트림을 찾지 못했습니다.");
    }

    static boolean isSupportedVideoUrl(String value) { return NativeVideoUrlRule.isVideoPage(value); }

    /** No cookies, credentials, or arbitrary HTTP endpoints are passed here. */
    private static final class SecureHttpDownloader extends Downloader {
        private static final int MAX_BODY_BYTES = 16 * 1024 * 1024;
        @Override public Response execute(Request request) throws IOException {
            URL url = new URL(request.url());
            if (!"https".equalsIgnoreCase(url.getProtocol()))
                throw new IOException("HTTPS 요청만 지원합니다.");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(16000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestMethod(request.httpMethod());
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            if (request.headers() != null) {
                for (Map.Entry<String, List<String>> entry : request.headers().entrySet()) {
                    if (entry.getKey() == null || entry.getValue() == null) continue;
                    for (String v : entry.getValue()) if (v != null) connection.addRequestProperty(entry.getKey(), v);
                }
            }
            byte[] payload = request.dataToSend();
            if (payload != null && payload.length > 0) {
                connection.setDoOutput(true);
                try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
            }
            try {
                int status = connection.getResponseCode();
                String body = "";
                if (!"HEAD".equalsIgnoreCase(request.httpMethod())) {
                    InputStream in = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    if (in != null) {
                        try (InputStream stream = in; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] bytes = new byte[8192]; int n; int total=0;
                            while ((n = stream.read(bytes)) != -1) {
                                total += n;
                                if (total > MAX_BODY_BYTES) throw new IOException("스트림 정보 응답 크기 초과");
                                buffer.write(bytes, 0, n);
                            }
                            body = buffer.toString(StandardCharsets.UTF_8.name());
                        }
                    }
                }
                String finalUrl = connection.getURL().toString();
                if (!finalUrl.startsWith("https://")) throw new IOException("HTTPS 리디렉션 실패");
                return new Response(status, connection.getResponseMessage(),
                        connection.getHeaderFields(), body, finalUrl);
            } finally { connection.disconnect(); }
        }
    }
}
