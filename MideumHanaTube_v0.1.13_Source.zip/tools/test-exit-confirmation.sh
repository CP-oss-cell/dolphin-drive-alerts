#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PYCODE'
from pathlib import Path
import re
p=Path('app/src/main/java/app/mideumhanatube/android/MainActivity.java').read_text(encoding='utf-8')
props=Path('app/build.gradle').read_text(encoding='utf-8')

def scope(start, end):
    assert start in p and end in p, (start, end)
    return p.split(start,1)[1].split(end,1)[0]
confirm=scope('private void showExitConfirmation() {','/** Called ONLY after the user confirms exit.')
back=scope('private void back() {','/**\n     * All user-facing exit paths ask first.')
physical=scope('@Override public boolean onKeyLongPress(int keyCode, KeyEvent event) {','@Override public boolean onKeyUp')
exitbody=scope('private void exitApp() {','/** Physical BACK keys')
checks={
    'v0112 monotonic version code': "versionCode 14" in props and "versionName '0.1.13'" in props,
    'exit button asks for confirmation': 'addAction(actions, "앱 종료",' in p and 'v -> showExitConfirmation());' in p,
    'in-app back button long press asks': 'backButton.setOnLongClickListener(v -> { showExitConfirmation(); return true; });' in p,
    'physical back long press asks': 'showExitConfirmation();' in physical and 'exitApp();' not in physical,
    'root double back asks': 'showExitConfirmation();' in back and 'exitApp();' not in back,
    'title': '믿음하나튜브 종료' in confirm,
    'message warns media stopping': '재생 중인 음악과 영상도 함께 종료됩니다.' in confirm,
    'cancel button': '.setNegativeButton("취소", null)' in confirm,
    'only confirm invokes hard exit': '.setPositiveButton("종료", (d, which) -> exitApp())' in confirm,
    'duplicate confirmation prevented': 'exitConfirmationDialog.isShowing()' in confirm,
    'dialog retained to avoid duplicates': 'exitConfirmationDialog = dialog;' in confirm,
    'cancel or back dismisses dialog safely': 'setOnDismissListener' in confirm,
    'confirmation does not stop background service': 'stopBackgroundService(' not in confirm,
    'confirmation does not pause videos': 'evaluateJavascript(' not in confirm and '.onPause(' not in confirm,
    'confirmation does not recreate or reload page': 'loadUrl(' not in confirm and 'reload(' not in confirm,
    'confirmation does not set exiting': 'exiting = true' not in confirm,
    'confirm stops web player': 'webView.evaluateJavascript' in exitbody and 'webView.onPause()' in exitbody,
    'confirm stops background audio service': 'stopBackgroundService();' in exitbody,
    'confirm closes task': 'finishAndRemoveTask();' in exitbody,
    'onDestroy clears dialog': 'exitConfirmationDialog.dismiss();' in p,
    'normal back still navigates': 'webView.goBack();' in back,
    'normal back still opens home': 'webView.loadUrl(HOME);' in back,
    'global Back callback retained': 'registerOnBackInvokedCallback' in p,
}
for name, valid in checks.items():
    if not valid: raise AssertionError(name)
print('Exit-confirmation and cancel-preserves-playback checks:',len(checks),'PASS')
PYCODE
