# CleanVideo Browser 1.0.0

광고 SDK와 앱 내 동영상 플레이어가 없는 **개인용 안드로이드 브라우저 + 동영상 다운로더**입니다.
원본 InShot Video Downloader의 코드를 복사하거나 패치한 제품이 아닌 **새로 작성한 독립 앱**입니다.

## 기능

- 웹 검색 및 주소 이동 (Android WebView), 방문 페이지의 영상 링크 감지
- 동영상 재생 페이지에서 **영상 찾기** → 원하는 링크 선택 → 다운로드
- 감지되지 않은 경우 영상 링크를 직접 붙여넣기
- MP4, WebM, MOV 등 직접 URL 파일은 안드로이드 DownloadManager로 백그라운드 다운로드
- 비암호화 MPEG-TS 기반 VOD HLS (`.m3u8`)는 화질(최고/절약) 선택 후 다운로드
- **다운로드** 화면에서 상태/진행률 확인, 시스템 다운로드 폴더 열기
- **즐겨찾기** 추가 및 삭제
- 앱 자체 광고·광고 SDK·분석 SDK·자체 플레이어 없음
- 일부 알려진 광고 서버 차단 (사이트 자체 광고를 모두 차단하는 기능은 아님)
- 별도 서버, 계정 또는 클라우드 데이터 전송 없음
- 저장: `내 파일 > 다운로드 > CleanVideo`

## APK 빌드: GitHub Actions (ZIP + 별도 YML)

1. 새 GitHub 저장소를 생성합니다.
2. 이 ZIP의 **내용물 전체**를 저장소 최상위에 업로드합니다.
3. 함께 받은 별도 `CleanVideoBrowser_v1.0.0_build-apk.yml` 파일을 GitHub 저장소의 `.github/workflows/build-apk.yml` 경로에 **이름을 `build-apk.yml`로 바꿔** 추가합니다.
4. GitHub **Actions > Build Android APK > Run workflow**로 빌드합니다.
5. 성공한 실행의 **Artifacts > CleanVideoBrowser-debug-apk**에서 `app-debug.apk`를 받습니다.

## Android Studio에서 빌드

Android Studio로 이 폴더를 열어 Gradle 동기화 후 `Build > Build APK(s)`를 실행합니다.
Java 17, Android SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3을 사용합니다.

## 사용법

1. 상단 주소창에 방문할 사이트 주소나 검색어를 입력합니다.
2. 웹페이지에서 동영상이 로드되면 하단 **영상 찾기**를 탭합니다.
3. 영상 주소를 고르고 다운로드하면 파일이 `Downloads/CleanVideo`에 저장됩니다.
4. 자동 감지가 되지 않는 사이트에서는 **주소 직접 입력**을 사용합니다.
5. 하단 **다운로드**에서 진행 상황을 확인합니다. **웹** 탭을 길게 누르면 시작 페이지로 갑니다. 상단 **이동** 버튼을 길게 누르면 새로고침됩니다.

## 제한 사항

- DRM(디지털 저작권 관리), 복제 방지 기술이나 접근 권한을 우회하지 않습니다.
- YouTube와 같은 일부 서비스는 이용약관·기술적 제약으로 지원되지 않습니다.
- `.m3u8` HLS는 **비암호화 VOD + MPEG-TS**만 지원합니다. 실시간 방송, 암호화 HLS, fMP4, DASH/MPD, `blob:` URL은 지원하지 않습니다.
- 스트림이 웹페이지 HTML이나 WebView 네트워크 요청에서 감지되지 않는 경우 자동 다운로드가 불가능할 수 있습니다.
- MP4 등 직접 다운로드는 Android DownloadManager가 네트워크 재시도/백그라운드 동작을 관리합니다. 앱 안에서 직접 일시정지·이어받기 버튼은 제공하지 않습니다.
- 사이트에 포함된 자체 광고, 동일 도메인 광고 및 일부 팝업은 남을 수 있습니다.
- Android 10(API 29) 이상 대상으로 설계했습니다. 브라우저의 웹영상은 웹페이지 내에서 재생될 수 있으나, **앱 자체 로컬 동영상 플레이어는 없습니다**.
- 원본 앱에 있던 비밀 폴더, SD카드 선택, 고급 다운로드 관리자 UI는 포함하지 않았습니다.

## 코드 구성

- `MainActivity.java`: 브라우저/감지/북마크/다운로드 UI
- `MediaDetector.java`: 다운로드 가능한 URL 형식 식별
- `HlsDownloadService.java`: 비암호화 HLS VOD 다운로드
- `DownloadStore.java`, `Bookmarks.java`: 기기 내부 데이터
- `AdBlock.java`: 일부 광고 도메인 차단
- 별도 제공 `build-apk.yml`: GitHub Actions 자동 APK 빌드

## 검증 범위

본 제공 환경에 Android SDK/Gradle 실행 파일이 없어 **APK 컴파일 및 실제 기기 실행 검증은 완료하지 못했습니다**.
XML, 프로젝트 구성, 코드 파싱 및 워크플로 정적 검사만 수행할 수 있습니다. GitHub Actions에서 APK 빌드가 가능하도록 설정했습니다.

© 2026. 개인 사용 목적의 독립 구현 예시. 다운로드는 저작권 및 사이트 이용약관을 준수해 사용하세요.
