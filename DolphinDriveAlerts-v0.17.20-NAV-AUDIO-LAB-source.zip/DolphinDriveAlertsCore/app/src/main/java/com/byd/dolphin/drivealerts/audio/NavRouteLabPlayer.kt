package com.byd.dolphin.drivealerts.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

/** The selected route affects ONLY this app's own 0.5s test tone, never another UID. */
object NavRouteLabPlayer {
    data class Route(val id: String, val label: String, val deviceId: Int? = null)
    data class Result(val ok: Boolean, val message: String)

    fun routes(context: Context): List<Route> {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val standard = listOf(
            Route("MEDIA", "MEDIA · 기본 미디어"),
            Route("NAV_USAGE", "NAVIGATION_GUIDANCE · Android 공식"),
            Route("LEGACY14", "Route 6 · AudioAttributes legacy stream 14 (기존 실차 성공)"),
            Route("RAW14", "Route 5 · AudioTrack raw stream 14 (기존 실차 성공)")
        )
        val outputs = runCatching { audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList() }
            .getOrDefault(emptyList()).sortedBy { it.id }
        return standard + outputs.map {
            Route("DEVICE_${it.id}", "Android 출력장치 ID=${it.id} type=${it.type} ${it.productName ?: ""} (물리 스피커 미확정)", it.id)
        }
    }

    @Suppress("DEPRECATION")
    fun play(context: Context, route: Route): Result {
        var track: AudioTrack? = null
        return try {
            val rate = 44_100
            val frames = rate / 2
            // Quiet, ramped 0.5 sec test tone. No AVAS/vehicle-control write operations.
            val pcm = ShortArray(frames) { i ->
                val envelope = minOf(1.0, i / 650.0, (frames - i) / 650.0).coerceAtLeast(0.0)
                (sin(2.0 * PI * 740.0 * i / rate) * 0.16 * envelope * Short.MAX_VALUE).toInt().toShort()
            }
            val minBytes = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            require(minBytes > 0) { "AudioTrack buffer unavailable: $minBytes" }
            val bytes = maxOf(minBytes, pcm.size * 2)
            val attrs = when (route.id) {
                "MEDIA" -> AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                "NAV_USAGE" -> AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                "LEGACY14" -> AudioAttributes.Builder().setLegacyStreamType(14).build()
                "RAW14" -> AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build() // ignored for raw constructor
                else -> AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            }
            track = if (route.id == "RAW14") {
                AudioTrack(14, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, bytes, AudioTrack.MODE_STATIC)
            } else {
                AudioTrack.Builder().setAudioAttributes(attrs)
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(bytes).build()
            }
            val t = track ?: throw IllegalStateException("AudioTrack not constructed")
            require(t.state == AudioTrack.STATE_INITIALIZED) { "AudioTrack not initialized" }
            val device = if (route.deviceId != null) {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == route.deviceId }
                    ?: throw IllegalStateException("출력장치가 사라졌습니다: ${route.deviceId}")
            } else null
            val preferredAccepted = device?.let { t.setPreferredDevice(it) }
            if (device != null && preferredAccepted != true) {
                return Result(false, "Android preferredDevice 요청 거부. 다른 출력으로 넘어가지 않음")
            }
            val written = t.write(pcm, 0, pcm.size)
            require(written == pcm.size) { "AudioTrack write incomplete $written/${pcm.size}" }
            t.setVolume(0.65f)
            t.play()
            Thread.sleep(650)
            val routed = t.routedDevice
            Result(true, "앱 자체 시험음 재생 요청: ${route.label}; session=${t.audioSessionId}; Android routedDevice=${routed?.id ?: "UNKNOWN"}/${routed?.type ?: "?"}; physical_driver_only=UNVERIFIED; ${if(device!=null) "preferredAccepted=$preferredAccepted" else ""}")
        } catch (e: Exception) {
            Result(false, "재생 실패: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }
}
