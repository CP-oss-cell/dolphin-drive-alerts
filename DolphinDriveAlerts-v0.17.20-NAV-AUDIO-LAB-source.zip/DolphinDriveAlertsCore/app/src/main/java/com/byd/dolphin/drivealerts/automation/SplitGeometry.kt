package com.byd.dolphin.drivealerts.automation

import kotlin.math.roundToInt

/** Uses BOTH independent split stack bounds; never selects the nearest arbitrary rectangle. */
internal object SplitGeometry {
    data class Rect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        fun args(): String = "$left $top $right $bottom"
    }
    data class PairBounds(val primary: Rect, val secondary: Rect)
    data class Resize(val command: String, val axis: String)
    private val bounds = Regex("""bounds=\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]""")

    fun parse(raw: String): PairBounds? {
        var pending: Rect? = null
        var primary: Rect? = null
        var secondary: Rect? = null
        raw.lineSequence().forEach { original ->
            val line = original.trim()
            if (line.startsWith("Stack id=",true)) {
                val match = bounds.find(line)
                pending = match?.groupValues?.drop(1)?.map { it.toInt() }?.let {
                    Rect(it[0],it[1],it[2],it[3])
                }
            }
            val rect = pending
            if (rect != null && ("mActivityType=standard" in line || "activityType=standard" in line)) {
                if ("split-screen-primary" in line || Regex("""(?:mWindowingMode|windowingMode)=3\b""").containsMatchIn(line)) primary=rect
                if ("split-screen-secondary" in line || Regex("""(?:mWindowingMode|windowingMode)=4\b""").containsMatchIn(line)) secondary=rect
            }
        }
        return if (primary != null && secondary != null) PairBounds(primary!!, secondary!!) else null
    }

    fun percent(bounds: PairBounds): Int? {
        val p=bounds.primary; val s=bounds.secondary
        return when {
            p.top==s.top && p.bottom==s.bottom && p.right<=s.left ->
                ((p.right-p.left)*100f/(s.right-p.left-(s.left-p.right)).coerceAtLeast(1)).roundToInt()
            p.left==s.left && p.right==s.right && p.bottom<=s.top ->
                ((p.bottom-p.top)*100f/(s.bottom-p.top-(s.top-p.bottom)).coerceAtLeast(1)).roundToInt()
            else -> null
        }
    }

    fun resize(bounds: PairBounds, requested: Int): Resize? {
        val p=bounds.primary; val s=bounds.secondary
        val ratio=requested.coerceIn(20,80)
        val target: Rect
        val axis: String
        if (p.top==s.top && p.bottom==s.bottom && p.right<=s.left) {
            axis="X"; val divider=s.left-p.right
            val usable=(s.right-p.left-divider).coerceAtLeast(1)
            target=Rect(p.left,p.top,p.left+(usable*ratio/100f).roundToInt(),p.bottom)
        } else if (p.left==s.left && p.right==s.right && p.bottom<=s.top) {
            axis="Y"; val divider=s.top-p.bottom
            val usable=(s.bottom-p.top-divider).coerceAtLeast(1)
            target=Rect(p.left,p.top,p.right,p.top+(usable*ratio/100f).roundToInt())
        } else return null
        // Verified Assistant v30 + AutoSplit use the TWO-rectangle 8-argument legacy signature.
        return Resize("am stack resize-docked-stack ${target.args()} ${target.args()}",axis)
    }
}
