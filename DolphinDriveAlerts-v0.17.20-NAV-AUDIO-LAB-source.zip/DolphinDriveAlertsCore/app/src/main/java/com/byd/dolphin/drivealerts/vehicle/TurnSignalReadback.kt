package com.byd.dolphin.drivealerts.vehicle

import android.content.Context
import com.byd.dolphin.drivealerts.model.Side

/** Read-only indicator probe. No sound-status or speculative CAN mapping is promoted to an active signal. */
internal class TurnSignalReadback(context: Context) {
    private val app = BydPermissionContext.wrap(context.applicationContext)
    data class Result(val side: Side, val detail: String, val anyBlinkerActive: Boolean = false)

    // Earlier global2602 capture: both getter results null. Do not turn null into an ON state.
    internal fun classify(left: Int?, right: Int?): Boolean =
        (left == 1 && right == 0) || (right == 1 && left == 0)

    private data class Sample(val method: String, val value: Int?)
    // Launcher V1 1.2.20 DEX actually reads these two named getters in its
    // VehicleReadOnlyMonitor; its exact provider is not real-car proven.
    // Extend only read-only reflection. Never synthesize an ON from null.
    private val classes = listOf(
        "android.hardware.bydauto.light.BYDAutoLightDevice",
        "android.hardware.bydauto.BYDAutoLightDevice",
        "android.hardware.bydauto.gearbox.BYDAutoGearboxDevice",
        "android.hardware.bydauto.instrument.BYDAutoInstrumentDevice"
    )
    private val leftMethods = listOf("getLeftTurnLightState", "getLeftTurnSignalState",
        "getLeftTurnLampState", "getLeftTurnState", "getLeftTurnSignalLightState")
    private val rightMethods = listOf("getRightTurnLightState", "getRightTurnSignalState",
        "getRightTurnLampState", "getRightTurnState", "getRightTurnSignalLightState")

    fun read(): Result {
        val notes = mutableListOf<String>()
        var left: Sample? = null
        var right: Sample? = null
        for (className in classes) {
            val cls = try { Class.forName(className) } catch (t: Throwable) {
                notes += "class:${className.substringAfterLast('.')}=${t.javaClass.simpleName}"
                continue
            }
            val device = try {
                cls.getMethod("getInstance", Context::class.java).invoke(null, app)
            } catch (t: Throwable) {
                notes += "instance:${cls.simpleName}=${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                continue
            }
            if (device == null) { notes += "instance:${cls.simpleName}=NULL"; continue }
            fun readSide(names: List<String>, tag: String): Sample? {
                for (name in names) {
                    val method = cls.methods.firstOrNull { it.name == name && it.parameterCount == 0 } ?: continue
                    val raw = try { method.invoke(device) } catch (t: Throwable) {
                        notes += "$tag.$name:${t.cause?.javaClass?.simpleName ?: t.javaClass.simpleName}"
                        continue
                    }
                    if (raw is Number) return Sample("${cls.simpleName}.$name", raw.toInt())
                    notes += "$tag.$name:nonNumeric=${raw?.javaClass?.simpleName ?: "null"}"
                }
                notes += "$tag:noCallableGetter"
                return null
            }
            val candidateLeft = readSide(leftMethods, "LEFT")
            val candidateRight = readSide(rightMethods, "RIGHT")
            // The two values must come from the SAME device and BOTH be
            // binary status values; never join unrelated provider snapshots.
            if (candidateLeft != null && candidateRight != null &&
                candidateLeft.value in 0..1 && candidateRight.value in 0..1) {
                left = candidateLeft
                right = candidateRight
                break
            }
            notes += "provider:${cls.simpleName}=UNVERIFIED_PAIR"
        }
        val l = left?.value
        val r = right?.value
        val side = when {
            l == 1 && r == 0 -> Side.LEFT
            r == 1 && l == 0 -> Side.RIGHT
            else -> Side.UNKNOWN
        }
        val detail = "left=$l right=$r;leftMethod=${left?.method ?: "MISSING"};" +
            "rightMethod=${right?.method ?: "MISSING"};reason=${notes.take(10).joinToString("|")};" +
            "SDK_ON_1_CANDIDATE;hazardSide=UNKNOWN;turnSoundIsOnlyCorrelationCandidate=true"
        return Result(side, detail, anyBlinkerActive = classify(l,r))
    }
}
