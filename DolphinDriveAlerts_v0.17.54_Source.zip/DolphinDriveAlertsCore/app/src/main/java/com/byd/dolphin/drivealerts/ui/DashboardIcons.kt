package com.byd.dolphin.drivealerts.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Pure Android Canvas vector icon engine for BYD Dolphin 10.1" cockpit UI.
 * Zero external dependencies; crisp anti-aliased rendering at any DPI and theme.
 */
object DashboardIcons {
    enum class IconKind {
        CAR_ALERT,
        POWER_LAUNCH,
        SPLIT_DISPLAY,
        AUDIO_NAV,
        SHIELD_ADB,
        DIAG_LOG,
        SPEAKER,
        GAUGE,
        RADAR_BSD,
        STEERING,
        CHECKLIST,
        ROTATE,
        DPI_GRID,
        EQUALIZER,
        NAV_ARROW,
        USB_TERMINAL,
        KEY_PERM,
        PLAY,
        STOP,
        SHARE,
        RESCUE,
        SEARCH_CHECK,
        BACK,
        CHEVRON_RIGHT,
        SUN,
        MOON,
        RECORD_DOT,
        CAR_AUDIO_WAVE
    }

    private fun dp(context: Context, v: Float): Float = context.resources.displayMetrics.density * v

    fun drawable(
        context: Context,
        kind: IconKind,
        color: Int,
        sizeDp: Int = 24,
        strokeDp: Float = 2.0f
    ): Drawable = VectorIconDrawable(
        kind = kind,
        color = color,
        sizePx = dp(context, sizeDp.toFloat()).toInt().coerceAtLeast(16),
        strokePx = dp(context, strokeDp).coerceAtLeast(1.5f)
    )

    fun badge(
        context: Context,
        kind: IconKind,
        iconColor: Int,
        bgColor: Int,
        borderColor: Int = 0,
        boxDp: Int = 44,
        iconDp: Int = 22,
        radiusDp: Int = 12
    ): View {
        val boxPx = dp(context, boxDp.toFloat()).toInt()
        val iconPx = dp(context, iconDp.toFloat()).toInt()
        return FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(boxPx, boxPx)
            background = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = dp(context, radiusDp.toFloat())
                if (borderColor != 0) setStroke(dp(context, 1f).toInt().coerceAtLeast(1), borderColor)
            }
            addView(ImageView(context).apply {
                setImageDrawable(drawable(context, kind, iconColor, iconDp, 2.0f))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(iconPx, iconPx, Gravity.CENTER))
        }
    }

    fun inferForTitle(title: String): IconKind = when {
        title.contains("알림") -> CHECKLIST
        title.contains("자동 실행") || title.contains("시동") -> POWER_LAUNCH
        title.contains("분할") -> SPLIT_DISPLAY
        title.contains("DPI") || title.contains("화면") -> DPI_GRID
        title.contains("이퀄라이저") || title.contains("음향") -> EQUALIZER
        title.contains("내비") || title.contains("오디오") -> NAV_ARROW
        title.contains("ADB") -> USB_TERMINAL
        title.contains("권한") -> KEY_PERM
        title.contains("주행모드") -> GAUGE
        title.contains("진단") || title.contains("로그") -> DIAG_LOG
        else -> CAR_ALERT
    }

    private class VectorIconDrawable(
        private val kind: IconKind,
        private val color: Int,
        private val sizePx: Int,
        private val strokePx: Float
    ) : Drawable() {
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = strokePx
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            this.color = this@VectorIconDrawable.color
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            this.color = this@VectorIconDrawable.color
        }

        override fun getIntrinsicWidth(): Int = sizePx
        override fun getIntrinsicHeight(): Int = sizePx

        override fun draw(canvas: Canvas) {
            val b = bounds
            val w = if (b.width() > 0) b.width().toFloat() else sizePx.toFloat()
            val h = if (b.height() > 0) b.height().toFloat() else sizePx.toFloat()
            val s = minOf(w, h)
            val ox = b.left + (w - s) / 2f
            val oy = b.top + (h - s) / 2f

            fun x(u: Float) = ox + u * s / 24f
            fun y(v: Float) = oy + v * s / 24f
            fun r(u: Float) = u * s / 24f

            when (kind) {
                IconKind.CAR_ALERT -> {
                    // Car silhouette
                    val body = Path().apply {
                        moveTo(x(4f), y(16f))
                        lineTo(x(5.6f), y(11.4f))
                        lineTo(x(8.4f), y(9.5f))
                        lineTo(x(15.6f), y(9.5f))
                        lineTo(x(18.4f), y(11.4f))
                        lineTo(x(20f), y(16f))
                        lineTo(x(20f), y(19f))
                        lineTo(x(4f), y(19f))
                        close()
                    }
                    canvas.drawPath(body, strokePaint)
                    canvas.drawCircle(x(7.5f), y(16.2f), r(1.1f), fillPaint)
                    canvas.drawCircle(x(16.5f), y(16.2f), r(1.1f), fillPaint)
                    // Top alert waves
                    canvas.drawArc(RectF(x(8.5f), y(4.8f), x(15.5f), y(10.8f)), 215f, 110f, false, strokePaint)
                    canvas.drawArc(RectF(x(6f), y(2.2f), x(18f), y(12.2f)), 220f, 100f, false, strokePaint)
                }
                IconKind.POWER_LAUNCH -> {
                    canvas.drawArc(RectF(x(4.5f), y(5f), x(19.5f), y(20f)), -55f, 290f, false, strokePaint)
                    canvas.drawLine(x(12f), y(3f), x(12f), y(11.5f), strokePaint)
                }
                IconKind.SPLIT_DISPLAY -> {
                    canvas.drawRoundRect(RectF(x(2.8f), y(4.5f), x(21.2f), y(19.5f)), r(2.6f), r(2.6f), strokePaint)
                    canvas.drawLine(x(12f), y(4.5f), x(12f), y(19.5f), strokePaint)
                    canvas.drawLine(x(5.5f), y(9f), x(9.2f), y(9f), strokePaint)
                    canvas.drawLine(x(5.5f), y(13f), x(9.2f), y(13f), strokePaint)
                    canvas.drawRoundRect(RectF(x(14.6f), y(8f), x(18.6f), y(16f)), r(1.1f), r(1.1f), strokePaint)
                }
                IconKind.AUDIO_NAV -> {
                    val arrow = Path().apply {
                        moveTo(x(3.5f), y(11.5f))
                        lineTo(x(13.5f), y(5.5f))
                        lineTo(x(10.8f), y(17.5f))
                        lineTo(x(8.6f), y(13.2f))
                        close()
                    }
                    canvas.drawPath(arrow, strokePaint)
                    canvas.drawLine(x(16.5f), y(9f), x(16.5f), y(17f), strokePaint)
                    canvas.drawLine(x(19.8f), y(6f), x(19.8f), y(19f), strokePaint)
                }
                IconKind.SHIELD_ADB -> {
                    val shield = Path().apply {
                        moveTo(x(12f), y(3f))
                        lineTo(x(19.2f), y(6f))
                        lineTo(x(19.2f), y(12.2f))
                        quadTo(x(19.2f), y(18f), x(12f), y(21f))
                        quadTo(x(4.8f), y(18f), x(4.8f), y(12.2f))
                        lineTo(x(4.8f), y(6f))
                        close()
                    }
                    canvas.drawPath(shield, strokePaint)
                    val check = Path().apply {
                        moveTo(x(8.6f), y(12.2f))
                        lineTo(x(11f), y(14.6f))
                        lineTo(x(15.6f), y(9.8f))
                    }
                    canvas.drawPath(check, strokePaint)
                }
                IconKind.DIAG_LOG -> {
                    canvas.drawRoundRect(RectF(x(3.5f), y(3.5f), x(20.5f), y(20.5f)), r(2.8f), r(2.8f), strokePaint)
                    val pulse = Path().apply {
                        moveTo(x(6f), y(13f))
                        lineTo(x(8.8f), y(13f))
                        lineTo(x(10.6f), y(8.2f))
                        lineTo(x(13.4f), y(16.4f))
                        lineTo(x(15.2f), y(12f))
                        lineTo(x(18f), y(12f))
                    }
                    canvas.drawPath(pulse, strokePaint)
                }
                IconKind.SPEAKER -> {
                    val horn = Path().apply {
                        moveTo(x(4f), y(9.5f))
                        lineTo(x(7.8f), y(9.5f))
                        lineTo(x(12.6f), y(5.5f))
                        lineTo(x(12.6f), y(18.5f))
                        lineTo(x(7.8f), y(14.5f))
                        lineTo(x(4f), y(14.5f))
                        close()
                    }
                    canvas.drawPath(horn, strokePaint)
                    canvas.drawArc(RectF(x(13.5f), y(8.2f), x(18.5f), y(15.8f)), -45f, 90f, false, strokePaint)
                    canvas.drawArc(RectF(x(14.5f), y(5.5f), x(21f), y(18.5f)), -45f, 90f, false, strokePaint)
                }
                IconKind.GAUGE -> {
                    canvas.drawArc(RectF(x(3.5f), y(5.5f), x(20.5f), y(22.5f)), 180f, 180f, false, strokePaint)
                    canvas.drawLine(x(12f), y(14.5f), x(16.8f), y(9.6f), strokePaint)
                    canvas.drawCircle(x(12f), y(14.5f), r(1.5f), fillPaint)
                    canvas.drawLine(x(5.2f), y(18.2f), x(18.8f), y(18.2f), strokePaint)
                }
                IconKind.RADAR_BSD -> {
                    canvas.drawRoundRect(RectF(x(4f), y(7.5f), x(11.5f), y(18.5f)), r(2f), r(2f), strokePaint)
                    canvas.drawArc(RectF(x(12.5f), y(8.5f), x(17.5f), y(15.5f)), -50f, 100f, false, strokePaint)
                    canvas.drawArc(RectF(x(13.8f), y(5.8f), x(20.6f), y(18.2f)), -50f, 100f, false, strokePaint)
                }
                IconKind.STEERING -> {
                    canvas.drawCircle(x(12f), y(12f), r(8.4f), strokePaint)
                    canvas.drawCircle(x(12f), y(12f), r(2.2f), strokePaint)
                    canvas.drawLine(x(4.2f), y(10.8f), x(9.8f), y(11.5f), strokePaint)
                    canvas.drawLine(x(14.2f), y(11.5f), x(19.8f), y(10.8f), strokePaint)
                    canvas.drawLine(x(12f), y(14.2f), x(12f), y(20.2f), strokePaint)
                }
                IconKind.CHECKLIST -> {
                    listOf(7.2f, 12f, 16.8f).forEach { cy ->
                        canvas.drawCircle(x(6f), y(cy), r(1.1f), fillPaint)
                        canvas.drawLine(x(9.5f), y(cy), x(19.2f), y(cy), strokePaint)
                    }
                }
                IconKind.ROTATE -> {
                    canvas.drawArc(RectF(x(4.5f), y(4.5f), x(19.5f), y(19.5f)), 35f, 275f, false, strokePaint)
                    val tip = Path().apply {
                        moveTo(x(16.4f), y(4.5f))
                        lineTo(x(19.6f), y(6.8f))
                        lineTo(x(15.8f), y(8.8f))
                    }
                    canvas.drawPath(tip, strokePaint)
                }
                IconKind.DPI_GRID -> {
                    canvas.drawRoundRect(RectF(x(4f), y(4f), x(10.5f), y(10.5f)), r(1.5f), r(1.5f), strokePaint)
                    canvas.drawRoundRect(RectF(x(13.5f), y(4f), x(20f), y(10.5f)), r(1.5f), r(1.5f), strokePaint)
                    canvas.drawRoundRect(RectF(x(4f), y(13.5f), x(10.5f), y(20f)), r(1.5f), r(1.5f), strokePaint)
                    canvas.drawRoundRect(RectF(x(13.5f), y(13.5f), x(20f), y(20f)), r(1.5f), r(1.5f), strokePaint)
                }
                IconKind.EQUALIZER -> {
                    val cols = listOf(Pair(6.5f, 14f), Pair(12f, 9f), Pair(17.5f, 15.5f))
                    cols.forEach { (cx, knobY) ->
                        canvas.drawLine(x(cx), y(4.5f), x(cx), y(19.5f), strokePaint)
                        canvas.drawCircle(x(cx), y(knobY), r(1.9f), fillPaint)
                    }
                }
                IconKind.NAV_ARROW -> {
                    val nav = Path().apply {
                        moveTo(x(12f), y(3.2f))
                        lineTo(x(19.5f), y(19.8f))
                        lineTo(x(12f), y(16.2f))
                        lineTo(x(4.5f), y(19.8f))
                        close()
                    }
                    canvas.drawPath(nav, strokePaint)
                }
                IconKind.USB_TERMINAL -> {
                    canvas.drawRoundRect(RectF(x(3.2f), y(4.5f), x(20.8f), y(19.5f)), r(2.5f), r(2.5f), strokePaint)
                    val prompt = Path().apply {
                        moveTo(x(7f), y(9.5f))
                        lineTo(x(10.2f), y(12f))
                        lineTo(x(7f), y(14.5f))
                    }
                    canvas.drawPath(prompt, strokePaint)
                    canvas.drawLine(x(12.2f), y(14.5f), x(17f), y(14.5f), strokePaint)
                }
                IconKind.KEY_PERM -> {
                    canvas.drawCircle(x(8.5f), y(12f), r(3.8f), strokePaint)
                    canvas.drawLine(x(12.3f), y(12f), x(20.5f), y(12f), strokePaint)
                    canvas.drawLine(x(17.2f), y(12f), x(17.2f), y(15.2f), strokePaint)
                    canvas.drawLine(x(20f), y(12f), x(20f), y(14.5f), strokePaint)
                }
                IconKind.PLAY -> {
                    val tri = Path().apply {
                        moveTo(x(7.5f), y(5.5f))
                        lineTo(x(19f), y(12f))
                        lineTo(x(7.5f), y(18.5f))
                        close()
                    }
                    canvas.drawPath(tri, fillPaint)
                }
                IconKind.STOP -> {
                    canvas.drawRoundRect(RectF(x(6.2f), y(6.2f), x(17.8f), y(17.8f)), r(2f), r(2f), fillPaint)
                }
                IconKind.SHARE -> {
                    canvas.drawCircle(x(17.5f), y(6f), r(2.2f), strokePaint)
                    canvas.drawCircle(x(6.5f), y(12f), r(2.2f), strokePaint)
                    canvas.drawCircle(x(17.5f), y(18f), r(2.2f), strokePaint)
                    canvas.drawLine(x(8.5f), y(10.9f), x(15.4f), y(7.1f), strokePaint)
                    canvas.drawLine(x(8.5f), y(13.1f), x(15.4f), y(16.9f), strokePaint)
                }
                IconKind.RESCUE -> {
                    canvas.drawRoundRect(RectF(x(4f), y(5f), x(20f), y(19f)), r(2.4f), r(2.4f), strokePaint)
                    canvas.drawLine(x(12f), y(8.5f), x(12f), y(15.5f), strokePaint)
                    canvas.drawLine(x(8.5f), y(12f), x(15.5f), y(12f), strokePaint)
                }
                IconKind.SEARCH_CHECK -> {
                    canvas.drawCircle(x(10.5f), y(10.5f), r(6.2f), strokePaint)
                    canvas.drawLine(x(15.2f), y(15.2f), x(20f), y(20f), strokePaint)
                    val ck = Path().apply {
                        moveTo(x(8.2f), y(10.5f))
                        lineTo(x(10f), y(12.3f))
                        lineTo(x(13.2f), y(8.8f))
                    }
                    canvas.drawPath(ck, strokePaint)
                }
                IconKind.BACK -> {
                    val p = Path().apply {
                        moveTo(x(15f), y(5.5f))
                        lineTo(x(8.5f), y(12f))
                        lineTo(x(15f), y(18.5f))
                    }
                    canvas.drawPath(p, strokePaint)
                }
                IconKind.CHEVRON_RIGHT -> {
                    val p = Path().apply {
                        moveTo(x(9.5f), y(6f))
                        lineTo(x(15.5f), y(12f))
                        lineTo(x(9.5f), y(18f))
                    }
                    canvas.drawPath(p, strokePaint)
                }
                IconKind.SUN -> {
                    canvas.drawCircle(x(12f), y(12f), r(4f), strokePaint)
                    listOf(
                        Pair(Pair(12f, 3.2f), Pair(12f, 5.4f)),
                        Pair(Pair(12f, 18.6f), Pair(12f, 20.8f)),
                        Pair(Pair(3.2f, 12f), Pair(5.4f, 12f)),
                        Pair(Pair(18.6f, 12f), Pair(20.8f, 12f)),
                        Pair(Pair(5.8f, 5.8f), Pair(7.4f, 7.4f)),
                        Pair(Pair(16.6f, 16.6f), Pair(18.2f, 18.2f)),
                        Pair(Pair(16.6f, 7.4f), Pair(18.2f, 5.8f)),
                        Pair(Pair(5.8f, 18.2f), Pair(7.4f, 16.6f))
                    ).forEach { (a, c) ->
                        canvas.drawLine(x(a.first), y(a.second), x(c.first), y(c.second), strokePaint)
                    }
                }
                IconKind.MOON -> {
                    val moon = Path().apply {
                        moveTo(x(18.5f), y(14.5f))
                        cubicTo(x(16f), y(19.5f), x(9f), y(20.5f), x(6f), y(16.5f))
                        cubicTo(x(3.5f), y(13f), x(5f), y(7f), x(10.5f), y(4.8f))
                        cubicTo(x(9.2f), y(9.5f), x(12.8f), y(14.8f), x(18.5f), y(14.5f))
                        close()
                    }
                    canvas.drawPath(moon, strokePaint)
                }
                IconKind.RECORD_DOT -> {
                    canvas.drawCircle(x(12f), y(12f), r(6.5f), fillPaint)
                }
                IconKind.CAR_AUDIO_WAVE -> {
                    listOf(
                        Triple(4.5f, 10f, 14f),
                        Triple(8.2f, 6.5f, 17.5f),
                        Triple(12f, 4.2f, 19.8f),
                        Triple(15.8f, 7.2f, 16.8f),
                        Triple(19.5f, 10f, 14f)
                    ).forEach { (cx, y1, y2) ->
                        canvas.drawLine(x(cx), y(y1), x(cx), y(y2), strokePaint)
                    }
                }
            }
        }

        override fun setAlpha(alpha: Int) {
            strokePaint.alpha = alpha
            fillPaint.alpha = alpha
        }

        override fun setColorFilter(colorFilter: ColorFilter?) {
            strokePaint.colorFilter = colorFilter
            fillPaint.colorFilter = colorFilter
        }

        @Deprecated("Deprecated in Android")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}
