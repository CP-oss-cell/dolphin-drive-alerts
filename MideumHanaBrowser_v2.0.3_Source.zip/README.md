# 믿음하나 브라우저 v2.0.3 — 새 출발 버전

## 이번 버전에서 변경된 내용

- **새 앱 설치**: 기존 v1.1.8의 `com.personal.cleanvideobrowser`와 구분된 신규 앱 ID `com.mideumhana.browser`.
  기존 앱을 삭제하지 않아도 별개 아이콘으로 설치됩니다. 이전 버전의 즐겨찾기·탭·설정·기록은 자동 이관되지 않습니다.
- **새 기본 다운로드 폴더**: `내 파일 → 내부 저장공간 → Download → 믿음하나`
  Android 내부 경로: `/storage/emulated/0/Download/믿음하나/`.
  MP4 직접 다운로드(DownloadManager)와 HLS/직접 서비스(MediaStore)는 모두 새 폴더에 저장합니다.
  설정에서 폴더를 따로 선택했다면 사용자가 고른 폴더가 우선합니다.
- **이후 업데이트**: v2.0.3을 새 기준으로 `applicationId` 고정, 후속 버전부터 `versionCode` 증가 및 **동일한 APK 서명키 재사용**.
- 기존 대시보드, 폴드 펼친 화면 대응, 웹페이지 탭, 광고 후보 필터, 화질/저장 위치 선택은 유지합니다.
- 이 앱은 다운로드한 영상의 재생 기능을 내장하지 않습니다. 파일 열기는 휴대전화의 다른 앱으로 연결됩니다.

## 통합 ZIP 사용

외부 `MideumHanaBrowser_v2.0.3_Complete_Build_Package.zip` 압축을 한 번 풀면 정확히 두 파일이 나옵니다.

1. `MideumHanaBrowser_v2.0.3_Source.zip` → GitHub 저장소 **최상위에 압축 상태 그대로 업로드**.
2. `MideumHanaBrowser_v2.0.3_Source.yml` → `.github/workflows/MideumHanaBrowser_v2.0.3_Source.yml`에 업로드.

기존 믿음하나/클린비디오 앱 워크플로는 해당 앱 이전 버전만 삭제하고, 다른 앱의 YML은 지우지 마세요.

## APK 빌드 방식: 최초 테스트 자동화 / 정식 업데이트는 안전한 고정 서명키

- GitHub Secrets를 **설정하지 않아도 Debug APK를 자동 생성**합니다. Debug APK는 임시 테스트 전용이며 새 빌드에서 업데이트 설치가 안 될 수 있습니다.
- 삭제 없이 업데이트할 **정식 Release APK**는 먼저 개인 전용 서명키를 만들고 `MHB_KEYSTORE_BASE64`, `MHB_KEYSTORE_PASSWORD` 두 Secrets를 등록해야 합니다.
- 이 두 값이 모두 등록돼 있으면 Release APK를 만들고, 하나만 등록되면 안전하게 오류로 중단합니다.
- 실제 설치를 시작할 기준 APK는 **Release APK를 권장**합니다. Debug → Release 전환 시 앱을 삭제해야 할 수 있습니다.
- 세부 안내: `SIGNING_SETUP_KO.md` 참조. 키스토어와 비밀번호를 소스 ZIP이나 공개 GitHub 저장소에 올리지 마세요.

## 기술/제한
Android 10 이상 (minSdk29), Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, SDK 35.
MP4 등 직접 URL과 비암호화 MPEG-TS HLS VOD에 한정. 사이트 구조·인증·DRM 및 분리 오디오 등은 지원하지 않을 수 있으며 광고/본편 판별은 추정입니다. 본인에게 권리가 있는 콘텐츠만 저장하세요.

## 검증 상태
소스 수준 문법, JS 구문, XML, 오프라인 회귀 테스트 및 ZIP 내부 무결성을 점검합니다. Android SDK가 없는 현재 환경에서는 **실제 APK 빌드와 폴드8 실기기 확인은 미검증**입니다.

## v2.0.3: GitHub 소스 ZIP 누락 자동 복구

- 이전 실패 로그에서 `MideumHanaBrowser_v2.0.1_Source.zip`이 GitHub 저장소에 없어 APK 빌드 전에 중단된 문제를 확인했습니다.
- v2.0.3 워크플로의 YML에는 **동일 버전 소스 ZIP을 Base64로 내장**하였습니다. GitHub 저장소 루트에 v2.0.3 소스 ZIP을 업로드하면 그것을 사용하고, 없으면 워크플로가 내장 소스 ZIP을 복원하여 빌드합니다.
- 내장 소스는 공개된 앱 소스만 포함합니다. APK 개인 서명키 및 비밀번호는 포함하지 않습니다.
- 이 워크플로는 다른 앱(YML)을 건드리지 않고 믿음하나 브라우저만 별도 임시 폴더에 빌드합니다.
- ZIP 파일의 checksum을 기록합니다. 실제 Android APK 컴파일 성공은 GitHub Actions 수행 결과를 확인해야 합니다.

가장 쉬운 방법: 통합 ZIP 압축을 푼 다음 **`MideumHanaBrowser_v2.0.3_Source.yml`만** 기존 저장소의 `.github/workflows/`에 올려도 해당 버전의 소스를 복원하여 빌드할 수 있습니다. 소스 ZIP을 저장소 최상위에 함께 올리는 방식도 지원합니다.

## v2.0.3 수정

- 2026-11-04 사용자 제공 `4.zip`(v2.0.1 워크플로 실행 로그)에서 확인된 GitHub `:app:processDebugResources` 오류 수정.
- 탭 스트립 `HorizontalScrollView`에서 지원하지 않는 `android:horizontalScrollBarEnabled` 제거 후 `android:scrollbars="none"`로 교체.
- 빌드 전 방지 검사를 추가했고, YML 내 내장 소스 ZIP도 v2.0.3으로 갱신함.
- Android SDK가 없어 실제 APK 컴파일 결과는 확인하지 못함.
