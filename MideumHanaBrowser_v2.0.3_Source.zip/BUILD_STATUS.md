# 믿음하나 브라우저 v2.0.3 빌드 오류 수정 결과

- 분석 로그: 사용자가 전달한 `4.zip` (GitHub Actions, 2026-11-04 15:31 UTC).
- GitHub 작업: `:app:processDebugResources` 에서 `Android resource linking failed`.
- AAPT 위치: `app/src/main/res/layout/activity_main.xml:56`.
- 추가 확인: `4.zip`이 실행한 것은 구버전 v2.0.1 워크플로였으며, 같은 잘못된 속성이 v2.0.2 소스에도 남아 있었음.
- 실패 원인: `android:horizontalScrollBarEnabled`는 Android 레이아웃 XML의 유효한 속성이 아님.
- 실제 수정: `HorizontalScrollView` 의 `android:scrollbars="none"` 사용.
- 방지책: `tests/android_resources_regression.py` 추가 및 `tests/verify_project.py` 오류 속성 재발 방지 검사.
- 버전 변경: `com.mideumhana.browser` 유지, `versionCode=4`, `versionName=2.0.3`.
- 소스 ZIP 누락을 복구하는 GitHub Actions 내장 ZIP fallback 기능 유지. 내장 소스 및 SHA-256은 v2.0.3과 동일하게 재생성.
- Debug/Release 자동 분기 및 signing 설정 동일. 기본 다운로드 폴더는 `Download/믿음하나`.
- 로컬 검증: XML 파싱, Java 소스 구문 파싱, 모든 Python 회귀 검사, JavaScript 구문 검사, 새 XML 회귀 검사, ZIP CRC/sha256, YML 내장 소스 복원 검사.
- **실제 AAPT/Gradle Android APK 컴파일은 로컬 Android SDK가 없어 미검증.** 같은 오류의 재발 방지는 정적 검증에 근거함.
