(function(){
  // Read only playlist entries actually exposed by the current YouTube page.
  // No network requests, no cookies, no authenticated account data.
  try {
    var here = new URL(location.href);
    var listId = here.searchParams.get('list') || '';
    if (!/^[A-Za-z0-9_-]{8,90}$/.test(listId)) return JSON.stringify({id:'',tracks:[]});
    var rows = document.querySelectorAll(
      'ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer, ' +
      'ytm-playlist-video-renderer, ytm-playlist-panel-video-renderer, ' +
      'ytm-playlist-item-renderer, yt-playlist-video-renderer');
    var tracks = [], seen = {};
    function add(anchor, row) {
      if (!anchor || tracks.length >= 80) return;
      var u = new URL(anchor.getAttribute('href') || anchor.href, location.origin);
      var id = u.searchParams.get('v');
      if (!id || !/^[A-Za-z0-9_-]{11}$/.test(id) || seen[id]) return;
      var otherList = u.searchParams.get('list');
      if (otherList && otherList !== listId) return;
      var t = row && row.querySelector('#video-title, .playlist-video-title, h3, .media-item-headline');
      var title = String((t && (t.getAttribute('title') || t.textContent)) ||
        anchor.getAttribute('title') || anchor.getAttribute('aria-label') || anchor.textContent || '영상');
      title = title.trim().slice(0,120) || '영상';
      seen[id] = true;
      tracks.push({url:'https://www.youtube.com/watch?v=' + id, title:title});
    }
    if (rows.length) {
      for (var i = 0; i < rows.length && tracks.length < 80; i++) {
        var anchors = rows[i].querySelectorAll('a[href*="watch"]');
        for (var a = 0; a < anchors.length; a++) {
          var before = tracks.length;
          try { add(anchors[a], rows[i]); } catch (_) {}
          if (tracks.length !== before) break;
        }
      }
    }
    // Some mobile layouts don't expose playlist-specific renderer elements.
    if (!tracks.length) {
      var links = document.querySelectorAll('a[href*="watch?v="][href*="list="]');
      for (var j = 0; j < links.length && tracks.length < 80; j++) {
        try { add(links[j], links[j]); } catch (_) {}
      }
    }
    return JSON.stringify({id:listId, tracks:tracks, from:rows.length?'PLAYLIST_PANEL':'PLAYLIST_LINKS'});
  } catch (_) {
    return JSON.stringify({id:'',tracks:[]});
  }
})()
