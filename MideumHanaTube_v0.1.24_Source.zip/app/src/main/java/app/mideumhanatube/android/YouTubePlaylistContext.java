package app.mideumhanatube.android;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** A public YouTube playlist identity is different from a list of recommended videos. */
public final class YouTubePlaylistContext {
    private YouTubePlaylistContext() { }

    public static String playlistId(String pageUrl) {
        if (pageUrl == null || pageUrl.isEmpty()) return "";
        try {
            URI url = new URI(pageUrl);
            String host = url.getHost();
            if (host == null) return "";
            host = host.toLowerCase(Locale.ROOT);
            if (!(host.equals("youtube.com") || host.endsWith(".youtube.com"))) return "";
            String query = url.getRawQuery();
            if (query == null) return "";
            for (String term : query.split("&")) {
                if (!term.startsWith("list=")) continue;
                String value = URLDecoder.decode(term.substring(5), StandardCharsets.UTF_8.name());
                return value.matches("[A-Za-z0-9_-]{8,90}") ? value : "";
            }
        } catch (Exception ignored) { }
        return "";
    }

    public static boolean containsVideo(List<String> urls, String videoUrl) {
        String id = videoId(videoUrl);
        if (id.isEmpty() || urls == null) return false;
        for (String url : urls) if (id.equals(videoId(url))) return true;
        return false;
    }

    public static String videoId(String urlText) {
        if (urlText == null) return "";
        try {
            URI url = new URI(urlText);
            String host = url.getHost();
            if (host == null || !(host.equalsIgnoreCase("youtube.com") ||
                    host.toLowerCase(Locale.ROOT).endsWith(".youtube.com"))) return "";
            String query = url.getRawQuery();
            if (query == null) return "";
            for (String param : query.split("&")) {
                if (param.startsWith("v=") && param.substring(2).matches("[A-Za-z0-9_-]{11}"))
                    return param.substring(2);
            }
        } catch (Exception ignored) { }
        return "";
    }
}
