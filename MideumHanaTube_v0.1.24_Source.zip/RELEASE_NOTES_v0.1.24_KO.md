# 믿음하나튜브 v0.1.24 (versionCode 25) — YouTube 재생목록 문맥 수정 후보

## 실사용 검증 배경
- v0.1.23 / Galaxy Z Fold8, Android 17 (API 37), WebView 156.0.8078.47.
- 사용자 보고: PIP → 웹 복귀, 백그라운드 → 웹 복귀 시 최신 항목/위치 유지 정상.
- 오류: 유튜브 원본 플레이리스트 '모두 재생'을 PIP나 백그라운드 음악으로 넘기면 방문 이력·추천 영상 목록으로 대체되는 현상.
- 2026-11-07 10:00:37 진단 ZIP 300개 이벤트에 `QUEUE_ADVANCE/NEXT` 4개, `PIP_EXPAND_TO_WEB` 2개, `WEB_RETURN_CONFIRMED` 7개 확인.
- 진단 로그는 제목·URL을 저장하지 않으므로 '틀린 영상'의 실제 URL 자체는 로그만으로 식별 불가. 해당 동작의 직접적인 원인은 v0.1.23의 `collectPlaybackQueue`에서 확인됨.

## 변경
1. 웹 페이지에 `list=` 재생목록 문맥이 있는 경우 YouTube의 **재생목록 전용 렌더러**에서 실제 노출된 항목 순서를 캡처.
2. 페이지 전환(playlist → watch) 동안 같은 `list`의 더 긴 기존 스냅샷을 유지.
3. PIP / 백그라운드 진입 시 원본 플레이리스트가 있으면 **방문 기록이나 추천 영상으로 대기열을 대체하지 않음**.
4. 원본 목록을 웹에서 아직 읽지 못한 경우 현재 영상만 전송하여 잘못된 추천 영상이 나오는 것을 방지. 로그 `YOUTUBE_PLAYLIST_QUEUE/LIST_ITEMS_NOT_LOADED` 기록.
5. 원본 목록이 확보된 경우 `YOUTUBE_PLAYLIST_CAPTURED/VISIBLE_ORDER_N`, `YOUTUBE_PLAYLIST_QUEUE/ORIGINAL_ORDER_VISIBLE_N` 기록. 사용자 URL·곡 제목은 로그에 기록하지 않음.
6. PIP의 기본 버튼 설정을 **뒤로 10초 / 재생·정지 / 앞으로 10초**로 변경(기존 사용자가 다른 모드를 저장한 경우 해당 설정 존중). `PIP_ACTIONS_SET` 진단을 추가.
7. 기존 v0.1.23의 웹 복귀·재생 위치 동기화 등 동작은 유지.

## 제한 및 미구현
- YouTube의 긴 플레이리스트는 화면에서 일부만 로드될 수 있으며, 현재는 **실제 로드된 최대 80개 항목까지만** 추출. 예: 503곡 전체를 한 번에 읽었다고 보장하지 않음.
- YouTube 페이지 구조가 바뀌면 전용 항목을 읽지 못할 수 있음. 이때 추천 영상으로 몰래 대체하는 대신 현재 영상만 유지함.
- Android 기본 PIP는 드래그하는 재생 구간 바가 없음. 시스템이 사용자 지정 미디어 버튼을 화면에 표시하는 방식도 제조사·Android 버전에 따라 다를 수 있음.
- 광고 완전 차단, MP4/MP3 다운로드, 장시간 플레이리스트 증분 수집은 이번 수정판 범위 밖.
- APK 전체 Android 빌드 및 실제 기기 테스트는 이 환경에서 미검증. 로직 단위 / 오프라인 회귀 검사 결과와 구분.

## 빌드
- 소스 ZIP과 GitHub Actions YML을 담은 바깥 ZIP 1개.
- 자동 Debug APK: 별도 keystore/secret 불필요. GitHub Actions 러너별 서명이 달라질 수 있어 기존 Debug APK와 서명이 불일치하면 삭제 후 설치 필요.
- NewPipeExtractor GPL-3.0-or-later 및 프로젝트의 관련 라이선스 의무 유지.
