#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
javac --release 17 -encoding UTF-8 -d "$T" \
  app/src/main/java/app/mideumhanatube/android/YouTubePlaylistContext.java \
  tools/TestYouTubePlaylistContext.java
java -cp "$T" app.mideumhanatube.android.TestYouTubePlaylistContext
node - <<'JS'
const fs=require('fs'), vm=require('vm'), assert=require('assert');
const source=fs.readFileSync('app/src/main/assets/youtube-playlist-context.js','utf8');
const p='PL0123456789';
function row(id,t){return {querySelector(s){return {textContent:t,getAttribute(){return null;}}},querySelectorAll(s){return [{getAttribute(name){return name==='href' ? 'https://www.youtube.com/watch?v='+id+'&list='+p : ''}}]}};}
function run(url,rows,links){
 const context={location:{href:url},URL,document:{querySelectorAll:(s)=>s.includes('ytd-playlist-video-renderer')?rows:links}};
 return JSON.parse(vm.runInNewContext(source,context));
}
const a=run('https://www.youtube.com/playlist?list='+p,[row('AAAAAAAAAAA','첫곡'),row('BBBBBBBBBBB','둘째곡')],[]);
assert.equal(a.id,p);assert.deepEqual(a.tracks.map(x=>x.url.split('v=')[1]),['AAAAAAAAAAA','BBBBBBBBBBB']);
const b=run('https://www.youtube.com/watch?v=AAAAAAAAAAA',[],[]);
assert.equal(b.tracks.length,0);
console.log('YouTube playlist page row order and no-list case: PASS');
JS
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main/java/app/mideumhanatube/android')
m=(root/'MainActivity.java').read_text()
s=(root/'VideoPlayerActivity.java').read_text()
assert 'YOUTUBE_PLAYLIST_QUEUE' in m
assert 'youtubePlaylistTracks' in m and 'collectYoutubePlaylistTracks' in m
assert 'visibleRelatedTracks' in m
assert 'captured ? "ORIGINAL_ORDER_VISIBLE_"' in m
assert 'LIST_ITEMS_NOT_LOADED' in m
assert 'getInt("pip_action_mode", 1)' in m and 'getInt("pip_action_mode", 1)' in s
assert 'PIP_ACTIONS_SET' in s
print('v0.1.24 playlist precedence and default seek controls: PASS')
PY
