package app.mideumhanatube.android;

import java.util.Arrays;

public class TestYouTubePlaylistContext {
    private static void check(boolean ok, String label) { if (!ok) throw new AssertionError(label); }
    public static void main(String[] args) {
        String list = "PL0123456789";
        String first = "https://www.youtube.com/watch?v=AAAAAAAAAAA&list="+list+"&index=1";
        String second = "https://m.youtube.com/watch?v=BBBBBBBBBBB&list="+list+"&index=2";
        check(list.equals(YouTubePlaylistContext.playlistId(first)), "watch list context");
        check(list.equals(YouTubePlaylistContext.playlistId("https://m.youtube.com/playlist?list="+list)), "list page context");
        check("".equals(YouTubePlaylistContext.playlistId("https://example.com/watch?v=AAAAAAAAAAA&list="+list)), "external host rejected");
        check("".equals(YouTubePlaylistContext.playlistId("https://www.youtube.com/watch?v=AAAAAAAAAAA")), "normal watch no playlist");
        check(YouTubePlaylistContext.containsVideo(Arrays.asList("https://www.youtube.com/watch?v=AAAAAAAAAAA", "https://www.youtube.com/watch?v=BBBBBBBBBBB"), second), "media identity ignores list params");
        check(!YouTubePlaylistContext.containsVideo(Arrays.asList(first), second), "no false media matches");
        System.out.println("YouTube playlist ID / ordered source identity: PASS");
    }
}
