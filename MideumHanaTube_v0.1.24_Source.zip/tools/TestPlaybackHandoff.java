package app.mideumhanatube.android;
public final class TestPlaybackHandoff {
    private static void yes(boolean ok, String label) { if (!ok) throw new AssertionError(label); }
    public static void main(String[] ignored) {
        yes(PlaybackHandoff.normalizedPipActionMode(-1)==0,"negative mode defaults to queue");
        yes(PlaybackHandoff.normalizedPipActionMode(0)==0,"queue mode");
        yes(PlaybackHandoff.normalizedPipActionMode(1)==1,"seek mode");
        yes(PlaybackHandoff.normalizedPipActionMode(999)==0,"invalid mode ignored");
        yes(PlaybackHandoff.withinSeekTolerance(123000,123000),"identical timeline");
        yes(PlaybackHandoff.withinSeekTolerance(123000,119500),"lagged keyframe");
        yes(PlaybackHandoff.withinSeekTolerance(123000,126500),"ahead keyframe");
        yes(!PlaybackHandoff.withinSeekTolerance(123000,126501),"reject more than tolerance");
        yes(!PlaybackHandoff.withinSeekTolerance(123000,0),"reject old web position");
        yes(!PlaybackHandoff.withinSeekTolerance(-1,0),"reject negative request");
        yes(!PlaybackHandoff.withinSeekTolerance(0,-1),"reject invalid actual");
        PlaybackQueue q=new PlaybackQueue();
        java.util.List<PlaybackQueue.Track> tracks=java.util.Arrays.asList(
            new PlaybackQueue.Track("a","first"),
            new PlaybackQueue.Track("a","duplicate"),
            new PlaybackQueue.Track("b","second"),
            new PlaybackQueue.Track("c","third"));
        q.setTracks(tracks,2);
        yes(q.size()==3,"deduplicated queue");
        yes(q.current()!=null && "b".equals(q.current().url),"selected identity preserved after dedup");
        yes("c".equals(q.next(false).url),"next follows real current track");
        q.setTracks(tracks,1);
        yes("a".equals(q.current().url),"selected duplicate picks correct identity");
        System.out.println("v0.1.24 session handoff / selected queue identity: PASS");
    }
}
