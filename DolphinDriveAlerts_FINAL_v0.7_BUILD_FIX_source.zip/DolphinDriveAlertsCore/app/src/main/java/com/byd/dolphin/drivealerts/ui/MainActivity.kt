package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.KeyEvent
import android.widget.AdapterView
import android.widget.*
import com.byd.dolphin.drivealerts.audio.VoiceAssetCatalog
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.log.DiagnosticsExporter
import com.byd.dolphin.drivealerts.steering.SteeringTriggerMode
import com.byd.dolphin.drivealerts.steering.SteeringTriggerPreferences

class MainActivity : Activity() {
    private lateinit var eventSpinner: Spinner
    private lateinit var sideSpinner: Spinner
    private lateinit var oneShotStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        DrivingAlertService.start(this)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 24, 30, 30)
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "주행 보조 알림 · CORE 0.7 FINAL · STEERING 3-TAP + AVAS DIAG + AUTO-START + VOICE + RAWLOG"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "UI 완성 전 기능 검증 화면입니다. 알림 출력·신호 감시·앱별 DPI 정책만 먼저 구현합니다."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(media); box.addView(route)
        if (AlertPreferences.route(this) == OutputRoute.DRIVER_STREAM14) driver.isChecked = true else media.isChecked = true
        route.setOnCheckedChangeListener { _, id -> AlertPreferences.setRoute(this, if (id == driver.id) OutputRoute.DRIVER_STREAM14 else OutputRoute.MEDIA) }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개 + 단발 기본음 남/여 2개(총 60개)를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        box.addView(section("알림 테스트"))
        eventSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, AlertEvent.entries.map { "${it.name} · ${it.phrase}" }) }
        sideSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Side.entries.map { it.name }) }
        box.addView(eventSpinner); box.addView(sideSpinner)
        box.addView(Button(this).apply {
            text = "선택 알림 즉시 재생"
            setOnClickListener {
                DrivingAlertService.test(this@MainActivity, AlertEvent.entries[eventSpinner.selectedItemPosition], Side.entries[sideSpinner.selectedItemPosition])
            }
        })

        box.addView(section("핸들 메뉴/이전 3연타 · 단발 음성"))
        box.addView(TextView(this).apply {
            text = "메뉴 또는 이전 버튼을 빠르게 3번(첫 입력부터 1.2초 이내) 누르면 단발 음성을 한 번 재생합니다. 키 입력은 감시만 하고 소비하지 않아 순정 단일/이중 클릭 동작은 그대로 둡니다. 현재는 운전석 stream 14 또는 미디어 경로로 재생하며, 외부 AVAS 스피커는 0.5 진단 로그로 실제 경로가 확인된 뒤 연결합니다."
            textSize = 13f
        })
        box.addView(CheckBox(this).apply {
            text = "핸들 3연타 단발 음성 사용"
            isChecked = SteeringTriggerPreferences.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> SteeringTriggerPreferences.setEnabled(this@MainActivity, checked) }
        })
        val triggerModes = SteeringTriggerMode.entries
        val triggerLabels = mapOf(
            SteeringTriggerMode.MENU to "메뉴 버튼 (KEYCODE_MENU)",
            SteeringTriggerMode.BACK to "이전 버튼 (KEYCODE_BACK)",
            SteeringTriggerMode.EITHER to "메뉴 또는 이전 버튼",
            SteeringTriggerMode.LEARNED to "실차에서 학습한 버튼"
        )
        box.addView(TextView(this).apply { text = "3연타 감지 버튼"; textSize = 14f })
        box.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, triggerModes.map { triggerLabels[it] ?: it.name })
            setSelection(triggerModes.indexOf(SteeringTriggerPreferences.mode(this@MainActivity)).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    SteeringTriggerPreferences.setMode(this@MainActivity, triggerModes[position])
                    refreshOneShotStatus()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        })
        oneShotStatus = TextView(this).apply { textSize = 13f; setPadding(0, 8, 0, 8) }
        box.addView(oneShotStatus)
        refreshOneShotStatus()
        box.addView(Button(this).apply {
            text = "내 단발 음성파일 선택 (WAV 권장 · MP3/M4A/OGG 가능)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(i, REQ_ONE_SHOT_AUDIO)
            }
        })
        box.addView(Button(this).apply {
            text = "선택 음성 삭제 · 기본 '빵빵, 차 좀 지나갈게요' 사용"
            setOnClickListener {
                SteeringTriggerPreferences.clearSound(this@MainActivity)
                refreshOneShotStatus()
                Toast.makeText(this@MainActivity, "기본 단발 음성으로 복원했습니다.", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "단발 음성 즉시 테스트"
            setOnClickListener { DrivingAlertService.playOneShot(this@MainActivity, "manual_test") }
        })
        box.addView(Button(this).apply {
            text = "실차 핸들 버튼 학습 시작 · 15초 안에 원하는 버튼 1회 누르기"
            setOnClickListener {
                SteeringTriggerPreferences.armLearning(this@MainActivity)
                SteeringTriggerPreferences.setMode(this@MainActivity, SteeringTriggerMode.LEARNED)
                DrivingAlertService.activeLogger?.marker("STEERING_LEARN_ARMED", "15s")
                refreshOneShotStatus("학습 대기 중: 15초 안에 핸들 메뉴/이전 버튼을 1번 누르세요.")
                Toast.makeText(this@MainActivity, "15초 안에 사용할 핸들 버튼을 한 번 누르세요.", Toast.LENGTH_LONG).show()
            }
        })
        box.addView(Button(this).apply {
            text = "핸들 버튼 학습 상태 새로고침"
            setOnClickListener { refreshOneShotStatus() }
        })
        box.addView(Button(this).apply {
            text = "핸들 버튼 RAW 10초 캡처 · 누른 뒤 버튼을 여러 번 눌러보기"
            setOnClickListener {
                val diag = DrivingAlertService.activeDiagnostics
                if (diag == null) {
                    DrivingAlertService.start(this@MainActivity)
                    Toast.makeText(this@MainActivity, "진단 서비스 시작 중입니다. 잠시 후 다시 눌러주세요.", Toast.LENGTH_LONG).show()
                } else {
                    diag.captureSteeringKeyWindow(10)
                    Toast.makeText(this@MainActivity, "10초 동안 RAW 입력을 캡처합니다. 메뉴/이전 버튼을 3~5번 눌러주세요.", Toast.LENGTH_LONG).show()
                }
            }
        })
        box.addView(TextView(this).apply {
            text = "핸들 키 감지는 접근성 서비스의 key-event filter를 사용합니다. 최초 한 번 '접근성 서비스 설정 열기'에서 이 앱을 켜야 합니다. 차량이 MENU/BACK 표준 KeyEvent를 보내지 않으면 '실차 버튼 학습' 또는 RAW 10초 캡처 결과로 실제 keyCode/scanCode를 찾습니다."
            textSize = 13f
        })

        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(TextView(this).apply {
            text = "설치 후 최초 1회 앱을 실행하면 이후 일반 재부팅·차량 Quick Boot·앱 업데이트 후 foreground 서비스가 자동 시작됩니다. 화면을 닫거나 최근 앱에서 지워도 서비스는 계속 유지됩니다. Android 설정에서 강제 종료한 경우에는 Android 정책상 다시 한 번 앱을 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(section("실차 RAW 신호 로그"))
        box.addView(TextView(this).apply {
            text = "앱 서비스가 실행되는 동안 차량 RAW 신호를 자동 수집합니다. 1초 주기 전체 스냅샷 + 값 변경 즉시 기록 + BYD read-only getter 자동 탐색을 함께 저장합니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "수집된 파일 생성 · Download 폴더에 저장"
            setOnClickListener {
                val logger = DrivingAlertService.activeLogger
                if (logger == null) {
                    DrivingAlertService.start(this@MainActivity)
                    Toast.makeText(this@MainActivity, "로그 서비스 시작 중입니다. 잠시 후 다시 눌러주세요.", Toast.LENGTH_LONG).show()
                } else {
                    logger.marker("USER_EXPORT_REQUEST")
                    isEnabled = false
                    Thread {
                        val result = DiagnosticsExporter.exportToDownloads(this@MainActivity, logger, DrivingAlertService.activeDiagnostics)
                        runOnUiThread {
                            isEnabled = true
                            Toast.makeText(this@MainActivity,
                                result.fold({ "생성 완료: $it" }, { "생성 실패: ${it.message}" }),
                                Toast.LENGTH_LONG).show()
                        }
                    }.start()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "현재 시점 마커 기록"
            setOnClickListener {
                DrivingAlertService.activeLogger?.marker("USER_MARKER")
                Toast.makeText(this@MainActivity, "마커를 기록했습니다.", Toast.LENGTH_SHORT).show()
            }
        })

        box.addView(section("순정 주행 전자음 / 외부 스피커 진단"))
        box.addView(TextView(this).apply {
            text = "이 기능은 순정 설정이나 차량 제어값을 변경하지 않고 읽기만 합니다. 순정 UI의 주행 전자음 OFF/ON 전후에 버튼을 눌러 BYD 이벤트 ID, read-only getter, Android 오디오 장치/라우트, dumpsys audio/audio_policy/audio_flinger, getprop, Settings 값, ALSA/tinymix 상태와 관련 logcat을 함께 저장합니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "1. 기준 상태 캡처"
            setOnClickListener {
                val logger = DrivingAlertService.activeLogger
                val diag = DrivingAlertService.activeDiagnostics
                if (logger == null || diag == null) {
                    DrivingAlertService.start(this@MainActivity)
                    Toast.makeText(this@MainActivity, "진단 서비스 시작 중입니다. 잠시 후 다시 눌러주세요.", Toast.LENGTH_LONG).show()
                } else {
                    logger.marker("AVAS_TEST_BASELINE")
                    diag.captureDeep("AVAS_BASELINE")
                    Toast.makeText(this@MainActivity, "기준 상태를 캡처합니다.", Toast.LENGTH_SHORT).show()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "2. 순정 UI에서 주행 전자음 OFF 후 기록"
            setOnClickListener {
                DrivingAlertService.activeLogger?.marker("AVAS_UI_OFF")
                DrivingAlertService.activeDiagnostics?.captureQuick("AVAS_UI_OFF")
                Toast.makeText(this@MainActivity, "OFF 상태 마커/진단 캡처를 시작했습니다.", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "3. 순정 UI에서 주행 전자음 ON 후 기록"
            setOnClickListener {
                DrivingAlertService.activeLogger?.marker("AVAS_UI_ON")
                DrivingAlertService.activeDiagnostics?.captureQuick("AVAS_UI_ON")
                Toast.makeText(this@MainActivity, "ON 상태 마커/진단 캡처를 시작했습니다.", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "4. 실제 외부 전자음 12초 구간 캡처"
            setOnClickListener {
                DrivingAlertService.activeDiagnostics?.captureWindow("AVAS_EXTERNAL_SOUND", 12)
                Toast.makeText(this@MainActivity, "12초 구간 캡처 시작. 안전한 곳에서 실제 외부 전자음이 나도록 저속 운행 후 정차하세요.", Toast.LENGTH_LONG).show()
            }
        })
        box.addView(TextView(this).apply {
            text = "권장 순서: 기준 캡처 → 순정 주행 전자음 OFF 후 5초 → OFF 기록 → ON 후 5초 → ON 기록 → 안전한 사유지/정차 가능한 곳에서 12초 실제 출력 구간 캡처 → 정차 후 Download ZIP 생성."
            textSize = 13f
        })

        box.addView(section("지정 앱 정책"))
        box.addView(Button(this).apply { text = "지정 앱 선택 · DPI/출력 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(Button(this).apply { text = "접근성 서비스 설정 열기"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        box.addView(TextView(this).apply {
            text = "DPI: 선택 앱이 전면에 있을 때 순정/140/120/수동값을 적용하고 벗어나면 wm density reset.\n다른 앱 오디오: 미디어는 기본 동작, 운전석 강제 라우팅은 BYD cross-UID 전용 훅 검증 전까지 '검증대기'로 표시합니다."
            textSize = 13f
        })

        val required = VoiceAssetCatalog.requiredAssetNames().size
        box.addView(section("상태"))
        box.addView(TextView(this).apply {
            text = "주행 알림 음성 슬롯: $required 개 + 단발 기본음 2개(총 60개)\nRAW 로그: 서비스 시작과 동시에 자동 수집 + BYD 이벤트/오디오 route 변화 기록, 버튼으로 RAW+AVAS 진단 Download ZIP 생성\n기어/EPB: 실차 확인 매핑 적용\n회생제동: AutoFeedback 참조값 2=STANDARD, 3=HIGH 적용\n그 외 원시신호: 추정 재생 금지, 캘리브레이션 로그 수집"
            textSize = 13f
        })
        return root
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ONE_SHOT_AUDIO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            Thread {
                val result = SteeringTriggerPreferences.importSound(this, uri)
                runOnUiThread {
                    result.fold(
                        onSuccess = {
                            refreshOneShotStatus()
                            Toast.makeText(this, "단발 음성 등록 완료: $it", Toast.LENGTH_LONG).show()
                        },
                        onFailure = { Toast.makeText(this, "음성 등록 실패: ${it.message}", Toast.LENGTH_LONG).show() }
                    )
                }
            }.start()
        }
    }

    private fun refreshOneShotStatus(extra: String? = null) {
        if (!::oneShotStatus.isInitialized) return
        val keyCode = SteeringTriggerPreferences.learnedKeyCode(this)
        val scanCode = SteeringTriggerPreferences.learnedScanCode(this)
        val learned = if (keyCode >= 0) "${KeyEvent.keyCodeToString(keyCode)} / keyCode=$keyCode / scanCode=$scanCode" else "아직 없음"
        val learning = if (SteeringTriggerPreferences.isLearning(this)) " · 현재 학습 대기 중" else ""
        oneShotStatus.text = buildString {
            append("현재 음성: ${SteeringTriggerPreferences.soundName(this@MainActivity)}\n")
            append("감지 모드: ${SteeringTriggerPreferences.mode(this@MainActivity)}$learning\n")
            append("학습된 버튼: $learned")
            if (!extra.isNullOrBlank()) append("\n$extra")
        }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }

    companion object {
        private const val REQ_ONE_SHOT_AUDIO = 6106
    }
}
