package com.byd.dolphin.drivealerts.steering

import android.content.Context
import android.view.KeyEvent
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Observes (does not consume) steering/menu/back key presses. Three DOWN presses of the same
 * configured key inside TRIPLE_WINDOW_MS trigger one local one-shot audio playback.
 */
object SteeringTripleTapDetector {
    private val window = TripleTapWindow(windowMs = 1_200L, minGapMs = 80L)

    @Synchronized
    fun onKeyEvent(context: Context, event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount != 0) return false
        val now = event.eventTime.takeIf { it > 0 } ?: System.currentTimeMillis()
        val detail = "keyCode=${event.keyCode} scanCode=${event.scanCode} deviceId=${event.deviceId} source=0x${event.source.toString(16)} flags=0x${event.flags.toString(16)}"
        DrivingAlertService.activeLogger?.marker("STEERING_KEY_DOWN", detail)
        CoreLog.i("STEERING_KEY", detail)

        if (SteeringTriggerPreferences.isLearning(context)) {
            SteeringTriggerPreferences.saveLearnedKey(context, event.keyCode, event.scanCode)
            DrivingAlertService.activeLogger?.marker("STEERING_KEY_LEARNED", detail)
            CoreLog.i("STEERING_KEY", "learned $detail")
            return false
        }

        if (!SteeringTriggerPreferences.enabled(context) || !matches(context, event)) return false
        val identity = "${event.keyCode}:${event.scanCode}"
        if (window.register(now, identity)) {
            DrivingAlertService.activeLogger?.marker("STEERING_TRIPLE_TAP", detail)
            CoreLog.i("STEERING_KEY", "triple tap trigger $detail")
            DrivingAlertService.playOneShot(context, "steering_triple_tap")
        }
        return false // Never consume: single/double presses keep the OEM behavior.
    }

    private fun matches(context: Context, event: KeyEvent): Boolean = when (SteeringTriggerPreferences.mode(context)) {
        SteeringTriggerMode.MENU -> event.keyCode == KeyEvent.KEYCODE_MENU
        SteeringTriggerMode.BACK -> event.keyCode == KeyEvent.KEYCODE_BACK
        SteeringTriggerMode.EITHER -> event.keyCode == KeyEvent.KEYCODE_MENU || event.keyCode == KeyEvent.KEYCODE_BACK
        SteeringTriggerMode.LEARNED -> {
            val code = SteeringTriggerPreferences.learnedKeyCode(context)
            val scan = SteeringTriggerPreferences.learnedScanCode(context)
            code >= 0 && event.keyCode == code && (scan < 0 || event.scanCode < 0 || event.scanCode == scan)
        }
    }
}
