package app.mideumhanatube.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Keeps the app process in a foreground media-playback service while WebView plays audio.
 * The actual video stays in MainActivity's WebView. This does NOT override YouTube's
 * site-level background restrictions or resurrect playback after the Activity is killed.
 */
public final class BackgroundAudioService extends Service {
    public static final String ACTION_UPDATE = "app.mideumhanatube.android.media.UPDATE";
    public static final String ACTION_PLAY = "app.mideumhanatube.android.media.PLAY";
    public static final String ACTION_PAUSE = "app.mideumhanatube.android.media.PAUSE";
    public static final String ACTION_STOP = "app.mideumhanatube.android.media.STOP";
    public static final String ACTION_CONTROL = "app.mideumhanatube.android.media.CONTROL";
    public static final String ACTION_FEEDBACK = "app.mideumhanatube.android.media.FEEDBACK";
    public static final String EXTRA_ERROR = "error";
    public static final String EXTRA_PLAYING = "playing";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_CONTROL = "control";
    private static final String CHANNEL_ID = "mht_background_audio";
    private static final int NOTIFICATION_ID = 1002;
    private static final long PAUSED_TIMEOUT_MS = 120_000L;

    // Java field initializers run in declaration order. State referenced from
    // stopWhenPaused must be declared before its lambda initializer.
    private boolean playing;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable stopWhenPaused = () -> {
        if (!playing) stopSelf();
    };
    private MediaSession session;
    private PowerManager.WakeLock wakeLock;
    private String title = "믿음하나튜브";
    private String playbackMessage = "재생 상태 확인 중";
    private boolean awaitingPlaybackConfirmation;
    private final Runnable noPlayerResponse = () -> {
        if (awaitingPlaybackConfirmation) {
            awaitingPlaybackConfirmation = false;
            playbackMessage = "웹 플레이어의 재생 응답 없음. 앱 화면을 확인하세요.";
            updateSessionAndNotification();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "백그라운드 음악 재생",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("믿음하나튜브가 음악을 재생할 때 표시합니다.");
            channel.setSound(null, null);
            nm.createNotificationChannel(channel);
        }
        session = new MediaSession(this, "MideumHanaTubeBackgroundAudio");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { requestPlayerControl(ACTION_PLAY); }
            @Override public void onPause() { requestPlayerControl(ACTION_PAUSE); }
            @Override public void onStop() { relay(ACTION_STOP); stopSelf(); }
        });
        session.setActive(true);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MideumHanaTube:BackgroundAudio");
            wakeLock.setReferenceCounted(false);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            relay(ACTION_STOP);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_PLAY.equals(action) || ACTION_PAUSE.equals(action)) {
            requestPlayerControl(action);
        } else if (ACTION_UPDATE.equals(action)) {
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            playing = intent.getBooleanExtra(EXTRA_PLAYING, false);
            String nextTitle = intent.getStringExtra(EXTRA_TITLE);
            if (nextTitle != null && !nextTitle.trim().isEmpty()) title = nextTitle;
            playbackMessage = playing ? "백그라운드 오디오 재생 중" : "재생 일시중지";
        } else if (ACTION_FEEDBACK.equals(action)) {
            awaitingPlaybackConfirmation = false;
            handler.removeCallbacks(noPlayerResponse);
            String error = intent.getStringExtra(EXTRA_ERROR);
            if (error != null && !error.trim().isEmpty()) {
                playing = false;
                playbackMessage = error;
            }
        } else {
            stopSelf();
            return START_NOT_STICKY;
        }
        updateSessionAndNotification();
        return START_NOT_STICKY;
    }

    private void requestPlayerControl(String action) {
        // Commands from MediaSession and notification both arrive here. Never set
        // playing=true until the WebView reports actual playback success.
        awaitingPlaybackConfirmation = true;
        playbackMessage = "웹 플레이어 응답 확인 중";
        relay(action);
        handler.removeCallbacks(noPlayerResponse);
        handler.postDelayed(noPlayerResponse, 1800L);
    }

    private void relay(String action) {
        Intent message = new Intent(ACTION_CONTROL);
        message.setPackage(getPackageName());
        message.putExtra(EXTRA_CONTROL, action);
        sendBroadcast(message);
    }

    private void updateSessionAndNotification() {
        long available = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_PLAY_PAUSE;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(available)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, playing ? 1f : 0f)
                .build());
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "믿음하나튜브")
                .build());
        Notification notification = buildNotification();
        // Start/refresh foreground state in response to active, user-initiated playback.
        if (playing) {
            handler.removeCallbacks(stopWhenPaused);
            try {
                startForeground(NOTIFICATION_ID, notification);
            } catch (RuntimeException e) {
                // Foreground start may be denied by newer Android background-start limits.
                stopSelf();
                return;
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        } else {
            releaseWakeLock();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIFICATION_ID, notification);
            handler.removeCallbacks(stopWhenPaused);
            handler.postDelayed(stopWhenPaused, PAUSED_TIMEOUT_MS);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 100, openIntent, flags());
        String controlAction = playing ? ACTION_PAUSE : ACTION_PLAY;
        int controlIcon = playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        String controlLabel = playing ? "일시중지" : "재생";
        Notification.Action toggle = new Notification.Action.Builder(
                controlIcon, controlLabel, servicePending(controlAction, 101)).build();
        Notification.Action stop = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel, "종료", servicePending(ACTION_STOP, 102)).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(playbackMessage)
                .setContentIntent(openPending)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(playing)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(toggle)
                .addAction(stop)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0))
                .build();
    }

    private PendingIntent servicePending(String action, int id) {
        return PendingIntent.getService(this, id,
                new Intent(this, BackgroundAudioService.class).setAction(action), flags());
    }

    private static int flags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(stopWhenPaused);
        handler.removeCallbacks(noPlayerResponse);
        releaseWakeLock();
        if (session != null) { session.setActive(false); session.release(); session = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
