package com.dolphin.sms.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.dolphin.sms.R;
import com.dolphin.sms.model.Conversation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConversationAdapter extends BaseAdapter {

    private final Context context;
    private final LayoutInflater inflater;
    private final List<Conversation> items = new ArrayList<>();
    private long selectedThreadId = -1L;

    private final SimpleDateFormat fmtTime = new SimpleDateFormat("a h:mm", Locale.KOREA);
    private final SimpleDateFormat fmtDate = new SimpleDateFormat("M/d", Locale.KOREA);

    public ConversationAdapter(Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    public void setItems(List<Conversation> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    public void setSelectedThreadId(long threadId) {
        this.selectedThreadId = threadId;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Conversation getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).threadId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_conversation, parent, false);
            h = new ViewHolder();
            h.root = convertView.findViewById(R.id.rowRoot);
            h.dot = convertView.findViewById(R.id.viewUnreadDot);
            h.sender = convertView.findViewById(R.id.tvSender);
            h.date = convertView.findViewById(R.id.tvDate);
            h.snippet = convertView.findViewById(R.id.tvSnippet);
            convertView.setTag(h);
        } else {
            h = (ViewHolder) convertView.getTag();
        }

        Conversation item = items.get(position);
        boolean isSelected = item.threadId == selectedThreadId;
        h.root.setBackgroundColor(context.getColor(
                isSelected ? R.color.bg_card_selected : R.color.bg_panel));

        h.dot.setVisibility(item.unreadCount > 0 ? View.VISIBLE : View.INVISIBLE);
        h.sender.setText(item.displayName);
        h.date.setText(formatShortTime(item.dateMillis));
        h.snippet.setText(item.snippet);
        h.snippet.setTypeface(null, item.unreadCount > 0 ? Typeface.BOLD : Typeface.NORMAL);
        h.snippet.setTextColor(context.getColor(
                item.unreadCount > 0 ? R.color.text_primary : R.color.text_secondary));

        return convertView;
    }

    private String formatShortTime(long millis) {
        Calendar now = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.setTimeInMillis(millis);
        if (now.get(Calendar.YEAR) == target.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR)) {
            return fmtTime.format(new Date(millis));
        }
        return fmtDate.format(new Date(millis));
    }

    private static class ViewHolder {
        View root;
        View dot;
        TextView sender;
        TextView date;
        TextView snippet;
    }
}
