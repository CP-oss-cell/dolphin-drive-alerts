package com.dolphin.sms.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.dolphin.sms.R;
import com.dolphin.sms.model.SmsMessageItem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageAdapter extends BaseAdapter {
    private static final int TYPE_IN = 0;
    private static final int TYPE_OUT = 1;

    private final LayoutInflater inflater;
    private final List<SmsMessageItem> items = new ArrayList<>();
    private final SimpleDateFormat fmt = new SimpleDateFormat("M/d a h:mm", Locale.KOREA);

    public MessageAdapter(Context context) {
        this.inflater = LayoutInflater.from(context);
    }

    public void setItems(List<SmsMessageItem> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public SmsMessageItem getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).id;
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).isIncoming() ? TYPE_IN : TYPE_OUT;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int viewType = getItemViewType(position);
        ViewHolder h;
        if (convertView == null) {
            int layoutId = (viewType == TYPE_IN)
                    ? R.layout.item_message_in
                    : R.layout.item_message_out;
            convertView = inflater.inflate(layoutId, parent, false);
            h = new ViewHolder();
            h.body = convertView.findViewById(R.id.tvBody);
            h.time = convertView.findViewById(R.id.tvTime);
            convertView.setTag(h);
        } else {
            h = (ViewHolder) convertView.getTag();
        }

        SmsMessageItem item = items.get(position);
        h.body.setText(item.body);
        String timeStr = fmt.format(new Date(item.dateMillis));
        if (item.isFailed()) {
            timeStr = timeStr + " · 전송 실패";
        }
        h.time.setText(timeStr);
        return convertView;
    }

    private static class ViewHolder {
        TextView body;
        TextView time;
    }
}
