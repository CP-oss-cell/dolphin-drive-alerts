package com.dolphin.sms.data;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.telephony.PhoneNumberUtils;

import com.dolphin.sms.model.Conversation;
import com.dolphin.sms.model.SmsMessageItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 순수 Android Telephony ContentProvider 기반 초경량 SMS 저장소.
 * BYD DiLink 등 OEM Android 환경에서 호환성 문제를 피하기 위해
 * 비표준 Threads 컬럼 대신 표준 Telephony.Sms 테이블을 직접 조회합니다.
 */
public class SmsRepository {

    private final Context context;
    private final Map<String, String> contactCache = new HashMap<>();

    public SmsRepository(Context context) {
        this.context = context.getApplicationContext();
    }

    public List<Conversation> loadConversations(String filterQuery) {
        Map<Long, ConversationBuilder> map = new LinkedHashMap<>();
        String[] projection = new String[]{
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.READ
        };

        try (Cursor c = context.getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                projection,
                null,
                null,
                Telephony.Sms.DATE + " DESC"
        )) {
            if (c != null) {
                int idxThread = c.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID);
                int idxAddr = c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS);
                int idxBody = c.getColumnIndexOrThrow(Telephony.Sms.BODY);
                int idxDate = c.getColumnIndexOrThrow(Telephony.Sms.DATE);
                int idxRead = c.getColumnIndexOrThrow(Telephony.Sms.READ);

                while (c.moveToNext()) {
                    long threadId = c.getLong(idxThread);
                    String address = safe(c.getString(idxAddr));
                    String body = safe(c.getString(idxBody));
                    long date = c.getLong(idxDate);
                    boolean isRead = c.getInt(idxRead) != 0;

                    ConversationBuilder b = map.get(threadId);
                    if (b == null) {
                        b = new ConversationBuilder(threadId, address, body, date);
                        map.put(threadId, b);
                    }
                    if (!isRead) {
                        b.unreadCount++;
                    }
                }
            }
        } catch (SecurityException ignored) {
            return new ArrayList<>();
        }

        String q = filterQuery == null ? "" : filterQuery.trim().toLowerCase(Locale.KOREA);
        List<Conversation> result = new ArrayList<>();
        for (ConversationBuilder b : map.values()) {
            String displayName = resolveContactName(b.address);
            if (!q.isEmpty()) {
                boolean match = displayName.toLowerCase(Locale.KOREA).contains(q)
                        || b.address.toLowerCase(Locale.KOREA).contains(q)
                        || b.snippet.toLowerCase(Locale.KOREA).contains(q);
                if (!match) continue;
            }
            result.add(new Conversation(
                    b.threadId,
                    b.address,
                    displayName,
                    b.snippet,
                    b.dateMillis,
                    b.unreadCount
            ));
        }
        return result;
    }

    public List<SmsMessageItem> loadMessages(long threadId) {
        List<SmsMessageItem> list = new ArrayList<>();
        String[] projection = new String[]{
                Telephony.Sms._ID,
                Telephony.Sms.THREAD_ID,
                Telephony.Sms.ADDRESS,
                Telephony.Sms.BODY,
                Telephony.Sms.DATE,
                Telephony.Sms.TYPE,
                Telephony.Sms.READ
        };

        try (Cursor c = context.getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                projection,
                Telephony.Sms.THREAD_ID + " = ?",
                new String[]{String.valueOf(threadId)},
                Telephony.Sms.DATE + " ASC"
        )) {
            if (c != null) {
                int idxId = c.getColumnIndexOrThrow(Telephony.Sms._ID);
                int idxThread = c.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID);
                int idxAddr = c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS);
                int idxBody = c.getColumnIndexOrThrow(Telephony.Sms.BODY);
                int idxDate = c.getColumnIndexOrThrow(Telephony.Sms.DATE);
                int idxType = c.getColumnIndexOrThrow(Telephony.Sms.TYPE);
                int idxRead = c.getColumnIndexOrThrow(Telephony.Sms.READ);

                while (c.moveToNext()) {
                    list.add(new SmsMessageItem(
                            c.getLong(idxId),
                            c.getLong(idxThread),
                            safe(c.getString(idxAddr)),
                            safe(c.getString(idxBody)),
                            c.getLong(idxDate),
                            c.getInt(idxType),
                            c.getInt(idxRead) != 0
                    ));
                }
            }
        } catch (SecurityException ignored) {
        }
        return list;
    }

    public long findThreadIdByAddress(String rawAddress) {
        if (rawAddress == null || rawAddress.trim().isEmpty()) return -1L;
        String target = normalizeDigits(rawAddress);
        try (Cursor c = context.getContentResolver().query(
                Telephony.Sms.CONTENT_URI,
                new String[]{Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS},
                null,
                null,
                Telephony.Sms.DATE + " DESC"
        )) {
            if (c != null) {
                int idxThread = c.getColumnIndexOrThrow(Telephony.Sms.THREAD_ID);
                int idxAddr = c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS);
                while (c.moveToNext()) {
                    String addr = safe(c.getString(idxAddr));
                    if (normalizeDigits(addr).equals(target) || addr.equalsIgnoreCase(rawAddress.trim())) {
                        return c.getLong(idxThread);
                    }
                }
            }
        } catch (SecurityException ignored) {
        }
        return -1L;
    }

    public void insertIncomingSms(String address, String body, long timestamp) {
        ContentValues values = new ContentValues();
        values.put(Telephony.Sms.ADDRESS, address);
        values.put(Telephony.Sms.BODY, body);
        values.put(Telephony.Sms.DATE, timestamp);
        values.put(Telephony.Sms.READ, 0);
        values.put(Telephony.Sms.SEEN, 0);
        values.put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX);
        try {
            context.getContentResolver().insert(Telephony.Sms.Inbox.CONTENT_URI, values);
        } catch (Exception ignored) {
        }
    }

    public void insertSentSms(String address, String body, boolean failed) {
        ContentValues values = new ContentValues();
        values.put(Telephony.Sms.ADDRESS, address);
        values.put(Telephony.Sms.BODY, body);
        values.put(Telephony.Sms.DATE, System.currentTimeMillis());
        values.put(Telephony.Sms.READ, 1);
        values.put(Telephony.Sms.SEEN, 1);
        values.put(Telephony.Sms.TYPE, failed
                ? Telephony.Sms.MESSAGE_TYPE_FAILED
                : Telephony.Sms.MESSAGE_TYPE_SENT);
        try {
            context.getContentResolver().insert(Telephony.Sms.Sent.CONTENT_URI, values);
        } catch (Exception ignored) {
        }
    }

    public void markThreadAsRead(long threadId) {
        if (!isDefaultSmsApp(context)) return;
        ContentValues values = new ContentValues();
        values.put(Telephony.Sms.READ, 1);
        values.put(Telephony.Sms.SEEN, 1);
        try {
            context.getContentResolver().update(
                    Telephony.Sms.CONTENT_URI,
                    values,
                    Telephony.Sms.THREAD_ID + " = ? AND " + Telephony.Sms.READ + " = 0",
                    new String[]{String.valueOf(threadId)}
            );
        } catch (Exception ignored) {
        }
    }

    public boolean deleteThread(long threadId) {
        if (!isDefaultSmsApp(context)) return false;
        try {
            int rows = context.getContentResolver().delete(
                    Telephony.Sms.CONTENT_URI,
                    Telephony.Sms.THREAD_ID + " = ?",
                    new String[]{String.valueOf(threadId)}
            );
            return rows > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean deleteMessage(long messageId) {
        if (!isDefaultSmsApp(context)) return false;
        try {
            int rows = context.getContentResolver().delete(
                    Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, String.valueOf(messageId)),
                    null,
                    null
            );
            return rows > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public String resolveContactName(String address) {
        if (address == null || address.trim().isEmpty()) return "알 수 없음";
        String cached = contactCache.get(address);
        if (cached != null) return cached;

        String result = formatPhone(address);
        if (context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {
            Uri uri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                    Uri.encode(address)
            );
            ContentResolver cr = context.getContentResolver();
            try (Cursor c = cr.query(
                    uri,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                    null, null, null
            )) {
                if (c != null && c.moveToFirst()) {
                    String name = c.getString(0);
                    if (name != null && !name.trim().isEmpty()) {
                        result = name.trim();
                    }
                }
            } catch (Exception ignored) {
            }
        }
        contactCache.put(address, result);
        return result;
    }

    public static String formatPhone(String raw) {
        if (raw == null) return "";
        String formatted = PhoneNumberUtils.formatNumber(raw, "KR");
        return formatted != null ? formatted : raw;
    }

    public static boolean isDefaultSmsApp(Context context) {
        String defaultPkg = Telephony.Sms.getDefaultSmsPackage(context);
        return context.getPackageName().equals(defaultPkg);
    }

    private static String normalizeDigits(String s) {
        return s == null ? "" : s.replaceAll("[^0-9]", "");
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private static class ConversationBuilder {
        final long threadId;
        final String address;
        final String snippet;
        final long dateMillis;
        int unreadCount = 0;

        ConversationBuilder(long threadId, String address, String snippet, long dateMillis) {
            this.threadId = threadId;
            this.address = address;
            this.snippet = snippet;
            this.dateMillis = dateMillis;
        }
    }
}
