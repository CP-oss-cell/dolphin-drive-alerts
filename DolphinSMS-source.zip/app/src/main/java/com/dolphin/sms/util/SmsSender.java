package com.dolphin.sms.util;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.telephony.SmsManager;

import com.dolphin.sms.data.SmsRepository;

import java.util.ArrayList;

/**
 * 한글 장문(70자 초과)도 끊기지 않도록 divideMessage + sendMultipartTextMessage를 사용합니다.
 */
public class SmsSender {
    public static final String ACTION_SMS_REFRESH = "com.dolphin.sms.ACTION_SMS_REFRESH";

    public static void send(Context context, String address, String body) {
        if (address == null || address.trim().isEmpty() || body == null || body.trim().isEmpty()) {
            return;
        }
        String cleanAddress = address.trim();
        String cleanBody = body.trim();

        SmsManager smsManager = getSmsManager(context);
        ArrayList<String> parts = smsManager.divideMessage(cleanBody);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        if (parts.size() <= 1) {
            PendingIntent sentPi = PendingIntent.getBroadcast(
                    context, (int) System.currentTimeMillis(),
                    new Intent(ACTION_SMS_REFRESH).setPackage(context.getPackageName()),
                    flags
            );
            smsManager.sendTextMessage(cleanAddress, null, cleanBody, sentPi, null);
        } else {
            ArrayList<PendingIntent> sentIntents = new ArrayList<>();
            for (int i = 0; i < parts.size(); i++) {
                sentIntents.add(PendingIntent.getBroadcast(
                        context, (int) (System.currentTimeMillis() + i),
                        new Intent(ACTION_SMS_REFRESH).setPackage(context.getPackageName()),
                        flags
                ));
            }
            smsManager.sendMultipartTextMessage(cleanAddress, null, parts, sentIntents, null);
        }

        // 기본 문자 앱인 경우 시스템 DB(Sent)에 직접 저장
        if (SmsRepository.isDefaultSmsApp(context)) {
            new SmsRepository(context).insertSentSms(cleanAddress, cleanBody, false);
        }

        Intent refresh = new Intent(ACTION_SMS_REFRESH);
        refresh.setPackage(context.getPackageName());
        context.sendBroadcast(refresh);
    }

    @SuppressWarnings("deprecation")
    private static SmsManager getSmsManager(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SmsManager mgr = context.getSystemService(SmsManager.class);
            if (mgr != null) return mgr;
        }
        return SmsManager.getDefault();
    }
}
