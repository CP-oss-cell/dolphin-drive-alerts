package com.dolphin.sms.model;

public class Conversation {
    public final long threadId;
    public final String address;
    public final String displayName;
    public final String snippet;
    public final long dateMillis;
    public final int unreadCount;

    public Conversation(long threadId, String address, String displayName,
                        String snippet, long dateMillis, int unreadCount) {
        this.threadId = threadId;
        this.address = address;
        this.displayName = displayName;
        this.snippet = snippet;
        this.dateMillis = dateMillis;
        this.unreadCount = unreadCount;
    }
}
