package com.dolphin.sms.model;

import android.provider.Telephony;

public class SmsMessageItem {
    public final long id;
    public final long threadId;
    public final String address;
    public final String body;
    public final long dateMillis;
    public final int type;
    public final boolean read;

    public SmsMessageItem(long id, long threadId, String address, String body,
                          long dateMillis, int type, boolean read) {
        this.id = id;
        this.threadId = threadId;
        this.address = address;
        this.body = body;
        this.dateMillis = dateMillis;
        this.type = type;
        this.read = read;
    }

    public boolean isIncoming() {
        return type == Telephony.Sms.MESSAGE_TYPE_INBOX;
    }

    public boolean isFailed() {
        return type == Telephony.Sms.MESSAGE_TYPE_FAILED;
    }
}
