package com.dolphin.sms.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import com.dolphin.sms.data.SmsRepository;
import com.dolphin.sms.util.NotificationHelper;
import com.dolphin.sms.util.SmsSender;

import java.util.LinkedHashMap;
import java.util.Map;

public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        boolean isDefault = SmsRepository.isDefaultSmsApp(context);

        // 기본 앱일 때는 SMS_DELIVER만 처리, 기본 앱이 아닐 때는 SMS_RECEIVED로 화면 갱신
        if (Telephony.Sms.Intents.SMS_DELIVER_ACTION.equals(action) && isDefault) {
            handleIncoming(context, intent, true);
        } else if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(action) && !isDefault) {
            handleIncoming(context, intent, false);
        }
    }

    private void handleIncoming(Context context, Intent intent, boolean saveToDb) {
        SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (msgs == null || msgs.length == 0) return;

        // 분할 수신된 장문 SMS를 발신자별로 합침
        Map<String, StringBuilder> grouped = new LinkedHashMap<>();
        long timestamp = System.currentTimeMillis();
        for (SmsMessage msg : msgs) {
            String addr = msg.getDisplayOriginatingAddress();
            if (addr == null) addr = "알 수 없음";
            StringBuilder sb = grouped.get(addr);
            if (sb == null) {
                sb = new StringBuilder();
                grouped.put(addr, sb);
            }
            if (msg.getMessageBody() != null) {
                sb.append(msg.getMessageBody());
            }
            if (msg.getTimestampMillis() > 0) {
                timestamp = msg.getTimestampMillis();
            }
        }

        SmsRepository repo = new SmsRepository(context);
        for (Map.Entry<String, StringBuilder> entry : grouped.entrySet()) {
            String addr = entry.getKey();
            String body = entry.getValue().toString();
            if (saveToDb) {
                repo.insertIncomingSms(addr, body, timestamp);
                String name = repo.resolveContactName(addr);
                NotificationHelper.showIncomingSms(context, name, addr, body);
            }
        }

        Intent refresh = new Intent(SmsSender.ACTION_SMS_REFRESH);
        refresh.setPackage(context.getPackageName());
        context.sendBroadcast(refresh);
    }
}
