package com.dolphin.sms.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.dolphin.sms.R;
import com.dolphin.sms.data.SmsRepository;
import com.dolphin.sms.model.Conversation;
import com.dolphin.sms.model.SmsMessageItem;
import com.dolphin.sms.util.NotificationHelper;
import com.dolphin.sms.util.SmsSender;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    public static final String EXTRA_OPEN_ADDRESS = "extra_open_address";
    private static final String STATE_THREAD_ID = "state_thread_id";
    private static final String STATE_ADDRESS = "state_address";
    private static final String STATE_TITLE = "state_title";
    private static final int REQ_PERMISSIONS = 1001;
    private static final int REQ_DEFAULT_SMS = 1002;

    private SmsRepository repository;
    private ConversationAdapter conversationAdapter;
    private MessageAdapter messageAdapter;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private boolean isLandscape;
    private long activeThreadId = -1L;
    private String activeAddress = null;
    private String activeTitle = null;

    private View paneList;
    private View paneDetail;
    private View bannerDefaultSms;
    private EditText etSearch;
    private ListView lvConversations;
    private TextView tvEmptyList;

    private TextView tvThreadTitle;
    private TextView tvThreadSubtitle;
    private TextView tvEmptyDetail;
    private ListView lvMessages;
    private View quickReplyScroll;
    private LinearLayout quickReplyContainer;
    private View composeBar;
    private EditText etMessage;

    private final BroadcastReceiver refreshReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refreshAll();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isLandscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        repository = new SmsRepository(this);
        NotificationHelper.ensureChannel(this);

        bindViews();
        setupQuickReplies();

        if (savedInstanceState != null) {
            activeThreadId = savedInstanceState.getLong(STATE_THREAD_ID, -1L);
            activeAddress = savedInstanceState.getString(STATE_ADDRESS);
            activeTitle = savedInstanceState.getString(STATE_TITLE);
        }

        handleIncomingIntent(getIntent());
        requestNeededPermissions();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
        refreshAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDefaultSmsBanner();
        IntentFilter filter = new IntentFilter(SmsSender.ACTION_SMS_REFRESH);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(refreshReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(refreshReceiver, filter);
        }
        if (hasSmsPermissions()) {
            refreshAll();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(refreshReceiver);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(STATE_THREAD_ID, activeThreadId);
        outState.putString(STATE_ADDRESS, activeAddress);
        outState.putString(STATE_TITLE, activeTitle);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    @Override
    public void onBackPressed() {
        if (!isLandscape && paneDetail.getVisibility() == View.VISIBLE) {
            closeDetailPane();
            return;
        }
        super.onBackPressed();
    }

    private void bindViews() {
        paneList = findViewById(R.id.paneList);
        paneDetail = findViewById(R.id.paneDetail);
        bannerDefaultSms = findViewById(R.id.bannerDefaultSms);
        etSearch = findViewById(R.id.etSearch);
        lvConversations = findViewById(R.id.lvConversations);
        tvEmptyList = findViewById(R.id.tvEmptyList);

        tvThreadTitle = findViewById(R.id.tvThreadTitle);
        tvThreadSubtitle = findViewById(R.id.tvThreadSubtitle);
        tvEmptyDetail = findViewById(R.id.tvEmptyDetail);
        lvMessages = findViewById(R.id.lvMessages);
        quickReplyScroll = findViewById(R.id.quickReplyScroll);
        quickReplyContainer = findViewById(R.id.quickReplyContainer);
        composeBar = findViewById(R.id.composeBar);
        etMessage = findViewById(R.id.etMessage);

        conversationAdapter = new ConversationAdapter(this);
        messageAdapter = new MessageAdapter(this);
        lvConversations.setAdapter(conversationAdapter);
        lvMessages.setAdapter(messageAdapter);

        findViewById(R.id.btnNewMessage).setOnClickListener(v -> showNewMessageDialog(null, null));
        findViewById(R.id.btnSetDefault).setOnClickListener(v -> promptDefaultSmsApp());
        findViewById(R.id.btnBack).setOnClickListener(v -> closeDetailPane());
        findViewById(R.id.btnDeleteThread).setOnClickListener(v -> confirmDeleteActiveThread());
        findViewById(R.id.btnSend).setOnClickListener(v -> sendCurrentInput());

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                loadConversationsAsync();
            }
        });

        lvConversations.setOnItemClickListener((parent, view, position, id) -> {
            Conversation conv = conversationAdapter.getItem(position);
            openConversation(conv.threadId, conv.address, conv.displayName);
        });

        lvMessages.setOnItemLongClickListener((parent, view, position, id) -> {
            SmsMessageItem item = messageAdapter.getItem(position);
            showMessageActionDialog(item);
            return true;
        });
    }

    private void setupQuickReplies() {
        String[] replies = new String[]{
                getString(R.string.quick_reply_1),
                getString(R.string.quick_reply_2),
                getString(R.string.quick_reply_3),
                getString(R.string.quick_reply_4)
        };
        quickReplyContainer.removeAllViews();
        int padH = dp(16);
        int padV = dp(8);
        int marginEnd = dp(8);

        for (String text : replies) {
            Button chip = new Button(this);
            chip.setText(text);
            chip.setAllCaps(false);
            chip.setTextSize(14f);
            chip.setTextColor(getColor(R.color.text_primary));
            chip.setBackgroundResource(R.drawable.bg_chip);
            chip.setPadding(padH, padV, padH, padV);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    dp(42)
            );
            lp.setMarginEnd(marginEnd);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                if (activeAddress != null) {
                    sendMessageAsync(activeAddress, text);
                }
            });
            quickReplyContainer.addView(chip);
        }
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        String extraAddr = intent.getStringExtra(EXTRA_OPEN_ADDRESS);
        if (extraAddr != null && !extraAddr.trim().isEmpty()) {
            openAddressAsync(extraAddr.trim(), null);
            return;
        }
        String action = intent.getAction();
        if (Intent.ACTION_SENDTO.equals(action) || Intent.ACTION_SEND.equals(action)) {
            Uri data = intent.getData();
            String recipient = data != null ? data.getSchemeSpecificPart() : null;
            String body = intent.getStringExtra("sms_body");
            if (body == null) body = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (recipient != null && !recipient.trim().isEmpty()) {
                openAddressAsync(recipient.trim(), body);
            } else if (body != null) {
                showNewMessageDialog("", body);
            }
        }
    }

    private void openAddressAsync(String address, String prefillBody) {
        executor.execute(() -> {
            long tid = repository.findThreadIdByAddress(address);
            String name = repository.resolveContactName(address);
            mainHandler.post(() -> {
                if (tid >= 0) {
                    openConversation(tid, address, name);
                    if (prefillBody != null) etMessage.setText(prefillBody);
                } else {
                    showNewMessageDialog(address, prefillBody);
                }
            });
        });
    }

    private void openConversation(long threadId, String address, String title) {
        activeThreadId = threadId;
        activeAddress = address;
        activeTitle = title != null ? title : SmsRepository.formatPhone(address);

        conversationAdapter.setSelectedThreadId(threadId);
        tvThreadTitle.setText(activeTitle);
        tvThreadSubtitle.setText(SmsRepository.formatPhone(address));

        if (!isLandscape) {
            paneList.setVisibility(View.GONE);
            paneDetail.setVisibility(View.VISIBLE);
        }
        tvEmptyDetail.setVisibility(View.GONE);
        lvMessages.setVisibility(View.VISIBLE);
        quickReplyScroll.setVisibility(View.VISIBLE);
        composeBar.setVisibility(View.VISIBLE);

        executor.execute(() -> {
            repository.markThreadAsRead(threadId);
            List<SmsMessageItem> msgs = repository.loadMessages(threadId);
            mainHandler.post(() -> {
                messageAdapter.setItems(msgs);
                if (!msgs.isEmpty()) {
                    lvMessages.setSelection(msgs.size() - 1);
                }
                loadConversationsAsync();
            });
        });
    }

    private void closeDetailPane() {
        activeThreadId = -1L;
        activeAddress = null;
        activeTitle = null;
        conversationAdapter.setSelectedThreadId(-1L);

        if (!isLandscape) {
            paneDetail.setVisibility(View.GONE);
            paneList.setVisibility(View.VISIBLE);
        } else {
            tvThreadTitle.setText("");
            tvThreadSubtitle.setText("");
            tvEmptyDetail.setVisibility(View.VISIBLE);
            lvMessages.setVisibility(View.GONE);
            quickReplyScroll.setVisibility(View.GONE);
            composeBar.setVisibility(View.GONE);
        }
    }

    private void refreshAll() {
        loadConversationsAsync();
        if (activeThreadId >= 0) {
            openConversation(activeThreadId, activeAddress, activeTitle);
        } else if (isLandscape) {
            closeDetailPane();
        }
    }

    private void loadConversationsAsync() {
        if (!hasSmsPermissions()) return;
        String query = etSearch.getText().toString();
        executor.execute(() -> {
            List<Conversation> list = repository.loadConversations(query);
            mainHandler.post(() -> {
                conversationAdapter.setItems(list);
                tvEmptyList.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                lvConversations.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
            });
        });
    }

    private void sendCurrentInput() {
        if (activeAddress == null) return;
        String text = etMessage.getText().toString().trim();
        if (text.isEmpty()) return;
        etMessage.setText("");
        sendMessageAsync(activeAddress, text);
    }

    private void sendMessageAsync(String address, String body) {
        executor.execute(() -> {
            try {
                SmsSender.send(this, address, body);
                long tid = repository.findThreadIdByAddress(address);
                String name = repository.resolveContactName(address);
                mainHandler.post(() -> {
                    Toast.makeText(this, R.string.sent_ok, Toast.LENGTH_SHORT).show();
                    if (tid >= 0) {
                        openConversation(tid, address, name);
                    } else {
                        loadConversationsAsync();
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() ->
                        Toast.makeText(this, R.string.sent_fail, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showNewMessageDialog(String prefillRecipient, String prefillBody) {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_new_message, null);
        EditText etRec = view.findViewById(R.id.etNewRecipient);
        EditText etBody = view.findViewById(R.id.etNewBody);
        if (prefillRecipient != null) etRec.setText(prefillRecipient);
        if (prefillBody != null) etBody.setText(prefillBody);

        new AlertDialog.Builder(this)
                .setTitle(R.string.new_message)
                .setView(view)
                .setPositiveButton(R.string.send, (d, which) -> {
                    String rec = etRec.getText().toString().trim();
                    String msg = etBody.getText().toString().trim();
                    if (!rec.isEmpty() && !msg.isEmpty()) {
                        sendMessageAsync(rec, msg);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showMessageActionDialog(SmsMessageItem item) {
        String[] actions = new String[]{getString(R.string.copy), getString(R.string.delete)};
        new AlertDialog.Builder(this)
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) {
                            cm.setPrimaryClip(ClipData.newPlainText("sms", item.body));
                            Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (!SmsRepository.isDefaultSmsApp(this)) {
                            Toast.makeText(this, R.string.not_default_delete_notice, Toast.LENGTH_SHORT).show();
                            return;
                        }
                        executor.execute(() -> {
                            repository.deleteMessage(item.id);
                            mainHandler.post(this::refreshAll);
                        });
                    }
                })
                .show();
    }

    private void confirmDeleteActiveThread() {
        if (activeThreadId < 0) return;
        if (!SmsRepository.isDefaultSmsApp(this)) {
            Toast.makeText(this, R.string.not_default_delete_notice, Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(R.string.delete_confirm_msg)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    long target = activeThreadId;
                    executor.execute(() -> {
                        repository.deleteThread(target);
                        mainHandler.post(() -> {
                            closeDetailPane();
                            loadConversationsAsync();
                        });
                    });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void updateDefaultSmsBanner() {
        boolean isDefault = SmsRepository.isDefaultSmsApp(this);
        bannerDefaultSms.setVisibility(isDefault ? View.GONE : View.VISIBLE);
    }

    private void promptDefaultSmsApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS)) {
                Intent intent = rm.createRequestRoleIntent(RoleManager.ROLE_SMS);
                startActivityForResult(intent, REQ_DEFAULT_SMS);
                return;
            }
        }
        Intent intent = new Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT);
        intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, getPackageName());
        startActivityForResult(intent, REQ_DEFAULT_SMS);
    }

    private boolean hasSmsPermissions() {
        return checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        List<String> needed = new ArrayList<>();
        String[] base = new String[]{
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.READ_CONTACTS
        };
        for (String p : base) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                needed.add(p);
            }
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMISSIONS) {
            if (hasSmsPermissions()) {
                refreshAll();
            } else {
                Toast.makeText(this, R.string.permission_needed, Toast.LENGTH_LONG).show();
            }
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
