package com.dolphin.sms.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Android 기본 문자 앱 등록 요건을 충족하기 위한 최소 MMS 리시버입니다.
 */
public class MmsReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // 순수 SMS 전용 경량 앱이므로 MMS 페이로드 처리는 생략합니다.
    }
}
