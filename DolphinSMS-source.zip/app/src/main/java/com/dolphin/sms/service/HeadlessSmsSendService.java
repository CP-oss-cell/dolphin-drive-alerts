package com.dolphin.sms.service;

import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;

import com.dolphin.sms.util.SmsSender;

/**
 * Android 기본 문자 앱 등록 요건(전화 수신 중 빠른 문자 답장)을 위한 서비스입니다.
 */
public class HeadlessSmsSendService extends Service {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "android.intent.action.RESPOND_VIA_MESSAGE".equals(intent.getAction())) {
            Uri uri = intent.getData();
            String body = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (uri != null && body != null && !body.trim().isEmpty()) {
                String recipient = uri.getSchemeSpecificPart();
                if (recipient != null && !recipient.trim().isEmpty()) {
                    SmsSender.send(this, recipient, body);
                }
            }
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
