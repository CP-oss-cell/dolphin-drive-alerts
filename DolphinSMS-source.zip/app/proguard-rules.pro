# 순수 Android Framework 기반 앱이므로 별도 서드파티 Keep 규칙이 필요 없습니다.
-keep public class * extends android.app.Activity
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Service
