# 돌핀 문자 (DolphinSMS)

BYD 돌핀(DiLink 안드로이드 인포테인먼트)에서 가볍고 쾌적하게 사용할 수 있도록 만든 **광고 0%, 인터넷 권한 0%, 외부 라이브러리 0개** 순수 문자메시지(SMS) 앱입니다.

## 핵심 특징
- **초경량 용량**: 외부 SDK(AdMob, Meta Audience Network, Firebase, AndroidX 등)를 전혀 쓰지 않고 순수 Android Framework API만으로 작성되어, 릴리즈 APK 빌드 시 **약 100~200KB** 수준으로 완성됩니다. (기존 `#Messages` 39MB 대비 99% 이상 절감)
- **광고·추적 원천 차단**: `INTERNET`, `AD_ID` 권한 자체가 없어 네트워크 통신이나 광고 로딩이 불가능합니다.
- **BYD 돌핀 10.1인치 회전 화면 최적화**:
  - **가로 모드**: 왼쪽(38%) 대화 목록 + 오른쪽(62%) 메시지 창 2분할 레이아웃
  - **세로 모드**: 화면 회전 시 단일 화면 자동 전환
  - **차량용 다크 테마 & 큰 터치 영역**: 주야간 시인성이 좋은 다크 UI, 18sp 이상 큰 글씨, 48~54dp 대형 버튼
  - **원터치 빠른 답장**: "운전 중입니다. 잠시 후 연락드릴게요." 등 4종 즉시 전송 버튼
- **한글 장문(LMS 분할) 지원**: 70자가 넘는 한글 문자도 `sendMultipartTextMessage`로 끊김 없이 전송합니다.

---

## 방법 1. Android Studio 없이 GitHub에서 2분 만에 APK 받기 (가장 쉬움)
1. GitHub에 새 저장소(Private 권장)를 만들고 이 압축을 푼 폴더 전체(`.github` 폴더 포함)를 업로드합니다.
2. GitHub 저장소 상단의 **Actions** 탭 → **Build DolphinSMS APK** 실행(자동 실행되거나 `Run workflow` 클릭).
3. 약 1~2분 뒤 완료되면 하단 **Artifacts → `DolphinSMS-APK`** 를 눌러 `app-release.apk`를 다운로드합니다.

## 방법 2. PC(Android Studio)에서 직접 APK 빌드하기
1. Android Studio에서 이 폴더(`DolphinSMS`)를 엽니다.
2. Gradle 동기화 완료 후 상단 메뉴 **Build → Build Bundle(s) / APK(s) → Build APK(s)** 클릭(또는 터미널에서 `gradle assembleRelease` 실행).
3. `app/build/outputs/apk/release/app-release.apk` 파일을 복사합니다.

## BYD 돌핀에 설치 및 설정
1. 생성된 `app-release.apk`를 USB 메모리(또는 무선 ADB / Bugjaeger 등)로 BYD 돌핀에 설치합니다.
2. 앱을 실행하고 문자·연락처·알림 권한을 허용합니다.
3. 문자 삭제 및 읽음 처리 기능까지 사용하려면 상단의 **기본 문자 앱 설정** 버튼을 눌러 `돌핀 문자`를 기본 SMS 앱으로 지정합니다.
