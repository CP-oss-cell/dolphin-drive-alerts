# Dolphin Drive Alerts v0.17.30 — 10/22 실차 PCM 검출 동기화 및 잘못된 NORMAL 근거 제거

## 근거
- `DolphinDriveLogs_20261022_074825_001_3e60a631.zip`: 49개 ZIP 멤버/48개 증거 SHA 통과.
- MCon K UID10131 스캔은 07:49:07~07:49:20, 실제 PCM 비영 최초 07:51:52. 기존 3/8/15초의 `primary navi` 활성 0은 길안내 시점의 진단이 아님.
- `0x34500030`은 `SET_ELECTRIC_RANGE`(155~168), ECO/NORMAL/SPORT 제3원천값 302/311/310이 아님. `0x26100008` 알림값 363·364·365만으로 NORMAL 단독 발화 금지.
- BSD 기존 1+2 음성 및 3번 즉시 경고, 두 앱 분할, 운전석 stream14 본 앱 출력, 기존 9개 메뉴는 보존.

## 실제 소스 수정
1. `NavPlaybackCaptureRelayService.kt`: 허가된 5종 UID의 **첫 nonzero PCM**이 발생하면 기록 상태 확인 후 `SystemDiagnosticsCollector.captureNavAudioOnset(pkg, uid)`를 정확히 한 번 비동기로 요청. `uid_relay_status.log`에 첫 PCM 시각·UID·수집 요청 상태 기록. PCM WAV/바이트 원본 저장하지 않음. 캡처값은 실제 길안내 음원 또는 단독 운전석 출력의 증거가 아님.
2. `SystemDiagnosticsCollector.kt`: NAV_PCM_ONSET_<pkg>_<uid> 진단 폴더에 `dumpsys audio`, `dumpsys media.audio_policy`, `dumpsys media.audio_flinger` 읽기 전용 스냅샷. `requestedAtMs`를 저장하고 기존 통합 ZIP의 세션 시간/종료 대기 로직을 그대로 사용해 ZIP에 포함. ADB 접근 불가 시 각 결과 헤더에 실패로 보존.
3. `InstrumentDriveModeGate.kt` + `ReferenceVehicleEventBridge.kt`: 잘못된 instrument+electric-range 교차검증 및 그 근거의 음성 발화를 제거. 363·364·365는 **UNVERIFIED**, 주행가능거리는 **EXCLUDED**로 로그에만 기록. 별도 SDK energy 콜백(기존 ECO/SPORT) 및 실차 교정 모드는 건드리지 않음. NORMAL은 미해결.
4. 검증: 오래된 v0.17.27 검사에서 10/18 시점 우연 상관을 정상 3모드 인식 성공으로 보는 테스트를 폐기하고 10/22 실제 주행가능거리 raw 155~168 기준 실패 차단 검사로 교정. v0.17.30 전용 자동 진단·무신호 발화 방지 검사 추가. 메인 9개 메뉴 검사 버전 정규식 갱신.

## 완료와 미완료 엄격 구분
- 소스 변경/정적 검증과 BYD 콜백 Kotlin 호환 검사는 통과. CI APK 전체 Gradle 컴파일 및 신규 차량 실차 자동 스냅샷은 미확인.
- 기존 실차에서 성공한 ZIP 49개 무결성 결과는 **v0.17.29** 검증이며, v0.17.30 실차 증거가 아님.
- 내비 5종 **운전석 단독 출력 미구현/미확인**: 기존 Android 10 캡처+stream14 출력은 MEDIA 원본을 차단하지 않음. 전체 미디어 mute, 타 UID 라우팅 쓰기, BYD AudioService write는 시행하지 않음.
- NORMAL 정확 발화, BSD 위험 방향 좌우 구분, 2분할 비율 변경, 외부 AVAS 사용자 음성 출력은 전부 미해결. 구현/검증 혼동 금지.
- 실차 P단 안전 환경에서 내비를 선택하고 사용자 승인을 한 뒤 `수집 시작` → 기존 내비 오디오 릴레이 시험 → PCM 첫 입력 발생 → `수집 종료` → ZIP 공유. 새 메뉴 없음.
