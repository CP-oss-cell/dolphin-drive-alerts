package com.byd.dolphin.drivealerts.vehicle

/**
 * Passive 2602 display-code observer, NOT a drive-mode decoder.
 * 2026-10-22 real car evidence disproved the second input: 0x34500030 is
 * SET_ELECTRIC_RANGE (155..168), not an independent three-mode confirmation.
 * 0x26100008 is INSTRUMENT_DD_FAULT_NOTICE_261; 363/364/365 are only candidates.
 * No speech may ever be emitted solely from either of these two events.
 */
internal class InstrumentDriveModeGate {
    data class Candidate(val raw: Int, val priorHypothesis: String, val observedAtMs: Long)
    private var previousDisplayRaw: Int? = null
    private var previousRangeRaw: Int? = null

    fun reset() { previousDisplayRaw = null; previousRangeRaw = null }

    /** Returns a candidate for DIAGNOSTIC LOGGING ONLY, never a mode alert. */
    fun observeDisplayCode(raw: Int, now: Long): Candidate? {
        val priorHypothesis = when (raw) {
            363 -> "ECO_UNVERIFIED"
            364 -> "NORMAL_UNVERIFIED"
            365 -> "SPORT_UNVERIFIED"
            else -> return null
        }
        if (previousDisplayRaw == raw) return null
        previousDisplayRaw = raw
        return Candidate(raw, priorHypothesis, now)
    }

    /** Vehicle setting value is electric range, not an operation-mode signal. */
    fun observeElectricRange(raw: Int): Boolean {
        if (previousRangeRaw == raw) return false
        previousRangeRaw = raw
        return true
    }
}
