package com.byd.dolphin.drivealerts.automation

import kotlin.math.roundToInt

/** DiLink/Android 10 stack geometry from TWO named split stacks, never arbitrary task bounds. */
internal object SplitGeometry {
    data class Rect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        fun args(): String = "$left $top $right $bottom"
        val width: Int get() = right-left
        val height: Int get() = bottom-top
    }
    data class PairBounds(val primary: Rect, val secondary: Rect)
    data class Resize(val command: String, val axis: String, val fourArgCommand: String)
    private val rect = Regex("""(?i)(?:mBounds|bounds)=\[(-?\d+),\s*(-?\d+)\]\[(-?\d+),\s*(-?\d+)\]""")
    private val androidRect = Regex("""(?i)(?:mBounds|bounds)=Rect\((-?\d+),\s*(-?\d+)\s*-\s*(-?\d+),\s*(-?\d+)\)""")
    private val stackHeader = Regex("""(?i)^(?:(?:Root)?Stack\s+id\s*=\s*|(?:Root)?Stack\s+#)(\d+)\b""")

    private data class StackRecord(var mode: Int? = null, var bounds: Rect? = null)
    /** [stackList] often has bounds but no mode; [activities] often has mode but no bounds. */
    fun parse(stackList: String, activities: String = ""): PairBounds? {
        val byId = linkedMapOf<Int, StackRecord>()
        for (raw in listOf(stackList, activities)) {
            var current: Int? = null
            var taskSection = false
            raw.lineSequence().forEach { line0 ->
                val line=line0.trim()
                stackHeader.find(line)?.let { match ->
                    current=match.groupValues[1].toIntOrNull()
                    taskSection=false
                    if(current!=null) byId.getOrPut(current!!) { StackRecord() }
                }
                val id=current ?: return@forEach
                val item=byId.getOrPut(id) { StackRecord() }
                if (!taskSection) {
                    val mode = when {
                        line.contains("split-screen-primary",true) -> 3
                        line.contains("split-screen-secondary",true) -> 4
                        else -> Regex("""(?i)\b(?:mWindowingMode|windowingMode|mode)\s*[=:]\s*([34])\b""")
                            .find(line)?.groupValues?.get(1)?.toIntOrNull()
                    }
                    if (mode!=null) item.mode=mode
                    // Do not mistake nested Task / Activity bounds for the parent stack bounds.
                    if (item.bounds==null) {
                        val m = rect.find(line) ?: androidRect.find(line)
                        if(m!=null) {
                            val a=m.groupValues.drop(1).map { it.toInt() }
                            val value=Rect(a[0],a[1],a[2],a[3])
                            if(value.width>0 && value.height>0) item.bounds=value
                        }
                    }
                }
                if (line.startsWith("Task{",true) || line.startsWith("TaskRecord{",true) ||
                    line.startsWith("Task #",true) || line.startsWith("RootTask{",true)) taskSection=true
            }
        }
        val primaries=byId.values.filter { it.mode==3 && it.bounds!=null }
        val secondaries=byId.values.filter { it.mode==4 && it.bounds!=null }
        if(primaries.size!=1 || secondaries.size!=1) return null
        val pair=PairBounds(primaries.single().bounds!!,secondaries.single().bounds!!)
        return if(percent(pair)!=null) pair else null
    }

    /** Percentage of usable split space. Divider width is excluded. */
    fun percent(pair: PairBounds): Int? {
        val p=pair.primary; val s=pair.secondary
        return when {
            p.top==s.top && p.bottom==s.bottom && (p.right<=s.left || s.right<=p.left) ->
                (p.width*100f/(p.width+s.width).coerceAtLeast(1)).roundToInt()
            p.left==s.left && p.right==s.right && (p.bottom<=s.top || s.bottom<=p.top) ->
                (p.height*100f/(p.height+s.height).coerceAtLeast(1)).roundToInt()
            else -> null
        }
    }

    fun resize(pair: PairBounds, requested: Int): Resize? {
        val p=pair.primary; val s=pair.secondary
        val ratio=requested.coerceIn(10,90)
        val target: Rect
        val axis: String
        if (p.top==s.top && p.bottom==s.bottom && (p.right<=s.left || s.right<=p.left)) {
            axis="X"
            val usable=p.width+s.width
            val amount=(usable*ratio/100f).roundToInt()
            target=if(p.right<=s.left) Rect(p.left,p.top,p.left+amount,p.bottom)
                   else Rect(p.right-amount,p.top,p.right,p.bottom)
        } else if(p.left==s.left && p.right==s.right && (p.bottom<=s.top || s.bottom<=p.top)) {
            axis="Y"
            val usable=p.height+s.height
            val amount=(usable*ratio/100f).roundToInt()
            target=if(p.bottom<=s.top) Rect(p.left,p.top,p.right,p.top+amount)
                   else Rect(p.left,p.bottom-amount,p.right,p.bottom)
        } else return null
        // Android 10 legacy shell supports a docked rect and an optional task rect; use both (8 coordinates).
        val args=target.args()
        return Resize("am stack resize-docked-stack $args $args",axis,"am stack resize-docked-stack $args")
    }
}
