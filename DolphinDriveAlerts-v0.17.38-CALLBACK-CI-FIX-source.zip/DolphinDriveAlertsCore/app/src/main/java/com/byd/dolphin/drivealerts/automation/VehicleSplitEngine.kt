package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.util.CoreLog

/** Independent best-effort system split implementation. OEM stack commands require local ADB. */
object VehicleSplitEngine {
    data class Result(val success: Boolean, val message: String)
    private fun shell(c: Context, command: String): NativeAdbClient.ShellResult =
        if (command.startsWith("wm size") || command.startsWith("am stack list") || command.startsWith("am help") || command.startsWith("cmd activity help") || command.startsWith("dumpsys "))
            AuthorizedAdbRuntime.read(c,command,timeoutMs=4_000).result
        else AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=4_000).result

    /** Read-only platform diagnostics. No unverified 3/4-way or popup commands are sent. */
    fun capabilities(c: Context): String {
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY)
            return "로컬 ADB 상태=${adb.state}; 분할 실행 권한과 별개로 확인 필요"
        val help = shell(c, "am help")
        val current = shell(c, "dumpsys activity activities")
        val activity = shell(c, "cmd activity help")
        val legacy = shell(c, "am stack list")
        val windowing = help.output.contains("windowingMode", ignoreCase = true) ||
            help.output.contains("windowing-mode", ignoreCase = true)
        val splitVisible = current.output.contains("split-screen", ignoreCase = true) ||
            Regex("(?i)windowingMode[=:]\\s*[34]").containsMatchIn(current.output)
        val resizeLegacy = activity.output.contains("resize-docked-stack", ignoreCase = true) ||
            legacy.output.contains("docked", ignoreCase = true)
        return "adb=READY;amStartWindowingOption=$windowing;activeSplitState=$splitVisible;" +
            "legacyResizeHint=$resizeLegacy;activityRead=${current.success};" +
            "3분할/4분할/멀티팝업=지원 확인 불가(OEM 태스크 관리자 기능 별도 검증 필요)"
    }

    fun launch(c: Context, profile: SplitProfile): Result {
        val one = AppSelection.safeComponent(c,profile.firstPackage) ?: return Result(false,"첫 번째 앱을 찾을 수 없음")
        val two = AppSelection.safeComponent(c,profile.secondPackage) ?: return Result(false,"두 번째 앱을 찾을 수 없음")
        if (one == two) return Result(false,"서로 다른 앱 2개를 선택해야 합니다")
        if (profile.firstPackage == c.packageName || profile.secondPackage == c.packageName)
            return Result(false,"Dolphin Drive 자신이 분할 대상에 포함된 프로필입니다. 앱 2개를 다시 선택하세요")
        // Never force the split stack while an OEM reverse/360-camera activity is foreground.
        val foreground = screenToken(c).orEmpty()
        if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground))
            return Result(false,"차량 카메라 화면 표시 중: 카메라 종료 후 분할을 실행합니다")
        val adb = AuthorizedAdbRuntime.health(c)
        if (adb.state != AuthorizedAdbRuntime.State.READY)
            return Result(false, "로컬 ADB 미준비(${adb.state}): 차량 ADB 포트/RSA 최초 승인을 확인하세요. " +
                "설치 앱 권한 부여 성공과 분할 셸 권한은 서로 다릅니다.")
        val requestId = java.util.UUID.randomUUID().toString().take(8)
        CoreLog.i("SPLIT", "SPLIT_REQUEST id=$requestId adbReady=true first=${profile.firstPackage} " +
            "second=${profile.secondPackage} pct=${profile.primaryPercent}")
        val before = shell(c, "dumpsys activity activities")
        CoreLog.i("SPLIT", "SPLIT_BEFORE id=$requestId state=${before.output.take(1200)}")
        // The Assistant v30 / AutoSplit reference first moves any EXISTING primary task into
        // a temporarily claimed split-primary stack. A second normal am-start does not do this.
        fun snapshot() = shell(c, "dumpsys activity activities")
        fun task(pkg: String): LegacySplitTaskLocator.State =
            LegacySplitTaskLocator.findTask(snapshot().output, pkg)
        fun cmd(command: String, label: String): Boolean {
            val result = AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=9_000L).result
            CoreLog.i("SPLIT", "$label id=$requestId command=$command exit=${result.exitCode} " +
                "message=${result.message} output=${result.output.take(950)}")
            return result.success
        }
        fun awaitMode(pkg: String, mode: Int, label: String, marker: String? = null): LegacySplitTaskLocator.State? {
            repeat(12) { n ->
                Thread.sleep(250L)
                val state = LegacySplitTaskLocator.findTask(snapshot().output,pkg,marker)
                CoreLog.i("SPLIT", "$label id=$requestId poll=$n task=${state.taskId} stack=${state.stackId} mode=${state.mode}")
                if (state.found && state.mode==mode) return state
            }
            return null
        }
        fun startInMode(component: String, pkg: String, mode: Int, label: String): Boolean =
            cmd("am start --user 0 --windowingMode $mode -n '$component'",label) &&
                awaitMode(pkg,mode,label)!=null

        val existingPrimary=task(profile.firstPackage)
        var primaryReady=existingPrimary.found && existingPrimary.mode==3
        if (existingPrimary.found && !primaryReady) {
            val ghost="${c.packageName}/.automation.SplitGhostActivity"
            if (cmd("am start --user 0 --windowingMode 3 -n '$ghost'","PRIMARY_GHOST")) {
                val ghostTask=awaitMode(c.packageName,3,"GHOST_READY","SplitGhostActivity")
                val currentPrimary=task(profile.firstPackage)
                if (ghostTask!=null && currentPrimary.found &&
                    cmd("am stack move-task ${currentPrimary.taskId} ${ghostTask.stackId} true","PRIMARY_MOVE"))
                    primaryReady=awaitMode(profile.firstPackage,3,"PRIMARY_MOVED")!=null
            }
        }
        if (!primaryReady) {
            primaryReady=startInMode(one,profile.firstPackage,3,"PRIMARY_COLD") ||
                startInMode(one,profile.firstPackage,3,"PRIMARY_COLD_RETRY")
        }
        if (!primaryReady) return Result(false,"첫 번째 앱 Task를 split-primary로 이동하지 못했습니다")

        var secondaryReady=task(profile.secondPackage).let { it.found && it.mode==4 }
        if (!secondaryReady) secondaryReady=startInMode(two,profile.secondPackage,4,"SECONDARY_START")
        if (!secondaryReady) {
            val state=task(profile.secondPackage)
            val stack=LegacySplitTaskLocator.findStack(snapshot().output,4)
            if (state.found && stack>=0 &&
                cmd("am stack move-task ${state.taskId} $stack true","SECONDARY_MOVE"))
                secondaryReady=awaitMode(profile.secondPackage,4,"SECONDARY_MOVED")!=null
        }
        if (!secondaryReady) secondaryReady=startInMode(two,profile.secondPackage,4,"SECONDARY_RETRY")
        if (!secondaryReady) return Result(false,"두 번째 앱 Task를 split-secondary로 이동하지 못했습니다")
        // Require separate selected Task IDs; the ghost/Drive Alerts task must not own the right pane.
        val primaryTask=task(profile.firstPackage)
        val secondaryTask=task(profile.secondPackage)
        if (!primaryTask.found || !secondaryTask.found || primaryTask.taskId==secondaryTask.taskId ||
            primaryTask.mode!=3 || secondaryTask.mode!=4)
            return Result(false,"Task 소유권 또는 모드 불일치 primary=$primaryTask secondary=$secondaryTask")
        val ownership=snapshot()
        val taskEvidence=SplitTaskReadback.inspect(ownership.output,profile.firstPackage,profile.secondPackage)
        CoreLog.i("SPLIT","SPLIT_TASK_READBACK id=$requestId first=$primaryTask second=$secondaryTask " +
            "strict=${taskEvidence.verified} ${taskEvidence.detail}")
        // Legacy task parser is the authoritative Android 10 source; the modern summary parser
        // may be inconclusive but a definitive shared-task mismatch is still disqualifying.
        if (taskEvidence.hasDefinitiveMismatch)
            return Result(false,"분할 Task 충돌: ${taskEvidence.detail}")
        FeatureProfiles.markSplit(c,profile.id)
        val ratio = applyRatio(c,profile.primaryPercent)
        if (!ratio.success) {
            CoreLog.w("SPLIT_RATIO","TWO_APPS_VERIFIED_RATIO_NOT_VERIFIED id=$requestId ${ratio.message}")
            // Two tasks must not be destroyed simply because the divider resize is unsupported.
            return Result(true,"두 앱 분할은 성공했지만 비율은 미적용: ${ratio.message}")
        }
        // Launcher V1 requires post-action readback; a verified ratio by itself
        // does NOT prove that the two selected apps still own separate Tasks.
        val postRatioSnapshot=snapshot()
        val postPrimary=LegacySplitTaskLocator.findTask(postRatioSnapshot.output,profile.firstPackage)
        val postSecondary=LegacySplitTaskLocator.findTask(postRatioSnapshot.output,profile.secondPackage)
        CoreLog.i("SPLIT", "SPLIT_POST_RATIO_TASKS id=$requestId primary=$postPrimary secondary=$postSecondary")
        if (!postPrimary.found || !postSecondary.found ||
            postPrimary.mode!=3 || postSecondary.mode!=4 ||
            postPrimary.taskId==postSecondary.taskId ||
            postPrimary.stackId==postSecondary.stackId) {
            return Result(false,"비율 변경 후 분할 Task 소유권 검증 실패; 앱2가 교체되었을 수 있습니다")
        }
        FeatureProfiles.markSplit(c,profile.id)
        CoreLog.i("SPLIT", "SPLIT_SUCCESS id=$requestId profile=${profile.id} " +
            "ratio=${profile.primaryPercent} evidence=${taskEvidence.detail}")
        return Result(true,"비율 bounds 확인; 앱별 창 분할 상태=${taskEvidence.detail}. 실차 표시 최종 확인 필요")
    }

    /** Ratio updates only the existing split; never relaunches either app. */
    fun applyRatio(c: Context, pct: Int): Result {
        if (pct !in 10..90) return Result(false,"지원 범위를 벗어난 비율 요청: $pct")
        val foreground=screenToken(c).orEmpty()
        if (Regex("(?i)(camera|surroundview|\\bavm\\b|com\\.byd\\.cdr)").containsMatchIn(foreground))
            return Result(false,"카메라 화면 표시 중: 비율 변경 보류")
        fun measure(tag: String): SplitGeometry.PairBounds? {
            val stacks=shell(c,"am stack list")
            val tasks=shell(c,"dumpsys activity activities")
            val source=if(stacks.success) stacks.output else ""
            val reference=ReferenceAutoSplitRatio.parse(source)
            val strict=SplitGeometry.parse(source,if(tasks.success)tasks.output else "")
            val pair=reference ?: strict
            CoreLog.i("SPLIT_RATIO", "RATIO_READBACK strategy=${if(reference!=null) "REFERENCE_AUTOSPLIT" else "STRICT_FALLBACK"} stage=$tag stackExit=${stacks.exitCode} " +
                "taskExit=${tasks.exitCode} pair=$pair percent=${pair?.let(SplitGeometry::percent)} " +
                "stacks=${stacks.output.take(1100)} activities=${tasks.output.take(1100)}")
            return pair
        }
        val bounds=measure("BEFORE")
            ?: return Result(false,"분할 창 크기 조회 실패: am stack list/dumpsys 스택 ID·mode·bounds 확인 필요 (로그 SPLIT_RATIO)")
        val original=SplitGeometry.percent(bounds)
            ?: return Result(false,"두 앱 창의 분할 방향이 확인되지 않았습니다")
        if (kotlin.math.abs(original-pct)<=2) return Result(true,"분할 비율 이미 ${original}:${100-original}")
        val resize=SplitGeometry.resize(bounds,pct)
            ?: return Result(false,"두 분할 창의 경계가 일치하지 않습니다")
        fun verify(label: String): Int? {
            repeat(4) { index ->
                try { Thread.sleep(300L) } catch (_: InterruptedException) { Thread.currentThread().interrupt();return null }
                val observed=measure("$label.$index")?.let(SplitGeometry::percent)
                CoreLog.i("SPLIT_RATIO", "RATIO_OBSERVED attempt=$label desired=$pct observed=$observed old=$original")
                if (observed!=null && kotlin.math.abs(observed-pct)<=3) return observed
            }
            return null
        }
        // Original AutoSplit issues the 8-number two-Rect command via the authorized local ADB.
        // AOSP Android 10 does NOT accept the previous four-number fallback.
        val command=resize.command
        for (attempt in 1..2) {
            val result=AuthorizedAdbRuntime.writeOnce(c,command,timeoutMs=9_000L).result
            val accepted=result.success && !result.output.contains("Error:",ignoreCase=true) &&
                !result.output.contains("invalid input bounds",ignoreCase=true)
            CoreLog.i("SPLIT_RATIO", "RATIO_COMMAND attempt=$attempt/2 requested=$pct axis=${resize.axis} " +
                "command=$command exit=${result.exitCode} accepted=$accepted " +
                "output=${result.output.take(800)} message=${result.message}")
            if(accepted) {
                val observed=verify("AFTER_$attempt")
                if(observed!=null)return Result(true,"비율 적용 확인: ${observed}:${100-observed}")
                // No blind retry if command was accepted but geometry did not change.
                break
            }
            if(attempt==1 && AuthorizedAdbRuntime.health(c).state != AuthorizedAdbRuntime.State.READY)break
        }
        val after=measure("FINAL")?.let(SplitGeometry::percent)
        return Result(false,"비율 요청 ${pct}:${100-pct} 미적용; 실제 ${after?.let { "$it:${100-it}" } ?: "조회 실패"}. " +
            "분할 앱은 유지하고 SPLIT_RATIO 로그에 명령/원인 기록")
    }

    /** Older DiLink exposes `am stack list`; newer Android may require dumpsys. */
    private fun splitState(c: Context): NativeAdbClient.ShellResult {
        val legacy = shell(c, "am stack list")
        if (legacy.success && (legacy.output.contains("docked",true) ||
            legacy.output.contains("split-screen",true) || legacy.output.contains("windowingMode",true))) return legacy
        val fallback = shell(c, "dumpsys activity activities")
        if (fallback.success) CoreLog.i("SPLIT", "using dumpsys activity split state fallback")
        return if (fallback.success) fallback else legacy
    }

    fun screenToken(c: Context): String? {
        val s = shell(c,"dumpsys activity activities")
        if (!s.success) return null
        val top = s.output.lineSequence().filter {
            it.contains("topResumedActivity",true) || it.contains("mResumedActivity",true) || it.contains("ResumedActivity",true)
        }.lastOrNull() ?: return null
        return top.take(350)
    }
}
