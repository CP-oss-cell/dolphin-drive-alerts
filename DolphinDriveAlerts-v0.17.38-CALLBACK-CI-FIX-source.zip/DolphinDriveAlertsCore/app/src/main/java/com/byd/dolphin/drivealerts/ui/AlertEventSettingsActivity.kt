package com.byd.dolphin.drivealerts.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.dpi.DensityAwareActivity
import com.byd.dolphin.drivealerts.model.AlertEventCatalog

/** 23 live audio preference toggles; records signal availability honestly. */
class AlertEventSettingsActivity : DensityAwareActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 32)
        }
        scroll.addView(root)
        setContentView(scroll)
        fun label(text: String, size: Float = 14f): TextView = TextView(this).apply {
            this.text = text; textSize = size; setPadding(0, 8, 0, 8)
        }
        root.addView(label("23종 주행 알림 · 개별 설정", 22f))
        root.addView(label("각 항목 ON은 알림 소리를 허용하는 설정일 뿐, 차량에서 신호가 검출되거나 실차 동작이 확정됐다는 뜻이 아닙니다. 꺼도 BYD 순정 경고와 신호 기록은 유지됩니다."))
        root.addView(label("전체 음성 ON/OFF는 주행 알림 메인 메뉴에서 설정합니다. 기존 모든 항목은 업데이트 후 기본 ON입니다."))
        val groups = AlertEventCatalog.entries.groupBy { it.group }
        for ((group, entries) in groups) {
            root.addView(label(group, 18f))
            for (entry in entries) {
                val cb = CheckBox(this).apply {
                    text = entry.event.phrase + " · " + AlertEventCatalog.evidenceKorean(entry.evidence)
                    textSize = 14f
                    isChecked = AlertPreferences.eventEnabled(this@AlertEventSettingsActivity, entry.event)
                    setOnCheckedChangeListener { button, enabled ->
                        if (!AlertPreferences.setEventEnabled(this@AlertEventSettingsActivity, entry.event, enabled)) {
                            button.setOnCheckedChangeListener(null)
                            button.isChecked = !enabled
                            // A failed write never falsely displays a persisted setting.
                            android.widget.Toast.makeText(this@AlertEventSettingsActivity, "설정 저장 실패. 화면을 다시 열어주세요.", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                }
                root.addView(cb)
            }
        }
        root.addView(Button(this).apply {
            text = "23종 알림 설정 초기값으로 복원 (모두 ON)"
            isAllCaps = false
            setOnClickListener {
                AlertDialog.Builder(this@AlertEventSettingsActivity)
                    .setTitle("사용자 알림 설정 복원")
                    .setMessage("추가 음성 23종의 개별 ON/OFF만 기본값 ON으로 되돌립니다. 차량 시스템 설정은 건드리지 않습니다.")
                    .setPositiveButton("복원") { _, _ ->
                        val ok = AlertEventCatalog.entries.all { entry ->
                            AlertPreferences.setEventEnabled(this@AlertEventSettingsActivity, entry.event, true)
                        }
                        if (ok) recreate() else android.widget.Toast.makeText(this@AlertEventSettingsActivity, "일부 설정 저장 실패", android.widget.Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("취소", null).show()
            }
        })
        root.addView(label("표시 근거: 과거 실차 보고와 소스/로그 분석 기준. 당일 차량 연결 상태와 신호를 실시간 검사한 결과가 아닙니다."))
    }
}
