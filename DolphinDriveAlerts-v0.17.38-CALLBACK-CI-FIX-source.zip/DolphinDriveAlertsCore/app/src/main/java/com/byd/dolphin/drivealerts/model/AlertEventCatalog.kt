package com.byd.dolphin.drivealerts.model

/**
 * Human-friendly inventory of the 23 user alerts. This is a UI/source contract,
 * not a declaration that the 2602 vehicle publishes every signal. Default user
 * preferences remain enabled to preserve already-working behaviors.
 */
object AlertEventCatalog {
    enum class Evidence { REALCAR_REPORTED, PARTIAL_REALCAR, NOT_CONFIRMED }
    data class Entry(val event: AlertEvent, val group: String, val evidence: Evidence)
    val entries: List<Entry> = listOf(
        Entry(AlertEvent.GEAR_P, "기어 · 회생제동 · 스노우", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.GEAR_D, "기어 · 회생제동 · 스노우", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.GEAR_N, "기어 · 회생제동 · 스노우", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.GEAR_R, "기어 · 회생제동 · 스노우", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.REGEN_STANDARD, "기어 · 회생제동 · 스노우", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.REGEN_HIGH, "기어 · 회생제동 · 스노우", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.SNOW_ON, "기어 · 회생제동 · 스노우", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.SNOW_OFF, "기어 · 회생제동 · 스노우", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.DRIVE_ECO, "ECO · NORMAL · SPORT", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.DRIVE_NORMAL, "ECO · NORMAL · SPORT", Evidence.NOT_CONFIRMED),
        Entry(AlertEvent.DRIVE_SPORT, "ECO · NORMAL · SPORT", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.AUTOHOLD_ON, "오토홀드 · 주차 브레이크", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.AUTOHOLD_OFF, "오토홀드 · 주차 브레이크", Evidence.REALCAR_REPORTED),
        Entry(AlertEvent.AUTOHOLD_ENGAGED, "오토홀드 · 주차 브레이크", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.AUTOHOLD_RELEASED, "오토홀드 · 주차 브레이크", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.EPB_ENGAGED, "오토홀드 · 주차 브레이크", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.EPB_RELEASED, "오토홀드 · 주차 브레이크", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.ICC_ON, "ADAS · BSD · 하차", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.ICC_OFF, "ADAS · BSD · 하차", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.BSD_WARNING, "ADAS · BSD · 하차", Evidence.PARTIAL_REALCAR),
        Entry(AlertEvent.LEAD_CAR_DEPARTURE, "ADAS · BSD · 하차", Evidence.NOT_CONFIRMED),
        Entry(AlertEvent.LANE_DEPARTURE, "ADAS · BSD · 하차", Evidence.NOT_CONFIRMED),
        Entry(AlertEvent.EXIT_REAR_WARNING, "ADAS · BSD · 하차", Evidence.NOT_CONFIRMED),
    )
    init {
        require(entries.size == AlertEvent.values().size) { "Alert catalog count mismatch" }
        require(entries.map { it.event }.toSet() == AlertEvent.values().toSet()) { "Missing or duplicate alert event" }
    }
    fun evidenceKorean(evidence: Evidence): String = when (evidence) {
        Evidence.REALCAR_REPORTED -> "과거 실차 동작 보고 (현재 버전 재확인 필요)"
        Evidence.PARTIAL_REALCAR -> "부분 근거 · 해당 동작 확정 아님"
        Evidence.NOT_CONFIRMED -> "현재 차량 알림 신호 미확정"
    }
}
