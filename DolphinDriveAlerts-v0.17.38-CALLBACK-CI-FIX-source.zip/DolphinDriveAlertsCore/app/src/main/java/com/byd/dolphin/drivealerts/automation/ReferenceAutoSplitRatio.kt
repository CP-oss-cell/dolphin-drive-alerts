package com.byd.dolphin.drivealerts.automation

/** Reference AutoSplit 1.2 / Assistant v30 compatible `am stack list` parser.
 * Prefer the single legacy stack dump; reject arbitrary Task rects.
 */
internal object ReferenceAutoSplitRatio {
    private val header=Regex("""(?i)\bStack\s+id\s*=\s*(\d+)""")
    private val bounds=Regex("""(?i)\bbounds=\[(-?\d+),\s*(-?\d+)\]\[(-?\d+),\s*(-?\d+)\]""")
    private val numericMode=Regex("""(?i)\b(?:mWindowingMode|windowingMode)\s*[=:]\s*([34])\b""")
    private data class Stack(val id: Int, var rect: SplitGeometry.Rect?=null, var mode: Int?=null)
    fun parse(raw: String): SplitGeometry.PairBounds? {
        val found=linkedMapOf<Int,Stack>()
        var active: Stack?=null
        raw.lineSequence().forEach { untrimmed ->
            val line=untrimmed.trim()
            header.find(line)?.let { m -> active=found.getOrPut(m.groupValues[1].toInt()) {Stack(m.groupValues[1].toInt())} }
            val e=active ?: return@forEach
            // A Task/Activity record is never a new stack and must not overwrite its geometry.
            if(line.startsWith("Task{",true) || line.startsWith("TaskRecord{",true) || line.startsWith("Task #",true))return@forEach
            if(e.rect==null) bounds.find(line)?.let {m ->
                val v=m.groupValues.drop(1).map(String::toInt)
                if(v[2]>v[0] && v[3]>v[1])e.rect=SplitGeometry.Rect(v[0],v[1],v[2],v[3])
            }
            if(line.contains("mWindowingMode=split-screen-primary",true) || line.contains("split-screen-primary",true)) e.mode=3
            else if(line.contains("mWindowingMode=split-screen-secondary",true) || line.contains("split-screen-secondary",true))e.mode=4
            else numericMode.find(line)?.groupValues?.get(1)?.toIntOrNull()?.let { e.mode=it }
        }
        val p=found.values.filter {it.mode==3 && it.rect!=null}
        val s=found.values.filter {it.mode==4 && it.rect!=null}
        if(p.size==1 && s.size==1) {
            val result=SplitGeometry.PairBounds(p.single().rect!!,s.single().rect!!)
            if(SplitGeometry.percent(result)!=null)return result
        }
        // AutoSplit 1.2.0 reference parser expects named split-primary/secondary
        // windowing modes. Never infer a split from two arbitrary fullscreen stacks.
        return null
    }
}
