package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** Read-only global display diagnostics and explicit legacy forced-density recovery only. */
object DisplaySettingsController {
    private const val PREF = "display_global_v0169"
    data class DensitySnapshot(val physical: Int?, val override: Int?)
    data class Result(val ok: Boolean, val message: String)
    private val physicalRegex = Regex("""(?i)physical density:\s*(\d+)""")
    private val overrideRegex = Regex("""(?i)override density:\s*(\d+)""")
    fun parseDensity(raw: String): DensitySnapshot = DensitySnapshot(
        physicalRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull(),
        overrideRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull()
    )
    fun readDensity(context: Context): DensitySnapshot? {
        val res = AuthorizedAdbRuntime.read(context, "wm density").result
        if (!res.success) return null
        return parseDensity(res.output).takeIf { it.physical != null }
    }
    fun readSize(context: Context): String {
        val res = AuthorizedAdbRuntime.read(context, "wm size").result
        return if (res.success) res.output.trim().take(240) else "해상도 조회 실패: ${res.message}"
    }
    fun readDisplayHardware(context: Context): String {
        // ADB read only: physical panel / logical mode / OEM profile must not be guessed.
        val res = AuthorizedAdbRuntime.read(context, "dumpsys display", timeoutMs = 6_000L).result
        if (!res.success) return "BYD 디스플레이 정보 읽기 실패: ${res.message}"
        val lines = res.output.lineSequence().filter { line ->
            listOf("DisplayDeviceInfo", "mBaseDisplayInfo", "DisplayInfo{", "supportedModes", "physicalWidth", "logicalWidth", "logicalHeight")
                .any { line.contains(it, ignoreCase = true) }
        }.take(18).joinToString("\n")
        return lines.ifBlank { "디스플레이 모드 정보가 dumpsys에서 노출되지 않음" }.take(2400)
    }
    fun applyDensity(context: Context, requested: Int?): Result {
        if (requested != null) {
            return Result(false, "다른 앱에 전역 DPI를 적용할 수 없습니다. 시스템 전체 화면 변경을 막았습니다. 우리 앱 DPI는 주행보조 앱 전용 메뉴에서 설정하세요.")
        }
        val app = context.applicationContext
        // Explicit recovery operation only. Never set a numeric forced density.
        // This is invoked solely by the user-confirmed device-wide recovery button.
        val before = readDensity(app) ?: return Result(false, "ADB로 현재 DPI 확인 불가: 변경하지 않았습니다")
        val prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        // Capture original override exactly once; do not overwrite on every subsequent change.
        if (!prefs.contains("baseline_captured")) {
            prefs.edit().putBoolean("baseline_captured", true)
                .putInt("baseline_physical", before.physical ?: -1)
                .putInt("baseline_override", before.override ?: -1).apply()
        }
        // Explicit OEM recovery always clears global override, even when old baseline captured a bad override.
        val command = "wm density reset"
        val ready = AuthorizedAdbRuntime.health(app)
        if (ready.state != AuthorizedAdbRuntime.State.READY) return Result(false, "ADB 연결 상태: ${ready.state}")
        val changed = AuthorizedAdbRuntime.writeOnce(app, command).result
        if (!changed.success) return Result(false, "명령 거부: ${changed.message}")
        val after = readDensity(app)
        val actual = after?.override ?: after?.physical
        val verified = after?.physical != null && after.override == null
        CoreLog.i("DPI", "before=$before cmd=$command after=$after verified=$verified")
        if (!verified) {
            val restore = if (before.override == null) "wm density reset" else "wm density ${before.override}"
            AuthorizedAdbRuntime.writeOnce(app, restore)
            return Result(false, "DPI 적용값 검증 실패. 직전 설정으로 복구를 시도했습니다. 실제=${after ?: "조회 실패"}")
        }
        return Result(true, "기존 전역 DPI 강제설정을 해제했습니다. 현재 물리 DPI=$actual. BYD 순정 레이아웃은 별도 점검이 필요할 수 있습니다.")
    }
}
