package com.byd.dolphin.drivealerts.log

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.NativeAdbClient
import com.byd.dolphin.drivealerts.util.CoreLog
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Passive AVAS/external-speaker diagnostics.
 * All shell commands are read-only: dumpsys/getprop/settings/service/logcat/cat/ls/tinymix.
 * No mixer value, system setting, vehicle ECU or BYD setter is changed.
 */
class SystemDiagnosticsCollector(
    context: Context,
    private val logger: RawSignalLogger,
    private val featureIds: FeatureIdCatalog
) {
    private val app = context.applicationContext
    private val root = File(app.filesDir, "external_speaker_diag").apply { mkdirs() }
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "external-speaker-diag").apply { isDaemon = true }
    }

    // A real navigation utterance must not wait behind deep diagnostics. Both
    // threads still use NativeAdbClient's serialized read-only ADB connection.
    // Regular captures yield between shell commands while an onset is pending.
    private val navOnsetPending = AtomicInteger(0)
    private val navOnsetExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "nav-first-pcm-diagnostics").apply { isDaemon = true }
    }

    init {
        writeText(File(root, "byd_feature_ids.json"), featureIds.asJson().toString(2))
    }

    fun directory(): File = root

    fun captureDeep(label: String) {
        val requestedAt = System.currentTimeMillis()
        executor.execute { captureInternal(label, COMMANDS_DEEP, requestedAt) }
    }

    /** Faster capture for an exact ON/OFF state. */
    fun captureQuick(label: String) {
        val requestedAt = System.currentTimeMillis()
        executor.execute { captureInternal(label, COMMANDS_QUICK, requestedAt) }
    }

    /**
     * Triggered ONCE by a consented navigation playback relay's first nonzero PCM.
     * A 3/8/15-second scheduled scan can miss guidance that begins minutes later.
     * Capture only read-only audio state, never the PCM itself or an OEM write.
     * Files are included by UnifiedLogCapture using their requestedAtMs.
     */
    fun captureNavAudioOnset(targetPackage: String, targetUid: Int): Boolean {
        if (targetUid < 0 || targetPackage.isBlank() || navOnsetExecutor.isShutdown) return false
        val safePkg = targetPackage.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(38)
        val label = "NAV_PCM_ONSET_${safePkg}_$targetUid"
        val requestedAtMs = System.currentTimeMillis()
        navOnsetPending.incrementAndGet()
        return runCatching {
            navOnsetExecutor.execute {
                try {
                    captureInternal(label, COMMANDS_NAV_ONSET, requestedAtMs)
                } finally {
                    navOnsetPending.decrementAndGet()
                }
            }
            true
        }.getOrElse {
            navOnsetPending.decrementAndGet()
            false
        }
    }

    /** Raw Linux input capture for steering-wheel button mapping. Read-only except for a temporary file under /data/local/tmp. */
    fun captureSteeringKeyWindow(seconds: Int = 10) {
        val duration = seconds.coerceIn(5, 20)
        logger.marker("STEERING_RAW_WINDOW_START", "${duration}s")
        executor.execute {
            val dir = File(root, "${stamp()}_STEERING_KEYS").apply { mkdirs() }
            val tmp = "/data/local/tmp/drivealerts_keys.txt"
            val command = "sh -c 'rm -f $tmp; getevent -lt > $tmp 2>&1 & pid=${'$'}!; sleep $duration; kill ${'$'}pid 2>/dev/null || true; wait ${'$'}pid 2>/dev/null || true; cat $tmp; rm -f $tmp'"
            val events = NativeAdbClient.executeShell(app, command, timeoutMs = (duration + 8L) * 1000L)
            val input = NativeAdbClient.executeShell(app, "dumpsys input", timeoutMs = 8_000L)
            val caps = NativeAdbClient.executeShell(app, "getevent -lp 2>&1", timeoutMs = 8_000L)
            writeText(File(dir, "steering_getevent.txt"), "# $command\n# success=${events.success} exit=${events.exitCode} ${events.message}\n\n${limit(events.output)}")
            writeText(File(dir, "dumpsys_input.txt"), limit(input.output))
            writeText(File(dir, "getevent_capabilities.txt"), limit(caps.output))
            logger.marker("STEERING_RAW_WINDOW_END", "${duration}s success=${events.success}")
        }
    }

    /** Capture start/end around a short real driving-sound window. */
    fun captureWindow(label: String, seconds: Int = 12) {
        logger.marker("${label}_WINDOW_START", "${seconds}s")
        val requestedAt = System.currentTimeMillis()
        executor.execute { captureInternal("${label}_START", COMMANDS_QUICK, requestedAt) }
        executor.schedule({
            logger.marker("${label}_WINDOW_END", "${seconds}s")
            captureInternal("${label}_END", COMMANDS_QUICK, System.currentTimeMillis())
        }, seconds.toLong(), TimeUnit.SECONDS)
    }

    /** Flush both diagnostic queues before the session ZIP is assembled. */
    fun captureDeepAndWait(label: String, timeoutSeconds: Long = 180): Boolean = runCatching {
        val regular = executor.submit<Boolean> {
            captureInternal(label, COMMANDS_DEEP, System.currentTimeMillis()); true
        }.get(timeoutSeconds, TimeUnit.SECONDS)
        // The foreground playback relay records an onset on a separate queue.
        // A barrier is mandatory or the ZIP may contain an incomplete snapshot.
        val onset = navOnsetExecutor.submit<Boolean> { true }.get(timeoutSeconds, TimeUnit.SECONDS)
        regular && onset
    }.getOrElse {
        CoreLog.w("EXT_SPK_DIAG", "final capture timeout/failure: ${it.message}")
        false
    }

    fun close() {
        executor.shutdown()
        navOnsetExecutor.shutdown()
        runCatching { executor.awaitTermination(2, TimeUnit.SECONDS) }
        runCatching { navOnsetExecutor.awaitTermination(2, TimeUnit.SECONDS) }
        executor.shutdownNow()
        navOnsetExecutor.shutdownNow()
    }

    private fun captureInternal(label: String, commands: Map<String, String>, requestedAtMs: Long) {
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(64)
        val dir = File(root, "${stamp()}_$safe").apply { mkdirs() }
        logger.marker("DIAG_CAPTURE_START", safe)

        writeText(File(dir, "00_meta.json"), JSONObject().apply {
            put("label", label)
            put("timestampMs", System.currentTimeMillis())
            put("requestedAtMs", requestedAtMs)
            put("adbPortOpen", NativeAdbClient.isPortOpen())
            put("note", "read-only vehicle audio/AVAS/navigation diagnostics; output sound not verified")
        }.toString(2))

        var commandSuccesses = 0
        var commandFailures = 0
        for ((filename, command) in commands) {
            // NativeAdbClient serializes all shell calls. Yield BEFORE the next
            // routine command, letting the urgent onset queue capture the active
            // audio track instead of waiting until a deep scan has finished.
            if (commands !== COMMANDS_NAV_ONSET && navOnsetPending.get() > 0) {
                val deadline = System.currentTimeMillis() + 40_000L
                logger.diagnostic("NAV_ONSET_PRIORITY_YIELD", "routine=$safe pending=${navOnsetPending.get()}")
                while (navOnsetPending.get() > 0 && System.currentTimeMillis() < deadline) {
                    try { Thread.sleep(50L) } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                        break
                    }
                }
            }
            // A failed ADB command or thrown exception is evidence of missing
            // access, NOT an empty/successful vehicle state.
            val attempt = runCatching { NativeAdbClient.executeShell(app, command) }
            val result = attempt.getOrNull()
            val success = result?.success == true
            if (success) commandSuccesses++ else commandFailures++
            val body = if (result != null) limit(result.output) else
                "EXCEPTION:${attempt.exceptionOrNull()?.javaClass?.simpleName}:${attempt.exceptionOrNull()?.message}"
            val header = "# command: $command\n# success=$success exit=${result?.exitCode ?: -1} " +
                "message=${result?.message ?: "EXCEPTION"}\n\n"
            writeText(File(dir, filename), header + body)
        }
        writeText(File(dir, "98_capture_status.json"), JSONObject().apply {
            put("schema", "DOLPHIN_READONLY_AUDIO_CAPTURE_RESULT_V1")
            put("label", label)
            put("requestedAtMs", requestedAtMs)
            put("completedAtMs", System.currentTimeMillis())
            put("totalCommands", commands.size)
            put("successes", commandSuccesses)
            put("failures", commandFailures)
            put("result", if (commandFailures == 0) "COMPLETE" else "PARTIAL_FAILED_COMMANDS")
            put("vehicleWriteOperations", 0)
        }.toString(2))
        logger.diagnostic("READONLY_AUDIO_DIAG_STATUS",
            "label=$safe;success=$commandSuccesses;failed=$commandFailures;vehicleWrites=0")
        logger.marker("DIAG_CAPTURE_END", safe)
    }

    private fun writeText(file: File, text: String) = runCatching {
        file.parentFile?.mkdirs()
        file.writeText(text, Charsets.UTF_8)
    }.onFailure { CoreLog.w("EXT_SPK_DIAG", "write failed ${file.name}: ${it.message}") }

    private fun limit(s: String): String = if (s.length <= MAX_CHARS) s else {
        "# output truncated to last $MAX_CHARS chars\n" + s.takeLast(MAX_CHARS)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    companion object {
        private const val MAX_CHARS = 2_000_000
        // Priority: policy and active flinger tracks BEFORE the less time-critical
        // AudioService dump, because short navigation utterances may end quickly.
        private val COMMANDS_NAV_ONSET = linkedMapOf(
            "03_audio_policy.txt" to "dumpsys media.audio_policy",
            "04_audio_flinger.txt" to "dumpsys media.audio_flinger",
            "02_audio.txt" to "dumpsys audio"
        )

        private val COMMANDS_QUICK = linkedMapOf(
            "02_audio.txt" to "dumpsys audio",
            "03_audio_policy.txt" to "dumpsys media.audio_policy",
            // Stock NAV vs third-party NAV: capture live AudioTrack/UID and physical output.
            "04_audio_flinger.txt" to "dumpsys media.audio_flinger",
            "05_properties.txt" to "getprop | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|acoustic' || true",
            "06_settings.txt" to "(settings list system; settings list global; settings list secure) | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "10_tinymix.txt" to "command -v tinymix >/dev/null 2>&1 && tinymix || echo 'tinymix unavailable'",
            "12_logcat_filtered.txt" to "logcat -d -v threadtime -t 2000 | grep -Ei 'byd|bydauto|audio|sound|avas|vsp|pedestrian|speaker|acoustic|warning|vehicle|low.?speed' || true"
        )

        private val COMMANDS_DEEP = linkedMapOf(
            "01_service_list.txt" to "service list | grep -Ei 'audio|sound|vehicle|car|byd|avas|vsp|pedestrian' || true",
            "02_audio.txt" to "dumpsys audio",
            "03_audio_policy.txt" to "dumpsys media.audio_policy",
            "04_audio_flinger.txt" to "dumpsys media.audio_flinger",
            "05_properties.txt" to "getprop | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|acoustic' || true",
            "06_settings_system.txt" to "settings list system | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "07_settings_global.txt" to "settings list global | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "08_settings_secure.txt" to "settings list secure | grep -Ei 'audio|sound|avas|vsp|pedestrian|vehicle|byd|warning|engine' || true",
            "09_asound_cards.txt" to "cat /proc/asound/cards 2>&1; echo; cat /proc/asound/pcm 2>&1; echo; ls -l /dev/snd 2>&1",
            "10_tinymix.txt" to "command -v tinymix >/dev/null 2>&1 && tinymix || echo 'tinymix unavailable'",
            "11_hal_audio_vehicle.txt" to "command -v lshal >/dev/null 2>&1 && lshal | grep -Ei 'audio|vehicle|byd|sound' || true",
            "12_logcat_filtered.txt" to "logcat -d -v threadtime -t 2000 | grep -Ei 'byd|bydauto|audio|sound|avas|vsp|pedestrian|speaker|acoustic|warning|vehicle|low.?speed' || true"
        )
    }
}
