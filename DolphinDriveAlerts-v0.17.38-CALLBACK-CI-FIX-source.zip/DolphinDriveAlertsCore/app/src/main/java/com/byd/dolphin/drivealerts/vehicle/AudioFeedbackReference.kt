package com.byd.dolphin.drivealerts.vehicle

/**
 * Evidence from user-supplied Byd_AutoFeedBack_v1.0.apk DEX:
 * BydAutoService$5.onOperationModeChanged -> handleOperationMode.
 * value=1 triggers operation_mode_1_sports_mode_off, value=2 triggers
 * operation_mode_2_sports_mode_on. Neither branch plays a NORMAL sound.
 * This class is intentionally diagnostic-only; SPORT_OFF is NOT proof of NORMAL.
 */
object AudioFeedbackReference {
    enum class Signal { SPORTS_MODE_OFF, SPORTS_MODE_ON, UNKNOWN }
    fun classify(raw: Int): Signal = when(raw) {
        1 -> Signal.SPORTS_MODE_OFF
        2 -> Signal.SPORTS_MODE_ON
        else -> Signal.UNKNOWN
    }
}
