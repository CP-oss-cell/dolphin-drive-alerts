# v0.17.30 GitHub 빌드와 실차 진단 (한국어)

1. 저장소 `CP-oss-cell/dolphin-drive-alerts` **최상위**에 `DolphinDriveAlerts-v0.17.30-PCM-ONSET-MODE-GUARD-source.zip` 업로드.
2. `.github/workflows/build-v01730-pcm-onset-mode-guard.yml`로 YML 업로드.
3. Actions의 `Build Dolphin Drive Alerts v0.17.30 PCM Onset Mode Guard` 실행.
4. 빌드 산출 `DolphinDriveAlerts-v0.17.30-PCM-ONSET-MODE-GUARD-SIGNED.apk` 다운로드해 차량에 설치. 기존 데이터/설정 보존 시 GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64`의 **기존 앱과 동일한 서명키** 필수. 서명키 미설정의 `ONE_TIME_EPHEMERAL` 새 APK는 기존 앱 위에 업데이트 불가능할 수 있으므로 앱을 삭제하지 마세요.
5. 차를 안전하게 정차한 뒤 앱의 `로그 수집 시작`, 기존 내비 오디오 실험실의 지정 내비와 캡처 승인, 안내 음성, `로그 수집 종료`를 수행. 새 메뉴·복잡한 경로 조작 불필요.
6. ZIP의 `diagnostics/*NAV_PCM_ONSET*/03_audio_policy.txt`, `04_audio_flinger.txt` 및 `nav_audio_lab/uid_relay_status.log`를 비교. `FIRST_NONZERO_PCM_ONSET ... diagnosticQueued=true`여도 해당 파일 헤더의 실제 명령 `success=true`를 별도 확인해야 함. 운전석 단독 출력과 정상 모드 완료로 표시 금지.

빌드와 실차 성과는 별개입니다. 이 파일은 소스+YML이지 미리 컴파일된 APK가 아닙니다.
