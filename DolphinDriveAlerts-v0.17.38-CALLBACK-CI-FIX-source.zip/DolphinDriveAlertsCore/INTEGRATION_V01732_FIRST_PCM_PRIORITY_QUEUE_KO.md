# BYD Dolphin Drive Alerts v0.17.32 — 첫 내비 PCM 진단 대기 병목 수정

날짜: 2026-10-24 KST | 기준: 라이브러리 v0.17.31 완전 소스(versionCode 57)

## 확인된 원인과 수정
- v0.17.31의 `captureNavAudioOnset`는 `SystemDiagnosticsCollector.executor`(한 개 작업 스레드)에 실행을 예약했습니다. 앞선 `captureDeep`, `captureQuick` 또는 긴 AVAS/핸들 스캔이 같은 대기열을 점유하면 **비무음 PCM이 감지돼도 AudioPolicy 검사 시작이 늦어질 수 있었습니다.** `dumpsys media.audio_policy`를 목록 맨 앞에 넣는 것만으로는 대기열 지연을 없앨 수 없었습니다.
- v0.17.32는 음성 시작 순간 스냅샷을 위한 `navOnsetExecutor`를 독립 설치하고, 일반 오디오 진단이 `NativeAdbClient.executeShell` 사이에서 이 큐를 우선 실행하도록 협조적으로 양보합니다. 이미 실행 중인 ADB 셸 명령을 강제로 취소하거나 선점하지는 않습니다.
- 원시 음성 PCM 저장/원본 미디어 차단/차량 음향설정 쓰기 없음. 음성·내비 관련 진단 파일을 다운로드 ZIP에 포함하기 전 큐 완료 배리어를 확인합니다.
- v0.17.31의 정책 → flinger → audio 우선순위, per-command 실패 및 `98_capture_status.json` 결과 유지. 기존 9개 메뉴/2앱 분할/BSD 공통 알림·오토홀드·회생제동을 유지하고 관련 코드는 수정하지 않았습니다.

## 한계와 정확한 상태
- 변경은 **실제 음성 순간 진단 신뢰도를 높이는 준비 작업**입니다. 운전석 스피커 독점 출력, 내비 원본 미디어 차단, NORMAL, BSD 좌우, 분할 비율, 외부 AVAS 음성 출력을 해결한 것이 아닙니다.
- `NativeAdbClient`는 셸 호출에 내부 공용 잠금을 사용합니다. 이미 실행 중인 명령(연결 대기/타임아웃)은 선점할 수 없어 오디오 순간을 일부 놓칠 수 있습니다. Android 전체 APK 컴파일/실차 동작 미검증.
- Android 10에서 오디오 캡처는 사용자 MediaProjection 승인 + 원본 앱의 캡처 허용이 필요합니다. 해당 앱이 사용한 audio usage에 따라 무음일 수 있습니다.

## 검증과 실차 테스트
- 정적 검증: `tools/verify_v01732_nav_onset_preemption.py` 및 기존 `tools/verify_v01731_nav_onset_priority.py`, `tools/verify_v01729_unified_evidence.py`.
- 실차(차량 정차, P): 로그 수집 시작 → 메뉴 7 내비에서 MCon K 선택 및 화면 캡처 승인 → 실제 안내 음성 1회 재생 → 로그 수집 종료 → Downloads ZIP 공유.
- 확인 파일: `external_speaker_diag/*NAV_PCM_ONSET*/00_meta.json` 및 `03_audio_policy.txt`, `04_audio_flinger.txt`, `02_audio.txt`, `98_capture_status.json`. 또한 로그에 `FIRST_NONZERO_PCM_ONSET`, `NAV_ONSET_PRIORITY_YIELD`가 기록될 수 있습니다. 전자음이 줄거나 내비 소리 독점이 실현됐는지는 별도로 검증해야 합니다.

## 서명
기존 앱 삭제 금지. `DOLPHIN_DEBUG_KEYSTORE_B64`에 설치 앱과 같은 서명키가 있어야 덮어쓰기 설치 가능. GitHub Actions 빌드 완료·서명 일치 전 설치 가능 APK로 보지 않음.
