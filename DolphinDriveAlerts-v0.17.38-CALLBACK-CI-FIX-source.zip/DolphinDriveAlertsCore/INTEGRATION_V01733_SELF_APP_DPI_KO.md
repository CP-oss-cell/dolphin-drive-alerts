# Dolphin Drive Alerts v0.17.33 — 앱 DPI 수정 및 순정 화면 보호

작성: 2026-11-01, Android 10 / BYD Dolphin 2602, package `com.byd.dolphin.drivealerts`
기준: v0.17.32 NAV-ONSET-QUEUE-PRIORITY 전체 소스(vCode58), v0.17.33 vCode59 후보.

## 기존 DPI가 원하는 대로 작동하지 않았던 이유
- v0.16.9 이후 다른 앱별 DPI 자동 전환 코드를 제거하고 `wm density` 기기 전체 DPI로 전환했다.
- v0.17.32의 화면 설정 UI는 `wm density` 전역 적용만 제공한다. 기기 전체 UI가 변하고 순정 공조/런처/360 화면 잘림을 유발했다.
- Android 10 `wm density`는 특정 패키지에 적용하는 명령이 아니다. Kinex의 embedded-app DPI는 독립된 앱 표시 화면에서 제공되는 것으로, 해당 방식의 구체 권한·구현·라이선스는 확인되지 않음.

## 이번에 실제 구현한 기능 (검사 통과, 실차 미검증)
1. 새 `dpi/SelfAppDensity.kt`의 `DensityAwareActivity`: `createConfigurationContext()`로 주행보조 앱 소유 Activity만 Configuration.densityDpi 덮어쓰기. 시스템 전체 `wm density` 변경 안 함.
2. 기존 11개 소유 Activity를 공통 DensityAwareActivity에 연결해 내부 화면 이동에서도 자기 앱 DPI가 유지되도록 함.
3. DPI 순정/200/180/160/140/120/수동 120~320 입력, SharedPreferences 즉시 저장(`commit`), Activity `recreate()` 적용, 실제 UI Configuration.densityDpi readback 표시. 값이 불일치하면 '미적용'으로 표시.
4. 이전 버전이 남긴 기기 전체 `wm density` 강제값 해제는 별도 사용자 확인을 받는 **복구** 버튼으로만 유지. 해제 전후 readback 및 실패 시 직전 설정 복구 시도. `wm density NUMBER` 일반 적용 차단.
5. 기존 내비 5종, 회전, 음성/모드, 분할, nav onset 우선 진단 등 경로 변경 안 함.

## 지원 경계
- **실제 지원 대상은 우리 주행보조 앱 자체 메뉴의 DPI**. 일반/순정 다른 패키지 하나만 조정하는 DPI는 미구현.
- 다른 앱, BYD 순정 런처/공조/카메라/계기판의 DPI는 변경하지 않음. 120도 자기 앱 화면에서만 적용.
- Android 10의 `wm density`와 WindowManager 강제 DPI 설정은 package별이 아닌 display별. Kinex의 앱 임베딩 엔진은 그대로 사용할 수 없는 독립 기능이다.
- 구 버전에서 전역 강제 DPI가 변경되어 있다면 이 업데이트만으로 복원하지 않음. 사용자가 복구 버튼을 명시적으로 눌러야 함.
- **Android Gradle CI 빌드 및 실차 작동 검증 전**이며 설치 확약 불가. 누적 문제 NORMAL/BSD 좌우/분할 비율/운전석 단독 출력/AVAS 미해결 유지.

## 로컬 검사 결과
- 새 `tools/verify_v01733_self_app_dpi.py` 정적 12개 PASS + Android Context stub 기반 실 Kotlin 실행 PASS.
- 기존 v0.17.29 unified evidence 20/20 PASS, v0.17.28 UI 16/16 PASS.
- 이전 v0.17.8/9, v0.17.30/31/32 게이트 중 의도적으로 대체된 글로벌 DPI·옛 버전 단언만 분리한 `verify_v01733_legacy_compat.py` PASS (나머지 오류는 FAIL).
- Gradle wrapper jar와 Android SDK가 로컬에 없어 APK 빌드는 실행하지 못함. CI에서 `:app:compileDebugKotlin`, `:app:assembleDebug`, APK 서명·버전 확인 필요.

## 한 번만 확인한다면
- 새 APK가 동일 서명키로 설치되면 기존 UI의 '화면 회전 · DPI' 메뉴에서 자기 앱 DPI 140 설정 → 메뉴 크기 확인 → 순정 설정.
- **타 앱 전용 DPI는 이번 버전에서 작동하지 않습니다.** 정상 완료로 표시하지 않음.
