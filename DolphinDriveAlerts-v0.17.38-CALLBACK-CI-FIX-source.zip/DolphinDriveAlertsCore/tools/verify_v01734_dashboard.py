#!/usr/bin/env python3
"""v0.17.34 UI contract: actual six-category dashboard and all legacy functions live.
These are source-level guards only, NOT Android build/real car results.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/byd/dolphin/drivealerts/ui/MainActivity.kt').read_text()
base=(root/'app/build.gradle.kts').read_text()
old=(root/'tools/verify_v01728_simple_menu.py').read_text()
menus=["주행 알림", "BSD 알림", "화면 · 분할", "오디오 · 내비", "자동 실행 · 권한", "로그 · 진단"]
legacy=[
"NEW · 순정 내비 + 5종 내비 오디오 경로 통합 실험실",
"NEW · ECO/NORMAL/SPORT 실차 3상태 교정",
"로컬 ADB / 최초 승인 · PC 연결 불필요",
"알림 출력 경로", "알림 종류", "핸들 메뉴/이전 버튼 3연타",
"후측방 경고 · 두 가지 독립 설정", "ICC 차선이탈·앞차 출발 · 실차 신호 연구",
"자동 실행 / 백그라운드", "화면 분할 프로필", "통합 로그 수집",
"글로벌 2602 · 순정 내비 / 외부 스피커 신호 연구", "ADB 권한 관리",
"디스플레이 DPI / 화면 회전 / 내비 음성", "이퀄라이저 / 음향 효과"
]
checks={
 'versionCode-at-least-60': int(re.search(r'versionCode\s*=\s*(\d+)',base).group(1)) >= 60,
 'six-home-cards': 'val titles = listOf('+ '"주행 알림"' in main and all('"'+x+'"' in main for x in menus) and 'chunked(cardsPerLine)' in main,
 'all-15-sections-mapped': all('"'+x+'" to ' in main for x in legacy),
 'main-status-six-keys': all('"'+x+'"' in main for x in ['서비스','자동실행','ADB','로그','회전','출력']) and 'refreshDashboardStatus()' in main,
 'status-no-fake-verified': '서비스 · 확인 필요' in main and 'AuthorizedAdbRuntime.State.READY -> \"인증 완료\"' in main and 'else -> \"확인 불가\"' in main and '실차 검증 완료를 뜻하지 않습니다' in main,
 'quick-actions-live': all(x in main for x in ['performCapture(true)','performCapture(false)','runReadOnlyAutoCheck()','shareLatestLogZip()','SplitProfilesActivity::class.java']),
 'capture-original-wiring': 'DrivingAlertService.beginUnifiedCapture(this@MainActivity)' in main and 'DrivingAlertService.endUnifiedCapture(this@MainActivity)' in main,
 'capture-additional-shortcut': 'DrivingAlertService.beginUnifiedCapture(this)' in main and 'DrivingAlertService.endUnifiedCapture(this)' in main,
 'log-share-live': all(x in main for x in ['MediaStore.Downloads.EXTERNAL_CONTENT_URI','Intent.ACTION_SEND','FLAG_GRANT_READ_URI_PERMISSION']),
 'card-drilldown-live': 'showCategory(id)' in main and 'groups.getValue(id).forEach { body.addView(it) }' in main,
 'back-navigation': 'override fun onBackPressed()' in main and 'dashboardBack?.invoke()' in main,
 'all-3-BSD-options': all(x in main for x in ['bsdBlinkerEnabled','bsdTurnSoundExperimentalEnabled','bsdInstantEnabled']),
 'steering-preserved': 'SteeringTriggerPreferences.setEnabled' in main,
 'all-three-alert-output-modes': all(x in main for x in ['DRIVER_STREAM14','DRIVER_RAW14','OutputRoute.MEDIA']),
 'all-three-voice-modes': all(x in main for x in ['AlertStyle.MALE','AlertStyle.FEMALE','AlertStyle.EFFECT']),
 'driving-alert-master-switch': all(x in main for x in ['AlertPreferences.isEnabled','AlertPreferences.setEnabled']),
 'nav-five-checkboxes': 'NAVIGATION_APPS.forEach { entry ->' in main and 'ExternalAppAudioRouter.setEnabled' in main,
 'seven-legacy-activities': all(x in main for x in ['SplitProfilesActivity','AudioTuningActivity','AppPolicyActivity','AutoLaunchSettingsActivity','DriveModeCalibrationActivity','NavAudioLabActivity','AppPermissionManagerActivity','AdbSetupActivity']),
 'runtime-safe-read': 'AuthorizedAdbRuntime.health(applicationContext)' in main and 'runOnUiThread' in main,
 'no-oem-writes': 'setAVAS' not in main and 'setVehicleMode' not in main,
 'keep-preferences': 'clear()' not in main and 'deleteSharedPreferences' not in main,
 'app-dpi-honest': '다른 앱의 개별 DPI 변경은 아직 지원하지 않습니다' in main,
 'keep-zip-evidence': 'USER_AUTOMATED_READONLY_CHECK' in main and 'UnifiedLogCapture.state(this)' in main,
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values()),'dashboard regression found'
print('V01734_DASHBOARD_PASS',len(checks),'SOURCE-GATES-ONLY')
