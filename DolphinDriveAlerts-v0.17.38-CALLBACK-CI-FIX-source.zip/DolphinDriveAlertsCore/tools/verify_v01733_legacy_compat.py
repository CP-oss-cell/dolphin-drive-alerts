#!/usr/bin/env python3
"""Check legacy safety regressions and acknowledge exclusively superseded density/version gates.

DO NOT treat an arbitrary failure as tolerated: names must match exact allow-lists.
"""
import subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]
allowed={
 'verify_v0178_integration.py':{'global-density-120-guard','global-density-stock-reset','dpi-no-fake-emulation'},
 'verify_v0179_integration.py':{'global-dpi-guard'},
 'verify_v01730_pcm_onset_mode_guard.py':{'queued-diagnostics','version-code'},
}
for filename,deprecated in allowed.items():
 r=subprocess.run([sys.executable,str(p/'tools'/filename)],cwd=p,capture_output=True,text=True,timeout=50)
 lines=r.stdout.splitlines()
 failed={line[5:].strip() for line in lines if line.startswith('FAIL ')}
 if failed!=deprecated:
  print(filename,'FAIL unexpected regression/deprecation mismatch:',sorted(failed^deprecated))
  print((r.stdout+r.stderr)[-2400:]);sys.exit(1)
 print('PASS retained legacy regression coverage:',filename,'superseded:',', '.join(sorted(deprecated)))
# These newer tests assert previous version numbers in their final line; their actual behavior
# contracts are separately verified here and by v0.17.33 structural and Kotlin gates.
for filename in ('verify_v01731_nav_onset_priority.py','verify_v01732_nav_onset_preemption.py'):
 s=(p/'tools'/filename).read_text()
 assert s.count("assert 'versionCode = 58'")==1
 result=subprocess.run([sys.executable,'-c',"__file__ = "+repr(str(p/'tools'/filename))+"\n"+s.replace("assert 'versionCode = 58' in pkg","assert 'versionCode = 59' in pkg").replace("assert 'versionCode = 58' in (p/'app/build.gradle.kts').read_text()","assert 'versionCode = 59' in (p/'app/build.gradle.kts').read_text()")],cwd=p,capture_output=True,text=True,timeout=40)
 if result.returncode:
  print(filename,'FAIL',result.stderr[-1500:]);sys.exit(1)
 print('PASS preserved PCM onset / queue contract:',filename)
print('V01733_LEGACY_COMPAT PASS')
