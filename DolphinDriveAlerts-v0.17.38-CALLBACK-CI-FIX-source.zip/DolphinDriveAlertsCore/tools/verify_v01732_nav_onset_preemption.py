#!/usr/bin/env python3
"""Static guard against re-introducing the queue-delay/ZIP-before-snapshot regression."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
root=p/'app/src/main/java/com/byd/dolphin/drivealerts'
s=(root/'log/SystemDiagnosticsCollector.kt').read_text()
relay=(root/'audio/NavPlaybackCaptureRelayService.kt').read_text()
cap=(root/'log/UnifiedLogCapture.kt').read_text()
assert 'navOnsetExecutor = Executors.newSingleThreadExecutor' in s
assert 'navOnsetExecutor.execute {' in s
assert 'navOnsetPending.incrementAndGet()' in s
assert 'navOnsetPending.decrementAndGet()' in s
assert 'commands !== COMMANDS_NAV_ONSET && navOnsetPending.get() > 0' in s
assert 'navOnsetExecutor.submit<Boolean> { true }.get(timeoutSeconds, TimeUnit.SECONDS)' in s
assert 'navOnsetExecutor.awaitTermination' in s
assert 'captureNavAudioOnset(pkg, uid)' in relay
assert 'captureDeepAndWait("UNIFIED_STOP_' in cap
assert 'versionCode = 58' in (p/'app/build.gradle.kts').read_text()
assert 'vehicleWriteOperations", 0' in s
print('PASS v0.17.32: urgent PCM queue, cooperative preemption, archive barrier, no OEM write')
