#!/usr/bin/env python3
"""2026-10-22 correction of the speculative 10/18 signature replay.
Old regression EXPECTING NORMAL from INSTRUMENT+SET_ELECTRIC_RANGE was invalid.
Require fail-closed diagnostic classification, never mode speech, instead.
"""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parent.parent
app=root/'app/src/main/java/com/byd/dolphin/drivealerts'
src=(app/'vehicle/InstrumentDriveModeGate.kt').read_text()
bridge=(app/'vehicle/ReferenceVehicleEventBridge.kt').read_text()
relay=(app/'audio/NavPlaybackCaptureRelayService.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert all(x in src for x in ['363 -> "ECO_UNVERIFIED"','364 -> "NORMAL_UNVERIFIED"','365 -> "SPORT_UNVERIFIED"','SET_ELECTRIC_RANGE','NOT a drive-mode decoder'])
assert 'MODE_DISPLAY_CODE_UNVERIFIED' in bridge and 'MODE_ELECTRIC_RANGE_EXCLUDED' in bridge
assert 'MODE_2602_DUAL_SOURCE_CONFIRMED' not in bridge
assert 'instrumentDriveMode.isConfirmed()' not in bridge
assert 'emit(event, "instrument+setting' not in bridge
assert all(x in relay for x in ['addMatchingUid(uid)','MediaProjectionManager','AudioRecord','setLegacyStreamType(14)','ACTION_STOP','nonzeroApproxBytes'])
assert 'android:foregroundServiceType="mediaProjection"' in manifest and 'android.permission.RECORD_AUDIO' in manifest
if True:
 with tempfile.TemporaryDirectory() as d:
  test=Path(d)/'Test.kt'; test.write_text('''package com.byd.dolphin.drivealerts.vehicle
fun main() {
  val gate = InstrumentDriveModeGate()
  for (value in listOf(363,364,365,363,364,365)) {
    val candidate = gate.observeDisplayCode(value,1000L+value)
    check(candidate != null)
    check(candidate!!.priorHypothesis.endsWith("_UNVERIFIED"))
  }
  for (range in listOf(155,158,159,160,161,162,164,165,166,167,168)) {
    check(gate.observeElectricRange(range))
    check(!gate.observeElectricRange(range))
  }
  check(gate.observeDisplayCode(198,2026L) == null)
  println("PASS real 2026-10-22 range 155..168 NEVER maps to NORMAL; instrument display only candidates")
}''')
  jar=Path(d)/'gate.jar'
  p=subprocess.run(['kotlinc',str(app/'vehicle/InstrumentDriveModeGate.kt'),str(test),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=100)
  assert p.returncode==0,p.stderr
  p=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
  assert p.returncode==0,p.stderr
  print(p.stdout.strip())
print('PASS v01727 old speculative mapping regression replaced with 2026-10-22 fail-closed evidence')
