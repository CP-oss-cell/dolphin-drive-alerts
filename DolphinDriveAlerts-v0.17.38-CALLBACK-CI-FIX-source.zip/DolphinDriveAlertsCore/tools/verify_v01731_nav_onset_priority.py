#!/usr/bin/env python3
"""v0.17.31 actual-onset diagnostics must be first, complete, and non-invasive."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=r/'app/src/main/java/com/byd/dolphin/drivealerts'
c=(a/'log/SystemDiagnosticsCollector.kt').read_text()
relay=(a/'audio/NavPlaybackCaptureRelayService.kt').read_text()
uc=(a/'log/UnifiedLogCapture.kt').read_text()
pkg=(r/'app/build.gradle.kts').read_text()
assert 'firstNonzeroSeen = true' in relay and 'captureNavAudioOnset(pkg, uid)' in relay
assert c.index('"03_audio_policy.txt" to "dumpsys media.audio_policy"',c.index('private val COMMANDS_NAV_ONSET')) < c.index('"04_audio_flinger.txt" to "dumpsys media.audio_flinger"',c.index('private val COMMANDS_NAV_ONSET')) < c.index('"02_audio.txt" to "dumpsys audio"',c.index('private val COMMANDS_NAV_ONSET'))
assert '98_capture_status.json' in c
assert 'PARTIAL_FAILED_COMMANDS' in c and 'runCatching { NativeAdbClient.executeShell(app, command) }' in c
assert 'vehicleWriteOperations", 0' in c
assert 'READONLY_AUDIO_DIAG_STATUS' in c
assert 'put("requestedAtMs", requestedAtMs)' in c
assert 'diagnosticFolders' in uc and 'captureDeepAndWait("UNIFIED_STOP_' in uc
assert 'versionCode = 58' in pkg
print('PASS: FIRST NONZERO -> policy > flinger > audio; failures explicit; ZERO OEM writes; session archive')
