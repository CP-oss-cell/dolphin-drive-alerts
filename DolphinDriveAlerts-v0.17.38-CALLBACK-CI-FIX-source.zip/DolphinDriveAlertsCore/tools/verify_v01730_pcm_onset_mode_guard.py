#!/usr/bin/env python3
"""Static contract checks for v0.17.30: no OEM writes / session-scoped PCM-onset dumpsys."""
from pathlib import Path
import re, subprocess, tempfile
p=Path(__file__).resolve().parents[1]
app=p/'app/src/main/java/com/byd/dolphin/drivealerts'
relay=(app/'audio/NavPlaybackCaptureRelayService.kt').read_text()
collector=(app/'log/SystemDiagnosticsCollector.kt').read_text()
bridge=(app/'vehicle/ReferenceVehicleEventBridge.kt').read_text()
gate=(app/'vehicle/InstrumentDriveModeGate.kt').read_text()
capture=(app/'log/UnifiedLogCapture.kt').read_text()
checks={
 'onset-on-first-nonzero': 'if (!firstNonzeroSeen)' in relay and 'if(active)' in relay,
 'pcm-only-not-guidance': 'PCM_NONZERO_ONLY_NOT_GUIDANCE_OR_DRIVER_ONLY_PROOF' in relay,
 'unified-recording-only': 'UnifiedLogCapture.RECORDING' in relay and 'if (recording)' in relay,
 'diagnostics-via-running-service': 'DrivingAlertService.activeDiagnostics' in relay,
 'one-per-relay': 'firstNonzeroSeen = true' in relay,
 'no-pcm-persist': 'appendStatus("FIRST_NONZERO_PCM_ONSET' in relay and 'FileOutputStream(pcm)' not in relay,
 'queued-diagnostics': 'executor.execute { captureInternal(label, COMMANDS_NAV_ONSET, requestedAtMs) }' in collector,
 'only-three-readonly-commands': all(x in collector for x in ['"dumpsys audio"','"dumpsys media.audio_policy"','"dumpsys media.audio_flinger"']),
 'requested-time-folder-selection': 'put("requestedAtMs", requestedAtMs)' in collector and 'diagnosticFolders' in capture,
 'end-awaits-queued-diagnostics': 'captureDeepAndWait("UNIFIED_STOP_' in capture,
 'range-signal-not-mode': 'MODE_ELECTRIC_RANGE_EXCLUDED' in bridge and 'SET_ELECTRIC_RANGE' in gate,
 'display-does-not-announce': 'MODE_DISPLAY_CODE_UNVERIFIED' in bridge and 'MODE_2602_DUAL_SOURCE_CONFIRMED' not in bridge,
 'existing-energy-callback': 'DriveModeDecoder.fromEnergyOperationMode(type)' in bridge,
 'no-vehicle-write': not any(x in gate+collector+relay for x in ('setChannel(', 'setOperationMode(', 'setStreamVolume(', 'setVess(', 'setAvAs(')),
 'no-menu-change': 'section("통합 로그 수집")' in (app/'ui/MainActivity.kt').read_text(),
 'version-code': 'versionCode = 57' in (p/'app/build.gradle.kts').read_text(),
}
for n,v in checks.items(): print(('PASS' if v else 'FAIL'),n)
assert all(checks.values())
print(f'V01730_PCM_ONSET_MODE_GUARD={sum(checks.values())}/{len(checks)}')
