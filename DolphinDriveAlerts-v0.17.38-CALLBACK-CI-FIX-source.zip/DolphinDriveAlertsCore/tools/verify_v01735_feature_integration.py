#!/usr/bin/env python3
"""v0.17.35 immutable feature inventory/voice gates and ZIP audit.
Source-level gates only. Does not claim vehicle/Android APK success.
"""
from pathlib import Path
import re,subprocess,shutil,tempfile,json
root=Path(__file__).resolve().parents[1]
app=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda path:(app/path).read_text(encoding='utf-8')
model=read('model/AlertModels.kt')
catalog=read('model/AlertEventCatalog.kt')
ui=read('ui/AlertEventSettingsActivity.kt')
prefs=read('config/AlertPreferences.kt')
svc=read('service/DrivingAlertService.kt')
main=read('ui/MainActivity.kt')
zipper=read('log/UnifiedLogCapture.kt')
snapshot=read('log/RuntimeFeatureSnapshot.kt')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
gradle=(root/'app/build.gradle.kts').read_text()
from_code=re.findall(r'^    ([A-Z][A-Z_0-9]+)\(',model,re.M)
from_catalog=re.findall(r'Entry\(AlertEvent\.([A-Z][A-Z_0-9]+),',catalog)
from_prompts=json.loads((root/'tools/voice_prompts.json').read_text(encoding='utf-8'))
checks={
 'versionCode-at-least-61': int(re.search(r'versionCode\s*=\s*(\d+)',gradle).group(1)) >= 61,
 '23-detected-events': len(from_code)==23 and len(set(from_code))==23,
 'catalog-complete-no-duplicates': len(from_catalog)==23 and len(set(from_catalog))==23 and set(from_code)==set(from_catalog),
 'voice-prompts-supplied': len(from_prompts)>=23 and len({x['file'] for x in from_prompts})==len(from_prompts),
 'preference-default-is-on': 'getBoolean("alert_event_" + event.name, true)' in prefs,
 'user-setting-is-durable': 'putBoolean("alert_event_" + event.name, enabled).commit()' in prefs,
 'delivery-filter-is-real': 'AlertPreferences.eventEnabled(this, request.event)' in svc and 'audio?.play(request)' in svc,
 'signal-decoding-not-disabled': 'g::submit' in svc,
 'new-activity-is-registered': '.ui.AlertEventSettingsActivity' in manifest,
 'new-activity-uses-own-density': 'DensityAwareActivity()' in ui,
 'all-alerts-in-real-ui': 'AlertEventCatalog.entries.groupBy' in ui and 'CheckBox(this).apply' in ui,
 'safe-write-failure': 'button.setOnCheckedChangeListener(null)' in ui,
 'dashboard-wires-open-activity': 'AlertEventSettingsActivity::class.java' in main,
 'enabled-vs-verified-separated': '허용하는 설정일 뿐' in ui and '현재 차량 알림 신호 미확정' in catalog,
 'read-only-metadata-schema': 'dolphin-feature-runtime-v1' in snapshot and 'carSignalOrAudioRouteVerified", false' in snapshot,
 'one-file-in-session-zip': 'settings/runtime_features.json' in zipper and 'RuntimeFeatureSnapshot.collect(context)' in zipper,
 'previous-capture-archive-preserved': 'nav_audio_lab/' in zipper and 'logs/vehicle_events.jsonl' in zipper,
 'no-oem-setter-added': all(x not in snapshot+ui+catalog for x in ['setVehicleMode','setAVAS','setForcedDisplayDensity','wm density']),
 'original-dashboard-retained': '6).chunked(cardsPerLine)' in main and 'refreshDashboardStatus()' in main,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values()), 'v0.17.35 source gate failed'
if shutil.which('kotlinc'):
  with tempfile.TemporaryDirectory(prefix='v01735_') as tmp:
    k=Path(tmp)/'CatalogSmoke.kt'
    k.write_text('import com.byd.dolphin.drivealerts.model.*\nfun main() {\n val c=AlertEventCatalog.entries\n check(c.size==23)\n check(c.groupBy { it.group }.values.map { it.size }==listOf(8,3,6,6))\n check(c.map { it.event }.toSet()==AlertEvent.values().toSet())\n println("PASS live Kotlin catalog parity + four groups")\n}\n')
    jar=Path(tmp)/'smoke.jar'
    result=subprocess.run(['kotlinc',str(app/'model/AlertModels.kt'),str(app/'model/AlertEventCatalog.kt'),str(k),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=75)
    assert result.returncode==0, result.stdout+result.stderr
    test=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
    assert test.returncode==0, test.stdout+test.stderr
    print(test.stdout.strip())
else: print('SKIP Kotlin compiler absent; GitHub Gradle compilation remains mandatory')
print('V01735_FEATURE_GATES_PASS',len(checks),'SOURCE_ONLY')
