# BYD Dolphin Drive Alerts v0.17.34 — 6개 카드 대시보드 개편

기준: v0.17.33 (versionCode 59), Android 10 / BYD Dolphin Standard / 글로벌 2602 / 1280×720.
새 버전: v0.17.34 (versionCode 60), package `com.byd.dolphin.drivealerts` 그대로 유지.

## 실제 변경
- MainActivity 기존 10개 아코디언 화면을 6개 대시보드 카드 + 상세 화면으로 바꿨습니다.
- 원래 `buildUi()`로 만들어지는 15개 기능 섹션과 기능 버튼·저장 리스너를 재사용하여 누락되지 않도록 매핑했습니다.
- 상태 6개: 주행 서비스 프로세스(진짜 차량 감시 성공 여부 아님), 자동실행, 인증 ADB, 로그, 회전, 출력 경로.
- 빠른 실행 6개: 로그 시작/종료, 읽기 전용 점검, ZIP 공유, 화면 분할 화면, 상태 새로고침.
- 실제 카드: 주행 알림, BSD 알림, 화면·분할, 오디오·내비, 자동 실행·권한, 로그·진단.
- 홈에서 설정으로 이동하고 시스템 뒤로가기/화면 뒤로가기 버튼으로 복귀.
- 차량용 어두운 색상, 화면 너비 기준 1/2/3열 자동 배치, Android 내장 UI만 사용.
- 주행 알림 전체 ON/OFF 노출은 기존 `AlertPreferences.isEnabled/setEnabled` 호출만 이용.
- 순정 UI·차량 ECU·AVAS 설정에 쓰기 명령을 추가하지 않았습니다.

## 기능 세부 메뉴 대응표
| 새 카드 | 기존 화면 및 설정 | 구동 경로 |
|---|---|---|
| 1 주행 알림 | 알림 경로: 운전석(stream14/raw14)/미디어, 음성: 남성/여성/효과음, 핸들 연타 ON/OFF, ECO/NORMAL/SPORT 교정, ICC·차선이탈·앞차출발 설명, 기어·회생제동·오토홀드 엔진 설명 | 기존 AlertPreferences/SteeringTriggerPreferences/DriveModeCalibrationActivity |
| 2 BSD 알림 | 깜빡이 연동, 클릭음 후보(시험), 즉시 일반 경고, 좌우 미확정 상태 설명 | 기존 BSD AlertPreferences 3종 |
| 3 화면·분할 | 2앱 비율/프로필/바로가기/카메라 복원, 전역 회전, 앱 전용 DPI/순정 복구/해상도 정보 | SplitProfilesActivity/AppPolicyActivity/RotationPolicy |
| 4 오디오·내비 | 내비 5종 대상(체크 상태 저장), 순정·5종 오디오 캡처 및 라우팅 연구, EQ/미세강화, 공간확장/Sound Focus/Global Mix | ExternalAppAudioRouter/NavAudioLabActivity/AudioTuningActivity |
| 5 자동 실행·권한 | 자동실행, 다중앱 실행 순서/지연/미디어, 차량 ADB RSA, 접근성·알림·TBT·사용기록·위치·배터리 예외 | AlertPreferences/AutoLaunchSettingsActivity/AdbSetupActivity/AppPermissionManagerActivity |
| 6 로그·진단 | 시작·종료, 읽기 전용 자동점검, ZIP 공유, 순정 AVAS 기록, 내비 경로 기록 | UnifiedLogCapture/DrivingAlertService/MediaStore |

## 검증 완료 (개발 환경)
- 새 6개 대시보드 연결/메뉴 매핑/기존 기능 연결 회귀검사 23개 PASS.
- v0.17.33 앱 전용 DPI Kotlin 설정/저장/복구 모의 실행 및 정적검사 PASS.
- v0.17.34 구버전 기능 호환 검사 PASS (구 테스트의 이전 버전 번호/전역 DPI 강제설정 항목만 명시적 제외).
- 과거 DA-010 로그 ZIP 회귀검사 20/20, Nav Audio Lab 21/21, 실차 신호 오판정 차단 테스트 PASS.
- GitHub workflow YAML 파싱, bash 셸 구문 점검 PASS.
- 소스 ZIP 및 빌드팩의 CRC·SHA256 검사는 패키징 후 확인.

## 미확인 / 유의사항
- Android Gradle APK 실제 조립(assembleDebug) 및 실차 UI 터치·물리 디스플레이 검증은 아직 **미실행**입니다.
- NORMAL 음성, BSD 좌우 구분, 분할 비율 복원, 타사 내비 운전석 단독 출력, 외부 AVAS 음성, 타사 앱별 DPI는 이번 UI 개편만으로 해결되지 않습니다.
- '서비스 프로세스 활성'은 `activeLogger` 존재 여부이며 실제 차 신호 수신 확인이 아닙니다. 상태 불명은 '확인 필요'로 표시합니다.
- ADB는 `AuthorizedAdbRuntime.health` 결과에 따라 인증 완료·승인 필요·포트 닫힘·권한 부족·확인 불가로 표시하며 그 자체가 기능 실행 성공을 보장하지 않습니다.
- HTML 파일은 화면 구조 미리보기이며 실제 차 기능을 실행하지 않습니다.
- 기존 서명키 Secret `DOLPHIN_DEBUG_KEYSTORE_B64`와 인증서 SHA-256 검증은 원래대로 유지합니다. 기존 앱 삭제/초기화 없이 업데이트할 경우 동일 키 필요.
