# v0.17.34 GitHub 빌드 안내

1. GitHub Actions 대상 저장소 최상위에 `DolphinDriveAlerts-v0.17.34-SIX-CARD-DASHBOARD-source.zip` 업로드.
2. `.github/workflows/build-v01734-six-card-dashboard.yml` 위치에 동봉된 yml 업로드.
3. Actions에서 `Build Dolphin Drive Alerts v0.17.34 Six-Card Dashboard` 워크플로 수동 실행.
4. `:app:compileDebugKotlin`, `:app:assembleDebug`, APK 서명 검사 및 `versionCode='60'` 검사 통과 후 ZIP/아티팩트 다운로드.
5. 기존 앱 데이터를 유지하려면 기존 APK와 동일한 서명키를 `DOLPHIN_DEBUG_KEYSTORE_B64`에 넣으세요. 서명이 다르면 덮어쓰기 설치 불가능합니다.

**주의:** 이 팩은 소스와 CI 워크플로입니다. 이 환경에서 Android APK 빌드 및 실차 검증은 실행하지 않았습니다. 사용자 테스트 없이 모든 기능 정상이라고 주장하지 않습니다.

UI 미리보기: `DASHBOARD_PREVIEW_V01734.html`은 웹 브라우저에서 로컬로 열 수 있지만 자동차 앱은 아닙니다.
