# Dolphin Drive Alerts v0.17.31 GitHub 빌드

**이 버전을 최종 시안으로 사용**. 이전에 중복 생성된 `v0.17.30` 후보들은 이번 빌드에 섞지 마세요.

1. GitHub `CP-oss-cell/dolphin-drive-alerts` 최상위에 `DolphinDriveAlerts-v0.17.31-NAV-ONSET-PRIORITY-STATUS-source.zip` 업로드
2. `.github/workflows/build-v01731-nav-onset-priority-status.yml` 경로에 YML 업로드
3. Actions → `Build Dolphin Drive Alerts v0.17.31 Nav Onset Priority and Status` → Run workflow
4. Kotlin 소스/회귀/ZIP 검사 후 APK 빌드와 서명 검증이 통과해야 다운로드 가능

**서명 주의:** 기존 설치 앱 데이터를 유지하려면 `DOLPHIN_DEBUG_KEYSTORE_B64`에 동일 서명키가 있어야 합니다. 임시 신규 디버그 키로 만든 APK는 기존 앱을 덮어쓸 수 없습니다. APK를 삭제하지 마세요. 서명키를 소스 ZIP에 넣지 않습니다.

**실차:** P단에서 기존 로그 수집 시작 → 7번 내비 실험실에서 MediaProjection 허용 → 선택 앱의 실제 음성 재생 → 수집 종료 및 ZIP 공유. 새 자동 진단 폴더에 `03_audio_policy.txt`, `04_audio_flinger.txt`, `02_audio.txt`, `98_capture_status.json`을 확인.

**미해결:** NORMAL 알림과 타사 내비 미디어 원본 출력 차단, BSD 좌우, 분할 비율, 외부 AVAS. 기능 완료로 표기하지 않음.
