# Dolphin Drive Alerts v0.17.31 (2026-10-24)

## 최신본 선정
라이브러리에 이미 존재한 v0.17.30 PCM ONSET MODE GUARD 전체 소스(버전코드 56)를 기준으로 계승. 이전에 추가 생성된 같은 번호의 실험용 소스와 혼동하지 않도록 이번 릴리스를 **v0.17.31 (versionCode 57)**로 분리.

## 실제 소스 변경
1. `SystemDiagnosticsCollector.kt`의 실제 내비 첫 PCM 감지(`COMMANDS_NAV_ONSET`) 자동 수집 순서를 `audio_policy → audio_flinger → audio`로 변경. 짧은 길안내 음성에서 가장 중요한 실제 출력 포트/트랙부터 읽음.
2. 기존 자동 진단의 실패 결과를 `98_capture_status.json`으로 명확히 저장: 요청/완료 시각, totalCommands, successes, failures, COMPLETE/PARTIAL_FAILED_COMMANDS, vehicleWriteOperations=0. 셸 호출 예외도 실패로 기록해 무음/빈 값의 성공 오판 방지.
3. 기존 `UnifiedLogCapture`와 통합 ZIP, 9개 메뉴, 기본 정상 ECO·SPORT, BSD 공통 경고, 2앱 분할 등은 그대로 유지. NORMAL 판정의 거짓 display/range pair 폐기 유지.
4. v0.17.30의 `FIRST_NONZERO_PCM_ONSET` 트리거 및 세션 시점별 폴더 ZIP 자동 포함 동작 유지. `MediaProjection` 승인이 있어야만 다른 앱의 캡처 가능. 

## 미해결 / 보존 사항
- NORMAL 발화: 여전히 실제 정상 확인 전. 순정 SubAI/AutoFeedback 검증된 신호와 추가 대조 필요.
- 5종 내비의 원본 미디어 스피커 출력 차단: **아직 해결되지 않음**. 스트림 14 재생/복사만으로 원본 출력 종료 안 됨.
- 분할 비율·BSD 좌우·AVAS 외부 음성: 실차 성공 미확인.
- 공용 미디어 소리 mute·OEM audio setting write·차량 ECU 변경·서명키 재생성 강제 없음.
- Android 전체 APK 빌드, 실차 v0.17.31 결과는 아직 미확인. 정적/실제 Kotlin 범위만 검증.

## 기존 UI에서의 수집
정차 P에서 기존 로그 수집 시작 → 7번 내비(승인된 UID 캡처) → 음성 안내 실제 재생 → 수집 종료 ZIP. `diagnostics/xxx_NAV_PCM_ONSET_xxx` 폴더에 정책/플링거 및 `98_capture_status.json` 포함 확인. 별도 버튼 추가 없음.
