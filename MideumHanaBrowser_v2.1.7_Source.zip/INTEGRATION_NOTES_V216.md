# 믿음하나 브라우저 v2.1.6 통합 수정 기록

- APK applicationId com.mideumhana.browser, versionName 2.1.6, versionCode 12, Debug CI 빌드 및 기존 ZIP+YML 포장 유지.
- 원인 1: v2.1.5의 WebChromeClient 구현에 onShowCustomView/onHideCustomView 없었음. 웹의 fullscreen 요청이 호스트에서 처리되지 않음.
- 수정 1: Android content FrameLayout에 WebChromeClient의 fullscreen custom view를 별도 오버레이로 추가, FULLSCREEN/IMMERSIVE 플래그 적용 및 원래 상태 복원. Android 뒤로가기·페이지 변경·탭 전환·종료에 정리 루틴 연결. 장치 방향 강제 전환하지 않음.
- 원인 2: 영상 스캔은 확장자/직접 파일 중심; blob/MSE 스트리밍 플레이어는 HTTP(S) 미디어 파일 URL을 제공하지 않을 수 있음. WebView shouldInterceptRequest는 blob: 호출을 제공하지 않음.
- 수정 2: 자바스크립트가 document.video의 존재·재생 여부·blob stream 및 알려진 비디오 iframe을 관찰해 "재생 확인 / 다운로드 URL 미확인" 구분. 직접 URL 없는 YouTube 영상은 임의 파일로 저장하지 않으며, 분할 googlevideo 스트림을 단일 MP4로 오인하지 않음. 기존 MP4/HLS 후보 감지 유지.
- 한계: 유튜브 영상 직접 다운로드가 가능해진 것은 아님; DRM이나 사이트 정책을 우회하지 않음. HTML media DOM 및 iframe 정보가 노출되지 않는 사이트에서는 재생 감지에도 한계가 있음.
- 회귀 검증: tests/v216_fullscreen_stream_regression.py 신규, 기존 tests 테스트 유지. 실 APK/기기 검증 필요.
