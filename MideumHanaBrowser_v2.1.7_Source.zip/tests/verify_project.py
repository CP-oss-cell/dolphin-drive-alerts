from pathlib import Path
from xml.etree import ElementTree
import json
import re
import subprocess

root = Path(__file__).resolve().parents[1]
for file in root.rglob('*.xml'):
    ElementTree.parse(file)
    print('XML_OK', file.relative_to(root))

source = '\n'.join(f.read_text() for f in root.rglob('*.java'))
for forbidden in ('com.google.android.gms.ads', 'com.applovin.sdk', 'com.facebook.ads.',
                  'VideoView(', 'new MediaPlayer(', 'ExoPlayer.Builder(',
                  'setAllowFileAccess(true)', 'handler.proceed()'):
    assert forbidden not in source, f'Unsupported/insecure feature: {forbidden}'

manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
# Guard the exact Android import mistake that broke v1.0.3 on GitHub CI.
assert 'import android.os.WindowInsets;' not in source, 'WindowInsets belongs to android.view'
assert 'import android.view.WindowInsets;' in source
assert 'WindowInsets.Type.systemBars()' in source
assert 'android.os.Build.VERSION.SDK_INT >= 35' in source
assert 'android.permission.INTERNET' in manifest
assert 'FOREGROUND_SERVICE_DATA_SYNC' in manifest
assert 'android:exported="false"' in manifest
assert 'usesCleartextTraffic' in manifest

assert 'android:horizontalScrollBarEnabled' not in (root / 'app/src/main/res/layout/activity_main.xml').read_text(), 'Unsupported AAPT XML scrollbar attribute'
main = (root / 'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
script = root / 'app/src/main/assets/video_scan.js'
assert script.is_file()
js = script.read_text()
assert 'return JSON.stringify({page:location.href,videos:media,player:player})' in js
assert 'CleanVideoMedia.' not in js
assert 'addJavascriptInterface' not in main
assert 'new JSONTokener(json)' in main
assert 'StorageTarget.selected(this)' in main
assert 'HlsQualityResolver.inspect' in main
assert 'VideoCandidate' in main
assert 'ACTION_OPEN_DOCUMENT_TREE' in main
subprocess.run(['node', '--check', str(script)], check=True)
print('JS_SYNTAX_OK, SECURITY_CHECKS_OK')

# R02: a player signal must not boost every HLS resource discovered on the page.
assert 'c.observe(3, width, height, duration, true, null)' not in main
assert 'candidate.observe(3, 480, 270, embeddedDuration' not in main
print('R02_HLS_CROSS_PROMOTION_GUARD_OK')
# R03: prevent silent downloads when master playlists reference separate audio renditions.
resolver = (root / 'app/src/main/java/com/mideumhana/browser/HlsQualityResolver.java').read_text()
service = (root / 'app/src/main/java/com/mideumhana/browser/HlsDownloadService.java').read_text()
assert 'AUDIO=' in resolver and '분리된 오디오' in resolver
assert 'separateAudio' in service and '무음 영상 방지' in service
print('R03_SEPARATE_AUDIO_GUARD_OK')
