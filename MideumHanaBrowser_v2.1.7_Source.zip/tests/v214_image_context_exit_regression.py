"""v2.1.4 image and navigation feature structural regression, not an Android device test."""
from pathlib import Path
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
svc=(root/'app/src/main/java/com/mideumhana/browser/HlsDownloadService.java').read_text()
mime=(root/'app/src/main/java/com/mideumhana/browser/MediaTypes.java').read_text()
layout=ET.parse(root/'app/src/main/res/layout/activity_main.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
ids=[node.get(ns+'id') for node in layout.iter() if node.get(ns+'id')]
assert ids.index('@+id/back') < ids.index('@+id/home') < ids.index('@+id/forward')
home=next(n for n in layout.iter() if n.get(ns+'id')=='@+id/home')
assert home.tag=='ImageButton' and home.get(ns+'src')=='@drawable/ic_home'
assert (root/'app/src/main/res/drawable/ic_home.xml').is_file()
assert ids.index('@+id/settings_menu')+1==ids.index('@+id/exit_app')
assert 'findViewById(R.id.exit_app).setOnClickListener(v -> confirmExitApp());' in main
assert 'persistTabs();' in main[main.index('private void confirmExitApp()'):main.index('private void confirmCloseQuickTab(')]
for term in ['"이미지 다운로드"','"이미지 열기 (현재 탭)"','"이미지를 새 탭에서 열기"',
             '"이미지 주소 복사"','"이미지 주소 공유"','"연결된 링크 복사"',
             'details.getString("src")','details.getString("url")','showLongPressResourceMenu',
             'private void offerImageDownload(', '"image", StorageTarget.selected(this)',
             'finishAffinity()', 'HlsDownloadService.ACTION_CANCEL',
             'ClipData.newPlainText','return false;\n    }\n\n    private void showLongPressResourceMenu']:
    assert term in main, term
assert '"service-image".equals(old.optString("type"))' in svc
assert 'MediaTypes.fromFileName(item.optString("name"))' in svc
assert 'MediaTypes.fromFileName(entry.optString("name"))' in main
for ext in ('jpg','jpeg','png','gif','webp','bmp','avif','heic','svg'):
    assert '.%s'%ext in mime, ext
assert 'versionCode 13' in (root/'app/build.gradle').read_text()
print('V214_CONTEXT_IMAGE_DOWNLOAD_NAV_EXIT_STATIC_OK')
