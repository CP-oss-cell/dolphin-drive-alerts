from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
layout = (root/'app/src/main/res/layout/activity_main.xml').read_text()
build = (root/'app/build.gradle').read_text()
assert "versionCode 13" in build and "versionName '2.1.7'" in build
assert 'com.mideumhana.browser' in build
assert 'android:text="설정"' in layout
assert '@+id/settings_menu' in layout
assert 'web_tab_strip' not in layout
assert 'setOnClickListener(v -> showSettingsDialog())' in main
assert 'new GridLayout(this)' in main and 'grid.setColumnCount(columns)' in main
assert 'setOnClickListener(v -> { dialog[0].dismiss(); activateTab(tab); })' in main
assert 'closeWebTab(tab); showTabPicker(false)' in main
assert 'MAX_WEB_TABS = 8' in main
assert 'showHomeAddressEditor()' in main
assert 'showBookmarkHomePicker()' in main
assert 'saveHome(url)' in main
assert '"현재 페이지를 홈으로"' in main
assert 'setMessage("현재 홈: " + homeUrl())' not in main
assert 'browser.clearCache(true)' in main
assert 'CookieManager.getInstance().removeAllCookies' in main
assert 'WebStorage.getInstance().deleteAllData()' in main
assert '다운로드한 동영상은 유지' in main
assert '현재 사이트 배율 초기화' in main
assert 'chooseFolder()' in main
ET.fromstring(layout)
print('V211_SETTINGS_CARD_TAB_REGRESSION_OK')
