"""v2.1.7 static integration and privacy boundary checks, not an Android device test."""
from pathlib import Path
import re
import subprocess
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/mideumhana/browser'
main=(src/'MainActivity.java').read_text()
diag=(src/'BrowserDiagnostics.java').read_text()
service=(src/'HlsDownloadService.java').read_text()
backup=(src/'BrowserBackup.java').read_text()
site=(src/'SiteCompatibility.java').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
build=(root/'app/build.gradle').read_text()
assert 'versionCode 13' in build and "versionName '2.1.7'" in build
assert 'android:name=".BrowserApp"' in manifest
assert 'APP_UNCAUGHT' in diag and 'getClass().getSimpleName()' in diag
for t in ('MAX_LOG_BYTES = 256 * 1024', 'ARCHIVES = 3', 'synchronized (FILE_LOCK)',
          'getFilesDir()', 'ZipOutputStream', 'MediaStore.Downloads.EXTERNAL_CONTENT_URI',
          'Environment.DIRECTORY_DOWNLOADS + "/믿음하나/진단/"', 'IS_PENDING',
          'FLAG_GRANT_READ_URI_PERMISSION' if False else 'REDACTED',
          'export(Context appContext)', 'ZipEntry', 'application/zip',
          'getCurrentWebViewPackage()', 'failureCategory'):
    assert t.lower() in diag.lower(),t
assert 'setDefaultUncaughtExceptionHandler' in (src/'BrowserApp.java').read_text()
assert 'send.putExtra(Intent.EXTRA_STREAM, output)' in main
assert 'Intent.createChooser(send,' in main
assert 'startActivity(Intent.createChooser(send,' in main
for t in ('진단·오류 신고 (ZIP 생성·공유)', 'exportDiagnostics()',
          'showSiteCompatibility()', 'SiteCompatibility.adBlock',
          'SiteCompatibility.videoScan', 'FULLSCREEN', 'PAGE', 'WEB_ERROR',
          'VIDEO_SCAN', 'VIDEO_PICKER', 'PREF_TAB_SCROLLS', 'pendingRestoreScrollY',
          'setOnScrollChangeListener', 'ui.postDelayed(saveScroll, 1800)',
          'BrowserDiagnostics.event(this, "MEMORY"'):
    assert t in main,t
for t in ('RETRY_', 'FAILED_', 'CANCEL_REQUEST', 'COMPLETED', 'PAUSED'):
    assert t in service,t
assert 'site_compat' in backup and 'tab_scroll' in backup
assert 'validateBackup' in site and 'backup(Context c)' in site
assert 'CookieManager' not in diag and 'getCookie(' not in diag
assert 'Log.getStackTraceString' not in diag and 'printStackTrace' not in diag
assert 'request.getUrl().toString()' not in diag
assert not re.search(r'data\.put\([^;]+(?:uri|url|token|cookie|title)',diag,re.I)
assert 'Upload' not in diag and 'HttpURLConnection' not in diag
ElementTree.parse(root/'app/src/main/AndroidManifest.xml')
for t in ('com.mideumhana.browser','minSdk 29', 'targetSdk 35'):
    assert t in build
print('V217_DIAG_PRIVACY_SITE_RESTORE_STATIC_OK')
