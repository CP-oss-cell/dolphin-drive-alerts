"""v2.1.6: static and simulated playback scan checks; not a real YouTube download test."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
media=(root/'app/src/main/java/com/mideumhana/browser/MediaDetector.java').read_text()
build=(root/'app/build.gradle').read_text()
assert "versionCode 13" in build and "versionName '2.1.7'" in build
for token in ('onShowCustomView(View view', 'onHideCustomView()',
              'enterVideoFullscreen(web, view, callback)',
              'leaveVideoFullscreen(false)', 'leaveVideoFullscreen(true)',
              'getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)',
              'getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)',
              'previousSystemUiVisibility', 'fullscreenLayer != null',
              'onBackPressed()', 'fullscreenOwner == view'):
    assert token in main, token
for token in ('isYoutubePage', 'isOpaqueStreamUrl', 'googlevideo.com',
              'youtube-nocookie.com'):
    assert token in media, token
for token in ('player.optBoolean("playing"', 'player.optBoolean("opaqueStream"',
              'tab.playerPresent', '다운로드 가능한 파일 주소 없음',
              '유튜브 재생 확인 · 다운로드 제한',
              'MediaDetector.isOpaqueStreamUrl(url)'):
    assert token in main, token
script=root/'app/src/main/assets/video_scan.js'
js=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(process.argv[1],'utf8');
function run(url,vid,resources=[],iframes=[]) {
 const w={};w.top=w;
 const ctx={window:w,location:{href:url},document:{baseURI:url,
   querySelectorAll:(sel)=>sel==='video'?[vid]:sel==='iframe[src]'?iframes:[]},
   performance:{getEntriesByType:()=>resources.map(name=>({name}))},
   URL,Math,isFinite,JSON,Object,innerHeight:900};
 return JSON.parse(vm.runInNewContext(source,ctx));
}
let yt={paused:false,ended:false,readyState:4,videoWidth:1920,videoHeight:1080,
 duration:500,currentSrc:'blob:https://www.youtube.com/fake-blob',src:'',
 getBoundingClientRect:()=>({width:500,height:360,bottom:400,top:0}),
 closest:()=>null,querySelectorAll:()=>[]};
let a=run('https://www.youtube.com/watch?v=123456789',yt);
assert.equal(a.videos.length,0); // No blob URL must be promoted as a downloadable file.
assert.equal(a.player.videoElements,1);
assert.equal(a.player.playing,true);
assert.equal(a.player.opaqueStream,true);
let normal={...yt,currentSrc:'https://cdn.example.org/valid.mp4'};
let b=run('https://example.org/watch',normal,[]);
assert.equal(b.videos.length,1);
assert.equal(b.videos[0].source,3);
assert.equal(b.videos[0].playing,true);
assert.equal(b.player.opaqueStream,false);
let frame={getAttribute:(k)=>k==='src'?'https://www.youtube.com/embed/abc':''};
let c=run('https://example.org/embedded',{...normal,paused:true,readyState:0,
 currentSrc:'',getBoundingClientRect:()=>({width:0,height:0,bottom:0,top:0})},[],[frame]);
assert.equal(c.player.embeddedPlayer,true);
assert.equal(c.player.playing,false);
console.log('V216_PLAYBACK_DETECTION_NO_FAKE_DOWNLOAD_OK');
'''
subprocess.run(['node','-e',js,str(script)],check=True)
print('V216_FULLSCREEN_STRUCTURAL_OK')
