"""v2.1.5 integration checks. These are structural/offline tests, not an APK device test."""
from pathlib import Path
from xml.etree import ElementTree as ET
import subprocess
import json

root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
backup=(root/'app/src/main/java/com/mideumhana/browser/BrowserBackup.java').read_text()
service=(root/'app/src/main/java/com/mideumhana/browser/HlsDownloadService.java').read_text()
script=root/'app/src/main/assets/video_scan.js'
video=(root/'app/src/main/java/com/mideumhana/browser/VideoCandidate.java').read_text()

assert 'versionName \'2.1.7\'' in (root/'app/build.gradle').read_text()
assert 'versionCode 13' in (root/'app/build.gradle').read_text()
for term in ('exportToDownloads', 'parseBackup', 'restore(', 'MAX_BYTES = 512 * 1024',
             'MediaStore.Downloads.EXTERNAL_CONTENT_URI','Environment.DIRECTORY_DOWNLOADS + "/믿음하나/백업/"',
             'validScaleKey', 'MediaDetector.validWebUrl',
             'mideumhana-browser-backup','bookmarks', 'saved_tabs_v3', 'site_zoom'):
    assert term in backup, term
for secret in ('CookieManager', 'getCookie(', 'password', 'downloads\"'):
    assert secret not in backup or secret == 'password', 'backup should exclude private session/history'
for term in ('exportBrowserBackup', 'confirmRestoreBackup', 'BACKUP_IMPORT_PICKER',
             'ACTION_OPEN_DOCUMENT', 'replacingSettingsFromBackup = true',
             'FLAG_ACTIVITY_CLEAR_TASK', 'showSettingsDialog',
             'brandTitle.setVisibility(widthDp < 600 ? View.GONE : View.VISIBLE)',
             'onTrimMemory(int level)', 'savedWebState', 'old.saveState(state)',
             'tab.web == null', 'tab.title()', 'tab.url()',
             'shareCompletedDownload', 'resolveCompletedUri',
             'Intent.ACTION_SEND', 'Intent.EXTRA_STREAM',
             'ACTION_SHARE_FILE', 'ACTION_DOWNLOAD_FILE',
             'maybeRequestNotificationPermission'):
    assert term in main, term
for term in ('MAX_NETWORK_ATTEMPTS = 3', 'TransientNetworkException',
             'requireSuccess(', 'retryable(', 'Thread.sleep(500L)',
             'ACTION_SHARE_FILE', 'ACTION_DOWNLOAD_FILE', '파일 열기', '파일 공유'):
    assert term in service, term
assert 'Thread.sleep(500L)' in service
assert 'adHint' in video and 'lastPlayingAt' in video
assert 'adHint' in main and 'candidate.observe(source, width, height, duration, playing, pageUri.getHost(), adHint)' in main
ET.parse(root/'app/src/main/res/layout/activity_main.xml')
ns='{http://schemas.android.com/apk/res/android}'
layout=ET.parse(root/'app/src/main/res/layout/activity_main.xml').getroot()
assert any(node.get(ns+'id')=='@+id/brand_title' for node in layout.iter())
# Simulated real scan: resource is registered before the playing video; outcome must be one promoted entry.
node=r'''
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(process.argv[1],'utf8');
const video={paused:false,ended:false,readyState:4,videoWidth:1920,videoHeight:1080,duration:800,
 currentSrc:'https://cdn.example.org/main.mp4',src:'',
 getBoundingClientRect:()=>({width:600,height:400,bottom:400,top:0}),
 closest:()=>null,querySelectorAll:()=>[]};
const win={};win.top=win;
const ctx={window:win,location:{href:'https://example.org/watch'},
 document:{baseURI:'https://example.org/watch',querySelectorAll:()=>[video]},
 performance:{getEntriesByType:()=>[{name:'https://cdn.example.org/main.mp4'},
 {name:'https://ads.example.org/ads/preroll.mp4'}]},
 innerHeight:900,URL,Math,isFinite,JSON,Object};
let r=JSON.parse(vm.runInNewContext(source,ctx));
assert.equal(r.videos.length,2);
assert.equal(r.videos[0].url,'https://cdn.example.org/main.mp4');
assert.equal(r.videos[0].source,3);
assert.equal(r.videos[0].playing,true);
assert.equal(r.videos[0].duration,800);
assert.equal(r.videos[0].adHint,false);
console.log('V215_JS_DUPLICATE_PROMOTION_OK');
'''
subprocess.run(['node','-e',node,str(script)],check=True)
print('V215_BACKUP_RESUME_MEMORY_FOLD_SHARE_STATIC_OK')
