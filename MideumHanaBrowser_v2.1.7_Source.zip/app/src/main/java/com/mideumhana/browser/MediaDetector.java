package com.mideumhana.browser;

import android.net.Uri;
import android.webkit.URLUtil;
import java.util.Locale;

final class MediaDetector {
    private MediaDetector() {}

    static boolean validWebUrl(String url) {
        if (url == null || url.length() > 8192) return false;
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            return ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))
                    && uri.getHost() != null && !uri.getHost().isEmpty()
                    && uri.getEncodedUserInfo() == null; // Reject misleading embedded credentials.
        } catch (Exception ignored) {
            return false;
        }
    }

    static boolean isYoutubePage(String url) {
        if (!validWebUrl(url)) return false;
        String host = Uri.parse(url).getHost().toLowerCase(Locale.ROOT);
        if (host.equals("youtu.be")) return true;
        boolean youtubeHost = host.equals("youtube.com") || host.endsWith(".youtube.com")
                || host.equals("youtube-nocookie.com")
                || host.endsWith(".youtube-nocookie.com");
        if (!youtubeHost) return false;
        String path = Uri.parse(url).getPath();
        if (path == null) return false;
        return path.equals("/watch") || path.startsWith("/shorts/")
                || path.startsWith("/live/") || path.startsWith("/embed/")
                || path.startsWith("/clip/");
    }

    /** Segmented media delivery cannot be treated as a normal downloadable file. */
    static boolean isOpaqueStreamUrl(String url) {
        if (!validWebUrl(url)) return true;
        Uri parsed = Uri.parse(url);
        String host = parsed.getHost().toLowerCase(Locale.ROOT);
        String path = parsed.getPath() == null ? "" : parsed.getPath().toLowerCase(Locale.ROOT);
        return (host.equals("googlevideo.com") || host.endsWith(".googlevideo.com"))
                && path.contains("/videoplayback");
    }

    static boolean isHls(String url) {
        if (!validWebUrl(url)) return false;
        String path = Uri.parse(url).getPath();
        return path != null && path.toLowerCase(Locale.ROOT).endsWith(".m3u8");
    }

    static boolean looksLikeVideo(String url) {
        if (!validWebUrl(url)) return false;
        String path = Uri.parse(url).getPath();
        if (path == null) return false;
        String p = path.toLowerCase(Locale.ROOT);
        return p.endsWith(".mp4") || p.endsWith(".m4v") || p.endsWith(".mov")
                || p.endsWith(".webm") || p.endsWith(".avi") || p.endsWith(".wmv")
                || p.endsWith(".flv") || p.endsWith(".3gp") || p.endsWith(".m3u8")
                || p.endsWith(".mpeg") || p.endsWith(".mpg");
    }

    static boolean adLike(String url) {
        if (!validWebUrl(url)) return true;
        Uri u = Uri.parse(url);
        if (AdBlock.blocked(u)) return true;
        String p = (u.getPath() == null ? "" : u.getPath()).toLowerCase(Locale.ROOT);
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
        return host.startsWith("ads.") || host.startsWith("adserver.")
            || p.matches(".*(?:^|[/_.-])(preroll|midroll|postroll|vpaid|vast|sponsor|advert|adserver|adclip|interstitial)(?:[/_.-]|$).*")
            || p.contains("/ads/") || p.contains("/ad/");
    }

    static String guessName(String url, String contentDisposition, String mime) {
        String guess = URLUtil.guessFileName(url, contentDisposition, mime);
        if (guess == null || guess.trim().isEmpty() || guess.equals("downloadfile.bin")) {
            guess = "video_" + System.currentTimeMillis() + ".mp4";
        }
        if (isHls(url)) {
            int dot = guess.lastIndexOf('.');
            guess = (dot > 0 ? guess.substring(0, dot) : guess) + ".ts";
        }
        return DownloadStore.safeFileName(guess);
    }
}
