package com.mideumhana.browser;

import android.net.Uri;
import java.util.Locale;

/** Heuristic ranking only: do not assert perfect advertising detection or DRM support. */
final class VideoCandidate {
    final String url;
    private int score;
    int width, height, duration;
    boolean active;
    boolean adHint;
    int source;
    String pageHost = "";
    long lastPlayingAt;
    VideoCandidate(String url) { this.url = url; }

    void observe(int source, int width, int height, int duration,
                 boolean playing, String pageHost, boolean adHint) {
        this.source = Math.max(this.source, source);
        this.width = Math.max(this.width, width);
        this.height = Math.max(this.height, height);
        this.duration = Math.max(this.duration, duration);
        this.adHint |= adHint;
        if (pageHost != null) this.pageHost = pageHost;
        if (playing) lastPlayingAt = (System.nanoTime() / 1000000L);
        refresh();
    }

    // Compatible with pre-v2.1.5 callers and offline regression harnesses.
    void observe(int source, int width, int height, int duration,
                 boolean playing, String pageHost) {
        observe(source, width, height, duration, playing, pageHost, false);
    }

    void refresh() {
        active = lastPlayingAt > 0 && (System.nanoTime() / 1000000L) - lastPlayingAt < 8000;
        int points = this.source == 3 ? 85 : this.source == 2 ? 60 : 22;
        if (this.active) points += 52;
        if (this.width >= 480 && this.height >= 270) points += 18;
        if (this.duration >= 60) points += 18;
        if (this.duration >= 600) points += 7;
        // Protect valid user-played short clips, but demote short, idle ad-like resources.
        if (this.duration > 0 && this.duration < 45 && !this.active) points -= 60;
        else if (this.duration >= 45 && this.duration < 90 && !this.active) points -= 12;
        else if (this.duration == 0 && this.source == 2 && !this.active) points -= 20;
        Uri uri = Uri.parse(url);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
        if (!pageHost.isEmpty() && host.equalsIgnoreCase(pageHost)) points += 6;
        if (MediaDetector.adLike(url)) points -= 200;
        if (adHint) points -= 150;
        if (path.contains("thumbnail") || path.contains("preview") || path.contains("teaser"))
            points -= 70;
        score = points;
    }

    int score() { return score; }
    boolean recommended() { return score >= 65 && !adHint; }
    boolean allowed() { return score >= 25 && !MediaDetector.adLike(url); }
    String qualityLabel() {
        if (height >= 360) return height + "p";
        String p = Uri.parse(url).getPath();
        if (p != null) {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?i)(?:^|[^\\d])(2160|1440|1080|720|480|360)p(?:[^\\d]|$)")
                    .matcher(p);
            if (m.find()) return m.group(1) + "p (주소 기준)";
        }
        return "화질 미확인";
    }
}
