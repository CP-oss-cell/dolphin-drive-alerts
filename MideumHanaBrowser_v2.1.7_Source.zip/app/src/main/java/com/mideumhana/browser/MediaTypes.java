package com.mideumhana.browser;

import java.util.Locale;

/** File type used both for MediaStore publication and Android viewing intents. */
final class MediaTypes {
    private MediaTypes() {}
    static String imageSuffixForContentType(String contentType) {
        if (contentType == null) return "";
        String type = contentType.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
        switch (type) {
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/webp": return ".webp";
            case "image/gif": return ".gif";
            case "image/avif": return ".avif";
            case "image/bmp": return ".bmp";
            case "image/heic": return ".heic";
            case "image/heif": return ".heif";
            case "image/svg+xml": return ".svg";
            default: return "";
        }
    }
    static String fromFileName(String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".jpe")) return "image/jpeg";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".bmp")) return "image/bmp";
        if (lower.endsWith(".avif")) return "image/avif";
        if (lower.endsWith(".heic")) return "image/heic";
        if (lower.endsWith(".heif")) return "image/heif";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".ts")) return "video/mp2t";
        if (lower.endsWith(".webm")) return "video/webm";
        if (lower.endsWith(".mov")) return "video/quicktime";
        if (lower.endsWith(".m4v")) return "video/x-m4v";
        return "video/mp4";
    }
}
