package com.mideumhana.browser;

import android.app.Application;

/** Start diagnostics in both the browser and download-service process. */
public final class BrowserApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        BrowserDiagnostics.event(this, "APP_PROCESS", "START");
        Thread.UncaughtExceptionHandler original = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try { BrowserDiagnostics.crash(this, throwable); }
            catch (Throwable ignored) { }
            if (original != null) original.uncaughtException(thread, throwable);
            else android.os.Process.killProcess(android.os.Process.myPid());
        });
    }
}
