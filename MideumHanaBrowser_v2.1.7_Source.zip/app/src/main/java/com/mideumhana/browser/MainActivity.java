package com.mideumhana.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Insets;
import android.graphics.Color;
import android.view.WindowManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.os.Build;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.view.ViewGroup;
import java.util.HashSet;
import java.util.Set;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONTokener;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * A clean-room implementation: browser + video detection + downloads.
 * No advertising, analytics, bundled player, or third-party dependencies.
 */
public final class MainActivity extends Activity {
    static final String ACTION_DOWNLOAD_FILE = "com.mideumhana.browser.ACTION_DOWNLOAD_FILE";
    static final String ACTION_SHARE_FILE = "com.mideumhana.browser.ACTION_SHARE_FILE";
    private static final String HOME = "https://www.google.com/";
    private static final int FOLDER_PICKER = 6601;
    private static final int BACKUP_IMPORT_PICKER = 6602;
    private String scanScript = "";
    private String pendingUrl;
    private String pendingName;
    // Each tab owns its browser history, candidates and navigation epoch.
    private static final class BrowserTab {
        WebView web; // Null only while safely hibernated under Android memory pressure.
        volatile String savedUrl = "";
        String savedTitle = "";
        Bundle savedWebState;
        long lastUsedAt = android.os.SystemClock.uptimeMillis();
        final LinkedHashMap<String, VideoCandidate> candidates = new LinkedHashMap<>();
        volatile long epoch = 0;
        volatile long lastPinchAt = 0;
        String lastScannedPage = "";
        // Read-only playback observation, not evidence of an accessible download URL.
        boolean playerPresent;
        boolean playerPlaying;
        boolean opaqueStream;
        boolean embeddedPlayer;
        int savedScrollY;
        int pendingRestoreScrollY = -1;
        String diagnosticPlaybackState = "";
        BrowserTab(WebView view) { this.web = view; }
        String url() { return web != null && MediaDetector.validWebUrl(web.getUrl())
                ? web.getUrl() : savedUrl; }
        String title() { return web != null && web.getTitle() != null
                ? web.getTitle() : savedTitle; }
    }
    private final CopyOnWriteArrayList<BrowserTab> webTabs = new CopyOnWriteArrayList<>();
    private final Map<WebView, BrowserTab> tabLookup = new ConcurrentHashMap<>();
    private volatile BrowserTab activeTab;
    private FrameLayout webContainer;
    // WebChromeClient hands fullscreen video rendering to the host Activity.
    private FrameLayout fullscreenLayer;
    private WebView fullscreenOwner;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private int previousSystemUiVisibility;
    private boolean previousWindowFullscreen;
    private TextView dashboardStatus;
    private TextView brandTitle;
    private Button openTabs;
    private HorizontalScrollView quickTabsScroll;
    private LinearLayout quickTabsStrip;
    private static final int MAX_WEB_TABS = 8;
    private static final String BROWSER_PREFS = "mideumhana_browser_ui";
    private static final String PREF_HOME_URL = "homepage";
    private static final String PREF_TABS = "saved_tabs_v3";
    private static final String PREF_SELECTED_TAB = "saved_tab_index_v3";
    private static final String PREF_TAB_SCROLLS = "saved_tab_scrolls_v1";
    private boolean exportingDiagnostics = false;
    private final Runnable saveScroll = this::persistTabs;
    private long automaticZoomUntil = 0;
    private boolean replacingSettingsFromBackup = false;
    private final List<DownloadRow> downloadRows = new ArrayList<>();
    private final Set<String> selectedDownloadIds = new HashSet<>();
    private BaseAdapter downloadsAdapter;
    private boolean selectingDownloads = false;
    private View downloadBulkActions;

    private static final class DownloadRow {
        final String id;
        JSONObject entry;
        String status;
        int progress;
        DownloadRow(JSONObject entry, String status, int progress) {
            this.entry = entry; this.id = entry.optString("id");
            this.status = status; this.progress = progress;
        }
        String label() {
            String pct = progress > 0 || status.startsWith("완료") ? " · " + progress + "%"
                    : status.startsWith("다운로드 중") ? " · 진행률 계산 중" : "";
            long bytes = entry.optLong("bytes", 0);
            long total = entry.optLong("total", -1);
            long speed = entry.optLong("speed", 0);
            long eta = entry.optLong("eta", -1);
            String details = bytes > 0 ? "\n" + readableSize(bytes) +
                    (total > 0 ? " / " + ("true".equals(entry.optString("estimated")) ? "약 " : "")
                            + readableSize(total) : "") : "";
            if (speed > 0 && status.startsWith("다운로드 중"))
                details += " · " + readableSize(speed) + "/초" +
                    (eta >= 0 ? " · 약 " + readableTime(eta) + " 남음" : "");
            return entry.optString("name") + "\n" + status + pct + details;
        }
    }

    private static String readableSize(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return String.format(Locale.KOREA, "%.1fKB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.KOREA, "%.1fMB", bytes / 1048576.0);
        return String.format(Locale.KOREA, "%.2fGB", bytes / 1073741824.0);
    }
    private static String readableTime(long seconds) {
        return seconds >= 3600 ? (seconds / 3600) + "시간 " + (seconds % 3600 / 60) + "분"
                : seconds >= 60 ? (seconds / 60) + "분 " + (seconds % 60) + "초" : seconds + "초";
    }

    private final Runnable scanTick = new Runnable() {
        @Override public void run() {
            if (browser != null && browser.getVisibility() == View.VISIBLE && !isFinishing()) {
                runScan();
                ui.postDelayed(this, 4000);
            }
        }
    };
    private LinearLayout detectedCard;
    private android.widget.TextView detectedSummary;
    private Button quickDownload;
    private Button moreVideos;
    private Button selectFolder;
    private android.widget.TextView folderLabel;
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private View downloadsPanel;
    private View bookmarksPanel;
    private ListView downloadsList;
    private ListView bookmarksList;
    private Button tabWeb;
    private Button tabDetect;
    private Button tabDownloads;
    private Button tabBookmarks;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
                renderDownloads();
                ui.postDelayed(this, 2000);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        BrowserDiagnostics.event(this, "ACTIVITY", "CREATE");
        DownloadStore.reconcile(this);
        BrowserDiagnostics.event(this, "DOWNLOAD", "RECOVERY_CHECK");
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets p = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(p.left, p.top, p.right, p.bottom);
                return insets;
            });
        }
        address = findViewById(R.id.address);
        progress = findViewById(R.id.progress);
        browser = findViewById(R.id.browser);
        webContainer = findViewById(R.id.web_container);
        dashboardStatus = findViewById(R.id.dashboard_status);
        brandTitle = findViewById(R.id.brand_title);
        openTabs = findViewById(R.id.open_tabs);
        quickTabsScroll = findViewById(R.id.quick_tabs_scroll);
        quickTabsStrip = findViewById(R.id.quick_tabs_strip);
        openTabs.setOnClickListener(v -> showTabPicker(false));
        openTabs.setOnLongClickListener(v -> { showTabPicker(true); return true; });
        findViewById(R.id.home).setOnClickListener(v -> { showPanel("web"); browser.loadUrl(homeUrl()); });
        findViewById(R.id.home).setOnLongClickListener(v -> {
            showHomeSettings(); return true;
        });
        findViewById(R.id.settings_menu).setOnClickListener(v -> showSettingsDialog());
        findViewById(R.id.exit_app).setOnClickListener(v -> confirmExitApp());
        downloadsPanel = findViewById(R.id.downloads_panel);
        bookmarksPanel = findViewById(R.id.bookmarks_panel);
        downloadsList = findViewById(R.id.downloads_list);
        bookmarksList = findViewById(R.id.bookmarks_list);
        downloadBulkActions = findViewById(R.id.download_bulk_actions);
        installDownloadAdapter();
        findViewById(R.id.select_downloads).setOnClickListener(v -> setDownloadSelection(!selectingDownloads));
        findViewById(R.id.select_all_downloads).setOnClickListener(v -> {
            if (selectedDownloadIds.size() == downloadRows.size()) selectedDownloadIds.clear();
            else { selectedDownloadIds.clear(); for (DownloadRow row : downloadRows) selectedDownloadIds.add(row.id); }
            redrawDownloadSelection();
        });
        findViewById(R.id.stop_downloads).setOnClickListener(v -> performBulk("stop"));
        findViewById(R.id.retry_downloads).setOnClickListener(v -> performBulk("retry"));
        findViewById(R.id.delete_downloads).setOnClickListener(v -> confirmDeleteSelected());
        detectedCard = findViewById(R.id.detected_card);
        detectedSummary = findViewById(R.id.detected_summary);
        quickDownload = findViewById(R.id.quick_download);
        moreVideos = findViewById(R.id.more_videos);
        selectFolder = findViewById(R.id.select_folder);
        folderLabel = findViewById(R.id.folder_label);
        try (InputStream in = getAssets().open("video_scan.js")) {
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            byte[] bytes = new byte[4096];
            int n;
            while ((n = in.read(bytes)) != -1) data.write(bytes, 0, n);
            scanScript = new String(data.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { toast("영상 감지 모듈을 불러오지 못했습니다"); }
        quickDownload.setOnClickListener(v -> {
            VideoCandidate top = bestCandidate();
            if (top != null) offerDownload(top.url, friendlyName(top.url));
            else showVideos();
        });
        moreVideos.setOnClickListener(v -> showVideos());
        findViewById(R.id.quick_folder).setOnClickListener(v -> chooseFolder());
        selectFolder.setOnClickListener(v -> chooseFolder());
        findViewById(R.id.reset_folder).setOnClickListener(v -> {
            StorageTarget.reset(this);
            refreshFolderLabel();
            toast("기본 다운로드 폴더를 사용합니다");
        });
        refreshFolderLabel();
        tabWeb = findViewById(R.id.tab_web);
        tabDetect = findViewById(R.id.tab_detect);
        tabDownloads = findViewById(R.id.tab_downloads);
        tabBookmarks = findViewById(R.id.tab_bookmarks);

        BrowserTab firstTab = registerTab(browser);
        configureBrowser(browser);
        findViewById(R.id.new_web_tab).setOnClickListener(v -> openNewWebTab(homeUrl(), true));
        findViewById(R.id.back).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoBack()) browser.goBack();
        });
        findViewById(R.id.forward).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoForward()) browser.goForward();
        });
        findViewById(R.id.go).setOnClickListener(v -> navigate());
        findViewById(R.id.go).setOnLongClickListener(v -> { browser.reload(); return true; });
        findViewById(R.id.star).setOnClickListener(v -> {
            if (MediaDetector.validWebUrl(browser.getUrl())) {
                Bookmarks.add(this, browser.getTitle(), browser.getUrl());
                toast("즐겨찾기에 저장했습니다");
            }
        });
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate();
                return true;
            }
            return false;
        });
        tabWeb.setOnClickListener(v -> showPanel("web"));
        tabWeb.setOnLongClickListener(v -> { showPanel("web"); browser.loadUrl(homeUrl()); return true; });
        tabDetect.setOnClickListener(v -> {
            showPanel("web");
            runScan();
            ui.postDelayed(this::showVideos, 350);
        });
        tabDownloads.setOnClickListener(v -> showPanel("downloads"));
        tabBookmarks.setOnClickListener(v -> showPanel("bookmarks"));
        findViewById(R.id.reload_downloads).setOnClickListener(v -> renderDownloads());
        findViewById(R.id.open_folder).setOnClickListener(v -> {
            String tree = StorageTarget.selected(this);
            if (!tree.isEmpty()) {
                try {
                    Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(tree));
                    open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(open);
                    return;
                } catch (Exception ignored) { }
            }
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { toast("내 파일 앱에서 저장 위치를 확인하세요"); }
        });
        bookmarksList.setOnItemClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                showPanel("web");
                browser.loadUrl(list.get(position).optString("url"));
            }
        });
        downloadsList.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= downloadRows.size()) return;
            DownloadRow row = downloadRows.get(position);
            if (selectingDownloads) {
                if (!selectedDownloadIds.add(row.id)) selectedDownloadIds.remove(row.id);
                redrawDownloadSelection();
            } else if (row.status.startsWith("완료")) openCompletedDownload(row.entry);
            else showDownloadActions(row);
        });
        downloadsList.setOnItemLongClickListener((parent, view, position, id) -> {
            if (position >= downloadRows.size()) return true;
            if (selectingDownloads) {
                selectedDownloadIds.add(downloadRows.get(position).id);
                redrawDownloadSelection();
            } else showDownloadActions(downloadRows.get(position));
            return true;
        });
        bookmarksList.setOnItemLongClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                JSONObject target = list.get(position);
                new AlertDialog.Builder(this).setTitle("즐겨찾기 삭제")
                        .setMessage(target.optString("title"))
                        .setPositiveButton("삭제", (d, w) -> {
                            Bookmarks.remove(this, target.optString("url"));
                            renderBookmarks();
                        }).setNegativeButton("취소", null).show();
            }
            return true;
        });
        if (saved != null && saved.getInt("browser_tabs_count", 0) > 0) {
            int count = Math.min(MAX_WEB_TABS, saved.getInt("browser_tabs_count", 1));
            for (int i = 1; i < count; i++) createWebTab();
            for (int i = 0; i < count; i++) {
                Bundle savedTab = saved.getBundle("browser_tab_" + i);
                if (savedTab != null) {
                    if (webTabs.get(i).web.restoreState(savedTab) == null) {
                        webTabs.get(i).web.loadUrl(savedTab.getString("last_url", HOME));
                    }
                }
            }
            activateTab(webTabs.get(Math.max(0,
                    Math.min(count - 1, saved.getInt("browser_tab_selected", 0)))));
        } else if (!restorePersistedTabs(firstTab)) {
            activateTab(firstTab);
            browser.loadUrl(homeUrl());
        }
        applyAdaptiveWindowLayout();
        handleCompletedFileAction(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleCompletedFileAction(intent);
    }

    private void handleCompletedFileAction(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!ACTION_DOWNLOAD_FILE.equals(action) && !ACTION_SHARE_FILE.equals(action)) return;
        String id = intent.getStringExtra("download_id");
        if (id == null || !id.matches("[a-z0-9-]{10,90}")) return;
        JSONObject entry = DownloadStore.get(this, id);
        if (entry != null) {
            if (ACTION_SHARE_FILE.equals(action)) shareCompletedDownload(entry);
            else openCompletedDownload(entry);
        } else toast("다운로드 기록을 찾을 수 없습니다");
        // Do not replay the share/open action when Android later recreates this Activity.
        intent.setAction(Intent.ACTION_MAIN);
        intent.removeExtra("download_id");
    }

    /** Persist only tab URLs and selection, never session cookies or WebView internal state. */
    private void persistTabs() {
        if (replacingSettingsFromBackup) return;
        JSONArray urls = new JSONArray();
        JSONArray positions = new JSONArray();
        for (BrowserTab tab : webTabs) {
            String url = tab.url();
            if (!MediaDetector.validWebUrl(url)) url = homeUrl();
            urls.put(url);
            if (tab.web != null) tab.savedScrollY = Math.max(0, tab.web.getScrollY());
            positions.put(Math.max(0, Math.min(2000000, tab.savedScrollY)));
        }
        getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit()
                .putString(PREF_TAB_SCROLLS, positions.toString())
                .putString(PREF_TABS, urls.toString())
                .putInt(PREF_SELECTED_TAB, Math.max(0, webTabs.indexOf(activeTab)))
                .apply();
    }

    private boolean restorePersistedTabs(BrowserTab first) {
        try {
            JSONArray stored = new JSONArray(getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                    .getString(PREF_TABS, "[]"));
            if (stored.length() <= 0) return false;
            int count = Math.min(MAX_WEB_TABS, stored.length());
            JSONArray positions;
            try { positions = new JSONArray(getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                    .getString(PREF_TAB_SCROLLS, "[]")); }
            catch (Exception e) { positions = new JSONArray(); }
            for (int i = 1; i < count; i++) createWebTab();
            for (int i = 0; i < count; i++) {
                BrowserTab tab = webTabs.get(i);
                tab.pendingRestoreScrollY = Math.max(0, Math.min(2000000, positions.optInt(i, 0)));
                String url = stored.optString(i, homeUrl());
                tab.web.loadUrl(MediaDetector.validWebUrl(url) ? url : homeUrl());
            }
            BrowserDiagnostics.event(this, "TABS", "RESTORED", count);
            int selected = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                    .getInt(PREF_SELECTED_TAB, 0);
            activateTab(webTabs.get(Math.max(0, Math.min(count - 1, selected))));
            return true;
        } catch (Exception ignored) { return false; }
    }

    private String scaleKey(String page) {
        if (!MediaDetector.validWebUrl(page)) return "";
        String host = Uri.parse(page).getHost();
        return host == null ? "" : "site_scale_" +
                (getResources().getConfiguration().screenWidthDp >= 600 ? "wide_" : "compact_")
                + host.toLowerCase(Locale.ROOT);
    }
    private void restoreSiteZoom(WebView view) {
        String key = scaleKey(view.getUrl());
        if (key.isEmpty()) return;
        float target = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getFloat(key, -1);
        if (target < 0.5f || target > 3f) return;
        view.post(() -> {
            if (isDestroyed() || view.getScale() <= 0) return;
            float factor = target / view.getScale();
            if (factor > 0.5f && factor < 2f && Math.abs(factor - 1f) > 0.05f) {
                automaticZoomUntil = android.os.SystemClock.uptimeMillis() + 750;
                view.zoomBy(factor);
            }
        });
    }

    private String homeUrl() {
        String value = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getString(PREF_HOME_URL, HOME);
        return MediaDetector.validWebUrl(value) ? value : HOME;
    }

    private void saveHome(String url) {
        if (!MediaDetector.validWebUrl(url)) { toast("올바른 홈페이지 주소가 아닙니다"); return; }
        getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit().putString(PREF_HOME_URL, url).apply();
        toast("홈 주소가 설정됐습니다");
    }

    /** Accessible homepage editor. The old setMessage()+setItems() AlertDialog hid the choices. */
    private void showHomeSettings() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(6), dp(14), dp(8));
        TextView current = new TextView(this);
        current.setText("현재 홈 주소\n" + homeUrl());
        current.setTextIsSelectable(true);
        current.setTextSize(13);
        current.setTextColor(0xff244660);
        current.setPadding(dp(6), dp(4), dp(6), dp(14));
        content.addView(current);
        final AlertDialog[] dialog = new AlertDialog[1];
        addSettingsEntry(content, "직접 주소 입력", "원하는 사이트 주소를 입력해 저장", () -> {
            dialog[0].dismiss(); showHomeAddressEditor();
        });
        addSettingsEntry(content, "현재 페이지를 홈으로", "지금 열려 있는 사이트를 홈으로 지정", () -> {
            dialog[0].dismiss();
            if (browser != null) saveHome(browser.getUrl());
        });
        addSettingsEntry(content, "즐겨찾기에서 선택", "저장한 즐겨찾기 중 홈페이지 지정", () -> {
            dialog[0].dismiss(); showBookmarkHomePicker();
        });
        addSettingsEntry(content, "Google 기본 홈으로 초기화", "https://www.google.com/", () -> {
            dialog[0].dismiss();
            new AlertDialog.Builder(this).setTitle("홈 주소 초기화")
                .setMessage("홈페이지를 Google로 변경할까요?")
                .setPositiveButton("초기화", (d, which) -> saveHome(HOME))
                .setNegativeButton("취소", null).show();
        });
        dialog[0] = new AlertDialog.Builder(this).setTitle("홈페이지 설정")
            .setView(content).setNegativeButton("닫기", null).create();
        dialog[0].show();
    }

    private void showHomeAddressEditor() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(homeUrl());
        input.setSelectAllOnFocus(true);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(6), dp(20), 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, dp(50)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("홈 주소 직접 편집")
            .setView(box).setPositiveButton("저장", null)
            .setNegativeButton("취소", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setOnClickListener(v -> {
                String url = input.getText().toString().trim();
                if (!url.contains("://")) url = "https://" + url;
                if (!MediaDetector.validWebUrl(url)) {
                    input.setError("https://사이트주소 형태로 입력하세요");
                    return;
                }
                saveHome(url);
                dialog.dismiss();
            }));
        dialog.show();
    }

    private void showBookmarkHomePicker() {
        List<JSONObject> items = Bookmarks.all(this);
        if (items.isEmpty()) { toast("저장된 즐겨찾기가 없습니다"); return; }
        String[] titles = new String[items.size()];
        for (int i = 0; i < items.size(); i++)
            titles[i] = items.get(i).optString("title") + "\n" + items.get(i).optString("url");
        new AlertDialog.Builder(this).setTitle("홈으로 지정할 즐겨찾기")
            .setItems(titles, (d, index) -> saveHome(items.get(index).optString("url")))
            .setNegativeButton("취소", null).show();
    }

    /** A grid of independent browser tab cards instead of a drop-down list. */
    private void showTabPicker(boolean closeMode) {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int width = Math.min(screenWidth - dp(28), dp(730));
        int columns = getResources().getConfiguration().screenWidthDp >= 650 ? 3 : 2;
        int cardWidth = (width - dp(28) - dp(columns * 10)) / columns;
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(columns);
        grid.setPadding(dp(9), dp(8), dp(9), dp(8));
        scroll.addView(grid);
        final AlertDialog[] dialog = new AlertDialog[1];
        List<BrowserTab> snapshot = new ArrayList<>(webTabs);
        for (int i = 0; i < snapshot.size(); i++) {
            BrowserTab tab = snapshot.get(i);
            String title = tab.title();
            if (title == null || title.trim().isEmpty()) title = "새 탭";
            String host;
            try { host = Uri.parse(tab.url()).getHost(); }
            catch (Exception e) { host = null; }
            if (host == null) host = "새 페이지";
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(10), dp(7), dp(8), dp(7));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(tab == activeTab ? 0xffE7F1FF : 0xffF7FAFD);
            bg.setCornerRadius(dp(12));
            bg.setStroke(dp(1), tab == activeTab ? 0xff2474CC : 0xffDCE6EF);
            card.setBackground(bg);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cardWidth;
            lp.height = dp(115);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            grid.addView(card, lp);
            LinearLayout top = new LinearLayout(this);
            top.setGravity(android.view.Gravity.CENTER_VERTICAL);
            card.addView(top, new LinearLayout.LayoutParams(-1, dp(29)));
            TextView number = new TextView(this);
            number.setText((i + 1) + (tab == activeTab ? " · 사용 중" : ""));
            number.setTextSize(11);
            number.setTextColor(0xff2474CC);
            top.addView(number, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView close = new TextView(this);
            close.setText("×");
            close.setTextSize(22);
            close.setTextColor(0xff526679);
            close.setGravity(android.view.Gravity.CENTER);
            close.setContentDescription("탭 닫기");
            top.addView(close, new LinearLayout.LayoutParams(dp(32), dp(32)));
            TextView mainTitle = new TextView(this);
            mainTitle.setText(title.replace('\n', ' '));
            mainTitle.setTextSize(14);
            mainTitle.setTypeface(null, android.graphics.Typeface.BOLD);
            mainTitle.setMaxLines(2);
            mainTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            mainTitle.setTextColor(0xff173754);
            card.addView(mainTitle, new LinearLayout.LayoutParams(-1, 0, 1f));
            TextView domain = new TextView(this);
            domain.setText(host);
            domain.setTextSize(11);
            domain.setSingleLine(true);
            domain.setEllipsize(android.text.TextUtils.TruncateAt.END);
            domain.setTextColor(0xff677E91);
            card.addView(domain);
            card.setContentDescription("탭 " + (i + 1) + ", " + title);
            card.setOnClickListener(v -> { dialog[0].dismiss(); activateTab(tab); });
            close.setOnClickListener(v -> {
                dialog[0].dismiss(); closeWebTab(tab); showTabPicker(false);
            });
        }
        if (webTabs.size() < MAX_WEB_TABS) {
            LinearLayout add = new LinearLayout(this);
            add.setOrientation(LinearLayout.VERTICAL);
            add.setGravity(android.view.Gravity.CENTER);
            GradientDrawable addBg = new GradientDrawable();
            addBg.setColor(0xffEBF5EE);
            addBg.setCornerRadius(dp(12));
            addBg.setStroke(dp(1), 0xffA6D7B5);
            add.setBackground(addBg);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = cardWidth;
            lp.height = dp(115);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            grid.addView(add, lp);
            TextView plus = new TextView(this);
            plus.setText("+");
            plus.setTextSize(28);
            plus.setTextColor(0xff26774C);
            plus.setGravity(android.view.Gravity.CENTER);
            add.addView(plus);
            TextView label = new TextView(this);
            label.setText("새 탭");
            label.setTextSize(13);
            label.setTextColor(0xff26774C);
            add.addView(label);
            add.setContentDescription("새 탭 열기");
            add.setOnClickListener(v -> {
                dialog[0].dismiss();
                BrowserTab newTab = createWebTab();
                activateTab(newTab);
                newTab.web.loadUrl(homeUrl());
            });
        }
        dialog[0] = new AlertDialog.Builder(this)
            .setTitle("웹페이지 탭 · " + webTabs.size() + "개")
            .setView(scroll)
            .setNeutralButton("다른 탭 모두 닫기", (d,w) -> confirmCloseOtherTabs())
            .setNegativeButton("닫기", null).create();
        dialog[0].show();
        if (dialog[0].getWindow() != null)
            dialog[0].getWindow().setLayout(width, -2);
    }

    private void confirmCloseOtherTabs() {
        if (webTabs.size() <= 1) { toast("현재 탭 하나만 열려 있습니다"); return; }
        new AlertDialog.Builder(this).setTitle("다른 탭 모두 닫기")
            .setMessage("현재 보고 있는 탭은 유지하고 나머지 탭을 닫을까요?")
            .setPositiveButton("닫기", (d,w) -> {
                BrowserTab keep = activeTab;
                for (BrowserTab tab : new ArrayList<>(webTabs))
                    if (tab != keep) closeWebTab(tab);
                renderWebTabs(); persistTabs();
            })
            .setNegativeButton("취소", null).show();
    }

    private void addSettingsEntry(LinearLayout list, String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xffF3F7FC);
        bg.setCornerRadius(dp(11));
        bg.setStroke(dp(1), 0xffE1E9F2);
        card.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(1), dp(4), dp(1), dp(4));
        list.addView(card, lp);
        TextView heading = new TextView(this);
        heading.setText(title + "  ›");
        heading.setTextSize(15);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        heading.setTextColor(0xff173754);
        card.addView(heading);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView detail = new TextView(this);
            detail.setText(subtitle);
            detail.setTextSize(12);
            detail.setTextColor(0xff60758A);
            detail.setMaxLines(2);
            detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.addView(detail);
        }
        card.setOnClickListener(v -> action.run());
    }

    private void fitCurrentPage() {
        if (browser == null || !MediaDetector.validWebUrl(browser.getUrl())) {
            toast("열린 웹페이지가 없습니다"); return;
        }
        new AlertDialog.Builder(this).setTitle("화면 맞춤")
            .setMessage("현재 사이트를 다시 불러와 폴드 화면 너비에 맞춥니다. 재생 중인 영상은 중단될 수 있습니다.")
            .setPositiveButton("화면 맞춤", (d,w) -> {
                browser.setInitialScale(0);
                browser.reload();
            }).setNegativeButton("취소", null).show();
    }

    private void resetCurrentSiteZoom() {
        if (browser == null || !MediaDetector.validWebUrl(browser.getUrl())) {
            toast("열린 웹페이지가 없습니다"); return;
        }
        new AlertDialog.Builder(this).setTitle("사이트 배율 초기화")
            .setMessage("접힘·펼침 화면에 저장된 이 사이트의 배율을 지웁니다. 페이지가 새로 열리므로 영상 재생은 중단될 수 있습니다.")
            .setPositiveButton("초기화", (d,w) -> {
                String host = Uri.parse(browser.getUrl()).getHost();
                if (host == null) return;
                getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit()
                    .remove("site_scale_wide_" + host.toLowerCase(Locale.ROOT))
                    .remove("site_scale_compact_" + host.toLowerCase(Locale.ROOT)).apply();
                browser.setInitialScale(0);
                browser.reload();
                toast("사이트 배율을 초기화했습니다");
            }).setNegativeButton("취소", null).show();
    }

    private void confirmClearCache() {
        new AlertDialog.Builder(this).setTitle("브라우저 캐시 삭제")
            .setMessage("웹페이지 임시 이미지·파일을 삭제합니다. 로그인 상태, 즐겨찾기, 열린 탭, 다운로드한 동영상은 유지됩니다.")
            .setPositiveButton("캐시 삭제", (d,w) -> {
                if (browser != null) browser.clearCache(true); // App-wide WebView cache.
                toast("웹페이지 캐시를 삭제했습니다");
            }).setNegativeButton("취소", null).show();
    }

    private void confirmClearSiteData() {
        new AlertDialog.Builder(this).setTitle("웹사이트 로그인 정보 삭제")
            .setMessage("쿠키와 일부 웹사이트 저장 데이터를 지웁니다. 사이트에서 로그아웃될 수 있습니다. 다운로드한 영상과 즐겨찾기는 유지됩니다.")
            .setPositiveButton("로그인 정보 삭제", (d,w) -> {
                CookieManager.getInstance().removeAllCookies(done -> {
                    CookieManager.getInstance().flush();
                    toast("사이트 로그인 쿠키를 삭제했습니다");
                });
                WebStorage.getInstance().deleteAllData();
                if (browser != null) browser.clearCache(true);
            }).setNegativeButton("취소", null).show();
    }

    private void showSettingsDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout entries = new LinearLayout(this);
        entries.setOrientation(LinearLayout.VERTICAL);
        entries.setPadding(dp(14), dp(4), dp(14), dp(12));
        scroll.addView(entries);
        final AlertDialog[] dialog = new AlertDialog[1];
        addSettingsEntry(entries, "진단·오류 신고 (ZIP 생성·공유)",
                "자동 기록된 최근 오류 · Downloads/믿음하나/진단 저장 · 원터치 공유", () -> {
            dialog[0].dismiss(); exportDiagnostics();
        });
        addSettingsEntry(entries, "현재 사이트 호환성", "광고 요청 차단·영상 자동 감지 사용 여부", () -> {
            dialog[0].dismiss(); showSiteCompatibility();
        });
        addSettingsEntry(entries, "홈페이지 주소 편집", homeUrl(), () -> {
            dialog[0].dismiss(); showHomeSettings();
        });
        addSettingsEntry(entries, "화면 맞춤", "현재 페이지를 화면 너비에 맞춰 다시 표시", () -> {
            dialog[0].dismiss(); fitCurrentPage();
        });
        addSettingsEntry(entries, "현재 사이트 배율 초기화", "접힘·펼침 상태별로 기억한 배율만 지우기", () -> {
            dialog[0].dismiss(); resetCurrentSiteZoom();
        });
        addSettingsEntry(entries, "설정·즐겨찾기 백업", "다운로드/믿음하나/백업에 저장 · 재설치 후 복원 가능", () -> {
            dialog[0].dismiss(); exportBrowserBackup();
        });
        addSettingsEntry(entries, "백업 파일에서 복원", "홈·탭·즐겨찾기·화면 배율 복원 (로그인은 제외)", () -> {
            dialog[0].dismiss(); chooseBackupToRestore();
        });
        addSettingsEntry(entries, "다운로드 저장 폴더", "기본: Download/믿음하나 · 다른 폴더 선택 가능", () -> {
            dialog[0].dismiss(); chooseFolder();
        });
        addSettingsEntry(entries, "웹페이지 탭 관리", "카드 배열에서 전환·닫기·새 탭 열기", () -> {
            dialog[0].dismiss(); showTabPicker(false);
        });
        addSettingsEntry(entries, "브라우저 캐시 삭제", "임시 웹 파일만 삭제 · 로그인 및 영상 파일 보존", () -> {
            dialog[0].dismiss(); confirmClearCache();
        });
        addSettingsEntry(entries, "웹사이트 로그인 정보 삭제", "별도 확인 후 쿠키 및 일부 웹 저장 데이터 삭제", () -> {
            dialog[0].dismiss(); confirmClearSiteData();
        });
        TextView about = new TextView(this);
        about.setText("믿음하나 브라우저 v2.1.7\n진단은 URL·쿠키·비밀번호를 제외한 분류형 기록입니다.\n백업에는 로그인 정보·다운로드 기록·선택 폴더 권한이 포함되지 않습니다.\n앱 자체 광고 SDK 및 영상 플레이어 없음");
        about.setTextColor(0xff738294);
        about.setTextSize(11);
        about.setPadding(dp(8), dp(14), 0, dp(5));
        entries.addView(about);
        dialog[0] = new AlertDialog.Builder(this).setTitle("브라우저 설정")
            .setView(scroll).setNegativeButton("닫기", null).create();
        dialog[0].show();
    }

    /** User-initiated: never send logs to a server or external app automatically. */
    private void exportDiagnostics() {
        if (exportingDiagnostics) { toast("진단 ZIP 생성 중입니다"); return; }
        exportingDiagnostics = true;
        BrowserDiagnostics.event(this, "DIAGNOSTIC", "EXPORT_REQUEST");
        new Thread(() -> {
            try {
                Uri output = BrowserDiagnostics.export(getApplicationContext());
                ui.post(() -> {
                    exportingDiagnostics = false;
                    if (isFinishing() || isDestroyed()) return;
                    BrowserDiagnostics.event(this, "DIAGNOSTIC", "EXPORT_SUCCESS");
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("application/zip");
                        send.putExtra(Intent.EXTRA_STREAM, output);
                        send.setClipData(ClipData.newRawUri("믿음하나 브라우저 진단", output));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "진단 ZIP 공유 (저장 완료)"));
                    } catch (Exception error) {
                        BrowserDiagnostics.event(this, "DIAGNOSTIC", "SHARE_FAILED");
                        new AlertDialog.Builder(this).setTitle("진단 ZIP 저장 완료")
                                .setMessage("Download/믿음하나/진단에 ZIP을 저장했습니다. 공유 화면을 열지 못했으니 내 파일 앱에서 공유해 주세요.")
                                .setPositiveButton("확인", null).show();
                    }
                });
            } catch (Exception error) {
                ui.post(() -> {
                    exportingDiagnostics = false;
                    if (isFinishing() || isDestroyed()) return;
                    BrowserDiagnostics.event(this, "DIAGNOSTIC", "EXPORT_FAILED");
                    new AlertDialog.Builder(this).setTitle("진단 ZIP 저장 실패")
                            .setMessage("저장 공간과 기기 상태를 확인한 뒤 다시 시도해 주세요. 기존 진단 기록은 보관됩니다.")
                            .setPositiveButton("확인", null).show();
                });
            }
        }, "BrowserDiagnosticExport").start();
    }

    private void showSiteCompatibility() {
        String page = browser == null ? "" : browser.getUrl();
        String host = SiteCompatibility.host(page);
        if (host.isEmpty()) { toast("웹사이트 페이지를 먼저 열어주세요"); return; }
        final boolean[] flags = {SiteCompatibility.adBlock(this, page),
                SiteCompatibility.videoScan(this, page)};
        new AlertDialog.Builder(this).setTitle("사이트 호환성 · " + host)
            .setMultiChoiceItems(new String[]{"광고 요청 차단 사용", "영상 자동 감지 사용"}, flags,
                    (dialog, which, checked) -> flags[which] = checked)
            .setPositiveButton("저장", (dialog, which) -> {
                SiteCompatibility.save(this, page, flags[0], flags[1]);
                BrowserDiagnostics.event(this, "SITE_COMPAT", "UPDATED");
                if (!flags[1] && activeTab != null) {
                    activeTab.candidates.clear();
                    activeTab.playerPresent = false;
                    activeTab.playerPlaying = false;
                    activeTab.opaqueStream = false;
                    activeTab.embeddedPlayer = false;
                    refreshCandidates();
                }
                if (browser != null && page.equals(browser.getUrl())) browser.reload();
                toast("현재 사이트 설정을 적용했습니다");
            })
            .setNeutralButton("기본값", (dialog, which) -> {
                SiteCompatibility.reset(this, page);
                BrowserDiagnostics.event(this, "SITE_COMPAT", "RESET");
                if (browser != null && page.equals(browser.getUrl())) browser.reload();
                toast("현재 사이트 설정을 초기화했습니다");
            })
            .setNegativeButton("취소", null).show();
    }

    /** Manual backup is kept outside app-private storage, so uninstall will not remove it. */
    private void exportBrowserBackup() {
        persistTabs();
        new Thread(() -> {
            try {
                Uri uri = BrowserBackup.exportToDownloads(getApplicationContext());
                ui.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    new AlertDialog.Builder(this).setTitle("백업 저장 완료")
                        .setMessage("Download/믿음하나/백업에 저장했습니다.\n\n앱을 삭제하기 전에 백업 파일이 있는지 확인하세요. 로그인 정보·다운로드 기록·폴더 접근 권한은 포함하지 않습니다.")
                        .setPositiveButton("확인", null).show();
                });
            } catch (Exception failure) {
                ui.post(() -> toast("백업 실패: " + failure.getMessage()));
            }
        }, "BrowserBackupExport").start();
    }

    private void chooseBackupToRestore() {
        try {
            Intent select = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            select.addCategory(Intent.CATEGORY_OPENABLE);
            select.setType("*/*");
            select.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "application/json", "text/plain", "application/octet-stream"});
            select.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(select, BACKUP_IMPORT_PICKER);
        } catch (Exception e) { toast("백업 파일 선택기를 열 수 없습니다"); }
    }

    private void confirmRestoreBackup(Uri uri) {
        new Thread(() -> {
            try {
                JSONObject parsed = BrowserBackup.parseBackup(getApplicationContext(), uri);
                int bookmarkCount = parsed.getJSONArray("bookmarks").length();
                int tabCount = parsed.getJSONArray("tabs").length();
                ui.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    new AlertDialog.Builder(this).setTitle("백업 복원 확인")
                        .setMessage("저장된 즐겨찾기 " + bookmarkCount + "개, 탭 " + tabCount
                            + "개와 홈페이지·배율 설정을 복원합니다.\n\n현재 즐겨찾기와 설정은 교체되며 로그인·다운로드 기록은 변경되지 않습니다. 복원 후 브라우저가 다시 열립니다.")
                        .setPositiveButton("복원", (d,w) -> {
                            try {
                                BrowserBackup.restore(this, parsed);
                                replacingSettingsFromBackup = true; // onPause/onDestroy must not overwrite imported tabs.
                                Intent open = new Intent(this, MainActivity.class);
                                open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(open);
                                finish();
                            } catch (Exception e) { toast("복원 실패: " + e.getMessage()); }
                        })
                        .setNegativeButton("취소", null).show();
                });
            } catch (Exception failure) {
                ui.post(() -> toast("복원 불가: " + failure.getMessage()));
            }
        }, "BrowserBackupImport").start();
    }

    private BrowserTab registerTab(WebView web) {
        BrowserTab tab = new BrowserTab(web);
        webTabs.add(tab);
        tabLookup.put(web, tab);
        return tab;
    }

    /** Links open in a new independent WebView without changing other tabs' history. */
    private void openNewWebTab(String url, boolean activate) {
        if (!MediaDetector.validWebUrl(url)) { toast("열 수 없는 링크입니다"); return; }
        if (webTabs.size() >= MAX_WEB_TABS) {
            toast("탭은 최대 8개입니다. 탭을 닫고 다시 시도하세요");
            showTabPicker(false);
            return;
        }
        BrowserTab tab = createWebTab();
        if (activate) activateTab(tab);
        else renderWebTabs();
        tab.web.loadUrl(url);
        persistTabs();
        if (!activate) toast("새 탭에 열었습니다 (탭 " + webTabs.size() + ")");
    }

    private void copyToClipboard(String title, String value) {
        if (value == null || value.trim().isEmpty()) {
            toast("복사할 내용이 없습니다");
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText(title, value));
            toast(title + " 복사했습니다");
        }
    }

    /** Long-press on regular text is passed through to WebView's native select/copy toolbar. */
    private boolean handleWebLongPress(WebView view) {
        WebView.HitTestResult hit = view.getHitTestResult();
        if (hit == null) return false;
        int type = hit.getType();
        if (type == WebView.HitTestResult.IMAGE_TYPE) {
            String imageUrl = hit.getExtra();
            if (MediaDetector.validWebUrl(imageUrl)) {
                showImageMenu(imageUrl, null, null);
                return true;
            }
            return false;
        }
        if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE
                || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            boolean linkedImage = type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE;
            // SRC_IMAGE_ANCHOR_TYPE returns image src in extra, not anchor href.
            String imageFallback = linkedImage ? hit.getExtra() : null;
            String linkFallback = linkedImage ? null : hit.getExtra();
            final java.util.concurrent.atomic.AtomicBoolean handled =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            Handler handler = new Handler(Looper.getMainLooper(), message -> {
                if (!handled.compareAndSet(false, true)) return true;
                if (isFinishing() || isDestroyed() || !tabLookup.containsKey(view)) return true;
                Bundle details = message.getData();
                String href = details == null ? null : details.getString("url");
                String title = details == null ? null : details.getString("title");
                String image = details == null ? null : details.getString("src");
                if (!MediaDetector.validWebUrl(href)) href = linkFallback;
                if (!MediaDetector.validWebUrl(image)) image = imageFallback;
                showLongPressResourceMenu(linkedImage, image, href, title);
                return true;
            });
            view.requestFocusNodeHref(handler.obtainMessage(1));
            ui.postDelayed(() -> {
                if (!handled.compareAndSet(false, true) || isFinishing() || isDestroyed()
                        || !tabLookup.containsKey(view)) return;
                showLongPressResourceMenu(linkedImage, imageFallback, linkFallback, null);
            }, 450);
            return true;
        }
        // Do not hijack long-press on ordinary text; Android's text handles + Copy remain.
        return false;
    }

    private void showLongPressResourceMenu(boolean imageAnchor, String image, String href, String title) {
        if (imageAnchor && MediaDetector.validWebUrl(image)) {
            showImageMenu(image, href, title);
        } else if (MediaDetector.validWebUrl(href)) {
            showLinkMenu(href, title);
        } else if (MediaDetector.validWebUrl(image)) {
            showImageMenu(image, null, title);
        } else toast("이 항목의 주소를 확인할 수 없습니다");
    }

    private void showLinkMenu(String href, String rawTitle) {
        if (!MediaDetector.validWebUrl(href)) return;
        String title = rawTitle == null ? "" : rawTitle.trim();
        ArrayList<String> options = new ArrayList<>();
        ArrayList<Runnable> actions = new ArrayList<>();
        if (!title.isEmpty()) {
            options.add("링크 텍스트 복사");
            actions.add(() -> copyToClipboard("텍스트", title));
        }
        options.add("링크 복사");
        actions.add(() -> copyToClipboard("링크", href));
        options.add("새 탭에서 열기");
        actions.add(() -> openNewWebTab(href, true));
        options.add("배경 탭에서 열기");
        actions.add(() -> openNewWebTab(href, false));
        options.add("링크 공유");
        actions.add(() -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, href);
            startActivity(Intent.createChooser(send, "링크 공유"));
        });
        if (MediaDetector.looksLikeVideo(href)) {
            options.add("링크된 영상 다운로드");
            actions.add(() -> offerDownload(href, MediaDetector.guessName(href, null, null)));
        }
        new AlertDialog.Builder(this).setTitle(title.isEmpty() ? "링크 작업" : title)
                .setItems(options.toArray(new String[0]), (dialog, which) -> actions.get(which).run())
                .setNegativeButton("취소", null).show();
    }

    private void showImageMenu(String image, String href, String rawTitle) {
        if (!MediaDetector.validWebUrl(image)) return;
        ArrayList<String> options = new ArrayList<>();
        ArrayList<Runnable> actions = new ArrayList<>();
        options.add("이미지 다운로드");
        actions.add(() -> offerImageDownload(image));
        options.add("이미지 열기 (현재 탭)");
        actions.add(() -> { showPanel("web"); browser.loadUrl(image); });
        options.add("이미지를 새 탭에서 열기");
        actions.add(() -> openNewWebTab(image, true));
        options.add("이미지 주소 복사");
        actions.add(() -> copyToClipboard("이미지 주소", image));
        options.add("이미지 주소 공유");
        actions.add(() -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, image);
            startActivity(Intent.createChooser(send, "이미지 주소 공유"));
        });
        if (MediaDetector.validWebUrl(href)) {
            options.add("연결된 링크 복사");
            actions.add(() -> copyToClipboard("링크", href));
            options.add("연결된 링크를 새 탭에서 열기");
            actions.add(() -> openNewWebTab(href, true));
            if (rawTitle != null && !rawTitle.trim().isEmpty()) {
                options.add("연결된 링크 텍스트 복사");
                actions.add(() -> copyToClipboard("텍스트", rawTitle.trim()));
            }
        }
        new AlertDialog.Builder(this).setTitle("이미지 작업")
                .setItems(options.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("취소", null).show();
    }

    /** Download actual image data, not the surrounding page or a video placeholder. */
    private void offerImageDownload(String imageUrl) {
        if (!MediaDetector.validWebUrl(imageUrl)) { toast("이미지 주소를 확인할 수 없습니다"); return; }
        EditText nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setText(suggestedImageFileName(imageUrl));
        nameBox.setSelectAllOnFocus(true);
        nameBox.setPadding(dp(12), dp(8), dp(12), dp(8));
        new AlertDialog.Builder(this).setTitle("이미지 다운로드")
                .setMessage("저장 위치: " + StorageTarget.display(this)
                        + "\n지원 형식: JPG, PNG, WEBP, GIF, AVIF 등. 사이트 정책에 따라 저장이 거부될 수 있습니다.")
                .setView(nameBox)
                .setPositiveButton("저장", (d, which) -> {
                    String name = DownloadStore.safeFileName(nameBox.getText().toString());
                    if (!MediaTypes.fromFileName(name).startsWith("image/")) {
                        toast("파일명에 이미지 확장자(.jpg, .png, .webp 등)를 입력하세요");
                        return;
                    }
                    enqueueService(imageUrl, name, "image", StorageTarget.selected(this),
                            browser == null ? "" : browser.getUrl(),
                            browser == null ? "" : browser.getSettings().getUserAgentString());
                })
                .setNegativeButton("취소", null).show();
    }

    private String suggestedImageFileName(String url) {
        Uri uri = Uri.parse(url);
        String file = uri.getLastPathSegment();
        if (file == null || file.trim().isEmpty()) file = "이미지";
        file = DownloadStore.safeFileName(file);
        String ext = file.toLowerCase(Locale.ROOT);
        if (MediaTypes.fromFileName(file).startsWith("image/")) return file;
        String format = uri.getQueryParameter("format");
        if (format == null) format = uri.getQueryParameter("fm");
        if (format != null) {
            String suffix = format.toLowerCase(Locale.ROOT);
            if (suffix.matches("jpg|jpeg|png|webp|gif|avif|bmp|heic|heif"))
                return file + "." + suffix;
        }
        return file + ".jpg"; // Editable when a CDN omits its original extension.
    }

    /** Explicit confirmation; active app-managed transfers receive a graceful pause request. */
    private void confirmExitApp() {
        int running = 0;
        for (JSONObject job : DownloadStore.list(this)) {
            if (HlsDownloadService.isJobActive(job.optString("id"))) running++;
        }
        String note = "열려 있는 탭 주소는 저장됩니다.\n"
                + (running == 0 ? "" : "진행 중인 앱 다운로드 " + running + "건에 중지를 요청합니다.\n")
                + "시스템에서 처리 중인 다운로드는 종료 후에도 계속될 수 있습니다.";
        new AlertDialog.Builder(this).setTitle("앱 종료")
                .setMessage("믿음하나 브라우저를 종료하시겠습니까?\n\n" + note)
                .setPositiveButton("종료", (d, which) -> {
                    persistTabs();
                    for (JSONObject job : DownloadStore.list(this)) {
                        String id = job.optString("id");
                        if (!HlsDownloadService.isJobActive(id)) continue;
                        try {
                            Intent stop = new Intent(this, HlsDownloadService.class);
                            stop.setAction(HlsDownloadService.ACTION_CANCEL);
                            stop.putExtra("id", id);
                            startService(stop);
                        } catch (Exception ignored) { /* Recovery on next launch. */ }
                    }
                    finishAffinity();
                })
                .setNegativeButton("취소", null).show();
    }

    private void confirmCloseQuickTab(BrowserTab tab) {
        int index = webTabs.indexOf(tab);
        if (index < 0) return;
        new AlertDialog.Builder(this).setTitle("탭 " + (index + 1) + " 닫기")
                .setMessage("이 탭을 닫을까요? 다른 탭은 그대로 유지됩니다.")
                .setPositiveButton("닫기", (d, w) -> closeWebTab(tab))
                .setNegativeButton("취소", null).show();
    }

    private BrowserTab createWebTab() {
        WebView web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        web.setVisibility(View.GONE);
        webContainer.addView(web);
        BrowserTab tab = registerTab(web);
        configureBrowser(web);
        return tab;
    }

    private void activateTab(BrowserTab tab) {
        if (tab == null || !webTabs.contains(tab)) return;
        if (fullscreenLayer != null && tab.web != fullscreenOwner) leaveVideoFullscreen(true);
        if (activeTab != null && activeTab != tab && activeTab.web != null) {
            activeTab.web.onPause();
            activeTab.web.setVisibility(View.GONE);
        }
        if (tab.web == null) {
            WebView revived = new WebView(this);
            revived.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
            webContainer.addView(revived, 0);
            tab.web = revived;
            tabLookup.put(revived, tab);
            configureBrowser(revived);
            boolean recovered = false;
            if (tab.savedWebState != null) {
                try { recovered = revived.restoreState(tab.savedWebState) != null; }
                catch (Exception ignored) { }
                tab.savedWebState = null;
            }
            if (!recovered) revived.loadUrl(MediaDetector.validWebUrl(tab.savedUrl)
                    ? tab.savedUrl : homeUrl());
        }
        tab.lastUsedAt = android.os.SystemClock.uptimeMillis();
        activeTab = tab;
        browser = tab.web;
        browser.setVisibility(View.VISIBLE);
        browser.onResume();
        address.setText(browser.getUrl() == null ? "" : browser.getUrl());
        progress.setVisibility(View.GONE);
        showPanel("web");
        renderWebTabs();
        persistTabs();
    }

    private void closeWebTab(BrowserTab tab) {
        if (fullscreenOwner != null && tab != null && tab.web == fullscreenOwner)
            leaveVideoFullscreen(true);
        if (webTabs.size() == 1) {
            tab.candidates.clear();
            tab.web.loadUrl(homeUrl());
            return;
        }
        int oldIndex = webTabs.indexOf(tab);
        if (tab == activeTab) {
            BrowserTab next = webTabs.get(oldIndex > 0 ? oldIndex - 1 : 1);
            // Remove the closed tab before switching its visibility.
            activeTab = null;
            browser = next.web;
            webTabs.remove(tab);
            if (tab.web != null) tabLookup.remove(tab.web);
            tab.web.setVisibility(View.GONE);
            activateTab(next);
        } else {
            webTabs.remove(tab);
            if (tab.web != null) tabLookup.remove(tab.web);
        }
        if (tab.web != null) {
            tab.web.stopLoading();
            tab.web.setWebChromeClient(null);
            tab.web.setWebViewClient(null);
            webContainer.removeView(tab.web);
            tab.web.destroy();
        }
        tab.savedWebState = null;
        renderWebTabs();
        persistTabs();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void renderWebTabs() {
        if (openTabs != null) openTabs.setText("▦");
        if (dashboardStatus != null) dashboardStatus.setText(webTabs.size() + "개 탭");
        if (quickTabsStrip == null || quickTabsScroll == null) return;
        final int previousX = quickTabsScroll.getScrollX();
        quickTabsStrip.removeAllViews();
        for (int i = 0; i < webTabs.size(); i++) {
            final BrowserTab tab = webTabs.get(i);
            final int number = i + 1;
            Button button = new Button(this);
            button.setText("탭 " + number);
            button.setTextSize(11);
            button.setAllCaps(false);
            button.setPadding(dp(8), 0, dp(8), 0);
            button.setMinWidth(0);
            button.setMinimumWidth(0);
            button.setMinHeight(0);
            button.setMinimumHeight(0);
            button.setTextColor(0xffFFFFFF);
            button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    tab == activeTab ? 0xff2874BA : 0xff38536D));
            String label = tab.title();
            button.setContentDescription("탭 " + number
                    + (label == null || label.isEmpty() ? "" : ", " + label)
                    + (tab == activeTab ? ", 현재 탭" : "")
                    + ". 길게 누르면 닫기");
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(62), dp(34));
            params.setMargins(dp(2), 0, dp(2), 0);
            quickTabsStrip.addView(button, params);
            button.setOnClickListener(v -> activateTab(tab));
            button.setOnLongClickListener(v -> { confirmCloseQuickTab(tab); return true; });
        }
        quickTabsScroll.post(() -> {
            if (!isFinishing() && !isDestroyed())
                quickTabsScroll.scrollTo(Math.min(previousX,
                        Math.max(0, quickTabsStrip.getWidth() - quickTabsScroll.getWidth())), 0);
        });
    }

    // Window size can change in-place on a foldable or in split-screen.
    private void applyAdaptiveWindowLayout() {
        final int widthDp = getResources().getConfiguration().screenWidthDp;
        // On a folded narrow window, prioritize immediately accessible tab buttons.
        if (brandTitle != null) brandTitle.setVisibility(widthDp < 600 ? View.GONE : View.VISIBLE);
        if (dashboardStatus != null) {
            dashboardStatus.setText(webTabs.size() + "개 탭 · "
                    + (widthDp >= 600 ? "펼친 화면" : "일반 화면"));
        }
        if (webContainer != null) webContainer.requestLayout();
        // Do not reset initial scale for every open tab; that erased per-site fold zoom.
        // Preserve the approximate scroll position and relayout the active viewport.
        final WebView current = browser;
        if (current == null) return;
        final int beforeY = current.getScrollY();
        current.requestLayout();
        current.postDelayed(() -> {
            if (isFinishing() || isDestroyed() || current != browser) return;
            current.invalidate();
            current.scrollTo(current.getScrollX(), Math.min(beforeY,
                    Math.max(0, Math.round(current.getContentHeight() * current.getScale())
                            - current.getHeight())));
            restoreSiteZoom(current);
            current.evaluateJavascript("window.dispatchEvent(new Event('resize'));", null);
        }, 280);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        BrowserDiagnostics.event(this, "WINDOW", newConfig.screenWidthDp >= 600
                ? "WIDE" : "COMPACT");
        applyAdaptiveWindowLayout();
    }

    /** Keep the browser controls out of the WebView video player's fullscreen surface. */
    private void enterVideoFullscreen(WebView owner, View custom,
                                      WebChromeClient.CustomViewCallback callback) {
        if (custom == null || owner != browser || isFinishing() || isDestroyed()
                || fullscreenLayer != null) {
            BrowserDiagnostics.event(this, "FULLSCREEN", "REJECTED_STATE");
            if (callback != null) callback.onCustomViewHidden();
            return;
        }
        FrameLayout windowContent = findViewById(android.R.id.content);
        if (windowContent == null) {
            BrowserDiagnostics.event(this, "FULLSCREEN", "NO_WINDOW");
            if (callback != null) callback.onCustomViewHidden();
            return;
        }
        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Color.BLACK);
        layer.setFocusable(true);
        layer.setFocusableInTouchMode(true);
        android.view.ViewParent existingParent = custom.getParent();
        if (existingParent instanceof ViewGroup)
            ((ViewGroup) existingParent).removeView(custom);
        layer.addView(custom, new FrameLayout.LayoutParams(-1, -1));
        fullscreenOwner = owner;
        fullscreenLayer = layer;
        fullscreenCallback = callback;
        View decor = getWindow().getDecorView();
        previousSystemUiVisibility = decor.getSystemUiVisibility();
        previousWindowFullscreen = (getWindow().getAttributes().flags
                & WindowManager.LayoutParams.FLAG_FULLSCREEN) != 0;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decor.setSystemUiVisibility(previousSystemUiVisibility
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        windowContent.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        layer.bringToFront();
        layer.requestFocus();
        BrowserDiagnostics.event(this, "FULLSCREEN", "ENTERED");
    }

    /** Called by both the website's close action and Android back navigation. */
    private void leaveVideoFullscreen(boolean notifyWebView) {
        FrameLayout layer = fullscreenLayer;
        if (layer == null) return;
        WebChromeClient.CustomViewCallback callback = fullscreenCallback;
        fullscreenLayer = null;
        fullscreenOwner = null;
        fullscreenCallback = null;
        layer.removeAllViews();
        android.view.ViewParent parent = layer.getParent();
        if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(layer);
        getWindow().getDecorView().setSystemUiVisibility(previousSystemUiVisibility);
        if (!previousWindowFullscreen)
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (notifyWebView && callback != null) callback.onCustomViewHidden();
        BrowserDiagnostics.event(this, "FULLSCREEN", notifyWebView ? "HOST_EXIT" : "WEB_EXIT");
    }

    private void configureBrowser(WebView web) {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); // Needed by most modern websites.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Android 8+: enable Google Safe Browsing protection for malicious URLs.
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        // Foldable / wide-window: let CSS viewport reflow to the actual WebView width.
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setInitialScale(0);
        web.setOnTouchListener((v, e) -> {
            BrowserTab tab = tabLookup.get(web);
            if (tab != null && e.getPointerCount() >= 2)
                tab.lastPinchAt = android.os.SystemClock.uptimeMillis();
            return false; // WebView still handles pinch and click itself.
        });
        web.setOnLongClickListener(v -> handleWebLongPress(web));
        web.setOnScrollChangeListener((view, x, y, oldX, oldY) -> {
            BrowserTab scrollTab = tabLookup.get(web);
            if (scrollTab == null) return;
            scrollTab.savedScrollY = Math.max(0, y);
            if (scrollTab == activeTab) {
                ui.removeCallbacks(saveScroll);
                ui.postDelayed(saveScroll, 1800);
            }
        });
        web.setLongClickable(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage message) {
                // Deliberately never record console contents; they can include credentials/URLs.
                if (message != null && message.messageLevel()
                        == android.webkit.ConsoleMessage.MessageLevel.ERROR)
                    BrowserDiagnostics.limited(MainActivity.this, "WEB_CONSOLE", "ERROR", 15000);
                return false;
            }
            @Override public void onProgressChanged(WebView view, int percent) {
                if (web != browser) return;
                progress.setProgress(percent);
                progress.setVisibility(percent >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public void onShowCustomView(View view,
                    WebChromeClient.CustomViewCallback callback) {
                BrowserDiagnostics.event(MainActivity.this, "FULLSCREEN", "REQUEST");
                enterVideoFullscreen(web, view, callback);
            }
            @Override public void onHideCustomView() {
                BrowserDiagnostics.event(MainActivity.this, "FULLSCREEN", "SITE_EXIT");
                if (fullscreenOwner == web) leaveVideoFullscreen(false);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                if (fullscreenOwner == view) leaveVideoFullscreen(true);
                if (view == browser) BrowserDiagnostics.event(MainActivity.this, "PAGE", "NAVIGATE");
                BrowserTab tab = tabLookup.get(view);
                if (tab == null) return;
                tab.playerPresent = false;
                tab.playerPlaying = false;
                tab.opaqueStream = false;
                tab.embeddedPlayer = false;
                tab.epoch++;
                tab.lastScannedPage = url == null ? "" : url;
                if (MediaDetector.validWebUrl(url)) tab.savedUrl = url;
                tab.candidates.clear();
                if (tab == activeTab) {
                    refreshCandidates();
                    address.setText(url);
                    renderWebTabs();
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (view == browser) {
                    address.setText(url);
                    restoreSiteZoom(view);
                    runScan();
                    BrowserDiagnostics.event(MainActivity.this, "PAGE", "FINISHED");
                }
                BrowserTab restored = tabLookup.get(view);
                if (restored != null && restored.pendingRestoreScrollY >= 0) {
                    final int scrollY = restored.pendingRestoreScrollY;
                    restored.pendingRestoreScrollY = -1;
                    view.postDelayed(() -> {
                        if (tabLookup.get(view) == restored && !isFinishing() && !isDestroyed())
                            view.scrollTo(0, scrollY);
                    }, 800);
                }
                // Background tabs also need their final URL saved for app restart.
                BrowserTab finished = tabLookup.get(view);
                if (finished != null) {
                    if (MediaDetector.validWebUrl(url)) finished.savedUrl = url;
                    if (view.getTitle() != null) finished.savedTitle = view.getTitle();
                }
                renderWebTabs();
                persistTabs();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                BrowserTab requestTab = tabLookup.get(view);
                boolean enableAdBlock = requestTab == null
                        || SiteCompatibility.adBlock(MainActivity.this, requestTab.savedUrl);
                if (enableAdBlock && AdBlock.blocked(uri)) {
                    BrowserDiagnostics.limited(MainActivity.this, "AD_REQUEST", "BLOCKED", 5000);
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                String url = uri.toString();
                BrowserTab tab = requestTab;
                if (MediaDetector.looksLikeVideo(url) && tab != null && tab == activeTab
                        && SiteCompatibility.videoScan(MainActivity.this, tab.savedUrl)) {
                    addVideo(tab, url, 1, 0, 0, 0, false, false, null, tab.epoch);
                }
                return null;
            }
            @Override public void onScaleChanged(WebView view, float oldScale, float newScale) {
                long now = android.os.SystemClock.uptimeMillis();
                if (now < automaticZoomUntil) return;
                BrowserTab zoomTab = tabLookup.get(view);
                if (zoomTab == null || now - zoomTab.lastPinchAt > 1500) return;
                if (newScale < 0.5f || newScale > 3f || Math.abs(oldScale - newScale) < 0.03f) return;
                String key = scaleKey(view.getUrl());
                if (!key.isEmpty()) getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE)
                        .edit().putFloat(key, newScale).apply();
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                    WebResourceResponse response) {
                if (request != null && request.isForMainFrame() && response != null)
                    BrowserDiagnostics.event(MainActivity.this, "WEB_HTTP", "MAIN_FRAME_STATUS",
                            response.getStatusCode());
            }
            @Override public void onReceivedSslError(WebView view,
                                                      SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never let invalid certificates through.
                BrowserDiagnostics.event(MainActivity.this, "WEB_ERROR", "TLS_REJECTED");
                runOnUiThread(() -> toast("안전하지 않은 연결을 차단했습니다"));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) {
                    BrowserDiagnostics.event(MainActivity.this, "WEB_ERROR", "MAIN_FRAME",
                            Math.abs(error.getErrorCode()));
                    runOnUiThread(() -> toast("웹페이지를 열 수 없습니다"));
                }
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (web != browser) { toast("먼저 해당 웹페이지 탭을 선택하세요"); return; }
            if (MediaDetector.validWebUrl(url)) {
                offerDownload(url, MediaDetector.guessName(url, contentDisposition, mimeType));
            } else {
                toast("이 다운로드 주소는 지원하지 않습니다");
            }
        });
    }

    /** Top-level, one-shot WebView query. No JavaScript bridge is exposed to iframes. */
    private void runScan() {
        if (scanScript.isEmpty() || browser == null || activeTab == null
                || browser.getVisibility() != View.VISIBLE) return;
        final BrowserTab tab = activeTab;
        final WebView currentWeb = browser;
        final String page = currentWeb.getUrl();
        if (!MediaDetector.validWebUrl(page)) return;
        if (!SiteCompatibility.videoScan(this, page)) {
            BrowserDiagnostics.limited(this, "VIDEO_SCAN", "DISABLED_BY_SITE", 60000);
            return;
        }
        if (!page.equals(tab.lastScannedPage)) {
            // Also clear stale candidates on single-page application URL changes.
            Uri previous = Uri.parse(tab.lastScannedPage.isEmpty() ? page : tab.lastScannedPage)
                    .buildUpon().fragment(null).build();
            Uri current = Uri.parse(page).buildUpon().fragment(null).build();
            if (!previous.equals(current)) {
                tab.candidates.clear();
                tab.playerPresent = false;
                tab.playerPlaying = false;
                tab.opaqueStream = false;
                tab.embeddedPlayer = false;
                refreshCandidates();
            }
            tab.lastScannedPage = page;
        }
        final long epoch = tab.epoch;
        currentWeb.evaluateJavascript(scanScript, json -> {
            if (json == null || "null".equals(json) || isFinishing() || isDestroyed()
                    || tab != activeTab || currentWeb != browser || epoch != tab.epoch) return;
            try {
                // WebView JSON-encodes JavaScript's JSON.stringify return string.
                Object decoded = new JSONTokener(json).nextValue();
                if (!(decoded instanceof String)) return;
                JSONObject result = new JSONObject((String) decoded);
                if (!samePageDocument(result.optString("page"))) return;
                JSONObject player = result.optJSONObject("player");
                if (player != null) {
                    tab.playerPresent = player.optInt("videoElements", 0) > 0;
                    tab.playerPlaying = player.optBoolean("playing", false);
                    tab.opaqueStream = player.optBoolean("opaqueStream", false);
                    tab.embeddedPlayer = player.optBoolean("embeddedPlayer", false);
                }
                JSONArray videos = result.optJSONArray("videos");
                if (videos != null) {
                    int adHintCount = 0;
                    for (int i = 0; i < Math.min(videos.length(), 80); i++) {
                        JSONObject sample = videos.optJSONObject(i);
                        if (sample != null && sample.optBoolean("adHint", false)) adHintCount++;
                    }
                    if (adHintCount > 0)
                        BrowserDiagnostics.limited(this, "VIDEO_SCAN", "AD_HINT_SEEN", 15000);
                }
                if (videos == null) {
                    BrowserDiagnostics.limited(this, "VIDEO_SCAN", "RESULT_MISSING", 30000);
                    return;
                }
                String signature = (tab.playerPlaying ? "PLAYING" : tab.playerPresent
                        ? "PLAYER_IDLE" : tab.opaqueStream ? "OPAQUE" : "NO_PLAYER")
                        + "_" + (videos.length() > 0 ? "CANDIDATE" : "NO_FILE");
                if (!signature.equals(tab.diagnosticPlaybackState)) {
                    tab.diagnosticPlaybackState = signature;
                    BrowserDiagnostics.event(this, "VIDEO_SCAN", signature, videos.length());
                }
                for (int i = 0; i < Math.min(80, videos.length()); i++) {
                    JSONObject v = videos.optJSONObject(i);
                    if (v == null) continue;
                    addVideo(tab, v.optString("url"), v.optInt("source", 1),
                            v.optInt("width", 0), v.optInt("height", 0),
                            v.optInt("duration", 0), v.optBoolean("playing", false),
                            v.optBoolean("adHint", false), result.optString("page"), epoch);
                }
                // A playing blob/MSE player is a useful observation, not an HTTP download.
                refreshCandidates();
            } catch (Exception ignored) {
                BrowserDiagnostics.limited(this, "VIDEO_SCAN", "PARSE_FAILED", 30000);
            }
        });
    }

    private void addVideo(BrowserTab tab, String url, int source, int width,
                          int height, int duration, boolean playing, boolean adHint,
                          String page, long epoch) {
        if (!MediaDetector.validWebUrl(url) || MediaDetector.adLike(url)
                || MediaDetector.isOpaqueStreamUrl(url)
                || MediaDetector.isYoutubePage(page)
                || (source <= 1 && !MediaDetector.looksLikeVideo(url))) return;
        ui.post(() -> {
            if (isFinishing() || isDestroyed() || tab != activeTab || epoch != tab.epoch) return;
            if (page != null && !samePageDocument(page)) return;
            VideoCandidate candidate = tab.candidates.get(url);
            if (candidate == null) {
                if (tab.candidates.size() >= 90) {
                    // Preserve room for the actual in-page player when many ads/resources exist.
                    if (source < 2) return;
                    String low = null;
                    for (Map.Entry<String, VideoCandidate> item : tab.candidates.entrySet()) {
                        if (item.getValue().source <= 1) { low = item.getKey(); break; }
                    }
                    if (low == null) return;
                    tab.candidates.remove(low);
                }
                candidate = new VideoCandidate(url);
                tab.candidates.put(url, candidate);
            }
            Uri pageUri = Uri.parse(browser.getUrl() == null ? HOME : browser.getUrl());
            candidate.observe(source, width, height, duration, playing, pageUri.getHost(), adHint);
            refreshCandidates();
        });
    }

    // Exact top-level document match, not merely same host. URL fragments are
    // excluded because they do not identify a different network document.
    // This does NOT authenticate messages from untrusted JavaScript frames.
    private boolean samePageDocument(String page) {
        if (!MediaDetector.validWebUrl(page)) return false;
        String current = browser.getUrl();
        if (!MediaDetector.validWebUrl(current)) return false;
        Uri reported = Uri.parse(page).buildUpon().fragment(null).build();
        Uri visible = Uri.parse(current).buildUpon().fragment(null).build();
        return reported.equals(visible);
    }

    private List<VideoCandidate> rankedCandidates() {
        List<VideoCandidate> list = new ArrayList<>();
        if (activeTab == null) return list;
        for (VideoCandidate c : activeTab.candidates.values()) {
            c.refresh();
            if (c.allowed()) list.add(c);
        }
        list.sort((a, b) -> Integer.compare(b.score(), a.score()));
        return list;
    }

    private VideoCandidate bestCandidate() {
        List<VideoCandidate> items = rankedCandidates();
        return !items.isEmpty() && items.get(0).recommended() ? items.get(0) : null;
    }

    private void refreshCandidates() {
        List<VideoCandidate> list = rankedCandidates();
        VideoCandidate best = !list.isEmpty() && list.get(0).recommended() ? list.get(0) : null;
        int good = 0;
        for (VideoCandidate item : list) if (item.recommended()) good++;
        tabDetect.setText(good == 0 ? "영상 찾기" : "영상 찾기 (" + good + ")");
        boolean youtube = MediaDetector.isYoutubePage(browser == null ? null : browser.getUrl());
        boolean playerOnly = best == null && activeTab != null
                && (activeTab.playerPlaying || activeTab.opaqueStream
                    || activeTab.playerPresent || activeTab.embeddedPlayer || youtube);
        detectedCard.setVisibility(best == null && !playerOnly ? View.GONE : View.VISIBLE);
        if (playerOnly) {
            detectedSummary.setText(youtube
                    ? (activeTab.playerPlaying ? "▶ 유튜브 영상 재생 확인" : "▶ 유튜브 페이지 확인")
                      + " · 다운로드 가능한 파일 주소 없음"
                    : (activeTab.playerPlaying ? "▶ 영상 재생 확인" : "▶ 영상 플레이어 확인")
                      + " · 직접 다운로드 주소 미확인");
            moreVideos.setVisibility(View.GONE);
            quickDownload.setText("안내");
        }
        if (best != null) {
            String title = browser.getTitle();
            if (title == null || title.trim().isEmpty()) title = "현재 페이지";
            if (title.length() > 24) title = title.substring(0, 24) + "…";
            detectedSummary.setText((best.active ? "▶ 재생 영상" : "▶ 영상 후보")
                    + " · " + best.qualityLabel() + " · " + title);
            moreVideos.setVisibility(good > 1 ? View.VISIBLE : View.GONE);
            quickDownload.setText(MediaDetector.isHls(best.url) ? "화질 · 받기" : "다운로드");
        }
    }

    private String friendlyName(String url) {
        String title = browser.getTitle();
        if (title == null || title.trim().isEmpty()) title = "영상";
        String name = DownloadStore.safeFileName(title);
        if (name.length() > 65) name = name.substring(0, 65);
        String path = Uri.parse(url).getPath();
        String ext = ".mp4";
        if (path != null) {
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".webm")) ext = ".webm";
            else if (lower.endsWith(".mov")) ext = ".mov";
            else if (lower.endsWith(".m4v")) ext = ".m4v";
        }
        return name + (MediaDetector.isHls(url) ? ".ts" : ext);
    }

    private void showVideos() {
        List<VideoCandidate> all = rankedCandidates();
        BrowserDiagnostics.event(this, "VIDEO_PICKER", all.isEmpty() ? "EMPTY" : "CANDIDATES", all.size());
        List<VideoCandidate> list = new ArrayList<>();
        for (VideoCandidate c : all) if (c.recommended()) list.add(c);
        if (list.isEmpty()) {
            boolean youtube = MediaDetector.isYoutubePage(browser == null ? null : browser.getUrl());
            boolean playback = activeTab != null && activeTab.playerPlaying;
            String message = youtube
                    ? (playback ? "유튜브 영상의 재생 상태는 확인됐습니다. "
                           : "유튜브 페이지를 확인했습니다. ")
                      + "하지만 유튜브의 분할·보호 스트리밍에서 저장 가능한 단일 영상 파일 주소를 확인하지 못했습니다. "
                      + "브라우저가 영상을 재생할 수 있다고 해서 파일 다운로드까지 가능한 것은 아닙니다. "
                      + "유튜브에서 허용하는 오프라인 저장이나 본인 영상의 공식 다운로드를 이용해주세요."
                    : (playback ? "영상 재생은 확인됐지만 저장 가능한 직접 파일 주소가 없습니다. " : "")
                      + "사이트에서 원하는 영상을 재생한 뒤 '영상 찾기'를 다시 눌러주세요. "
                      + "광고로 추정되는 주소는 숨겼으며 blob·보호된 스트리밍은 직접 저장할 수 없습니다.";
            new AlertDialog.Builder(this).setTitle(youtube
                    ? "유튜브 재생 확인 · 다운로드 제한" : "다운로드 가능한 영상 주소 없음")
                .setMessage(message)
                .setPositiveButton("다시 찾기", (d,w) -> runScan())
                .setNeutralButton(all.isEmpty() ? "주소 직접 입력" : "기타 영상 후보 (주의)",
                    (d,w) -> {
                        if (all.isEmpty()) enterDownloadUrl();
                        else showLowConfidence(all);
                    })
                .setNegativeButton("닫기", null).show();
            return;
        }
        // Only surface a few high-confidence results; don't dump ad/network resource URLs.
        if (list.size() > 8) list = new ArrayList<>(list.subList(0, 8));
        final List<VideoCandidate> choices = list;
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            VideoCandidate c = choices.get(i);
            Uri uri = Uri.parse(c.url);
            labels[i] = (c.active ? "▶ 재생 중" : "영상 후보") + " · "
                    + c.qualityLabel() + " · " + (MediaDetector.isHls(c.url) ? "HLS" : "파일")
                    + "\n" + uri.getHost();
        }
        new AlertDialog.Builder(this).setTitle("본편으로 추정되는 영상 " + choices.size() + "개")
            .setItems(labels, (d, which) -> {
                String url = choices.get(which).url;
                offerDownload(url, friendlyName(url));
            })
            .setNeutralButton("주소 직접 입력", (d, w) -> enterDownloadUrl())
            .setNegativeButton("닫기", null).show();
    }

    private void showLowConfidence(List<VideoCandidate> all) {
        int max = Math.min(5, all.size());
        String[] labels = new String[max];
        for (int i = 0; i < max; i++) {
            VideoCandidate c = all.get(i);
            labels[i] = "확인되지 않은 영상 · " + c.qualityLabel()
                + "\n" + Uri.parse(c.url).getHost();
        }
        new AlertDialog.Builder(this).setTitle("기타 후보 · 광고 영상 포함 가능")
            .setItems(labels, (d, index) -> {
                String url = all.get(index).url;
                offerDownload(url, friendlyName(url));
            })
            .setNegativeButton("닫기", null).show();
    }

    private void chooseFolder() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, FOLDER_PICKER);
        } catch (Exception e) { toast("폴더 선택기를 실행할 수 없습니다"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_IMPORT_PICKER && resultCode == RESULT_OK && data != null
                && data.getData() != null) confirmRestoreBackup(data.getData());
        if (requestCode == FOLDER_PICKER && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                StorageTarget.choose(this, tree);
                refreshFolderLabel();
                toast("저장 폴더를 변경했습니다");
            } catch (SecurityException e) {
                toast("선택한 폴더의 쓰기 권한을 얻지 못했습니다");
            }
        }
        if (requestCode == FOLDER_PICKER && pendingUrl != null) {
            String url = pendingUrl, name = pendingName;
            pendingUrl = null; pendingName = null;
            if (resultCode == RESULT_OK) offerDownload(url, name);
        }
    }

    private void refreshFolderLabel() {
        folderLabel.setText("저장 위치: " + StorageTarget.display(this));
    }

    private void enterDownloadUrl() {
        EditText text = new EditText(this);
        text.setSingleLine(false);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        text.setHint("https://example.com/video.mp4");
        text.setPadding(32, 20, 32, 20);
        new AlertDialog.Builder(this).setTitle("동영상 주소 붙여넣기")
                .setView(text)
                .setPositiveButton("다음", (d, w) -> {
                    String url = text.getText().toString().trim();
                    if (MediaDetector.validWebUrl(url))
                        offerDownload(url, MediaDetector.guessName(url, null, null));
                    else toast("http:// 또는 https:// 주소를 입력하세요");
                })
                .setNegativeButton("취소", null).show();
    }

    private void offerDownload(String url, String suggestedName) {
        if (!MediaDetector.validWebUrl(url)) { toast("다운로드 주소 오류"); return; }
        boolean hls = MediaDetector.isHls(url);
        EditText nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setText(suggestedName);
        nameBox.setSelectAllOnFocus(true);
        nameBox.setPadding(32, 24, 32, 24);
        new AlertDialog.Builder(this).setTitle(hls ? "영상 저장 · 화질 선택" : "영상 다운로드")
            .setMessage("저장 위치: " + StorageTarget.display(this)
                + (hls ? "\n실제 제공되는 화질을 다음 화면에서 선택합니다." :
                    "\nMP4 파일은 사이트에서 제공하는 원본 화질로 저장합니다."))
            .setView(nameBox)
            .setPositiveButton(hls ? "화질 선택" : "다운로드", (d, w) -> {
                String name = DownloadStore.safeFileName(nameBox.getText().toString());
                if (hls) {
                    int dot = name.lastIndexOf('.');
                    name = (dot > 0 ? name.substring(0, dot) : name) + ".ts";
                    chooseHlsQuality(url, name);
                } else downloadDirect(url, name);
            })
            .setNeutralButton("폴더 선택", (d, w) -> {
                pendingUrl = url;
                pendingName = DownloadStore.safeFileName(nameBox.getText().toString());
                chooseFolder();
            })
            .setNegativeButton("취소", null).show();
    }

    private void chooseHlsQuality(String url, String filename) {
        final String referer = browser.getUrl();
        final String ua = browser.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final AlertDialog loading = new AlertDialog.Builder(this)
                .setTitle("화질 확인 중")
                .setMessage("영상 사이트가 제공하는 화질을 확인합니다…")
                .setNegativeButton("취소", null).create();
        loading.show();
        new Thread(() -> {
            List<HlsQualityResolver.Quality> qualities = null;
            String error = null;
            try { qualities = HlsQualityResolver.inspect(url, referer, ua, cookie); }
            catch (Exception e) { error = e.getMessage(); }
            final List<HlsQualityResolver.Quality> options = qualities;
            final String reason = error;
            ui.post(() -> {
                if (isDestroyed() || isFinishing() || !loading.isShowing()) return;
                loading.dismiss();
                if (reason != null) {
                    new AlertDialog.Builder(this).setTitle("화질 정보를 확인하지 못했습니다")
                        .setMessage(reason + "\n원본 영상 주소로 다운로드를 시도할 수 있습니다.")
                        .setPositiveButton("원본으로 시도", (d,w) -> startHlsDownload(url, filename))
                        .setNegativeButton("취소", null).show();
                    return;
                }
                String[] labels = new String[options.size()];
                for (int i=0; i < options.size(); i++) labels[i] = options.get(i).label;
                new AlertDialog.Builder(this).setTitle("영상 화질 선택")
                    .setSingleChoiceItems(labels, 0, (dialog, which) -> {
                        dialog.dismiss();
                        startHlsDownload(options.get(which).url, filename);
                    })
                    .setNegativeButton("취소", null).show();
            });
        }, "HlsQualityInspect").start();
    }

    private void maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33
                || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED) return;
        android.content.SharedPreferences prefs = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("notification_permission_asked", false)) return;
        prefs.edit().putBoolean("notification_permission_asked", true).apply();
        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 6610);
    }

    private void startHlsDownload(String url, String filename) {
        startServiceDownload(url, filename, "hls");
    }

    private void startServiceDownload(String url, String filename, String mode) {
        enqueueService(url, filename, mode, StorageTarget.selected(this),
                browser == null ? "" : browser.getUrl(),
                browser == null ? "" : browser.getSettings().getUserAgentString());
    }

    private boolean enqueueService(String url, String filename, String mode,
                                   String folder, String referer, String ua) {
        if (!MediaDetector.validWebUrl(url)) return false;
        String id = mode + "-" + UUID.randomUUID();
        String kind = "service-" + mode;
        filename = DownloadStore.freshName(this, filename);
        DownloadStore.addSource(this, id, kind, filename, url, referer, folder, ua);
        Intent intent = new Intent(this, HlsDownloadService.class);
        intent.putExtra("id", id);
        intent.putExtra("mode", mode);
        intent.putExtra("url", url);
        intent.putExtra("filename", filename);
        intent.putExtra("folder", folder);
        intent.putExtra("referer", referer);
        intent.putExtra("ua", ua);
        // Resolve the current site's cookie at retry time; never save session secrets in history.
        intent.putExtra("cookie", CookieManager.getInstance().getCookie(url));
        try {
            maybeRequestNotificationPermission();
            BrowserDiagnostics.event(this, "DOWNLOAD", "ENQUEUE_" + mode.toUpperCase(Locale.ROOT));
            startForegroundService(intent);
            toast("다운로드를 시작했습니다");
            return true;
        } catch (Exception e) {
            BrowserDiagnostics.event(this, "DOWNLOAD", "START_FAILED");
            DownloadStore.update(this, id, "실패: 다운로드 서비스 시작 오류", 0);
            toast("다운로드를 시작할 수 없습니다");
            return false;
        }
    }

    private void downloadDirect(String url, String filename) {
        enqueueService(url, filename, "direct", StorageTarget.selected(this),
                browser == null ? "" : browser.getUrl(),
                browser == null ? "" : browser.getSettings().getUserAgentString());
    }

    /** System DownloadManager has automatic network retry, but no app pause/resume API. */
    private boolean enqueueDirect(String url, String filename, String referer, String ua) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription(getString(R.string.app_name));
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS, "믿음하나/" + filename);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            if (ua != null && !ua.isEmpty()) request.addRequestHeader("User-Agent", ua);
            if (MediaDetector.validWebUrl(referer)) request.addRequestHeader("Referer", referer);
            if (filename.toLowerCase(Locale.ROOT).endsWith(".mp4"))
                request.setMimeType("video/mp4");
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            DownloadStore.addSource(this, String.valueOf(id), "direct", filename,
                    url, referer, "", ua);
            toast("다운로드를 시작했습니다");
            return true;
        } catch (Exception e) {
            toast("다운로드 실패: " + e.getClass().getSimpleName());
            return false;
        }
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        String url;
        if (MediaDetector.validWebUrl(input)) url = input;
        else if (input.matches("(?i)^[^\\s]+\\.[a-z]{2,}([/:?].*)?$")) url = "https://" + input;
        else url = "https://www.google.com/search?q=" + Uri.encode(input);
        showPanel("web");
        browser.loadUrl(url);
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    private void showPanel(String name) {
        boolean download = "downloads".equals(name);
        boolean bookmark = "bookmarks".equals(name);
        downloadsPanel.setVisibility(download ? View.VISIBLE : View.GONE);
        bookmarksPanel.setVisibility(bookmark ? View.VISIBLE : View.GONE);
        for (BrowserTab tab : webTabs) {
            if (tab.web == null) continue;
            tab.web.setVisibility(!download && !bookmark && tab == activeTab
                    ? View.VISIBLE : View.GONE);
        }
        if (!download && !bookmark) {
            refreshCandidates();
            ui.removeCallbacks(scanTick);
            ui.post(scanTick);
        } else {
            ui.removeCallbacks(scanTick);
            detectedCard.setVisibility(View.GONE);
        }
        if (download) refreshFolderLabel();
        tabWeb.setTextColor(!download && !bookmark ? 0xff1357b5 : 0xff303030);
        tabDownloads.setTextColor(download ? 0xff1357b5 : 0xff303030);
        tabBookmarks.setTextColor(bookmark ? 0xff1357b5 : 0xff303030);
        tabDetect.setTextColor(0xff303030);
        ui.removeCallbacks(tick);
        if (download) { renderDownloads(); ui.postDelayed(tick, 2000); }
        if (bookmark) renderBookmarks();
    }

    private void renderBookmarks() {
        List<String> labels = new ArrayList<>();
        for (JSONObject item : Bookmarks.all(this)) {
            labels.add(item.optString("title") + "\n" + item.optString("url"));
        }
        if (labels.isEmpty()) labels.add("즐겨찾기가 없습니다. 웹사이트에서 ☆ 버튼을 누르세요.");
        bookmarksList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void installDownloadAdapter() {
        downloadsAdapter = new BaseAdapter() {
            @Override public int getCount() { return downloadRows.isEmpty() ? 1 : downloadRows.size(); }
            @Override public Object getItem(int position) {
                return downloadRows.isEmpty() ? null : downloadRows.get(position);
            }
            @Override public long getItemId(int position) {
                return downloadRows.isEmpty() ? -1 : downloadRows.get(position).id.hashCode();
            }
            @Override public boolean hasStableIds() { return true; }
            @Override public View getView(int position, View recycled, ViewGroup parent) {
                TextView label = recycled instanceof TextView ? (TextView) recycled : new TextView(MainActivity.this);
                label.setTextSize(14);
                label.setTextColor(0xff1B354B);
                label.setPadding(dp(12), dp(9), dp(12), dp(9));
                label.setMinHeight(dp(58));
                if (downloadRows.isEmpty()) {
                    label.setText("다운로드 내역이 없습니다. 웹페이지에서 영상을 선택하세요.");
                    label.setBackgroundColor(0xffffffff);
                } else {
                    DownloadRow row = downloadRows.get(position);
                    label.setText((selectingDownloads ? (selectedDownloadIds.contains(row.id) ? "☑ " : "☐ ") : "")
                            + row.label());
                    label.setBackgroundColor(selectedDownloadIds.contains(row.id) ? 0xffDFEFFF : 0xffffffff);
                }
                return label;
            }
        };
        downloadsList.setAdapter(downloadsAdapter);
    }

    private void setDownloadSelection(boolean on) {
        selectingDownloads = on;
        if (!on) selectedDownloadIds.clear();
        downloadBulkActions.setVisibility(on ? View.VISIBLE : View.GONE);
        ((Button) findViewById(R.id.select_downloads)).setText(on ? "선택 취소" : "선택");
        redrawDownloadSelection();
    }

    private void redrawDownloadSelection() {
        int first = downloadsList.getFirstVisiblePosition();
        View child = downloadsList.getChildAt(0);
        int top = child == null ? 0 : child.getTop();
        downloadsAdapter.notifyDataSetChanged();
        downloadsList.post(() -> downloadsList.setSelectionFromTop(first, top));
    }

    /** Update visible rows without rebuilding the adapter every two seconds. */
    private void renderDownloads() {
        List<DownloadRow> next = new ArrayList<>();
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        for (JSONObject entry : DownloadStore.list(this)) {
            String id = entry.optString("id");
            String status = entry.optString("status", "대기 중");
            int percent = entry.optInt("progress", 0);
            if ("direct".equals(entry.optString("type"))
                    && !status.startsWith("중지")) {
                try {
                    long number = Long.parseLong(id);
                    try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                        if (cursor != null && cursor.moveToFirst()) {
                            int raw = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            long done = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                            percent = total > 0 ? (int) Math.min(100, done * 100 / total) : 0;
                            if (raw == DownloadManager.STATUS_SUCCESSFUL) { status = "완료"; percent = 100; }
                            else if (raw == DownloadManager.STATUS_RUNNING) status = "다운로드 중";
                            else if (raw == DownloadManager.STATUS_PAUSED) status = "일시 대기 (시스템 자동 재시도)";
                            else if (raw == DownloadManager.STATUS_FAILED) status = "실패";
                            else status = "대기 중";
                        } else status = "시스템에 다운로드 기록 없음";
                    }
                } catch (Exception e) { status = "상태 확인 실패"; }
            }
            next.add(new DownloadRow(entry, status, percent));
        }
        int first = downloadsList.getFirstVisiblePosition();
        View topView = downloadsList.getChildAt(0);
        int top = topView == null ? 0 : topView.getTop();
        boolean changedStructure = next.size() != downloadRows.size();
        if (!changedStructure) {
            for (int i = 0; i < next.size(); i++) {
                if (!next.get(i).id.equals(downloadRows.get(i).id)) {
                    changedStructure = true; break;
                }
            }
        }
        if (changedStructure) {
            downloadRows.clear();
            downloadRows.addAll(next);
            downloadsAdapter.notifyDataSetChanged();
            // Restore the exact row and pixel offset after insertion/removal.
            downloadsList.post(() -> downloadsList.setSelectionFromTop(
                    Math.min(first, Math.max(0, downloadsAdapter.getCount() - 1)), top));
        } else {
            for (int i = 0; i < next.size(); i++) {
                DownloadRow previous = downloadRows.get(i), current = next.get(i);
                String oldLabel = previous.label();
                previous.entry = current.entry;
                previous.status = current.status;
                previous.progress = current.progress;
                if (!oldLabel.equals(previous.label())) {
                    int child = i - first;
                    if (child >= 0 && child < downloadsList.getChildCount()) {
                        View visible = downloadsList.getChildAt(child);
                        if (visible instanceof TextView) {
                            ((TextView) visible).setText((selectingDownloads
                                    ? (selectedDownloadIds.contains(previous.id) ? "☑ " : "☐ ") : "")
                                    + previous.label());
                        }
                    }
                }
            }
        }
        selectedDownloadIds.retainAll(downloadIds());
    }

    private Set<String> downloadIds() {
        Set<String> ids = new HashSet<>();
        for (DownloadRow row : downloadRows) ids.add(row.id);
        return ids;
    }

    private boolean isActive(DownloadRow row) {
        String state = row.entry.optString("state");
        if (row.entry.optString("type").startsWith("service-")
                && (HlsDownloadService.isJobActive(row.id) || "RUNNING".equals(state)
                    || "QUEUED".equals(state) || "RETRY_WAIT".equals(state))) return true;
        String s = row.status;
        return s.startsWith("다운로드 중") || s.startsWith("대기 중")
                || s.startsWith("일시 대기") || s.startsWith("중지 요청")
                || s.startsWith("이어받기 준비") || s.startsWith("다운로드 재개 중");
    }

    private void showDownloadActions(DownloadRow row) {
        List<String> actions = new ArrayList<>();
        if (row.status.startsWith("완료")) {
            actions.add("완료 파일 열기");
            actions.add("완료 파일 공유");
        }
        if (isActive(row)) actions.add("다운로드 중지");
        if (!isActive(row) && row.entry.optString("type").startsWith("service-")
                && !row.status.startsWith("완료")) actions.add("이어받기 (가능한 지점부터)");
        if (!isActive(row)) actions.add("다시 받기 (처음부터)");
        actions.add("삭제 옵션…");
        new AlertDialog.Builder(this).setTitle(row.entry.optString("name"))
            .setItems(actions.toArray(new String[0]), (d, which) -> {
                String action = actions.get(which);
                if (action.equals("완료 파일 열기")) openCompletedDownload(row.entry);
                else if (action.equals("완료 파일 공유")) shareCompletedDownload(row.entry);
                else if (action.startsWith("다운로드 중지")) stopDownload(row);
                else if (action.startsWith("이어받기")) resumeDownload(row, false);
                else if (action.startsWith("다시 받기")) resumeDownload(row, true);
                else { selectedDownloadIds.clear(); selectedDownloadIds.add(row.id); confirmDeleteSelected(); }
            }).setNegativeButton("닫기", null).show();
    }

    private void stopDownload(DownloadRow row) {
        if (!isActive(row)) return;
        if ("direct".equals(row.entry.optString("type"))) {
            try {
                DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (manager.remove(Long.parseLong(row.id)) <= 0) { toast("시스템 다운로드를 찾지 못했습니다"); return; }
                DownloadStore.update(this, row.id, "중지됨 · 처음부터 다시 받기", 0);
            } catch (Exception e) { toast("중지 실패"); return; }
        } else {
            if (!HlsDownloadService.isJobActive(row.id)) {
                DownloadStore.patch(this, row.id, "state", "PAUSED", "status", "중지됨 · 이어받기 가능");
                renderDownloads();
                return;
            }
            try {
                Intent stop = new Intent(this, HlsDownloadService.class);
                stop.setAction(HlsDownloadService.ACTION_CANCEL);
                stop.putExtra("id", row.id);
                startService(stop);
                DownloadStore.patch(this, row.id, "status", "중지 요청 중");
            } catch (Exception e) { toast("중지 명령 실패"); return; }
        }
        renderDownloads();
    }

    private void retryDownload(DownloadRow row) { resumeDownload(row, false); }

    /** Same task ID preserves validated private chunks; full restart creates a fresh transfer. */
    private void resumeDownload(DownloadRow row, boolean restart) {
        if (isActive(row)) { toast("먼저 현재 작업을 중지하세요"); return; }
        JSONObject entry = DownloadStore.get(this, row.id);
        if (entry == null) return;
        String url = entry.optString("url");
        if (!MediaDetector.validWebUrl(url)) { toast("이전 기록의 영상 주소가 없습니다"); return; }
        String type = entry.optString("type");
        String filename = entry.optString("name");
        String folder = entry.optString("folder");
        String referer = entry.optString("referer");
        String ua = entry.optString("ua");
        if (!type.startsWith("service-")) {
            boolean ok = "direct".equals(type) ? enqueueService(url, filename, "direct", folder, referer, ua) : false;
            if (ok) toast("과거 시스템 다운로드는 처음부터 새로 받습니다");
            else toast("다시 받기를 시작할 수 없습니다");
            return;
        }
        if (restart || "COMPLETED".equals(entry.optString("state"))) {
            if (enqueueService(url, filename, type.substring("service-".length()), folder, referer, ua))
                toast("처음부터 새 다운로드로 시작합니다");
            return;
        }
        if (HlsDownloadService.isJobActive(row.id)) {
            toast("이전 다운로드 중지 처리 중입니다"); return;
        }
        DownloadStore.patch(this, row.id, "state", "QUEUED", "status", "이어받기 준비 중");
        Intent start = new Intent(this, HlsDownloadService.class).putExtra("id", row.id);
        try {
            startForegroundService(start);
            toast("저장된 지점부터 이어받기를 시도합니다");
        } catch (Exception e) {
            DownloadStore.patch(this, row.id, "state", "RECOVERY", "status", "이어받기 실패 · 다시 선택");
            toast("이어받기를 시작할 수 없습니다");
        }
        renderDownloads();
    }

    private void performBulk(String operation) {
        List<DownloadRow> chosen = new ArrayList<>();
        for (DownloadRow row : downloadRows)
            if (selectedDownloadIds.contains(row.id)) chosen.add(row);
        if (chosen.isEmpty()) { toast("작업할 다운로드를 선택하세요"); return; }
        if ("stop".equals(operation)) for (DownloadRow row : chosen) stopDownload(row);
        if ("retry".equals(operation)) for (DownloadRow row : chosen) retryDownload(row);
        renderDownloads();
    }

    private void confirmDeleteSelected() {
        if (selectedDownloadIds.isEmpty()) { toast("삭제할 다운로드를 선택하세요"); return; }
        final Set<String> ids = new HashSet<>(selectedDownloadIds);
        String[] options = {"목록에서만 삭제 (파일 유지)", "목록과 다운로드 파일 함께 삭제"};
        new AlertDialog.Builder(this).setTitle("선택한 " + ids.size() + "개 다운로드 삭제")
            .setItems(options, (d, which) -> {
                int success = 0, skipped = 0;
                for (DownloadRow row : new ArrayList<>(downloadRows)) {
                    if (!ids.contains(row.id)) continue;
                    if (removeDownload(row, which == 1)) success++; else skipped++;
                }
                selectedDownloadIds.clear();
                renderDownloads();
                toast("삭제 " + success + "개" + (skipped > 0 ? ", 확인 필요 " + skipped + "개" : ""));
            }).setNegativeButton("취소", null).show();
    }

    private boolean removeDownload(DownloadRow row, boolean deleteFile) {
        // Do not hide an active worker: users need to be able to stop it first.
        if (isActive(row) && !deleteFile) return false;
        if ("direct".equals(row.entry.optString("type"))) {
            if (deleteFile && !row.status.startsWith("중지")) {
                try {
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (dm.remove(Long.parseLong(row.id)) <= 0) return false;
                } catch (Exception e) { return false; }
            }
        } else {
            if (isActive(row)) {
                stopDownload(row);
                toast("먼저 중지했습니다. 중지 완료 후 파일 삭제를 다시 선택하세요");
                return false;
            }
            if (deleteFile) {
                String fileUri = row.entry.optString("uri");
                if (!fileUri.isEmpty()) {
                    try {
                        Uri uri = Uri.parse(fileUri);
                        boolean deleted = "content".equals(uri.getScheme())
                                && (uri.getAuthority() != null && uri.getAuthority().contains("documents")
                                    ? DocumentsContract.deleteDocument(getContentResolver(), uri)
                                    : getContentResolver().delete(uri, null, null) > 0);
                        if (!deleted) return false;
                    } catch (Exception e) { return false; }
                }
            }
        }
        DownloadStore.remove(this, row.id);
        HlsDownloadService.discardStaging(this, row.id);
        return true;
    }

    private Uri resolveCompletedUri(JSONObject entry) throws Exception {
        if (!"COMPLETED".equals(entry.optString("state"))
                && !entry.optString("status").startsWith("완료"))
            throw new Exception("다운로드가 완료되지 않았습니다");
        if ("direct".equals(entry.optString("type"))) {
            long number = Long.parseLong(entry.optString("id"));
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                if (cursor == null || !cursor.moveToFirst() || cursor.getInt(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        != DownloadManager.STATUS_SUCCESSFUL) throw new Exception("시스템 다운로드가 완료되지 않았습니다");
            }
            return manager.getUriForDownloadedFile(number);
        }
        String saved = entry.optString("uri");
        if (saved.isEmpty()) throw new Exception("저장 파일 정보가 없습니다");
        return Uri.parse(saved);
    }

    private void openCompletedDownload(JSONObject entry) {
        try {
            Uri file = resolveCompletedUri(entry);
            if (file == null) throw new Exception("파일을 찾을 수 없습니다");
            String mime = MediaTypes.fromFileName(entry.optString("name"));
            Intent view = new Intent(Intent.ACTION_VIEW);
            view.setDataAndType(file, mime);
            view.setClipData(ClipData.newRawUri("다운로드", file));
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(view, mime.startsWith("image/") ? "이미지 열기" : "파일 열기"));
        } catch (Exception e) { toast("파일 열기 실패: " + e.getMessage()); }
    }

    private void shareCompletedDownload(JSONObject entry) {
        try {
            Uri file = resolveCompletedUri(entry);
            if (file == null) throw new Exception("파일을 찾을 수 없습니다");
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(MediaTypes.fromFileName(entry.optString("name")));
            share.putExtra(Intent.EXTRA_STREAM, file);
            share.setClipData(ClipData.newRawUri("다운로드", file));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "다운로드 파일 공유"));
        } catch (Exception e) { toast("파일 공유 실패: " + e.getMessage()); }
    }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() {
        if (fullscreenLayer != null) {
            leaveVideoFullscreen(true);
            return;
        }
        if (selectingDownloads && downloadsPanel.getVisibility() == View.VISIBLE) {
            setDownloadSelection(false);
            return;
        }
        if (downloadsPanel.getVisibility() == View.VISIBLE
                || bookmarksPanel.getVisibility() == View.VISIBLE) showPanel("web");
        else if (browser.canGoBack()) browser.goBack();
        else if (webTabs.size() > 1) closeWebTab(activeTab);
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        persistTabs();
        BrowserDiagnostics.event(this, "ACTIVITY", "PAUSED");
        super.onPause();
        ui.removeCallbacks(tick);
        ui.removeCallbacks(scanTick);
        for (BrowserTab tab : webTabs) if (tab.web != null) tab.web.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        BrowserDiagnostics.event(this, "ACTIVITY", "RESUMED");
        if (browser != null) browser.onResume();
        ui.removeCallbacks(scanTick);
        if (browser != null && browser.getVisibility() == View.VISIBLE) ui.post(scanTick);
        if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
            ui.removeCallbacks(tick);
            renderDownloads();
            ui.postDelayed(tick, 2000);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("browser_tabs_count", webTabs.size());
        state.putInt("browser_tab_selected", Math.max(0, webTabs.indexOf(activeTab)));
        for (int i = 0; i < webTabs.size(); i++) {
            Bundle tabState = new Bundle();
            BrowserTab tab = webTabs.get(i);
            WebView web = tab.web;
            if (web != null) web.saveState(tabState);
            else if (tab.savedWebState != null) tabState.putAll(tab.savedWebState);
            tabState.putString("last_url", MediaDetector.validWebUrl(tab.url()) ? tab.url() : homeUrl());
            state.putBundle("browser_tab_" + i, tabState);
        }
        super.onSaveInstanceState(state);
    }

    /** Release old background renderers only when Android reports memory pressure. */
    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        BrowserDiagnostics.event(this, "MEMORY", "TRIM", level);
        // UI_HIDDEN alone must never discard a user's in-progress page.
        if (level != android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW
                && level != android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
                && level != android.content.ComponentCallbacks2.TRIM_MEMORY_MODERATE
                && level != android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE) return;
        if (isFinishing() || isDestroyed()) return;
        List<BrowserTab> inactive = new ArrayList<>();
        int live = 0;
        for (BrowserTab tab : webTabs) {
            if (tab.web != null) live++;
            if (tab != activeTab && tab.web != null) inactive.add(tab);
        }
        inactive.sort((a,b) -> Long.compare(a.lastUsedAt, b.lastUsedAt));
        long now = android.os.SystemClock.uptimeMillis();
        for (BrowserTab tab : inactive) {
            if (live <= 3) break;
            if (now - tab.lastUsedAt < 30000 || tab.web.getProgress() < 100
                    || tab.web.hasFocus()) continue;
            WebView old = tab.web;
            if (MediaDetector.validWebUrl(old.getUrl())) tab.savedUrl = old.getUrl();
            if (old.getTitle() != null) tab.savedTitle = old.getTitle();
            Bundle state = new Bundle();
            try { if (old.saveState(state) != null) tab.savedWebState = state; }
            catch (Exception ignored) { }
            tabLookup.remove(old);
            tab.web = null;
            old.onPause();
            old.stopLoading();
            old.setWebChromeClient(null);
            old.setWebViewClient(null);
            webContainer.removeView(old);
            old.destroy();
            BrowserDiagnostics.event(this, "TABS", "HIBERNATED");
            live--;
        }
    }

    @Override protected void onDestroy() {
        BrowserDiagnostics.event(this, "ACTIVITY", "DESTROYED");
        leaveVideoFullscreen(true);
        persistTabs();
        ui.removeCallbacksAndMessages(null);
        for (BrowserTab tab : webTabs) {
            if (tab.web == null) continue;
            tab.web.stopLoading();
            tab.web.setWebChromeClient(null);
            tab.web.setWebViewClient(null);
            tab.web.destroy();
        }
        webTabs.clear();
        tabLookup.clear();
        super.onDestroy();
    }
}
