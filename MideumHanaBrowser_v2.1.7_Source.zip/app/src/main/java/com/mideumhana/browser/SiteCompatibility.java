package com.mideumhana.browser;

import android.content.Context;
import android.net.Uri;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import org.json.JSONObject;
import java.util.Map;

/** Site-local opt-outs. Host name is hashed before using it as a preference key. */
final class SiteCompatibility {
    private static final String PREF = "browser_site_compat_v1";
    private SiteCompatibility() { }
    static String host(String page) {
        if (!MediaDetector.validWebUrl(page)) return "";
        String h = Uri.parse(page).getHost();
        return h == null ? "" : h.toLowerCase(Locale.ROOT);
    }
    private static String key(String host, String feature) {
        if (host == null || host.isEmpty()) return "";
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(host.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder(feature).append('_');
            for (int i = 0; i < 12; i++) result.append(String.format(Locale.ROOT, "%02x", hash[i] & 255));
            return result.toString();
        } catch (Exception e) { return ""; }
    }
    private static boolean enabled(Context c, String page, String feature) {
        String token = key(host(page), feature);
        return token.isEmpty() || c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getBoolean(token, true);
    }
    static boolean adBlock(Context c, String page) { return enabled(c, page, "ad"); }
    static boolean videoScan(Context c, String page) { return enabled(c, page, "scan"); }
    static void save(Context c, String page, boolean ad, boolean scan) {
        String host = host(page);
        if (host.isEmpty()) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean(key(host, "ad"), ad)
                .putBoolean(key(host, "scan"), scan).apply();
    }
    static JSONObject backup(Context c) throws Exception {
        JSONObject json = new JSONObject();
        for (Map.Entry<String, ?> item : c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getAll().entrySet()) {
            if (!validBackupKey(item.getKey()) || !(item.getValue() instanceof Boolean)) continue;
            if (json.length() >= 200) break;
            json.put(item.getKey(), (Boolean) item.getValue());
        }
        return json;
    }
    static void validateBackup(JSONObject json) throws Exception {
        if (json == null || json.length() > 200) throw new Exception("사이트 설정 항목이 너무 많습니다");
        java.util.Iterator<String> keys = json.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (!validBackupKey(key) || !(json.opt(key) instanceof Boolean))
                throw new Exception("사이트 설정 내용이 올바르지 않습니다");
        }
    }
    static void restoreBackup(Context c, JSONObject json) throws Exception {
        validateBackup(json);
        android.content.SharedPreferences.Editor editor =
                c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear();
        java.util.Iterator<String> keys = json.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            editor.putBoolean(key, json.getBoolean(key));
        }
        if (!editor.commit()) throw new Exception("사이트 설정 저장에 실패했습니다");
    }
    private static boolean validBackupKey(String key) {
        return key != null && key.matches("(ad|scan)_[a-f0-9]{24}");
    }
    static void reset(Context c, String page) {
        String host = host(page);
        if (host.isEmpty()) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .remove(key(host, "ad")).remove(key(host, "scan")).apply();
    }
}
