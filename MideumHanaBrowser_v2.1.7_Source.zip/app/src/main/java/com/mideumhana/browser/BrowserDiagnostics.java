package com.mideumhana.browser;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Private, bounded diagnostic timeline. Every event is a fixed, category-only
 * code; never accept a URL, response body, cookie, token, title or stack trace.
 * Export happens only after the user explicitly taps the share entry.
 */
final class BrowserDiagnostics {
    private static final int MAX_LOG_BYTES = 256 * 1024;
    private static final int ARCHIVES = 3;
    private static final Object FILE_LOCK = new Object();
    private static final ExecutorService WRITER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "MHB-DiagnosticWriter");
        t.setDaemon(true);
        return t;
    });
    private static final ConcurrentHashMap<String, Long> LAST = new ConcurrentHashMap<>();
    private BrowserDiagnostics() { }

    private static String safeToken(String value) {
        if (value == null || !value.matches("[A-Za-z0-9_\\-]{1,44}")) return "REDACTED";
        return value;
    }

    static void event(Context context, String kind, String code) {
        event(context, kind, code, 0);
    }
    static void event(Context context, String kind, String code, int count) {
        if (context == null) return;
        Context app = context.getApplicationContext();
        final String event = safeToken(kind), category = safeToken(code);
        final int bounded = Math.max(0, Math.min(9999, count));
        final long when = System.currentTimeMillis();
        WRITER.execute(() -> write(app, when, event, category, bounded));
    }
    static void limited(Context context, String kind, String code, long intervalMs) {
        String key = safeToken(kind) + ":" + safeToken(code);
        long now = android.os.SystemClock.elapsedRealtime();
        Long prev = LAST.get(key);
        if (prev != null && now - prev < intervalMs && now >= prev) return;
        LAST.put(key, now);
        event(context, kind, code);
    }
    private static File logDir(Context c) { return new File(c.getFilesDir(), "browser_diagnostics"); }
    private static File logFile(File dir, int index) { return new File(dir, "timeline" + index + ".jsonl"); }
    private static void write(Context app, long at, String kind, String code, int count) {
        synchronized (FILE_LOCK) {
            try {
                JSONObject data = new JSONObject();
                data.put("time_ms", at);
                data.put("event", kind);
                data.put("category", code);
                data.put("count", count);
                byte[] line = (data.toString() + "\n").getBytes(StandardCharsets.UTF_8);
                File dir = logDir(app);
                if (!dir.exists() && !dir.mkdirs()) return;
                File current = logFile(dir, 0);
                if (current.length() + line.length > MAX_LOG_BYTES) {
                    logFile(dir, ARCHIVES - 1).delete();
                    for (int i = ARCHIVES - 2; i >= 0; i--) {
                        File source = logFile(dir, i);
                        if (source.exists()) source.renameTo(logFile(dir, i + 1));
                    }
                }
                try (FileOutputStream stream = new FileOutputStream(current, true)) {
                    stream.write(line);
                }
            } catch (Exception ignored) { /* A full filesystem must not crash the browser. */ }
        }
    }
    /** Keep a last-resort crash marker even when queued writes will not run. */
    static void crash(Context context, Throwable error) {
        String category = error == null ? "UNKNOWN" : safeToken(error.getClass().getSimpleName());
        int appLine = 0;
        if (error != null && error.getStackTrace().length > 0)
            appLine = Math.max(0, error.getStackTrace()[0].getLineNumber());
        write(context.getApplicationContext(), System.currentTimeMillis(), "APP_UNCAUGHT",
                category, Math.min(9999, appLine));
    }
    static String failureCategory(Throwable error) {
        if (error == null) return "OTHER_ERROR";
        String failureClass = error.getClass().getSimpleName();
        if ("AccessExpiredException".equals(failureClass)) return "ACCESS_EXPIRED";
        if ("HttpStatusException".equals(failureClass)) return "HTTP_STATUS";
        if ("TransientNetworkException".equals(failureClass)) return "HTTP_TEMPORARY";
        if (error instanceof java.net.SocketTimeoutException) return "TIMEOUT";
        if (error instanceof java.net.UnknownHostException) return "DNS_FAILURE";
        if (error instanceof javax.net.ssl.SSLException) return "TLS_FAILURE";
        if (error instanceof java.io.FileNotFoundException) return "NOT_FOUND";
        if (error instanceof java.io.IOException) return "NETWORK_OR_IO";
        if (error instanceof SecurityException) return "PERMISSION_DENIED";
        if (error instanceof java.util.concurrent.CancellationException) return "CANCELLED";
        return "OTHER_ERROR";
    }
    /** Export MediaStore URI; caller launches the Android Sharesheet. */
    static Uri export(Context appContext) throws Exception {
        Context app = appContext.getApplicationContext();
        Future<byte[]> task = WRITER.submit(() -> {
            synchronized (FILE_LOCK) {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (ZipOutputStream zip = new ZipOutputStream(bytes, StandardCharsets.UTF_8)) {
                    String version = "2.1.7";
                    String webview = "unknown";
                    try {
                        android.content.pm.PackageInfo pkg = WebView.getCurrentWebViewPackage();
                        if (pkg != null && pkg.versionName != null) webview = pkg.versionName;
                    } catch (Exception ignored) { }
                    JSONObject summary = new JSONObject();
                    summary.put("diagnostic_schema", "mideumhana-browser-diagnostics-v1");
                    summary.put("exported_at_ms", System.currentTimeMillis());
                    summary.put("browser_version", version);
                    summary.put("android_sdk", Build.VERSION.SDK_INT);
                    summary.put("android_release", Build.VERSION.RELEASE);
                    summary.put("webview_version", webview);
                    summary.put("privacy", "No URLs, hostnames, cookies, page text, tokens, passwords or stacks");
                    addZip(zip, "summary.json", summary.toString(2).getBytes(StandardCharsets.UTF_8));
                    File directory = logDir(app);
                    int fileCount = 0;
                    for (int i = ARCHIVES - 1; i >= 0; i--) {
                        File file = logFile(directory, i);
                        if (!file.exists() || file.length() > MAX_LOG_BYTES + 4096) continue;
                        byte[] data = readBounded(file, MAX_LOG_BYTES + 4096);
                        addZip(zip, "events/timeline" + i + ".jsonl", data);
                        fileCount++;
                    }
                    if (fileCount == 0) addZip(zip, "events/empty.txt",
                            "진단 기록이 아직 없습니다.\n".getBytes(StandardCharsets.UTF_8));
                    addZip(zip, "README.txt", (
                        "믿음하나 브라우저 자동 진단 ZIP\n" +
                        "앱 실행부터 자동 순환 기록된 최근 이벤트입니다.\n" +
                        "파일에는 페이지 주소, 로그인 정보, 영상 내용, 쿠키, 비밀번호가 없습니다.\n" +
                        "공유는 사용자가 Android 공유 화면에서 직접 선택합니다.\n").getBytes(StandardCharsets.UTF_8));
                }
                return bytes.toByteArray();
            }
        });
        byte[] zip = task.get(8, TimeUnit.SECONDS);
        String name = "믿음하나_브라우저_진단_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date()) + ".zip";
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/믿음하나/진단/");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = app.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("ZIP 생성 실패");
        boolean success = false;
        try {
            try (OutputStream stream = app.getContentResolver().openOutputStream(uri, "w")) {
                if (stream == null) throw new Exception("저장 공간 접근 실패");
                stream.write(zip);
                stream.flush();
            }
            ContentValues complete = new ContentValues();
            complete.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (app.getContentResolver().update(uri, complete, null, null) <= 0)
                throw new Exception("ZIP 완료 처리 실패");
            success = true;
            return uri;
        } finally {
            if (!success) try { app.getContentResolver().delete(uri, null, null); }
                catch (Exception ignored) { }
        }
    }
    private static byte[] readBounded(File f, int max) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int size;
            while ((size = in.read(buffer)) != -1) {
                if (out.size() + size > max) throw new Exception("로그 크기 초과");
                out.write(buffer, 0, size);
            }
            return out.toByteArray();
        }
    }
    private static void addZip(ZipOutputStream zip, String name, byte[] bytes) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(bytes);
        zip.closeEntry();
    }
}
