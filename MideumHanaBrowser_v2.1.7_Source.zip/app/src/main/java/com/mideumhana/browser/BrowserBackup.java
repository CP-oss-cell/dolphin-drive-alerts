package com.mideumhana.browser;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/** Export only browser preferences and bookmarks. No cookies, passwords, auth tokens or downloads. */
final class BrowserBackup {
    private static final String PREFS = "mideumhana_browser_ui";
    private static final String BOOKMARK_PREFS = "mideumhana_local_v2";
    private static final String FORMAT = "mideumhana-browser-backup";
    private static final int VERSION = 1;
    private static final int MAX_BYTES = 512 * 1024;
    private BrowserBackup() { }

    static JSONObject snapshot(Context c) throws Exception {
        SharedPreferences prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONObject root = new JSONObject();
        root.put("format", FORMAT);
        root.put("version", VERSION);
        root.put("created", System.currentTimeMillis());
        String home = prefs.getString("homepage", "https://www.google.com/");
        root.put("homepage", MediaDetector.validWebUrl(home) ? home : "https://www.google.com/");
        JSONObject zoom = new JSONObject();
        for (Map.Entry<String, ?> pair : prefs.getAll().entrySet()) {
            if (!validScaleKey(pair.getKey()) || !(pair.getValue() instanceof Number)) continue;
            float scale = ((Number) pair.getValue()).floatValue();
            if (scale >= 0.5f && scale <= 3f && zoom.length() < 300)
                zoom.put(pair.getKey(), (double) scale);
        }
        root.put("site_zoom", zoom);
        JSONArray tabs = new JSONArray();
        JSONArray saved = new JSONArray(prefs.getString("saved_tabs_v3", "[]"));
        for (int i = 0; i < saved.length() && tabs.length() < 8; i++) {
            String url = saved.optString(i, "");
            if (MediaDetector.validWebUrl(url)) tabs.put(url);
        }
        root.put("tabs", tabs);
        JSONArray tabScrolls = new JSONArray();
        JSONArray storedScrolls;
        try { storedScrolls = new JSONArray(prefs.getString("saved_tab_scrolls_v1", "[]")); }
        catch (Exception ignored) { storedScrolls = new JSONArray(); }
        for (int i = 0; i < tabs.length(); i++)
            tabScrolls.put(Math.max(0, Math.min(2000000, storedScrolls.optInt(i, 0))));
        root.put("tab_scroll", tabScrolls);
        root.put("site_compat", SiteCompatibility.backup(c));
        root.put("active_tab", Math.max(0, Math.min(7, prefs.getInt("saved_tab_index_v3", 0))));
        JSONArray bookmarks = new JSONArray();
        for (JSONObject item : Bookmarks.all(c)) {
            String url = item.optString("url", "");
            if (!MediaDetector.validWebUrl(url)) continue;
            JSONObject entry = new JSONObject();
            entry.put("url", url);
            entry.put("title", cleanTitle(item.optString("title", url)));
            bookmarks.put(entry);
            if (bookmarks.length() >= 200) break;
        }
        root.put("bookmarks", bookmarks);
        return root;
    }

    private static String cleanTitle(String value) {
        if (value == null) return "";
        String text = value.replace('\n', ' ').replace('\r', ' ').trim();
        return text.length() > 180 ? text.substring(0, 180) : text;
    }

    private static boolean validScaleKey(String key) {
        return key != null && key.length() < 260
                && key.matches("site_scale_(wide|compact)_[A-Za-z0-9][A-Za-z0-9.-]*");
    }

    /** Save to the public Downloads collection so an app uninstall does not delete the backup. */
    static Uri exportToDownloads(Context c) throws Exception {
        byte[] bytes = snapshot(c).toString(2).getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_BYTES) throw new Exception("백업 데이터가 제한 크기를 초과했습니다");
        String name = "믿음하나_브라우저_백업_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date()) + ".json";
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/믿음하나/백업/");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("백업 파일을 생성할 수 없습니다");
        boolean success = false;
        try {
            try (OutputStream output = c.getContentResolver().openOutputStream(uri, "w")) {
                if (output == null) throw new Exception("백업 파일에 쓸 수 없습니다");
                output.write(bytes);
                output.flush();
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
            c.getContentResolver().update(uri, ready, null, null);
            success = true;
            return uri;
        } finally {
            if (!success) try { c.getContentResolver().delete(uri, null, null); }
                catch (Exception ignored) { }
        }
    }

    static JSONObject parseBackup(Context c, Uri uri) throws Exception {
        if (uri == null || !"content".equals(uri.getScheme()))
            throw new Exception("파일 선택에 실패했습니다");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("백업 파일을 열 수 없습니다");
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) {
                if (out.size() + n > MAX_BYTES) throw new Exception("백업 파일이 너무 큽니다");
                out.write(buf, 0, n);
            }
        }
        JSONObject json = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
        validate(json);
        return json;
    }

    private static void validate(JSONObject json) throws Exception {
        if (!FORMAT.equals(json.optString("format")) || json.optInt("version") != VERSION)
            throw new Exception("지원하지 않는 백업 파일입니다");
        if (!MediaDetector.validWebUrl(json.optString("homepage")))
            throw new Exception("홈 주소가 올바르지 않습니다");
        JSONArray tabs = json.optJSONArray("tabs");
        JSONArray bookmarks = json.optJSONArray("bookmarks");
        JSONObject scales = json.optJSONObject("site_zoom");
        if (tabs == null || tabs.length() > 8 || bookmarks == null || bookmarks.length() > 200
                || scales == null || scales.length() > 300)
            throw new Exception("백업 파일 형식이나 항목 수가 잘못됐습니다");
        for (int i = 0; i < tabs.length(); i++)
            if (!MediaDetector.validWebUrl(tabs.optString(i))) throw new Exception("탭 주소 오류");
        for (int i = 0; i < bookmarks.length(); i++) {
            JSONObject item = bookmarks.optJSONObject(i);
            if (item == null || !MediaDetector.validWebUrl(item.optString("url"))
                    || item.optString("title").length() > 512)
                throw new Exception("즐겨찾기 내용 오류");
        }
        java.util.Iterator<String> keys = scales.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = scales.opt(key);
            double scale = value instanceof Number ? ((Number) value).doubleValue() : -1;
            if (!validScaleKey(key) || scale < 0.5 || scale > 3 || !Double.isFinite(scale))
                throw new Exception("화면 확대 설정 오류");
        }
        JSONArray tabScroll = json.optJSONArray("tab_scroll");
        if (tabScroll != null) {
            if (tabScroll.length() != tabs.length()) throw new Exception("탭 스크롤 항목 수 오류");
            for (int i = 0; i < tabScroll.length(); i++) {
                Object v = tabScroll.opt(i);
                if (!(v instanceof Number) || tabScroll.optInt(i, -1) < 0
                        || tabScroll.optInt(i, -1) > 2000000)
                    throw new Exception("탭 스크롤 정보 오류");
            }
        }
        JSONObject siteCompat = json.optJSONObject("site_compat");
        if (siteCompat != null) SiteCompatibility.validateBackup(siteCompat);
        int selected = json.optInt("active_tab", 0);
        if (selected < 0 || selected > 7) throw new Exception("선택된 탭 정보 오류");
    }

    /** Validate first, then commit only approved keys; never overwrite download history. */
    static void restore(Context c, JSONObject backup) throws Exception {
        validate(backup);
        SharedPreferences prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();
        for (String key : prefs.getAll().keySet()) if (validScaleKey(key)) edit.remove(key);
        JSONObject scales = backup.getJSONObject("site_zoom");
        java.util.Iterator<String> keys = scales.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            edit.putFloat(key, (float) scales.getDouble(key));
        }
        edit.putString("homepage", backup.getString("homepage"));
        JSONArray tabs = backup.getJSONArray("tabs");
        edit.putString("saved_tabs_v3", tabs.toString());
        JSONArray positions = backup.optJSONArray("tab_scroll");
        edit.putString("saved_tab_scrolls_v1", positions == null ? "[]" : positions.toString());
        edit.putInt("saved_tab_index_v3", Math.min(Math.max(0, backup.optInt("active_tab")),
                Math.max(0, tabs.length() - 1)));
        JSONArray bookmarks = backup.getJSONArray("bookmarks");
        // Local bookmark storage is distinct; validate both payloads before any writes.
        if (!c.getSharedPreferences(BOOKMARK_PREFS, Context.MODE_PRIVATE).edit()
                .putString("bookmarks", bookmarks.toString()).commit())
            throw new Exception("즐겨찾기 저장에 실패했습니다");
        if (!edit.commit()) throw new Exception("설정 저장에 실패했습니다");
        JSONObject site = backup.optJSONObject("site_compat");
        if (site != null) SiteCompatibility.restoreBackup(c, site);
    }
}
