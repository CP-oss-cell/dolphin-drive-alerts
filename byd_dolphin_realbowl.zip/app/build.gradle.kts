plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.byd.dolphin.realbowl"
    compileSdk = 33
    defaultConfig {
        applicationId = "com.byd.dolphin.realbowl"
        minSdk = 29
        targetSdk = 33
        versionCode = 2
        versionName = "2.0.0-gles3-avm"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {}
