/*
 * ============================================================================
 * BYD Dolphin Pure Live 4-ch Camera 3D Bowl Real-View (Method 1 — Zero Fake World)
 * ============================================================================
 * Target Hardware : BYD Dolphin DiLink 3.0 (Qualcomm QCM6125 / Adreno 610 / ~3.5GB RAM)
 * Access Method   : No-Root ADB UID 2000 (app_process + bmmcamera.jar + BYDAuto HAL)
 * Mode            : 100% Read-Only Visual Real-View (NO autonomous driving control)
 * ============================================================================
 */
package com.byd.dolphin.realbowl

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URL
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null
    @Volatile private var bridgeOnline = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveMode()

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#05070b"))
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                cacheMode = WebSettings.LOAD_NO_CACHE
                useWideViewPort = true
                loadWithOverviewMode = true
            }
            addJavascriptInterface(DolphinJsBridge(), "DolphinJsBridge")
        }
        setContentView(webView)
        webView.loadDataWithBaseURL("file:///android_asset/", REAL_BOWL_HTML, "text/html", "UTF-8", null)
        startTelemetryPoller()
    }

    private fun startTelemetryPoller() {
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleAtFixedRate({
            try {
                val conn = URL("http://127.0.0.1:8765/telemetry").openConnection() as HttpURLConnection
                conn.connectTimeout = 100
                conn.readTimeout = 100
                if (conn.responseCode == 200) {
                    val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    bridgeOnline = true
                    mainHandler.post {
                        val safe = body.replace("\\", "\\\\").replace("'", "\\'")
                        webView.evaluateJavascript("window.onDolphinTelemetry && window.onDolphinTelemetry('$safe');", null)
                    }
                }
                conn.disconnect()
            } catch (_: Throwable) {
                bridgeOnline = false
            }
        }, 300, 50, TimeUnit.MILLISECONDS)
    }

    inner class DolphinJsBridge {
        @JavascriptInterface fun isBridgeOnline(): Boolean = bridgeOnline
        @JavascriptInterface fun getDeviceStats(): String {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return "{\"model\":\"${Build.MODEL}\",\"sdk\":${Build.VERSION.SDK_INT},\"availMb\":${mi.availMem / 1048576},\"totalMb\":${mi.totalMem / 1048576}}"
        }
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onDestroy() {
        poller?.shutdownNow()
        webView.destroy()
        super.onDestroy()
    }
}

class BydPermissionContext(base: Context) : ContextWrapper(base) {
    override fun checkCallingOrSelfPermission(permission: String): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkCallingOrSelfPermission(permission)
    override fun checkPermission(permission: String, pid: Int, uid: Int): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkPermission(permission, pid, uid)
    override fun enforceCallingOrSelfPermission(permission: String, message: String?) {
        if (!permission.contains("BYDAUTO")) super.enforceCallingOrSelfPermission(permission, message)
    }
}

object NativeAutoserviceClient {
    private var binder: IBinder? = null
    private var descriptor: String? = null
    fun init() {
        try {
            val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java).invoke(null, "autoservice") as? IBinder
            if (b != null) { binder = b; descriptor = b.interfaceDescriptor }
        } catch (_: Throwable) {}
    }
    fun readInt(deviceType: Int, featureId: Int): Int? {
        val b = binder ?: return null
        val d = descriptor ?: return null
        val data = Parcel.obtain(); val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(d); data.writeInt(deviceType); data.writeInt(featureId)
            if (b.transact(5, data, reply, 0)) {
                val st = reply.readInt(); val v = reply.readInt()
                if (st == 0 && v != -10011 && v != 65535) v else null
            } else null
        } catch (_: Throwable) { null } finally { data.recycle(); reply.recycle() }
    }
}

object BydRealBowlBridge {
    private const val PORT = 8765
    private const val CAM_W = 1280
    private const val CAM_H = 960

    @Volatile private var speedKmh = 0.0
    @Volatile private var soc = 0.0
    @Volatile private var rangeKm = 0
    @Volatile private var gear = 4
    @Volatile private var turnSignal = 0
    @Volatile private var bsdLeft = false
    @Volatile private var bsdRight = false
    @Volatile private var ultrasonicCm = intArrayOf(180, 180, 180, 180, 180, 180)
    @Volatile private var halSummary = "booting"
    @Volatile private var bmmStatus = "probing"
    @Volatile private var bmmMethods = ""
    @Volatile private var frameCounts = intArrayOf(0, 0, 0, 0)

    private val latestJpegs = arrayOfNulls<ByteArray>(4)
    private var speedDev: Any? = null; private var statDev: Any? = null
    private var gearDev: Any? = null; private var radarDev: Any? = null
    private var lightDev: Any? = null; private var adasDev: Any? = null
    private var fidBsdL: Int? = null; private var fidBsdR: Int? = null
    private var fidTurnL: Int? = null; private var fidTurnR: Int? = null

    @JvmStatic
    fun main(args: Array<String>) {
        println("[BydRealBowlBridge] Starting UID 2000 Pure 4-ch Camera + HAL Bridge...")
        val ctx = obtainSystemContext()
        NativeAutoserviceClient.init()
        if (ctx != null) {
            val pctx = BydPermissionContext(ctx)
            speedDev = getInst("android.hardware.bydauto.speed.BYDAutoSpeedDevice", pctx)
            statDev  = getInst("android.hardware.bydauto.statistic.BYDAutoStatisticDevice", pctx)
            gearDev  = getInst("android.hardware.bydauto.gearbox.BYDAutoGearboxDevice", pctx)
            radarDev = getInst("android.hardware.bydauto.radar.BYDAutoRadarDevice", pctx)
            lightDev = getInst("android.hardware.bydauto.light.BYDAutoLightDevice", pctx)
            adasDev  = getInst("android.hardware.bydauto.adas.BYDAutoADASDevice", pctx)
            val ok = listOf(speedDev, statDev, gearDev, radarDev, lightDev, adasDev).count { it != null }
            halSummary = "HAL $ok/6"
            fidBsdL  = findFid("Adas",  listOf("ADAS_BSD_LEFT", "BSD_LEFT_WARN", "BSD_ALARM_LEFT"))
            fidBsdR  = findFid("Adas",  listOf("ADAS_BSD_RIGHT", "BSD_RIGHT_WARN", "BSD_ALARM_RIGHT"))
            fidTurnL = findFid("Light", listOf("LIGHT_LEFT_TURN", "LEFT_TURN_SIGNAL", "TURN_LEFT"))
            fidTurnR = findFid("Light", listOf("LIGHT_RIGHT_TURN", "RIGHT_TURN_SIGNAL", "TURN_RIGHT"))
        }
        initBmmCamera()
        startHalPoller()
        serveHttp()
    }

    @SuppressLint("PrivateApi")
    private fun obtainSystemContext(): Context? = try {
        if (Looper.getMainLooper() == null) Looper.prepareMainLooper()
        val at = Class.forName("android.app.ActivityThread")
        at.getMethod("getSystemContext").invoke(at.getMethod("systemMain").invoke(null)) as? Context
    } catch (_: Throwable) { null }

    private fun getInst(cn: String, ctx: Context): Any? = try {
        Class.forName(cn).getMethod("getInstance", Context::class.java).invoke(null, ctx)
    } catch (_: Throwable) { null }

    private fun findFid(nested: String, keys: List<String>): Int? = try {
        Class.forName("android.hardware.bydauto.BYDAutoFeatureIds$$nested").fields.firstOrNull { f ->
            val n = f.name.uppercase(); keys.any { n.contains(it) } && !n.endsWith("_SET")
        }?.getInt(null)
    } catch (_: Throwable) { null }

    private fun initBmmCamera() {
        val candidates = listOf("com.byd.bmmcamera.JNIBMMCamera", "com.byd.camera.JNIBMMCamera", "android.hardware.JNIBMMCamera")
        var cls: Class<*>? = null
        for (name in candidates) {
            try { cls = Class.forName(name); break } catch (_: Throwable) {}
        }
        if (cls == null) {
            bmmStatus = "bmmcamera.jar class not found"
            return
        }
        bmmMethods = cls.declaredMethods.joinToString(" | ") { m ->
            "${m.name}(${m.parameterTypes.joinToString(",") { it.simpleName }}):${m.returnType.simpleName}"
        }
        bmmStatus = "loaded ${cls.simpleName} (${cls.declaredMethods.size} methods)"
        println("[BmmCamera] $bmmStatus -> $bmmMethods")

        // Try opening & reading 4 channels dynamically
        val readM = cls.declaredMethods.firstOrNull { m ->
            val n = m.name.lowercase()
            (n.contains("frame") || n.contains("data") || n.contains("read") || n.contains("get")) &&
                m.parameterTypes.size >= 2 &&
                m.parameterTypes[0] == Int::class.javaPrimitiveType &&
                (m.parameterTypes[1] == ByteArray::class.java || m.parameterTypes[1] == ByteBuffer::class.java)
        } ?: return

        readM.isAccessible = true
        val inst = try { cls.getDeclaredConstructor().apply { isAccessible = true }.newInstance() } catch (_: Throwable) { null }
        val nv21 = ByteArray(CAM_W * CAM_H * 3 / 2)
        val dbuf = ByteBuffer.allocateDirect(nv21.size)

        Thread({
            while (true) {
                for (ch in 0..3) {
                    try {
                        if (readM.parameterTypes[1] == ByteArray::class.java) {
                            readM.invoke(inst, ch, nv21)
                        } else {
                            dbuf.clear(); readM.invoke(inst, ch, dbuf); dbuf.rewind(); dbuf.get(nv21)
                        }
                        val yuv = YuvImage(nv21, ImageFormat.NV21, CAM_W, CAM_H, null)
                        val out = ByteArrayOutputStream()
                        yuv.compressToJpeg(Rect(0, 0, CAM_W, CAM_H), 58, out)
                        latestJpegs[ch] = out.toByteArray()
                        frameCounts[ch]++
                    } catch (_: Throwable) {}
                }
                try { Thread.sleep(66) } catch (_: InterruptedException) { break } // ~15 FPS
            }
        }, "bmm-capture").apply { isDaemon = true; start() }
    }

    private fun findMethod(obj: Any, name: String, vararg p: Class<*>): Method? {
        var c: Class<*>? = obj.javaClass
        while (c != null) {
            try { return c.getDeclaredMethod(name, *p).apply { isAccessible = true } }
            catch (_: NoSuchMethodException) { c = c.superclass }
        }
        return null
    }

    private fun readProtected(obj: Any?, devType: Int, fid: Int?): Int? {
        if (fid == null) return null
        if (obj != null) {
            try {
                val v = (findMethod(obj, "get", Int::class.javaPrimitiveType!!, Int::class.javaPrimitiveType!!)?.invoke(obj, devType, fid) as? Number)?.toInt()
                if (v != null && v != -10011 && v != 65535) return v
            } catch (_: Throwable) {}
        }
        return NativeAutoserviceClient.readInt(devType, fid)
    }

    private fun startHalPoller() {
        Thread({
            while (true) {
                try {
                    speedDev?.let { (findMethod(it, "getCurrentSpeed")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..260.0) speedKmh = v } }
                    statDev?.let {
                        (findMethod(it, "getElecPercentageValue")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..100.0) soc = v }
                        (findMethod(it, "getElecDrivingRangeValue")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 0..1000) rangeKm = v }
                    }
                    gearDev?.let { (findMethod(it, "getGearboxAutoModeType")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 1..4) gear = v } }
                    radarDev?.let {
                        val arr = findMethod(it, "getAllRadarDistance")?.invoke(it) as? IntArray
                        if (arr != null && arr.size >= 6) for (i in 0 until 6) ultrasonicCm[i] = arr[i]
                    }
                    val tl = readProtected(lightDev, 1004, fidTurnL) ?: 0
                    val tr = readProtected(lightDev, 1004, fidTurnR) ?: 0
                    turnSignal = when { tl > 0 && tr == 0 -> -1; tr > 0 && tl == 0 -> 1; else -> 0 }
                    bsdLeft = (readProtected(adasDev, 1001, fidBsdL) ?: 0) > 0
                    bsdRight = (readProtected(adasDev, 1001, fidBsdR) ?: 0) > 0
                    Thread.sleep(50)
                } catch (_: InterruptedException) { break } catch (_: Throwable) { Thread.sleep(200) }
            }
        }, "hal-poller").apply { isDaemon = true; start() }
    }

    private fun serveHttp() {
        val server = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
        while (true) {
            val client = server.accept()
            try {
                val req = BufferedReader(InputStreamReader(client.getInputStream())).readLine() ?: ""
                client.getOutputStream().use { out ->
                    if (req.startsWith("GET /camera/")) {
                        val ch = req.removePrefix("GET /camera/").take(1).toIntOrNull()?.coerceIn(0, 3) ?: 0
                        val jpg = latestJpegs[ch]
                        if (jpg != null) {
                            out.write(("HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: ${jpg.size}\r\n\r\n").toByteArray())
                            out.write(jpg)
                        } else {
                            val b = "{\"status\":\"no_frame\",\"ch\":$ch}".toByteArray()
                            out.write(("HTTP/1.1 404 Not Found\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: ${b.size}\r\n\r\n").toByteArray())
                            out.write(b)
                        }
                    } else if (req.startsWith("GET /debug")) {
                        val b = "{\"hal\":\"$halSummary\",\"bmmStatus\":\"$bmmStatus\",\"frames\":[${frameCounts.joinToString(",")}],\"bmmMethods\":\"${bmmMethods.replace("\"", "'")}\"}".toByteArray(StandardCharsets.UTF_8)
                        out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: ${b.size}\r\n\r\n").toByteArray())
                        out.write(b)
                    } else {
                        val b = "{\"hal\":\"$halSummary\",\"bmmStatus\":\"$bmmStatus\",\"speedKmh\":$speedKmh,\"soc\":$soc,\"rangeKm\":$rangeKm,\"gear\":$gear,\"turnSignal\":$turnSignal,\"bsdLeft\":$bsdLeft,\"bsdRight\":$bsdRight,\"ultrasonicCm\":[${ultrasonicCm.joinToString(",")}],\"frames\":[${frameCounts.joinToString(",")}]}".toByteArray(StandardCharsets.UTF_8)
                        out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: ${b.size}\r\n\r\n").toByteArray())
                        out.write(b)
                    }
                    out.flush()
                }
            } catch (_: Throwable) {} finally { client.close() }
        }
    }
}

// ============================================================================
// PURE LIVE 4-CH CAMERA 3D BOWL + FSD 15 HUD (ZERO FAKE WORLD)
// ============================================================================
private const val REAL_BOWL_HTML: String = """
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>BYD 돌핀 실시간 4ch 3D 보울 리얼뷰</title>
  <script src="file:///android_asset/tailwind.min.js"></script>
  <script src="file:///android_asset/three.min.js"></script>
  <style>
    * { box-sizing: border-box; user-select: none; -webkit-tap-highlight-color: transparent; }
    html, body { margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:#05070b; color:#f8fafc; font-family:-apple-system,BlinkMacSystemFont,sans-serif; }
    .glass { background:rgba(10,14,22,0.75); backdrop-filter:blur(16px); border:1px solid rgba(255,255,255,0.12); }
    .btn-on { background:rgba(56,189,248,0.24); border-color:rgba(56,189,248,0.7); color:#e0f2fe; }
    canvas { display:block; touch-action:none; }
  </style>
</head>
<body class="flex flex-col h-screen w-screen overflow-hidden">
  <div id="wrap" class="relative flex-1 w-full overflow-hidden cursor-grab">
    <canvas id="gl"></canvas>

    <!-- Top-Left FSD 15 Style HUD -->
    <div class="absolute top-3 left-3 z-20 flex flex-col gap-2 pointer-events-none">
      <div class="glass rounded-2xl px-4 py-2.5 flex items-center gap-3.5 pointer-events-auto">
        <div class="flex flex-col items-center text-[11px] font-semibold text-slate-500 leading-tight">
          <span id="gP">P</span><span id="gR">R</span><span id="gN">N</span><span id="gD" class="text-white font-bold">D</span>
        </div>
        <div class="h-9 w-px bg-white/10"></div>
        <div>
          <div class="flex items-baseline gap-1">
            <span id="spd" class="text-4xl font-bold tabular-nums leading-none">0</span>
            <span class="text-[10px] text-slate-400">km/h</span>
          </div>
          <div id="conn-badge" class="text-[10px] font-semibold text-amber-300 mt-1">ADB 브릿지 대기 중 (127.0.0.1:8765)</div>
        </div>
      </div>
      <div id="bsd-pill" class="hidden glass rounded-full px-3 py-1 bg-red-500/25 border-red-400/60 text-red-200 text-xs font-bold w-fit">BSD 사각지대 차량 접근</div>
    </div>

    <!-- Top-Right Status & Camera Presets -->
    <div class="absolute top-3 right-3 z-20 flex flex-col items-end gap-2">
      <div class="glass rounded-full px-3 py-1.5 text-[11px] flex items-center gap-2.5">
        <span id="soc-txt" class="text-emerald-400 font-bold">--%</span>
        <span class="text-white/20">|</span>
        <span id="rng-txt" class="text-slate-300">-- km</span>
        <span class="text-white/20">|</span>
        <span id="fps-txt" class="text-sky-300 font-mono">60 FPS</span>
      </div>
      <div class="glass rounded-xl p-1 flex gap-1 text-[11px]">
        <button data-c="drone" class="cbtn btn-on px-2 py-1 rounded-lg border border-transparent">드론</button>
        <button data-c="top" class="cbtn px-2 py-1 rounded-lg border border-transparent text-slate-300">탑뷰</button>
        <button data-c="rear" class="cbtn px-2 py-1 rounded-lg border border-transparent text-slate-300">후측</button>
      </div>
    </div>

    <!-- Calibration & Diagnostics Drawer -->
    <div id="diag-panel" class="hidden absolute bottom-16 right-3 z-30 glass rounded-2xl p-3.5 w-[310px] text-xs space-y-2.5">
      <div class="flex items-center justify-between font-bold">
        <span>실차 4ch 카메라 보정 &amp; 진단</span>
        <button id="btn-close-diag" type="button" class="text-slate-400">✕</button>
      </div>
      <div class="space-y-1.5 text-[11px]">
        <div class="flex justify-between"><span>3D 보울 곡률</span><input id="sl-curve" type="range" min="10" max="45" value="26" class="w-32" /></div>
        <div class="flex justify-between"><span>투명 차체 (하부 투시)</span><input id="chk-trans" type="checkbox" class="accent-sky-400" /></div>
      </div>
      <div id="diag-log" class="rounded-xl bg-black/60 p-2 font-mono text-[10px] text-sky-300 max-h-32 overflow-y-auto break-all">
        브릿지 연결 후 /debug 응답이 여기에 표시됩니다.
      </div>
      <button id="btn-fetch-diag" type="button" class="w-full py-1.5 rounded-xl bg-sky-500/20 border border-sky-400/40 text-sky-200 font-semibold">실차 bmmcamera 메서드 조회</button>
    </div>
  </div>

  <!-- Minimal Bottom Dock -->
  <footer class="glass z-30 w-full px-3 py-2 flex items-center justify-between text-xs">
    <div class="flex items-center gap-1.5">
      <span class="px-2 py-1 rounded-lg bg-sky-500/20 border border-sky-400/40 text-sky-200 font-semibold">실시간 4ch 3D 보울</span>
      <span id="cam-status" class="text-[11px] text-slate-400">CH0·1·2·3 대기</span>
    </div>
    <div class="flex items-center gap-1.5">
      <button id="btn-reset-cam" type="button" class="px-2.5 py-1.5 rounded-xl bg-white/5 border border-white/10">시점 초기화</button>
      <button id="btn-diag" type="button" class="px-2.5 py-1.5 rounded-xl bg-sky-500/15 border border-sky-400/40 text-sky-200 font-semibold">보정·진단</button>
    </div>
  </footer>

  <script>
    (function () {
      'use strict';
      const canvas = document.getElementById('gl'), wrap = document.getElementById('wrap');
      const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(1.0); // QCM6125 Adreno 610 optimal DPR
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x05070b);
      const camera = new THREE.PerspectiveCamera(50, 1, 0.2, 120);
      scene.add(new THREE.HemisphereLight(0xffffff, 0x222836, 1.1));
      const dl = new THREE.DirectionalLight(0xffffff, 0.8); dl.position.set(8, 18, 8); scene.add(dl);

      // 3D Hemispherical Surround Bowl Mesh (receives live 4-ch bmmcamera.jar frames)
      const bowlCanvas = document.createElement('canvas');
      bowlCanvas.width = 1024; bowlCanvas.height = 1024;
      const bctx = bowlCanvas.getContext('2d');
      const bowlTex = new THREE.CanvasTexture(bowlCanvas);
      bowlTex.anisotropy = 4;

      const bowlGeo = new THREE.PlaneGeometry(36, 36, 40, 40);
      bowlGeo.rotateX(-Math.PI / 2);
      function rebuildBowlCurve(curveFactor) {
        const p = bowlGeo.attributes.position;
        for (let i = 0; i < p.count; i++) {
          const r = Math.hypot(p.getX(i), p.getZ(i));
          p.setY(i, r > 7.5 ? Math.pow((r - 7.5) * (curveFactor / 100), 2.0) : 0.0);
        }
        p.needsUpdate = true;
        bowlGeo.computeVertexNormals();
      }
      rebuildBowlCurve(26);
      const bowlMesh = new THREE.Mesh(bowlGeo, new THREE.MeshBasicMaterial({ map: bowlTex, side: THREE.DoubleSide }));
      scene.add(bowlMesh);

      // Sculpted BYD Dolphin Center Car (with Transparent Chassis toggle)
      const ego = new THREE.Group();
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.22, metalness: 0.65, transparent: true, opacity: 1.0 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x0b1220, roughness: 0.1, metalness: 0.9, transparent: true, opacity: 0.95 });
      const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.62, 4.28), bodyMat); chassis.position.y = 0.56;
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.52, 0.52, 2.35), glassMat); cabin.position.set(0, 1.12, 0.2);
      ego.add(chassis, cabin);
      scene.add(ego);

      // FSD 15 Live Trajectory + BSD + Ultrasonic PDC Overlays
      const trajMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.45, side: THREE.DoubleSide, depthWrite: false });
      const trajMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.45, 14), trajMat);
      trajMesh.rotation.x = -Math.PI / 2; trajMesh.position.set(0, 0.05, -9.2);
      scene.add(trajMesh);

      const bsdLMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false });
      const bsdRMat = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false });
      const bsdL = new THREE.Mesh(new THREE.RingGeometry(1.3, 3.8, 18, 1, Math.PI * 0.62, Math.PI * 0.36), bsdLMat);
      bsdL.rotation.x = -Math.PI / 2; bsdL.position.set(-0.7, 0.06, 1.4);
      const bsdR = new THREE.Mesh(new THREE.RingGeometry(1.3, 3.8, 18, 1, Math.PI * 0.02, Math.PI * 0.36), bsdRMat);
      bsdR.rotation.x = -Math.PI / 2; bsdR.position.set(0.7, 0.06, 1.4);
      scene.add(bsdL, bsdR);

      // Live 4-Channel JPEG Streamers from 127.0.0.1:8765/camera/{0..3}
      const imgs = [new Image(), new Image(), new Image(), new Image()];
      const loaded = [false, false, false, false];
      imgs.forEach(function (im, i) { im.crossOrigin = 'anonymous'; im.onload = function () { loaded[i] = true; }; });

      let telemetry = { speedKmh: 0, soc: 0, rangeKm: 0, gear: 4, turnSignal: 0, bsdLeft: false, bsdRight: false, hal: '', bmmStatus: '', frames: [0,0,0,0] };
      window.onDolphinTelemetry = function (raw) {
        try {
          telemetry = JSON.parse(raw);
          document.getElementById('spd').textContent = String(Math.round(telemetry.speedKmh || 0));
          document.getElementById('soc-txt').textContent = (telemetry.soc > 0 ? Math.round(telemetry.soc) : '--') + '%';
          document.getElementById('rng-txt').textContent = (telemetry.rangeKm > 0 ? telemetry.rangeKm : '--') + ' km';
          document.getElementById('conn-badge').textContent = 'LIVE ADB · ' + (telemetry.hal || 'OK');
          document.getElementById('conn-badge').className = 'text-[10px] font-semibold text-emerald-400 mt-1';
          document.getElementById('cam-status').textContent = '프레임: ' + (telemetry.frames || [0,0,0,0]).join('/');
          const gMap = {1:'P', 2:'R', 3:'N', 4:'D'};
          const ag = gMap[telemetry.gear] || 'D';
          ['P','R','N','D'].forEach(function (g) {
            document.getElementById('g' + g).className = g === ag ? 'text-white font-bold' : 'text-slate-500';
          });
          document.getElementById('bsd-pill').classList.toggle('hidden', !(telemetry.bsdLeft || telemetry.bsdRight));
        } catch (e) {}
      };

      // Orbit Camera
      const cam = { az: 0, tAz: 0, el: 0.48, tEl: 0.48, d: 13.5, tD: 13.5, drag: false, x: 0, y: 0 };
      canvas.addEventListener('pointerdown', function (e) { cam.drag = true; cam.x = e.clientX; cam.y = e.clientY; canvas.setPointerCapture(e.pointerId); });
      canvas.addEventListener('pointermove', function (e) {
        if (!cam.drag) return;
        cam.tAz -= (e.clientX - cam.x) * 0.007;
        cam.tEl = Math.max(0.18, Math.min(1.38, cam.tEl + (e.clientY - cam.y) * 0.006));
        cam.x = e.clientX; cam.y = e.clientY;
      });
      canvas.addEventListener('pointerup', function () { cam.drag = false; });

      document.querySelectorAll('.cbtn').forEach(function (b) {
        b.addEventListener('click', function () {
          document.querySelectorAll('.cbtn').forEach(function (x) { x.classList.remove('btn-on'); x.classList.add('text-slate-300'); });
          b.classList.add('btn-on'); b.classList.remove('text-slate-300');
          const c = b.getAttribute('data-c');
          if (c === 'drone') { cam.tAz = 0; cam.tEl = 0.48; cam.tD = 13.5; }
          else if (c === 'top') { cam.tAz = 0; cam.tEl = 1.32; cam.tD = 20.0; }
          else { cam.tAz = 0.72; cam.tEl = 0.36; cam.tD = 12.5; }
        });
      });
      document.getElementById('btn-reset-cam').addEventListener('click', function () { cam.tAz = 0; cam.tEl = 0.48; cam.tD = 13.5; });
      document.getElementById('btn-diag').addEventListener('click', function () { document.getElementById('diag-panel').classList.toggle('hidden'); });
      document.getElementById('btn-close-diag').addEventListener('click', function () { document.getElementById('diag-panel').classList.add('hidden'); });
      document.getElementById('sl-curve').addEventListener('input', function (e) { rebuildBowlCurve(Number(e.target.value)); });
      document.getElementById('chk-trans').addEventListener('change', function (e) { bodyMat.opacity = e.target.checked ? 0.32 : 1.0; glassMat.opacity = e.target.checked ? 0.35 : 0.95; });
      document.getElementById('btn-fetch-diag').addEventListener('click', function () {
        fetch('http://127.0.0.1:8765/debug').then(function (r) { return r.text(); }).then(function (t) {
          document.getElementById('diag-log').textContent = t;
        }).catch(function () {
          document.getElementById('diag-log').textContent = '127.0.0.1:8765 브릿지 미실행 상태입니다. start_bridge.sh 실행 후 다시 눌러주세요.';
        });
      });

      function resize() {
        const w = wrap.clientWidth || window.innerWidth, h = wrap.clientHeight || window.innerHeight;
        renderer.setSize(w, h, false); camera.aspect = w / Math.max(1, h); camera.updateProjectionMatrix();
      }
      window.addEventListener('resize', resize);

      let lastFetch = 0, lastT = performance.now(), frames = 0, acc = 0;
      function loop(now) {
        requestAnimationFrame(loop);
        const dt = Math.min(0.05, (now - lastT) / 1000); lastT = now;

        // Fetch live 4-channel JPEGs at ~15 FPS when ADB bridge is online
        if (now - lastFetch > 66 && window.DolphinJsBridge && window.DolphinJsBridge.isBridgeOnline && window.DolphinJsBridge.isBridgeOnline()) {
          lastFetch = now;
          for (let i = 0; i < 4; i++) imgs[i].src = 'http://127.0.0.1:8765/camera/' + i + '?t=' + Math.floor(now);
        }

        if (loaded[0] || loaded[1] || loaded[2] || loaded[3]) {
          if (loaded[0]) bctx.drawImage(imgs[0], 0, 0, 1024, 512);      // Front
          if (loaded[1]) bctx.drawImage(imgs[1], 0, 512, 1024, 512);    // Rear
          if (loaded[2]) bctx.drawImage(imgs[2], 0, 256, 512, 512);     // Left
          if (loaded[3]) bctx.drawImage(imgs[3], 512, 256, 512, 512);   // Right
        } else {
          bctx.fillStyle = '#090d16'; bctx.fillRect(0, 0, 1024, 1024);
          bctx.strokeStyle = 'rgba(56,189,248,0.18)'; bctx.lineWidth = 2;
          for (let r = 120; r <= 480; r += 120) { bctx.beginPath(); bctx.arc(512, 512, r, 0, Math.PI * 2); bctx.stroke(); }
          bctx.fillStyle = '#38bdf8'; bctx.font = 'bold 24px sans-serif'; bctx.textAlign = 'center';
          bctx.fillText('BYD 돌핀 4ch 실사 카메라 대기 중 (bmmcamera.jar)', 512, 310);
          bctx.fillStyle = '#94a3b8'; bctx.font = '18px sans-serif';
          bctx.fillText('ADB 브릿지 실행 시 전·후·좌·우 1280×960 실사 영상이 3D 보울에 실시간 투영됩니다', 512, 355);
        }
        bowlTex.needsUpdate = true;

        const pulse = 0.35 + Math.abs(Math.sin(now * 0.008)) * 0.4;
        bsdLMat.opacity = telemetry.bsdLeft ? pulse : 0.0;
        bsdRMat.opacity = telemetry.bsdRight ? pulse : 0.0;

        cam.az += (cam.tAz - cam.az) * Math.min(1, dt * 6);
        cam.el += (cam.tEl - cam.el) * Math.min(1, dt * 6);
        cam.d  += (cam.tD  - cam.d)  * Math.min(1, dt * 6);
        const hd = cam.d * Math.cos(cam.el);
        camera.position.set(Math.sin(cam.az) * hd, Math.max(1.8, cam.d * Math.sin(cam.el)), Math.cos(cam.az) * hd);
        camera.lookAt(0, 0.8, -5.0);
        renderer.render(scene, camera);

        frames++; acc += dt;
        if (acc >= 0.4) {
          document.getElementById('fps-txt').textContent = Math.round(frames / acc) + ' FPS';
          frames = 0; acc = 0;
        }
      }
      window.addEventListener('load', function () { resize(); requestAnimationFrame(loop); });
    })();
  </script>
</body>
</html>
"""
