/*
 * ============================================================================
 * BYD Dolphin × FSD 15 Pure Real-View (Native OpenGL ES 3.0 + AVMCamera + LUT)
 * ============================================================================
 * Target Hardware : BYD Dolphin DiLink 3.0 (Qualcomm QCM6125 / Adreno 610 / ~3.5GB RAM)
 * Architecture    :
 *   1) Zero WebView Overhead: Native GLSurfaceView (OpenGL ES 3.0) + lightweight HUD
 *   2) Camera Backend       : android.hardware.AVMCamera (2560x1920 4-split quad) via SurfaceTexture
 *   3) GPU Shader Pipeline  : GL_OES_EGL_image_external_essl3 + Precomputed Fisheye LUT +
 *                             1-pass Brightness/Contrast/Saturation/Gamma + 3D Hemispherical Bowl
 *   4) Vehicle Telemetry    : ADB UID 2000 HAL Poller (Speed, Gear, SOC, BSD, Turn Signals)
 * ============================================================================
 */
package com.byd.dolphin.realbowl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import dalvik.system.PathClassLoader
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// ============================================================================
// 1. NATIVE ACTIVITY + FSD 15 GLASSMORPHIC HUD OVERLAY
// ============================================================================
class MainActivity : Activity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: RealBowlGlRenderer
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    private lateinit var tvSpeed: TextView
    private lateinit var tvConn: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvBsd: TextView
    private lateinit var tvDiag: TextView
    private lateinit var diagPanel: LinearLayout
    private val gearViews = mutableMapOf<Int, TextView>()

    private var dragX = 0f
    private var dragY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyImmersiveMode()

        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 101)
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05070b")) }

        renderer = RealBowlGlRenderer(this) { statusText ->
            mainHandler.post { tvConn.text = statusText }
        }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dragX = ev.x; dragY = ev.y }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.x - dragX
                        val dy = ev.y - dragY
                        dragX = ev.x; dragY = ev.y
                        renderer.orbitBy(-dx * 0.0065f, dy * 0.0055f)
                    }
                }
                true
            }
        }
        root.addView(glView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        buildFsdHudOverlay(root)
        setContentView(root)
        startTelemetryPoller()
    }

    private fun glassBg(radiusDp: Float = 16f, alpha: Int = 185, borderColor: Int = 0x26FFFFFF): GradientDrawable {
        val d = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(Color.argb(alpha, 10, 14, 22))
            cornerRadius = radiusDp * d
            setStroke((1 * d).toInt().coerceAtLeast(1), borderColor)
        }
    }

    private fun buildFsdHudOverlay(root: FrameLayout) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        // Top-Left Cluster HUD
        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cluster = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glassBg(16f)
            setPadding(dp(14), dp(10), dp(16), dp(10))
        }

        val gearCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        listOf(1 to "P", 2 to "R", 3 to "N", 4 to "D").forEach { (id, lbl) ->
            val tv = TextView(this).apply {
                text = lbl
                textSize = 11f
                setTypeface(null, if (id == 4) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (id == 4) Color.WHITE else Color.parseColor("#64748b"))
            }
            gearViews[id] = tv
            gearCol.addView(tv)
        }
        cluster.addView(gearCol)

        val sep = View(this).apply { setBackgroundColor(0x22FFFFFF) }
        cluster.addView(sep, LinearLayout.LayoutParams(dp(1), dp(38)).apply { marginStart = dp(12); marginEnd = dp(12) })

        val spdCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val spdRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        tvSpeed = TextView(this).apply { text = "0"; textSize = 32f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) }
        val tvUnit = TextView(this).apply { text = " km/h"; textSize = 11f; setTextColor(Color.parseColor("#94a3b8")) }
        spdRow.addView(tvSpeed); spdRow.addView(tvUnit)
        tvConn = TextView(this).apply { text = "AVMCamera 초기화 중..."; textSize = 10f; setTextColor(Color.parseColor("#38bdf8")) }
        spdCol.addView(spdRow); spdCol.addView(tvConn)
        cluster.addView(spdCol)
        leftCol.addView(cluster)

        tvBsd = TextView(this).apply {
            text = "BSD 후측방 사각지대 차량 감지"
            textSize = 11f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#fecaca"))
            background = glassBg(20f, 210, 0xAAEF4444.toInt())
            setPadding(dp(12), dp(5), dp(12), dp(5))
            visibility = View.GONE
        }
        leftCol.addView(tvBsd, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        root.addView(leftCol, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START
        ).apply { setMargins(dp(14), dp(14), 0, 0) })

        // Top-Right Status & Camera Presets
        val rightCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        val statusPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glassBg(20f)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        tvSoc = TextView(this).apply { text = "--%  |  -- km"; textSize = 11f; setTextColor(Color.parseColor("#34d399")) }
        tvFps = TextView(this).apply { text = "  |  GLES3"; textSize = 11f; setTextColor(Color.parseColor("#7dd3fc")) }
        statusPill.addView(tvSoc); statusPill.addView(tvFps)
        rightCol.addView(statusPill)

        val camRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glassBg(12f)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listOf("드론" to floatArrayOf(0f, 0.48f, 13.5f), "탑뷰" to floatArrayOf(0f, 1.30f, 19.5f), "후측" to floatArrayOf(0.75f, 0.36f, 12.5f)).forEach { (label, preset) ->
            val b = Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener { renderer.setCameraTarget(preset[0], preset[1], preset[2]) }
            }
            camRow.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32)))
        }
        rightCol.addView(camRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        root.addView(rightCol, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END
        ).apply { setMargins(0, dp(14), dp(14), 0) })

        // Calibration & Diagnostic Drawer (Bottom-Right)
        diagPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glassBg(16f, 220)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            visibility = View.GONE
        }
        val title = TextView(this).apply { text = "어안 LUT · 화질 · AVMCamera 진단"; textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) }
        diagPanel.addView(title)

        fun addSlider(lbl: String, max: Int, init: Int, onChange: (Int) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val tv = TextView(this).apply { text = lbl; textSize = 11f; setTextColor(Color.parseColor("#cbd5e1")) }
            val sb = SeekBar(this).apply {
                this.max = max; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(tv, LinearLayout.LayoutParams(dp(92), LinearLayout.LayoutParams.WRAP_CONTENT))
            row.addView(sb, LinearLayout.LayoutParams(dp(170), LinearLayout.LayoutParams.WRAP_CONTENT))
            diagPanel.addView(row)
        }
        addSlider("어안 보정(LUT)", 100, 42) { p -> renderer.setFisheyeStrength(p / 100f) }
        addSlider("3D 보울 곡률", 50, 26) { p -> renderer.setBowlCurvature(p / 100f) }
        addSlider("야간 밝기/감마", 100, 55) { p -> renderer.setGammaBoost(0.8f + (p / 100f) * 0.7f) }

        tvDiag = TextView(this).apply {
            text = "진단 대기 중..."
            textSize = 10f
            setTextColor(Color.parseColor("#7dd3fc"))
            setPadding(0, dp(6), 0, 0)
        }
        diagPanel.addView(tvDiag)
        root.addView(diagPanel, FrameLayout.LayoutParams(
            dp(296), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END
        ).apply { setMargins(0, 0, dp(14), dp(62)) })

        // Bottom Minimal Bar
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glassBg(14f, 215)
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val tag = TextView(this).apply { text = "GLES3 · AVMCamera 3D 보울"; textSize = 11f; setTextColor(Color.parseColor("#38bdf8")); setTypeface(null, Typeface.BOLD) }
        val btnDiag = Button(this).apply {
            text = "LUT 보정 · 진단"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                diagPanel.visibility = if (diagPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                tvDiag.text = renderer.getCameraDiagnostics()
            }
        }
        dock.addView(tag, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dock.addView(btnDiag, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)))
        root.addView(dock, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dp(46), Gravity.BOTTOM
        ).apply { setMargins(dp(12), 0, dp(12), dp(8)) })
    }

    private fun startTelemetryPoller() {
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleAtFixedRate({
            try {
                val conn = URL("http://127.0.0.1:8765/telemetry").openConnection() as HttpURLConnection
                conn.connectTimeout = 100; conn.readTimeout = 100
                if (conn.responseCode == 200) {
                    val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    val j = JSONObject(body)
                    val spd = j.optDouble("speedKmh", 0.0).toInt()
                    val soc = j.optDouble("soc", 0.0).toInt()
                    val rng = j.optInt("rangeKm", 0)
                    val g = j.optInt("gear", 4)
                    val bsdL = j.optBoolean("bsdLeft", false)
                    val bsdR = j.optBoolean("bsdRight", false)
                    renderer.setBsdState(bsdL, bsdR)
                    mainHandler.post {
                        tvSpeed.text = spd.toString()
                        tvSoc.text = "${if (soc > 0) soc else "--"}%  |  ${if (rng > 0) rng else "--"} km"
                        gearViews.forEach { (id, v) ->
                            v.setTypeface(null, if (id == g) Typeface.BOLD else Typeface.NORMAL)
                            v.setTextColor(if (id == g) Color.WHITE else Color.parseColor("#64748b"))
                        }
                        tvBsd.visibility = if (bsdL || bsdR) View.VISIBLE else View.GONE
                    }
                }
                conn.disconnect()
            } catch (_: Throwable) {}
        }, 300, 50, TimeUnit.MILLISECONDS)
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
        renderer.resumeCamera()
    }

    override fun onPause() {
        renderer.pauseCamera()
        glView.onPause()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }

    override fun onDestroy() {
        poller?.shutdownNow()
        super.onDestroy()
    }
}

// ============================================================================
// 2. AVMCamera CONTROLLER (bmmcamera.jar / android.hardware.AVMCamera)
// ============================================================================
class AvmCameraController(private val context: Context) {
    private var avmInstance: Any? = null
    private var avmClass: Class<*>? = null
    @Volatile var isStreaming = false
    @Volatile var lastStatus = "초기화 전"
    @Volatile var methodDump = ""

    fun start(surfaceTexture: SurfaceTexture): Boolean {
        stop()
        try {
            val cls = resolveAvmClass()
            if (cls == null) {
                lastStatus = "AVMCamera 클래스 미발견 (실차 bmmcamera.jar 필요)"
                return false
            }
            avmClass = cls
            methodDump = cls.declaredMethods.joinToString(", ") { "${it.name}(${it.parameterTypes.size})" }

            // Try standard AVMCamera.open(...) signatures used across BYD DiLink 3/5
            val openZero = cls.methods.firstOrNull { it.name == "open" && it.parameterTypes.isEmpty() }
            val openInt  = cls.methods.firstOrNull { it.name == "open" && it.parameterTypes.size == 1 && it.parameterTypes[0] == Int::class.javaPrimitiveType }
            avmInstance = when {
                openInt != null  -> openInt.invoke(null, 0)
                openZero != null -> openZero.invoke(null)
                else -> cls.getDeclaredConstructor().apply { isAccessible = true }.newInstance()
            }
            if (avmInstance == null) {
                lastStatus = "AVMCamera.open() null 반환 (CAMERA 권한 또는 순정 360° 점유 확인)"
                return false
            }

            // Attach SurfaceTexture directly (Zero-Copy OES texture)
            val setTex = cls.methods.firstOrNull { it.name == "setPreviewTexture" && it.parameterTypes.size == 1 }
            val setSurf = cls.methods.firstOrNull { it.name == "setPreviewSurface" && it.parameterTypes.size == 1 }
            when {
                setTex != null -> setTex.invoke(avmInstance, surfaceTexture)
                setSurf != null -> setSurf.invoke(avmInstance, Surface(surfaceTexture))
            }

            val startPrev = cls.methods.firstOrNull { it.name == "startPreview" && it.parameterTypes.isEmpty() }
            startPrev?.invoke(avmInstance)

            isStreaming = true
            lastStatus = "LIVE AVMCamera (2560×1920 OES Zero-Copy)"
            return true
        } catch (t: Throwable) {
            isStreaming = false
            lastStatus = "AVMCamera 대기: ${t.cause?.message ?: t.message}"
            return false
        }
    }

    private fun resolveAvmClass(): Class<*>? {
        try { return Class.forName("android.hardware.AVMCamera") } catch (_: Throwable) {}
        return try {
            val loader = PathClassLoader("/system/framework/bmmcamera.jar", context.classLoader)
            loader.loadClass("android.hardware.AVMCamera")
        } catch (_: Throwable) { null }
    }

    fun stop() {
        val inst = avmInstance ?: return
        val cls = avmClass ?: return
        try { cls.methods.firstOrNull { it.name == "stopPreview" }?.invoke(inst) } catch (_: Throwable) {}
        try { cls.methods.firstOrNull { it.name == "release" }?.invoke(inst) } catch (_: Throwable) {}
        avmInstance = null
        isStreaming = false
    }
}

// ============================================================================
// 3. OPENGL ES 3.0 3D BOWL + PRECOMPUTED LUT FISHEYE + YUV COLOR SHADER
// ============================================================================
class RealBowlGlRenderer(
    private val context: Context,
    private val onStatus: (String) -> Unit
) : GLSurfaceView.Renderer {

    private var camTexId = 0
    private var lutTexId = 0
    private lateinit var surfaceTexture: SurfaceTexture
    private val avmController = AvmCameraController(context)
    @Volatile private var frameAvailable = false

    private var bowlProgram = 0
    private var simpleProgram = 0
    private lateinit var bowlVbo: FloatBuffer
    private lateinit var bowlIbo: ShortBuffer
    private var bowlIndexCount = 0
    private lateinit var carVbo: FloatBuffer
    private lateinit var trajVbo: FloatBuffer

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    @Volatile private var az = 0f
    @Volatile private var tAz = 0f
    @Volatile private var el = 0.48f
    @Volatile private var tEl = 0.48f
    @Volatile private var dist = 13.5f
    @Volatile private var tDist = 13.5f
    @Volatile private var fisheyeStrength = 0.42f
    @Volatile private var bowlCurvature = 0.26f
    @Volatile private var gammaBoost = 1.12f
    @Volatile private var bowlDirty = true
    @Volatile private var bsdLeft = false
    @Volatile private var bsdRight = false

    fun orbitBy(dAz: Float, dEl: Float) {
        tAz += dAz
        tEl = max(0.18f, min(1.36f, tEl + dEl))
    }

    fun setCameraTarget(a: Float, e: Float, d: Float) { tAz = a; tEl = e; tDist = d }
    fun setFisheyeStrength(s: Float) { fisheyeStrength = s }
    fun setBowlCurvature(c: Float) { bowlCurvature = c; bowlDirty = true }
    fun setGammaBoost(g: Float) { gammaBoost = g }
    fun setBsdState(l: Boolean, r: Boolean) { bsdLeft = l; bsdRight = r }

    fun getCameraDiagnostics(): String =
        "상태: ${avmController.lastStatus}\n메서드: ${avmController.methodDump.ifEmpty { "미로드" }}"

    fun resumeCamera() {
        if (::surfaceTexture.isInitialized) {
            avmController.start(surfaceTexture)
            onStatus(avmController.lastStatus)
        }
    }

    fun pauseCamera() { avmController.stop() }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.02f, 0.028f, 0.043f, 1.0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        // 1) External OES Texture for Zero-Copy AVMCamera
        val ids = IntArray(2)
        GLES30.glGenTextures(2, ids, 0)
        camTexId = ids[0]
        lutTexId = ids[1]

        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTexId)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        // 2) Precomputed Fisheye Undistortion LUT Texture (128x128 RG8, computed once)
        buildFisheyeLutTexture(lutTexId)

        surfaceTexture = SurfaceTexture(camTexId).apply {
            setDefaultBufferSize(2560, 1920)
            setOnFrameAvailableListener { frameAvailable = true }
        }
        avmController.start(surfaceTexture)
        onStatus(avmController.lastStatus)

        bowlProgram = createProgram(BOWL_VS, BOWL_FS)
        simpleProgram = createProgram(SIMPLE_VS, SIMPLE_FS)
        rebuildBowlMesh()
        buildStaticCarAndTraj()
    }

    private fun buildFisheyeLutTexture(texId: Int) {
        val size = 128
        val buf = ByteBuffer.allocateDirect(size * size * 2)
        for (y in 0 until size) {
            val ny = (y / (size - 1f)) * 2f - 1f
            for (x in 0 until size) {
                val nx = (x / (size - 1f)) * 2f - 1f
                val r = hypot(nx.toDouble(), ny.toDouble()).toFloat()
                // Brown-Conrady barrel-to-rectilinear radial LUT factor
                val scale = if (r > 0.001f) (1.0f / (1.0f + 0.36f * r * r)) else 1.0f
                val ux = ((nx * scale * 0.5f) + 0.5f).coerceIn(0f, 1f)
                val uy = ((ny * scale * 0.5f) + 0.5f).coerceIn(0f, 1f)
                buf.put((ux * 255f).toInt().toByte())
                buf.put((uy * 255f).toInt().toByte())
            }
        }
        buf.rewind()
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RG8, size, size, 0, GLES30.GL_RG, GLES30.GL_UNSIGNED_BYTE, buf)
    }

    private fun rebuildBowlMesh() {
        val n = 40
        val size = 36f
        val verts = FloatArray((n + 1) * (n + 1) * 5)
        var vi = 0
        for (iz in 0..n) {
            val tz = iz / n.toFloat()
            val z = (tz - 0.5f) * size
            for (ix in 0..n) {
                val tx = ix / n.toFloat()
                val x = (tx - 0.5f) * size
                val r = hypot(x, z)
                val y = if (r > 7.5f) ((r - 7.5f) * bowlCurvature).pow(2.0f) else 0f
                verts[vi++] = x; verts[vi++] = y; verts[vi++] = z
                verts[vi++] = tx; verts[vi++] = tz
            }
        }
        val idx = ShortArray(n * n * 6)
        var ii = 0
        for (iz in 0 until n) {
            for (ix in 0 until n) {
                val a = (iz * (n + 1) + ix).toShort()
                val b = (a + 1).toShort()
                val c = (a + n + 1).toShort()
                val d = (c + 1).toShort()
                idx[ii++] = a; idx[ii++] = c; idx[ii++] = b
                idx[ii++] = b; idx[ii++] = c; idx[ii++] = d
            }
        }
        bowlIndexCount = idx.size
        bowlVbo = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(verts); position(0) }
        bowlIbo = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().apply { put(idx); position(0) }
        bowlDirty = false
    }

    private fun buildStaticCarAndTraj() {
        // Ego Dolphin simplified 3D box (x, y, z)
        val c = floatArrayOf(
            -0.88f, 0.35f, -2.14f,   0.88f, 0.35f, -2.14f,   0.88f, 0.35f, 2.14f,
            -0.88f, 0.35f, -2.14f,   0.88f, 0.35f,  2.14f,  -0.88f, 0.35f, 2.14f,
            -0.82f, 1.38f, -1.25f,   0.82f, 1.38f, -1.25f,   0.82f, 1.38f, 1.45f,
            -0.82f, 1.38f, -1.25f,   0.82f, 1.38f,  1.45f,  -0.82f, 1.38f, 1.45f
        )
        carVbo = ByteBuffer.allocateDirect(c.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(c); position(0) }
        val t = floatArrayOf(
            -0.70f, 0.05f, -2.3f,   0.70f, 0.05f, -2.3f,   0.52f, 0.05f, -15.5f,
            -0.70f, 0.05f, -2.3f,   0.52f, 0.05f, -15.5f, -0.52f, 0.05f, -15.5f
        )
        trajVbo = ByteBuffer.allocateDirect(t.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(t); position(0) }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h)
        Matrix.perspectiveM(projMatrix, 0, 48f, w.toFloat() / max(1, h), 0.3f, 140f)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (bowlDirty) rebuildBowlMesh()
        if (frameAvailable) {
            frameAvailable = false
            surfaceTexture.updateTexImage()
        }

        az += (tAz - az) * 0.14f
        el += (tEl - el) * 0.14f
        dist += (tDist - dist) * 0.14f
        val hd = dist * cos(el)
        Matrix.setLookAtM(viewMatrix, 0, sin(az) * hd, max(1.8f, dist * sin(el)), cos(az) * hd, 0f, 0.8f, -5.0f, 0f, 1f, 0f)
        Matrix.multiplyMM(mvpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // 1) Draw 3D Hemispherical Bowl (Live AVMCamera OES + LUT + YUV Color Shader)
        GLES30.glUseProgram(bowlProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(bowlProgram, "uMvp"), 1, false, mvpMatrix, 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(bowlProgram, "uFisheye"), fisheyeStrength)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(bowlProgram, "uGamma"), gammaBoost)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uHasCam"), if (avmController.isStreaming) 1 else 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTexId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uCamTex"), 0)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, lutTexId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uLutTex"), 1)

        val stride = 5 * 4
        bowlVbo.position(0)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, bowlVbo)
        bowlVbo.position(3)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, bowlVbo)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, bowlIndexCount, GLES30.GL_UNSIGNED_SHORT, bowlIbo)

        // 2) Draw Ego Dolphin + FSD Blue Trajectory Ribbon
        GLES30.glUseProgram(simpleProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(simpleProgram, "uMvp"), 1, false, mvpMatrix, 0)
        GLES30.glEnableVertexAttribArray(0)

        trajVbo.position(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, trajVbo)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(simpleProgram, "uColor"), 0.22f, 0.74f, 0.97f, 0.45f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)

        carVbo.position(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 12, carVbo)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(simpleProgram, "uColor"), 0.92f, 0.95f, 0.98f, 1.0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(simpleProgram, "uColor"), 0.08f, 0.12f, 0.18f, 1.0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 6, 6)
    }

    private fun createProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int = GLES30.glCreateShader(type).also {
            GLES30.glShaderSource(it, src); GLES30.glCompileShader(it)
        }
        return GLES30.glCreateProgram().also {
            GLES30.glAttachShader(it, compile(GLES30.GL_VERTEX_SHADER, vs))
            GLES30.glAttachShader(it, compile(GLES30.GL_FRAGMENT_SHADER, fs))
            GLES30.glLinkProgram(it)
        }
    }

    companion object {
        private const val BOWL_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
out vec2 vUv;
void main() {
    vUv = aUv;
    gl_Position = uMvp * vec4(aPos, 1.0);
}"""

        private const val BOWL_FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
in vec2 vUv;
uniform samplerExternalOES uCamTex;
uniform sampler2D uLutTex;
uniform float uFisheye;
uniform float uGamma;
uniform int uHasCam;
out vec4 fragColor;

vec2 sampleQuadUv(vec2 p) {
    // Map 3D bowl planar coords [-0.5..0.5] into 4-split 2560x1920 quad (Front/Rear/Left/Right)
    vec2 localUv;
    vec2 quadOffset;
    if (abs(p.y) >= abs(p.x)) {
        if (p.y < 0.0) { // Front (Top-Left quadrant)
            localUv = vec2(p.x + 0.5, (-p.y) * 2.0);
            quadOffset = vec2(0.0, 0.0);
        } else {         // Rear (Top-Right quadrant)
            localUv = vec2(0.5 - p.x, p.y * 2.0);
            quadOffset = vec2(0.5, 0.0);
        }
    } else {
        if (p.x < 0.0) { // Left (Bottom-Left quadrant)
            localUv = vec2(p.y + 0.5, (-p.x) * 2.0);
            quadOffset = vec2(0.0, 0.5);
        } else {         // Right (Bottom-Right quadrant)
            localUv = vec2(0.5 - p.y, p.x * 2.0);
            quadOffset = vec2(0.5, 0.5);
        }
    }
    vec2 clamped = clamp(localUv, 0.02, 0.98);
    vec2 lut = texture(uLutTex, clamped).rg;
    vec2 corrected = mix(clamped, lut, uFisheye);
    return quadOffset + corrected * 0.5;
}

void main() {
    vec2 p = vUv - 0.5;
    if (uHasCam == 0) {
        float r = length(p);
        float ring = smoothstep(0.004, 0.0, abs(fract(r * 8.0) - 0.5) - 0.485);
        vec3 bg = mix(vec3(0.035, 0.051, 0.086), vec3(0.14, 0.52, 0.80), ring * 0.42);
        fragColor = vec4(bg, 1.0);
        return;
    }
    vec2 qUv = sampleQuadUv(p);
    vec3 col = texture(uCamTex, qUv).rgb;
    // 1-pass Color Grading (Contrast + Saturation + Gamma)
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(luma), col, 1.18);
    col = pow(clamp((col - 0.5) * 1.08 + 0.5, 0.0, 1.0), vec3(1.0 / uGamma));
    fragColor = vec4(col, 1.0);
}"""

        private const val SIMPLE_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uMvp;
void main() { gl_Position = uMvp * vec4(aPos, 1.0); }"""

        private const val SIMPLE_FS = """#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main() { fragColor = uColor; }"""
    }
}

// ============================================================================
// 4. ADB UID 2000 HAL BRIDGE (Telemetry only: Speed, Gear, SOC, BSD, Turn)
// ============================================================================
class BydPermissionContext(base: Context) : ContextWrapper(base) {
    override fun checkCallingOrSelfPermission(permission: String): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkCallingOrSelfPermission(permission)
    override fun checkPermission(permission: String, pid: Int, uid: Int): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkPermission(permission, pid, uid)
    override fun enforceCallingOrSelfPermission(permission: String, message: String?) {
        if (!permission.contains("BYDAUTO")) super.enforceCallingOrSelfPermission(permission, message)
    }
}

object NativeAutoserviceClient {
    private var binder: IBinder? = null
    private var descriptor: String? = null
    fun init() {
        try {
            val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java).invoke(null, "autoservice") as? IBinder
            if (b != null) { binder = b; descriptor = b.interfaceDescriptor }
        } catch (_: Throwable) {}
    }
    fun readInt(deviceType: Int, featureId: Int): Int? {
        val b = binder ?: return null; val d = descriptor ?: return null
        val data = Parcel.obtain(); val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(d); data.writeInt(deviceType); data.writeInt(featureId)
            if (b.transact(5, data, reply, 0)) {
                val st = reply.readInt(); val v = reply.readInt()
                if (st == 0 && v != -10011 && v != 65535) v else null
            } else null
        } catch (_: Throwable) { null } finally { data.recycle(); reply.recycle() }
    }
}

object BydRealBowlBridge {
    private const val PORT = 8765
    @Volatile private var speedKmh = 0.0
    @Volatile private var soc = 0.0
    @Volatile private var rangeKm = 0
    @Volatile private var gear = 4
    @Volatile private var turnSignal = 0
    @Volatile private var bsdLeft = false
    @Volatile private var bsdRight = false

    private var speedDev: Any? = null; private var statDev: Any? = null
    private var gearDev: Any? = null; private var lightDev: Any? = null; private var adasDev: Any? = null
    private var fidBsdL: Int? = null; private var fidBsdR: Int? = null
    private var fidTurnL: Int? = null; private var fidTurnR: Int? = null

    @JvmStatic
    fun main(args: Array<String>) {
        println("[BydRealBowlBridge] UID 2000 HAL Telemetry Bridge Starting...")
        val ctx = obtainSystemContext()
        NativeAutoserviceClient.init()
        if (ctx != null) {
            val pctx = BydPermissionContext(ctx)
            speedDev = getInst("android.hardware.bydauto.speed.BYDAutoSpeedDevice", pctx)
            statDev  = getInst("android.hardware.bydauto.statistic.BYDAutoStatisticDevice", pctx)
            gearDev  = getInst("android.hardware.bydauto.gearbox.BYDAutoGearboxDevice", pctx)
            lightDev = getInst("android.hardware.bydauto.light.BYDAutoLightDevice", pctx)
            adasDev  = getInst("android.hardware.bydauto.adas.BYDAutoADASDevice", pctx)
            fidBsdL  = findFid("Adas",  listOf("ADAS_BSD_LEFT", "BSD_LEFT_WARN", "BSD_ALARM_LEFT"))
            fidBsdR  = findFid("Adas",  listOf("ADAS_BSD_RIGHT", "BSD_RIGHT_WARN", "BSD_ALARM_RIGHT"))
            fidTurnL = findFid("Light", listOf("LIGHT_LEFT_TURN", "LEFT_TURN_SIGNAL", "TURN_LEFT"))
            fidTurnR = findFid("Light", listOf("LIGHT_RIGHT_TURN", "RIGHT_TURN_SIGNAL", "TURN_RIGHT"))
        }
        Thread({
            while (true) {
                try {
                    speedDev?.let { (findMethod(it, "getCurrentSpeed")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..260.0) speedKmh = v } }
                    statDev?.let {
                        (findMethod(it, "getElecPercentageValue")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..100.0) soc = v }
                        (findMethod(it, "getElecDrivingRangeValue")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 0..1000) rangeKm = v }
                    }
                    gearDev?.let { (findMethod(it, "getGearboxAutoModeType")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 1..4) gear = v } }
                    val tl = readProtected(lightDev, 1004, fidTurnL) ?: 0
                    val tr = readProtected(lightDev, 1004, fidTurnR) ?: 0
                    turnSignal = when { tl > 0 && tr == 0 -> -1; tr > 0 && tl == 0 -> 1; else -> 0 }
                    bsdLeft = (readProtected(adasDev, 1001, fidBsdL) ?: 0) > 0
                    bsdRight = (readProtected(adasDev, 1001, fidBsdR) ?: 0) > 0
                    Thread.sleep(50)
                } catch (_: InterruptedException) { break } catch (_: Throwable) { Thread.sleep(200) }
            }
        }, "hal-poller").apply { isDaemon = true; start() }

        val server = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
        while (true) {
            val client = server.accept()
            try {
                client.getOutputStream().use { out ->
                    val b = "{\"speedKmh\":$speedKmh,\"soc\":$soc,\"rangeKm\":$rangeKm,\"gear\":$gear,\"turnSignal\":$turnSignal,\"bsdLeft\":$bsdLeft,\"bsdRight\":$bsdRight}".toByteArray(StandardCharsets.UTF_8)
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${b.size}\r\n\r\n").toByteArray())
                    out.write(b); out.flush()
                }
            } catch (_: Throwable) {} finally { client.close() }
        }
    }

    @SuppressLint("PrivateApi")
    private fun obtainSystemContext(): Context? = try {
        if (Looper.getMainLooper() == null) Looper.prepareMainLooper()
        val at = Class.forName("android.app.ActivityThread")
        at.getMethod("getSystemContext").invoke(at.getMethod("systemMain").invoke(null)) as? Context
    } catch (_: Throwable) { null }

    private fun getInst(cn: String, ctx: Context): Any? = try {
        Class.forName(cn).getMethod("getInstance", Context::class.java).invoke(null, ctx)
    } catch (_: Throwable) { null }

    private fun findFid(nested: String, keys: List<String>): Int? = try {
        Class.forName("android.hardware.bydauto.BYDAutoFeatureIds$$nested").fields.firstOrNull { f ->
            val n = f.name.uppercase(); keys.any { n.contains(it) } && !n.endsWith("_SET")
        }?.getInt(null)
    } catch (_: Throwable) { null }

    private fun findMethod(obj: Any, name: String, vararg p: Class<*>): Method? {
        var c: Class<*>? = obj.javaClass
        while (c != null) {
            try { return c.getDeclaredMethod(name, *p).apply { isAccessible = true } }
            catch (_: NoSuchMethodException) { c = c.superclass }
        }
        return null
    }

    private fun readProtected(obj: Any?, devType: Int, fid: Int?): Int? {
        if (fid == null) return null
        if (obj != null) {
            try {
                val v = (findMethod(obj, "get", Int::class.javaPrimitiveType!!, Int::class.javaPrimitiveType!!)?.invoke(obj, devType, fid) as? Number)?.toInt()
                if (v != null && v != -10011 && v != 65535) return v
            } catch (_: Throwable) {}
        }
        return NativeAutoserviceClient.readInt(devType, fid)
    }
}
