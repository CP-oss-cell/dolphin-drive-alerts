/*
 * ============================================================================
 * BYD Dolphin × FSD 15 Pure Real-View v2.3
 * - First-Run Auto Permission & Loopback ADB (127.0.0.1:5555) Provisioner
 *   (Auto-grants CAMERA + BYDAUTO_*_COMMON + launches UID 2000 HAL Bridge)
 * - Sculpted 3D Dolphin + Animated FSD 15 Neon Trajectory
 * - Native GLES3 AVMCamera (2560x1920 OES Zero-Copy) + Precomputed Fisheye LUT
 * ============================================================================
 */
package com.byd.dolphin.realbowl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import dalvik.system.PathClassLoader
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.lang.reflect.Method
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// ============================================================================
// 1. PURE-KOTLIN LOOPBACK ADB CLIENT (127.0.0.1:5555, Zero Dependencies)
// ============================================================================
object LoopbackAdbProvisioner {
    private const val A_CNXN = 0x4e584e43
    private const val A_AUTH = 0x48545541
    private const val A_OPEN = 0x4e45504f
    private const val A_OKAY = 0x59414b4f
    private const val A_CLSE = 0x45534c43
    private const val A_WRTE = 0x45545257
    private const val AUTH_TOKEN = 1
    private const val AUTH_SIGNATURE = 2
    private const val AUTH_RSAPUBLICKEY = 3

    fun autoProvisionAsync(context: Context, onLog: (String) -> Unit) {
        Thread({
            try {
                onLog("Loopback ADB(127.0.0.1:5555) 연결 시도 중...")
                val kp = loadOrCreateRsaKeyPair(context)
                val apkPath = context.packageCodePath
                val pkg = context.packageName

                Socket("127.0.0.1", 5555).use { sock ->
                    sock.soTimeout = 8000
                    val inp = sock.getInputStream()
                    val out = sock.getOutputStream()

                    // 1. Send CNXN
                    sendPacket(out, A_CNXN, 0x01000000, 256 * 1024, "host::\u0000".toByteArray())

                    var sentSig = false
                    var connected = false
                    while (!connected) {
                        val pkt = readPacket(inp) ?: break
                        when (pkt.cmd) {
                            A_CNXN -> connected = true
                            A_AUTH -> {
                                if (pkt.arg0 == AUTH_TOKEN) {
                                    if (!sentSig) {
                                        sentSig = true
                                        val sig = signAdbToken(kp.private, pkt.payload)
                                        sendPacket(out, A_AUTH, AUTH_SIGNATURE, 0, sig)
                                    } else {
                                        onLog("차량 화면에 '디버깅 허용(항상 허용)' 팝업이 뜨면 수락해 주세요...")
                                        val pub = encodeAdbPublicKey(kp.public as RSAPublicKey, "dolphin-realbowl@byd")
                                        sendPacket(out, A_AUTH, AUTH_RSAPUBLICKEY, 0, pub)
                                    }
                                }
                            }
                        }
                    }

                    if (!connected) {
                        onLog("ADB 인증 대기/실패 (무선 디버깅 ON 및 팝업 허용 필요)")
                        return@Thread
                    }

                    onLog("Loopback ADB 인증 성공! 권한 부여 및 브릿지 기동 중...")
                    val perms = listOf(
                        "android.permission.CAMERA",
                        "android.permission.BYDAUTO_BODYWORK_COMMON",
                        "android.permission.BYDAUTO_SPEED_COMMON",
                        "android.permission.BYDAUTO_RADAR_COMMON",
                        "android.permission.BYDAUTO_ADAS_COMMON",
                        "android.permission.BYDAUTO_STATISTIC_COMMON"
                    )
                    val grantCmd = perms.joinToString("; ") { "pm grant $pkg $it 2>/dev/null || true" }
                    val bridgeCmd = "pkill -f BydRealBowlBridge 2>/dev/null || true; " +
                        "nohup app_process -Djava.class.path=$apkPath:/system/framework/bmmcamera.jar / " +
                        "com.byd.dolphin.realbowl.BydRealBowlBridge >/data/local/tmp/realbowl.log 2>&1 &"

                    runShell(inp, out, 1, "$grantCmd; $bridgeCmd")
                    onLog("자동 권한 부여 + UID 2000 HAL 브릿지 기동 완료!")
                }
            } catch (t: Throwable) {
                onLog("Loopback ADB 미연결 (${t.message}) — 무선 디버깅 OFF 상태거나 수동 허용 필요")
            }
        }, "loopback-adb-provisioner").start()
    }

    private data class AdbPkt(val cmd: Int, val arg0: Int, val arg1: Int, val payload: ByteArray)

    private fun sendPacket(out: OutputStream, cmd: Int, arg0: Int, arg1: Int, data: ByteArray) {
        var sum = 0
        for (b in data) sum += (b.toInt() and 0xFF)
        val hdr = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
            putInt(cmd); putInt(arg0); putInt(arg1); putInt(data.size); putInt(sum); putInt(cmd xor -1)
        }.array()
        out.write(hdr)
        if (data.isNotEmpty()) out.write(data)
        out.flush()
    }

    private fun readPacket(inp: InputStream): AdbPkt? {
        val hdr = ByteArray(24)
        if (!readFully(inp, hdr)) return null
        val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int; val arg0 = bb.int; val arg1 = bb.int; val len = bb.int; bb.int; bb.int
        val payload = ByteArray(len.coerceIn(0, 1024 * 1024))
        if (len > 0 && !readFully(inp, payload)) return null
        return AdbPkt(cmd, arg0, arg1, payload)
    }

    private fun readFully(inp: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val r = inp.read(buf, off, buf.size - off)
            if (r < 0) return false
            off += r
        }
        return true
    }

    private fun runShell(inp: InputStream, out: OutputStream, localId: Int, cmd: String) {
        sendPacket(out, A_OPEN, localId, 0, "shell:$cmd\u0000".toByteArray(StandardCharsets.UTF_8))
        while (true) {
            val pkt = readPacket(inp) ?: break
            if (pkt.cmd == A_OKAY) sendPacket(out, A_OKAY, localId, pkt.arg0, ByteArray(0))
            else if (pkt.cmd == A_WRTE) sendPacket(out, A_OKAY, localId, pkt.arg0, ByteArray(0))
            else if (pkt.cmd == A_CLSE) break
        }
    }

    private fun loadOrCreateRsaKeyPair(ctx: Context): KeyPair {
        val privFile = File(ctx.filesDir, "adb_key.priv")
        val pubFile = File(ctx.filesDir, "adb_key.pub")
        if (privFile.exists() && pubFile.exists()) {
            val kf = KeyFactory.getInstance("RSA")
            val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
            val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes()))
            return KeyPair(pub, priv)
        }
        val kpg = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }
        val kp = kpg.generateKeyPair()
        privFile.writeBytes(kp.private.encoded)
        pubFile.writeBytes(kp.public.encoded)
        return kp
    }

    private fun signAdbToken(priv: PrivateKey, token: ByteArray): ByteArray {
        val digestInfoPrefix = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
        )
        val input = digestInfoPrefix + token
        return Signature.getInstance("NONEwithRSA").run {
            initSign(priv)
            update(input)
            sign()
        }
    }

    private fun encodeAdbPublicKey(pub: RSAPublicKey, name: String): ByteArray {
        val words = 64 // 2048 / 32
        val n = pub.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.modInverse(r32)).intValueExact()
        val r = BigInteger.ONE.shiftLeft(2048)
        val rr = r.multiply(r).mod(n)

        val bb = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(words)
        bb.putInt(n0inv)
        for (i in 0 until words) bb.putInt(n.shiftRight(i * 32).and(BigInteger.valueOf(0xFFFFFFFFL)).toInt())
        for (i in 0 until words) bb.putInt(rr.shiftRight(i * 32).and(BigInteger.valueOf(0xFFFFFFFFL)).toInt())
        bb.putInt(pub.publicExponent.toInt())

        val b64 = Base64.encodeToString(bb.array(), Base64.NO_WRAP)
        return "$b64 $name\u0000".toByteArray(StandardCharsets.UTF_8)
    }
}

// ============================================================================
// 2. NATIVE ACTIVITY + FIRST-RUN AUTO PERMISSION WIZARD + FSD 15 HUD
// ============================================================================
class MainActivity : Activity() {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: RealBowlGlRenderer
    private val mainHandler = Handler(Looper.getMainLooper())
    private var poller: ScheduledExecutorService? = null

    private lateinit var tvSpeed: TextView
    private lateinit var tvConn: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvBsd: TextView
    private lateinit var tvDiag: TextView
    private lateinit var tvPermLog: TextView
    private lateinit var diagPanel: LinearLayout
    private lateinit var permBanner: LinearLayout
    private val gearViews = mutableMapOf<Int, TextView>()

    private var dragX = 0f
    private var dragY = 0f

    private val runtimePermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        "android.permission.BYDAUTO_BODYWORK_COMMON",
        "android.permission.BYDAUTO_SPEED_COMMON",
        "android.permission.BYDAUTO_RADAR_COMMON",
        "android.permission.BYDAUTO_ADAS_COMMON",
        "android.permission.BYDAUTO_STATISTIC_COMMON"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#05070b")) }

        renderer = RealBowlGlRenderer(this) { statusText ->
            mainHandler.post {
                tvConn.text = statusText
                if (::tvDiag.isInitialized) tvDiag.text = renderer.getCameraDiagnostics()
            }
        }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dragX = ev.x; dragY = ev.y }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.x - dragX
                        val dy = ev.y - dragY
                        dragX = ev.x; dragY = ev.y
                        renderer.orbitBy(-dx * 0.0065f, dy * 0.0055f)
                    }
                }
                true
            }
        }
        root.addView(glView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val hudLayer = FrameLayout(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        hudLayer.setPadding(dp(12), dp(46), dp(12), dp(58))
        hudLayer.setOnApplyWindowInsetsListener { v, insets ->
            val top = max(dp(44), insets.systemWindowInsetTop + dp(8))
            val bot = max(dp(56), insets.systemWindowInsetBottom + dp(8))
            v.setPadding(dp(12), top, dp(12), bot)
            insets
        }
        buildFsdHudOverlay(hudLayer)
        root.addView(hudLayer, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))

        setContentView(root)
        runFirstLaunchPermissionFlow()
        startTelemetryPoller()
    }

    private fun runFirstLaunchPermissionFlow() {
        val missing = runtimePermissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 101)
        }
        // Automatically attempt Loopback ADB self-provisioning (CAMERA + BYDAUTO + UID 2000 Bridge)
        LoopbackAdbProvisioner.autoProvisionAsync(this) { msg ->
            mainHandler.post {
                if (::tvPermLog.isInitialized) tvPermLog.text = msg
                if (msg.contains("완료")) {
                    renderer.resumeCamera()
                    mainHandler.postDelayed({
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                            permBanner.visibility = View.GONE
                        }
                    }, 1800)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            renderer.resumeCamera()
            permBanner.visibility = View.GONE
        }
    }

    private fun glassBg(radiusDp: Float = 16f, alpha: Int = 195, borderColor: Int = 0x33FFFFFF): GradientDrawable {
        val d = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(Color.argb(alpha, 10, 14, 22))
            cornerRadius = radiusDp * d
            setStroke((1 * d).toInt().coerceAtLeast(1), borderColor)
        }
    }

    private fun buildFsdHudOverlay(hudLayer: FrameLayout) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cluster = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glassBg(16f); setPadding(dp(14), dp(10), dp(16), dp(10))
        }
        val gearCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        listOf(1 to "P", 2 to "R", 3 to "N", 4 to "D").forEach { (id, lbl) ->
            val tv = TextView(this).apply {
                text = lbl; textSize = 11f
                setTypeface(null, if (id == 4) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (id == 4) Color.WHITE else Color.parseColor("#64748b"))
            }
            gearViews[id] = tv; gearCol.addView(tv)
        }
        cluster.addView(gearCol)
        cluster.addView(View(this).apply { setBackgroundColor(0x22FFFFFF) }, LinearLayout.LayoutParams(dp(1), dp(36)).apply { marginStart = dp(12); marginEnd = dp(12) })

        val spdCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val spdRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        tvSpeed = TextView(this).apply { text = "0"; textSize = 30f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) }
        val tvUnit = TextView(this).apply { text = " km/h"; textSize = 11f; setTextColor(Color.parseColor("#94a3b8")) }
        spdRow.addView(tvSpeed); spdRow.addView(tvUnit)
        tvConn = TextView(this).apply { text = "권한 · AVMCamera 확인 중..."; textSize = 10f; setTextColor(Color.parseColor("#38bdf8")) }
        spdCol.addView(spdRow); spdCol.addView(tvConn)
        cluster.addView(spdCol)
        leftCol.addView(cluster)

        tvBsd = TextView(this).apply {
            text = "BSD 후측방 사각지대 차량 감지"; textSize = 11f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#fecaca")); background = glassBg(20f, 215, 0xAAEF4444.toInt())
            setPadding(dp(12), dp(5), dp(12), dp(5)); visibility = View.GONE
        }
        leftCol.addView(tvBsd, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        hudLayer.addView(leftCol, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))

        // First-Run Auto Permission Card (shown until CAMERA & Bridge are ready)
        permBanner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glassBg(16f, 230, 0x6638BDF8)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) View.GONE else View.VISIBLE
        }
        permBanner.addView(TextView(this).apply {
            text = "초기 권한 자동 획득 (카메라 · BYD 차량 정보)"
            textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
        })
        tvPermLog = TextView(this).apply {
            text = "초기 권한 요청 중..."
            textSize = 10f; setTextColor(Color.parseColor("#7dd3fc"))
            setPadding(0, dp(4), 0, dp(6))
        }
        permBanner.addView(tvPermLog)

        val permBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnAutoGrant = Button(this).apply {
            text = "자동 권한 재시도"; textSize = 10f; setTextColor(Color.WHITE)
            background = glassBg(10f, 220, 0x8838BDF8.toInt())
            setOnClickListener { runFirstLaunchPermissionFlow() }
        }
        val btnAppSettings = Button(this).apply {
            text = "앱 권한 설정 열기"; textSize = 10f; setTextColor(Color.WHITE)
            background = glassBg(10f, 180)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            }
        }
        permBtnRow.addView(btnAutoGrant, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(6) })
        permBtnRow.addView(btnAppSettings, LinearLayout.LayoutParams(0, dp(34), 1f))
        permBanner.addView(permBtnRow)
        hudLayer.addView(permBanner, FrameLayout.LayoutParams(dp(320), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply { bottomMargin = dp(52) })

        val rightCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        val statusPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = glassBg(20f); setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        tvSoc = TextView(this).apply { text = "--%  |  -- km  |  GLES3"; textSize = 11f; setTextColor(Color.parseColor("#34d399")) }
        statusPill.addView(tvSoc); rightCol.addView(statusPill)

        val camRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = glassBg(12f); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        listOf("드론" to floatArrayOf(0f, 0.44f, 11.8f), "탑뷰" to floatArrayOf(0f, 1.30f, 18.5f), "후측" to floatArrayOf(0.75f, 0.34f, 11.2f)).forEach { (label, preset) ->
            val b = Button(this).apply {
                text = label; textSize = 11f; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT)
                setPadding(dp(10), dp(2), dp(10), dp(2))
                setOnClickListener { renderer.setCameraTarget(preset[0], preset[1], preset[2]) }
            }
            camRow.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32)))
        }
        rightCol.addView(camRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        hudLayer.addView(rightCol, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))

        diagPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = glassBg(16f, 225, 0x5538BDF8)
            setPadding(dp(14), dp(10), dp(14), dp(10)); visibility = View.GONE
        }
        diagPanel.addView(TextView(this).apply { text = "AVMCamera 진단 & LUT 보정"; textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) })

        fun addSlider(lbl: String, max: Int, init: Int, onChange: (Int) -> Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val tv = TextView(this).apply { text = lbl; textSize = 11f; setTextColor(Color.parseColor("#cbd5e1")) }
            val sb = SeekBar(this).apply {
                this.max = max; progress = init
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(tv, LinearLayout.LayoutParams(dp(92), LinearLayout.LayoutParams.WRAP_CONTENT))
            row.addView(sb, LinearLayout.LayoutParams(dp(190), LinearLayout.LayoutParams.WRAP_CONTENT))
            diagPanel.addView(row)
        }
        addSlider("어안 보정(LUT)", 100, 42) { p -> renderer.setFisheyeStrength(p / 100f) }
        addSlider("3D 보울 곡률", 50, 26) { p -> renderer.setBowlCurvature(p / 100f) }
        addSlider("야간 감마", 100, 55) { p -> renderer.setGammaBoost(0.8f + (p / 100f) * 0.7f) }

        tvDiag = TextView(this).apply { text = "AVMCamera 메서드 수집 중..."; textSize = 10f; setTextColor(Color.parseColor("#7dd3fc")) }
        diagPanel.addView(ScrollView(this).apply { addView(tvDiag) }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(105)).apply { topMargin = dp(6) })
        hudLayer.addView(diagPanel, FrameLayout.LayoutParams(dp(320), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = dp(52) })

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glassBg(14f, 220); setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val tag = TextView(this).apply { text = "GLES3 · AVMCamera 3D 보울 v2.3"; textSize = 11f; setTextColor(Color.parseColor("#38bdf8")); setTypeface(null, Typeface.BOLD) }
        val btnPerm = Button(this).apply {
            text = "권한 설정"; textSize = 11f; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { permBanner.visibility = if (permBanner.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        val btnDiag = Button(this).apply {
            text = "진단 · LUT"; textSize = 11f; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                diagPanel.visibility = if (diagPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                tvDiag.text = renderer.getCameraDiagnostics()
            }
        }
        dock.addView(tag, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dock.addView(btnPerm, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)))
        dock.addView(btnDiag, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(34)))
        hudLayer.addView(dock, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(44), Gravity.BOTTOM))
    }

    private fun startTelemetryPoller() {
        poller = Executors.newSingleThreadScheduledExecutor()
        poller?.scheduleAtFixedRate({
            try {
                val conn = URL("http://127.0.0.1:8765/telemetry").openConnection() as HttpURLConnection
                conn.connectTimeout = 100; conn.readTimeout = 100
                if (conn.responseCode == 200) {
                    val body = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    val j = JSONObject(body)
                    val spd = j.optDouble("speedKmh", 0.0).toInt()
                    val soc = j.optDouble("soc", 0.0).toInt()
                    val rng = j.optInt("rangeKm", 0)
                    val g = j.optInt("gear", 4)
                    val bsdL = j.optBoolean("bsdLeft", false); val bsdR = j.optBoolean("bsdRight", false)
                    mainHandler.post {
                        tvSpeed.text = spd.toString()
                        tvSoc.text = "${if (soc > 0) soc else "--"}%  |  ${if (rng > 0) rng else "--"} km  |  GLES3"
                        gearViews.forEach { (id, v) ->
                            v.setTypeface(null, if (id == g) Typeface.BOLD else Typeface.NORMAL)
                            v.setTextColor(if (id == g) Color.WHITE else Color.parseColor("#64748b"))
                        }
                        tvBsd.visibility = if (bsdL || bsdR) View.VISIBLE else View.GONE
                    }
                }
                conn.disconnect()
            } catch (_: Throwable) {}
        }, 300, 50, TimeUnit.MILLISECONDS)
    }

    override fun onResume() { super.onResume(); glView.onResume(); renderer.resumeCamera() }
    override fun onPause() { renderer.pauseCamera(); glView.onPause(); super.onPause() }
    override fun onDestroy() { poller?.shutdownNow(); super.onDestroy() }
}

class AvmCameraController(private val context: Context) {
    private var avmInstance: Any? = null
    private var avmClass: Class<*>? = null
    @Volatile var lastStatus = "초기화 전"
    @Volatile var methodDump = ""
    @Volatile var bindLog = ""

    fun start(surfaceTexture: SurfaceTexture): Boolean {
        stop()
        try {
            val cls = resolveAvmClass() ?: run { lastStatus = "AVMCamera 클래스 미발견"; return false }
            avmClass = cls
            methodDump = cls.declaredMethods.joinToString("\n") { m ->
                "${m.name}(${m.parameterTypes.joinToString(",") { it.simpleName }}):${m.returnType.simpleName}"
            }

            val openZero = cls.methods.firstOrNull { it.name == "open" && it.parameterTypes.isEmpty() }
            val openInt  = cls.methods.firstOrNull { it.name == "open" && it.parameterTypes.size == 1 && it.parameterTypes[0] == Int::class.javaPrimitiveType }
            var opened: Any? = null; var openDesc = ""
            if (openZero != null) { opened = try { openZero.invoke(null) } catch (_: Throwable) { null }; if (opened != null) openDesc = "open()" }
            if (opened == null && openInt != null) {
                for (id in intArrayOf(0, 1, 2, 4, 5)) {
                    opened = try { openInt.invoke(null, id) } catch (_: Throwable) { null }
                    if (opened != null) { openDesc = "open($id)"; break }
                }
            }
            if (opened == null) {
                opened = try { cls.getDeclaredConstructor().apply { isAccessible = true }.newInstance() } catch (_: Throwable) { null }
                if (opened != null) openDesc = "new()"
            }
            avmInstance = opened ?: run { lastStatus = "AVMCamera open 실패 (CAMERA 권한 확인)"; return false }

            val setTex = cls.methods.firstOrNull { it.name == "setPreviewTexture" && it.parameterTypes.size == 1 }
            val setSurf = cls.methods.firstOrNull { it.name == "setPreviewSurface" && it.parameterTypes.size == 1 }
            var texBind = "none"
            when {
                setTex != null -> { setTex.invoke(avmInstance, surfaceTexture); texBind = "setPreviewTexture" }
                setSurf != null -> { setSurf.invoke(avmInstance, Surface(surfaceTexture)); texBind = "setPreviewSurface" }
            }
            cls.methods.firstOrNull { it.name == "startPreview" && it.parameterTypes.isEmpty() }?.invoke(avmInstance)
            bindLog = "$openDesc -> $texBind -> startPreview"
            lastStatus = "AVMCamera 연결됨 (프레임 대기 · 진단 확인)"
            return true
        } catch (t: Throwable) {
            lastStatus = "AVMCamera 예외: ${t.cause?.message ?: t.message}"
            return false
        }
    }

    private fun resolveAvmClass(): Class<*>? {
        try { return Class.forName("android.hardware.AVMCamera") } catch (_: Throwable) {}
        return try { PathClassLoader("/system/framework/bmmcamera.jar", context.classLoader).loadClass("android.hardware.AVMCamera") } catch (_: Throwable) { null }
    }

    fun stop() {
        val inst = avmInstance ?: return; val cls = avmClass ?: return
        try { cls.methods.firstOrNull { it.name == "stopPreview" }?.invoke(inst) } catch (_: Throwable) {}
        try { cls.methods.firstOrNull { it.name == "release" }?.invoke(inst) } catch (_: Throwable) {}
        avmInstance = null
    }
}

class RealBowlGlRenderer(
    private val context: Context,
    private val onStatus: (String) -> Unit
) : GLSurfaceView.Renderer {

    private var camTexId = 0; private var lutTexId = 0
    private lateinit var surfaceTexture: SurfaceTexture
    private val avmController = AvmCameraController(context)
    @Volatile private var frameAvailable = false
    @Volatile private var receivedFrames = 0L

    private var bowlProgram = 0; private var carProgram = 0; private var trajProgram = 0
    private lateinit var bowlVbo: FloatBuffer; private lateinit var bowlIbo: ShortBuffer; private var bowlIndexCount = 0
    private lateinit var bodyVbo: FloatBuffer; private var bodyVertCount = 0
    private lateinit var glassVbo: FloatBuffer; private var glassVertCount = 0
    private lateinit var wheelVbo: FloatBuffer; private var wheelVertCount = 0
    private lateinit var lightVbo: FloatBuffer; private var lightVertCount = 0
    private lateinit var shadowVbo: FloatBuffer; private lateinit var trajVbo: FloatBuffer

    private val projMatrix = FloatArray(16); private val viewMatrix = FloatArray(16); private val mvpMatrix = FloatArray(16)
    private var startTimeMs = System.currentTimeMillis()

    @Volatile private var az = 0f; @Volatile private var tAz = 0f
    @Volatile private var el = 0.44f; @Volatile private var tEl = 0.44f
    @Volatile private var dist = 11.8f; @Volatile private var tDist = 11.8f
    @Volatile private var fisheyeStrength = 0.42f; @Volatile private var bowlCurvature = 0.26f; @Volatile private var gammaBoost = 1.12f
    @Volatile private var bowlDirty = true

    fun orbitBy(dAz: Float, dEl: Float) { tAz += dAz; tEl = max(0.18f, min(1.36f, tEl + dEl)) }
    fun setCameraTarget(a: Float, e: Float, d: Float) { tAz = a; tEl = e; tDist = d }
    fun setFisheyeStrength(s: Float) { fisheyeStrength = s }
    fun setBowlCurvature(c: Float) { bowlCurvature = c; bowlDirty = true }
    fun setGammaBoost(g: Float) { gammaBoost = g }

    fun getCameraDiagnostics(): String =
        "상태: ${avmController.lastStatus}\n수신 프레임: $receivedFrames\n바인딩: ${avmController.bindLog}\n--- AVMCamera 메서드 ---\n${avmController.methodDump.ifEmpty { "없음" }}"

    fun resumeCamera() { if (::surfaceTexture.isInitialized) { avmController.start(surfaceTexture); onStatus(avmController.lastStatus) } }
    fun pauseCamera() { avmController.stop() }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.02f, 0.028f, 0.043f, 1.0f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST); GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        val ids = IntArray(2); GLES30.glGenTextures(2, ids, 0)
        camTexId = ids[0]; lutTexId = ids[1]

        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTexId)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        buildFisheyeLutTexture(lutTexId)
        surfaceTexture = SurfaceTexture(camTexId).apply {
            setDefaultBufferSize(2560, 1920)
            setOnFrameAvailableListener {
                frameAvailable = true; receivedFrames++
                if (receivedFrames == 1L || receivedFrames % 60L == 0L) onStatus("LIVE AVMCamera · ${receivedFrames} frames")
            }
        }
        avmController.start(surfaceTexture); onStatus(avmController.lastStatus)

        bowlProgram = createProgram(BOWL_VS, BOWL_FS)
        carProgram = createProgram(CAR_VS, CAR_FS)
        trajProgram = createProgram(TRAJ_VS, TRAJ_FS)
        rebuildBowlMesh(); buildSculptedDolphinMesh()
    }

    private fun buildFisheyeLutTexture(texId: Int) {
        val size = 128; val buf = ByteBuffer.allocateDirect(size * size * 2)
        for (y in 0 until size) {
            val ny = (y / (size - 1f)) * 2f - 1f
            for (x in 0 until size) {
                val nx = (x / (size - 1f)) * 2f - 1f
                val r = hypot(nx.toDouble(), ny.toDouble()).toFloat()
                val scale = if (r > 0.001f) (1.0f / (1.0f + 0.36f * r * r)) else 1.0f
                buf.put((((nx * scale * 0.5f) + 0.5f).coerceIn(0f, 1f) * 255f).toInt().toByte())
                buf.put((((ny * scale * 0.5f) + 0.5f).coerceIn(0f, 1f) * 255f).toInt().toByte())
            }
        }
        buf.rewind()
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RG8, size, size, 0, GLES30.GL_RG, GLES30.GL_UNSIGNED_BYTE, buf)
    }

    private fun rebuildBowlMesh() {
        val n = 40; val size = 36f; val verts = FloatArray((n + 1) * (n + 1) * 5); var vi = 0
        for (iz in 0..n) {
            val tz = iz / n.toFloat(); val z = (tz - 0.5f) * size
            for (ix in 0..n) {
                val tx = ix / n.toFloat(); val x = (tx - 0.5f) * size
                val r = hypot(x, z); val y = if (r > 7.5f) ((r - 7.5f) * bowlCurvature).pow(2.0f) else 0f
                verts[vi++] = x; verts[vi++] = y; verts[vi++] = z; verts[vi++] = tx; verts[vi++] = tz
            }
        }
        val idx = ShortArray(n * n * 6); var ii = 0
        for (iz in 0 until n) for (ix in 0 until n) {
            val a = (iz * (n + 1) + ix).toShort(); val b = (a + 1).toShort(); val c = (a + n + 1).toShort(); val d = (c + 1).toShort()
            idx[ii++] = a; idx[ii++] = c; idx[ii++] = b; idx[ii++] = b; idx[ii++] = c; idx[ii++] = d
        }
        bowlIndexCount = idx.size
        bowlVbo = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(verts); position(0) }
        bowlIbo = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().apply { put(idx); position(0) }
        bowlDirty = false
    }

    private fun buildSculptedDolphinMesh() {
        fun pushQuad(out: MutableList<Float>, x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float) {
            val ux = x1 - x0; val uy = y1 - y0; val uz = z1 - z0
            val vx = x2 - x0; val vy = y2 - y0; val vz = z2 - z0
            var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
            val len = max(1e-5f, hypot(nx, hypot(ny, nz))); nx /= len; ny /= len; nz /= len
            fun v(x: Float, y: Float, z: Float) { out.add(x); out.add(y); out.add(z); out.add(nx); out.add(ny); out.add(nz) }
            v(x0, y0, z0); v(x1, y1, z1); v(x2, y2, z2); v(x0, y0, z0); v(x2, y2, z2); v(x3, y3, z3)
        }
        fun addBox(out: MutableList<Float>, cx: Float, cy: Float, cz: Float, w: Float, h: Float, l: Float) {
            val hw = w * 0.5f; val hh = h * 0.5f; val hl = l * 0.5f
            pushQuad(out, cx - hw, cy + hh, cz - hl, cx - hw, cy + hh, cz + hl, cx + hw, cy + hh, cz + hl, cx + hw, cy + hh, cz - hl)
            pushQuad(out, cx - hw, cy - hh, cz + hl, cx + hw, cy - hh, cz + hl, cx + hw, cy + hh, cz + hl, cx - hw, cy + hh, cz + hl)
            pushQuad(out, cx + hw, cy - hh, cz - hl, cx - hw, cy - hh, cz - hl, cx - hw, cy + hh, cz - hl, cx + hw, cy + hh, cz - hl)
            pushQuad(out, cx - hw, cy - hh, cz - hl, cx - hw, cy - hh, cz + hl, cx - hw, cy + hh, cz + hl, cx - hw, cy + hh, cz - hl)
            pushQuad(out, cx + hw, cy - hh, cz + hl, cx + hw, cy - hh, cz - hl, cx + hw, cy + hh, cz - hl, cx + hw, cy + hh, cz + hl)
        }
        val body = mutableListOf<Float>()
        addBox(body, 0f, 0.54f, 0f, 1.82f, 0.52f, 4.24f)
        pushQuad(body, -0.84f, 0.80f, -2.10f, -0.84f, 0.94f, -1.08f, 0.84f, 0.94f, -1.08f, 0.84f, 0.80f, -2.10f)
        addBox(body, -0.78f, 1.24f, 0.35f, 0.14f, 0.44f, 2.55f); addBox(body, 0.78f, 1.24f, 0.35f, 0.14f, 0.44f, 2.55f)
        addBox(body, 0f, 1.43f, 1.68f, 1.56f, 0.10f, 0.36f); addBox(body, 0f, 0.92f, 2.04f, 1.72f, 0.36f, 0.24f)
        bodyVertCount = body.size / 6
        bodyVbo = ByteBuffer.allocateDirect(body.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(body.toFloatArray()); position(0) }

        val glass = mutableListOf<Float>()
        pushQuad(glass, -0.72f, 1.46f, -0.86f, -0.72f, 1.46f, 1.46f, 0.72f, 1.46f, 1.46f, 0.72f, 1.46f, -0.86f)
        pushQuad(glass, -0.78f, 0.94f, -1.10f, -0.72f, 1.45f, -0.85f, 0.72f, 1.45f, -0.85f, 0.78f, 0.94f, -1.10f)
        pushQuad(glass, -0.72f, 1.42f, 1.48f, -0.76f, 1.06f, 1.98f, 0.76f, 1.06f, 1.98f, 0.72f, 1.42f, 1.48f)
        pushQuad(glass, -0.85f, 0.84f, -1.02f, -0.85f, 0.84f, 1.65f, -0.76f, 1.42f, 1.46f, -0.76f, 1.42f, -0.84f)
        pushQuad(glass,  0.85f, 0.84f, 1.65f,   0.85f, 0.84f, -1.02f, 0.76f, 1.42f, -0.84f, 0.76f, 1.42f, 1.46f)
        glassVertCount = glass.size / 6
        glassVbo = ByteBuffer.allocateDirect(glass.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(glass.toFloatArray()); position(0) }

        val wheels = mutableListOf<Float>()
        listOf(-0.88f to -1.36f, 0.88f to -1.36f, -0.88f to 1.36f, 0.88f to 1.36f).forEach { (wx, wz) -> addBox(wheels, wx, 0.34f, wz, 0.24f, 0.66f, 0.66f) }
        wheelVertCount = wheels.size / 6
        wheelVbo = ByteBuffer.allocateDirect(wheels.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(wheels.toFloatArray()); position(0) }

        val lights = mutableListOf<Float>(); addBox(lights, 0f, 0.82f, 2.16f, 1.64f, 0.08f, 0.05f)
        lightVertCount = lights.size / 6
        lightVbo = ByteBuffer.allocateDirect(lights.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(lights.toFloatArray()); position(0) }

        val s = floatArrayOf(-1.25f, 0.03f, -2.5f, 0f, 0f, 1.25f, 0.03f, -2.5f, 1f, 0f, 1.25f, 0.03f, 2.5f, 1f, 1f, -1.25f, 0.03f, -2.5f, 0f, 0f, 1.25f, 0.03f, 2.5f, 1f, 1f, -1.25f, 0.03f, 2.5f, 0f, 1f)
        shadowVbo = ByteBuffer.allocateDirect(s.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(s); position(0) }
        val t = floatArrayOf(-0.95f, 0.045f, -2.3f, 0f, 0f, 0.95f, 0.045f, -2.3f, 1f, 0f, 0.68f, 0.045f, -16.5f, 1f, 1f, -0.95f, 0.045f, -2.3f, 0f, 0f, 0.68f, 0.045f, -16.5f, 1f, 1f, -0.68f, 0.045f, -16.5f, 0f, 1f)
        trajVbo = ByteBuffer.allocateDirect(t.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(t); position(0) }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h); Matrix.perspectiveM(projMatrix, 0, 46f, w.toFloat() / max(1, h), 0.3f, 140f)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (bowlDirty) rebuildBowlMesh()
        if (frameAvailable) { frameAvailable = false; surfaceTexture.updateTexImage() }

        az += (tAz - az) * 0.14f; el += (tEl - el) * 0.14f; dist += (tDist - dist) * 0.14f
        val hd = dist * cos(el)
        Matrix.setLookAtM(viewMatrix, 0, sin(az) * hd, max(1.8f, dist * sin(el)), cos(az) * hd, 0f, 0.7f, -4.2f, 0f, 1f, 0f)
        Matrix.multiplyMM(mvpMatrix, 0, projMatrix, 0, viewMatrix, 0)
        val elapsedSec = (System.currentTimeMillis() - startTimeMs) / 1000f

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        GLES30.glUseProgram(bowlProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(bowlProgram, "uMvp"), 1, false, mvpMatrix, 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(bowlProgram, "uFisheye"), fisheyeStrength)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(bowlProgram, "uGamma"), gammaBoost)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uHasCam"), if (receivedFrames > 0L) 1 else 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTexId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uCamTex"), 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, lutTexId)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(bowlProgram, "uLutTex"), 1)

        val bStride = 5 * 4
        bowlVbo.position(0); GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, bStride, bowlVbo)
        bowlVbo.position(3); GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, bStride, bowlVbo)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, bowlIndexCount, GLES30.GL_UNSIGNED_SHORT, bowlIbo)

        GLES30.glUseProgram(trajProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(trajProgram, "uMvp"), 1, false, mvpMatrix, 0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(trajProgram, "uTime"), elapsedSec)
        GLES30.glDepthMask(false)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(trajProgram, "uMode"), 1)
        shadowVbo.position(0); GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 20, shadowVbo)
        shadowVbo.position(3); GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 20, shadowVbo)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(trajProgram, "uMode"), 0)
        trajVbo.position(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 20, trajVbo)
        trajVbo.position(3); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 20, trajVbo)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 6)
        GLES30.glDepthMask(true)

        GLES30.glUseProgram(carProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(carProgram, "uMvp"), 1, false, mvpMatrix, 0)
        val cStride = 6 * 4; GLES30.glEnableVertexAttribArray(0); GLES30.glEnableVertexAttribArray(1)
        fun drawPart(vbo: FloatBuffer, count: Int, r: Float, g: Float, b: Float, spec: Float, emissive: Float) {
            vbo.position(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, cStride, vbo)
            vbo.position(3); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, cStride, vbo)
            GLES30.glUniform4f(GLES30.glGetUniformLocation(carProgram, "uBaseColor"), r, g, b, 1.0f)
            GLES30.glUniform1f(GLES30.glGetUniformLocation(carProgram, "uSpec"), spec)
            GLES30.glUniform1f(GLES30.glGetUniformLocation(carProgram, "uEmissive"), emissive)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
        }
        drawPart(wheelVbo, wheelVertCount, 0.08f, 0.10f, 0.14f, 0.20f, 0.0f)
        drawPart(bodyVbo,  bodyVertCount,  0.90f, 0.93f, 0.97f, 0.55f, 0.0f)
        drawPart(glassVbo, glassVertCount, 0.04f, 0.08f, 0.15f, 0.95f, 0.0f)
        drawPart(lightVbo, lightVertCount, 1.00f, 0.12f, 0.22f, 0.10f, 1.0f)
    }

    private fun createProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int = GLES30.glCreateShader(type).also { GLES30.glShaderSource(it, src); GLES30.glCompileShader(it) }
        return GLES30.glCreateProgram().also {
            GLES30.glAttachShader(it, compile(GLES30.GL_VERTEX_SHADER, vs))
            GLES30.glAttachShader(it, compile(GLES30.GL_FRAGMENT_SHADER, fs))
            GLES30.glLinkProgram(it)
        }
    }

    companion object {
        private const val BOWL_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
out vec2 vUv;
void main() { vUv = aUv; gl_Position = uMvp * vec4(aPos, 1.0); }"""

        private const val BOWL_FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
in vec2 vUv;
uniform samplerExternalOES uCamTex;
uniform sampler2D uLutTex;
uniform float uFisheye;
uniform float uGamma;
uniform int uHasCam;
out vec4 fragColor;
vec2 sampleQuadUv(vec2 p) {
    vec2 localUv; vec2 quadOffset;
    if (abs(p.y) >= abs(p.x)) {
        if (p.y < 0.0) { localUv = vec2(p.x + 0.5, (-p.y) * 2.0); quadOffset = vec2(0.0, 0.0); }
        else           { localUv = vec2(0.5 - p.x, p.y * 2.0);    quadOffset = vec2(0.5, 0.0); }
    } else {
        if (p.x < 0.0) { localUv = vec2(p.y + 0.5, (-p.x) * 2.0); quadOffset = vec2(0.0, 0.5); }
        else           { localUv = vec2(0.5 - p.y, p.x * 2.0);    quadOffset = vec2(0.5, 0.5); }
    }
    vec2 clamped = clamp(localUv, 0.02, 0.98);
    vec2 lut = texture(uLutTex, clamped).rg;
    return quadOffset + mix(clamped, lut, uFisheye) * 0.5;
}
void main() {
    vec2 p = vUv - 0.5;
    if (uHasCam == 0) {
        float r = length(p);
        float ring = smoothstep(0.0035, 0.0, abs(fract(r * 7.0) - 0.5) - 0.488);
        float fade = smoothstep(0.52, 0.06, r);
        vec3 bg = mix(vec3(0.025, 0.036, 0.062), vec3(0.18, 0.62, 0.92), ring * 0.45 * fade);
        fragColor = vec4(bg, 1.0);
        return;
    }
    vec3 col = texture(uCamTex, sampleQuadUv(p)).rgb;
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(luma), col, 1.18);
    col = pow(clamp((col - 0.5) * 1.08 + 0.5, 0.0, 1.0), vec3(1.0 / uGamma));
    fragColor = vec4(col, 1.0);
}"""

        private const val CAR_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNorm;
uniform mat4 uMvp;
out vec3 vNorm;
void main() { vNorm = normalize(aNorm); gl_Position = uMvp * vec4(aPos, 1.0); }"""

        private const val CAR_FS = """#version 300 es
precision mediump float;
in vec3 vNorm;
uniform vec4 uBaseColor;
uniform float uSpec;
uniform float uEmissive;
out vec4 fragColor;
void main() {
    vec3 n = normalize(vNorm);
    vec3 lightDir = normalize(vec3(0.35, 0.85, 0.40));
    vec3 viewDir = normalize(vec3(0.0, 0.45, 0.88));
    float diff = max(dot(n, lightDir), 0.0);
    float spec = pow(max(dot(n, normalize(lightDir + viewDir)), 0.0), 28.0) * uSpec;
    float rim = pow(1.0 - max(dot(n, viewDir), 0.0), 2.5) * 0.25;
    vec3 col = uBaseColor.rgb * (0.38 + 0.62 * diff + uEmissive) + vec3(0.75, 0.88, 1.0) * (spec + rim);
    fragColor = vec4(col, uBaseColor.a);
}"""

        private const val TRAJ_VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUv;
uniform mat4 uMvp;
out vec2 vUv;
void main() { vUv = aUv; gl_Position = uMvp * vec4(aPos, 1.0); }"""

        private const val TRAJ_FS = """#version 300 es
precision mediump float;
in vec2 vUv;
uniform float uTime;
uniform int uMode;
out vec4 fragColor;
void main() {
    if (uMode == 1) {
        vec2 d = (vUv - 0.5) * 2.0;
        fragColor = vec4(0.0, 0.0, 0.0, smoothstep(1.0, 0.15, length(d)) * 0.68);
        return;
    }
    float edgeDist = abs(vUv.x - 0.5) * 2.0;
    float sideGlow = smoothstep(1.0, 0.72, edgeDist) * smoothstep(0.65, 0.92, edgeDist);
    float baseFill = smoothstep(1.0, 0.75, edgeDist) * 0.28;
    float fadeFar = smoothstep(1.0, 0.12, vUv.y);
    float chevronCoord = fract(vUv.y * 4.5 - uTime * 1.45 + abs(vUv.x - 0.5) * 0.75);
    float chevron = smoothstep(0.24, 0.08, abs(chevronCoord - 0.5)) * smoothstep(0.85, 0.2, edgeDist);
    vec3 col = mix(vec3(0.18, 0.68, 0.96), vec3(0.68, 0.94, 1.0), clamp(chevron + sideGlow, 0.0, 1.0));
    fragColor = vec4(col, (baseFill + sideGlow * 0.55 + chevron * 0.72) * fadeFar);
}"""
    }
}

class BydPermissionContext(base: Context) : ContextWrapper(base) {
    override fun checkCallingOrSelfPermission(permission: String): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkCallingOrSelfPermission(permission)
    override fun checkPermission(permission: String, pid: Int, uid: Int): Int =
        if (permission.contains("BYDAUTO")) PackageManager.PERMISSION_GRANTED else super.checkPermission(permission, pid, uid)
    override fun enforceCallingOrSelfPermission(permission: String, message: String?) {
        if (!permission.contains("BYDAUTO")) super.enforceCallingOrSelfPermission(permission, message)
    }
}

object NativeAutoserviceClient {
    private var binder: IBinder? = null; private var descriptor: String? = null
    fun init() {
        try {
            val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java).invoke(null, "autoservice") as? IBinder
            if (b != null) { binder = b; descriptor = b.interfaceDescriptor }
        } catch (_: Throwable) {}
    }
    fun readInt(deviceType: Int, featureId: Int): Int? {
        val b = binder ?: return null; val d = descriptor ?: return null
        val data = Parcel.obtain(); val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(d); data.writeInt(deviceType); data.writeInt(featureId)
            if (b.transact(5, data, reply, 0)) {
                val st = reply.readInt(); val v = reply.readInt()
                if (st == 0 && v != -10011 && v != 65535) v else null
            } else null
        } catch (_: Throwable) { null } finally { data.recycle(); reply.recycle() }
    }
}

object BydRealBowlBridge {
    private const val PORT = 8765
    @Volatile private var speedKmh = 0.0; @Volatile private var soc = 0.0; @Volatile private var rangeKm = 0
    @Volatile private var gear = 4; @Volatile private var turnSignal = 0
    @Volatile private var bsdLeft = false; @Volatile private var bsdRight = false
    private var speedDev: Any? = null; private var statDev: Any? = null; private var gearDev: Any? = null; private var lightDev: Any? = null; private var adasDev: Any? = null
    private var fidBsdL: Int? = null; private var fidBsdR: Int? = null; private var fidTurnL: Int? = null; private var fidTurnR: Int? = null

    @JvmStatic
    fun main(args: Array<String>) {
        val ctx = obtainSystemContext(); NativeAutoserviceClient.init()
        if (ctx != null) {
            val pctx = BydPermissionContext(ctx)
            speedDev = getInst("android.hardware.bydauto.speed.BYDAutoSpeedDevice", pctx)
            statDev  = getInst("android.hardware.bydauto.statistic.BYDAutoStatisticDevice", pctx)
            gearDev  = getInst("android.hardware.bydauto.gearbox.BYDAutoGearboxDevice", pctx)
            lightDev = getInst("android.hardware.bydauto.light.BYDAutoLightDevice", pctx)
            adasDev  = getInst("android.hardware.bydauto.adas.BYDAutoADASDevice", pctx)
            fidBsdL  = findFid("Adas",  listOf("ADAS_BSD_LEFT", "BSD_LEFT_WARN", "BSD_ALARM_LEFT"))
            fidBsdR  = findFid("Adas",  listOf("ADAS_BSD_RIGHT", "BSD_RIGHT_WARN", "BSD_ALARM_RIGHT"))
            fidTurnL = findFid("Light", listOf("LIGHT_LEFT_TURN", "LEFT_TURN_SIGNAL", "TURN_LEFT"))
            fidTurnR = findFid("Light", listOf("LIGHT_RIGHT_TURN", "RIGHT_TURN_SIGNAL", "TURN_RIGHT"))
        }
        Thread({
            while (true) {
                try {
                    speedDev?.let { (findMethod(it, "getCurrentSpeed")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..260.0) speedKmh = v } }
                    statDev?.let {
                        (findMethod(it, "getElecPercentageValue")?.invoke(it) as? Number)?.toDouble()?.let { v -> if (v in 0.0..100.0) soc = v }
                        (findMethod(it, "getElecDrivingRangeValue")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 0..1000) rangeKm = v }
                    }
                    gearDev?.let { (findMethod(it, "getGearboxAutoModeType")?.invoke(it) as? Number)?.toInt()?.let { v -> if (v in 1..4) gear = v } }
                    val tl = readProtected(lightDev, 1004, fidTurnL) ?: 0; val tr = readProtected(lightDev, 1004, fidTurnR) ?: 0
                    turnSignal = when { tl > 0 && tr == 0 -> -1; tr > 0 && tl == 0 -> 1; else -> 0 }
                    bsdLeft = (readProtected(adasDev, 1001, fidBsdL) ?: 0) > 0; bsdRight = (readProtected(adasDev, 1001, fidBsdR) ?: 0) > 0
                    Thread.sleep(50)
                } catch (_: InterruptedException) { break } catch (_: Throwable) { Thread.sleep(200) }
            }
        }, "hal-poller").apply { isDaemon = true; start() }

        val server = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
        while (true) {
            val client = server.accept()
            try {
                client.getOutputStream().use { out ->
                    val b = "{\"speedKmh\":$speedKmh,\"soc\":$soc,\"rangeKm\":$rangeKm,\"gear\":$gear,\"turnSignal\":$turnSignal,\"bsdLeft\":$bsdLeft,\"bsdRight\":$bsdRight}".toByteArray(StandardCharsets.UTF_8)
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${b.size}\r\n\r\n").toByteArray())
                    out.write(b); out.flush()
                }
            } catch (_: Throwable) {} finally { client.close() }
        }
    }

    @SuppressLint("PrivateApi")
    private fun obtainSystemContext(): Context? = try {
        if (Looper.getMainLooper() == null) Looper.prepareMainLooper()
        val at = Class.forName("android.app.ActivityThread")
        at.getMethod("getSystemContext").invoke(at.getMethod("systemMain").invoke(null)) as? Context
    } catch (_: Throwable) { null }
    private fun getInst(cn: String, ctx: Context): Any? = try { Class.forName(cn).getMethod("getInstance", Context::class.java).invoke(null, ctx) } catch (_: Throwable) { null }
    private fun findFid(nested: String, keys: List<String>): Int? = try {
        Class.forName("android.hardware.bydauto.BYDAutoFeatureIds$$nested").fields.firstOrNull { f -> val n = f.name.uppercase(); keys.any { n.contains(it) } && !n.endsWith("_SET") }?.getInt(null)
    } catch (_: Throwable) { null }
    private fun findMethod(obj: Any, name: String, vararg p: Class<*>): Method? {
        var c: Class<*>? = obj.javaClass; while (c != null) { try { return c.getDeclaredMethod(name, *p).apply { isAccessible = true } } catch (_: NoSuchMethodException) { c = c.superclass } }; return null
    }
    private fun readProtected(obj: Any?, devType: Int, fid: Int?): Int? {
        if (fid == null) return null
        if (obj != null) { try { val v = (findMethod(obj, "get", Int::class.javaPrimitiveType!!, Int::class.javaPrimitiveType!!)?.invoke(obj, devType, fid) as? Number)?.toInt(); if (v != null && v != -10011 && v != 65535) return v } catch (_: Throwable) {} }
        return NativeAutoserviceClient.readInt(devType, fid)
    }
}
