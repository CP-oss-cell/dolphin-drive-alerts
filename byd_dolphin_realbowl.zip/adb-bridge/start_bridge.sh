#!/usr/bin/env bash
set -euo pipefail
IP="${1:-192.168.10.10}"
adb connect "${IP}:5555"
adb push byd_reality_bridge.dex /data/local/tmp/byd_reality_bridge.dex
adb shell "nohup app_process -Djava.class.path=/data/local/tmp/byd_reality_bridge.dex:/system/framework/bmmcamera.jar / com.byd.dolphin.realbowl.BydRealBowlBridge >/data/local/tmp/realbowl.log 2>&1 &"
echo "Started BYD Dolphin RealBowl HAL Bridge (UID 2000). Logs: adb shell tail -f /data/local/tmp/realbowl.log"
