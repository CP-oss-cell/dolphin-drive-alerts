from pathlib import Path
from xml.etree import ElementTree
import json
import re
import subprocess

root = Path(__file__).resolve().parents[1]
for file in root.rglob('*.xml'):
    ElementTree.parse(file)
    print('XML_OK', file.relative_to(root))

source = '\n'.join(f.read_text() for f in root.rglob('*.java'))
for forbidden in ('com.google.android.gms.ads', 'com.applovin.sdk', 'com.facebook.ads.',
                  'VideoView(', 'new MediaPlayer(', 'ExoPlayer.Builder(',
                  'setAllowFileAccess(true)', 'handler.proceed()'):
    assert forbidden not in source, f'Unsupported/insecure feature: {forbidden}'

manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
# Guard the exact Android import mistake that broke v1.0.3 on GitHub CI.
assert 'import android.os.WindowInsets;' not in source, 'WindowInsets belongs to android.view'
assert 'import android.view.WindowInsets;' in source
assert 'WindowInsets.Type.systemBars()' in source
assert 'android.os.Build.VERSION.SDK_INT >= 35' in source
assert 'android.permission.INTERNET' in manifest
assert 'FOREGROUND_SERVICE_DATA_SYNC' in manifest
assert 'android:exported="false"' in manifest
assert 'usesCleartextTraffic' in manifest

main = (root / 'app/src/main/java/com/personal/cleanvideobrowser/MainActivity.java').read_text()
script = root / 'app/src/main/assets/video_scan.js'
assert script.is_file()
js = script.read_text()
assert 'MutationObserver' in js and 'PerformanceObserver' in js
assert 'CleanVideoMedia.found' in js
assert 'StorageTarget.selected(this)' in main
assert 'HlsQualityResolver.inspect' in main
assert 'VideoCandidate' in main
assert 'ACTION_OPEN_DOCUMENT_TREE' in main
subprocess.run(['node', '--check', str(script)], check=True)
print('JS_SYNTAX_OK, SECURITY_CHECKS_OK')
