/* Video detection runs inside the current webpage. It never accesses device files. */
(function () {
  if (window.__cvbScanNow) { window.__cvbScanNow(); return; }
  function send(url, source, width, height, duration, playing) {
    try {
      if (!url || /^blob:|^data:|^javascript:/i.test(url)) return;
      var resolved = new URL(url, document.baseURI);
      if (!/^https?:$/.test(resolved.protocol)) return;
      CleanVideoMedia.found(resolved.href, source, Math.round(width || 0),
        Math.round(height || 0), Math.round(isFinite(duration) ? duration : 0),
        playing ? 1 : 0, location.href);
    } catch (e) { /* inaccessible or invalid media URL */ }
  }
  function relevant(e) {
    if (!e || !e.tagName) return false;
    var r = e.getBoundingClientRect();
    return r.width >= 180 && r.height >= 100 && r.bottom > 0 && r.top < innerHeight;
  }
  function inspect(video, active) {
    var rect = video.getBoundingClientRect();
    var playing = active || (!video.paused && !video.ended && video.readyState >= 2);
    var source = playing ? 3 : 2;
    var width = video.videoWidth || rect.width || 0;
    var height = video.videoHeight || rect.height || 0;
    var length = video.duration || 0;
    if (playing && relevant(video)) {
      try { CleanVideoMedia.playerPlaying(Math.round(width), Math.round(height),
        Math.round(isFinite(length) ? length : 0), location.href); } catch (e) {}
    }
    if (playing || relevant(video)) {
      send(video.currentSrc || video.src, source, width, height, length, playing);
      video.querySelectorAll('source[src]').forEach(function (child) {
        send(child.src, source, width, height, length, playing);
      });
    }
  }
  function scan() {
    try {
      document.querySelectorAll('video').forEach(function (v) {
        if (!v.__cvbBound) {
          v.__cvbBound = true;
          ['playing', 'loadedmetadata', 'canplay'].forEach(function (ev) {
            v.addEventListener(ev, function () { inspect(v, ev === 'playing'); }, {passive:true});
          });
        }
        inspect(v, false);
      });
      performance.getEntriesByType('resource').forEach(function (r) {
        if (/\.(m3u8|mp4|m4v|mov|webm)(?:[?#]|$)/i.test(r.name))
          send(r.name, 1, 0, 0, 0, false);
      });
    } catch (e) { /* site-specific DOM */ }
  }
  window.__cvbScanNow = scan;
  scan();
  try {
    var last = 0;
    new MutationObserver(function () {
      var now = Date.now();
      if (now - last > 800) { last = now; scan(); }
    }).observe(document.documentElement, {childList:true, subtree:true, attributes:true,
      attributeFilter:['src']});
  } catch (e) {}
  try {
    new PerformanceObserver(function (entries) {
      entries.getEntries().forEach(function (r) {
        if (/\.(m3u8|mp4|m4v|mov|webm)(?:[?#]|$)/i.test(r.name))
          send(r.name, 1, 0, 0, 0, false);
      });
    }).observe({entryTypes:['resource']});
  } catch (e) {}
  setInterval(scan, 4000);
})();
