package com.personal.cleanvideobrowser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads a public HLS master manifest to offer genuine, advertised stream qualities. */
final class HlsQualityResolver {
    static final class Quality {
        final String label;
        final String url;
        final int height;
        final long bandwidth;
        Quality(String label, String url, int height, long bandwidth) {
            this.label = label; this.url = url; this.height = height; this.bandwidth = bandwidth;
        }
    }
    private HlsQualityResolver() {}

    static List<Quality> inspect(String url, String referer, String userAgent, String cookie)
            throws Exception {
        URL master = new URL(url);
        String text = load(master, referer, userAgent, cookie, master.getHost());
        List<Quality> result = new ArrayList<>();
        String attrs = null;
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                attrs = line.substring("#EXT-X-STREAM-INF:".length());
            } else if (attrs != null && !line.isEmpty() && !line.startsWith("#")) {
                long bw = valueLong(attrs, "BANDWIDTH");
                int h = 0;
                Matcher m = Pattern.compile("(?:^|,)RESOLUTION=\\d+x(\\d+)", Pattern.CASE_INSENSITIVE).matcher(attrs);
                if (m.find()) h = Integer.parseInt(m.group(1));
                String label = h > 0 ? h + "p" : "해상도 미표기";
                if (bw > 0) label += String.format(Locale.ROOT, " · %.1f Mbps", bw / 1000000.0);
                result.add(new Quality(label, new URL(master, line).toString(), h, bw));
                attrs = null;
                if (result.size() >= 40) break;
            }
        }
        result.sort((a, b) -> {
            int byHeight = Integer.compare(b.height, a.height);
            return byHeight != 0 ? byHeight : Long.compare(b.bandwidth, a.bandwidth);
        });
        if (result.isEmpty()) result.add(new Quality("원본 화질 (선택 가능한 화질 없음)", url, 0, 0));
        return result;
    }

    private static long valueLong(String attrs, String key) {
        Matcher m = Pattern.compile("(?:^|,)" + key + "=(\\d+)").matcher(attrs);
        if (m.find()) try { return Long.parseLong(m.group(1)); } catch (NumberFormatException ignored) { }
        return 0;
    }

    private static String load(URL url, String referer, String ua, String cookie, String sourceHost)
            throws Exception {
        if (!"http".equalsIgnoreCase(url.getProtocol()) && !"https".equalsIgnoreCase(url.getProtocol()))
            throw new Exception("지원되지 않는 프로토콜");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept-Encoding", "identity");
        if (ua != null && !ua.isEmpty()) c.setRequestProperty("User-Agent", ua);
        if (MediaDetector.validWebUrl(referer)) c.setRequestProperty("Referer", referer);
        if (cookie != null && url.getHost().equalsIgnoreCase(sourceHost)) c.setRequestProperty("Cookie", cookie);
        try {
            if (c.getResponseCode() != 200) throw new Exception("사이트에서 화질 정보를 제공하지 않음 (HTTP " + c.getResponseCode() + ")");
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) >= 0) {
                    if (out.size() + n > 2 * 1024 * 1024) throw new Exception("재생목록이 너무 큽니다");
                    out.write(buffer, 0, n);
                }
                String result = out.toString(StandardCharsets.UTF_8.name()).replace("\uFEFF", "");
                if (!result.trim().startsWith("#EXTM3U")) throw new Exception("HLS 재생목록 형식이 아닙니다");
                return result;
            }
        } finally { c.disconnect(); }
    }
}
