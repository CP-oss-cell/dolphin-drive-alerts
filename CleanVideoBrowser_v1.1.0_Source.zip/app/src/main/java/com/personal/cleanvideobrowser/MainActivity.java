package com.personal.cleanvideobrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.os.Build;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * A clean-room implementation: browser + video detection + downloads.
 * No advertising, analytics, bundled player, or third-party dependencies.
 */
public final class MainActivity extends Activity {
    private static final String HOME = "https://www.google.com/";
    private static final int FOLDER_PICKER = 6601;
    private String scanScript = "";
    private String pendingUrl;
    private String pendingName;
    private volatile long pageEpoch = 0;
    private boolean activeEmbeddedPlayer = false;
    private int embeddedDuration = 0;
    private LinearLayout detectedCard;
    private android.widget.TextView detectedSummary;
    private Button quickDownload;
    private Button moreVideos;
    private Button selectFolder;
    private android.widget.TextView folderLabel;
    private WebView browser;
    private EditText address;
    private ProgressBar progress;
    private View downloadsPanel;
    private View bookmarksPanel;
    private ListView downloadsList;
    private ListView bookmarksList;
    private Button tabWeb;
    private Button tabDetect;
    private Button tabDownloads;
    private Button tabBookmarks;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final LinkedHashMap<String, VideoCandidate> detected = new LinkedHashMap<>();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
                renderDownloads();
                ui.postDelayed(this, 2000);
            }
        }
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets p = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(p.left, p.top, p.right, p.bottom);
                return insets;
            });
        }
        address = findViewById(R.id.address);
        progress = findViewById(R.id.progress);
        browser = findViewById(R.id.browser);
        downloadsPanel = findViewById(R.id.downloads_panel);
        bookmarksPanel = findViewById(R.id.bookmarks_panel);
        downloadsList = findViewById(R.id.downloads_list);
        bookmarksList = findViewById(R.id.bookmarks_list);
        detectedCard = findViewById(R.id.detected_card);
        detectedSummary = findViewById(R.id.detected_summary);
        quickDownload = findViewById(R.id.quick_download);
        moreVideos = findViewById(R.id.more_videos);
        selectFolder = findViewById(R.id.select_folder);
        folderLabel = findViewById(R.id.folder_label);
        try (InputStream in = getAssets().open("video_scan.js")) {
            ByteArrayOutputStream data = new ByteArrayOutputStream();
            byte[] bytes = new byte[4096];
            int n;
            while ((n = in.read(bytes)) != -1) data.write(bytes, 0, n);
            scanScript = new String(data.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { toast("영상 감지 모듈을 불러오지 못했습니다"); }
        quickDownload.setOnClickListener(v -> {
            VideoCandidate top = bestCandidate();
            if (top != null) offerDownload(top.url, friendlyName(top.url));
            else showVideos();
        });
        moreVideos.setOnClickListener(v -> showVideos());
        selectFolder.setOnClickListener(v -> chooseFolder());
        findViewById(R.id.reset_folder).setOnClickListener(v -> {
            StorageTarget.reset(this);
            refreshFolderLabel();
            toast("기본 다운로드 폴더를 사용합니다");
        });
        refreshFolderLabel();
        tabWeb = findViewById(R.id.tab_web);
        tabDetect = findViewById(R.id.tab_detect);
        tabDownloads = findViewById(R.id.tab_downloads);
        tabBookmarks = findViewById(R.id.tab_bookmarks);

        configureBrowser();
        findViewById(R.id.back).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoBack()) browser.goBack();
        });
        findViewById(R.id.forward).setOnClickListener(v -> {
            showPanel("web");
            if (browser.canGoForward()) browser.goForward();
        });
        findViewById(R.id.go).setOnClickListener(v -> navigate());
        findViewById(R.id.go).setOnLongClickListener(v -> { browser.reload(); return true; });
        findViewById(R.id.star).setOnClickListener(v -> {
            if (MediaDetector.validWebUrl(browser.getUrl())) {
                Bookmarks.add(this, browser.getTitle(), browser.getUrl());
                toast("즐겨찾기에 저장했습니다");
            }
        });
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate();
                return true;
            }
            return false;
        });
        tabWeb.setOnClickListener(v -> showPanel("web"));
        tabWeb.setOnLongClickListener(v -> { showPanel("web"); browser.loadUrl(HOME); return true; });
        tabDetect.setOnClickListener(v -> {
            showPanel("web");
            runScan();
            ui.postDelayed(this::showVideos, 350);
        });
        tabDownloads.setOnClickListener(v -> showPanel("downloads"));
        tabBookmarks.setOnClickListener(v -> showPanel("bookmarks"));
        findViewById(R.id.reload_downloads).setOnClickListener(v -> renderDownloads());
        findViewById(R.id.open_folder).setOnClickListener(v -> {
            String tree = StorageTarget.selected(this);
            if (!tree.isEmpty()) {
                try {
                    Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(tree));
                    open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(open);
                    return;
                } catch (Exception ignored) { }
            }
            try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
            catch (Exception e) { toast("내 파일 앱에서 저장 위치를 확인하세요"); }
        });
        bookmarksList.setOnItemClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                showPanel("web");
                browser.loadUrl(list.get(position).optString("url"));
            }
        });
        bookmarksList.setOnItemLongClickListener((parent, view, position, id) -> {
            List<JSONObject> list = Bookmarks.all(this);
            if (position < list.size()) {
                JSONObject target = list.get(position);
                new AlertDialog.Builder(this).setTitle("즐겨찾기 삭제")
                        .setMessage(target.optString("title"))
                        .setPositiveButton("삭제", (d, w) -> {
                            Bookmarks.remove(this, target.optString("url"));
                            renderBookmarks();
                        }).setNegativeButton("취소", null).show();
            }
            return true;
        });
        showPanel("web");
        if (saved == null) browser.loadUrl(HOME);
        else browser.restoreState(saved);
    }

    private void configureBrowser() {
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true); // Needed by most modern websites.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);
        browser.addJavascriptInterface(new MediaBridge(), "CleanVideoMedia");
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int percent) {
                progress.setProgress(percent);
                progress.setVisibility(percent >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                pageEpoch++;
                detected.clear();
                activeEmbeddedPlayer = false;
                embeddedDuration = 0;
                refreshCandidates();
                address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                address.setText(url);
                runScan();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (AdBlock.blocked(uri)) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                String url = uri.toString();
                if (MediaDetector.looksLikeVideo(url)) {
                    addVideo(url, 1, 0, 0, 0, false, null, pageEpoch);
                }
                return null;
            }
            @Override public void onReceivedSslError(WebView view,
                                                      SslErrorHandler handler, SslError error) {
                handler.cancel(); // Never let invalid certificates through.
                runOnUiThread(() -> toast("안전하지 않은 연결을 차단했습니다"));
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   WebResourceError error) {
                if (request.isForMainFrame()) {
                    runOnUiThread(() -> toast("웹페이지를 열 수 없습니다"));
                }
            }
        });
        browser.setDownloadListener((url, userAgent, contentDisposition, mimeType, length) -> {
            if (MediaDetector.validWebUrl(url)) {
                offerDownload(url, MediaDetector.guessName(url, contentDisposition, mimeType));
            } else {
                toast("이 다운로드 주소는 지원하지 않습니다");
            }
        });
    }

    /** The web-page bridge can only report media URLs and metadata; no device-file methods. */
    private final class MediaBridge {
        @JavascriptInterface public void found(String url, int source, int width, int height,
                                                int duration, int playing, String page) {
            addVideo(url, source, width, height, duration, playing != 0, page, pageEpoch);
        }
        @JavascriptInterface public void playerPlaying(int width, int height,
                                                       int duration, String page) {
            final long epoch = pageEpoch;
            ui.post(() -> {
                if (isDestroyed() || epoch != pageEpoch || !samePageHost(page)) return;
                if (width >= 160 && height >= 90) {
                    activeEmbeddedPlayer = true;
                    embeddedDuration = Math.max(embeddedDuration, duration);
                    for (VideoCandidate c : detected.values()) {
                        if (MediaDetector.isHls(c.url) && c.source == 1)
                            c.observe(3, width, height, duration, true, null);
                    }
                    refreshCandidates();
                }
            });
        }
    }

    private void runScan() {
        if (!scanScript.isEmpty() && browser != null) browser.evaluateJavascript(scanScript, null);
    }

    private void addVideo(String url, int source, int width, int height, int duration,
                          boolean playing, String page, long epoch) {
        if (!MediaDetector.validWebUrl(url) || MediaDetector.adLike(url)
                || (source <= 1 && !MediaDetector.looksLikeVideo(url))) return;
        ui.post(() -> {
            if (isFinishing() || isDestroyed() || epoch != pageEpoch) return;
            if (page != null && !samePageHost(page)) return;
            VideoCandidate candidate = detected.get(url);
            if (candidate == null) {
                if (detected.size() >= 90) return;
                candidate = new VideoCandidate(url);
                detected.put(url, candidate);
            }
            Uri pageUri = Uri.parse(browser.getUrl() == null ? HOME : browser.getUrl());
            candidate.observe(source, width, height, duration, playing, pageUri.getHost());
            if (activeEmbeddedPlayer && source == 1 && MediaDetector.isHls(url))
                candidate.observe(3, 480, 270, embeddedDuration, true, pageUri.getHost());
            refreshCandidates();
        });
    }

    private boolean samePageHost(String page) {
        if (!MediaDetector.validWebUrl(page)) return false;
        String current = browser.getUrl();
        if (!MediaDetector.validWebUrl(current)) return false;
        String first = Uri.parse(page).getHost();
        String second = Uri.parse(current).getHost();
        return first != null && first.equalsIgnoreCase(second);
    }

    private List<VideoCandidate> rankedCandidates() {
        List<VideoCandidate> list = new ArrayList<>();
        for (VideoCandidate c : detected.values()) if (c.allowed()) list.add(c);
        list.sort((a, b) -> Integer.compare(b.score(), a.score()));
        return list;
    }

    private VideoCandidate bestCandidate() {
        List<VideoCandidate> items = rankedCandidates();
        return !items.isEmpty() && items.get(0).recommended() ? items.get(0) : null;
    }

    private void refreshCandidates() {
        List<VideoCandidate> list = rankedCandidates();
        VideoCandidate best = !list.isEmpty() && list.get(0).recommended() ? list.get(0) : null;
        int good = 0;
        for (VideoCandidate item : list) if (item.recommended()) good++;
        tabDetect.setText(good == 0 ? "영상 찾기" : "영상 찾기 (" + good + ")");
        detectedCard.setVisibility(best == null ? View.GONE : View.VISIBLE);
        if (best != null) {
            String title = browser.getTitle();
            if (title == null || title.trim().isEmpty()) title = "현재 페이지";
            if (title.length() > 24) title = title.substring(0, 24) + "…";
            detectedSummary.setText((best.active ? "재생 중인 영상" : "본편 추정 영상")
                    + " · " + best.qualityLabel() + "\n" + title);
            moreVideos.setVisibility(good > 1 ? View.VISIBLE : View.GONE);
        }
    }

    private String friendlyName(String url) {
        String title = browser.getTitle();
        if (title == null || title.trim().isEmpty()) title = "영상";
        String name = DownloadStore.safeFileName(title);
        if (name.length() > 65) name = name.substring(0, 65);
        String path = Uri.parse(url).getPath();
        String ext = ".mp4";
        if (path != null) {
            String lower = path.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".webm")) ext = ".webm";
            else if (lower.endsWith(".mov")) ext = ".mov";
            else if (lower.endsWith(".m4v")) ext = ".m4v";
        }
        return name + (MediaDetector.isHls(url) ? ".ts" : ext);
    }

    private void showVideos() {
        List<VideoCandidate> all = rankedCandidates();
        List<VideoCandidate> list = new ArrayList<>();
        for (VideoCandidate c : all) if (c.recommended()) list.add(c);
        if (list.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("현재 영상이 확인되지 않았습니다")
                .setMessage("사이트에서 원하는 영상을 재생한 뒤 '영상 찾기'를 다시 눌러주세요. "
                    + "광고 영상으로 추정되는 주소는 숨겼습니다. 보호된 스트리밍은 감지되지 않을 수 있습니다.")
                .setPositiveButton("다시 찾기", (d,w) -> runScan())
                .setNeutralButton(all.isEmpty() ? "주소 직접 입력" : "기타 영상 후보 (주의)",
                    (d,w) -> {
                        if (all.isEmpty()) enterDownloadUrl();
                        else showLowConfidence(all);
                    })
                .setNegativeButton("닫기", null).show();
            return;
        }
        // Only surface a few high-confidence results; don't dump ad/network resource URLs.
        if (list.size() > 8) list = new ArrayList<>(list.subList(0, 8));
        final List<VideoCandidate> choices = list;
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            VideoCandidate c = choices.get(i);
            Uri uri = Uri.parse(c.url);
            labels[i] = (c.active ? "▶ 재생 중" : "영상 후보") + " · "
                    + c.qualityLabel() + " · " + (MediaDetector.isHls(c.url) ? "HLS" : "파일")
                    + "\n" + uri.getHost();
        }
        new AlertDialog.Builder(this).setTitle("본편으로 추정되는 영상 " + choices.size() + "개")
            .setItems(labels, (d, which) -> {
                String url = choices.get(which).url;
                offerDownload(url, friendlyName(url));
            })
            .setNeutralButton("주소 직접 입력", (d, w) -> enterDownloadUrl())
            .setNegativeButton("닫기", null).show();
    }

    private void showLowConfidence(List<VideoCandidate> all) {
        int max = Math.min(5, all.size());
        String[] labels = new String[max];
        for (int i = 0; i < max; i++) {
            VideoCandidate c = all.get(i);
            labels[i] = "확인되지 않은 영상 · " + c.qualityLabel()
                + "\n" + Uri.parse(c.url).getHost();
        }
        new AlertDialog.Builder(this).setTitle("기타 후보 · 광고 영상 포함 가능")
            .setItems(labels, (d, index) -> {
                String url = all.get(index).url;
                offerDownload(url, friendlyName(url));
            })
            .setNegativeButton("닫기", null).show();
    }

    private void chooseFolder() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, FOLDER_PICKER);
        } catch (Exception e) { toast("폴더 선택기를 실행할 수 없습니다"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FOLDER_PICKER && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                StorageTarget.choose(this, tree);
                refreshFolderLabel();
                toast("저장 폴더를 변경했습니다");
            } catch (SecurityException e) {
                toast("선택한 폴더의 쓰기 권한을 얻지 못했습니다");
            }
        }
        if (requestCode == FOLDER_PICKER && pendingUrl != null) {
            String url = pendingUrl, name = pendingName;
            pendingUrl = null; pendingName = null;
            if (resultCode == RESULT_OK) offerDownload(url, name);
        }
    }

    private void refreshFolderLabel() {
        folderLabel.setText("저장 위치: " + StorageTarget.display(this));
    }

    private void enterDownloadUrl() {
        EditText text = new EditText(this);
        text.setSingleLine(false);
        text.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        text.setHint("https://example.com/video.mp4");
        text.setPadding(32, 20, 32, 20);
        new AlertDialog.Builder(this).setTitle("동영상 주소 붙여넣기")
                .setView(text)
                .setPositiveButton("다음", (d, w) -> {
                    String url = text.getText().toString().trim();
                    if (MediaDetector.validWebUrl(url))
                        offerDownload(url, MediaDetector.guessName(url, null, null));
                    else toast("http:// 또는 https:// 주소를 입력하세요");
                })
                .setNegativeButton("취소", null).show();
    }

    private void offerDownload(String url, String suggestedName) {
        if (!MediaDetector.validWebUrl(url)) { toast("다운로드 주소 오류"); return; }
        boolean hls = MediaDetector.isHls(url);
        EditText nameBox = new EditText(this);
        nameBox.setSingleLine(true);
        nameBox.setText(suggestedName);
        nameBox.setSelectAllOnFocus(true);
        nameBox.setPadding(32, 24, 32, 24);
        new AlertDialog.Builder(this).setTitle(hls ? "영상 저장 · 화질 선택" : "영상 다운로드")
            .setMessage("저장 위치: " + StorageTarget.display(this)
                + (hls ? "\n실제 제공되는 화질을 다음 화면에서 선택합니다." :
                    "\nMP4 파일은 사이트에서 제공하는 원본 화질로 저장합니다."))
            .setView(nameBox)
            .setPositiveButton(hls ? "화질 선택" : "다운로드", (d, w) -> {
                String name = DownloadStore.safeFileName(nameBox.getText().toString());
                if (hls) {
                    int dot = name.lastIndexOf('.');
                    name = (dot > 0 ? name.substring(0, dot) : name) + ".ts";
                    chooseHlsQuality(url, name);
                } else downloadDirect(url, name);
            })
            .setNeutralButton("폴더 선택", (d, w) -> {
                pendingUrl = url;
                pendingName = DownloadStore.safeFileName(nameBox.getText().toString());
                chooseFolder();
            })
            .setNegativeButton("취소", null).show();
    }

    private void chooseHlsQuality(String url, String filename) {
        final String referer = browser.getUrl();
        final String ua = browser.getSettings().getUserAgentString();
        final String cookie = CookieManager.getInstance().getCookie(url);
        final AlertDialog loading = new AlertDialog.Builder(this)
                .setTitle("화질 확인 중")
                .setMessage("영상 사이트가 제공하는 화질을 확인합니다…")
                .setNegativeButton("취소", null).create();
        loading.show();
        new Thread(() -> {
            List<HlsQualityResolver.Quality> qualities = null;
            String error = null;
            try { qualities = HlsQualityResolver.inspect(url, referer, ua, cookie); }
            catch (Exception e) { error = e.getMessage(); }
            final List<HlsQualityResolver.Quality> options = qualities;
            final String reason = error;
            ui.post(() -> {
                if (isDestroyed() || isFinishing() || !loading.isShowing()) return;
                loading.dismiss();
                if (reason != null) {
                    new AlertDialog.Builder(this).setTitle("화질 정보를 확인하지 못했습니다")
                        .setMessage(reason + "\n원본 영상 주소로 다운로드를 시도할 수 있습니다.")
                        .setPositiveButton("원본으로 시도", (d,w) -> startHlsDownload(url, filename))
                        .setNegativeButton("취소", null).show();
                    return;
                }
                String[] labels = new String[options.size()];
                for (int i=0; i < options.size(); i++) labels[i] = options.get(i).label;
                new AlertDialog.Builder(this).setTitle("영상 화질 선택")
                    .setSingleChoiceItems(labels, 0, (dialog, which) -> {
                        dialog.dismiss();
                        startHlsDownload(options.get(which).url, filename);
                    })
                    .setNegativeButton("취소", null).show();
            });
        }, "HlsQualityInspect").start();
    }

    private void startHlsDownload(String url, String filename) {
        startServiceDownload(url, filename, "hls");
    }

    private void startServiceDownload(String url, String filename, String mode) {
        String id = mode + "-" + UUID.randomUUID();
        DownloadStore.add(this, id, "service-" + mode, filename);
        Intent intent = new Intent(this, HlsDownloadService.class);
        intent.putExtra("id", id);
        intent.putExtra("mode", mode);
        intent.putExtra("url", url);
        intent.putExtra("filename", filename);
        intent.putExtra("folder", StorageTarget.selected(this));
        intent.putExtra("referer", browser.getUrl());
        intent.putExtra("ua", browser.getSettings().getUserAgentString());
        intent.putExtra("cookie", CookieManager.getInstance().getCookie(url));
        try {
            startForegroundService(intent);
            toast("다운로드를 시작했습니다");
        } catch (Exception e) {
            DownloadStore.update(this, id, "실패: 다운로드 서비스 시작 오류", 0);
            toast("다운로드를 시작할 수 없습니다");
        }
    }

    private void downloadDirect(String url, String filename) {
        if (!StorageTarget.selected(this).isEmpty()) {
            startServiceDownload(url, filename, "direct");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(filename);
            request.setDescription("CleanVideo Browser");
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS + "/CleanVideo", filename);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null && !cookie.isEmpty()) request.addRequestHeader("Cookie", cookie);
            request.addRequestHeader("User-Agent", browser.getSettings().getUserAgentString());
            if (MediaDetector.validWebUrl(browser.getUrl()))
                request.addRequestHeader("Referer", browser.getUrl());
            if (filename.toLowerCase(Locale.ROOT).endsWith(".mp4"))
                request.setMimeType("video/mp4");
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            DownloadStore.add(this, String.valueOf(id), "direct", filename);
            toast("다운로드를 시작했습니다");
        } catch (Exception e) {
            toast("다운로드 실패: " + e.getClass().getSimpleName());
        }
    }

    private void navigate() {
        String input = address.getText().toString().trim();
        if (input.isEmpty()) return;
        String url;
        if (MediaDetector.validWebUrl(input)) url = input;
        else if (input.matches("(?i)^[^\\s]+\\.[a-z]{2,}([/:?].*)?$")) url = "https://" + input;
        else url = "https://www.google.com/search?q=" + Uri.encode(input);
        showPanel("web");
        browser.loadUrl(url);
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
    }

    private void showPanel(String name) {
        boolean download = "downloads".equals(name);
        boolean bookmark = "bookmarks".equals(name);
        downloadsPanel.setVisibility(download ? View.VISIBLE : View.GONE);
        bookmarksPanel.setVisibility(bookmark ? View.VISIBLE : View.GONE);
        browser.setVisibility(!download && !bookmark ? View.VISIBLE : View.GONE);
        if (!download && !bookmark) refreshCandidates();
        else detectedCard.setVisibility(View.GONE);
        if (download) refreshFolderLabel();
        tabWeb.setTextColor(!download && !bookmark ? 0xff1357b5 : 0xff303030);
        tabDownloads.setTextColor(download ? 0xff1357b5 : 0xff303030);
        tabBookmarks.setTextColor(bookmark ? 0xff1357b5 : 0xff303030);
        tabDetect.setTextColor(0xff303030);
        ui.removeCallbacks(tick);
        if (download) { renderDownloads(); ui.postDelayed(tick, 2000); }
        if (bookmark) renderBookmarks();
    }

    private void renderBookmarks() {
        List<String> labels = new ArrayList<>();
        for (JSONObject item : Bookmarks.all(this)) {
            labels.add(item.optString("title") + "\n" + item.optString("url"));
        }
        if (labels.isEmpty()) labels.add("즐겨찾기가 없습니다. 웹사이트에서 ☆ 버튼을 누르세요.");
        bookmarksList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void renderDownloads() {
        List<String> labels = new ArrayList<>();
        DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        for (JSONObject entry : DownloadStore.list(this)) {
            String id = entry.optString("id");
            String status = entry.optString("status", "대기 중");
            int percent = entry.optInt("progress", 0);
            if ("direct".equals(entry.optString("type"))) {
                try {
                    long number = Long.parseLong(id);
                    try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(number))) {
                        if (cursor != null && cursor.moveToFirst()) {
                            int raw = cursor.getInt(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_STATUS));
                            long total = cursor.getLong(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                            long done = cursor.getLong(cursor.getColumnIndexOrThrow(
                                    DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                            percent = total > 0 ? (int) (done * 100 / total) : 0;
                            if (raw == DownloadManager.STATUS_SUCCESSFUL) { status = "완료"; percent = 100; }
                            else if (raw == DownloadManager.STATUS_RUNNING) status = "다운로드 중";
                            else if (raw == DownloadManager.STATUS_PAUSED) status = "일시 대기 (네트워크 등)";
                            else if (raw == DownloadManager.STATUS_FAILED) status = "실패";
                            else status = "대기 중";
                        } else status = "시스템에서 다운로드 내역을 찾을 수 없음";
                    }
                } catch (Exception ignored) { status = "상태 확인 실패"; }
            }
            labels.add(entry.optString("name") + "\n" + status + " · " + percent + "%");
        }
        if (labels.isEmpty()) labels.add("다운로드 기록이 없습니다. '영상 찾기'를 눌러 시작하세요.");
        downloadsList.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_SHORT).show(); }

    @Override public void onBackPressed() {
        if (downloadsPanel.getVisibility() == View.VISIBLE
                || bookmarksPanel.getVisibility() == View.VISIBLE) showPanel("web");
        else if (browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
        browser.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (browser != null) browser.onResume();
        if (downloadsPanel != null && downloadsPanel.getVisibility() == View.VISIBLE) {
            ui.removeCallbacks(tick);
            renderDownloads();
            ui.postDelayed(tick, 2000);
        }
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        browser.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (browser != null) {
            browser.stopLoading();
            browser.setWebChromeClient(null);
            browser.setWebViewClient(null);
            browser.destroy();
        }
        super.onDestroy();
    }
}
