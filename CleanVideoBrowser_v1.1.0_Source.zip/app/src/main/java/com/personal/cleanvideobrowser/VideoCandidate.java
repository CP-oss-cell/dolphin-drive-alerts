package com.personal.cleanvideobrowser;

import android.net.Uri;
import java.util.Locale;

/** Confidence estimate, not a claim of perfect ad/main-video identification. */
final class VideoCandidate {
    final String url;
    private int score;
    int width, height, duration;
    boolean active;
    int source;
    VideoCandidate(String url) { this.url = url; }

    void observe(int source, int width, int height, int duration, boolean active, String pageHost) {
        this.source = Math.max(this.source, source);
        this.active |= active;
        this.width = Math.max(this.width, width);
        this.height = Math.max(this.height, height);
        this.duration = Math.max(this.duration, duration);
        int points = this.source == 3 ? 90 : this.source == 2 ? 65 : 25;
        if (this.active) points += 50;
        if (this.width >= 480 && this.height >= 270) points += 18;
        if (this.duration >= 60) points += 18;
        if (this.duration >= 600) points += 7;
        // Short auto-playing clips are frequently pre-roll ads; hide them by default.
        if (this.duration > 0 && this.duration < 45) points -= 125;
        else if (this.duration >= 45 && this.duration < 90) points -= 25;
        else if (this.duration == 0 && this.source == 2 && !this.active) points -= 25;
        Uri uri = Uri.parse(url);
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
        if (pageHost != null && host.equalsIgnoreCase(pageHost)) points += 6;
        if (MediaDetector.adLike(url)) points -= 200;
        if (path.contains("thumbnail") || path.contains("preview") || path.contains("teaser")) points -= 70;
        score = points;
    }

    int score() { return score; }
    boolean recommended() { return score >= 65; }
    boolean allowed() { return score >= 25 && !MediaDetector.adLike(url); }
    String qualityLabel() {
        if (height >= 360) return height + "p";
        String p = Uri.parse(url).getPath();
        if (p != null) {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?i)(?:^|[^\\d])(2160|1440|1080|720|480|360)p(?:[^\\d]|$)")
                    .matcher(p);
            if (m.find()) return m.group(1) + "p (주소 기준)";
        }
        return "화질 미확인";
    }
}
