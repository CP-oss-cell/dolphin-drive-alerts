"""New v2.1.4 regression. Structural only; never claimed as an APK/device test."""
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
java = (root/'app/src/main/java/com/mideumhana/browser/MainActivity.java').read_text()
layout = (root/'app/src/main/res/layout/activity_main.xml').read_text()
build = (root/'app/build.gradle').read_text()
xml = ET.fromstring(layout)
ns = '{http://schemas.android.com/apk/res/android}'
ids = {element.get(ns+'id'): element for element in xml.iter() if element.get(ns+'id')}
for name in ('quick_tabs_scroll', 'quick_tabs_strip', 'open_tabs', 'new_web_tab', 'settings_menu'):
    assert '@+id/'+name in ids, name
scroll = ids['@+id/quick_tabs_scroll']
assert scroll.tag == 'HorizontalScrollView'
assert scroll.get(ns+'layout_weight') == '1'
assert ids['@+id/quick_tabs_strip'].tag == 'LinearLayout'
assert 'android:horizontalScrollBarEnabled' not in layout  # Previous AAPT regression
assert 'String number' not in java
for key in ('renderWebTabs()', 'button.setText("탭 " + number)',
            'button.setOnClickListener(v -> activateTab(tab))',
            'button.setOnLongClickListener(v -> { confirmCloseQuickTab(tab); return true; })',
            'handleWebLongPress(web)', 'setOnLongClickListener(v -> handleWebLongPress(web))',
            'WebView.HitTestResult.SRC_ANCHOR_TYPE', 'WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE',
            'requestFocusNodeHref(handler.obtainMessage(1))', 'details.getString("title")',
            'details.getString("url")', 'ClipboardManager', 'ClipData.newPlainText',
            '"링크 텍스트 복사"', '"링크 복사"', '"새 탭에서 열기"',
            '"배경 탭에서 열기"', '"링크 공유"', '"이미지 주소 복사"',
            "return false;\n    }\n\n    private void showLongPressResourceMenu"):
    assert key in java, key
assert 'openNewWebTab(href, true)' in java and 'openNewWebTab(href, false)' in java
assert 'MediaDetector.validWebUrl(url)' in java
assert "applicationId 'com.mideumhana.browser'" in build
assert "versionName '2.1.4'" in build and 'versionCode 10' in build
print('V212_LINK_CONTEXT_AND_QUICK_TABS_STATIC_OK')
