from pathlib import Path
root=Path(__file__).resolve().parents[1]
b=(root/'app/build.gradle').read_text()
assert "versionCode 10" in b and "versionName '2.1.4'" in b
assert 'signingConfig signingConfigs.mhbRelease' not in b
assert 'MHB_SIGNING_PASSWORD' not in b
assert 'debuggable true' in b
print('V213_NO_SECRETS_DEBUG_BUILD_STATIC_OK')
