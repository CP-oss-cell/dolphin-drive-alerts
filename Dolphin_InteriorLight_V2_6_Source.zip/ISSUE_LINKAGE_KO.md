# V2.6 이슈 연계 · 실내등 ON/OFF

- IL-UI-001 (SOURCE_PATCHED, REALCAR_REVERIFY_REQUIRED): 복잡한 전문 후보·경로 UI 대신 4단계 단일 화면. 사용자의 요청으로 공통 표준화.
- IL-AUTO-002 (SOURCE_PATCHED, REALCAR_REVERIFY_REQUIRED): 권한 메타데이터, SystemUI 후보, CarSettings, 미리 정의된 4 Getter의 안전한 읽기 자동 실행. 실제 Getter 시도 0/4를 분리 기록.
- IL-EXPORT-003 (SOURCE_PATCHED, REALCAR_REVERIFY_REQUIRED): 종료 시 ZIP 4파일 생성, 내부 보존, Android 10 Downloads MediaStore 저장 및 content:// 공유.
- IL-OEM-004 (BLOCKED_BY_SIGNATURE_PERMISSION): 기존 실차에서는 COMMON 미허용, GET/SET 서명 미허용. 제어 성공 판단/제조사 권한 우회 금지. 조건부 명시 승인 단발성 후보만 유지.
- IL-BUILD-005 (NOT_CI_BUILT): Gradle Android APK 컴파일/차량 설치/권한창/ZIP 공유 미검증. GitHub Actions 실행과 실차 결과 필요.
- IL-WATCHDOG-006 (SOURCE_PATCHED, REALCAR_REVERIFY_REQUIRED): 15초 경과 알림, 중단 결과를 미완료로 기록하며 재진입 차단. 스레드 지연 호출의 취소를 주장하지 않는다.

기존 연계: DA-004 권한, DA-013 Actions, DA-025 쓰기 안전, DA-029 로그 중복·실측 수치 정확도.

근거 원본은 `/개발앱 4종 연구/실내등 전체 소등 ON_OFF/실차원본_Dolphin_InteriorLight_20261018_V23.json`과 V2.4 통합팩. V2.6 신규 실차 성공 건은 없음.


## 2026-10-21 V2.6 업데이트
- IL-OEM-004: `SIGNATURE_GET_NOT_GRANTED`, 제어 `BLOCKED_BY_SIGNATURE_SET`; 읽기 호출 생략 경로 소스 반영. 물리 기능은 아직 **UNVERIFIED**.
- IL-AUTO-002: 12건의 동일 권한 예외를 반복하지 않도록 실제 호출/생략 횟수를 분리.
- IL-UI-001: 제어 경로 인증 전까지 버튼 잠금. 기본 4단계 UI 유지.
- IL-EXPORT-003: ZIP 필드 확장; V2.6 실차 다운로드/공유 동작은 아직 검증되지 않음.
- IL-BUILD-005: 본 빌드팩은 소스 후보. GitHub Actions / APK / 새 실차 실행 확인 전까지 VERIFIED로 승격하지 않음.
- 기존 DA-004/DA-029 및 APP4-R006/R007 연구와 링크되며 신규 중복 이슈 생성 금지.
