# BYD 돌핀 실내등 전체 소등 ON/OFF 연구 앱 V2.6

2026-10-18 · 독립 앱 `com.dolphin.insidelightprobe` · Android 10 / 한국형 돌핀 스탠다드 기준

## 사용법 — 화면에서 네 단계만 진행

1. **로그 수집 시작**: 새 검사 세션을 시작한다. 기존 V2.4 기록이 남아 있으면 덮어쓰기 전 알림을 표시한다.
2. **자동 테스트 시작**: 후보 패키지/OEM 메서드를 재검색하고 COMMON·GET·SET 권한과 보호 등급을 검사한다. `insight_light_online`을 읽고, COMMON이 허용된 경우에 한해 미리 정해진 Getter 4개를 순차 조회한다. 이 과정에는 실내등 제어 요청이 전혀 없다.
3. **직접 해야 하는 수동 테스트**: 안전한 정차/P단/주차 브레이크 확인; 필요하면 Android 공식 COMMON 권한 허용창에서 사용자 직접 승인; 순정 실내등 스위치로 소등/점등 확인 후 한 줄 결과 선택. 모든 조작은 차량 자체에서 수동으로 한다. OEM 제어 후보 버튼은 **COMMON과 SET이 모두 실제 부여**된 경우에만 보이며, 사용자의 추가 동의 없이는 실행되지 않는다. 이 후보는 아직 실차 미검증이다.
4. **수집 종료 · ZIP 자동 저장**: `다운로드/DolphinLightLogs/Dolphin_InteriorLight_YYYYMMDD_HHMMSS.zip` 생성 후 공유 버튼 제공. 저장 실패 시 앱 내부에 ZIP을 남기고 공유할 수 있도록 한다.

ZIP 내용: `report.json`(원본 이벤트 및 권한·스캔 정보), `summary_ko.txt`(핵심 결과), `manual_steps_ko.txt`(직접 확인 안내), `manifest.json`(SHA-256 검증값 및 판정 상태).

## V2.4 → V2.6 변경

- 후보 메서드·컴포넌트 목록·4단계 전문 메뉴를 **기본 UI에서 제거**하고 동일한 한 화면에 4개 기본 행동만 남김.
- 백그라운드 읽기 자동화를 새로 추가. 읽기 0/4와 실제 호출/반환 수를 정확히 구분.
- OEM 응답이 15초 이상 늦으면 중복 호출을 막고 사용자 중단/미완료 기록 및 ZIP 보존을 지원.
- 시작~종료 세션 상태 및 검사 결과를 앱 설정에 보존. Android 10 `MediaStore.Downloads`를 통한 ZIP 기록 및 URI 부여 기반 ZIP 공유.
- 패키지 ID와 SharedPreferences 키 `dolphin_wizard_v2`는 그대로 유지. `versionCode=7`.

## 꼭 알아야 할 실제 제한

- 기존 V2.3 실차 로그에서 `BYDAUTO_SETTING_COMMON` 미허용, `BYDAUTO_SETTING_GET/SET`은 서명 보호/미허용. `insight_light_online=0` 읽기 성공만 확보. `isCanFd`는 미확인.
- **ON/OFF 실물 동작은 아직 구현 완료/검증 성공이 아니다.** 소스에는 `turnOffInsideLight(1)` / `(2)` 후보를 유지했지만 권한 확인+정차 수동 확인+동의 없이 실행하지 않는다.
- 표면 API의 존재나 정상 반환값은 실내등이 실제 켜지고 꺼졌다는 증거가 아니다.
- ROOT, ADB, CAN/SPI 전송, 시스템 설정 쓰기, 서명 우회, 인터넷 전송 없음.
- 자동 테스트의 '검색'은 앱에서 접근할 수 있는 패키지/리플렉션/설정 조회 범위로 제한되며 모든 OEM 내부 경로에 접근한다는 의미가 아니다.
- 프로젝트 내 오래된 탐색 함수는 구현 참고용으로 남겨두었으나 일반 화면에서는 호출할 수 없다.

## GitHub Actions 빌드

1. 통합팩에 포함된 `Dolphin_InteriorLight_V2_6_Source.zip`을 **압축 해제하지 말고** GitHub 저장소 최상위에 업로드.
2. 별도 제공된 `.github/workflows/build-apk.yml`을 정확한 경로에 업로드.
3. 저장소 `Actions` → `Build Dolphin Interior Light V2.6 One Screen ZIP Diagnostic` → `Run workflow`.
4. 성공한 실행의 Artifact `Dolphin-InteriorLight-V2-6-Diagnostic-APK`에서 `app-debug.apk`를 내려받아 설치.
5. 버전 업데이트가 기존 설치와 서명 불일치로 실패하면 **먼저 기존 앱에서 진단 파일을 공유하여 보존**. 패키지를 지우면 보존 로그가 삭제된다.

## 검증 수준

V2.6 정적 소스 검증 및 Java 파서 검사만 시행. **APK Android 컴파일, 기기 UI, 다운로드/공유, 물리 조명 전환은 아직 실차 미검증**이다. 빌드팩에 `VERIFICATION_KO.txt`를 동봉한다.


## V2.6 변경 (2026-10-21)
- 실차 V2.5 결과: COMMON 허용, GET/SET 서명 권한 차단, 4 Getter × 3회 = 총 12회 SecurityException.
- GET 권한이 미허용인 경우 실제 OEM Getter 호출을 **0회**로 하고 4/4를 `SKIPPED_NO_PERMISSION`으로 별도 집계. 이전의 이미 확인된 오류를 자동 검사에서 반복하지 않음.
- `getter_skipped`, `getter_skip_reason`, `oem_control_trial_enabled=false`를 보고서에 추가.
- 순정 `InsightLightOnItem.onItemClick` → `turnOffInsideLight(2)` + UI 상태 변경은 오프라인 디스어셈블리 증거로서만 유지. `InsightLightOffItem.onItemClick` 본문은 미확보이므로 1/2 물리 의미 확정 불가.
- 안전 잠금: 제어 후보 버튼을 단순 UI에서 완전히 제외하고, 레거시 제어 경로도 `isControlTrialCertified()`에서 항상 차단. 검증 전에는 권한이 허용돼도 차량 제어 불가.
- 기존 앱의 수집 시작→자동 검사→수동 관찰→ZIP 종료·공유 흐름과 수집 복원 키(v25_*) 보존.
- 정적 검사/Java 구문 검사와 Python 회귀 검사만 수행함. APK를 실제로 빌드하거나 차에서 ON/OFF를 성공시켰다는 뜻이 아님.
