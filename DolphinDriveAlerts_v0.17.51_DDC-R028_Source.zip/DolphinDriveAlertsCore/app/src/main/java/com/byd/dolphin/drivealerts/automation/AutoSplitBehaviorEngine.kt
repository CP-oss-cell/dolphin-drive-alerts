package com.byd.dolphin.drivealerts.automation

import android.content.Context
import com.byd.dolphin.drivealerts.dpi.AuthorizedAdbRuntime
import com.byd.dolphin.drivealerts.dpi.TemporaryAppDpiController
import com.byd.dolphin.drivealerts.util.CoreLog
import kotlin.math.abs

/**
 * Direct in-app integration of observed AutoSplit 1.2 command semantics.
 * NO dependency on / launch of AutoSplit itself, and NO old ghost-task route.
 * Platform success is always conditional on actual BYD windowing support.
 */
object AutoSplitBehaviorEngine {
    data class Result(val success:Boolean,val message:String)
    private fun read(c:Context,cmd:String)=AuthorizedAdbRuntime.read(c,cmd,timeoutMs=4_000L).result
    private fun write(c:Context,cmd:String):Boolean {
        val r=AuthorizedAdbRuntime.writeOnce(c,cmd,timeoutMs=12_000L)
        val out=r.result.output
        val ok=r.state==AuthorizedAdbRuntime.State.READY && r.result.success &&
            r.result.exitCode==0 &&
            !Regex("(?i)(Error:|Exception|Permission Denial|Unknown option|not supported|invalid input bounds)").containsMatchIn(out)
        CoreLog.i("SPLIT_NATIVE","command=$cmd;state=${r.state};exit=${r.result.exitCode};ok=$ok;output=${out.take(450)}")
        return ok
    }
    private fun snap(c:Context):String = read(c,"am stack list").output + "\n" + read(c,"dumpsys activity activities").output
    private fun state(c:Context,pkg:String):LegacySplitTaskLocator.State=
        LegacySplitTaskLocator.findTask(snap(c),pkg)
    private fun camera(s:String)=ForegroundResolver.camera(s)
    fun screenToken(c:Context):String? = ForegroundResolver.topToken(read(c,"dumpsys activity activities").output)
    fun capabilities(c:Context):String {
        val adb=AuthorizedAdbRuntime.health(c)
        if(adb.state!=AuthorizedAdbRuntime.State.READY)return "ADB=${adb.state}: 차량 분할 명령 사용 불가"
        val help=read(c,"am start --help").output
        val stacks=read(c,"am stack list")
        return "ADB=READY; windowingMode=${help.contains("windowingMode",true)};"+
            " stackList=${stacks.success};split=${stacks.output.contains("split-screen",true)};"+
            " 직전 빌드 동작 결과와 무관하게 실제 분할은 실행 후 두 Task 확인이 필요합니다"
    }

    fun launch(c:Context,profile:SplitProfile):Result {
        val firstComp=AppSelection.safeComponent(c,profile.firstPackage)
            ?:return Result(false,"첫 번째 앱 실행 Activity가 없습니다")
        val secondComp=AppSelection.safeComponent(c,profile.secondPackage)
            ?:return Result(false,"두 번째 앱 실행 Activity가 없습니다")
        if(profile.firstPackage==profile.secondPackage ||
            profile.firstPackage==c.packageName || profile.secondPackage==c.packageName)
            return Result(false,"서로 다른 외부 앱 2개를 선택하세요")
        if(camera(screenToken(c).orEmpty()))return Result(false,"360 카메라 동작 중에는 분할을 시작하지 않습니다")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)
            return Result(false,"로컬 ADB 승인 필요")
        if(TemporaryAppDpiController.hasActiveSession(c))
            return Result(false,"임시 전역 DPI 복원 대기 중입니다. 먼저 화면·DPI 메뉴의 복원을 완료한 후 분할하세요")

        // Reference APK split launches use modes 3/4. The FULLSCREEN-only
        // 0x18000000 flag and blocking -W were not observed on its split start.
        val primary="am start --user 0 --windowingMode 3 -n '$firstComp'"
        val secondary="am start --user 0 --windowingMode 4 -n '$secondComp'"
        CoreLog.i("SPLIT_NATIVE","BEGIN profile=${profile.id} first=${profile.firstPackage} second=${profile.secondPackage}")
        if(!write(c,primary))return Result(false,"1단계: primary split 실행 명령 거부. SPLIT_NATIVE 로그 확인")
        // If the OEM returned an existing fullscreen task instead of creating
        // mode 3, try ONE bounded first-party placeholder to seed a primary stack.
        // This is an experimental fallback, NOT guaranteed AutoSplit parity.
        var a=state(c,profile.firstPackage)
        if(a.mode!=3) {
            CoreLog.w("SPLIT_NATIVE","PRIMARY_NOT_CONFIRMED afterFirstStart state=$a;bootstrap=singleAttempt")
            if(camera(screenToken(c).orEmpty())) return Result(false,"카메라 화면 감지: 추가 분할 작업 중단")
            val candidate=LegacySplitTaskLocator.findStack(snap(c),3)
            var root=candidate
            if(root<0) {
                val ghost="${c.packageName}/.automation.SplitGhostActivity"
                val cmd="am start --user 0 --windowingMode 3 -n '$ghost'"
                val seeded=write(c,cmd)
                if(seeded) {
                    Thread.sleep(400L)
                    root=LegacySplitTaskLocator.findStack(snap(c),3)
                }
                CoreLog.i("SPLIT_NATIVE","PRIMARY_BOOTSTRAP ghostAttempted=true accepted=$seeded stack=$root")
            }
            if(root>=0 && a.found && !camera(screenToken(c).orEmpty())) {
                val moved=write(c,"am stack move-task ${a.taskId} $root true")
                CoreLog.i("SPLIT_NATIVE","PRIMARY_ATTACH task=${a.taskId} stack=$root commandAccepted=$moved")
                a=state(c,profile.firstPackage)
            }
        }
        if(camera(screenToken(c).orEmpty()))return Result(false,"카메라 화면 감지: 두 번째 앱 실행 취소")
        // Existing task reuse is not split success; mode 4 readback remains required.
        Thread.sleep(250L)
        if(!write(c,secondary))return Result(false,"2단계: secondary split 실행 명령 거부. SPLIT_NATIVE 로그 확인")
        var b=state(c,profile.secondPackage)
        CoreLog.i("SPLIT_NATIVE","INITIAL_OWNERSHIP first=$a second=$b")
        // Reuse visible split stack if the OEM firmware reused a prior app task.
        if(a.mode!=3 && a.found) {
            val stack=LegacySplitTaskLocator.findStack(snap(c),3)
            if(stack>=0) {
                if(!camera(screenToken(c).orEmpty())) write(c,"am stack move-task ${a.taskId} $stack true")
                a=state(c,profile.firstPackage)
            }
        }
        if(b.mode!=4 && b.found) {
            val stack=LegacySplitTaskLocator.findStack(snap(c),4)
            if(stack>=0) {
                if(!camera(screenToken(c).orEmpty())) write(c,"am stack move-task ${b.taskId} $stack true")
                b=state(c,profile.secondPackage)
            }
        }
        // At most two short reads, not a minute of silent waiting.
        if(a.mode!=3 || b.mode!=4) {
            Thread.sleep(450L)
            a=state(c,profile.firstPackage)
            b=state(c,profile.secondPackage)
        }
        val separated=!camera(screenToken(c).orEmpty()) &&
            a.found && b.found && a.mode==3 && b.mode==4 &&
            a.taskId!=b.taskId && a.stackId!=b.stackId
        if(!separated) {
            val raw=read(c,"am stack list").output
            val modes=raw.lineSequence().filter{
                it.contains("Stack id=",true)||it.contains("windowingMode",true)
            }.take(8).joinToString(" | ").take(340)
            CoreLog.w("SPLIT_NATIVE","SPLIT_NOT_CONFIRMED first=$a second=$b stack=$modes")
            return Result(false,"분할 실패: 첫 앱=${a.mode}/${a.stackId}, 둘째 앱=${b.mode}/${b.stackId}. 차량 창 스택 명령·권한 확인 필요")
        }
        FeatureProfiles.markSplit(c,profile.id)
        val ratio=applyRatio(c,profile.primaryPercent,profile)
        if(!ratio.success)return Result(true,"두 앱 분할 확인, 비율은 미확인: ${ratio.message}")
        return Result(true,"두 앱 분할 확인: ${ratio.message}")
    }

    /** Only resize an actually identified 3/4 split pair; this may be unsupported by the OEM WM.
     * A shell exit code alone is NEVER sufficient to claim that a 1% ratio was applied.
     */
    fun applyRatio(c:Context,percentage:Int,expected:SplitProfile?=null):Result {
        if(percentage !in 10..90)return Result(false,"비율은 10~90%입니다")
        if(camera(screenToken(c).orEmpty()))return Result(false,"카메라 화면에서 비율 변경 보류")
        if(AuthorizedAdbRuntime.health(c).state!=AuthorizedAdbRuntime.State.READY)return Result(false,"ADB 승인 필요")
        if(TemporaryAppDpiController.hasActiveSession(c))return Result(false,"임시 전역 DPI 복원 대기 중: 분할 비율 변경 차단")
        if(expected!=null) {
            val snapshot=snap(c)
            val a=LegacySplitTaskLocator.findTask(snapshot,expected.firstPackage)
            val b=LegacySplitTaskLocator.findTask(snapshot,expected.secondPackage)
            if(!a.found || !b.found || a.mode!=3 || b.mode!=4 || a.stackId==b.stackId) {
                CoreLog.w("SPLIT_RATIO","OWNERSHIP_MISMATCH expected=${expected.id} first=$a second=$b")
                return Result(false,"비율 변경 취소: 저장된 두 앱의 실제 분할(모드 3/4)이 확인되지 않습니다")
            }
        }
        fun measure():SplitGeometry.PairBounds? {
            val stack=read(c,"am stack list")
            val activities=read(c,"dumpsys activity activities")
            val parsed=ReferenceAutoSplitRatio.parse(stack.output)
                ?:SplitGeometry.parse(stack.output,activities.output)
            CoreLog.i("SPLIT_RATIO","BOUNDS_READBACK found=${parsed!=null} value=${parsed?.let(SplitGeometry::percent)}")
            return parsed
        }
        val bounds=measure()?:run {
            CoreLog.w("SPLIT_RATIO","BOUNDS_UNAVAILABLE requested=$percentage (no trusted split bounds)")
            return Result(false,"분할은 확인됐으나 창 좌표를 읽을 수 없어 비율 변경을 중단했습니다")
        }
        val before=SplitGeometry.percent(bounds)?:return Result(false,"분할 방향 확인 실패")
        CoreLog.i("SPLIT_RATIO","BEGIN desired=$percentage actual=$before primary=${bounds.primary} secondary=${bounds.secondary}")
        if(before==percentage)return Result(true,"실제 비율 확인: $before:${100-before}")
        val resize=SplitGeometry.resize(bounds,percentage)?:return Result(false,"비율 좌표 계산 실패")
        fun confirmed():Int? {
            repeat(3) {
                Thread.sleep(350L)
                val value=measure()?.let(SplitGeometry::percent)
                if(value==percentage)return value
            }
            return measure()?.let(SplitGeometry::percent)
        }
        // Some Android 10/OEM builds accept both 8-arg and 4-arg command syntax
        // but silently ignore one of them. Try the alternate once when readback fails.
        val eightAccepted=write(c,resize.command)
        var actual=if(eightAccepted)confirmed() else measure()?.let(SplitGeometry::percent)
        CoreLog.i("SPLIT_RATIO","TRY_8_ARGS accepted=$eightAccepted requested=$percentage readback=$actual axis=${resize.axis}")
        if(actual!=percentage && !camera(screenToken(c).orEmpty())) {
            val fourAccepted=write(c,resize.fourArgCommand)
            actual=if(fourAccepted)confirmed() else measure()?.let(SplitGeometry::percent)
            CoreLog.i("SPLIT_RATIO","TRY_4_ARGS accepted=$fourAccepted requested=$percentage readback=$actual")
            if(actual==percentage) return Result(true,"실제 비율 $actual:${100-actual} 확인 (4좌표 방식)")
        } else if(actual==percentage) return Result(true,"실제 비율 $actual:${100-actual} 확인 (8좌표 방식)")
        return Result(false,"요청 $percentage:${100-percentage}, 실제 ${actual?.let { "$it:${100-it}" } ?: "측정 불가"}. 차량이 비율 명령을 거부하거나 제한했을 수 있습니다")
    }
}
