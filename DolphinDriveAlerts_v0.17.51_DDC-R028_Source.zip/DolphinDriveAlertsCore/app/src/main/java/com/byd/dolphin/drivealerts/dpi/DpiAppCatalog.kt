package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.ApplicationInfo

/** PackageManager lookup; handles OEM apps without LAUNCHER activity. Scan on background thread. */
object DpiAppCatalog {
    data class Entry(val packageName:String, val title:String, val system:Boolean, val launchable:Boolean) {
        val label:String get() = "${if(system) "[순정/시스템]" else "[설치 앱]"} $title ($packageName)${if(!launchable) " · 직접 실행 아이콘 없음" else ""}"
    }
    fun load(context:Context):List<Entry> {
        val pm=context.packageManager
        val packages=runCatching { pm.getInstalledApplications(0) }.getOrDefault(emptyList())
        val seen=packages.map { it.packageName }.toMutableSet()
        // OEM navigation may have no LAUNCHER icon and may not be visible to PackageManager.
        // Read exact package identifiers from the already-authorized BYD local ADB (read-only).
        val adb=AuthorizedAdbRuntime.read(context,"pm list packages", timeoutMs=8_000L)
        val safePattern=Regex("[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z_][A-Za-z0-9_]*)+")
        val adbPackages=if(adb.state==AuthorizedAdbRuntime.State.READY) adb.result.output
            .lineSequence().map { it.trim().removePrefix("package:") }
            .filter { safePattern.matches(it) && !ThirdPartyDpiRules.isProtected(it) }
            .toSet() else emptySet()
        if(adbPackages.isNotEmpty()) context.getSharedPreferences("dpi_adb_visible_packages",Context.MODE_PRIVATE)
            .edit().putStringSet("packages",adbPackages).commit()
        val base=packages.asSequence().filter { ThirdPartyDpiRules.allowed(context,it.packageName) }
            .map { info ->
                val title=runCatching { pm.getApplicationLabel(info).toString() }.getOrDefault(info.packageName)
                val system=(info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0 ||
                    info.packageName.startsWith("com.byd.")
                val launchable=runCatching { pm.getLaunchIntentForPackage(info.packageName)!=null }.getOrDefault(false)
                Entry(info.packageName,title,system,launchable)
            }.toList()
        val shellOnly=adbPackages.asSequence().filterNot { it in seen }.map { pkg ->
            Entry(pkg,pkg,true,false)
        }.toList()
        return (base+shellOnly).distinctBy { it.packageName }
            .sortedWith(compareBy<Entry> { it.system }.thenBy { it.title.lowercase() }.thenBy { it.packageName })
    }
    // This is only a *candidate* rank, never evidence that any candidate is the active OEM navigation UI.
    private val navPattern=Regex("(?i)(navi|navigation|tmap|automap|navimap|maps?|znav|gaode|autonavi)")
    fun navigationCandidates(items:List<Entry>):List<Entry> = items.filter {
        navPattern.containsMatchIn(it.title) || navPattern.containsMatchIn(it.packageName)
    }.sortedWith(compareBy<Entry> { if(it.packageName=="com.tmap.auto.byd") 0 else if(it.system) 1 else 2 }
        .thenBy { it.title.lowercase() })

    fun count(items:List<Entry>,filter:Int,query:String):Int {
        val q=query.trim()
        return items.count { (filter==0 || (filter==1 && !it.system) || (filter==2 && it.system)) &&
            (q.isEmpty() || it.title.contains(q,true) || it.packageName.contains(q,true)) }
    }
    fun find(items:List<Entry>,filter:Int,query:String,limit:Int=200):List<Entry> {
        val q=query.trim()
        return items.asSequence().filter { filter==0 || (filter==1 && !it.system) || (filter==2 && it.system) }
            .filter { q.isEmpty() || it.title.contains(q,true) || it.packageName.contains(q,true) }
            .sortedWith(compareBy<Entry> { if(q.isBlank() && navPattern.containsMatchIn(it.title+" "+it.packageName)) 0 else 1 }
                .thenBy { if(it.system) 0 else 1 }.thenBy { it.title.lowercase() })
            .take(limit).toList()
    }
}
