package com.byd.dolphin.drivealerts.automation

/** No arbitrary time-only auto-rearm. A vendor quickboot wake AND new BYD ACC/IGN ON
 * are required after a previous run, with a long quiet gap to reject duplicate broadcasts.
 * These are observable hints, not verified physical ignition state.
 */
object IgnitionWakePolicy {
    data class Decision(val allowed: Boolean, val reason: String)
    fun decide(armed: Boolean, now: Long, lastStart: Long, quickbootWake: Long): Decision {
        val sameBoot = lastStart >= 0L && now >= lastStart
        if (!sameBoot) return Decision(true, "NEW_ANDROID_BOOT")
        if (armed) return Decision(now - lastStart > 2_000L, "ARMED")
        val pairedWake = quickbootWake > lastStart + 120_000L &&
            quickbootWake <= now && now - quickbootWake <= 120_000L &&
            now - lastStart > 120_000L
        return if (pairedWake) Decision(true, "VENDOR_QUICKBOOT_AND_BYD_IGNITION_PAIR")
        else Decision(false, "WAIT_OFF_OR_VERIFIED_WAKE_PAIR")
    }
}
