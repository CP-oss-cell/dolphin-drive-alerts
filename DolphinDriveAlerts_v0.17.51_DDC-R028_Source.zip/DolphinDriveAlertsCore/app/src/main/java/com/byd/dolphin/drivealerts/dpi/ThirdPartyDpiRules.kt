package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import android.content.pm.ApplicationInfo

/** Density override is DISPLAY-WIDE, never true private OEM app DPI. */
object ThirdPartyDpiRules {
    private const val PREF = "third_party_dpi_v01739" // Keep prior user preferences.
    private const val ENABLED = "auto_enabled"
    private const val PREFIX = "pkg_"
    private val safePkg = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    // Exclude low-level safety/system UI. OEM navigation, media and regular OEM apps ARE selectable.
    private val critical = setOf("android", "com.android.systemui", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.byd.dolphin.drivealerts")
    fun isProtected(pkg:String):Boolean = pkg in critical ||
        pkg.contains("cluster",true) || pkg.contains("instrument",true) ||
        pkg.contains("airbag",true)
    fun enabled(context: Context) = context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean(ENABLED,false)
    fun setEnabled(context: Context, value: Boolean): Boolean = context.getSharedPreferences(PREF,Context.MODE_PRIVATE)
        .edit().putBoolean(ENABLED,value).commit()
    fun allowed(context: Context, pkg: String): Boolean {
        if (!safePkg.matches(pkg) || pkg == context.packageName || isProtected(pkg)) return false
        return runCatching { context.packageManager.getApplicationInfo(pkg,0) }.isSuccess ||
            pkg in context.getSharedPreferences("dpi_adb_visible_packages",Context.MODE_PRIVATE)
                .getStringSet("packages", emptySet()).orEmpty()
    }
    fun isSystem(context:Context, pkg:String):Boolean {
        val info=runCatching {context.packageManager.getApplicationInfo(pkg,0)}.getOrNull()
            ?: return pkg in context.getSharedPreferences("dpi_adb_visible_packages",Context.MODE_PRIVATE)
                .getStringSet("packages", emptySet()).orEmpty()
        return info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0 ||
            pkg.startsWith("com.byd.")
    }
    fun rule(context: Context, pkg: String): Int {
        if (!allowed(context,pkg)) return 0
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getInt(PREFIX+pkg,0).takeIf { it in 120..320 } ?: 0
    }
    fun save(context: Context,pkg: String, dpi: Int): Boolean {
        if (!allowed(context,pkg) || dpi != 0 && dpi !in 120..320) return false
        return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putInt(PREFIX+pkg,dpi).commit()
    }
    fun summary(context: Context): String = context.getSharedPreferences(PREF,Context.MODE_PRIVATE).all
        .filter { it.key.startsWith(PREFIX) && it.value is Int && (it.value as Int) in 120..320 }
        .map { "${it.key.removePrefix(PREFIX)}=${it.value}" }.sorted().joinToString(";")
}
