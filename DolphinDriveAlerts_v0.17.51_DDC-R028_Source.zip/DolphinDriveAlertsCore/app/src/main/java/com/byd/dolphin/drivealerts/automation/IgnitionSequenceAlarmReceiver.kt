package com.byd.dolphin.drivealerts.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.log.IgnitionAuditJournal

/** Launcher V1 AlarmManager fallback: only if the initial sequence service was NEVER delivered.
 *  Does not launch vehicle controllers, send CAN writes, or replay an acknowledged batch.
 */
class IgnitionSequenceAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_CHECK) return
        val prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE)
        val request=intent.getLongExtra(EXTRA_REQUEST,-1L)
        val stored=prefs.getLong("requested",-2L)
        val acknowledged=prefs.getLong("acknowledged",-1L)
        val armed=context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
            .getBoolean("armed",true)
        if (request<0L || stored!=request || armed || !FeatureProfiles.sequenceEnabled(context)) {
            CoreLog.i("BOOT","AUTO_SEQUENCE_ALARM_SUPPRESSED id=$request current=$stored armed=$armed")
            return
        }
        if (acknowledged >= request) {
            CoreLog.i("BOOT","AUTO_SEQUENCE_SERVICE_ACK_ALREADY_DELIVERED requested=$request ack=$acknowledged")
            return
        }
        // Clear the one-shot request BEFORE dispatch to prevent duplicate retries.
        prefs.edit().putLong("requested",-1L).commit()
        CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_MISSING requested=$request;retry=one")
        val accepted=AutoLaunchSequenceService.start(context.applicationContext)
        IgnitionAuditJournal.record(context,"ALARM_RETRY", "accepted=$accepted ack=$acknowledged request=$request")
        if (!accepted) {
            // Delivery has definitively failed, unlike a service that was ACKed but
            // later could not launch a user app. Retain eligibility for the next ON.
            context.getSharedPreferences("ignition_sequence_guard",Context.MODE_PRIVATE)
                .edit().putBoolean("armed",true).commit()
            CoreLog.w("BOOT","AUTO_SEQUENCE_RETRY_REJECTED rearmed=true")
        }
    }
    companion object {
        private const val PREF="ignition_sequence_delivery_v01719"
        private const val ACTION_CHECK="com.byd.dolphin.drivealerts.IGNITION_SEQUENCE_DELIVERY_CHECK"
        private const val EXTRA_REQUEST="request_elapsed"
        private fun pending(c:Context,request:Long):PendingIntent {
            val i=Intent(c,IgnitionSequenceAlarmReceiver::class.java).setAction(ACTION_CHECK)
                .putExtra(EXTRA_REQUEST,request)
            return PendingIntent.getBroadcast(c,1719,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        fun schedule(c:Context) {
            val elapsed=SystemClock.elapsedRealtime()
            val prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
            if (!prefs.edit().putLong("requested",elapsed).putLong("acknowledged",-1L).commit()) {
                CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_GUARD_PERSIST_FAILED")
                return
            }
            runCatching {
                val alarm=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,elapsed+12_000L,pending(c,elapsed))
            }.onSuccess { CoreLog.i("BOOT","AUTO_SEQUENCE_DELIVERY_CHECK_SCHEDULED request=$elapsed") }
                .onFailure { CoreLog.w("BOOT","AUTO_SEQUENCE_DELIVERY_CHECK_FAILED ${it.message}") }
        }
        fun acknowledge(c:Context) {
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putLong("acknowledged",SystemClock.elapsedRealtime()).commit()
        }
        fun cancel(c:Context) {
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putLong("requested",-1L).commit()
            val alarm=c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            alarm?.cancel(pending(c,0L))
        }
    }
}
