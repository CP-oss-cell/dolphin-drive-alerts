package com.byd.dolphin.drivealerts.log

import android.content.Context
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small, app-private and durable chronological audit, independent of a running vehicle FGS.
 *  It logs ONLY app lifecycle / capture / ignition decisions; not positions, contacts or media URLs.
 *  Stored between power cycles; the older file remains intact until next size rotation.
 */
object IgnitionAuditJournal {
    private const val MAX_BYTES = 262_144L
    private val valid = Regex("[^a-zA-Z0-9_./:=-]")
    @Synchronized fun record(context: Context, kind: String, detail: String = "") {
        try {
            val dir = File(context.applicationContext.filesDir, "ignition_audit").apply { mkdirs() }
            val active = File(dir, "events.jsonl")
            val older = File(dir, "events.prev.jsonl")
            if (active.length() > MAX_BYTES) {
                if (older.exists()) older.delete()
                if (!active.renameTo(older)) return
            }
            val event = JSONObject().put("ts", System.currentTimeMillis())
                .put("kind", valid.replace(kind.take(72), "_"))
                .put("detail", valid.replace(detail.take(360), "_"))
                .put("elapsedMs", android.os.SystemClock.elapsedRealtime())
            FileOutputStream(active, true).use { stream ->
                stream.write((event.toString() + "\n").toByteArray(Charsets.UTF_8))
                stream.fd.sync() // the last decision must survive a sudden ACC power loss
            }
        } catch (_: Throwable) { /* diagnostics cannot stop vehicle alerts */ }
    }

    @Synchronized fun snapshot(context: Context): ByteArray {
        val dir = File(context.applicationContext.filesDir, "ignition_audit")
        val combined = StringBuilder()
        for (name in listOf("events.prev.jsonl", "events.jsonl")) {
            val file = File(dir, name)
            if (!file.isFile) continue
            runCatching { file.forEachLine(Charsets.UTF_8) { line ->
                if (line.length <= 1024 && line.trimStart().startsWith("{"))
                    combined.append(line).append('\n')
            } }
        }
        return combined.toString().toByteArray(Charsets.UTF_8)
    }

    /** One-touch rescue export. Works even when the vehicle monitor/log session is not alive.
     * Contains only the bounded ignition timeline; never labels this as full vehicle evidence.
     */
    fun exportRecent(context: Context): Result<String> = runCatching {
        val body = snapshot(context)
        check(body.isNotEmpty()) { "기록된 시동 이벤트가 없습니다. 앱이 시동 방송을 수신했는지 확인하세요." }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val filename = "DolphinIgnitionAudit_$stamp.zip"
        val output = ByteArrayOutputStream()
        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("ignition_audit.jsonl"))
            zip.write(body)
            zip.closeEntry()
            zip.putNextEntry(ZipEntry("about.json"))
            zip.write(JSONObject().put("type", "ignition_only_rescue")
                .put("noVehicleFrames", true).put("missingPowerOffEventsNotReconstructed", true)
                .put("createdAtMs", System.currentTimeMillis()).toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        val staged = File(context.cacheDir, "$filename.staged")
        FileOutputStream(staged).use { stream ->
            stream.write(output.toByteArray())
            stream.fd.sync()
        }
        ZipFile(staged).use { archive ->
            check(archive.getEntry("ignition_audit.jsonl") != null && archive.getEntry("about.json") != null)
            check(archive.size() == 2)
        }
        val location = if (Build.VERSION.SDK_INT >= 29) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Downloads 파일 생성 실패")
            try {
                val dst = resolver.openOutputStream(uri, "w") ?: error("Downloads 기록 실패")
                dst.use { staged.inputStream().use { input -> input.copyTo(it) } }
                check(resolver.update(uri, ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }, null, null) > 0) { "Downloads 완료 표시 실패" }
            } catch (failure: Throwable) {
                resolver.delete(uri, null, null)
                throw failure
            }
            "Download/$filename"
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val target = File(dir, filename)
            staged.copyTo(target, overwrite = true)
            ZipFile(target).use { check(it.size() == 2) }
            target.absolutePath
        }
        staged.delete()
        location
    }
}
