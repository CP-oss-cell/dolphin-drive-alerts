package com.byd.dolphin.drivealerts.automation

/** Android 10/AutoSplit 1.2 compatible parser for both `am stack list` and dumpsys activity.
 * Stock `am stack list` prints `Stack id=N` and `taskId=N` (not `Stack #N` / `Task{#N}`).
 * The previous parser omitted these forms and could block the SECOND app from even launching.
 */
internal object LegacySplitTaskLocator {
    data class State(val taskId:Int=-1,val stackId:Int=-1,val mode:Int=-1) {
        val found get()=taskId>=0 && stackId>=0
    }
    private val stackHeader=Regex("""(?i)(?:\b(?:Root)?Stack\s+id\s*=\s*|\b(?:Root)?Stack\s*#|\bActivityStack[^#\n]*#)(\d+)\b""")
    private val taskPatterns=listOf(
        Regex("""(?i)\btaskId\s*[=:]\s*(\d+)"""),
        Regex("""(?i)\bTask\s+#(\d+)"""),
        Regex("""(?i)\bTask(?:Record)?\{[^}]*?#(\d+)\b"""),
        Regex("""(?i)\bTask\{\s*(\d+)(?=\s|\})"""),
        Regex("""(?i)\bmTaskId\s*=\s*(\d+)""")
    )
    private fun stackId(line:String)=stackHeader.find(line)?.groupValues?.get(1)?.toIntOrNull()
    private fun taskId(line:String):Int?=taskPatterns.firstNotNullOfOrNull { it.find(line)?.groupValues?.get(1)?.toIntOrNull() }
    private fun mode(line:String):Int? = when {
        line.contains("split-screen-primary",true) -> 3
        line.contains("split-screen-secondary",true) -> 4
        line.contains("windowingMode=fullscreen",true) || line.contains("mWindowingMode=fullscreen",true) -> 1
        else -> Regex("""(?i)\b(?:mWindowingMode|windowingMode)\s*[=:]\s*([134])\b""")
            .find(line)?.groupValues?.get(1)?.toIntOrNull()
    }
    private fun owns(line:String,pkg:String)=
        line.contains("$pkg/") || line.contains("$pkg ") || line.contains("package=$pkg") ||
        line.contains("A=$pkg") || line.trimEnd().endsWith(pkg)

    fun findStack(raw:String,targetMode:Int):Int {
        var stack=-1
        for(line in raw.lineSequence()) {
            stackId(line)?.let { stack=it }
            if(stack>=0 && mode(line)==targetMode)return stack
        }
        return -1
    }
    fun findTask(raw:String,pkg:String,requiredMarker:String?=null):State {
        var stack=-1;var task=-1;var taskMode=-1
        val modes=mutableMapOf<Int,Int>()
        // First collect stack modes from dumpsys; am stack list commonly omits the mode.
        for(line in raw.lineSequence()) {
            stackId(line)?.let { stack=it }
            if(stack>=0) mode(line)?.let { modes[stack]=it }
        }
        stack=-1
        for(line in raw.lineSequence()) {
            stackId(line)?.let { stack=it; task=-1;taskMode=modes[stack]?:-1 }
            mode(line)?.let { if(stack>=0)taskMode=it }
            taskId(line)?.let {task=it}
            if(stack>=0 && task>=0 && owns(line,pkg) &&
                (requiredMarker==null || line.contains(requiredMarker,true))) {
                return State(task,stack,modes[stack]?:taskMode)
            }
        }
        return State()
    }
}
