# v0.17.51 DDC-R028 — 재시동 자동 실행·진단 연속성 개선 후보

기준: R027 v0.17.50 전체 소스. 과거 정상 동작한 NORMAL·회생제동·AutoHold·BSD 기존 발화 경로 및 분할/DPI 엔진 미변경.

## 실제 코드 변경
- `IgnitionAuditJournal`: App-private bounded 2×256 KiB file with fsync. `BootReceiver`가 FGS를 시작하지 못한 상황도 앱 프로세스가 broadcast를 받았다면 기록. 시스템이 실제 꺼진 시간은 기록할 수 없고 수신되지 않은 방송을 만들어내지 않는다.
- `IgnitionWakePolicy`: 재시동 뒤 latch가 남아 있을 때, **BYD/Android Quickboot→BYD ACC_ON/IGN_ON** 조합이 지정된 시간창과 이전 실행 2분 이후 조건을 만족할 때만 다시 시도. Quickboot나 화면 켜짐 단독으로 사용자 앱/미디어 실행하지 않음. 물리적 점화 검증은 여전히 필요.
- `IgnitionSequenceAlarmReceiver`: 12초 배달 확인의 재시도 실패 시 latch를 다시 준비시켜 다음 명시적 점화 시도 기회 보존.
- `AutoLaunchSequenceService`: dispatch/request/ACK/시퀀스 시작·종료와 ineligible status를 영속 저널에 기록. 시작 요청을 앱 실제 실행 성공이라고 판정하지 않음.
- `FeatureProfiles`: 사용자가 지정 앱 자동 실행을 OFF→ON으로 변경한 경우, 미래의 실제 ACC/IGN 방송을 위한 가드를 재무장 (즉시 미디어 재생은 하지 않음).
- `IgnitionAuditJournal.exportRecent`: 별도 수집 세션이 실패했어도 최근 시동·서비스 기록만 Downloads ZIP에 원터치 보존 가능. 기록이 없다면 명확하게 알림.
- `DrivingAlertService`: 수집 시작/종료 명령 접수 및 실제 결과를 별도로 기록. FGS 시작·소멸 저널도 기록.
- `UnifiedLogCapture`: ZIP 성공 경로와 저장 실패 원인을 SharedPreferences에 남기고, 실패 시 원본·세션 ID를 유지해서 재시도. `lifecycle/ignition_audit.jsonl` 자동 동봉. SharedPreferences 저장 실패나 MediaStore 오류에 대해서도 성공을 보장하지 않음.
- `MainActivity`: 서비스 비동기 결과를 1.5/6/17초에 새로 읽고 마지막 성공/실패 메시지 표시. 기존 UI와 기능 카드는 보존.
- `RuntimeFeatureSnapshot`: 주행보조 자체 auto start와 지정 앱 시퀀스 enable/armed 상태 별도 기록.

## 검증한 것과 못한 것
- 소스 수준 회귀검사, 순수 Kotlin 점화 정책 9개 사례, Android 스텁 기반 영속 로그/구조적 ZIP 생성 테스트 통과. GitHub Actions 셸/YAML 검사도 실행. Android Gradle assembleDebug 및 실제 차량에서 시동 OFF→ON 자동 실행은 미검증.
- Quickboot/ACC_ON 방송이 실제 글로벌 2602 펌웨어에서 항상 발생한다는 증거는 아직 없음. OEM이 둘 중 하나를 보내지 않으면 억지로 재생하지 않고 상태·오류 기록으로 남김.
- 새 ADAS 좌우/앞차출발/차선이탈 발화는 추가하지 않음. 안전 관련 신호는 실차 검증 전 read-only 유지.
- 장기간 원시 차량 데이터를 무한 저장하는 블랙박스 구현은 아님. 작은 점화·서비스·로그 결과만 자동 보관하는 1차 안정화 단계.

## 설치 주의
- v0.17.50의 versionCode=76에서 이 후보는 versionCode=77.
- 정상 업데이트 설치에는 기존 설치 APK와 동일한 앱 서명 인증서 필요. GitHub Action Secret `DOLPHIN_DEBUG_KEYSTORE_B64` 확인.
