# Dolphin Drive Alerts v0.17.50 / DDC-R027 — 변경·검증 보고서

작성 기준: 2026-11-05. 기준 소스: v0.17.48 DDC-R026. 증거: 2026-11-05 18:42 실차 로그 ZIP.

## 로그에서 실제 확인된 문제
- 문자 앱 + Chrome 실행은 전체화면 task 재활용, primary/secondary split(3/4) 소유 미확인.
- `SplitGhostActivity`를 로컬 ADB shell에서 실행할 때 `not exported` SecurityException 반복.
- 카메라/TMAP 및 TMAP/영상 앱 조합은 3/4 분할 진입이 기록됨.
- 선택 DPI 200→원래 override 140 복원(`RESTORED_PREVIOUS_DENSITY override=140`) 확인.
- `com.tmap.auto.byd`는 OEM 내비 관련 알림에서 보인 패키지 후보이며 실제 실행 화면의 단독 패키지로 확정된 것은 아님.

## R027 수정
1. `SplitGhostActivity`: shell UID가 사용할 수 있도록 exported=true, android.permission.DUMP 보호, 리사이즈 가능. 종전 4.5초 자체 종료 보존. 차량별 성공은 미검증.
2. fullscreen 창 모드를 1로 읽어서 미확인(-1)과 구분.
3. 2앱의 실제 모드 3/4/task 소유 일치 여부 확인 후에만 비율 변경.
4. 8좌표 명령은 코드 0이어도 실제 측정값을 확인. 실패한 경우 4좌표 대체 명령은 딱 한 번. 비율 1% 목표는 readback이 정확하게 일치할 때만 성공으로 표시.
5. 비율 편집창 +1%/-1% 버튼. 기존 10..90%, 1% 슬라이더 보존.
6. DPI 앱 목록 최대 100개 표시 제한 완화, 내비/지도 후보 우선 및 별도 직접 선택 버튼. 설치된 패키지를 읽기 전용으로 확인하되 순정 앱 확정은 하지 않음.
7. ADB 미확인 패키지는 시스템 앱으로 보수적으로 판정해 자동 전역 DPI 변경을 회피. 사용자가 직접 실행 및 동의하는 기존 전역 DPI 실험은 유지.
8. 활성 임시 전역 DPI 세션과 분할 명령 충돌 차단. DPI 기존 복원/재시도 로직 그대로.
9. 시동 자동 실행 화면에 ADB 현재 상태 및 승인 메뉴를 추가. 정상 작동한 자동 실행 엔진은 변경하지 않음.

## 미해결 / 제한
- **분할 불가 앱의 resizeableActivity/minWidth 제한**, OEM 모드 불지원, 카메라 복귀 직후 task 재배치 등은 실차 장치 없이는 보장 불가.
- 1% 입력/설정 가능과 **차량에서 실제 1% 적용 가능**은 별개. 실제 비율이 다르면 실패로 표시하고 로그에 남김.
- 순정 내비의 **독립(per-app) DPI**는 구현되지 않았으며 `wm density`는 여전히 전역 변경. 순정 화면 빈 공간은 내부 UI/layout 문제일 수 있음.
- 순정 내비는 패키지가 실행 가능한 LAUNCHER 활동을 제공해야 수동 DPI 실행이 가능. 목록 선택과 실행 가능 여부는 별개.
- 테스트는 Kotlin stub 기반 모의 실행/원본 핵심 SHA-256/정적 검사이며, 이 환경에서 Android SDK 전체 APK 빌드 및 차량 실차 검증은 하지 못함.
- v0.17.49의 실제 설치 버전코드가 76보다 크거나 기존 앱 서명키가 다르면 인플레이스 업데이트 불가. GitHub Secret `DOLPHIN_DEBUG_KEYSTORE_B64`로 기존 서명키 보존 필요.

## 배포 구조
- 바깥 통합 ZIP 안에 같은 stem의 프로젝트 소스 ZIP 1개와 GitHub Actions YML 1개.
- GitHub에 소스 ZIP과 YML을 각각 업로드 후 `.github/workflows/`로 YML을 등록하면 `workflow_dispatch`에서 APK를 빌드. 소스 ZIP과 YML 이름은 변경하지 않음.
