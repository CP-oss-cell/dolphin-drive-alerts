#!/usr/bin/env python3
"""v0.17.47 R12 behavioral source gates; NOT evidence of Android APK/real-car success."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
s=root/'app/src/main/java/com/byd/dolphin/drivealerts'
r=lambda rel:(s/rel).read_text(encoding='utf-8')
boot=r('service/BootReceiver.kt')
seq=r('automation/AutoLaunchSequenceService.kt')
media=r('automation/MediaPlaybackObserver.kt')
split=r('automation/AutoSplitBehaviorEngine.kt')
prof=r('automation/FeatureProfiles.kt')
ui=r('automation/AutoLaunchSettingsActivity.kt')
build=(root/'app/build.gradle.kts').read_text()
checks={
 'merged_version_0.17.48_code_74': 'versionCode = 76' in build and 'versionName = "0.17.50"' in build,
 'normal_mode_untouched_ref': (s/'vehicle/ReferenceVehicleEventBridge.kt').exists(),
 'alert_service_present': (s/'service/DrivingAlertService.kt').exists(),
 'ignition_only_strict_trigger': '"com.byd.action.ACC_ON", "com.byd.action.IGN_ON"' in boot,
 'not_charger_as_off': 'STOP_SIDE_ACTIONS = setOf("com.byd.action.ACC_OFF")' in boot,
 'not_boot_music_trigger': 'AUTO_SEQUENCE_BOOT_OBSERVED' in boot,
 'monotonic_start_window': 'last_started_elapsed' in boot and 'SystemClock.elapsedRealtime()' in boot,
 'diagnostic_trigger_details': 'AUTO_SEQUENCE_TRIGGER' in boot and 'steps=$steps' in boot,
 'guard_dispatch_rollback': 'AUTO_SEQUENCE_DELIVERY_REJECTED' in boot and 'putBoolean("armed",true).commit()' in boot,
 'ack_not_completion': 'delivery ACK != work success' in seq,
 'trigger_source_logged': 'source=${if(manual)' in seq,
 'service_start_boolean': 'fun start(context:Context, manual:Boolean=false):Boolean' in seq,
 'listener_readback': 'isNotificationListenerAccessGranted' in media,
 'no_permission_retry_loop': 'if(!listenerAccess(c)) return false' in media,
 'media_unknown_not_success': 'val accepted = status == PlaybackState.STATE_PLAYING' in media,
 'permission_status_ui': 'MediaPlaybackObserver.listenerAccess(this)' in ui,
 'per_step_parse_error_logging': 'STEP_CONFIG_INVALID_ROW' in prof,
 'preserve_raw_bad_json': 'STEP_CONFIG_INVALID_JSON' in prof and 'saveSteps(c' not in prof.split('fun steps(c: Context)')[1].split('fun saveSteps')[0],
 'shell_requires_real_success': 'r.result.success &&' in split and 'r.result.exitCode==0' in split,
 'single_ghost_bootstrap_attempt': 'PRIMARY_BOOTSTRAP ghostAttempted=true' in split and 'SplitGhostActivity' in split,
 'split_camera_guard_first': 'if(camera(screenToken(c).orEmpty()))return Result(false' in split,
 'split_camera_guard_second': '두 번째 앱 실행 취소' in split,
 'split_readback_verification': 'a.mode==3 && b.mode==4' in split and 'SPLIT_NOT_CONFIRMED' in split,
 'no_unsafe_car_write': all(x not in split+boot+seq for x in ['setVehicleCan','sendCanFrame','BYDAutoEnergyDevice.set']),
 'matching_zip_workflow': 'SOURCE_ZIP: DolphinDriveAlerts_v0.17.50_DDC-R027_Source.zip' in (root/'.github/workflows/DolphinDriveAlerts_v0.17.50_DDC-R027_Source.yml').read_text(),
 'sdk_component_verification': 'ANDROID_SDK_34_AND_BUILD_TOOLS_34_VERIFIED' in (root/'.github/workflows/DolphinDriveAlerts_v0.17.50_DDC-R027_Source.yml').read_text(),
}
for k,passed in checks.items(): print(('PASS' if passed else 'FAIL'),k)
print('R12_STATIC_GATE',sum(checks.values()),'/',len(checks))
assert all(checks.values()),'patch regression failed'
