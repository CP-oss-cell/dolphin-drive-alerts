#!/usr/bin/env python3
"""DDC-R028 isolated source/Kotlin fixture tests. Not an Android build or in-car test."""
from pathlib import Path
import subprocess, shutil, tempfile, re, hashlib, json, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda f:(src/f).read_text(encoding='utf-8')
manifest=root/'app/src/main/AndroidManifest.xml'
ns='{http://schemas.android.com/apk/res/android}'
tree=ET.parse(manifest)
activities=tree.findall('.//activity')
ghost=next(x for x in activities if x.get(ns+'name')=='.automation.SplitGhostActivity')
assert ghost.get(ns+'exported')=='true' and ghost.get(ns+'permission')=='android.permission.DUMP' and ghost.get(ns+'resizeableActivity')=='true'
assert 'versionName = "0.17.51"' in (root/'app/build.gradle.kts').read_text()
assert 'versionCode = 77' in (root/'app/build.gradle.kts').read_text()
engine=read('automation/AutoSplitBehaviorEngine.kt')
dpi=read('dpi/TemporaryAppDpiController.kt')
ui=read('ui/AppPolicyActivity.kt')
catalog=read('dpi/DpiAppCatalog.kt')
assert 'TRY_8_ARGS' in engine and 'TRY_4_ARGS' in engine
assert 'actual==percentage' in engine and 'abs(before-percentage)<=2' not in engine
assert 'OWNERSHIP_MISMATCH' in engine
assert 'TemporaryAppDpiController.hasActiveSession(c)' in engine
assert 'DpiAppCatalog.navigationCandidates(allEntries)' in ui
assert '순정 내비 후보 바로 선택' in ui
assert 'limit:Int=200' in catalog and 'fun count(' in catalog
assert 'RESTORED_PREVIOUS_DENSITY' in dpi and 'AUTO_SKIP_OEM_FOREGROUND' in dpi
assert 'APP_STARTED_THEN_DPI' in dpi and 'beforeOverride' in dpi
assert 'ADB 연결/승인' in read('automation/AutoLaunchSettingsActivity.kt')
assert 'button("-1%")' in read('automation/SplitProfilesActivity.kt') and 'button("+1%")' in read('automation/SplitProfilesActivity.kt')

# Critical vehicle modules must remain byte-for-byte equal to R026 baseline.
expected=json.loads((root/'tools/R027_PRESERVED_CORE_SHA256.json').read_text())
# Intentional R028 lifecycle changes are excluded, but confirmed ADAS/audio/UI independent
# modules and unmodified split/media behavior must retain their exact R027 hashes.
modified={
    'service/DrivingAlertService.kt','service/BootReceiver.kt',
    'ui/MainActivity.kt','automation/AutoLaunchSequenceService.kt'
}
for path,digest in expected.items():
    if path.split('/drivealerts/')[-1] in modified: continue
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
original=Path('/mnt/data/inspect_dda/DolphinDriveAlertsCore')
if original.exists():
    sensitive=[
        'vehicle/ReferenceVehicleEventBridge.kt','vehicle/ModeNoticeCorrelator.kt',
        'audio/AlertAudioPlayer.kt', 'automation/MediaPlaybackObserver.kt',
        'automation/SplitRecoveryService.kt',
    ]
    for rel in sensitive:
        f='app/src/main/java/com/byd/dolphin/drivealerts/'+rel
        assert hashlib.sha256((root/f).read_bytes()).digest()==hashlib.sha256((original/f).read_bytes()).digest(),rel

if not shutil.which('kotlinc') or not shutil.which('java'):
    print('R027_ANDROID_FREE_KOTLIN_FIXTURE_SKIPPED: kotlinc/java unavailable')
else:
    with tempfile.TemporaryDirectory(prefix='dda-r027-kotlin-') as td:
        t=Path(td)
        (t/'Android.kt').write_text('''package android.content
import android.content.pm.ApplicationInfo
class Prefs {
 private var values=mutableMapOf<String,Set<String>>()
 fun getStringSet(key:String, default:Set<String>):Set<String> = values[key] ?: default
 fun edit()=this
 fun putStringSet(key:String, value:Set<String>):Prefs { values[key]=value;return this }
 fun commit()=true
}
open class Context {
 companion object { const val MODE_PRIVATE=0 }
 val packageName="com.test.owner"
 val applicationContext:Context get()=this
 val packageManager=PackageManager()
 private val prefs=mutableMapOf<String,Prefs>()
 fun getSharedPreferences(name:String,mode:Int):Prefs=prefs.getOrPut(name){Prefs()}
}
class ComponentName(private val pkg:String) {fun flattenToString()=pkg+"/.Main"}
class Intent(val component:ComponentName?)
class PackageManager {
 fun getInstalledApplications(flags:Int):List<ApplicationInfo> = (1..150).map{ApplicationInfo("com.example.app$it",0)}+ApplicationInfo("com.tmap.auto.byd",ApplicationInfo.FLAG_SYSTEM)
 fun getApplicationLabel(app:ApplicationInfo):String=app.packageName
 fun getLaunchIntentForPackage(pkg:String):Intent?=Intent(ComponentName(pkg))
 fun getApplicationInfo(pkg:String,flags:Int):ApplicationInfo=ApplicationInfo(pkg,if(pkg.endsWith(".byd"))1 else 0)
}
''')
        (t/'Package.kt').write_text('''package android.content.pm
class ApplicationInfo(val packageName:String,val flags:Int) {
 companion object {const val FLAG_SYSTEM=1;const val FLAG_UPDATED_SYSTEM_APP=128}
}
''')
        (t/'Runtime.kt').write_text('''package com.byd.dolphin.drivealerts.dpi
import android.content.Context
object TemporaryAppDpiController {fun hasActiveSession(c:Context)=false}
object ThirdPartyDpiRules {fun isProtected(pkg:String)=false;fun allowed(c:Context,pkg:String)=true}
object AuthorizedAdbRuntime {
 enum class State { READY, DENIED }
 data class Outcome(val success:Boolean,val exitCode:Int,val output:String,val message:String="ok")
 data class Report(val state:State,val result:Outcome)
 var percent=50
 var eightAttempts=0
 var fourAttempts=0
 private fun dump():String {
  val x=1280*percent/100
  return "Stack id=11 bounds=[0,0][$x,720] displayId=0\\n"+
   "mWindowingMode=split-screen-primary\\n"+
   "taskId=101: com.demo.first/com.demo.first.Main\\n"+
   "Stack id=12 bounds=[$x,0][1280,720] displayId=0\\n"+
   "mWindowingMode=split-screen-secondary\\n"+
   "taskId=102: com.demo.second/com.demo.second.Main\\n"
 }
 fun health(c:Context)=Report(State.READY,Outcome(true,0,"OK"))
 fun read(c:Context,cmd:String,timeoutMs:Long=4000L):Report {
  return if(cmd=="pm list packages") Report(State.READY,Outcome(true,0,"package:com.tmap.auto.byd\\n"))
         else Report(State.READY,Outcome(true,0,dump()))
 }
 fun writeOnce(c:Context,cmd:String,timeoutMs:Long=12000L):Report {
  if(cmd.startsWith("am stack resize-docked-stack")) {
    val args=cmd.removePrefix("am stack resize-docked-stack ").trim().split(Regex("\\\\s+"))
    if(args.size==8)eightAttempts++
    if(args.size==4) {fourAttempts++;percent=(args[2].toInt()*100/1280)}
  }
  return Report(State.READY,Outcome(true,0,""))
 }
}
''')
        (t/'Automation.kt').write_text('''package com.byd.dolphin.drivealerts.automation
import android.content.Context
object AppSelection { fun safeComponent(c:Context,p:String)=p+"/.Main" }
object ForegroundResolver {fun topToken(raw:String):String?="mResumedActivity: com.android.launcher3/.Main"; fun camera(s:String)=false}
data class SplitProfile(val id:String,val title:String,val firstPackage:String,val secondPackage:String,val primaryPercent:Int)
object FeatureProfiles {fun markSplit(c:Context,id:String) {}}
''')
        (t/'Log.kt').write_text('''package com.byd.dolphin.drivealerts.util
object CoreLog {fun i(t:String,m:String) {};fun w(t:String,m:String) {}}
''')
        (t/'Fixture.kt').write_text('''package fixture
import android.content.Context
import com.byd.dolphin.drivealerts.automation.*
import com.byd.dolphin.drivealerts.dpi.*
fun main(){
 val ctx=Context()
 val apps=DpiAppCatalog.load(ctx)
 require(apps.size>100)
 require(DpiAppCatalog.find(apps,0,"").first().packageName=="com.tmap.auto.byd")
 require(DpiAppCatalog.navigationCandidates(apps).first().packageName=="com.tmap.auto.byd")
 require(DpiAppCatalog.count(apps,2,"")>=1)
 val first=LegacySplitTaskLocator.findTask("Stack id=25 bounds=[0,0][1280,720]\\nmWindowingMode=fullscreen\\ntaskId=350: com.demo.first/com.demo.first.Main", "com.demo.first")
 require(first.mode==1) {"Fullscreen should be recognized: $first"}
 val profile=SplitProfile("id","test","com.demo.first","com.demo.second",60)
 val result=AutoSplitBehaviorEngine.applyRatio(ctx,60,profile)
 require(result.success) {"Resize failed: $result"}
 require(AuthorizedAdbRuntime.eightAttempts==1 && AuthorizedAdbRuntime.fourAttempts==1)
 require(AuthorizedAdbRuntime.percent==60)
 val again=AutoSplitBehaviorEngine.applyRatio(ctx,60,profile)
 require(again.success && AuthorizedAdbRuntime.fourAttempts==1)
 println("R027_KOTLIN_SPLIT_DPI_FIXTURE_PASS")
}
''')
        files=[src/'automation/AutoSplitBehaviorEngine.kt',src/'automation/SplitGeometry.kt',src/'automation/LegacySplitTaskLocator.kt',src/'automation/ReferenceAutoSplitRatio.kt',src/'dpi/DpiAppCatalog.kt',*[t/x for x in ('Android.kt','Package.kt','Runtime.kt','Automation.kt','Log.kt','Fixture.kt')]]
        command=['kotlinc',*[str(x) for x in files],'-include-runtime','-d',str(t/'test.jar')]
        p=subprocess.run(command,capture_output=True,text=True,timeout=70)
        assert p.returncode==0,p.stdout+p.stderr
        q=subprocess.run(['java','-jar',str(t/'test.jar')],capture_output=True,text=True,timeout=20)
        assert q.returncode==0,q.stdout+q.stderr
        print(q.stdout.strip())
print('R027_STATIC_GATES_PASS')

# Added independent, full source assertions for R028 ignition/restart audit behavior.
ignition=read('automation/IgnitionWakePolicy.kt')
boot=read('service/BootReceiver.kt')
service=read('service/DrivingAlertService.kt')
capture=read('log/UnifiedLogCapture.kt')
journal=read('log/IgnitionAuditJournal.kt')
main=read('ui/MainActivity.kt')
alarm=read('automation/IgnitionSequenceAlarmReceiver.kt')
for token in ('VENDOR_QUICKBOOT_AND_BYD_IGNITION_PAIR','WAIT_OFF_OR_VERIFIED_WAKE_PAIR','120_000L'):
    assert token in ignition,token
for token in ('QUICKBOOT_ACTIONS','SEQUENCE_SUPPRESSED','IgnitionWakePolicy.decide','IGNITION_OFF'):
    assert token in boot,token
for token in ('CAPTURE_BEGIN_RECEIVED','CAPTURE_END_RECEIVED','MONITOR_SERVICE_CREATED'):
    assert token in service,token
for token in ('CAPTURE_SAVE_INTERRUPTED','CAPTURE_SAVE_FAILED','lifecycle/ignition_audit.jsonl','lastResult'):
    assert token in capture,token
assert 'stream.fd.sync()' in journal and 'MAX_BYTES = 262_144L' in journal
assert 'fun exportRecent(context: Context)' in journal and 'DolphinIgnitionAudit_' in journal
assert '시동 기록만 ZIP 저장 (수집 실패 시)' in main
assert 'updateCaptureStatus(); refreshDashboardStatus()' in main
assert 'AUTO_SEQUENCE_RETRY_REJECTED' in alarm
assert 'guardRearmedForNextIgnition' in read('automation/FeatureProfiles.kt')
assert 'onFrontCarStartStateChange' not in ignition  # no invented ADAS activation
print('R028_IGNITION_CAPTURE_STATIC_PASS')
