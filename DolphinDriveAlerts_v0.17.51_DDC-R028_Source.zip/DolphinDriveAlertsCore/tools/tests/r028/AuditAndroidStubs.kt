package android.content
import java.io.File
import java.io.OutputStream
class ContentValues {
  private val map = mutableMapOf<String,Any>()
  fun put(key:String,v:String){ map[key]=v }
  fun put(key:String,v:Int){ map[key]=v }
}
open class Context(private val root:File=File(System.getProperty("java.io.tmpdir"),"r028fake")) {
  val applicationContext:Context get()=this
  val filesDir:File get()=File(root,"files").apply{mkdirs()}
  val cacheDir:File get()=File(root,"cache").apply{mkdirs()}
  val contentResolver=ContentResolver()
}
class ContentResolver {
 fun insert(uri:String,v:ContentValues):String?="test://audit"
 fun openOutputStream(uri:String,mode:String):OutputStream?=null
 fun update(uri:String,v:ContentValues,where:String?,args:Array<String>?):Int=1
 fun delete(uri:String,where:String?,args:Array<String>?):Int=1
}
