package com.byd.dolphin.drivealerts.automation
fun main() {
    fun allowed(a:Boolean,now:Long,last:Long,wake:Long)=IgnitionWakePolicy.decide(a,now,last,wake).allowed
    check(allowed(true,10_000,-1,-1)) // first ignition
    check(allowed(false,100,999_000,-1)) // Android truly rebooted
    check(!allowed(true,10_001,9_000,-1)) // repeated immediately
    check(!allowed(false,200_000,10_000,-1)) // time alone cannot re-arm
    check(allowed(false,200_000,10_000,190_000)) // paired BYD quickboot + ON
    check(!allowed(false,200_000,10_000,10_200)) // stale wake
    check(!allowed(false,220_000,10_000,50_000)) // wake too old
    check(!allowed(false,140_000,100_000,135_000)) // less than 2min since prior
    check(!allowed(false,300_000,10_000,305_000)) // future wake
    println("R028_IGNITION_WAKE_POLICY_9_CASES_PASS")
}
