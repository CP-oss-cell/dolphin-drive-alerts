package com.byd.dolphin.drivealerts.log
import android.content.Context
import java.io.File
import java.util.zip.ZipFile
fun main() {
  val root=File(System.getProperty("java.io.tmpdir"),"r028fake").apply { deleteRecursively();mkdirs() }
  val ctx=Context(root)
  IgnitionAuditJournal.record(ctx,"BOOT_RX","action=ACC_ON")
  IgnitionAuditJournal.record(ctx,"STEP_BLOCKED","reason=ADB_AUTH_REQUIRED")
  val snapshot=IgnitionAuditJournal.snapshot(ctx).toString(Charsets.UTF_8)
  check(snapshot.contains("BOOT_RX") && snapshot.contains("STEP_BLOCKED"))
  val result=IgnitionAuditJournal.exportRecent(ctx)
  check(result.isSuccess) { result.exceptionOrNull()?.message ?: "export failed" }
  val loc=result.getOrNull()!!
  ZipFile(loc).use { zip ->
    check(zip.size()==2)
    check(zip.getEntry("ignition_audit.jsonl")!=null)
    check(zip.getInputStream(zip.getEntry("ignition_audit.jsonl")).bufferedReader().readText().contains("BOOT_RX"))
  }
  println("R028_PERSISTENT_AUDIT_AND_RESCUE_ZIP_TEST_PASS")
}
