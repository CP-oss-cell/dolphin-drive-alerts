package org.json
class JSONObject {
  private val map = linkedMapOf<String,Any>()
  fun put(key:String,v:Any):JSONObject { map[key]=v;return this }
  override fun toString():String = "{"+map.entries.joinToString(",") { (k,v) ->
    val text=when(v) {is Number, is Boolean->v.toString();else->"\""+v.toString().replace("\\","\\\\").replace("\"","\\\"")+"\""}
    "\"$k\":$text"
  }+"}"
}
