package android.provider
object MediaStore {
 object MediaColumns {
  const val DISPLAY_NAME="name";const val MIME_TYPE="mime";
  const val RELATIVE_PATH="relative";const val IS_PENDING="pending"
 }
 object Downloads {const val EXTERNAL_CONTENT_URI="test://downloads"}
}
