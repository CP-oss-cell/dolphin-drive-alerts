package android.os
import java.io.File
object Build {object VERSION {const val SDK_INT=28}}
object SystemClock {fun elapsedRealtime():Long=System.currentTimeMillis()}
object Environment {
 const val DIRECTORY_DOWNLOADS="Downloads"
 fun getExternalStoragePublicDirectory(s:String):File=
   File(System.getProperty("java.io.tmpdir"),"r028fake/$s").apply{mkdirs()}
}
