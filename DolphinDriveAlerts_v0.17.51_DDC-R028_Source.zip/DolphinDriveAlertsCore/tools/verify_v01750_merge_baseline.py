#!/usr/bin/env python3
"""R026: source-only checks; Kotlin fixture compile below is not Android APK validation."""
from pathlib import Path
import re, subprocess, tempfile, shutil, hashlib
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/byd/dolphin/drivealerts'
read=lambda rel:(src/rel).read_text(encoding='utf-8')
diag=read('dpi/DdcReadOnlyDiagnostic.kt')
math=read('dpi/DdcDensityMath.kt')
ui=read('ui/AppPolicyActivity.kt')
dpi=read('dpi/TemporaryAppDpiController.kt')
workflow=(root/'.github/workflows/DolphinDriveAlerts_v0.17.50_DDC-R027_Source.yml').read_text()
build=(root/'app/build.gradle.kts').read_text()
checks={
 'version_unique': 'versionName = "0.17.50"' in build and 'versionCode = 76' in build,
 'oem_auto_dpi_guard_preserved': 'ThirdPartyDpiRules.isSystem(c,pkg)' in dpi and 'AUTO_SKIP_OEM_FOREGROUND' in dpi,
 'baseline_restore_journal': 'scheduleRestore(c,id,attempt+1)' in dpi,
 'no_vehicle_write_added': not any(x in diag+math for x in ['BYDAutoEnergyDevice.set','setVehicleCan','sendCanFrame']),
 'strict_read_only_commands': set(re.findall(r'read\(app, "([^"]+)"\)',diag))== {'wm size','dumpsys window windows','dumpsys activity activities'} and 'writeOnce' not in diag,
 'density_lookup_only': 'DisplaySettingsController.readDensity(app)' in diag and 'applyDensity' not in diag,
 'privacy_raw_not_logged': 'result.output' in diag and 'DDC_READ_ONLY' in diag and 'summary.replace' in diag,
 'camera_package_observed': 'com.byd.avc' in diag,
 'window_boundary_guard': 'firstOrNull { lines[it].contains("Window{") }' in diag,
 'ui_diagnostic_call': 'DdcReadOnlyDiagnostic.collect(applicationContext)' in ui and 'getOrElse' in ui,
 'no_bogus_causality': '원인 자동 진단' not in ui and '실제 빈공간 면적을 측정한 결과 아님' in diag,
 'source_workflow_sync': 'SOURCE_ZIP: DolphinDriveAlerts_v0.17.50_DDC-R027_Source.zip' in workflow,
 'gradle_installed': 'gradle/actions/setup-gradle@v4' in workflow and "gradle-version: '8.7'" in workflow,
 'no_missing_gradle_wrapper_run': './gradlew --no-daemon' not in workflow and 'gradle --no-daemon' in workflow,
 'full_sdk_build_gate': ':app:compileDebugKotlin' in workflow and ':app:assembleDebug' in workflow,
 'car_core_preserved': all((src/p).exists() for p in ['vehicle/ReferenceVehicleEventBridge.kt','vehicle/ModeNoticeCorrelator.kt','service/DrivingAlertService.kt','automation/AutoSplitBehaviorEngine.kt','audio/AlertAudioPlayer.kt']),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
assert all(checks.values()), 'R026 source regression failed'
if shutil.which('kotlinc') and shutil.which('java'):
  with tempfile.TemporaryDirectory(prefix='r026-kt-') as td:
    tmp=Path(td)
    (tmp/'Stubs.kt').write_text("""package android.content
open class Context { val applicationContext: Context get() = this }
""")
    (tmp/'Stubs2.kt').write_text("""package com.byd.dolphin.drivealerts.dpi
import android.content.Context
object AuthorizedAdbRuntime {
 enum class State { READY, DENIED }
 data class ShellResult(val success:Boolean, val exitCode:Int, val output:String)
 data class Report(val state:State, val result:ShellResult)
 val responses=mapOf(
  "wm size" to "Physical size: 1280x720\\nOverride size: 1280x720",
  "dumpsys window windows" to "Window{0 u0 com.android.launcher3/.Launcher}\\nmFrame=[0,0][1280,720]\\nWindow{1 u0 com.byd.avc/.Camera}\\nmFrame=[0,0][1280,720]",
  "dumpsys activity activities" to "mResumedActivity: ActivityRecord{ u0 com.android.launcher3/.Launcher windowingMode=fullscreen }"
 )
 fun read(c:Context, command:String, timeoutMs:Long=7000L):Report {
   require(command in responses)
   return Report(State.READY, ShellResult(true, 0, responses.getValue(command)))
 }
}
object DisplaySettingsController {
 data class DensitySnapshot(val physical:Int?,val override:Int?)
 fun readDensity(c:Context) = DensitySnapshot(160,120)
}
""")
    (tmp/'Log.kt').write_text("""package com.byd.dolphin.drivealerts.util
object CoreLog { fun i(tag:String, msg:String) {} }
""")
    (tmp/'Fixture.kt').write_text("""package fixtures
import com.byd.dolphin.drivealerts.dpi.*
import android.content.Context
fun main(){
 require(DdcDensityMath.ratio(160,120)=="75.0%")
 require(DdcDensityMath.ratio(160,140)=="87.5%")
 require(DdcDensityMath.ratio(0,140)=="UNKNOWN")
 val txt=DdcReadOnlyDiagnostic.collect(Context())
 require("75.0%" in txt && "1280x720" in txt && "com.byd.avc" in txt)
 require("WINDOW_OR_VIEW_OR_SURFACE_UNKNOWN" in txt)
 println("R026_KOTLIN_DIAGNOSTIC_FIXTURE_PASS")
}
""")
    cmd=['kotlinc',str(src/'dpi/DdcReadOnlyDiagnostic.kt'),str(src/'dpi/DdcDensityMath.kt'),str(tmp/'Stubs.kt'),str(tmp/'Stubs2.kt'),str(tmp/'Log.kt'),str(tmp/'Fixture.kt'),'-include-runtime','-d',str(tmp/'test.jar')]
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=70)
    assert p.returncode == 0,p.stdout+p.stderr
    q=subprocess.run(['java','-jar',str(tmp/'test.jar')],capture_output=True,text=True,timeout=10)
    assert q.returncode == 0,q.stdout+q.stderr
    print(q.stdout.strip())
print('MERGE_R026_GATES_PASS',len(checks))
