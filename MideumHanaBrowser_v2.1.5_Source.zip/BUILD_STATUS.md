# 믿음하나 브라우저 v2.1.5 소스 빌드 상태

- 기반: v2.1.4 전체 소스, v2.1.5 / versionCode 11.
- 최종 변경: 백업/복원, 영상 감지, 다운로드 재시도/복구, 탭 저메모리 정리, 상단바 최적화, 폴드 전환, 완료 파일 열기·공유.
- 앱 ID/Debug 자동 서명/개인 키 불필요 방식 유지.
- 로컬 검증 대상: Java 문법, Android XML, JS node 검증 및 DOM 영상 감지 실행 시뮬레이션, 기존/신규 회귀 테스트, Range/HLS checkpoint Java 독립 테스트, 패키지 ZIP/YML SHA256 및 추출 검증.
- APK `assembleDebug` 및 Android 스마트폰에서의 동작 검증: 이 환경에 Android SDK/Gradle이 없어 실행하지 못함. GitHub Actions에서 확인 필요.
