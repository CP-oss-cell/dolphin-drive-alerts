/* Same-origin top-document scan only. No JavaScript interface exposed to untrusted iframes.
   Results are hints: DRM/blob media cannot be downloaded from these URLs. */
(function () {
  'use strict';
  var media = [];
  var seen = Object.create(null);
  function collect(url, source, width, height, duration, playing, adHint) {
    try {
      if (!url || /^(blob|data|javascript):/i.test(url)) return;
      var resolved = new URL(url, document.baseURI);
      if (!/^https?:$/.test(resolved.protocol)) return;
      var href = resolved.href;
      if (href.length > 4096) return;
      var w = Math.max(0, Math.round(width || 0));
      var h = Math.max(0, Math.round(height || 0));
      var seconds = Math.max(0, Math.round(isFinite(duration) ? duration : 0));
      if (Object.prototype.hasOwnProperty.call(seen, href)) {
        // A resource may be seen before its <video> begins playing. Promote that same
        // entry instead of keeping the stale, low-confidence network observation.
        var old = media[seen[href]];
        old.source = Math.max(old.source, source);
        old.width = Math.max(old.width, w);
        old.height = Math.max(old.height, h);
        old.duration = Math.max(old.duration, seconds);
        old.playing = old.playing || !!playing;
        old.adHint = old.adHint || !!adHint;
        return;
      }
      if (media.length >= 75) return;
      seen[href] = media.length;
      media.push({url:href, source:source, width:w, height:h,
        duration:seconds, playing:!!playing, adHint:!!adHint});
    } catch (e) { /* invalid or inaccessible URL */ }
  }
  try {
    if (window !== window.top) return JSON.stringify({page:location.href,videos:[]});
    // Network entries first: a subsequently visible/playing player promotes them.
    var entries = performance.getEntriesByType('resource');
    for (var k = Math.max(0, entries.length - 160); k < entries.length; k++) {
      var url = entries[k].name;
      if (/\.(m3u8|mp4|m4v|mov|webm)(?:[?#]|$)/i.test(url))
        collect(url, 1, 0, 0, 0, false, false);
    }
    var videos = document.querySelectorAll('video');
    for (var i = 0; i < videos.length && i < 40; i++) {
      var v = videos[i];
      var rect = v.getBoundingClientRect();
      var visible = rect.width >= 180 && rect.height >= 100 && rect.bottom > 0
        && rect.top < innerHeight;
      var playing = !v.paused && !v.ended
        && (typeof v.readyState !== 'number' || v.readyState > 1);
      if (!visible && !playing) continue;
      var context = typeof v.closest === 'function' ?
        v.closest('[class*="advert"], [id*="advert"], [class*="preroll"], [data-ad]') : null;
      var adHint = !!context;
      var source = playing ? 3 : 2;
      var width = v.videoWidth || rect.width || 0;
      var height = v.videoHeight || rect.height || 0;
      collect(v.currentSrc || v.src, source, width, height, v.duration, playing, adHint);
      var children = v.querySelectorAll('source[src]');
      for (var j = 0; j < children.length && j < 8; j++)
        collect(children[j].src, source, width, height, v.duration, playing, adHint);
    }
  } catch (e) { /* site-specific DOM may be inaccessible */ }
  media.sort(function (a,b) { return b.source - a.source; });
  return JSON.stringify({page:location.href,videos:media});
})();
