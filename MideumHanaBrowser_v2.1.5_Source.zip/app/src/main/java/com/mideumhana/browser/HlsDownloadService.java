package com.mideumhana.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * User-initiated, non-DRM video downloads. Both direct files and plain MPEG-TS HLS use
 * private, durable staging files. No cookie, token or authorization header is persisted.
 * Stop retains the verified local checkpoint; "resume" validates the remote version.
 */
public final class HlsDownloadService extends Service {
    private static final String CHANNEL = "mideumhana_downloads";
    static final String ACTION_CANCEL = "com.mideumhana.browser.CANCEL_DOWNLOAD";
    private static final int NOTIFICATION_ID = 8901;
    private static final int MAX_MANIFEST_BYTES = 4 * 1024 * 1024;
    private static final int MAX_NETWORK_ATTEMPTS = 3;
    /** Retry only transient transport/HTTP errors; never DRM, authentication or integrity failures. */
    private static final class TransientNetworkException extends IOException {
        TransientNetworkException(String message) { super(message); }
    }
    private static void requireSuccess(int code) throws Exception {
        if (code == 401 || code == 403)
            throw new Exception("파일 접근 권한이 만료됐습니다. 사이트에서 새 주소로 다시 받으세요 (" + code + ")");
        if (code == 408 || code == 429 || (code >= 500 && code <= 599))
            throw new TransientNetworkException("서버 일시 오류 " + code);
        if (code < 200 || code >= 300) throw new Exception("영상 서버 응답 " + code);
    }
    private static boolean retryable(Exception e) {
        return e instanceof IOException;
    }

    private static final Set<String> ACTIVE = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final ConcurrentHashMap<String, AtomicBoolean> cancels = new ConcurrentHashMap<>();
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final AtomicInteger pending = new AtomicInteger();
    private NotificationManager notifications;

    static boolean isJobActive(String id) { return ACTIVE.contains(id); }
    static void discardStaging(android.content.Context context, String id) {
        if (id == null || !id.matches("[a-z0-9-]{10,90}")) return;
        File stage = new File(partialDir(context), id + ".part");
        if (stage.exists()) stage.delete();
    }

    private static File partialDir(android.content.Context context) {
        File home = context.getExternalFilesDir(null);
        if (home == null) home = context.getFilesDir();
        return new File(home, "partial_downloads");
    }

    @Override public void onCreate() {
        super.onCreate();
        notifications = getSystemService(NotificationManager.class);
        notifications.createNotificationChannel(new NotificationChannel(
                CHANNEL, "영상 다운로드", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_CANCEL.equals(intent.getAction())) {
            String id = intent.getStringExtra("id");
            AtomicBoolean flag = cancels.get(id);
            if (flag != null) flag.set(true);
            return START_NOT_STICKY;
        }
        String id = intent.getStringExtra("id");
        if (id == null || !id.matches("[a-z0-9-]{10,90}")) return START_NOT_STICKY;
        JSONObject record = DownloadStore.get(this, id);
        if (record == null || !record.optString("type").startsWith("service-")) return START_NOT_STICKY;
        if (!MediaDetector.validWebUrl(record.optString("url"))) return START_NOT_STICKY;
        if (ACTIVE.contains(id)) return START_NOT_STICKY;
        ACTIVE.add(id);
        cancels.put(id, new AtomicBoolean(false));
        pending.incrementAndGet();
        startForeground(NOTIFICATION_ID, notice("다운로드 준비 중", 0, true));
        jobs.execute(() -> executeJob(id));
        return START_NOT_STICKY;
    }

    private void executeJob(String id) {
        String name = "영상";
        try {
            JSONObject item = DownloadStore.get(this, id);
            if (item == null) throw new CancellationException("삭제된 작업");
            name = item.optString("name", "영상");
            check(id);
            reportAt = 0;
            lastMeasureAt = 0;
            lastMeasureBytes = 0;
            DownloadStore.patch(this, id, "state", "RUNNING", "status", "다운로드 중");
            String url = item.optString("url");
            String referer = item.optString("referer");
            String ua = item.optString("ua");
            String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
            Source source = new Source(url, cookie, referer, ua);
            File stage = stageFile(id);
            for (int attempt = 1; attempt <= MAX_NETWORK_ATTEMPTS; attempt++) {
                check(id);
                try {
                    if ("service-hls".equals(item.optString("type")))
                        downloadHls(id, source, stage);
                    else downloadDirect(id, source, stage);
                    break;
                } catch (Exception failure) {
                    if (!retryable(failure) || attempt >= MAX_NETWORK_ATTEMPTS) throw failure;
                    DownloadStore.patch(this, id, "state", "RETRY_WAIT", "status",
                            "네트워크 오류 · 자동 재시도 " + (attempt + 1) + "/" + MAX_NETWORK_ATTEMPTS);
                    // Never busy-loop on unreachable hosts. Cancellation can interrupt waiting.
                    for (int t = 0; t < attempt * 3; t++) {
                        check(id);
                        Thread.sleep(500L);
                    }
                    check(id);
                    DownloadStore.patch(this, id, "state", "RUNNING", "status", "다운로드 재개 중");
                }
            }
            check(id);
            // Keep stage intact if a selected SAF provider rejects the final copy.
            item = DownloadStore.get(this, id);
            if (item == null) throw new CancellationException("삭제된 작업");
            publish(id, stage, item.optString("folder"), item.optString("name"),
                    "service-hls".equals(item.optString("type")) ? "video/mp2t" : MediaTypes.fromFileName(item.optString("name")));
            DownloadStore.patch(this, id, "state", "COMPLETED", "status", "완료",
                    "progress", "100", "speed", "0", "eta", "0");
            // Remove private cache only after the output URI is known and committed.
            stage.delete();
            notifications.notify(completedNoticeId(id), notice("다운로드 완료: " + name, 100, false, id));
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            JSONObject item = DownloadStore.get(this, id);
            if (item != null) DownloadStore.patch(this, id, "state", "PAUSED",
                    "status", "중지됨 · 이어받기 가능", "speed", "0", "eta", "-1");
        } catch (CancellationException cancelled) {
            JSONObject item = DownloadStore.get(this, id);
            if (item != null) DownloadStore.patch(this, id, "state", "PAUSED",
                    "status", "중지됨 · 이어받기 가능", "speed", "0", "eta", "-1");
        } catch (Exception failure) {
            JSONObject item = DownloadStore.get(this, id);
            String reason = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
            if (reason.length() > 100) reason = reason.substring(0, 100);
            if (item != null) DownloadStore.patch(this, id, "state", "FAILED", "status", "실패: " + reason,
                    "speed", "0", "eta", "-1");
            notifications.notify(completedNoticeId(id), notice("실패: " + reason, 0, false));
        } finally {
            ACTIVE.remove(id);
            cancels.remove(id);
            if (pending.decrementAndGet() == 0) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                stopSelf();
            }
        }
    }

    private File stageFile(String id) throws Exception {
        File dir = partialDir(this);
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("임시 저장 폴더 생성 실패");
        return new File(dir, id + ".part");
    }

    private void check(String id) {
        AtomicBoolean flag = cancels.get(id);
        if (flag != null && flag.get()) throw new CancellationException("일시 중지");
        if (Thread.currentThread().isInterrupted()) throw new CancellationException("서비스 중단");
    }

    private int completedNoticeId(String id) {
        return NOTIFICATION_ID + 10 + ((id.hashCode() & Integer.MAX_VALUE) % 100000);
    }
    private Notification notice(String text, int percent, boolean active) {
        return notice(text, percent, active, null);
    }
    private Notification notice(String text, int percent, boolean active, String completedId) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent click = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(getString(R.string.app_name)).setContentText(text)
                .setContentIntent(click).setOnlyAlertOnce(true).setOngoing(active);
        if (active) b.setProgress(100, percent, percent <= 0);
        else b.setAutoCancel(true);
        if (completedId != null) {
            Intent file = new Intent(this, MainActivity.class);
            file.setAction(MainActivity.ACTION_DOWNLOAD_FILE);
            file.putExtra("download_id", completedId);
            file.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent fileIntent = PendingIntent.getActivity(this,
                    completedNoticeId(completedId) * 2, file,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Intent send = new Intent(this, MainActivity.class);
            send.setAction(MainActivity.ACTION_SHARE_FILE);
            send.putExtra("download_id", completedId);
            send.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent shareIntent = PendingIntent.getActivity(this,
                    completedNoticeId(completedId) * 2 + 1, send,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_view,
                    "파일 열기", fileIntent).build());
            b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_share,
                    "파일 공유", shareIntent).build());
        }
        return b.build();
    }

    private static final class Source {
        final URL address;
        final String host;
        final String cookie, referer, ua;
        Source(String url, String cookie, String referer, String ua) throws Exception {
            this.address = new URL(url);
            this.host = address.getHost();
            this.cookie = cookie;
            this.referer = referer;
            this.ua = ua;
        }
    }
    private HttpURLConnection open(URL url, Source source, long offset, String validator) throws Exception {
        URL current = url;
        for (int redirect = 0; redirect <= 5; redirect++) {
            String scheme = current.getProtocol().toLowerCase(Locale.ROOT);
            if (!"https".equals(scheme) && !"http".equals(scheme))
                throw new Exception("HTTP(S) 영상 주소만 지원합니다");
            // Never silently downgrade a secure source to plain HTTP.
            if ("https".equalsIgnoreCase(url.getProtocol()) && !"https".equals(scheme))
                throw new Exception("안전하지 않은 HTTP 리다이렉트 차단");
            HttpURLConnection c = (HttpURLConnection) current.openConnection();
            c.setConnectTimeout(18000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (source.ua != null && !source.ua.isEmpty())
                c.setRequestProperty("User-Agent", source.ua);
            if (MediaDetector.validWebUrl(source.referer))
                c.setRequestProperty("Referer", source.referer);
            // Explicit redirect handling prevents source cookies being copied to a CDN.
            if (current.getHost().equalsIgnoreCase(source.host) &&
                    source.cookie != null && !source.cookie.isEmpty())
                c.setRequestProperty("Cookie", source.cookie);
            if (offset > 0) {
                c.setRequestProperty("Range", "bytes=" + offset + "-");
                if (validator != null && !validator.isEmpty())
                    c.setRequestProperty("If-Range", validator);
            }
            int status = c.getResponseCode();
            if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                String redirectTo = c.getHeaderField("Location");
                c.disconnect();
                if (redirectTo == null || redirectTo.isEmpty())
                    throw new Exception("영상 서버 이동 주소를 찾을 수 없습니다");
                current = new URL(current, redirectTo);
                continue;
            }
            return c;
        }
        throw new Exception("영상 주소 리다이렉트가 너무 많습니다");
    }
    private static String strongValidator(String etag, String modified) {
        return etag != null && !etag.isEmpty() && !etag.startsWith("W/") ? etag
                : modified == null ? "" : modified;
    }
    private static long contentRangeTotal(String value, long offset) throws Exception {
        return TransferIntegrity.contentRangeTotal(value, offset);
    }
    private static String sha256(String content) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(content.getBytes(StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder();
        for (byte value : digest) b.append(String.format(Locale.ROOT, "%02x", value & 255));
        return b.toString();
    }
    private long reportAt = 0;
    private long lastMeasureAt = 0;
    private long lastMeasureBytes = 0;
    private void report(String id, String title, long bytes, long total, int segmentPercent) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - reportAt < 850 && (segmentPercent < 0 || segmentPercent < 99)) return;
        long interval = lastMeasureAt == 0 ? 0 : now - lastMeasureAt;
        long speed = interval > 0 ? Math.max(0, (bytes - lastMeasureBytes) * 1000L / interval) : 0;
        long eta = total > 0 && speed > 0 ? Math.max(0, (total - bytes) / speed) : -1;
        int percent = total > 0 ? (int) Math.min(99, bytes * 100L / total)
                : Math.max(0, segmentPercent);
        DownloadStore.patch(this, id, "state", "RUNNING", "status", "다운로드 중",
                "bytes", Long.toString(bytes), "total", Long.toString(total),
                "speed", Long.toString(speed), "eta", Long.toString(eta),
                "progress", Integer.toString(percent));
        notifications.notify(NOTIFICATION_ID, notice(title, percent, true));
        reportAt = now;
        lastMeasureAt = now;
        lastMeasureBytes = bytes;
    }

    /** Direct HTTP Range resume with If-Range and strict 206 / entity validation. */
    private void downloadDirect(String id, Source source, File stage) throws Exception {
        JSONObject old = DownloadStore.get(this, id);
        long offset = stage.exists() ? stage.length() : 0;
        String oldTag = old.optString("etag");
        String oldMod = old.optString("modified");
        long recordedTotal = old.optLong("total", -1);
        String validator = strongValidator(oldTag, oldMod);
        if (offset > 0 && (validator.isEmpty() || offset > recordedTotal && recordedTotal >= 0)) {
            // Without a validator, a changed video could corrupt appended data.
            offset = 0;
            DownloadStore.patch(this, id, "status", "서버 검증 정보 없음 · 안전하게 처음부터 받기");
        }
        if (offset > 0 && recordedTotal > 0 && offset == recordedTotal && !validator.isEmpty())
            return; // Previously received complete file; a prior final publication failed.
        HttpURLConnection c = open(source.address, source, offset, validator);
        int code = c.getResponseCode();
        try { requireSuccess(code); } catch (Exception failed) { c.disconnect(); throw failed; }
        boolean append = offset > 0 && code == 206;
        long total;
        if (append) {
            total = contentRangeTotal(c.getHeaderField("Content-Range"), offset);
            String latestTag = c.getHeaderField("ETag");
            String latestMod = c.getHeaderField("Last-Modified");
            if (!TransferIntegrity.validatorMatches(oldTag, oldMod, latestTag, latestMod) ||
                    (recordedTotal > 0 && total > 0 && total != recordedTotal)) {
                c.disconnect(); throw new Exception("서버 파일이 변경됐습니다. 처음부터 다시 받기를 선택하세요");
            }
        } else {
            if (code == 206) total = contentRangeTotal(c.getHeaderField("Content-Range"), 0);
            else total = c.getContentLengthLong();
            offset = 0;
            DownloadStore.patch(this, id, "etag", c.getHeaderField("ETag") == null ? "" : c.getHeaderField("ETag"),
                    "modified", c.getHeaderField("Last-Modified") == null ? "" : c.getHeaderField("Last-Modified"),
                    "bytes", "0", "total", Long.toString(total));
        }
        String ct = c.getContentType();
        if ("service-image".equals(old.optString("type")) && ct != null
                && !ct.toLowerCase(Locale.ROOT).startsWith("image/")
                && !ct.toLowerCase(Locale.ROOT).startsWith("application/octet-stream")
                && !ct.toLowerCase(Locale.ROOT).startsWith("binary/octet-stream")) {
            c.disconnect(); throw new Exception("이미지가 아닌 응답을 받았습니다: " + ct);
        }
        if ("service-image".equals(old.optString("type"))) {
            // CDNs often omit an extension or serve AVIF/WEBP from a .jpg URL.
            // Match the published filename/MIME to the actual response when known.
            String suffix = MediaTypes.imageSuffixForContentType(ct);
            String original = old.optString("name");
            if (!suffix.isEmpty() && !MediaTypes.fromFileName(original).equals(
                    MediaTypes.fromFileName("image" + suffix))) {
                int dot = original.lastIndexOf('.');
                String stem = dot > 0 ? original.substring(0, dot) : original;
                DownloadStore.patch(this, id, "name", DownloadStore.safeFileName(stem + suffix));
            }
        }
        if (ct != null && (ct.toLowerCase(Locale.ROOT).startsWith("text/html") ||
                ct.toLowerCase(Locale.ROOT).contains("application/json"))) {
            c.disconnect(); throw new Exception("사이트가 파일 대신 로그인/웹페이지를 반환했습니다");
        }
        final long replyLength = c.getContentLengthLong();
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(stage, append)) {
            byte[] buf = new byte[65536];
            long bytes = offset;
            int n;
            while ((n = in.read(buf)) != -1) {
                check(id);
                out.write(buf, 0, n);
                bytes += n;
                report(id, "영상 받는 중", bytes, total, -1);
            }
            out.getFD().sync();
            if (replyLength >= 0 && bytes - offset != replyLength)
                throw new Exception("서버가 선언한 응답 길이와 실제 다운로드가 다릅니다");
            if (total >= 0 && bytes != total)
                throw new Exception("서버 크기와 받은 데이터가 다릅니다 (이어받기 가능)");
            DownloadStore.patch(this, id, "bytes", Long.toString(bytes), "total", Long.toString(total));
        } finally { c.disconnect(); }
    }

    private String readManifest(URL url, Source source) throws Exception {
        HttpURLConnection c = open(url, source, 0, "");
        try {
            int status = c.getResponseCode();
            requireSuccess(status);
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (out.size() + n > MAX_MANIFEST_BYTES) throw new Exception("HLS 재생목록 크기 초과");
                    out.write(buf, 0, n);
                }
                String playlist = out.toString(StandardCharsets.UTF_8.name()).replace("\uFEFF", "");
                if (!playlist.trim().startsWith("#EXTM3U")) throw new Exception("HLS 재생목록이 아닙니다");
                return playlist;
            }
        } finally { c.disconnect(); }
    }
    private static final class Variant {
        final URL url; final long bitrate;
        Variant(URL u, long b) { url = u; bitrate = b; }
    }
    private List<Variant> variants(String playlist, URL base) throws Exception {
        List<Variant> result = new ArrayList<>();
        long pendingBitrate = -1;
        boolean separateAudio = false;
        for (String sourceLine : playlist.split("\\r?\\n")) {
            String line = sourceLine.trim();
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                pendingBitrate = 0;
                separateAudio = line.matches("(?i).*\\bAUDIO=\"[^\"]+\".*");
                Matcher m = Pattern.compile("(?:^|,)BANDWIDTH=(\\d+)")
                        .matcher(line.substring("#EXT-X-STREAM-INF:".length()));
                if (m.find()) pendingBitrate = Long.parseLong(m.group(1));
            } else if (pendingBitrate >= 0 && !line.isEmpty() && !line.startsWith("#")) {
                if (separateAudio) throw new Exception("분리된 오디오 HLS는 미지원 (무음 영상 방지)");
                result.add(new Variant(new URL(base, line), pendingBitrate));
                pendingBitrate = -1;
            }
        }
        return result;
    }
    private List<URL> segments(String playlist, URL base) throws Exception {
        if (!playlist.contains("#EXT-X-ENDLIST")) throw new Exception("실시간 HLS는 이어받기를 지원하지 않습니다");
        List<URL> result = new ArrayList<>();
        boolean expected = false;
        for (String sourceLine : playlist.split("\\r?\\n")) {
            String line = sourceLine.trim();
            if (line.startsWith("#EXT-X-KEY:") && !line.matches("^#EXT-X-KEY:METHOD=NONE(?:,.*)?$"))
                throw new Exception("암호화/DRM HLS는 지원하지 않습니다");
            if (line.startsWith("#EXT-X-MAP:") || line.startsWith("#EXT-X-BYTERANGE:"))
                throw new Exception("fMP4/부분 범위 HLS는 아직 지원하지 않습니다");
            if (line.startsWith("#EXT-X-DISCONTINUITY"))
                throw new Exception("구간별 포맷 변경 HLS는 안전한 결합을 위해 지원하지 않습니다");
            if (line.startsWith("#EXTINF:")) expected = true;
            else if (expected && !line.isEmpty() && !line.startsWith("#")) {
                result.add(new URL(base, line)); expected = false;
            }
            if (result.size() > 5000) throw new Exception("영상 조각 수가 너무 많습니다");
        }
        if (result.isEmpty()) throw new Exception("다운로드 가능한 영상 조각이 없습니다");
        return result;
    }
    /** HLS resume at the last fsync'ed complete TS segment, never mid-segment. */
    private void downloadHls(String id, Source source, File stage) throws Exception {
        URL location = source.address;
        String playlist = readManifest(location, source);
        for (int depth = 0; depth < 3; depth++) {
            List<Variant> options = variants(playlist, location);
            if (options.isEmpty()) break;
            Variant selected = options.get(0);
            for (Variant option : options) if (option.bitrate > selected.bitrate) selected = option;
            location = selected.url;
            playlist = readManifest(location, source);
        }
        if (!variants(playlist, location).isEmpty()) throw new Exception("HLS 재생목록이 지나치게 중첩됐습니다");
        List<URL> urls = segments(playlist, location);
        String fingerprint = sha256(location + "\n" + playlist);
        JSONObject journal = DownloadStore.get(this, id);
        int start = journal.optInt("segmentIndex", 0);
        long committed = journal.optLong("segmentBytes", 0L);
        if (!TransferIntegrity.keepHlsCheckpoint(journal.optString("playlistHash"),
                fingerprint, start, urls.size(), committed,
                stage.exists() ? stage.length() : -1)) {
            start = 0; committed = 0;
            DownloadStore.patch(this, id, "playlistHash", fingerprint,
                    "segmentIndex", "0", "segmentBytes", "0");
        }
        try (RandomAccessFile output = new RandomAccessFile(stage, "rw")) {
            output.setLength(committed); // A killed process might have left an unverified partial segment.
            output.seek(committed);
            for (int index = start; index < urls.size(); index++) {
                check(id);
                HttpURLConnection c = open(urls.get(index), source, 0, "");
                try {
                    int code = c.getResponseCode();
                    requireSuccess(code);
                    long expected = c.getContentLengthLong();
                    long count = 0;
                    try (InputStream in = c.getInputStream()) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            check(id);
                            output.write(buf, 0, n);
                            count += n;
                        }
                    }
                    if (expected >= 0 && expected != count) throw new Exception("HLS 영상 조각 크기 불일치");
                    output.getFD().sync();
                    committed += count;
                    int percent = (int) ((index + 1L) * 99 / urls.size());
                    DownloadStore.patch(this, id, "segmentIndex", Integer.toString(index + 1),
                            "segmentBytes", Long.toString(committed),
                            "playlistHash", fingerprint, "progress", Integer.toString(percent));
                    DownloadStore.patch(this, id, "estimated", "true");
                    long approximateTotal = Math.max(committed,
                            committed / (index + 1) * urls.size());
                    report(id, "영상 조각 " + (index + 1) + "/" + urls.size(),
                            committed, approximateTotal, percent);
                } finally { c.disconnect(); }
            }
        }
    }
    private void publish(String id, File stage, String folder, String filename, String mime) throws Exception {
        if (!stage.isFile() || stage.length() <= 0)
            throw new Exception("받은 영상 데이터가 비어 있습니다");
        StorageTarget.FileOutput target = StorageTarget.create(this, folder, filename, mime);
        DownloadStore.patch(this, id, "targetUri", target.uri.toString());
        boolean ready = false;
        try {
            long length = 0;
            try (InputStream in = new FileInputStream(stage); OutputStream out = StorageTarget.open(this, target)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) != -1) {
                    check(id);
                    out.write(buf, 0, n);
                    length += n;
                }
                out.flush();
            }
            if (length != stage.length()) throw new Exception("저장된 영상 크기 검증 실패");
            StorageTarget.finish(this, target);
            DownloadStore.setUri(this, id, target.uri.toString());
            DownloadStore.patch(this, id, "name", StorageTarget.actualName(this, target.uri, filename),
                    "targetUri", "");
            ready = true;
        } finally {
            if (!ready) {
                StorageTarget.delete(this, target);
                DownloadStore.patch(this, id, "targetUri", "");
            }
        }
    }

    @Override public void onTimeout(int startId, int fgsType) {
        for (AtomicBoolean value : cancels.values()) value.set(true);
        jobs.shutdownNow();
        stopSelf();
    }
    @Override public void onDestroy() {
        jobs.shutdownNow();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
