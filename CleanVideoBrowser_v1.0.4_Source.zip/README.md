# CleanVideoBrowser v1.0.4

개인용 광고 SDK 없는 브라우저 + 동영상 URL 감지/다운로드 앱입니다. 자체 동영상 플레이어는 포함하지 않습니다.

## 무엇을 수정했나요?

2026-11-03에 수신한 `logs_no1.zip`에서 Java 컴파일 오류 2개가 발생했습니다.

- `MainActivity.java:15`의 `android.os.WindowInsets`를 `android.view.WindowInsets`로 수정했습니다.
- `MainActivity.java:85`에서 발생한 `WindowInsets.Type.systemBars()`의 타입 인식 실패는 동일 원인으로 수정했습니다.
- 페이지 이동 시 이전 영상 감지 숫자가 남는 문제를 수정했습니다.
- 같은 잘못된 import가 다시 들어오면 정적 검사가 실패하도록 회귀 검사에 추가했습니다.
- 프로젝트 버전 `1.0.4` (versionCode 5)로 증가했습니다.

## GitHub 업로드 방법

바깥 통합 ZIP을 **한 번** 풀면 정확히 2개 파일이 나옵니다.

1. `CleanVideoBrowser_v1.0.4_Source.zip` — **압축을 풀지 말고** GitHub 저장소 최상위(root)에 업로드하세요.
2. `CleanVideoBrowser_v1.0.4_Source.yml` — `.github/workflows/CleanVideoBrowser_v1.0.4_Source.yml` 경로에 업로드하세요.
3. GitHub Actions에서 **CleanVideoBrowser v1.0.4 APK**를 실행하세요. 성공 시 `CleanVideoBrowser_v1.0.4_APK` 아티팩트를 내려받습니다.

기존 `.github/workflows/build-apk.yml` 및 구버전 `CleanVideoBrowser_v1.0.x_Source.yml`은 **삭제해야** 오래된 버전이 중복 빌드되지 않습니다. 저장소의 다른 앱 워크플로는 건드리지 마세요.

## 기능과 한계

- WebView 웹 브라우저, 사이트 이동/검색/즐겨찾기
- MP4 등 직접 영상 링크 탐지 및 DownloadManager 다운로드
- 비암호화 VOD MPEG-TS HLS(.m3u8) 다운로드, 화질 선택
- 자체 광고·분석 SDK 및 별도 동영상 플레이어 없음
- 저장: `Download/CleanVideo`, Android 10 (API29) 이상

웹사이트 자체 광고는 일부 표시될 수 있습니다. 모든 사이트의 보호/DRM 영상이나 암호화된 HLS 및 라이브 방송을 다운로드하지 않습니다. 권한이 있는 콘텐츠만 저장하세요.

## 테스트 수준

이번 로그에서 Android SDK/Gradle 설정 및 리소스 처리까지 성공한 것은 확인했습니다. 이 패키지는 Java 파서/정적 검증 및 ZIP 자동 추출 시뮬레이션을 통과했으나, 현 실행 환경에는 Android SDK가 없어 **APK 컴파일 및 실기기 동작 성공은 아직 확인하지 못했습니다.**
