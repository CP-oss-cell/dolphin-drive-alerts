package com.dolphin.goodlock.probe;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** One-install, candidate-based, consent-gated inspector. No OEM code invocation/write. */
public final class MainActivity extends Activity {
    private final String PREF_KEY="guided_report";
    private static final int REQUEST_PLAN_JSON=1303;
    private ProbeEngine baseline;
    private CandidateEngine candidatesEngine;
    private JSONObject report;
    private JSONArray discovered=new JSONArray();
    private JSONArray timeline=new JSONArray();
    private Spinner candidateSpinner, actionSpinner, verdictSpinner;
    private EditText notes;
    private TextView status, details;
    private boolean busy=false;
    private int lastSelected=-1;
    private String lastInspectedId="";
    private final ArrayList<String> candidateLabels = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        baseline=new ProbeEngine(this);
        candidatesEngine=new CandidateEngine(this);
        try {
            String old=getPreferences(MODE_PRIVATE).getString(PREF_KEY,"");
            report=old.isEmpty()?fresh():new JSONObject(old);
            CandidateEngine.put(report,"schema","DolphinGoodLockProbe/0.3");
            timeline=report.optJSONArray("timeline");
            if (timeline==null)timeline=new JSONArray();
            lastInspectedId=report.optString("last_inspected","");
            discovered=report.optJSONArray("candidates");
            if (discovered==null)discovered=new JSONArray();
        } catch(Exception e){report=fresh();}
        buildUi();
        refreshCandidates();
    }

    private static String timestamp(){return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",Locale.KOREA).format(new Date());}
    private JSONObject fresh(){
        JSONObject j=new JSONObject();
        CandidateEngine.put(j,"schema","DolphinGoodLockProbe/0.3");
        CandidateEngine.put(j,"type","one_install_guided_probe");
        CandidateEngine.put(j,"started",timestamp());
        CandidateEngine.put(j,"safety","NO_ROOT_NO_ADB_NO_OEM_WRITE_NO_VEHICLE_SIGNAL_NO_INTERNET");
        CandidateEngine.put(j,"baseline","NOT_RUN");
        CandidateEngine.put(j,"candidates",new JSONArray());
        CandidateEngine.put(j,"timeline",new JSONArray());
        return j;
    }
    private void persist(){
        CandidateEngine.put(report,"candidates",discovered);
        CandidateEngine.put(report,"timeline",timeline);
        getPreferences(MODE_PRIVATE).edit().putString(PREF_KEY,report.toString()).apply();
    }
    private void event(String phase,JSONObject candidate,String action,String state,JSONObject evidence){
        JSONObject j=new JSONObject();
        CandidateEngine.put(j,"at",timestamp());CandidateEngine.put(j,"phase",phase);
        CandidateEngine.put(j,"candidate_id",candidate==null?"NONE":candidate.optString("id"));
        CandidateEngine.put(j,"candidate_kind",candidate==null?"NONE":candidate.optString("kind"));
        CandidateEngine.put(j,"candidate_target",candidate==null?"NONE":candidate.optString("target"));
        CandidateEngine.put(j,"action",action);CandidateEngine.put(j,"state",state);
        CandidateEngine.put(j,"evidence",evidence==null?new JSONObject():evidence);
        timeline.put(j);persist();
    }
    private LinearLayout panel(LinearLayout root){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(18,10,18,15);root.addView(p,new LinearLayout.LayoutParams(-1,-2));return p;
    }
    private TextView label(LinearLayout p,String t,int sp,boolean bold){
        TextView v=new TextView(this);v.setText(t);v.setTextSize(sp);
        v.setTextColor(Color.rgb(18,34,47));v.setPadding(0,7,0,7);
        if(bold)v.setTypeface(null, Typeface.BOLD);p.addView(v);return v;
    }
    private void button(LinearLayout p,String t,View.OnClickListener cb){
        Button b=new Button(this);b.setAllCaps(false);b.setText(t);b.setOnClickListener(cb);p.addView(b);
    }
    private Spinner spinner(LinearLayout p){
        Spinner s=new Spinner(this);p.addView(s,new LinearLayout.LayoutParams(-1,-2));return s;
    }
    private void buildUi(){
        ScrollView outer=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10,6,10,24);outer.addView(root);setContentView(outer);
        LinearLayout head=panel(root);
        label(head,"Dolphin Good Lock · 연속 검사 0.3",22,true);
        label(head,"설치 한 번 → 후보 탐색 → 후보 선택 → 다음 테스트 → 결과 저장",14,true);
        label(head,"정차(P)에서만 검사. 순정 HOME 교체·OEM APK 수정·차량 신호 송신·ADB/ROOT 사용·인터넷 전송 없음.",13,false);
        status=label(head,"상태: 준비됨. 후보 탐색부터 시작",14,true);

        LinearLayout gate=panel(root);
        label(gate,"★ V0.3 핵심 후속 검증 · 한 번에 검사",18,true);
        label(gate,"순정 HomeProvider/CardProvider 권한·서비스 선언·우리 앱 바로가기 고정 상태·위젯 지원 여부를 읽기 전용으로 조회합니다. OEM Provider는 호출하지 않습니다.",13,false);
        button(gate,"V0.3 권한·서비스·바로가기 5종 일괄 검사",v->runV03Gate(null));
        button(gate,"허용된 JSON 검사 플랜 선택 (재설치 없이 재시험)",v->selectV03Plan());
        button(gate,"V0.3 결과 간단 요약 보기",v->showV03GateSummary());

        LinearLayout p1=panel(root);
        label(p1,"① 모든 안전 후보 탐색",18,true);
        label(p1,"HOME·설정·위젯·바로가기·OEM 공개 구성요소를 한 번에 조회합니다. 실패 항목은 UNKNOWN으로 남깁니다.",13,false);
        button(p1,"1단계 실행 / 다시 스캔",v->scan());

        LinearLayout p2=panel(root);
        label(p2,"② 후보를 선택하고 실제 근거 확인",18,true);
        candidateSpinner=spinner(p2);
        button(p2,"선택한 후보 분석 → 3단계 활성화",v->inspectSelected());
        details=label(p2,"탐색을 하면 후보가 여기에 나타납니다.",12,false);

        LinearLayout p3=panel(root);
        label(p3,"③ 지금 찾은 경로의 다음 시험",18,true);
        actionSpinner=spinner(p3);
        button(p3,"선택한 다음 시험 실행",v->runNextAction());
        label(p3,"외부 화면 열기·아이콘 추가는 버튼을 눌렀을 때만 진행합니다. 위젯/바로가기는 승인창을 한번 더 표시합니다.",12,false);

        LinearLayout p4=panel(root);
        label(p4,"④ 홈에서 직접 본 결과 기록",18,true);
        verdictSpinner=spinner(p4);
        verdictSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"미확인/판정 보류","실차 화면에서 성공 확인","시도했지만 실패","지원 메뉴 없음/거부됨","안전 문제로 중단"}));
        notes=new EditText(this);notes.setMinLines(4);
        notes.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        notes.setHint("예: 선택 후보 C003. 홈 위젯 메뉴 있음/없음, 진단 위젯 실제 보임, 독바 편집/스크롤, 오류 메시지. 차량정보 실값 입력 불필요.");
        p4.addView(notes,new LinearLayout.LayoutParams(-1,190));
        button(p4,"현재 후보에 관찰 결과 저장 → 다른 후보도 계속 시험",v->saveObservation());

        LinearLayout p5=panel(root);
        label(p5,"⑤ 모든 단계 결과 통합 저장",18,true);
        button(p5,"전체 JSON Download 저장",v->saveJson());
        button(p5,"전체 JSON 복사",v->copyJson());
        label(p5,"새 APK 설치 없이 다른 후보로 돌아가 여러 번 시험할 수 있어요. JSON에는 기기 식별 정보가 포함될 수 있으므로 공개 GitHub에는 업로드하지 마세요.",12,false);
    }
    private void refreshCandidates(){
        candidateLabels.clear();
        for(int i=0;i<discovered.length();i++){
            JSONObject c=discovered.optJSONObject(i);
            if(c!=null)candidateLabels.add(c.optString("id")+" · "+c.optString("label"));
        }
        candidateSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,candidateLabels));
        candidateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View v,int pos,long id){
                if (pos!=lastSelected){ lastSelected=pos; actionsForCurrent(); }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        if(discovered.length()>0){actionsForCurrent();status.setText("이전 후보 "+discovered.length()+"개 복원. 2단계에서 후보를 선택하세요.");}
    }
    private JSONObject selected(){
        int idx=candidateSpinner.getSelectedItemPosition();
        return idx>=0 && idx<discovered.length()?discovered.optJSONObject(idx):null;
    }
    private void actionsForCurrent(){
        JSONObject c=selected();
        String[] opts=c==null?new String[]{"먼저 1단계를 실행하세요"}:candidatesEngine.suggestedActions(c);
        if(actionSpinner!=null)actionSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts));
    }
    private void selectV03Plan(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,REQUEST_PLAN_JSON);}
        catch(Exception e){status.setText("파일 선택을 열 수 없음: "+e.getClass().getSimpleName());}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=REQUEST_PLAN_JSON||result!=RESULT_OK||data==null||data.getData()==null)return;
        try(InputStream in=getContentResolver().openInputStream(data.getData())){
            if(in==null)throw new IllegalStateException("NO_INPUT_STREAM");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;
            while((n=in.read(buf))!=-1){
                if(bytes.size()+n>8192)throw new IllegalArgumentException("PLAN_TOO_LARGE");
                bytes.write(buf,0,n);
            }
            JSONObject plan=new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
            if(!"DolphinGoodLockPlan/0.3".equals(plan.optString("schema")))throw new IllegalArgumentException("WRONG_SCHEMA");
            JSONArray steps=plan.optJSONArray("steps");
            if(steps==null||steps.length()<1||steps.length()>5)throw new IllegalArgumentException("INVALID_STEPS_COUNT");
            java.util.HashSet<String> visited=new java.util.HashSet<>();
            for(int i=0;i<steps.length();i++){
                String key=steps.optString(i,"");
                if(!java.util.Arrays.asList("home_provider","card_provider","card_window_service","own_shortcut","own_widget").contains(key))
                    throw new IllegalArgumentException("UNSUPPORTED_STEP:"+key);
                if(!visited.add(key))throw new IllegalArgumentException("DUPLICATE_STEP:"+key);
            }
            runV03Gate(steps);
        }catch(Exception e){status.setText("검사 플랜 거부: "+e.getMessage());}
    }
    private void runV03Gate(JSONArray chosenSteps){
        if(busy)return; busy=true;status.setText("V0.3 OEM 읽기 전용 접근 게이트 검사 중...");
        new Thread(()->{
            JSONObject result;
            try{ result=chosenSteps==null?new AccessGateEngine(this).run():new AccessGateEngine(this).runPlan(chosenSteps); }
            catch(Exception e){ result=new JSONObject();CandidateEngine.put(result,"status","UNKNOWN_ERROR");CandidateEngine.put(result,"error",e.getClass().getSimpleName()); }
            final JSONObject data=result;
            runOnUiThread(()->{
                busy=false;CandidateEngine.put(report,"v03_access_gates",data);
                event("V03_GATE",null,"BATCH_PERMISSION_SERVICE_SHORTCUT_CHECK","READ_ONLY_GATES_RECORDED",data);
                showV03GateSummary();
            });
        },"goodlock-v03-access-gates").start();
    }
    private void showV03GateSummary(){
        JSONObject gate=report.optJSONObject("v03_access_gates");
        if(gate==null){status.setText("먼저 V0.3 검사를 실행하세요.");return;}
        StringBuilder b=new StringBuilder("V0.3 접근 게이트 결과 (실제 변경 허가 아님)\n");
        for(String key:new String[]{"home_provider","card_provider","card_window_service","own_shortcut","own_widget"}){
            JSONObject v=gate.optJSONObject(key);
            b.append(key).append(" : ").append(v==null?"UNKNOWN":v.optString("status")).append("\n");
        }
        details.setText(b.toString());status.setText("V0.3 5종 검사 기록 완료. 결과는 ⑤ 전체 JSON 저장에 자동 포함됩니다.");
    }
    private void scan(){
        if(busy)return;busy=true;status.setText("1단계: 읽기 전용 후보 탐색 중...");
        new Thread(()->{
            JSONObject base=baseline.runAll();JSONArray items=candidatesEngine.discover();
            runOnUiThread(()->{
                busy=false;CandidateEngine.put(report,"baseline",base);
                discovered=items;lastSelected=-1;lastInspectedId="";CandidateEngine.put(report,"last_inspected","");refreshCandidates();
                JSONObject info=new JSONObject();CandidateEngine.put(info,"candidate_count",items.length());
                event("STAGE1",null,"BATCH_DISCOVER","SOURCE_CANDIDATES_FOUND",info);
                status.setText("1단계 완료: "+items.length()+"개 후보. 2단계 후보 선택 가능.");
            });
        },"goodlock-discover").start();
    }
    private void inspectSelected(){
        JSONObject c=selected();if(c==null){status.setText("먼저 1단계 탐색을 실행하세요.");return;}
        JSONObject data=candidatesEngine.inspect(c);
        lastInspectedId=c.optString("id");CandidateEngine.put(report,"last_inspected",lastInspectedId);
        event("STAGE2",c,"SELECT_AND_INSPECT",data.optString("status"),data);
        details.setText(c.optString("label")+"\n"+data.toString());
        actionsForCurrent();
        status.setText("2단계 완료 · "+c.optString("id")+" · 다음 시험을 선택해 3단계 실행");
    }
    private void logAction(JSONObject c,String action,String result){
        JSONObject e=new JSONObject();CandidateEngine.put(e,"details",result);
        event("STAGE3",c,action,result,e);status.setText("3단계: "+result+" · 홈/팝업을 확인하고 4단계에 기록");
    }
    private void confirm(String message,Runnable yes){
        new AlertDialog.Builder(this).setTitle("사용자 확인 필요").setMessage(message)
            .setPositiveButton("진행",(d,w)->yes.run()).setNegativeButton("취소",(d,w)->{}).show();
    }
    private void runNextAction(){
        JSONObject c=selected();if(c==null){status.setText("후보를 먼저 선택하세요.");return;}
        if(!c.optString("id").equals(lastInspectedId)){status.setText("해당 후보의 2단계 분석을 먼저 실행하세요.");return;}
        int index=actionSpinner.getSelectedItemPosition();String kind=c.optString("kind"),target=c.optString("target");
        if(index<0){status.setText("다음 시험을 선택하세요.");return;}
        if("HOME".equals(kind) && index==0) {
            try {
                logAction(c,"OPEN_HOME","USER_SCREEN_OPEN_REQUESTED_NOT_VERIFIED");
                startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }catch(Exception e){logAction(c,"OPEN_HOME","FAILED_"+e.getClass().getSimpleName());}
            return;
        }
        if("WIDGET_OWN".equals(kind) && index==1){
            confirm("진단 위젯을 순정 홈에 추가하도록 요청합니다. 순정 홈에서 승인·거부를 선택할 수 있어요. 차량 설정이나 런처 파일은 변경하지 않습니다.",()->{
                try {
                    AppWidgetManager wm=AppWidgetManager.getInstance(this);
                    if(!wm.isRequestPinAppWidgetSupported()){logAction(c,"PIN_WIDGET","UNSUPPORTED_LAUNCHER");return;}
                    boolean ok=wm.requestPinAppWidget(new ComponentName(this,DiagnosticWidget.class),null,null);
                    logAction(c,"PIN_WIDGET",ok?"REQUEST_ACCEPTED_NOT_ACTUAL_PIN_PROOF":"REQUEST_REJECTED");
                }catch(Exception e){logAction(c,"PIN_WIDGET","UNKNOWN_"+e.getClass().getSimpleName());}
            });return;
        }
        if("SHORTCUT".equals(kind) && index==1){
            confirm("순정 홈에 이 진단 앱의 바로가기 아이콘을 추가하도록 요청합니다. 홈에서 추가를 승인하거나 취소할 수 있습니다.",()->{
                try {
                    ShortcutManager sm=(ShortcutManager)getSystemService(Context.SHORTCUT_SERVICE);
                    if(sm==null||!sm.isRequestPinShortcutSupported()){logAction(c,"PIN_SHORTCUT","UNSUPPORTED_LAUNCHER");return;}
                    Intent link=new Intent(this,MainActivity.class).setAction(Intent.ACTION_VIEW);
                    ShortcutInfo info=new ShortcutInfo.Builder(this,"goodlock_probe_diagnostic")
                        .setShortLabel("Good Lock 검사").setLongLabel("돌핀 Good Lock 연속 검사")
                        .setIcon(Icon.createWithResource(this,android.R.drawable.ic_menu_info_details))
                        .setIntent(link).build();
                    boolean ok=sm.requestPinShortcut(info,null);
                    logAction(c,"PIN_SHORTCUT",ok?"REQUEST_ACCEPTED_NOT_PIN_VERIFIED":"REQUEST_REJECTED");
                }catch(Exception e){logAction(c,"PIN_SHORTCUT","UNKNOWN_"+e.getClass().getSimpleName());}
            });return;
        }
        if("SETTINGS".equals(kind) && index==1){
            confirm("Android 공개 설정 화면을 엽니다. 설정값은 앱이 변경하지 않아요. 원하는 항목을 직접 확인한 뒤 뒤로 돌아오세요.",()->{
                try {
                    logAction(c,"OPEN_PUBLIC_SETTINGS","USER_SCREEN_OPEN_REQUESTED_NOT_VERIFIED");
                    startActivity(new Intent(target));
                }catch(Exception e){logAction(c,"OPEN_PUBLIC_SETTINGS","FAILED_"+e.getClass().getSimpleName());}
            });return;
        }
        JSONObject inspected=candidatesEngine.inspect(c);
        event("STAGE3",c,"RECHECK_OR_MANUAL",inspected.optString("status"),inspected);
        details.setText(c.optString("label")+"\n"+inspected.toString());
        status.setText("3단계 갱신: "+inspected.optString("status")+". 직접 확인한 내용은 4단계에 기록하세요.");
    }
    private void saveObservation(){
        JSONObject c=selected();if(c==null){status.setText("먼저 후보를 선택하세요.");return;}
        JSONObject o=new JSONObject();CandidateEngine.put(o,"verdict",verdictSpinner.getSelectedItem().toString());
        CandidateEngine.put(o,"notes",notes.getText().toString().trim());
        if(verdictSpinner.getSelectedItemPosition()==1 && notes.getText().toString().trim().isEmpty()){
            status.setText("성공으로 표시하려면 실제 본 화면·행동을 메모에 기록해주세요.");return;
        }
        event("STAGE4",c,"USER_OBSERVATION","USER_REPORTED_NOT_AUTOMATED_VERIFICATION",o);
        status.setText("4단계 저장: "+c.optString("id")+". 후보를 바꿔 계속 검사하거나 5단계로 내보내세요.");
        notes.setText("");verdictSpinner.setSelection(0);
    }
    private void copyJson(){
        persist();ClipboardManager mgr=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(mgr==null){status.setText("클립보드 접근 실패. Download 저장을 이용하세요.");return;}
        mgr.setPrimaryClip(ClipData.newPlainText("DolphinGoodLockProbe",report.toString()));
        status.setText("전체 JSON 복사 완료. 기기 정보가 있으므로 공개 저장소에 올리지 마세요.");
    }
    private void saveJson(){
        if(busy){status.setText("탐색이 끝난 뒤 저장해주세요.");return;}
        persist();String name="DolphinGoodLockGuided_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".json";
        Uri uri=null;
        try {
            ContentValues cv=new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE,"application/json");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/");
            cv.put(MediaStore.MediaColumns.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
            if(uri==null)throw new IllegalStateException("null_download_uri");
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new IllegalStateException("null_output_stream");
                out.write(report.toString(2).getBytes(StandardCharsets.UTF_8));
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);
            status.setText("저장 완료: Download/"+name+" / 후보 "+discovered.length()+"개, 기록 "+timeline.length()+"개");
        }catch(Exception e){
            if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
            status.setText("저장 오류: "+e.getClass().getSimpleName()+". JSON 복사 버튼을 쓰세요.");
        }
    }
}
