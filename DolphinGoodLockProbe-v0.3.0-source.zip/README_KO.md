# Dolphin Good Lock Probe 0.3 — 순정 런처 접근 경로 검사

Android 10 / SDK29 앱입니다. 순정 홈을 대체하지 않고, 런처 내부 Provider/서비스의 선언 및 **우리 앱 권한 보유 여부**와 자체 바로가기/위젯 상태를 읽기 전용으로 확인합니다.

- 앱 ID `com.dolphin.goodlock.probe.v03`: 기존 0.2와 별도 설치, 기존 앱 삭제 불필요.
- UI 버튼 `V0.3 권한·서비스·바로가기 5종 일괄 검사` → 결과 요약 → `⑤ 전체 JSON Download 저장`.
- JSON 검사 플랜을 불러와 이미 구현된 5종 검사 순서를 바꿀 수 있습니다. 8KB 이하, 1~5개, 중복/미허용 단계 불가. 임의 명령이나 OEM Provider 호출 금지.
- 기존 0.2의 단계 1~5 후보 검사/수동 관찰/JSON 저장 기능 유지.
- 차량 신호, 설정, 순정 홈, CardBar 데이터 변경/읽기 요청, ADB/root/network 권한 없음.
- Android CI 빌드/실차 작동은 별도 확인 필요. `tools/verify_source.py`는 정적 검사이며 SDK 컴파일을 대체하지 않음.
