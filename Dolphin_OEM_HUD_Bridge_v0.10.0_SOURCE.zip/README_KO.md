# Dolphin OEM HUD Bridge v0.10.0 — 순정 TMAP 우선

**최종 목적**: BYD 돌핀 순정 내비 `com.tmap.auto.byd`의 실제 TBT(회전 유형·회전까지 거리)를 ARIA/TPLAY HUD Q에 표시.
네이버지도·일반 TMAP·아틀란·카카오맵은 부가 지원이다.

## v0.10.0의 실제 변경

순정 TMAP의 `NaviService`는 AIDL Binder 서비스로 공개되지만(RE-004), 현재 74개 트랜잭션의 직접 반환/콜백 데이터에서 다음 회전 방향·거리 TBT 쌍이 입증되지 않았다. v0.10.0은 **읽기 전용 Binder 경계 진단**을 넣어 서비스 외부 접근 가능성부터 자동으로 구분한다. Binder 연결이 되더라도 TBT 수신 성공으로 표시하지 않는다.

- `OemTmapBinderProbe.java`: 서비스 설치·exported·permission 조사, Binder descriptor 자동 확인, 권한 오류/타임아웃 등 상태 분류. OEM 커스텀 트랜잭션 호출 없음.
- `research/HUD-RE-005/`: 2602/2606 순정 TMAP·DiCarServer·MCon K DEX 정적 교차 분석 근거와 재현 스크립트.
- 기존 MCon K 모델별 BLE 연결/설정 명령 및 다크 모드 보존.
- AutoNavi 호환 방송은 **순정 TMAP에서 송출된다는 증거 없음**으로 명확히 표시.

## 빌드

다운로드 받은 통합 ZIP에서 소스 ZIP과 YML을 꺼내 저장소에 올린다. 소스 ZIP은 **압축 해제하지 않고 저장소 루트**에 업로드한다. YML은 `.github/workflows/build-oem-hud-bridge.yml` 경로에 배치한다. Actions에서 `Build Dolphin OEM HUD Bridge v0.10.0 (ZIP + YML)` 실행 후, `DolphinOemHudBridge_v0.10.0_vc20.apk` 산출 여부를 확인한다.

## 현재 진행 상태

OEM 순정 TBT의 별도 앱 실시간 수신 경로 **미확정**. Binder descriptor 확인은 경계 진단에 불과하다. HUD GATT 쓰기 성공은 실제 HUD 표시 성공을 뜻하지 않는다. 미완성 기능을 완성이라 표시하지 않는다.
