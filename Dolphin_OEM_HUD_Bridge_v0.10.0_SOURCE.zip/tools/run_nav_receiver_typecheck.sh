#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/stubs"
python3 tools/create_dashboard_compile_stubs.py "$TMP/stubs" >/dev/null
python3 - "$TMP/stubs" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
(root/'com/dolphin/oemhud/BridgeLog.java').unlink(missing_ok=True)
extra={
'android/accessibilityservice/AccessibilityServiceInfo.java':'''package android.accessibilityservice;public class AccessibilityServiceInfo{public static final int FLAG_REPORT_VIEW_IDS=16,FLAG_RETRIEVE_INTERACTIVE_WINDOWS=64;public int flags;}''',
'android/accessibilityservice/AccessibilityService.java':'''package android.accessibilityservice;import android.content.Context;import android.view.accessibility.*;import java.util.*;public class AccessibilityService extends Context {public AccessibilityServiceInfo getServiceInfo(){return new AccessibilityServiceInfo();}public void setServiceInfo(AccessibilityServiceInfo i){}public AccessibilityNodeInfo getRootInActiveWindow(){return null;}public List<AccessibilityWindowInfo> getWindows(){return Collections.emptyList();}protected void onServiceConnected(){}public void onAccessibilityEvent(AccessibilityEvent e){}public void onInterrupt(){}public void onDestroy(){}}''',
'android/view/accessibility/AccessibilityEvent.java':'''package android.view.accessibility;import java.util.*;public class AccessibilityEvent{public CharSequence getPackageName(){return null;}public CharSequence getContentDescription(){return null;}public List<CharSequence> getText(){return Collections.emptyList();}}''',
'android/view/accessibility/AccessibilityNodeInfo.java':'''package android.view.accessibility;public class AccessibilityNodeInfo{public CharSequence getPackageName(){return null;}public CharSequence getText(){return null;}public CharSequence getContentDescription(){return null;}public int getChildCount(){return 0;}public AccessibilityNodeInfo getChild(int n){return null;}public void recycle(){}}''',
'android/view/accessibility/AccessibilityWindowInfo.java':'''package android.view.accessibility;public class AccessibilityWindowInfo{public AccessibilityNodeInfo getRoot(){return null;}}''',
'android/os/SystemClock.java':'''package android.os;public class SystemClock {public static long elapsedRealtime(){return 0;}}''',
'android/os/Bundle.java':'''package android.os;public class Bundle{public CharSequence getCharSequence(String k,CharSequence d){return d;}}''',
'android/app/Notification.java':'''package android.app;import android.os.Bundle;public class Notification {public static final String EXTRA_TITLE="",EXTRA_BIG_TEXT="",EXTRA_TEXT="",EXTRA_SUB_TEXT="";public Bundle extras=new Bundle();}''',
'android/service/notification/NotificationListenerService.java':'''package android.service.notification;import android.content.Context;public class NotificationListenerService extends Context{public void onListenerConnected(){}public void onNotificationPosted(StatusBarNotification s){}public StatusBarNotification[] getActiveNotifications(){return null;}}''',
'android/service/notification/StatusBarNotification.java':'''package android.service.notification;import android.app.Notification;public class StatusBarNotification{public String getPackageName(){return "";}public Notification getNotification(){return null;}}''',

'com/dolphin/oemhud/NavCue.java':'''package com.dolphin.oemhud;public class NavCue{public String direction="",source="";public int distanceMeters;public static NavCue fromText(String s,String t){return null;}public static boolean hasDistanceToken(String s){return false;}public static boolean hasDirectionToken(String s){return false;}public boolean isUsable(){return false;}public String display(){return "";}}''',
'android/content/SharedPreferences.java':'''package android.content;public interface SharedPreferences{boolean getBoolean(String s,boolean d);int getInt(String s,int d);String getString(String s,String d);Editor edit();interface Editor{Editor putBoolean(String s,boolean b);Editor putInt(String s,int v);Editor putLong(String s,long v);Editor putString(String s,String v);Editor remove(String k);void apply();}}''',
'android/util/Log.java':'''package android.util;public class Log{public static int i(String t,String s){return 0;}}''',
}
extra['com/dolphin/oemhud/BridgeService.java']='''package com.dolphin.oemhud;public class BridgeService{public static boolean onCue(NavCue cue){return true;}}'''
extra['android/content/pm/PackageManager.java']='''package android.content.pm;public class PackageManager{public ApplicationInfo getApplicationInfo(String s,int flags){return new ApplicationInfo();}public CharSequence getApplicationLabel(ApplicationInfo i){return "";}}'''
for name,val in extra.items():
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(val)
PY
find "$TMP/stubs" -name '*.java' > "$TMP/files.txt"
printf '%s\n' \
  app/src/main/java/com/dolphin/oemhud/NavAccessibilityService.java \
  app/src/main/java/com/dolphin/oemhud/NavNotificationService.java \
  app/src/main/java/com/dolphin/oemhud/BridgeLog.java \
  app/src/main/java/com/dolphin/oemhud/NavPackageMatcher.java >> "$TMP/files.txt"
javac -encoding UTF-8 -d "$TMP/classes" @"$TMP/files.txt"
echo 'PASS OEM TMAP accessibility + notification receiver source typecheck against offline Android stubs (NOT real Android SDK build)'
