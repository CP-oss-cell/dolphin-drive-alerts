package com.byd.dolphin.drivealerts.audio

import android.content.Context

enum class SoundFocusMode { REFERENCE, SURROUND, CINEMA }

data class EqSettings(
    val enabled: Boolean = false,
    val bass: Int = 0,
    val mid: Int = 0,
    val treble: Int = 0,
    val centerpoint360: Boolean = false,
    val soundFocus: SoundFocusMode = SoundFocusMode.REFERENCE
)

object EqPreferences {
    private const val PREF = "audio_tuning"
    private const val K_ENABLED = "enabled"
    private const val K_BASS = "bass"
    private const val K_MID = "mid"
    private const val K_TREBLE = "treble"
    private const val K_CENTERPOINT = "centerpoint360"
    private const val K_FOCUS = "sound_focus"

    fun read(context: Context): EqSettings {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val focus = runCatching {
            SoundFocusMode.valueOf(p.getString(K_FOCUS, SoundFocusMode.REFERENCE.name)!!)
        }.getOrDefault(SoundFocusMode.REFERENCE)
        return EqSettings(
            enabled = p.getBoolean(K_ENABLED, false),
            bass = p.getInt(K_BASS, 0).coerceIn(-10, 10),
            mid = p.getInt(K_MID, 0).coerceIn(-10, 10),
            treble = p.getInt(K_TREBLE, 0).coerceIn(-10, 10),
            centerpoint360 = p.getBoolean(K_CENTERPOINT, false),
            soundFocus = focus
        )
    }

    fun setEnabled(context: Context, value: Boolean) = edit(context).putBoolean(K_ENABLED, value).apply()
    fun setBass(context: Context, value: Int) = edit(context).putInt(K_BASS, value.coerceIn(-10, 10)).apply()
    fun setMid(context: Context, value: Int) = edit(context).putInt(K_MID, value.coerceIn(-10, 10)).apply()
    fun setTreble(context: Context, value: Int) = edit(context).putInt(K_TREBLE, value.coerceIn(-10, 10)).apply()
    fun setCenterpoint360(context: Context, value: Boolean) = edit(context).putBoolean(K_CENTERPOINT, value).apply()
    fun setSoundFocus(context: Context, value: SoundFocusMode) = edit(context).putString(K_FOCUS, value.name).apply()

    private fun edit(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
}
