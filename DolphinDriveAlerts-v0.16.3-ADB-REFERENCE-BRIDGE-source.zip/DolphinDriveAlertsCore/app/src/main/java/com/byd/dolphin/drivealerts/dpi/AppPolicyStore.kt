package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.model.OutputRoute

enum class DpiMode { STOCK, DPI_140, DPI_120, MANUAL }

data class AppPolicy(
    val packageName: String,
    val dpiMode: DpiMode = DpiMode.STOCK,
    val manualDpi: Int = 160,
    val audioRoute: OutputRoute = OutputRoute.MEDIA,
    val orientationMode: OrientationMode = OrientationMode.STOCK
) {
    fun requestedDpi(): Int? = when (dpiMode) {
        DpiMode.STOCK -> null
        DpiMode.DPI_140 -> 140
        DpiMode.DPI_120 -> 120
        DpiMode.MANUAL -> manualDpi.coerceIn(120, 640)
    }
}

object AppPolicyStore {
    private const val PREF = "app_policy"
    private const val KEY = "rules"

    fun all(context: Context): Map<String, AppPolicy> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getStringSet(KEY, emptySet()).orEmpty()
        return raw.mapNotNull(::decode).associateBy { it.packageName }
    }

    fun put(context: Context, policy: AppPolicy?) {
        if (policy == null) return
        val map = all(context).toMutableMap()
        map[policy.packageName] = policy
        save(context, map.values)
    }

    fun remove(context: Context, pkg: String) {
        val map = all(context).toMutableMap(); map.remove(pkg); save(context, map.values)
    }

    private fun save(context: Context, values: Collection<AppPolicy>) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putStringSet(KEY, values.map(::encode).toSet()).apply()
    }

    private fun encode(p: AppPolicy) = listOf(
        p.packageName,
        p.dpiMode.name,
        p.manualDpi.toString(),
        p.audioRoute.name,
        p.orientationMode.name
    ).joinToString("|")

    /** v0.11 4-field rules migrate automatically with STOCK orientation. */
    private fun decode(s: String): AppPolicy? = runCatching {
        val x = s.split('|'); require(x.size >= 4)
        AppPolicy(
            packageName = x[0],
            dpiMode = DpiMode.valueOf(x[1]),
            manualDpi = x[2].toInt(),
            audioRoute = OutputRoute.valueOf(x[3]),
            orientationMode = x.getOrNull(4)?.let { OrientationMode.valueOf(it) } ?: OrientationMode.STOCK
        )
    }.getOrNull()
}
