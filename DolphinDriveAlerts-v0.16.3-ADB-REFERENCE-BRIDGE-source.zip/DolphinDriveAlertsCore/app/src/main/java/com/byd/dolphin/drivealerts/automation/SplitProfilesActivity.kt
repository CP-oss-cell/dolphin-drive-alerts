package com.byd.dolphin.drivealerts.automation

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Bundle
import android.view.View
import android.widget.*

/** Editable split profiles and launcher-visible shortcuts (launcher support is device-dependent). */
class SplitProfilesActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var apps: List<AppSelection.App>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apps = AppSelection.launchable(this)
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,20,24,30) }
        setContentView(ScrollView(this).apply { addView(content) })
        redraw()
    }
    private fun label(s: String) = TextView(this).apply { text=s; textSize=17f; setPadding(0,8,0,8) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text=s; setOnClickListener { action() } }
    private fun redraw() {
        content.removeAllViews()
        content.addView(label("화면 분할 프로필 · AutoSplit 방식 통합 후보"))
        content.addView(label("앱 2개/비율/바로가기: 자체 ADB 또는 실차 정상 AutoSplit 프로필 공개 실행 경로를 선택. 원본 연결에는 그 앱의 실제 프로필 ID가 필요합니다."))
        content.addView(button("+ 새 분할 프로필", { edit(null) }))
        content.addView(button("실차 검증된 기존 AutoSplit 앱 열기 (설치된 경우)", {
            val original=packageManager.getLaunchIntentForPackage("com.sspark.bydautosplit")
            if(original!=null)startActivity(original) else toast("BYD AutoSplit 원본 앱 미설치")
        }))
        content.addView(Switch(this).apply {
            text="360 카메라 전체화면 사용 후 분할 비율 복원 감시"
            isChecked=FeatureProfiles.splitEnabled(this@SplitProfilesActivity)
            setOnCheckedChangeListener { _, value -> FeatureProfiles.setSplitEnabled(this@SplitProfilesActivity,value) }
        })
        FeatureProfiles.splits(this).forEach { p ->
            content.addView(label("${p.title}: ${p.firstPackage} + ${p.secondPackage} (${p.primaryPercent}% / ${100-p.primaryPercent}%)" +
                if (p.originalAutoSplitProfileId.isNotBlank()) " · 원본 AutoSplit 프로필 연동" else ""))
            content.addView(button("실행 · ${p.title}", { execute(p) }))
            content.addView(button("비율 ${p.primaryPercent}% 다시 적용 · ${p.title}", {
                Thread({
                    val result=VehicleSplitEngine.applyRatio(applicationContext,p.primaryPercent)
                    runOnUiThread {toast(result.message)}
                },"manual-split-ratio").start()
            }))
            content.addView(button("편집 · ${p.title}", { edit(p) }))
            content.addView(button("앱 서랍/홈 화면용 바로가기 요청 · ${p.title}", { pin(p) }))
            content.addView(button("삭제 · ${p.title}", {
                FeatureProfiles.saveSplits(this,FeatureProfiles.splits(this).filterNot { it.id==p.id }); redraw()
            }))
        }
    }
    private fun edit(existing: SplitProfile?) {
        if (apps.size < 2) { Toast.makeText(this,"실행 가능한 앱이 2개 이상 필요합니다",Toast.LENGTH_LONG).show(); return }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,8,22,4) }
        val name = EditText(this).apply { hint="바로가기 이름"; setSingleLine(); setText(existing?.title?:"") }
        root.addView(name)
        val referenceId = EditText(this).apply {
            hint="기존 AutoSplit 앱의 실제 프로필 ID (선택, 없으면 자체 분할)"
            setSingleLine()
            setText(existing?.originalAutoSplitProfileId.orEmpty())
        }
        root.addView(label("원본 AutoSplit이 설치되어 있고 그 앱의 프로필 ID를 아는 경우에만 입력"))
        root.addView(referenceId)
        val appLabels=apps.map { "${it.title} (${it.packageName})" }
        val first=Spinner(this).apply { adapter=ArrayAdapter(this@SplitProfilesActivity,android.R.layout.simple_spinner_dropdown_item,appLabels) }
        val second=Spinner(this).apply { adapter=ArrayAdapter(this@SplitProfilesActivity,android.R.layout.simple_spinner_dropdown_item,appLabels) }
        root.addView(label("왼쪽/첫 번째 앱"));root.addView(first)
        root.addView(label("오른쪽/두 번째 앱"));root.addView(second)
        val oldPercent=existing?.primaryPercent?:50
        val value=TextView(this).apply { text="첫 번째 앱 ${oldPercent}% / 두 번째 앱 ${100-oldPercent}%" }
        val seek=SeekBar(this).apply {
            max=80;progress=oldPercent-10
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { value.text="첫 번째 앱 ${progress+10}% / 두 번째 앱 ${90-progress}%" }
                override fun onStartTrackingTouch(seekBar: SeekBar?)=Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?)=Unit
            })
        }
        root.addView(value);root.addView(seek)
        existing?.let { old ->
            first.setSelection(apps.indexOfFirst{it.packageName==old.firstPackage}.coerceAtLeast(0))
            second.setSelection(apps.indexOfFirst{it.packageName==old.secondPackage}.coerceAtLeast(0))
        } ?: second.setSelection(1)
        AlertDialog.Builder(this).setTitle(if (existing==null) "분할 프로필 만들기" else "분할 프로필 수정")
            .setView(ScrollView(this).apply { addView(root) }).setNegativeButton("취소",null)
            .setPositiveButton("저장") { _, _ ->
                val a=apps[first.selectedItemPosition].packageName
                val b=apps[second.selectedItemPosition].packageName
                if(a==b){toast("서로 다른 앱 2개를 선택해 주세요");return@setPositiveButton}
                val title=name.text.toString().trim().ifBlank { "분할 ${FeatureProfiles.splits(this).size+1}" }
                val next=SplitProfile(existing?.id?:java.util.UUID.randomUUID().toString(),title,a,b,seek.progress+10,referenceId.text.toString().trim())
                val current=FeatureProfiles.splits(this).filterNot { it.id==next.id }.toMutableList()
                current.add(next);FeatureProfiles.saveSplits(this,current);redraw()
            }.show()
    }
    private fun execute(p: SplitProfile) {
        toast("${p.title}: 분할 실행 요청")
        Thread({
            val result=VehicleSplitEngine.launch(applicationContext,p)
            if (result.success && !result.delegated) SplitRecoveryService.start(applicationContext,p.id)
            runOnUiThread{toast(result.message)}
        },"dolphin-split-ui").start()
    }
    private fun pin(p: SplitProfile) {
        val manager=getSystemService(ShortcutManager::class.java)
        if(manager==null || !manager.isRequestPinShortcutSupported){toast("현재 런처에서 고정 바로가기를 지원하지 않습니다. 앱 내 프로필은 사용 가능합니다.");return}
        val launch=Intent(this,SplitShortcutActivity::class.java).apply {
            action=Intent.ACTION_VIEW;putExtra(SplitShortcutActivity.EXTRA_ID,p.id)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val shortcut=ShortcutInfo.Builder(this,"split_${p.id}")
            .setShortLabel(p.title.take(30)).setLongLabel(p.title.take(80))
            .setIcon(Icon.createWithResource(this,android.R.drawable.ic_menu_crop)).setIntent(launch).build()
        try {
            // Dynamic shortcut is visible in supported launcher menus; pin requests a home/app shortcut.
            manager.addDynamicShortcuts(listOf(shortcut))
            val success=manager.requestPinShortcut(shortcut,null)
            toast(if(success)"런처에 바로가기 등록을 요청했습니다" else "동적 바로가기는 등록했으나 고정 바로가기는 거부됐습니다")
        }catch(t:Throwable){toast("바로가기 등록 실패: ${t.message}")}
    }
    private fun toast(msg:String)=Toast.makeText(this,msg,Toast.LENGTH_LONG).show()
}

class SplitShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id=intent.getStringExtra(EXTRA_ID)
        val p=FeatureProfiles.splits(this).firstOrNull{it.id==id}
        if(p==null){Toast.makeText(this,"삭제되거나 없는 분할 프로필",Toast.LENGTH_LONG).show();finish();return}
        Thread({
            val result=VehicleSplitEngine.launch(applicationContext,p)
            if(result.success && !result.delegated) SplitRecoveryService.start(applicationContext,p.id)
            runOnUiThread {Toast.makeText(this,result.message,Toast.LENGTH_LONG).show();finish()}
        },"split-shortcut").start()
    }
    companion object {const val EXTRA_ID="split_profile_id"}
}
