package com.byd.dolphin.drivealerts.automation

import android.content.Context
import android.content.Intent

/** Avoids duplicate startup when user elects to let the verified original AutoStart own it. */
object OriginalAutoStartBridge {
    const val PACKAGE = "com.sspark.bydautostart"
    @Suppress("DEPRECATION")
    fun installed(context: Context): Boolean = runCatching {
        context.packageManager.getPackageInfo(PACKAGE, 0)
        true
    }.getOrDefault(false)

    fun openSettings(context: Context): Boolean = runCatching {
        val intent: Intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)
}
