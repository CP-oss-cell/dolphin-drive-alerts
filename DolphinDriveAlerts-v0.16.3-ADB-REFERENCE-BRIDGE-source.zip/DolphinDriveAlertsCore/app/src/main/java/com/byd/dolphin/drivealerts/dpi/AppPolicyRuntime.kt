package com.byd.dolphin.drivealerts.dpi

import com.byd.dolphin.drivealerts.model.OutputRoute

/** Runtime route override applies to audio originated by THIS app only. */
object AppPolicyRuntime {
    @Volatile var activeRoute: OutputRoute? = null
}
