package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.util.CoreLog

/** ADB wm density is SYSTEM WIDE. Read back and fail closed, never claim per-app density. */
object DensityController {
    @Volatile private var applied: Int? = null
    fun apply(context: Context, dpi: Int?): Boolean = synchronized(this) {
        val target = dpi?.coerceIn(120, 640)
        if (target == applied) {
            val current = NativeAdbClient.executeShell(context, "wm density")
            if (current.success && matches(current.output, target)) return@synchronized true
        }
        val cmd = if (target == null) "wm density reset" else "wm density $target"
        val result = NativeAdbClient.executeShell(context.applicationContext, cmd)
        if (!result.success) {
            CoreLog.w("DPI", "apply failed $cmd: ${result.message}")
            return@synchronized false
        }
        val readback = NativeAdbClient.executeShell(context.applicationContext, "wm density")
        val ok = readback.success && matches(readback.output, target)
        if (ok) applied = target
        CoreLog.i("DPI", "requested=$target verified=$ok output=${readback.output.take(180)} (system-wide)")
        ok
    }
    private fun matches(output: String, dpi: Int?): Boolean {
        val overrideDpi = Regex("""(?i)override density:\s*(\d+)""").find(output)?.groupValues?.get(1)?.toIntOrNull()
        return if (dpi == null) overrideDpi == null else overrideDpi == dpi
    }
}
