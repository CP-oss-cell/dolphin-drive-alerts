package com.byd.dolphin.drivealerts.dpi

import android.content.Context

/** Top-level user opt-in controlling ALL auto/per-app orientation overlays. */
object RotationPolicy {
    private const val PREF = "global_rotation_v016"
    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        .getBoolean("enabled", true) // migrate existing v0.15 profiles without changing default
    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
        if (!enabled) OrientationOverlayController.clear()
    }
    fun mode(context: Context, requested: OrientationMode): OrientationMode =
        if (enabled(context)) requested else OrientationMode.STOCK
}
