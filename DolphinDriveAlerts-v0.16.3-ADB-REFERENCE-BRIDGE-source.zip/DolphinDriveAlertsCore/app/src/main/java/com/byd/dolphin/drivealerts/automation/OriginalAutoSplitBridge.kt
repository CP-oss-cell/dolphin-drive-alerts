package com.byd.dolphin.drivealerts.automation

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.byd.dolphin.drivealerts.util.CoreLog

/** Documented reference-APK interop discovered in the user's working AutoStart/AutoSplit bytecode.
 * Only the user's matching ORIGINAL AutoSplit profile ID can be passed. We never share its ADB key.
 */
object OriginalAutoSplitBridge {
    private const val PACKAGE = "com.sspark.bydautosplit"
    private const val ACTIVITY = "com.sspark.bydautosplit.QuickSplitActivity"
    private const val ACTION = "com.sspark.bydautosplit.RUN_PROFILE"
    data class Result(val attempted: Boolean, val requested: Boolean, val message: String)

    @Suppress("DEPRECATION")
    fun installed(context: Context): Boolean = runCatching {
        context.packageManager.getPackageInfo(PACKAGE, 0)
        true
    }.getOrDefault(false)

    fun request(context: Context, referenceProfileId: String): Result {
        val id = referenceProfileId.trim()
        if (id.isEmpty()) return Result(false, false, "원본 AutoSplit 프로필 ID 미지정")
        if (id.length > 128 || id.any { Character.isISOControl(it) }) return Result(true, false, "원본 AutoSplit 프로필 ID 형식 오류")
        if (!installed(context)) return Result(true, false, "원본 AutoSplit 앱 미설치")
        val intent = Intent(ACTION).apply {
            component = ComponentName(PACKAGE, ACTIVITY)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra("profile_id", id)
        }
        return try {
            context.startActivity(intent)
            CoreLog.i("ORIGINAL_AUTOSPLIT", "public RUN_PROFILE intent requested")
            Result(true, true, "원본 AutoSplit 프로필 호출 요청됨 (실제 분할/비율은 원본 앱 담당; 호출 성공과 화면 상태는 별도)")
        } catch (e: Exception) {
            CoreLog.w("ORIGINAL_AUTOSPLIT", "public integration blocked: ${e.javaClass.simpleName}")
            Result(true, false, "원본 AutoSplit 공개 실행 거부/미지원: ${e.javaClass.simpleName}")
        }
    }
}
