package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.model.OutputRoute
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Policy surface for external-app routing.
 * Public Android APIs cannot force another UID's playback onto BYD legacy stream 14.
 * Keep the user's per-app choice now, but do not fake a successful route until a
 * vehicle-specific vendor command/API is captured and verified.
 */
object ExternalAppAudioRouter {
    // Research mapping only. No privileged output routing is invoked by this catalog.
    val navigationPackages = setOf(
        "com.skt.tmap.ku", "com.nhn.android.nmap", "net.daum.android.map",
        "kr.mappers.AtlanSmart", "kr.co.telecons.mcon"
    )
    enum class Status { MEDIA_DEFAULT, DRIVER_ROUTE_PENDING_VENDOR_HOOK }

    fun apply(context: Context, packageName: String, route: OutputRoute): Status {
        return when (route) {
            OutputRoute.MEDIA -> Status.MEDIA_DEFAULT
            OutputRoute.DRIVER_STREAM14, OutputRoute.DRIVER_RAW14 -> {
                val uid = runCatching { context.packageManager.getApplicationInfo(packageName, 0).uid }.getOrNull()
                val vendorGranted = context.checkSelfPermission("android.permission.MODIFY_AUDIO_ROUTING") ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                CoreLog.w("APP_AUDIO", "pkg=$packageName uid=$uid modify_audio_routing=$vendorGranted " +
                    "BYD driver output/UID affinity unbound; no cross-UID rerouting performed")
                Status.DRIVER_ROUTE_PENDING_VENDOR_HOOK
            }
        }
    }
}
