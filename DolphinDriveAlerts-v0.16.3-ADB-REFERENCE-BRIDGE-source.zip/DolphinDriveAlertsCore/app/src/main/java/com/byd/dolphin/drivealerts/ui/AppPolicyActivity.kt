package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.*
import com.byd.dolphin.drivealerts.model.OutputRoute

class AppPolicyActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,20,24,20) }
        root.addView(TextView(this).apply { text="지정 앱 · DPI / 화면 회전 / 오디오 정책"; textSize=22f })
        root.addView(TextView(this).apply {
            text="전역 회전 ON일 때 0×0 오버레이로 앱별 회전을 적용합니다. DPI는 Android 전체 wm density를 앱 실행 전 변경/확인하며, 개별 앱 DPI가 아닙니다. 외부 앱 운전석 스피커 이동은 BYD AudioPolicy 권한 미확보로 아직 지원하지 않습니다."
            textSize=13f; setPadding(0,6,0,12)
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val policies = AppPolicyStore.all(this)
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val current = policies[pkg]
            val row = Button(this).apply {
                isAllCaps = false
                text = buildString {
                    append(if (current != null) "✓ " else "○ ")
                    append(ri.loadLabel(pm)); append("\n"); append(pkg)
                    if (current != null) {
                        append("\nDPI=${current.dpiMode}${if(current.dpiMode==DpiMode.MANUAL) "(${current.manualDpi})" else ""}")
                        append(" · ROT=${current.orientationMode} · AUDIO=${current.audioRoute}")
                    }
                }
                setOnClickListener { edit(pkg, ri.loadLabel(pm).toString(), current) }
            }
            list.addView(row, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun edit(pkg: String, label: String, existing: AppPolicy?) {
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(35,10,35,0) }
        val enabled = CheckBox(this).apply { text="이 앱에 정책 적용"; isChecked=existing!=null }
        outer.addView(enabled)

        outer.addView(TextView(this).apply { text="화면 방향" })
        val orientationModes = listOf(
            OrientationMode.STOCK,
            OrientationMode.LANDSCAPE,
            OrientationMode.REVERSE_LANDSCAPE,
            OrientationMode.PORTRAIT,
            OrientationMode.REVERSE_PORTRAIT,
            OrientationMode.SENSOR_LANDSCAPE,
            OrientationMode.FULL_SENSOR
        )
        val orientationLabels = listOf("순정", "가로 고정", "가로 반전", "세로 고정", "세로 반전", "센서 가로", "센서 전체")
        val orientation = Spinner(this).apply {
            adapter = ArrayAdapter(this@AppPolicyActivity, android.R.layout.simple_spinner_dropdown_item, orientationLabels)
            setSelection(orientationModes.indexOf(existing?.orientationMode ?: OrientationMode.STOCK).coerceAtLeast(0))
        }
        outer.addView(orientation)

        outer.addView(TextView(this).apply { text="DPI" })
        val dpi = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity, android.R.layout.simple_spinner_dropdown_item, listOf("순정","140","120","수동"))
            setSelection(when(existing?.dpiMode){ DpiMode.DPI_140->1; DpiMode.DPI_120->2; DpiMode.MANUAL->3; else->0 })
        }
        outer.addView(dpi)
        val manual = EditText(this).apply {
            hint="수동 DPI (120~640)"; inputType=InputType.TYPE_CLASS_NUMBER
            setText((existing?.manualDpi ?: 160).toString())
        }
        outer.addView(manual)

        outer.addView(TextView(this).apply { text="오디오 출력 정책" })
        val audio = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity, android.R.layout.simple_spinner_dropdown_item, listOf("미디어 출력","운전석(앱 알림음만)"))
            setSelection(if(existing?.audioRoute==OutputRoute.DRIVER_STREAM14) 1 else 0)
        }
        outer.addView(audio)
        outer.addView(TextView(this).apply {
            text = "DPI는 시스템 전체 wm density를 임시 변경합니다. '저장 후 실행'은 실행 전 적용값을 검사하고 앱을 엽니다. 종료/복귀할 때 접근성 서비스가 원복합니다."
            textSize=12f
        })

        fun save(): AppPolicy? {
            if (!enabled.isChecked) { AppPolicyStore.remove(this, pkg); return null }
            val mode = when(dpi.selectedItemPosition){1->DpiMode.DPI_140;2->DpiMode.DPI_120;3->DpiMode.MANUAL;else->DpiMode.STOCK}
            val value = manual.text.toString().toIntOrNull()?.coerceIn(120,640) ?: 160
            val route = if(audio.selectedItemPosition==1) OutputRoute.DRIVER_STREAM14 else OutputRoute.MEDIA
            val policy = AppPolicy(pkg,mode,value,route,orientationModes[orientation.selectedItemPosition])
            AppPolicyStore.put(this,policy)
            return policy
        }
        AlertDialog.Builder(this).setTitle(label).setView(outer)
            .setNeutralButton("저장 후 실행") { _, _ ->
                val policy = save()
                refresh()
                Thread {
                    val ok = DensityController.apply(this,policy?.requestedDpi())
                    val launcher = packageManager.getLaunchIntentForPackage(pkg)
                    runOnUiThread {
                        if(ok && launcher!=null) runCatching { startActivity(launcher) }
                            .onFailure { Toast.makeText(this,"앱 실행 실패: ${it.message}",Toast.LENGTH_LONG).show() }
                        else Toast.makeText(this,"DPI 검증 실패 또는 실행 불가 · ADB 권한을 확인하세요",Toast.LENGTH_LONG).show()
                    }
                }.start()
            }.setPositiveButton("저장") { _, _ -> save();refresh() }
            .setNegativeButton("취소", null).show()
    }
}
