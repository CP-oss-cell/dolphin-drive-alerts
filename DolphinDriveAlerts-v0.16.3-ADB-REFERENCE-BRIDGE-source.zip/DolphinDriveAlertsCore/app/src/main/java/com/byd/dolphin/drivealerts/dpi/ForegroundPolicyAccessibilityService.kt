package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.steering.SteeringTripleTapDetector
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors

class ForegroundPolicyAccessibilityService : AccessibilityService() {
    @Volatile private var activePackage: String? = null
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "dpi-adb-worker").apply { isDaemon = true } }

    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
            CoreLog.i("ACCESSIBILITY", "key-event filter enabled")
        }.onFailure { CoreLog.w("ACCESSIBILITY", "key-event filtering failed: ${it.message}") }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val pkg = event.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (pkg == activePackage) return
        activePackage = pkg
        runCatching { worker.execute {
          runCatching {
            if (pkg != activePackage) return@execute
            val policy = AppPolicyStore.all(this)[pkg]
            AppPolicyRuntime.activeRoute = policy?.audioRoute
            val orientation = policy?.orientationMode ?: OrientationMode.STOCK
            CoreLog.i("APP_POLICY", "foreground=$pkg dpi=${policy?.requestedDpi()} orientation=$orientation selfAudio=${policy?.audioRoute}")
            OrientationOverlayController.apply(this, RotationPolicy.mode(this, orientation))
            val success = DensityController.apply(this, policy?.requestedDpi())
            CoreLog.i("APP_POLICY", "DPI_APPLY_RESULT package=$pkg success=$success")
            if (policy != null) ExternalAppAudioRouter.apply(this, pkg, policy.audioRoute)
          }.onFailure { CoreLog.w("ACCESSIBILITY", "policy worker failed for $pkg: ${it.message}", it) }
        } }.onFailure { CoreLog.w("ACCESSIBILITY", "policy enqueue failed: ${it.message}", it) }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        runCatching { SteeringTripleTapDetector.onKeyEvent(this, event) }
            .onFailure { CoreLog.w("ACCESSIBILITY", "key handler error: ${it.message}", it) }
        return false
    }

    override fun onInterrupt() = Unit
    override fun onDestroy() {
        activePackage = null
        AppPolicyRuntime.activeRoute = null
        runCatching { worker.execute {
            DensityController.apply(this, null)
            OrientationOverlayController.clear()
        } }.onFailure { CoreLog.w("ACCESSIBILITY", "restore enqueue: ${it.message}") }
        worker.shutdown()
        super.onDestroy()
    }
}
