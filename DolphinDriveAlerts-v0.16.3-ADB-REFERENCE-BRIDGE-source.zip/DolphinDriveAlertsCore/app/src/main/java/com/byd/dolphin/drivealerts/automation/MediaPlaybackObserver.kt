package com.byd.dolphin.drivealerts.automation

import android.service.notification.NotificationListenerService
import android.content.ComponentName
import android.content.Context
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.util.Log
import com.byd.dolphin.drivealerts.util.CoreLog

/** Media play is targeted to a matching active session; no blind global keyevent. */
class MediaPlaybackObserver : NotificationListenerService() {
    companion object {
        fun play(c: Context, pkg: String): Boolean {
            return try {
                val manager=c.getSystemService(MediaSessionManager::class.java)
                val component=ComponentName(c,MediaPlaybackObserver::class.java)
                val matching=manager.getActiveSessions(component).firstOrNull{ it.packageName==pkg }
                if(matching==null){CoreLog.w("MEDIA_START","No controllable session for $pkg; require notification access");false}
                else {
                    matching.transportControls.play()
                    Thread.sleep(350L)
                    val state = matching.playbackState?.state
                    val confirmed = state == PlaybackState.STATE_PLAYING
                    CoreLog.i("MEDIA_START","pkg=$pkg play_requested=true state=$state confirmed=$confirmed")
                    confirmed
                }
            }catch(t:Throwable){CoreLog.w("MEDIA_START","play failure for $pkg: ${t.message}");false}
        }
    }
}
