package com.byd.dolphin.drivealerts.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.Closeable
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

/**
 * Bass/Mid/Treble and user-selected sound presets only.
 * EVSound reference used only for effect ownership, session lifecycle and readback.
 * No speed compensation (SVC), simulated engine audio, or other-UID speaker routing.
 * Session 0 is a legacy, deprecated compatibility path; the platform may reject it.
 */
class GlobalEqualizerEngine(private val context: Context) : Closeable {
    private val app = context.applicationContext
    private val sessions = ConcurrentHashMap<Int, SessionFx>()
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val data = intent ?: return
            val session = data.getIntExtra(EXTRA_AUDIO_SESSION, -1)
            if (session <= 0) return
            val pkg = data.getStringExtra(EXTRA_PACKAGE_NAME).orEmpty()
            when (data.action) {
                ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "session-open id=$session pkg=$pkg")
                    // Do not apply both session 0 and app session effects to the same stream.
                    sessions.remove(0)?.close()
                    attach(session)
                    refresh()
                }
                ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    CoreLog.i("EQ", "session-close id=$session pkg=$pkg")
                    sessions.remove(session)?.close()
                    if (sessions.isEmpty()) attach(0)
                    refresh()
                }
            }
        }
    }

    fun start() {
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                addAction(ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
            }
            runCatching { app.registerReceiver(receiver, filter) }
                .onSuccess { receiverRegistered = true }
                .onFailure { CoreLog.w("EQ", "session receiver unavailable: ${it.message}", it) }
        }
        attach(0)
        refresh()
    }

    fun refresh() {
        val settings = EqPreferences.read(app)
        if (sessions.isEmpty()) attach(0)
        val results = sessions.values.sortedBy { it.sessionId }.map { fx ->
            fx.sessionId to runCatching { fx.apply(settings) }
                .getOrElse { "ERROR:${it.javaClass.simpleName}" }
        }
        val operational = results.any { it.second.contains("eq=ON") }
        val status = when {
            !settings.enabled -> "EQ 사용 안 함 · 기존 음향 복원"
            operational -> "EQ API 적용/readback 확인(실제 청감 미확인): ${results.joinToString { "세션 ${it.first} ${it.second}" }}"
            else -> "EQ 적용 미확인: ${results.joinToString { "세션 ${it.first} ${it.second}" }}"
        }
        app.getSharedPreferences(STATUS_PREF, Context.MODE_PRIVATE).edit()
            .putString(STATUS_KEY, status).apply()
        CoreLog.i("EQ", "enabled=${settings.enabled} bass=${settings.bass} mid=${settings.mid} " +
            "treble=${settings.treble} focus=${settings.soundFocus} $status")
    }

    private fun attach(sessionId: Int) {
        if (sessions.containsKey(sessionId)) return
        val fx = SessionFx(sessionId)
        sessions[sessionId] = fx
        CoreLog.i("EQ", "attached session=$sessionId")
    }

    override fun close() {
        if (receiverRegistered) {
            runCatching { app.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
        sessions.values.forEach { runCatching { it.close() } }
        sessions.clear()
    }

    private class SessionFx(val sessionId: Int) : Closeable {
        private val equalizer: Equalizer? = runCatching { Equalizer(0, sessionId) }.getOrNull()
        private val bassBoost: BassBoost? = runCatching { BassBoost(0, sessionId) }.getOrNull()
        private val virtualizer: Virtualizer? = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        private val loudness: LoudnessEnhancer? = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()

        // Capture state before touching an effect. Do not disable another app's pre-existing EQ.
        private val eqEnabled = runCatching { equalizer?.enabled }.getOrNull()
        private val eqBands = runCatching {
            equalizer?.let { eq ->
                (0 until eq.numberOfBands.toInt()).map { eq.getBandLevel(it.toShort()) }
            }
        }.getOrNull()
        private val bassEnabled = runCatching { bassBoost?.enabled }.getOrNull()
        private val bassStrength = runCatching { bassBoost?.roundedStrength }.getOrNull()
        private val virtEnabled = runCatching { virtualizer?.enabled }.getOrNull()
        private val virtStrength = runCatching { virtualizer?.roundedStrength }.getOrNull()
        private val loudEnabled = runCatching { loudness?.enabled }.getOrNull()
        private val loudGain = runCatching { loudness?.targetGain }.getOrNull()

        private fun owned(effect: AudioEffect?): Boolean = runCatching { effect?.hasControl() == true }.getOrDefault(false)

        private fun restore() {
            if (owned(equalizer)) runCatching {
                eqBands?.forEachIndexed { i, value -> equalizer?.setBandLevel(i.toShort(), value) }
                if (eqEnabled != null) equalizer?.enabled = eqEnabled
            }.onFailure { CoreLog.w("EQ", "restore equalizer session=$sessionId: ${it.message}", it) }
            if (owned(bassBoost)) runCatching {
                if (bassStrength != null && bassBoost?.strengthSupported == true) bassBoost?.setStrength(bassStrength)
                if (bassEnabled != null) bassBoost?.enabled = bassEnabled
            }
            if (owned(virtualizer)) runCatching {
                if (virtStrength != null && virtualizer?.strengthSupported == true) virtualizer?.setStrength(virtStrength)
                if (virtEnabled != null) virtualizer?.enabled = virtEnabled
            }
            if (owned(loudness)) runCatching {
                if (loudGain != null) loudness?.setTargetGain(loudGain.toInt())
                if (loudEnabled != null) loudness?.enabled = loudEnabled
            }
        }

        fun apply(s: EqSettings): String {
            if (!s.enabled) {
                restore()
                return "OFF/RESTORED"
            }
            // Each effect is independent: missing Virtualizer must not block 3-band EQ.
            val eqStatus = if (!owned(equalizer)) "NO_CONTROL" else runCatching {
                val eq = requireNotNull(equalizer)
                val range = eq.bandLevelRange
                val min = range[0].toInt(); val max = range[1].toInt()
                var mismatched = 0
                for (b in 0 until eq.numberOfBands.toInt()) {
                    val band = b.toShort()
                    val hz = eq.getCenterFreq(band) / 1000
                    val user = when {
                        hz < 250 -> s.bass
                        hz < 4000 -> s.mid
                        else -> s.treble
                    }
                    val modeOffset = when (s.soundFocus) {
                        SoundFocusMode.REFERENCE -> 0
                        SoundFocusMode.SURROUND -> if (hz < 250) 0 else if (hz < 4000) 1 else 2
                        SoundFocusMode.CINEMA -> if (hz < 250) 3 else 1
                    }
                    val effective = (user + modeOffset).coerceIn(-10, 10)
                    val level = if (effective >= 0) (max * (effective / 10.0)).roundToInt()
                        else ((-min) * (effective / 10.0)).roundToInt()
                    val target = level.coerceIn(min, max).toShort()
                    eq.setBandLevel(band, target)
                    if (eq.getBandLevel(band) != target) mismatched++
                }
                val code = eq.setEnabled(true)
                if (code == AudioEffect.SUCCESS && eq.enabled && mismatched == 0) "ON"
                else "READBACK_FAIL(code=$code,mismatch=$mismatched)"
            }.getOrElse { "ERROR:${it.javaClass.simpleName}" }

            if (owned(bassBoost)) runCatching {
                val bb = requireNotNull(bassBoost)
                val strength = ((s.bass.coerceAtLeast(0) * 65) +
                    if (s.soundFocus == SoundFocusMode.CINEMA) 250 else 0).coerceIn(0, 1000)
                if (bb.strengthSupported) bb.setStrength(strength.toShort())
                bb.enabled = strength > 0
            }.onFailure { CoreLog.w("EQ", "bass boost failed session=$sessionId", it) }

            if (owned(virtualizer)) runCatching {
                val v = requireNotNull(virtualizer)
                val strength = when {
                    s.centerpoint360 -> 850
                    s.soundFocus == SoundFocusMode.SURROUND -> 650
                    s.soundFocus == SoundFocusMode.CINEMA -> 350
                    else -> 0
                }
                if (v.strengthSupported) v.setStrength(strength.toShort())
                v.enabled = strength > 0
            }.onFailure { CoreLog.w("EQ", "virtualizer failed session=$sessionId", it) }

            if (owned(loudness)) runCatching {
                val le = requireNotNull(loudness)
                val gain = if (s.soundFocus == SoundFocusMode.CINEMA) 450 else 0
                le.setTargetGain(gain)
                le.enabled = gain > 0
            }.onFailure { CoreLog.w("EQ", "loudness failed session=$sessionId", it) }

            return "eq=$eqStatus bassCtrl=${owned(bassBoost)} spatialCtrl=${owned(virtualizer)}"
        }

        override fun close() {
            restore()
            runCatching { equalizer?.release() }
            runCatching { bassBoost?.release() }
            runCatching { virtualizer?.release() }
            runCatching { loudness?.release() }
        }
    }

    companion object {
        private const val STATUS_PREF = "audio_tuning_runtime"
        private const val STATUS_KEY = "eq_last_state"
        fun readStatus(context: Context): String = context.getSharedPreferences(
            STATUS_PREF, Context.MODE_PRIVATE).getString(STATUS_KEY, "EQ 적용 상태 확인 전").orEmpty()

        private const val ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.OPEN_AUDIO_EFFECT_CONTROL_SESSION"
        private const val ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION = "android.media.action.CLOSE_AUDIO_EFFECT_CONTROL_SESSION"
        private const val EXTRA_AUDIO_SESSION = "android.media.extra.AUDIO_SESSION"
        private const val EXTRA_PACKAGE_NAME = "android.media.extra.PACKAGE_NAME"
    }
}
